param(
  [string]$DataSourceName,
  [string]$PgHost,
  [string]$PgUser = 'postgres',
  [string]$PgPassword,
  [int]$PgPort = 5432,
  [string]$PgDatabase = 'postgres',
  [ValidateSet('disable','allow','prefer','require','verify-ca','verify-full')]
  [string]$PgSslMode = 'require',
  [int]$ListenPort = 9187,
  [string]$PgPasswordFile,
  [string]$ZipPath,
  [string]$DownloadUrl,
  [string]$Sha256,
  [string]$InstallDir = 'C:\Program Files\postgres_exporter',
  [string]$ServiceName = 'postgres_exporter',
  [string]$BindAddress = '',
  [string[]]$RemoteAddress = @('LocalSubnet'),
  [string[]]$FirewallProfile = @('Domain','Private'),
  [string]$WinSwPath,
  [string]$WinSwUrl,
  [string]$WinSwSha256,
  [switch]$AllowAnyRemote,
  [switch]$SkipFirewall,
  [switch]$Force,
  [switch]$Help
)
# =====================================================================================
# PostgresExporter-Register.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
# Installs postgres_exporter UNDER A SERVICE WRAPPER (it cannot be a Windows service on its
# own), keeps the DSN out of the machine environment, and PROVES pg_up 1 before anything.
#
# WHAT CHANGED AND WHY
# --------------------
#  1. [P0-25] THE EXPORTER WAS REGISTERED AS A WINDOWS SERVICE, WHICH IT CANNOT BE.
#     The old script called New-Service + Start-Service, both with -EA SilentlyContinue.
#     postgres_exporter is a plain Go binary with NO Windows service control handler.
#     Verified against the current release: cmd/postgres_exporter/main.go imports only
#     kingpin, the exporter's own collector/config/exporter packages, client_golang,
#     promslog, version and exporter-toolkit/web - there is no golang.org/x/sys/windows/svc
#     and no kardianos/minwinsvc anywhere. The SCM never receives StartServiceCtrlDispatcher
#     and kills the process after 30 seconds with ERROR 1053. Both -EA SilentlyContinue
#     calls hid it and the script logged 'done - scrape at http://<host>:9187/metrics' and
#     exited 0. THIS EXPORTER HAS NEVER RUN ON ANY VM.
#     FIX: it now runs under WinSW (github.com/winsw/winsw), which implements the dispatcher
#     and supervises the child process.
#     WHY WinSW AND NOT NSSM: NSSM's last stable is 2.24 and the newest build on nssm.cc is a
#     2017 pre-release its own author warns about; WinSW is maintained (v2.12.0), is a single
#     self-contained .exe needing no runtime install on Server 2016-2025, and takes a
#     declarative XML service definition with <env> and <onfailure action="restart"/>.
#     The wrapper comes from a staged file or from -WinSwUrl WITH a mandatory -WinSwSha256.
#  2. [P0-25 secrets] THE DATABASE PASSWORD IS OUT OF THE MACHINE ENVIRONMENT.
#     The old script did:
#         [Environment]::SetEnvironmentVariable('DATA_SOURCE_NAME',$DataSourceName,'Machine')
#     which writes the PostgreSQL password in cleartext to
#     HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment - readable by every
#     authenticated user and injected into the environment block of EVERY new process for
#     EVERY user. Any local user could run 'echo $env:DATA_SOURCE_NAME'. It also could not
#     work: services.exe caches the machine environment at startup and does not process
#     WM_SETTINGCHANGE, so a service started in the same session inherits the STALE block
#     with no DSN at all.
#     FIX: the vendor's documented password-to-file mechanism is used instead -
#     DATA_SOURCE_URI + DATA_SOURCE_USER + DATA_SOURCE_PASS_FILE. The password is written
#     to <InstallDir>\.pgpass with inheritance stripped and SYSTEM + Administrators only
#     (ACL VERIFIED), and only the URI, the user name and the FILE PATH go into the service's
#     own environment, inside the WinSW XML - which is itself ACL'd the same way and is read
#     by the SCM at every service start. No secret reaches any environment variable, any
#     command line or any registry value readable by a normal user.
#     This script also DELETES a stale machine DATA_SOURCE_NAME left behind by earlier runs:
#     nothing in the old script ever removed it, so the password persisted in the registry
#     forever, including after an uninstall.
#  3. IT NO LONGER LIES. Proof is now, in order: the binary reports its version; the wrapper
#     service exists and reaches Running; it is STILL Running 40s later (past the SCM's 30s
#     dispatcher deadline); /metrics returns 200 with Prometheus text; and the body contains
#     pg_up 1. pg_up 0 - exporter up, database unreachable or the role is wrong - is a
#     FAILURE, which is exactly the state the old script reported as 'done'.
#  4. THE DSN IS BUILT CORRECTLY. The old string concatenation did no URL-encoding, so a
#     password containing @ / : ? # % or a space produced an invalid URI and the exporter
#     connected to the wrong host or failed with an opaque parse error. Values are now
#     percent-encoded with [uri]::EscapeDataString, and the password is not in the URI at all.
#  5. sslmode DEFAULT CHANGED FROM 'disable' TO 'require'. BEHAVIOUR CHANGE TO REPORT: the
#     old default put the PostgreSQL password and every query and result set on the wire in
#     cleartext, which is indefensible on a multi-tenant IaaS. 'disable' is still available
#     but is now an explicit choice and logs a loud WARN.
#  6. [cross-cutting] THE LISTENER IS NO LONGER WORLD-OPEN. -RemoteAddress defaults to
#     LocalSubnet, -FirewallProfile to Domain,Private, 'Any' is refused unless
#     -AllowAnyRemote is passed, -BindAddress can pin the listener, and the rule is created
#     ONLY after /metrics has been proven.
#  7. The DSN is no longer built BEFORE the -Help block (so -Help no longer builds and
#     discards a DSN), the staged-zip pick is version-aware, service removal POLLS instead of
#     Start-Sleep 2, files are managed idempotently, and there is an unhandled-exception
#     guard with temp cleanup on every path.
#
# PARAMETERS ADDED (none renamed, none removed): -PgPasswordFile, -ZipPath, -DownloadUrl,
#     -Sha256, -InstallDir, -ServiceName, -BindAddress, -RemoteAddress, -FirewallProfile,
#     -WinSwPath, -WinSwUrl, -WinSwSha256, -AllowAnyRemote, -SkipFirewall, -Force.
#
# VERIFIED AGAINST THE CURRENT RELEASE (docs/source, not memory):
#   no Windows service dispatcher in postgres_exporter
#     https://github.com/prometheus-community/postgres_exporter/blob/master/cmd/postgres_exporter/main.go
#   DATA_SOURCE_NAME / DATA_SOURCE_URI / DATA_SOURCE_USER / DATA_SOURCE_PASS_FILE,
#   --web.listen-address, --config.file, pg_up
#     https://github.com/prometheus-community/postgres_exporter/blob/master/README.md
#   WinSW XML elements and the rename-the-exe-next-to-the-xml discovery rule
#     https://github.com/winsw/winsw/blob/v2.12.0/doc/xmlConfigFile.md
#     https://github.com/winsw/winsw/blob/v2/doc/installation.md
#   NSSM status (last stable 2.24, newest build 2017)
#     https://nssm.cc/builds
#
# Log: C:\Scripts\postgresexporter-register.log
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'postgresexporter-register'
$ErrorActionPreference = 'Stop'

$HelpText = @"
postgresexporter-register - SILENT install of postgres_exporter (Prometheus PostgreSQL metrics
                            exporter) UNDER THE WinSW SERVICE WRAPPER, with the password in an
                            ACL-verified file (never the machine environment) and an actual
                            /metrics proof (pg_up 1) before any firewall rule is created.

  postgres_exporter is a plain Go binary with no Windows service dispatcher: registered directly
  with New-Service it is killed by the SCM after 30s with error 1053. It therefore runs under WinSW.
  Stage C:\Scripts\WinSW-x64.exe (or WinSW.NET461.exe), or pass -WinSwPath / -WinSwUrl+-WinSwSha256.

USAGE:
  postgresexporter-register -PgHost <host> -PgUser <user> -PgPasswordFile <file> [-PgPort 5432]
                            [-PgDatabase postgres] [-PgSslMode require] [-ListenPort 9187]
                            [-RemoteAddress 10.20.0.11]
  postgresexporter-register -DataSourceName <dsn>
  postgresexporter-register -Help

PARAMETERS:
  -PgHost           (required unless -DataSourceName) PostgreSQL host.
  -PgUser           DB role for the exporter (default postgres; prefer a least-privilege role with
                    pg_monitor).
  -PgPasswordFile   PREFERRED. File whose first line is the DB password. Never appears in the process
                    table, in a 4688 event, or in the transcript header.
  -PgPassword       DEPRECATED, kept for compatibility. Visible in Win32_Process.CommandLine, in
                    Windows Security event 4688, and in the transcript header. Use -PgPasswordFile or
                    the environment variable YC_POSTGRES_EXPORTER_PASSWORD instead.
  -PgPort           DB port (default 5432).
  -PgDatabase       DB name (default postgres).
  -PgSslMode        disable|allow|prefer|require|verify-ca|verify-full. DEFAULT IS NOW 'require'
                    (it used to be 'disable', which put the password and all query traffic on the
                    wire in cleartext). 'disable' still works but logs a loud WARN.
  -DataSourceName   Full libpq DSN instead of the -Pg* parts. The password then has to live inside
                    the DSN, so it is stored in the ACL-verified service XML and a WARN is logged;
                    the -Pg* form with -PgPasswordFile is strictly better.
  -ListenPort       TCP port for /metrics. Default 9187.
  -BindAddress      Listen address. Default '' = all interfaces. Set the management IP to keep the
                    exporter off the tenant-facing NIC.
  -RemoteAddress    Sources allowed through the inbound rule. Default LocalSubnet. 'Any' is refused
                    unless -AllowAnyRemote is also passed.
  -FirewallProfile  Profiles the rule applies to. Default Domain,Private.
  -AllowAnyRemote   Explicitly allow a world-open rule. Logs a loud WARN.
  -SkipFirewall     Do not create an inbound rule at all.
  -ZipPath          Explicit staged exporter zip. Default: newest
                    C:\Scripts\postgres_exporter-*.windows-amd64.zip by PARSED version.
  -DownloadUrl      Download the exporter zip instead of using a staged one.
  -Sha256           Expected SHA256 of the exporter zip. Strongly recommended.
  -WinSwPath        Explicit WinSW executable. Default: C:\Scripts\WinSW-x64.exe, WinSW.NET461.exe or
                    WinSW.exe.
  -WinSwUrl         Download WinSW from here when it is not staged. Requires -WinSwSha256.
  -WinSwSha256      Expected SHA256 of the WinSW executable.
  -InstallDir       Install folder. Default C:\Program Files\postgres_exporter.
  -ServiceName      Windows service name. Default postgres_exporter.
  -Force            Rewrite the password file and the wrapper XML even if unchanged.
  -Help             Show this help and exit 0.

EXAMPLES:
  set YC_POSTGRES_EXPORTER_PASSWORD=...
  postgresexporter-register -PgHost 10.0.0.5 -PgUser exporter -RemoteAddress 10.20.0.11
  postgresexporter-register -PgHost localhost -PgUser exporter -PgPasswordFile C:\Scripts\.pg.pw
  postgresexporter-register -PgHost db1 -PgUser exporter -PgPasswordFile C:\Scripts\.pg.pw -PgSslMode verify-full
  postgresexporter-register -Help

PROOF PERFORMED (in this order - any failure is a non-zero exit):
  1. postgres_exporter.exe --version                   -> version recorded in the log
  2. the password file and the service XML written, then their ACLs VERIFIED
  3. WinSW wrapper installed; service Running, polled, then re-checked 40s later
  4. GET http://127.0.0.1:<port>/metrics               -> 200, Prometheus text
  5. the body contains 'pg_up 1'                       -> the exporter is really talking to Postgres

EXIT CODES:
  0  Verified: service Running and pg_up 1 on /metrics.
  1  Failure at any step (no installer, no WinSW, service not Running, /metrics dead, pg_up 0).
  2  Usage error (no host/DSN, no password, RemoteAddress Any without -AllowAnyRemote).
  5  Not elevated.
  6  No outbound internet when -DownloadUrl / -WinSwUrl was used.

Log: C:\Scripts\postgresexporter-register.log   Wrapper log: <InstallDir>\logs\
"@

if($Help){ Write-Host $HelpText -ForegroundColor Cyan; Exit-Yc 0 'help shown' 'OK' }
if(-not $DataSourceName -and -not $PgHost){
  Write-Host $HelpText -ForegroundColor Cyan
  Exit-Yc 2 'One of -PgHost or -DataSourceName is required.' 'ERROR'
}

Assert-YcPrereqs -NeedAdmin

# A .cmd wrapper or a parent script passing '-RemoteAddress 10.0.0.1,10.0.0.2' through
# powershell.exe -File delivers ONE string, not two elements, so New-NetFirewallRule would
# receive a single meaningless address. Split it back apart here.
function Split-YcList{
  param([string[]]$Value)
  $out = @()
  foreach($v in $Value){
    foreach($p in ([string]$v -split ',')){
      if($p.Trim().Length -gt 0){ $out += $p.Trim() }
    }
  }
  return $out
}
$RemoteAddress   = Split-YcList $RemoteAddress
$FirewallProfile = Split-YcList $FirewallProfile
$script:YcExit   = 1
$script:YcTemp   = $null
$script:YcSecret = $null

# ------------------------------------------------------------------ helpers

function Write-YcAsciiFile{
  param([string]$Path,[string]$Content)
  $sw = New-Object System.IO.StreamWriter($Path,$false,(New-Object System.Text.ASCIIEncoding))
  try{ $sw.Write($Content) } finally{ $sw.Close() }
}

function Invoke-YcNative{
  param([string]$File,[string[]]$Arguments)
  $ErrorActionPreference = 'Continue'
  $out = & $File @Arguments 2>&1
  $rc  = $LASTEXITCODE
  $txt = @()
  foreach($o in $out){ if($null -ne $o){ $txt += ([string]$o) } }
  return (New-Object psobject -Property @{ Output = $txt; ExitCode = $rc })
}

function Get-YcRedacted([string]$Text){
  $t = $Text
  if($script:YcSecret){ $t = ($t -replace [regex]::Escape($script:YcSecret),'***REDACTED***') }
  return (Protect-YcSecret $t)
}

function Protect-YcFileAcl{
  param([string]$Path)
  $r1 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/inheritance:r')
  $r2 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/grant','*S-1-5-18:(F)','*S-1-5-32-544:(F)')
  if($r1.ExitCode -ne 0 -or $r2.ExitCode -ne 0){
    Write-YcLog ('icacls FAILED on ' + $Path + ' (inheritance rc=' + $r1.ExitCode + ', grant rc=' +
      $r2.ExitCode + '): ' + (($r1.Output + $r2.Output) -join ' ')) 'ERROR'
    return $false
  }
  $allowed = @('S-1-5-18','S-1-5-32-544')
  $acl = Get-Acl -LiteralPath $Path
  if(-not $acl.AreAccessRulesProtected){
    Write-YcLog ('VERIFICATION FAILED: inheritance is still enabled on ' + $Path) 'ERROR'
    return $false
  }
  $bad = @()
  foreach($ace in $acl.Access){
    $sid = $null
    try{ $sid = $ace.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch{ $sid = [string]$ace.IdentityReference }
    if($allowed -notcontains $sid){ $bad += ([string]$ace.IdentityReference + ' (' + $sid + ')') }
  }
  if($bad.Count -gt 0){
    Write-YcLog ('VERIFICATION FAILED: ' + $Path + ' is still accessible to: ' + ($bad -join ', ') +
      '. It contains the PostgreSQL credential.') 'ERROR'
    return $false
  }
  Write-YcLog ('ACL verified on ' + $Path + ': inheritance removed, trustees are exactly SYSTEM ' +
    'and BUILTIN\Administrators.') 'OK'
  return $true
}

function Set-YcManagedFile{
  param([string]$Path,[string]$Content,[switch]$Always)
  if(Test-Path -LiteralPath $Path){
    $cur = Get-Content -LiteralPath $Path -Raw
    if($null -eq $cur){ $cur = '' }
    if($cur -eq $Content -and -not $Always){ Write-YcLog ('Unchanged, left in place: ' + $Path); return $true }
    $bak = $Path + '.bak-' + (Get-Date).ToString('yyyyMMddHHmmss')
    Copy-Item -LiteralPath $Path -Destination $bak -Force
    Write-YcLog ('Content changed; previous file backed up to ' + $bak) 'WARN'
  }
  Write-YcAsciiFile -Path $Path -Content $Content
  Write-YcLog ('Wrote ' + $Path)
  return $true
}

function ConvertTo-YcXmlText([string]$Text){
  $t = $Text
  $t = $t -replace '&','&amp;'
  $t = $t -replace '<','&lt;'
  $t = $t -replace '>','&gt;'
  $t = $t -replace '"','&quot;'
  return $t
}

function Get-YcServiceObject([string]$Name){
  return (Get-Service | Where-Object { $_.Name -eq $Name } | Select-Object -First 1)
}

function Get-YcExporterPassword{
  if($PgPasswordFile){
    if(-not (Test-Path -LiteralPath $PgPasswordFile)){
      Write-YcLog ('-PgPasswordFile not found: ' + $PgPasswordFile) 'ERROR'; return $null
    }
    foreach($l in (Get-Content -LiteralPath $PgPasswordFile)){
      if($null -ne $l -and $l.Trim().Length -gt 0){
        Write-YcLog ('Password read from ' + $PgPasswordFile + ' (never on a command line).')
        return $l.Trim()
      }
    }
    Write-YcLog ('-PgPasswordFile ' + $PgPasswordFile + ' is empty.') 'ERROR'
    return $null
  }
  if($env:YC_POSTGRES_EXPORTER_PASSWORD){
    Write-YcLog 'Password read from environment variable YC_POSTGRES_EXPORTER_PASSWORD.'
    return $env:YC_POSTGRES_EXPORTER_PASSWORD
  }
  if($PgPassword){
    Write-YcLog ('-PgPassword was passed on the command line. That value is visible in ' +
      'Win32_Process.CommandLine, in Windows Security event 4688 (this estate can enable ' +
      'ProcessCreationIncludeCmdLine and forward the Security channel off-box) and in the ' +
      'PowerShell transcript header. Use -PgPasswordFile or YC_POSTGRES_EXPORTER_PASSWORD ' +
      'instead. The value is scrubbed from this log when the run ends.') 'WARN'
    return $PgPassword
  }
  return $null
}

function Get-YcWinSw{
  if($WinSwPath){
    if(-not (Test-Path -LiteralPath $WinSwPath)){ Write-YcLog ('-WinSwPath not found: ' + $WinSwPath) 'ERROR'; return $null }
    return (Get-Item -LiteralPath $WinSwPath)
  }
  foreach($n in @('WinSW-x64.exe','WinSW.NET461.exe','WinSW.NET4.exe','WinSW.exe','winsw.exe')){
    $p = Join-Path 'C:\Scripts' $n
    if(Test-Path -LiteralPath $p){ return (Get-Item -LiteralPath $p) }
  }
  if($WinSwUrl){
    if(-not $WinSwSha256){
      Write-YcLog ('-WinSwUrl requires -WinSwSha256. A service wrapper runs as LocalSystem and ' +
        'supervises a process holding a database credential; it is not downloaded unpinned.') 'ERROR'
      return $null
    }
    Assert-YcPrereqs -NeedInternet
    if(-not $script:YcTemp){
      $script:YcTemp = Join-Path $env:TEMP ('pgexp_' + [guid]::NewGuid().ToString('N'))
      New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
    }
    $dst = Join-Path $script:YcTemp 'WinSW.exe'
    $got = Get-YcFile -Uri $WinSwUrl -OutFile $dst -Sha256 $WinSwSha256 -MinBytes 65536
    if(-not $got){ return $null }
    return (Get-Item -LiteralPath $dst)
  }
  return $null
}

function Remove-YcWrapperService{
  param([string]$Name,[string]$WrapperExe,[int]$TimeoutSec = 60)
  $svc = Get-YcServiceObject $Name
  if(-not $svc){ return $true }
  if($svc.Status -ne 'Stopped'){
    try{ Stop-Service -Name $Name -Force -ErrorAction Stop }
    catch{ Write-YcLog ('Stop-Service ' + $Name + ' failed: ' + $_.Exception.Message) 'WARN' }
  }
  $removed = $false
  if($WrapperExe -and (Test-Path -LiteralPath $WrapperExe)){
    $u = Invoke-YcNative -File $WrapperExe -Arguments @('uninstall')
    if($u.ExitCode -eq 0){ $removed = $true }
    else{ Write-YcLog ('WinSW uninstall returned ' + $u.ExitCode + ': ' + ($u.Output -join ' ')) 'WARN' }
  }
  if(-not $removed){
    $d = Invoke-YcNative -File 'sc.exe' -Arguments @('delete',$Name)
    if($d.ExitCode -ne 0){
      Write-YcLog ('sc.exe delete ' + $Name + ' returned ' + $d.ExitCode + ': ' + ($d.Output -join ' ')) 'WARN'
    }
  }
  $deadline = (Get-Date).AddSeconds($TimeoutSec)
  while((Get-Date) -lt $deadline){
    if(-not (Get-YcServiceObject $Name)){ Write-YcLog ('Service ' + $Name + ' removed.'); return $true }
    Start-Sleep -Seconds 2
  }
  Write-YcLog ('Service ' + $Name + ' is still present ' + $TimeoutSec + 's after removal (deletion ' +
    'pending - something holds an open handle). Refusing to continue.') 'ERROR'
  return $false
}

# The old script's machine-wide DATA_SOURCE_NAME is a cleartext password in
# HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment, readable by every
# authenticated user. Nothing ever removed it. Remove it here, loudly.
function Remove-YcStaleMachineDsn{
  $existing = $null
  try{ $existing = [Environment]::GetEnvironmentVariable('DATA_SOURCE_NAME','Machine') }catch{}
  if($existing){
    Write-YcLog ('A machine-wide environment variable DATA_SOURCE_NAME exists on this host. It was ' +
      'written by the previous version of this script and contains the PostgreSQL password in ' +
      'cleartext in HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment, where every ' +
      'authenticated user can read it and from where it is injected into every new process. ' +
      'REMOVING IT. Rotate that PostgreSQL password: assume it is compromised.') 'WARN'
    try{
      [Environment]::SetEnvironmentVariable('DATA_SOURCE_NAME',$null,'Machine')
      $after = [Environment]::GetEnvironmentVariable('DATA_SOURCE_NAME','Machine')
      if($after){ Write-YcLog 'FAILED to remove the machine-wide DATA_SOURCE_NAME.' 'ERROR'; return $false }
      Write-YcLog 'Machine-wide DATA_SOURCE_NAME removed.' 'OK'
    }catch{
      Write-YcLog ('Could not remove the machine-wide DATA_SOURCE_NAME: ' + $_.Exception.Message) 'ERROR'
      return $false
    }
  }
  return $true
}

# ------------------------------------------------------------------ main

function Invoke-Main{

  # --- 0. inputs ----------------------------------------------------------------------
  $pw = $null
  $useDsnEnv = $false
  if($DataSourceName){
    $useDsnEnv = $true
    $script:YcSecret = $DataSourceName
    Write-YcLog ('-DataSourceName was supplied, so the credential has to travel inside the DSN. It ' +
      'is stored in the service XML, which is ACL''d to SYSTEM + Administrators and verified - but ' +
      'the -PgHost/-PgUser/-PgPasswordFile form is better: it uses the exporter''s documented ' +
      'DATA_SOURCE_PASS_FILE so the password sits in a file of its own.') 'WARN'
  }else{
    $pw = Get-YcExporterPassword
    if(-not $pw){
      Write-YcLog ('No password supplied for PostgreSQL role "' + $PgUser + '". Supply ' +
        '-PgPasswordFile <file>, set YC_POSTGRES_EXPORTER_PASSWORD, or (not recommended) pass ' +
        '-PgPassword. With no password every scrape fails and /metrics reports pg_up 0 while the ' +
        'old script still reported success.') 'ERROR'
      $script:YcExit = 2; return
    }
    $script:YcSecret = $pw
  }
  if($PgSslMode -eq 'disable'){
    Write-YcLog ('-PgSslMode disable sends the PostgreSQL password and every query and result set ' +
      'over the network in cleartext. On a multi-tenant IaaS this is only acceptable for a ' +
      'same-host loopback connection you have separately reasoned about. The default is now ' +
      '"require".') 'WARN'
  }
  if($ListenPort -lt 1 -or $ListenPort -gt 65535){
    Write-YcLog ('-ListenPort ' + $ListenPort + ' is out of range.') 'ERROR'; $script:YcExit = 2; return
  }
  # Test-YcWorldOpen (_yc-lib.ps1) tests EVERY element for Any / * / 0.0.0.0/0 / ::/0 / Internet.
  # The old test was ($RemoteAddress.Count -eq 1 -and $RemoteAddress[0] -eq 'Any'), which let
  # -RemoteAddress 0.0.0.0/0 through unexamined, and let ANY two-element list skip the gate.
  if((Test-YcWorldOpen -Scope $RemoteAddress) -and -not $SkipFirewall -and -not $AllowAnyRemote){
    Write-YcLog ('-RemoteAddress Any would expose /metrics - database names, sizes, replication and ' +
      'connection detail - to every network this VM is attached to, with no TLS and no ' +
      'authentication. Pass your Prometheus servers or the management CIDR, or -SkipFirewall, or ' +
      '-AllowAnyRemote if you really mean it.') 'ERROR'
    $script:YcExit = 2; return
  }
  if(-not (Remove-YcStaleMachineDsn)){ $script:YcExit = 1; return }

  # --- 1. the exporter binary ---------------------------------------------------------
  if(-not $script:YcTemp){
    $script:YcTemp = Join-Path $env:TEMP ('pgexp_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
  }
  $zip = $null
  if($ZipPath){
    if(-not (Test-Path -LiteralPath $ZipPath)){ Write-YcLog ('-ZipPath not found: ' + $ZipPath) 'ERROR'; $script:YcExit = 1; return }
    $zip = Get-Item -LiteralPath $ZipPath
  }elseif($DownloadUrl){
    Assert-YcPrereqs -NeedInternet
    $dst = Join-Path $script:YcTemp 'postgres_exporter.zip'
    $got = Get-YcFile -Uri $DownloadUrl -OutFile $dst -Sha256 $Sha256 -MinBytes 1048576
    if(-not $got){ $script:YcExit = 1; return }
    $zip = Get-Item -LiteralPath $dst
  }else{
    $all = Get-ChildItem -Path 'C:\Scripts\postgres_exporter-*.windows-amd64.zip' -File -ErrorAction Ignore
    if($all){
      $zip = $all | Sort-Object {
          $m = [regex]::Match($_.Name,'(\d+\.\d+\.\d+)')
          if($m.Success){ [version]$m.Groups[1].Value } else { [version]'0.0.0' }
        } -Descending | Select-Object -First 1
    }
  }
  if(-not $zip){
    Write-YcLog ('No postgres_exporter installer. Stage ' +
      'C:\Scripts\postgres_exporter-<ver>.windows-amd64.zip, or pass -ZipPath / -DownloadUrl.') 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcFile -Path $zip.FullName -MinBytes 524288 -Because 'postgres_exporter zip')){ $script:YcExit = 1; return }
  $zh = (Get-FileHash -LiteralPath $zip.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
  if($Sha256 -and -not $DownloadUrl){
    if($zh -ne $Sha256.Trim().ToUpperInvariant()){
      Write-YcLog ('SHA256 MISMATCH on ' + $zip.Name + ': expected ' + $Sha256.Trim().ToUpperInvariant() +
        ', got ' + $zh + '. Refusing to install.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('SHA256 verified: ' + $zh) 'OK'
  }elseif(-not $DownloadUrl){
    Write-YcLog ('No -Sha256 pin supplied. Archive hash is ' + $zh + ' - pin it on the next run.') 'WARN'
  }

  # --- 2. the WinSW wrapper (mandatory) ------------------------------------------------
  $winsw = Get-YcWinSw
  if(-not $winsw){
    Write-YcLog ('No WinSW service wrapper found. postgres_exporter has NO Windows service dispatcher ' +
      '(verified against the current cmd/postgres_exporter/main.go: no golang.org/x/sys/windows/svc, ' +
      'no kardianos/minwinsvc), so registering it directly with New-Service produces a service the ' +
      'SCM kills after 30 seconds with error 1053 - which is why this exporter has never actually run ' +
      'here. Stage C:\Scripts\WinSW-x64.exe (or WinSW.NET461.exe), or pass -WinSwPath, or -WinSwUrl ' +
      'with -WinSwSha256. Refusing to install a service that cannot start.') 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcFile -Path $winsw.FullName -MinBytes 65536 -Because 'WinSW service wrapper')){ $script:YcExit = 1; return }
  if($WinSwSha256 -and -not $WinSwUrl){
    $wh = (Get-FileHash -LiteralPath $winsw.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
    if($wh -ne $WinSwSha256.Trim().ToUpperInvariant()){
      Write-YcLog ('SHA256 MISMATCH on ' + $winsw.Name + ': expected ' +
        $WinSwSha256.Trim().ToUpperInvariant() + ', got ' + $wh + '. Refusing to use it.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('WinSW SHA256 verified: ' + $wh) 'OK'
  }

  # --- 3. lay the files down ----------------------------------------------------------
  if(-not (Test-Path -LiteralPath $InstallDir)){ New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
  $logDir = Join-Path $InstallDir 'logs'
  if(-not (Test-Path -LiteralPath $logDir)){ New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
  $ex = Join-Path $script:YcTemp 'x'
  New-Item -ItemType Directory -Path $ex -Force | Out-Null
  Expand-Archive -Path $zip.FullName -DestinationPath $ex -Force
  $src = Get-ChildItem -Path $ex -Recurse -Filter 'postgres_exporter.exe' -File | Select-Object -First 1
  if(-not $src){ Write-YcLog ('postgres_exporter.exe not found inside ' + $zip.Name) 'ERROR'; $script:YcExit = 1; return }

  $exePath    = Join-Path $InstallDir 'postgres_exporter.exe'
  $wrapperExe = Join-Path $InstallDir ($ServiceName + '-service.exe')
  $wrapperXml = Join-Path $InstallDir ($ServiceName + '-service.xml')
  $pwFile     = Join-Path $InstallDir '.pgpass'

  $existing = Get-YcServiceObject $ServiceName
  if($existing -and $existing.Status -ne 'Stopped'){
    Write-YcLog ('Existing service ' + $ServiceName + ' is ' + $existing.Status + '; stopping it to ' +
      'replace the binaries (upgrade path).')
    try{ Stop-Service -Name $ServiceName -Force -ErrorAction Stop }
    catch{ Write-YcLog ('Stop-Service failed: ' + $_.Exception.Message) 'WARN' }
    Start-Sleep -Seconds 3
  }
  Copy-Item -LiteralPath $src.FullName -Destination $exePath -Force
  Copy-Item -LiteralPath $winsw.FullName -Destination $wrapperExe -Force
  if(-not (Assert-YcFile -Path $exePath -MinBytes 524288 -Because 'installed exporter binary')){ $script:YcExit = 1; return }
  if(-not (Assert-YcFile -Path $wrapperExe -MinBytes 65536 -Because 'installed service wrapper')){ $script:YcExit = 1; return }

  # --- 4. PROOF: the exporter binary runs ---------------------------------------------
  $ver = Invoke-YcNative -File $exePath -Arguments @('--version')
  $verLine = ($ver.Output | Where-Object { $_.Trim().Length -gt 0 } | Select-Object -First 1)
  if($ver.ExitCode -ne 0 -and -not $verLine){
    Write-YcLog ('postgres_exporter.exe --version failed (exit ' + $ver.ExitCode + ').') 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Installed binary: ' + $exePath + ' -- ' + ([string]$verLine).Trim()) 'OK'

  # --- 5. credentials -----------------------------------------------------------------
  # https://github.com/prometheus-community/postgres_exporter/blob/master/README.md
  # DATA_SOURCE_URI carries the host WITHOUT credentials; DATA_SOURCE_USER carries the role;
  # DATA_SOURCE_PASS_FILE points at a file - the vendor's own "password to file" mechanism.
  $envLines = @()
  if($useDsnEnv){
    $envLines += ('DATA_SOURCE_NAME=' + $DataSourceName)
  }else{
    $uri = $PgHost + ':' + $PgPort + '/' + [uri]::EscapeDataString($PgDatabase) + '?sslmode=' + $PgSslMode
    Set-YcManagedFile -Path $pwFile -Content $pw -Always:$Force | Out-Null
    if(-not (Protect-YcFileAcl -Path $pwFile)){ $script:YcExit = 1; return }
    $envLines += ('DATA_SOURCE_URI=' + $uri)
    $envLines += ('DATA_SOURCE_USER=' + $PgUser)
    $envLines += ('DATA_SOURCE_PASS_FILE=' + $pwFile)
    Write-YcLog ('DSN (no credential in it): ' + $uri + ' user=' + $PgUser + ' password from ' +
      $pwFile + ' (ACL verified).') 'OK'
  }

  # --- 6. the WinSW service definition ------------------------------------------------
  $listen = ':' + $ListenPort
  if($BindAddress){ $listen = $BindAddress + ':' + $ListenPort }
  $envXml = ''
  foreach($e in $envLines){
    $i = $e.IndexOf('=')
    $n = $e.Substring(0,$i)
    $v = $e.Substring($i+1)
    $envXml += ('  <env name="' + (ConvertTo-YcXmlText $n) + '" value="' + (ConvertTo-YcXmlText $v) + '"/>' + "`r`n")
  }
  $svcArgs = '--web.listen-address=' + $listen
  $xml = @"
<service>
  <!-- Managed by YallaCloud postgresexporter-register.
       postgres_exporter has no Windows service dispatcher of its own, so the SCM would kill
       it after 30s with error 1053. WinSW implements the dispatcher and supervises the child.
       The environment below is the SERVICE's own, not the machine environment: the previous
       version of this script wrote the whole DSN, password included, to
       HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment, where every
       authenticated user could read it and every new process inherited it. -->
  <id>$(ConvertTo-YcXmlText $ServiceName)</id>
  <name>Prometheus postgres_exporter (YallaCloud)</name>
  <description>Exports PostgreSQL metrics for Prometheus. Managed by C:\Scripts\PostgresExporter-Register.ps1.</description>
  <executable>$(ConvertTo-YcXmlText $exePath)</executable>
  <arguments>$(ConvertTo-YcXmlText $svcArgs)</arguments>
  <workingdirectory>$(ConvertTo-YcXmlText $InstallDir)</workingdirectory>
$envXml  <startmode>Automatic</startmode>
  <delayedAutoStart/>
  <onfailure action="restart" delay="10 sec"/>
  <stoptimeout>15 sec</stoptimeout>
  <logpath>$(ConvertTo-YcXmlText $logDir)</logpath>
  <log mode="roll-by-size">
    <sizeThreshold>10240</sizeThreshold>
    <keepFiles>8</keepFiles>
  </log>
</service>
"@
  Set-YcManagedFile -Path $wrapperXml -Content $xml -Always:$Force | Out-Null
  if(-not (Protect-YcFileAcl -Path $wrapperXml)){ $script:YcExit = 1; return }

  # --- 7. install the wrapper service --------------------------------------------------
  $svc = Get-YcServiceObject $ServiceName
  $needInstall = $true
  if($svc){
    $curBin = ''
    $k = 'HKLM:\SYSTEM\CurrentControlSet\Services\' + $ServiceName
    if(Test-Path $k){ try{ $curBin = [string](Get-ItemProperty -Path $k).ImagePath }catch{} }
    if($curBin -like ('*' + $wrapperExe + '*')){
      Write-YcLog ('Service ' + $ServiceName + ' already runs under this wrapper - reusing it; the XML ' +
        'is re-read at every start, so a config change lands on restart (idempotent).')
      $needInstall = $false
    }else{
      Write-YcLog ('Service ' + $ServiceName + ' exists but is NOT the wrapper (ImagePath: ' + $curBin +
        '). That is the broken registration this fix exists to replace - removing it.') 'WARN'
      if(-not (Remove-YcWrapperService -Name $ServiceName -WrapperExe $wrapperExe)){ $script:YcExit = 1; return }
    }
  }
  if($needInstall){
    $ins = Invoke-YcNative -File $wrapperExe -Arguments @('install')
    foreach($l in $ins.Output){ if($l.Trim().Length -gt 0){ Write-Host ('    ' + (Get-YcRedacted $l)) } }
    if($ins.ExitCode -ne 0){
      Write-YcLog ('WinSW install FAILED (exit ' + $ins.ExitCode + ').') 'ERROR'
      $script:YcExit = 1; return
    }
    if(-not (Get-YcServiceObject $ServiceName)){
      Write-YcLog ('VERIFICATION FAILED: service ' + $ServiceName + ' does not exist after WinSW ' +
        'install returned 0.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('Service ' + $ServiceName + ' created under the WinSW wrapper.') 'OK'
  }
  $sc1 = Invoke-YcNative -File 'sc.exe' -Arguments @('config',$ServiceName,'start=','delayed-auto')
  if($sc1.ExitCode -ne 0){
    Write-YcLog ('sc.exe config start= delayed-auto returned ' + $sc1.ExitCode + ': ' + ($sc1.Output -join ' ')) 'WARN'
  }

  # --- 8. PROOF: it runs and STAYS running --------------------------------------------
  $svc = Get-YcServiceObject $ServiceName
  try{
    if($svc.Status -eq 'Running'){ Restart-Service -Name $ServiceName -Force -ErrorAction Stop }
    else{ Start-Service -Name $ServiceName -ErrorAction Stop }
  }catch{
    Write-YcLog ('Start-Service ' + $ServiceName + ' FAILED: ' + $_.Exception.Message +
      '. Wrapper log: ' + $logDir) 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcService -Name $ServiceName -TimeoutSec 60 -Because 'postgres_exporter under WinSW')){
    $script:YcExit = 1; return
  }
  Start-Sleep -Seconds 40
  $svc2 = Get-YcServiceObject $ServiceName
  if((-not $svc2) -or ($svc2.Status -ne 'Running')){
    $st = 'absent'; if($svc2){ $st = [string]$svc2.Status }
    Write-YcLog ('VERIFICATION FAILED: ' + $ServiceName + ' reached Running but is "' + $st + '" 40s ' +
      'later - the classic no-service-dispatcher / error 1053 pattern, or the exporter crashed on ' +
      'startup. Wrapper log: ' + $logDir) 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Service ' + $ServiceName + ' is Running and stayed Running past the 30s SCM ' +
    'dispatcher deadline that used to kill this exporter.') 'OK'

  # --- 9. PROOF: /metrics answers AND the exporter is really talking to PostgreSQL ----
  $probeHost = '127.0.0.1'
  if($BindAddress){ $probeHost = $BindAddress }
  $url = 'http://' + $probeHost + ':' + $ListenPort + '/metrics'
  if(-not (Assert-YcHttp -Uri $url -ExpectStatus 200 -TimeoutSec 90 -MatchContent '# HELP')){
    Write-YcLog ('VERIFICATION FAILED: ' + $url + ' did not return Prometheus text. No firewall rule ' +
      'was created. Wrapper log: ' + $logDir) 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcHttp -Uri $url -ExpectStatus 200 -TimeoutSec 60 -MatchContent 'pg_up 1')){
    Write-YcLog ('VERIFICATION FAILED: ' + $url + ' answered 200 but pg_up is not 1. The exporter is ' +
      'running and is NOT collecting from PostgreSQL - check the host/port, sslmode (' + $PgSslMode +
      '), the role and its pg_monitor grant. This is exactly the state the old script reported as ' +
      '"done".') 'ERROR'
    $script:YcExit = 1; return
  }

  # --- 10. side effects ONLY after the thing they support is proven -------------------
  if($SkipFirewall){
    Write-YcLog '-SkipFirewall set: no inbound rule created.'
  }else{
    $rn = 'YallaCloud postgres_exporter in ' + $ListenPort
    if(Get-NetFirewallRule -DisplayName $rn -ErrorAction Ignore){
      Write-YcLog ('Inbound firewall rule already present: ' + $rn)
    }else{
      if($AllowAnyRemote -and (Test-YcWorldOpen -Scope $RemoteAddress)){
        Write-YcLog ('Opening TCP ' + $ListenPort + ' to ANY remote address, as explicitly requested.') 'WARN'
      }
      try{
        New-NetFirewallRule -DisplayName $rn -Direction Inbound -Action Allow -Protocol TCP `
          -LocalPort $ListenPort -RemoteAddress $RemoteAddress -Profile $FirewallProfile `
          -Description 'Prometheus scrape of postgres_exporter. Managed by YallaCloud.' `
          -ErrorAction Stop | Out-Null
      }catch{
        Write-YcLog ('Firewall rule creation FAILED: ' + $_.Exception.Message) 'ERROR'
        $script:YcExit = 1; return
      }
      if(-not (Get-NetFirewallRule -DisplayName $rn -ErrorAction Ignore)){
        Write-YcLog ('VERIFICATION FAILED: firewall rule "' + $rn + '" does not exist after ' +
          'New-NetFirewallRule returned.') 'ERROR'
        $script:YcExit = 1; return
      }
      Write-YcLog ('Inbound allow verified: TCP ' + $ListenPort + ' from ' + ($RemoteAddress -join ',') +
        ' on profile(s) ' + ($FirewallProfile -join ',')) 'OK'
    }
  }

  Write-YcLog ('DONE. ' + $ServiceName + ' Running under WinSW, ' + $url + ' returned 200 with pg_up 1, ' +
    'credential in an ACL-verified file and NOT in the machine environment.') 'OK'
  $script:YcExit = 0
}

try{
  Invoke-Main | Out-Null
}catch{
  Write-YcLog ('UNHANDLED EXCEPTION: ' + (Get-YcRedacted $_.Exception.Message)) 'ERROR'
  if($_.ScriptStackTrace){ Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}finally{
  if($script:YcTemp -and (Test-Path -LiteralPath $script:YcTemp)){
    try{ Remove-Item -LiteralPath $script:YcTemp -Recurse -Force }
    catch{ Write-YcLog ('Could not remove temp dir ' + $script:YcTemp + ': ' + $_.Exception.Message) 'WARN' }
  }
}

if($script:YcExit -eq 0){ Exit-Yc 0 'postgresexporter-register verified' 'OK' }
Exit-Yc $script:YcExit 'postgresexporter-register FAILED - nothing was reported as working that is not proven' 'ERROR'
