@echo off
rem Stamp 2026-08-19: added the missing "exit /b %ERRORLEVEL%" and documented -PartialPayload.
rem yc-compliance [-Path <folder>] [-OutDir <folder>] [-Fix] [-Json] [-Quiet]
rem               [-PartialPayload] [-Help]
rem Exit code gates the build: 0 pass, non-zero = a blocking defect. In full-payload mode WRAPPER and
rem CATALOG completeness findings are FAIL. -PartialPayload downgrades them to INFO and does NOT certify.
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Yc-Compliance.ps1" %*
exit /b %ERRORLEVEL%
