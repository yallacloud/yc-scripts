# Bytebase - YallaCloud deployment note

ASCII only. Written 2026-08-16 against Bytebase 3.21.1.
Updated 2026-08-19: the file list in section 11 quoted session temp paths (/tmp/repair3/...)
that exist on no image; it now uses repaired-scripts\... relative paths.

---

## 1. What Bytebase is

Bytebase is a database DevOps and access-control platform. It is the change
pipeline and the front door for databases, in the same way a CI system is the
change pipeline for application code. It solves four problems:

1. **Schema migration review and change workflow.** A developer raises an
   issue containing DDL/DML; the change goes through an approval workflow and
   a rollout plan across environments (dev -> test -> prod), and the applied
   history is recorded per database. Both a UI workflow and a GitOps workflow
   (migrations live in a repo, a PR triggers the change) are supported.
2. **SQL review / lint.** A configurable policy engine rejects statements
   that violate house rules before they reach production - missing WHERE on
   UPDATE/DELETE, no primary key, disallowed column types, naming conventions,
   table drops.
3. **SQL Editor with query control.** An audited console for running queries,
   with read-only/admin modes, per-query approval, row limits, result export
   control and data masking.
4. **Access control and audit.** RBAC over projects, environments and
   databases; an audit log of who queried or changed what.

It supports roughly 33 engines. Relevant to this estate: **SQL Server 2019+**
has Change Workflow (UI and GitOps), Batch Change, SQL Lint, the full SQL
Editor, RBAC, Audit, Query Control, Data Masking and Schema Synchronisation.
It does **not** get Online Schema Change (MySQL only) or State-Based Migration
(PostgreSQL only). MySQL, PostgreSQL, Oracle, MariaDB, MongoDB, Redis,
Snowflake, ClickHouse and BigQuery are also supported.

Docs: <https://docs.bytebase.com/introduction/supported-databases>

---

## 2. The deployment decision, and the evidence

### Decision: option (a)

* **Server**: `deploy-bytebase.sh` - a bash script that deploys the pinned
  Docker image on a **Linux** Docker host (a CloudStack/KVM guest, or a
  PVE-managed host), behind the **existing** HAProxy + keepalived pair.
* **Windows**: `Set-BytebaseClient.ps1` + `set-bytebaseclient.cmd` - configures
  and proves **CLIENT** access only. It installs no server component.

### Why: Bytebase has no Windows server deployment. At all.

**Evidence 1 - the image manifest.** Queried live against
`registry-1.docker.io`. The tag `bytebase/bytebase:3.21.1` and the tag
`bytebase/bytebase:latest` resolve to the identical multi-arch index digest
`sha256:6bc68141455da4964f3e469b606955906290602afb1f8fc4c9c584457b053b40`,
whose platform list is exactly:

```
linux/amd64   sha256:3ab85a747ae5334f91...
linux/arm64   sha256:b38cf9e9ab4c3348a5...
```

There is no `windows/amd64` manifest. Windows containers therefore cannot run
this image under any host configuration - the runtime has nothing to pull.

**Evidence 2 - the vendor says so.** "The image only supports `linux/amd64`
and `linux/arm64` architectures."
<https://docs.bytebase.com/get-started/self-host/deploy-with-docker>

**Evidence 3 - the supported methods.** The self-host documentation covers
Docker and Kubernetes only, plus an official Helm chart. There is no Windows
binary, no MSI, no Windows service, and no `bytebase.exe` release asset.
<https://docs.bytebase.com/get-started/self-host/deploy-with-kubernetes>

### Why option (b) was rejected

Running the Linux image on Windows would require Docker Desktop and a nested
WSL2 Linux VM. That is a licensed desktop product requiring an interactive
user session; it cannot be sealed into a Server 2016-2025 golden image and
started unattended by cloud-init or SYSTEM; and it would place a production
database-change console inside a Linux VM inside a Windows VM inside KVM. This
shop already runs Linux KVM/PVE hosts. The server belongs on Linux. Anything
else would be a fake Windows installer.

---

## 3. Facts the scripts encode

| Fact | Value |
| --- | --- |
| Image repository | bytebase/bytebase |
| Pinned default tag | 3.21.1 (pushed 2026-08-13) |
| Index digest of 3.21.1 | sha256:6bc68141455da4964f3e469b606955906290602afb1f8fc4c9c584457b053b40 |
| Platforms | linux/amd64, linux/arm64 |
| Default listen port | 8080 |
| Volume path inside container | /var/opt/bytebase |
| Health endpoint | /healthz (HTTP 200) |
| Metadata default | embedded PostgreSQL in the data directory |
| External metadata store | PostgreSQL 14+, UTF-8 database, owner role |
| Minimum Docker version | 20.10.24 |

Server startup flags used, verbatim from
<https://www.bytebase.com/docs/reference/command-line/>:

```
--data          directory where Bytebase stores metadata if --pg is not specified   (default ".")
--port          port where Bytebase server runs                                     (default 8080)
--external-url  the external URL where user visits Bytebase, must start with
                http:// or https://                                                 (default "")
--pg            optional external PostgreSQL instance connection url; the
                environment variable equivalent is PG_URL                           (default "")
```

The scripts pass the external PostgreSQL DSN as the **`PG_URL` environment
variable**, never as `--pg` on a command line, because argv is world-readable
in `ps` and lands in shell history and audit records.

---

## 4. Why `--external-url` is a required, validated parameter

Bytebase sits behind the HAProxy VIP, so the server itself never observes the
public hostname or the `https` scheme. Every absolute URL it generates is
built from `--external-url`:

* the OAuth2/OIDC `redirect_uri` for SSO, and the SCIM endpoints - the docs
  state it "is required for SSO and SCIM";
* webhook callback URLs;
* the links embedded in issue, approval and rollout notifications.

Set it wrong and the console still loads - which is exactly why this fails
quietly. SSO breaks at the redirect and every notification mails a link to
`http://localhost:8080`. Both scripts therefore reject a missing scheme, a
path, a query or a fragment, and warn on `http://`, on `localhost`/loopback
hosts, and on a trailing slash (which is stripped).

If the HAProxy frontend hostname ever changes, **re-run `deploy-bytebase.sh`
with the new `--external-url`**. Changing only the proxy is not enough.

Doc: <https://docs.bytebase.com/get-started/self-host/external-url>

---

## 5. TLS and the existing reverse proxy

Bytebase does not terminate TLS:

> "Bytebase service itself does not provide native HTTPS support. We recommend
> using a reverse proxy (Nginx, Caddy) on the same VM for Docker deployments,
> or ingress/gateway for Kubernetes deployments."
> <https://docs.bytebase.com/get-started/self-host/external-access>

This estate already has HAProxy + keepalived and an internal ACME CA, so the
script **does not** install nginx, Caddy or certbot and **does not** issue a
certificate. It binds the container to loopback and emits the correct HAProxy
backend stanza with `--emit-haproxy`. The operator validates and reloads
HAProxy - the script never reloads someone else's ingress.

Two things in the emitted stanza are not optional:

* `timeout tunnel 3600s` (and `timeout server 3600s`). The SQL Editor uses
  WebSocket on `/v1:adminExecute` and `/lsp`; the vendor's own nginx sample
  sets 3600s. Without it the editor disconnects every 30-60 seconds.
* `http-check send meth GET uri /healthz` + `http-check expect status 200`.
  `/healthz` is the same endpoint the vendor uses as the Kubernetes
  `livenessProbe`.

The Windows client script validates the TLS chain with **default** .NET
certificate validation on purpose. If the internal ACME CA root is not in
`LocalMachine\Root`, the script fails with exit 11 and tells you to pass
`-CaCertPath`. A client that "works" because validation was disabled is not a
configured client.

---

## 6. What "proven" means here

The sibling-script incident - an undocumented switch, a rejected command line,
a 4-second exit, 14 silent no-op runs - is the reason these post-conditions
exist. `docker run` returning 0 proves nothing.

`deploy-bytebase.sh` will not report success unless **all** of the following
hold:

1. `docker inspect` shows `State.Status == running` and
   `State.Restarting == false`. On failure it dumps the last 40 container log
   lines and exits 5.
2. The running container's image id (`docker inspect <name> --format
   '{{.Image}}'`) is byte-identical to the image id of the requested tag
   (`docker image inspect <repo>:<tag> --format '{{.Id}}'`). This is the
   authoritative version proof; it cannot be satisfied by a stale container or
   a mis-tagged image. Mismatch exits 7.
3. `GET http://<bind>:<port>/healthz` returns **HTTP 200** within
   `--health-timeout` (default 300s, matching the vendor's own
   `initialDelaySeconds: 300`). Failure dumps container logs and exits 6.
4. `GET http://<bind>:<port>/` returns 200 (WARN, not fatal, if not).
5. Best effort: `GET /v1/actuator/info` is parsed for a `version` field and
   compared to the requested tag. This endpoint is **not** in the published
   documentation, so a miss is logged INFO and a mismatch WARN - step 2 is the
   authority, and the note says so rather than pretending otherwise.

Supply chain: the resolved repo digest is logged, compared against a built-in
known-good digest for the default version (WARN on drift), and can be made
fatal with `--expect-digest`.

`Set-BytebaseClient.ps1` proves: DNS resolves the console host; the TLS chain
validates against the machine trust store; `/healthz` returns 200
(`Assert-YcHttp -Fatal`, exit 8); `/` returns 200; a CA import is re-read back
from `LocalMachine\Root` by thumbprint; the recorded URL file and the machine
environment variable are read back after writing.

---

## 7. Upgrade and backup of the migration history

**This is the part that matters.** The metadata store holds the applied
migration history of every database Bytebase manages. Losing it does not lose
your data, but it loses the record of every change ever applied and the state
Bytebase uses to decide what to apply next.

The vendor's documented order is: stop and remove the container, **back up the
metadata**, then start the new tag.
<https://docs.bytebase.com/get-started/self-host/upgrade>

`deploy-bytebase.sh` enforces that order and refuses to skip it:

* Re-running with the **same** `--version` that is already running is a no-op
  that only re-proves the deployment. Safe for cloud-init and RMM.
* Re-running with a **different** `--version` is refused with **exit 9**
  unless `--allow-upgrade` is passed. No silent version bumps.
* With `--allow-upgrade`, the container is stopped **first**, then the backup
  is taken, then the container is removed and recreated. If the backup fails,
  the script exits 10 and the upgrade does not happen, unless `--skip-backup`
  is explicitly given.

### Embedded PostgreSQL (default)

Metadata lives in the host bind mount (default `/var/lib/bytebase/data`,
mounted at `/var/opt/bytebase`). The directory is **not** touched when the
container is replaced - that is what makes the vendor's "just change the tag"
upgrade work. Backup, container stopped:

```
docker stop bytebase
tar czf /var/backups/bytebase/bytebase-data-$(date +%Y%m%d-%H%M%S).tar.gz -C /var/lib/bytebase/data .
```

The container must be stopped. The vendor is explicit: "Copy the directory
only while Bytebase is stopped. A copy taken from a running instance captures
PostgreSQL mid-write and may not restore."

Restore - as root, with a command that preserves ownership. `tar` as root and
`cp -a` do; a plain `cp -r` does not, and PostgreSQL refuses to start when it
does not own its files:

```
docker stop bytebase
mv /var/lib/bytebase/data /var/lib/bytebase/data.old
mkdir -p /var/lib/bytebase/data
tar xzf /var/backups/bytebase/bytebase-data-<stamp>.tar.gz -C /var/lib/bytebase/data
```

Then start the **previous** image tag, confirm, and only then delete
`data.old`.

### External PostgreSQL (recommended for production)

Metadata lives in the database named in `PG_URL`. The script dumps it with
`pg_dump` before an upgrade, gzipped to `--backup-dir` at mode 0600. If
`pg_dump` is not installed it **refuses the upgrade** (exit 10) rather than
proceeding unbacked. Manual equivalent:

```
pg_dump --dbname="$PG_URL" --no-owner --no-privileges | gzip -9 > bytebase-meta.sql.gz
```

Note that the embedded PostgreSQL listens only on a Unix socket inside the
container and shuts down with Bytebase, so it cannot be dumped from another
host - which is one more reason to use external PostgreSQL. HA is also
unsupported on embedded PostgreSQL.

### Rolling back

Restore the backup, then start the **old** tag:

```
./deploy-bytebase.sh --external-url https://bytebase.corp.example.com --version 3.20.1 --allow-upgrade --skip-backup
```

`--skip-backup` is correct here only because you have just restored a known
good backup and the current state is the bad one.

---

## 8. Secret handling

The metadata DSN is a database superuser-grade credential. It is handled as
follows:

* Supplied to the script as `--pg-url-file /etc/yallacloud/bytebase-pg.url`,
  a root-owned 0600 file. The script tightens the mode if it is looser and
  warns if the owner is not root.
* Passed to the container through a 0600 `--env-file` created under `/run` and
  deleted on exit. It is **never** an argv element, so it never appears in
  `ps`, in shell history, or in a 4688-equivalent audit record.
* Every log path runs through a redactor that masks
  `postgres://user:PASSWORD@` and any `PG_URL=` / `password=` / `token=`
  assignment. The Windows script uses `Protect-YcSecret` and
  `Write-YcInvocation` from `_yc-lib.ps1`, so nothing reaches
  `C:\Scripts\bytebase-client.log` or the Application event log unmasked.
* **Honest caveat:** `docker inspect bytebase` still shows `PG_URL` in
  `.Config.Env`. That is inherent to how the image takes the setting; there is
  no secrets-file option in the image. The script logs this as a WARN. Mitigate
  by restricting `docker` group membership - anyone in it is already root
  equivalent.

---

## 9. Licensing - the verdict for a commercial redistributor

Bytebase is **not** plain open source. The repository is dual licensed:

> "Portions of this software are licensed as follows:
> - Source code files that contain 'enterprise' in their dirname, is licensed
>   under the license defined in 'LICENSE.enterprise'.
> - Any code controlling feature, permission, role and plan enablement.
> - Content outside of the above mentioned directories or restrictions above
>   is available under the 'MIT Expat' license as defined below."

So the bulk of the code is MIT Expat, but the enterprise directories **and all
feature/permission/role/plan gating code** are under a proprietary Enterprise
Licence. The Enterprise Licence permits copying and modification "for
development and testing purposes, without requiring a subscription", but
production use, and the copy/merge/publish/distribute/sublicense/sell rights,
require a valid Bytebase Enterprise subscription.

### Plan limits

* **Community (free, forever)** - self-host or cloud, up to **20 users** and
  **10 database instances**. No SSO. No audit log.
* **Pro** - cloud only, USD 20/user/month, 10 instances. Adds Google/GitHub
  SSO, 7-day audit retention, Batch Query, read-only query auto-routing, user
  groups.
* **Enterprise** - custom users and instances, self-host or cloud. Adds
  OAuth2/OIDC/LDAP SSO, unlimited audit retention, Approval Workflow, Risk
  Assessment, Dynamic Data Masking, Restrict Data Copying, Just-in-Time
  Access, Custom Roles, Data Classification, Auth Policies (2FA, password,
  sign-in), SCIM/Entra/AD/Okta provisioning. HA is an Enterprise add-on.

<https://www.bytebase.com/pricing/> and
<https://docs.bytebase.com/administration/license>

### The verdict

1. **Internal use is fine.** YallaCloud running one Community instance for its
   own engineers, under 20 users and 10 instances, needs no subscription.
2. **Reselling or multi-tenanting it is not.** Standing Bytebase up as a
   service that YallaCloud's tenants log into is exactly the case the
   Enterprise Licence carves out - the enterprise-licensed code includes the
   plan and permission enablement logic that such a service depends on, and
   the licence conditions distribution and production exploitation on a valid
   subscription. **Talk to Bytebase sales and get a written OEM/redistribution
   term before any tenant sees this console.**
3. **Do not remove or bypass the licence gating.** That code is specifically
   named as enterprise-licensed. Patching it out is a licence breach, not a
   configuration choice.
4. **Practically**, the 20-user / 10-instance Community ceiling and the
   absence of SSO and audit log make Community unsuitable for tenant-facing
   use anyway. Any real deployment here is an Enterprise conversation.
5. **Per-tenant model.** If tenants want Bytebase, the defensible pattern is
   one instance per tenant on their own subscription, deployed with this
   script into their own VM - YallaCloud provides the automation, the tenant
   holds the licence. That keeps YallaCloud out of the redistribution
   question entirely.

---

## 10. Integrating the existing SQL Server estate

SQL Server 2019+ is a first-class target. What to do, in order:

1. **Create a dedicated login per instance.** Do not reuse `sa`, and do not
   reuse an application login. Bytebase needs enough rights to read metadata
   and to apply the DDL you intend to approve through it - which means the
   grant is a change-controlled decision per instance, not a default.
2. **Register the instance in the console** under Instances, using that login.
   Neither script does this: registering an instance means handing Bytebase a
   database credential, and an unattended golden-image script has no business
   doing that. The scripts log a line saying exactly this.
3. **Network path.** Bytebase connects outbound from the Linux Docker host to
   TCP 1433 on each SQL Server. Allow that path from the Bytebase host's
   address only - not from the management CIDR at large.
4. **Environments and approval.** Map dev/test/prod to Bytebase environments
   and attach the SQL review policy per environment. Approval Workflow and
   Risk Assessment are Enterprise features; on Community you get lint plus
   manual review, which is still an improvement on ad-hoc SSMS changes.
5. **Known gaps for SQL Server.** No Online Schema Change (MySQL only), no
   State-Based Migration (PostgreSQL only). Schema Synchronisation is
   available. Plan migrations as versioned DDL, not as state diffs.
6. **The metadata store is not SQL Server.** Bytebase stores its own metadata
   in PostgreSQL only - embedded, or external PostgreSQL 14+. There is no
   option to keep Bytebase's own state in the SQL Server estate.

---

## 11. Files

```
repaired-scripts\deploy-bytebase.sh          Linux server deployment (bash)
repaired-scripts\Set-BytebaseClient.ps1      Windows CLIENT configuration
repaired-scripts\set-bytebaseclient.cmd      canonical .cmd wrapper
repaired-scripts\BYTEBASE-NOTES.md           this note
```

Deploy the two Windows files to `C:\Scripts` alongside `_yc-lib.ps1`. The
bash script belongs on the Linux Docker host, not in the golden image.
