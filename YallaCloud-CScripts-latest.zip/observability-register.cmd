@echo off
setlocal
rem ================================================================================================
rem observability-register - Windows audit hardening + ONE observability collector stack.
rem                          Wrapper for C:\Scripts\Setup-Observability.ps1.
rem
rem WHAT CHANGED, AND WHY:
rem   - The old wrapper had no usage text at all and no "exit /b", so cloud-init and the RMM never
rem     saw a real exit code.
rem   - It no longer advertises secrets on the command line. ANYTHING typed here is readable by any
rem     local user through the process table, is recorded in Windows event 4688 when command-line
rem     auditing is on, and lands in the PowerShell transcript header. Use the *File parameters.
rem   - The script this calls NO LONGER enables command-line auditing or forwards the Security
rem     channel by default: those two together shipped every password on every command line to the
rem     observability platform. They are now -EnableCmdLineAudit and -ForwardSecurityLog.
rem   - The SQL maintenance block is gone: use install-sql (it verifies the Ola Hallengren
rem     procedures exist before registering any task and uses integrated auth).
rem
rem USAGE:
rem   observability-register -OOEndpoint <url> -OOUser <u> -OOPassFile <file> [-OOOrg default]
rem   observability-register -Collector otel -OOEndpoint <url> -OOAuthFile <file>
rem   observability-register -Collector prometheus -RemoteAddress <cidr>
rem   observability-register -Help
rem
rem COLLECTORS:  -Collector alloy (default) | otel | prometheus | all
rem SECRETS (prefer the file form):  -OOPassFile  -OOAuthFile  -SqlPassFile
rem SCOPING:     -RemoteAddress <cidr[,cidr]>   -FirewallProfile Domain,Private   -SkipFirewall
rem AUDIT:       -EnableCmdLineAudit   -ForwardSecurityLog   -SkipAudit   -EventLogMB <n>
rem
rem EXIT CODES: 0 everything proven | 1 a component failed | 2 usage | 5 not elevated
rem Logs: C:\Scripts\observability-register.log plus the per-product register logs.
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Setup-Observability.ps1" %*
exit /b %ERRORLEVEL%
