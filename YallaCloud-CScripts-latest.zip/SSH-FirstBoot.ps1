# SSH-FirstBoot.ps1 - GISSHInit first-boot task: give THIS clone its own SSH host keys.
#
# WHAT CHANGED (2026-08-16 audit P0-1) AND WHY
#   The old guard was "if ssh_host_ed25519_key is MISSING, run ssh-keygen -A". sshd is a
#   baked service and doseal.cmd never emptied C:\ProgramData\ssh, so the key always
#   existed at seal time, the guard was true on every clone, and ssh-keygen -A has never
#   run on a single deployed VM. The whole fleet answered with the build VM's host key:
#   anyone with the golden image, or root on any one VM, could impersonate every VM, and
#   because the key never changed the host-key-mismatch warning never fired.
#   Now the logic is inverted: regenerate UNLESS a marker keyed to THIS machine's SID says
#   the keys were generated on this clone. sysprep /generalize resets the machine SID
#   (documented Microsoft behaviour) but does not touch files, so a marker baked into the
#   image can never match a clone - the keys are regenerated exactly once per clone.
#   ssh-keygen -A only creates key types that do NOT already exist, so the inherited keys
#   are deleted first, otherwise -A is a no-op. Private keys are re-ACL'd to SYSTEM +
#   Administrators, and GISSHInit is unregistered only after every host key file exists
#   AND sshd is Running - otherwise the task stays and retries at the next boot.
#
# WHAT CHANGED (2026-08-19) AND WHY
#   The GISSHInit removal printed OK without verifying it. It is now re-read with
#   Get-ScheduledTask and a surviving task is an ERROR with exit 11. Added the EXIT CODES
#   section (0, 1, 11) that this script never had.
#
# Runs as SYSTEM from a scheduled task: no prompts, no admin check, idempotent, re-entrant.
# PowerShell 5.1 only, ASCII only. No key material is ever written to the log.
param([switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'ssh-firstboot'
if($Help){
@"
ssh-firstboot  -  regenerate the per-clone OpenSSH host keys, then retire the GISSHInit task.
USAGE:
  ssh-firstboot
  ssh-firstboot -Help
PARAMETERS:
  -Help  Show this help and exit.
EXAMPLES:
  ssh-firstboot
  ssh-firstboot -Help
EXIT CODES:
  0   Host keys are present for every required key type (private + public), sshd is Running,
      the per-clone marker was written, and GISSHInit was verified absent by re-reading it.
  1   Host key files are still missing and/or sshd is not Running. GISSHInit is deliberately
      KEPT registered so it retries at the next boot.
  11  The work succeeded but Unregister-ScheduledTask did not take effect - GISSHInit is still
      registered. Remove it by hand.
Log: C:\Scripts\ssh-firstboot.log
"@ | Write-Host -ForegroundColor Cyan; Stop-YcLog 0; exit 0
}

$ErrorActionPreference = 'SilentlyContinue'
$sshDir = 'C:\ProgramData\ssh'
$marker = 'C:\Scripts\.sshhostkeys'
# What ssh-keygen -A generates by default. DSA is intentionally NOT required: OpenSSH
# disabled it in 9.9 and removed it in 10.0, so -A no longer produces ssh_host_dsa_key.
# A stale ssh_host_dsa_key from an older build is deleted with the rest either way.
$types = @('rsa','ecdsa','ed25519')

# Machine identity that sysprep /generalize is guaranteed to change: the local account
# domain SID. Not secret, but only the short form is logged.
function Get-YcMachineId{
    try{
        $u = Get-CimInstance Win32_UserAccount -Filter "LocalAccount=true" -ErrorAction Stop | Select-Object -First 1
        if($u -and $u.SID){
            $s = New-Object System.Security.Principal.SecurityIdentifier($u.SID)
            if($s.AccountDomainSid){ return $s.AccountDomainSid.Value }
            return [string]$u.SID
        }
    }catch{}
    try{
        $g = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name 'MachineGuid' -ErrorAction Stop).MachineGuid
        if($g){ return ('GUID-' + $g) }
    }catch{}
    return ('HOST-' + $env:COMPUTERNAME)
}

function Get-YcMissingHostKeys{
    $missing = @()
    foreach($t in $types){
        foreach($sfx in @('','.pub')){
            $n = 'ssh_host_' + $t + '_key' + $sfx
            if(-not (Test-Path (Join-Path $sshDir $n))){ $missing += $n }
        }
    }
    return $missing
}

function Set-YcHostKeyAcl{
    # OpenSSH refuses a host private key that other principals can read/write.
    foreach($f in @(Get-ChildItem -Path $sshDir -Filter 'ssh_host_*_key' -File -ErrorAction SilentlyContinue)){
        & icacls $f.FullName /inheritance:r 2>&1 | Out-Null
        & icacls $f.FullName /grant 'NT AUTHORITY\SYSTEM:(F)' 'BUILTIN\Administrators:(F)' 2>&1 | Out-Null
    }
}

$id = Get-YcMachineId
$kg = @("$env:WINDIR\System32\OpenSSH\ssh-keygen.exe",
        'C:\Program Files\OpenSSH\OpenSSH-Win64\ssh-keygen.exe',
        'C:\Program Files\OpenSSH\ssh-keygen.exe') | Where-Object { Test-Path $_ } | Select-Object -First 1
if(-not $kg){ $kg = (Get-ChildItem 'C:\Program Files\OpenSSH' -Recurse -Filter ssh-keygen.exe -ErrorAction SilentlyContinue | Select-Object -First 1).FullName }

$markerId = ''
if(Test-Path $marker){
    $markerId = (('' + (Get-Content -Path $marker -TotalCount 1 -ErrorAction SilentlyContinue))).Trim()
}
$missing = @(Get-YcMissingHostKeys)
$mine    = ($markerId -ne '') -and ($markerId -eq $id) -and ($missing.Count -eq 0)

if($mine){
    Write-YcLog 'host keys were generated on this clone already - keeping them' 'INFO'
}else{
    if($markerId -ne '' -and $markerId -ne $id){
        Write-YcLog 'host key marker belongs to another machine (golden image leftover) - regenerating' 'WARN'
    }elseif($missing.Count -gt 0){
        Write-YcLog ('host key files missing (' + ($missing -join ',') + ') - regenerating') 'WARN'
    }else{
        Write-YcLog 'no per-clone host key marker - generating this clone its own host keys' 'INFO'
    }

    Remove-Item -LiteralPath $marker -Force -ErrorAction SilentlyContinue
    Stop-Service -Name sshd -Force -ErrorAction SilentlyContinue
    if(-not (Test-Path $sshDir)){ New-Item -ItemType Directory -Path $sshDir -Force | Out-Null }

    # ssh-keygen -A skips key types that already exist, so the inherited ones must go first.
    $old = @(Get-ChildItem -Path $sshDir -Filter 'ssh_host_*' -File -ErrorAction SilentlyContinue)
    foreach($f in $old){ Remove-Item -LiteralPath $f.FullName -Force -ErrorAction SilentlyContinue }
    Write-YcLog ('removed ' + $old.Count + ' inherited host key file(s)') 'INFO'

    if($kg){
        & $kg -A 2>&1 | Out-Null
        Write-YcLog 'ssh-keygen -A completed' 'INFO'
    }else{
        Write-YcLog 'ssh-keygen.exe not found - falling back to sshd generating host keys at service start' 'WARN'
    }
    Set-YcHostKeyAcl
}

Set-Service -Name sshd -StartupType Automatic -ErrorAction SilentlyContinue
for($i = 0; $i -lt 12; $i++){
    $svc = Get-Service -Name sshd -ErrorAction SilentlyContinue
    if($svc -and $svc.Status -eq 'Running'){ break }
    Start-Service -Name sshd -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 5
}

# Only retire the task once the outcome is actually verified (P0-1).
$missing = @(Get-YcMissingHostKeys)
$svc     = Get-Service -Name sshd -ErrorAction SilentlyContinue
$running = ($svc -ne $null) -and ($svc.Status -eq 'Running')

if($missing.Count -eq 0 -and $running){
    Set-YcHostKeyAcl
    Set-Content -Path $marker -Value $id -Encoding ascii -Force
    Write-YcLog ('host keys present for ' + $types.Count + ' key types (private + public) and sshd is Running') 'OK'
    # 2026-08-19 (D5): the removal was fire-and-forget - Unregister-ScheduledTask with
    # -ErrorAction SilentlyContinue followed by an unconditional 'OK' line. If the removal
    # failed (task locked, running, ACL, missing ScheduledTasks module) the log said the task
    # was gone while GISSHInit stayed registered and regenerated the host keys at EVERY boot,
    # so every SSH client saw a changed host key every time. Re-read it with Get-ScheduledTask
    # and only claim success once it is verified absent. yc-firstboot.ps1 already does this.
    Unregister-ScheduledTask -TaskName 'GISSHInit' -Confirm:$false -ErrorAction SilentlyContinue
    if(Get-ScheduledTask -TaskName 'GISSHInit' -ErrorAction SilentlyContinue){
        Write-YcLog 'GISSHInit is STILL REGISTERED after Unregister-ScheduledTask - the removal did not take effect. This task will run again at the next boot and, because the marker written above is now valid, it will keep the keys; but if the marker is ever lost or the machine SID changes the host keys WILL be regenerated on every boot and every SSH client will see a changed host key. Remove the task by hand: Unregister-ScheduledTask -TaskName GISSHInit -Confirm:$false' 'ERROR'
        Stop-YcLog 11
        exit 11
    }
    Write-YcLog 'GISSHInit verified absent by re-reading it with Get-ScheduledTask - the task is gone and this clone has its own host keys' 'OK'
    Stop-YcLog 0
    exit 0
}

if($missing.Count -gt 0){ Write-YcLog ('host key files still missing: ' + ($missing -join ',')) 'ERROR' }
if(-not $running){ Write-YcLog 'sshd is not Running' 'ERROR' }
Write-YcLog 'GISSHInit kept registered - it will run again at the next boot' 'WARN'
Stop-YcLog 1
exit 1
