<#
=============================================================================
 Set-BytebaseClient.ps1 - YallaCloud C:\Scripts toolkit
=============================================================================

 STAMP
   2026-08-19 - documented the previously undocumented exit code 3 (C:\Scripts\_yc-lib.ps1
   missing, nothing was attempted). No behaviour changed.

 WHAT THIS IS
   CLIENT-side configuration for an EXISTING Bytebase server. It makes a
   Windows Server 2016-2025 golden image able to REACH and TRUST the Bytebase
   database-DevOps console, and it PROVES that it can before reporting
   success. Bytebase is the schema-migration review / change-workflow / SQL
   review / access-control platform this estate points at its SQL Server,
   MySQL and PostgreSQL instances.

 WHAT THIS IS NOT, AND WHY
   THIS SCRIPT DOES NOT INSTALL A BYTEBASE SERVER ON WINDOWS, BECAUSE THERE
   IS NO SUCH THING. That is a statement of fact, not a limitation of this
   script:

     * The published container image advertises exactly two platforms in its
       manifest list - linux/amd64 and linux/arm64. There is no windows/amd64
       manifest, so Windows containers cannot run it under any configuration.
       (Verified against registry-1.docker.io for bytebase/bytebase:3.21.1,
       index digest
       sha256:6bc68141455da4964f3e469b606955906290602afb1f8fc4c9c584457b053b40.)
     * The vendor states it: "The image only supports linux/amd64 and
       linux/arm64 architectures."
       https://docs.bytebase.com/get-started/self-host/deploy-with-docker
     * The only documented self-host methods are Docker and Kubernetes, with
       an official Helm chart. There is no Windows binary, no MSI, no Windows
       service, and no bytebase.exe release asset.
       https://docs.bytebase.com/get-started/self-host/deploy-with-kubernetes

   Running the Linux image on Windows would mean Docker Desktop and a nested
   WSL2 Linux VM - an interactive-session desktop product, inside a Windows
   VM, inside KVM - to host a production database-change console. That is not
   sealed into a golden image and it is not supportable. The SERVER is
   deployed by the sibling script deploy-bytebase.sh on a Linux Docker host.
   This script is the Windows half of the same job and nothing more.

 WHAT IT DELIBERATELY DOES NOT DO
   - No server, no Docker, no container, no database.
   - No inbound firewall rule. A console CLIENT needs outbound 443 only, which
     the default Windows profile already permits. Inbound scoping to a
     management CIDR is the SERVER's problem and is handled by
     deploy-bytebase.sh --mgmt-cidr.
   - No TLS termination and no certificate issuance. It will IMPORT the
     internal ACME CA root you hand it so the console's certificate chains,
     and that is all.
   - No Bytebase API calls: it does not create projects, register SQL Server
     instances, or push credentials. Registering an instance means handing
     Bytebase a database login, which is a change-controlled action, not
     something an unattended golden-image script should do.

=============================================================================
#>

[CmdletBinding()]
param(
    [string]$ExternalUrl,
    [string]$CaCertPath,
    [int]$TimeoutSec = 90,
    [switch]$NoShortcut,
    [switch]$Diagnose,
    [switch]$Help
)

$ErrorActionPreference = 'Stop'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc
# is missing. Everything after this point exits via Exit-Yc, so the transcript
# always ends with [END] exit=<n>.
$YcLib = Join-Path $PSScriptRoot '_yc-lib.ps1'
if (-not (Test-Path -LiteralPath $YcLib)) { $YcLib = 'C:\Scripts\_yc-lib.ps1' }
if (-not (Test-Path -LiteralPath $YcLib)) {
    Write-Host ''
    Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
    Write-Host '*** Nothing was configured. Re-deploy the C:\Scripts payload and re-run.   ***' -ForegroundColor Red
    Write-Host ''
    exit 3
}
. $YcLib
Start-YcLog 'bytebase-client'

# -----------------------------------------------------------------------------
# Help
# -----------------------------------------------------------------------------
function Show-BbHelp {
@'
=============================================================================
Set-BytebaseClient.ps1 - configure and PROVE CLIENT access to a Bytebase server
=============================================================================

THE ONLY COMMAND MOST PEOPLE NEED:

  set-bytebaseclient -ExternalUrl https://bytebase.example.com

That points this machine at the Bytebase server and PROVES it can reach it. If it cannot, it
tells you which step failed - DNS, TCP, TLS or HTTP - instead of just failing.

USAGE
  set-bytebaseclient -ExternalUrl <URL> [-CaCertPath <file>]
                     [-TimeoutSec <n>] [-NoShortcut]
  set-bytebaseclient -Diagnose        re-run the checks against the URL already configured
  set-bytebaseclient -Help

EXIT CODES: 0 configured and proved reachable. 1 the server could not be reached or did not
  answer as Bytebase - the message says which step failed. 2 bad arguments. 5 not elevated.
LOG: C:\Scripts\set-bytebaseclient.log

  Runs as Administrator. Installs NO Bytebase server - Bytebase has no Windows
  server build (its container image publishes only linux/amd64 and
  linux/arm64). The server lives on a Linux Docker host, deployed by the
  sibling script deploy-bytebase.sh.

PARAMETERS
  -ExternalUrl <URL>   REQUIRED (except with -Diagnose or -Help).
                       The console URL, e.g. https://bytebase.corp.example.com
                       This MUST be byte-for-byte the same value the server
                       was started with as --external-url.

                       WHY THAT MATTERS AND WHY IT IS VALIDATED HERE:
                       Bytebase sits behind the HAProxy + keepalived VIP, so
                       the server never observes the public hostname or the
                       https scheme itself. Every absolute URL it emits - the
                       OAuth/OIDC redirect_uri, the SSO and SCIM endpoints,
                       webhook callbacks, and the links inside issue and
                       approval notifications - is generated from
                       --external-url. If this client is pointed at a
                       different name than the server was configured with,
                       the console loads but SSO fails at the redirect and
                       every notification link is wrong. The vendor documents
                       the flag as "the external URL where user visits
                       Bytebase, must start with http:// or https://" and as
                       "required for SSO and SCIM".
                       Rejected: no scheme, a path/query/fragment, whitespace.
                       Warned: http://, localhost, a trailing slash (stripped).

  -CaCertPath <file>   .cer/.crt/.pem root of the internal ACME CA. Imported
                       into LocalMachine\Root, idempotently by thumbprint, so
                       the console certificate chains for every user and for
                       SYSTEM. Omit it if the CA is already distributed by
                       Group Policy - the script verifies the chain either
                       way and fails if it does not validate.

  -TimeoutSec <n>      Seconds to wait for the console to answer. Default 90.
  -NoShortcut          Do not create the Start Menu shortcut.
  -Diagnose            Change NOTHING. Report the recorded URL, CA trust,
                       chain validation, reachability, and server version.
  -Help                This text.

EXAMPLES
  Set-BytebaseClient.ps1 -ExternalUrl https://bytebase.corp.example.com
  Set-BytebaseClient.ps1 -ExternalUrl https://bytebase.corp.example.com -CaCertPath C:\Scripts\yc-internal-ca.cer
  Set-BytebaseClient.ps1 -Diagnose

EXIT CODES
  0   success - the console answered, /healthz returned 200, the TLS chain
      validated, and the URL was recorded machine-wide
  2   usage or -ExternalUrl validation error
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4   -CaCertPath is missing, empty, or not a parseable certificate
  5   not running as Administrator
  6   no outbound internet / name resolution for the console host
  8   the console did not return HTTP 200 within -TimeoutSec
  11  the TLS chain for the console did not validate (import the internal
      ACME CA root with -CaCertPath, or fix GPO distribution)

LOG
  C:\Scripts\bytebase-client.log, plus the Windows Application event log
  under source YallaCloud (1000 start, 1001 info, 1002 warn, 1003 error,
  1099 end).
=============================================================================
'@ | Write-Host
}

if ($Help) {
    Show-BbHelp
    Exit-Yc 0 'help displayed' 'OK'
}

Write-YcInvocation -BoundParameters $PSBoundParameters

$script:BbStateDir  = 'C:\Scripts'
$script:BbStateFile = Join-Path $script:BbStateDir 'bytebase-client.url.txt'
$script:BbEnvVar    = 'BYTEBASE_EXTERNAL_URL'
$script:BbShortcut  = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Bytebase Console.url'

Assert-YcPrereqs -NeedAdmin

# -----------------------------------------------------------------------------
# URL validation
# -----------------------------------------------------------------------------
function Resolve-BbUrl {
    param([string]$Url)
    if ([string]::IsNullOrWhiteSpace($Url)) {
        Exit-Yc 2 '-ExternalUrl is REQUIRED. It must match the servers --external-url exactly; see -Help for why it cannot be guessed.' 'ERROR'
    }
    if ($Url -match '\s') {
        Exit-Yc 2 ("-ExternalUrl must not contain whitespace: '" + $Url + "'") 'ERROR'
    }
    # A userinfo component would put a credential in the URL, and that URL is
    # about to be written to C:\Scripts, to a machine environment variable, and
    # to a Start Menu shortcut - three world-readable places. Reject it, and
    # redact it on the way out so the rejection message is not itself the leak.
    if ($Url -match '^(?i)https?://[^/@]*@') {
        Exit-Yc 2 ('-ExternalUrl contains embedded credentials (a user:password@ component): ' + (Protect-YcSecret $Url) + ' . Bytebase --external-url is an origin, not a credential carrier, and this value gets recorded machine-wide. Remove the userinfo and authenticate in the console.') 'ERROR'
    }
    if ($Url -notmatch '^(?i)https?://') {
        Exit-Yc 2 ("-ExternalUrl must start with http:// or https:// (got '" + $Url + "'). The vendor documents the flag as 'must start with http:// or https://'.") 'ERROR'
    }
    $trimmed = $Url
    while ($trimmed.EndsWith('/')) { $trimmed = $trimmed.Substring(0, $trimmed.Length - 1) }
    if ($trimmed -ne $Url) {
        Write-YcLog ("stripped the trailing slash from -ExternalUrl; using '" + $trimmed + "'") 'INFO'
    }
    $uri = $null
    try { $uri = [Uri]$trimmed } catch {
        Exit-Yc 2 ("-ExternalUrl is not a parseable URL: '" + $Url + "'") 'ERROR'
    }
    if ([string]::IsNullOrWhiteSpace($uri.Host)) {
        Exit-Yc 2 ("-ExternalUrl has no host component: '" + $Url + "'") 'ERROR'
    }
    if ($uri.AbsolutePath -and $uri.AbsolutePath -ne '/') {
        Exit-Yc 2 ("-ExternalUrl must be scheme://host[:port] only - no path. Got '" + $Url + "'. Bytebase stores an origin, and a path here breaks every generated SSO redirect and notification link.") 'ERROR'
    }
    if ($uri.Query -or $uri.Fragment) {
        Exit-Yc 2 ("-ExternalUrl must not contain a query or fragment. Got '" + $Url + "'.") 'ERROR'
    }
    if ($uri.Scheme -eq 'http') {
        Write-YcLog 'the console URL is plain http. This estate terminates TLS on HAProxy with the internal ACME CA; session cookies will not be marked secure over http. Use https unless this is a lab.' 'WARN'
    }
    if (@('localhost','127.0.0.1','::1','0.0.0.0') -contains $uri.Host) {
        Write-YcLog ("the console host is '" + $uri.Host + "'. Every link Bytebase generates will point at the loopback of whatever machine renders it. Only acceptable for a throwaway lab.") 'WARN'
    }
    return $trimmed
}

# -----------------------------------------------------------------------------
# TLS chain validation - separate from reachability, so the failure is honest
# -----------------------------------------------------------------------------
function Test-BbTlsChain {
    param([string]$Url, [int]$TimeoutMs = 15000)
    $uri = [Uri]$Url
    if ($uri.Scheme -ne 'https') {
        return [pscustomobject]@{ Applicable = $false; Valid = $true; Subject = ''; Issuer = ''; NotAfter = $null; Reason = 'not https' }
    }
    $port = $uri.Port
    if ($port -le 0) { $port = 443 }
    $tcp = $null; $ssl = $null
    $result = [pscustomobject]@{ Applicable = $true; Valid = $false; Subject = ''; Issuer = ''; NotAfter = $null; Reason = '' }
    try {
        Set-YcTls
        $tcp = New-Object System.Net.Sockets.TcpClient
        $iar = $tcp.BeginConnect($uri.Host, $port, $null, $null)
        if (-not $iar.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) {
            $result.Reason = "TCP connect to $($uri.Host):$port timed out"
            return $result
        }
        $tcp.EndConnect($iar)
        $ssl = New-Object System.Net.Security.SslStream($tcp.GetStream(), $false)
        # Default validation on purpose: we WANT this to throw if the internal
        # ACME CA root is not trusted by this machine.
        $ssl.AuthenticateAsClient($uri.Host)
        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)
        $result.Subject  = $cert.Subject
        $result.Issuer   = $cert.Issuer
        $result.NotAfter = $cert.NotAfter
        $result.Valid    = $true
        $result.Reason   = 'chain validated against the machine trust store'
    } catch {
        $result.Reason = ([string]$_.Exception.Message) -replace '[\r\n]+', ' '
    } finally {
        if ($ssl) { try { $ssl.Dispose() } catch {} }
        if ($tcp) { try { $tcp.Close() } catch {} }
    }
    return $result
}

function Get-BbServerVersion {
    param([string]$Url, [int]$TimeoutSec = 15)
    # /v1/actuator/info is NOT in the published documentation, so this is
    # strictly informational corroboration. The authoritative version proof
    # lives on the server side, in deploy-bytebase.sh, where the running
    # container's image id is compared to the requested tag.
    try {
        $r = Invoke-WebRequest -Uri ($Url + '/v1/actuator/info') -UseBasicParsing -TimeoutSec $TimeoutSec -ErrorAction Stop
        $body = [string]$r.Content
        if ($body -match '"version"\s*:\s*"([^"]+)"') { return $Matches[1] }
    } catch {}
    return ''
}

function Get-BbRecordedUrl {
    if (Test-Path -LiteralPath $script:BbStateFile) {
        try { return ((Get-Content -LiteralPath $script:BbStateFile -TotalCount 1 -ErrorAction Stop) -as [string]).Trim() } catch {}
    }
    return ''
}

# -----------------------------------------------------------------------------
# Diagnose - installs and changes nothing
# -----------------------------------------------------------------------------
if ($Diagnose) {
    Write-YcLog 'DIAGNOSE MODE - nothing will be installed, imported, or changed.' 'INFO'
    Write-YcLog 'This host is a Bytebase CLIENT. Bytebase has no Windows server build, so there is no local service or container to report on.' 'INFO'

    $recorded = Get-BbRecordedUrl
    $envUrl = ''
    try { $envUrl = [Environment]::GetEnvironmentVariable($script:BbEnvVar, 'Machine') } catch {}
    if ($recorded) { Write-YcLog ("recorded console URL (" + $script:BbStateFile + "): " + $recorded) 'INFO' }
    else { Write-YcLog ("no console URL recorded at " + $script:BbStateFile) 'WARN' }
    if ($envUrl) { Write-YcLog ("machine environment variable " + $script:BbEnvVar + " = " + $envUrl) 'INFO' }
    else { Write-YcLog ("machine environment variable " + $script:BbEnvVar + " is not set") 'WARN' }
    if ($recorded -and $envUrl -and ($recorded -ne $envUrl)) {
        Write-YcLog ("DRIFT: the recorded URL and " + $script:BbEnvVar + " disagree. Re-run without -Diagnose to reconcile them.") 'WARN'
    }
    Write-YcLog ("Start Menu shortcut present: " + (Test-Path -LiteralPath $script:BbShortcut)) 'INFO'

    $target = $ExternalUrl
    if (-not $target) { $target = $recorded }
    if (-not $target) { $target = $envUrl }
    if (-not $target) {
        Exit-Yc 0 'Diagnose complete: this host has never been configured for a Bytebase console. Re-run with -ExternalUrl to configure it. Nothing was changed.' 'OK'
    }

    Write-YcLog ("probing " + $target) 'INFO'
    $chain = Test-BbTlsChain -Url $target
    if (-not $chain.Applicable) {
        Write-YcLog 'TLS chain check skipped: the console URL is not https.' 'WARN'
    } elseif ($chain.Valid) {
        Write-YcLog ("TLS chain VALID. subject=" + $chain.Subject + " issuer=" + $chain.Issuer + " notAfter=" + $chain.NotAfter) 'OK'
        try {
            if ($chain.NotAfter -and (($chain.NotAfter - (Get-Date)).TotalDays -lt 21)) {
                Write-YcLog ("the console certificate expires in " + [int]($chain.NotAfter - (Get-Date)).TotalDays + " days. Check ACME renewal on the HAProxy pair.") 'WARN'
            }
        } catch {}
    } else {
        Write-YcLog ("TLS chain did NOT validate: " + $chain.Reason + ". Import the internal ACME CA root with -CaCertPath, or fix GPO distribution.") 'ERROR'
    }

    $healthOk = Assert-YcHttp -Uri ($target + '/healthz') -TimeoutSec 20 -ExpectStatus 200
    $rootOk   = Assert-YcHttp -Uri ($target + '/')        -TimeoutSec 20 -ExpectStatus 200
    $ver = Get-BbServerVersion -Url $target
    if ($ver) { Write-YcLog ("server self-reports Bytebase version " + $ver) 'INFO' }
    else { Write-YcLog 'the server returned no parseable version document at /v1/actuator/info (undocumented endpoint); this is informational only.' 'INFO' }

    if ($healthOk -and $rootOk -and ($chain.Valid -or -not $chain.Applicable)) {
        Exit-Yc 0 'Diagnose complete: the console is reachable, healthy, and trusted. Nothing was changed.' 'OK'
    }
    Exit-Yc 0 'Diagnose complete: problems were reported above. Nothing was changed.' 'WARN'
}

# -----------------------------------------------------------------------------
# Configure
# -----------------------------------------------------------------------------
$url = Resolve-BbUrl -Url $ExternalUrl
Write-YcLog ("console URL validated: " + $url) 'OK'
$uri = [Uri]$url

# Name resolution first, so a DNS problem is not reported as a TLS problem.
$resolved = $false
try {
    $ips = [System.Net.Dns]::GetHostAddresses($uri.Host)
    if ($ips -and $ips.Count -gt 0) {
        $resolved = $true
        Write-YcLog ("DNS: " + $uri.Host + " -> " + (($ips | ForEach-Object { $_.IPAddressToString }) -join ', ')) 'OK'
    }
} catch {
    Write-YcLog ("DNS lookup of " + $uri.Host + " failed: " + (([string]$_.Exception.Message) -replace '[\r\n]+',' ')) 'ERROR'
}
if (-not $resolved) {
    Exit-Yc 6 ("Cannot resolve '" + $uri.Host + "'. Fix DNS (or the hosts entry) before configuring this client. Nothing was changed.") 'ERROR'
}

# Internal ACME CA root, if supplied.
if ($CaCertPath) {
    Assert-YcFile -Path $CaCertPath -MinBytes 200 -Because 'internal ACME CA root certificate' -Fatal | Out-Null
    $ca = $null
    try {
        $ca = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
        $ca.Import($CaCertPath)
    } catch {
        Exit-Yc 4 ("'" + $CaCertPath + "' is not a parseable certificate: " + (([string]$_.Exception.Message) -replace '[\r\n]+',' ')) 'ERROR'
    }
    $tp = $ca.Thumbprint
    $existing = Get-ChildItem -Path 'Cert:\LocalMachine\Root' -ErrorAction SilentlyContinue | Where-Object { $_.Thumbprint -eq $tp }
    if ($existing) {
        Write-YcLog ("internal CA already trusted in LocalMachine\Root: " + $ca.Subject + " thumbprint " + $tp + " (idempotent no-op)") 'OK'
    } else {
        try {
            $store = New-Object System.Security.Cryptography.X509Certificates.X509Store('Root','LocalMachine')
            $store.Open('ReadWrite')
            $store.Add($ca)
            $store.Close()
            Write-YcLog ("imported the internal CA into LocalMachine\Root: " + $ca.Subject + " thumbprint " + $tp + " notAfter " + $ca.NotAfter) 'OK'
        } catch {
            Exit-Yc 4 ("Failed to import '" + $CaCertPath + "' into LocalMachine\Root: " + (([string]$_.Exception.Message) -replace '[\r\n]+',' ')) 'ERROR'
        }
        $verify = Get-ChildItem -Path 'Cert:\LocalMachine\Root' -ErrorAction SilentlyContinue | Where-Object { $_.Thumbprint -eq $tp }
        if (-not $verify) {
            Exit-Yc 4 ("The CA import reported success but thumbprint " + $tp + " is NOT in LocalMachine\Root. Refusing to report success.") 'ERROR'
        }
        Write-YcLog ("verified: thumbprint " + $tp + " is present in LocalMachine\Root") 'OK'
    }
}

# TLS chain must validate BEFORE we call the console healthy. A client that
# only works because somebody disabled certificate validation is not configured.
$chain = Test-BbTlsChain -Url $url
if ($chain.Applicable) {
    if (-not $chain.Valid) {
        Exit-Yc 11 ("The TLS chain for " + $uri.Host + " did NOT validate against this machine's trust store: " + $chain.Reason + ". Supply the internal ACME CA root with -CaCertPath, or fix GPO distribution. Nothing else was changed.") 'ERROR'
    }
    Write-YcLog ("TLS chain VALID. subject=" + $chain.Subject + " issuer=" + $chain.Issuer + " notAfter=" + $chain.NotAfter) 'OK'
    try {
        if ($chain.NotAfter -and (($chain.NotAfter - (Get-Date)).TotalDays -lt 21)) {
            Write-YcLog ("the console certificate expires in " + [int]($chain.NotAfter - (Get-Date)).TotalDays + " days - check ACME renewal on the HAProxy pair.") 'WARN'
        }
    } catch {}
} else {
    Write-YcLog 'TLS chain check skipped: the console URL is not https. TLS is terminated on the HAProxy + keepalived VIP; Bytebase itself has no native HTTPS.' 'WARN'
}

# PROOF 1: the documented health endpoint answers 200. Fatal (exit 8).
Assert-YcHttp -Uri ($url + '/healthz') -TimeoutSec $TimeoutSec -ExpectStatus 200 -Fatal | Out-Null

# PROOF 2: the console root actually serves the UI.
if (-not (Assert-YcHttp -Uri ($url + '/') -TimeoutSec 30 -ExpectStatus 200)) {
    Write-YcLog 'the console root did not return 200 although /healthz is green. The server is up; check the HAProxy backend and the frontend ACL for this hostname.' 'WARN'
}

# Informational: what the server says it is.
$ver = Get-BbServerVersion -Url $url
if ($ver) {
    Write-YcLog ("server self-reports Bytebase version " + $ver + " (informational; the authoritative version proof is the image-id comparison in deploy-bytebase.sh on the server host)") 'INFO'
} else {
    Write-YcLog 'the server returned no parseable version document at /v1/actuator/info (undocumented endpoint). Version is proven server-side by deploy-bytebase.sh.' 'INFO'
}

# Record the URL machine-wide, idempotently.
if (-not (Test-Path -LiteralPath $script:BbStateDir)) {
    New-Item -ItemType Directory -Path $script:BbStateDir -Force | Out-Null
}
$prior = Get-BbRecordedUrl
if ($prior -eq $url) {
    Write-YcLog ("console URL already recorded at " + $script:BbStateFile + " (idempotent no-op)") 'OK'
} else {
    if ($prior) { Write-YcLog ("replacing the previously recorded console URL '" + $prior + "' with '" + $url + "'") 'WARN' }
    Set-Content -LiteralPath $script:BbStateFile -Value $url -Encoding ascii -Force
    Write-YcLog ("recorded the console URL at " + $script:BbStateFile) 'OK'
}
Assert-YcFile -Path $script:BbStateFile -MinBytes 8 -Because 'recorded console URL' -Fatal | Out-Null

$envUrl = ''
try { $envUrl = [Environment]::GetEnvironmentVariable($script:BbEnvVar, 'Machine') } catch {}
if ($envUrl -eq $url) {
    Write-YcLog ($script:BbEnvVar + " is already set machine-wide (idempotent no-op)") 'OK'
} else {
    [Environment]::SetEnvironmentVariable($script:BbEnvVar, $url, 'Machine')
    $check = [Environment]::GetEnvironmentVariable($script:BbEnvVar, 'Machine')
    if ($check -ne $url) {
        Exit-Yc 2 ("Failed to set the machine environment variable " + $script:BbEnvVar + ". Refusing to report success.") 'ERROR'
    }
    Write-YcLog ("set machine environment variable " + $script:BbEnvVar + " = " + $url + " (new processes only; this session is unchanged)") 'OK'
}

# Start Menu shortcut - convenience for operators on a jump host.
if ($NoShortcut) {
    Write-YcLog '-NoShortcut: no Start Menu entry created.' 'INFO'
} else {
    $want = "[InternetShortcut]`r`nURL=$url`r`n"
    $have = ''
    if (Test-Path -LiteralPath $script:BbShortcut) {
        try { $have = [IO.File]::ReadAllText($script:BbShortcut) } catch {}
    }
    if ($have -eq $want) {
        Write-YcLog 'Start Menu shortcut already correct (idempotent no-op)' 'OK'
    } else {
        try {
            $sdir = Split-Path -Parent $script:BbShortcut
            if (-not (Test-Path -LiteralPath $sdir)) { New-Item -ItemType Directory -Path $sdir -Force | Out-Null }
            [IO.File]::WriteAllText($script:BbShortcut, $want, [Text.Encoding]::ASCII)
            Write-YcLog ("Start Menu shortcut written: " + $script:BbShortcut) 'OK'
        } catch {
            Write-YcLog ("could not write the Start Menu shortcut: " + (([string]$_.Exception.Message) -replace '[\r\n]+',' ')) 'WARN'
        }
    }
}

Write-YcLog 'firewall: no inbound rule was created. A console client needs outbound 443 only. Inbound access to the Bytebase host is scoped to a management CIDR by deploy-bytebase.sh --mgmt-cidr on the server side.' 'INFO'
Write-YcLog 'SQL Server estate: registering an instance means handing Bytebase a SQL login, which is a change-controlled action. Do it in the console under Instances, using a dedicated least-privilege account - not from an unattended golden-image script.' 'INFO'
Write-YcLog 'licence: Community is free for up to 20 users and 10 instances. SSO (OIDC/LDAP), approval workflow, dynamic data masking, custom roles and HA are Enterprise-gated. See BYTEBASE-NOTES.md before reselling console access to tenants.' 'INFO'

Exit-Yc 0 ("Bytebase client configured and PROVEN: " + $url + " resolves, its TLS chain validates, /healthz returned 200, and the URL is recorded machine-wide. No server component was installed - Bytebase has no Windows server build.") 'OK'
