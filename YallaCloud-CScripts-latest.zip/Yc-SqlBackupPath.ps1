param(
  [string]$Path,
  [string]$InstanceName  = 'MSSQLSERVER',
  [int]$RetainFullDays   = 0,
  [int]$RetainDiffDays   = 0,
  [int]$RetainLogDays    = 0,
  [string]$MonthlyPath   = '',
  [int]$KeepMonths       = 0,
  [switch]$Move,
  [switch]$NoRegistry,
  [switch]$Force,
  [switch]$Report,
  [switch]$SelfCheck,
  [switch]$Help
)
# =====================================================================================
# Yc-SqlBackupPath.ps1 - move the SQL backup location, and change retention, on a
# machine that is already installed. PowerShell 5.1 only. ASCII only.
#
# WHY THIS EXISTS
#   The backup root is chosen once, at install time, by install-sql -BackupDir. It is then
#   frozen into the ARGUMENTS of six scheduled tasks. The default is C:\dbbackupdaily, on
#   the system drive. Backups grow, C: fills, and a full system drive does not degrade a
#   Windows VM - it stops it. SQL Server cannot write its error log, the page file cannot
#   grow, services fail to start, and the machine is effectively down. The fix at that
#   point used to be "re-run install-sql", which is a heavy, risky thing to do to a live
#   production database server just to change one folder.
#   This changes the folder. Nothing else.
#
# WHAT IT CHANGES - all of it, or none of it
#   1. @Directory   in YC-SqlBackupFull / -Diff / -Log     (where new backups are written)
#   2. @CleanupTime in the same three tasks                (how long Ola KEEPS them there -
#                                                           this is the cleanup, and it only
#                                                           ever prunes the directory it is
#                                                           pointed at, which is exactly why
#                                                           location and retention have to
#                                                           move together)
#   3. -MonthlyDir and -KeepMonths in YC-SqlBackupMonthly  (the retained monthly archive)
#   4. the INSTANCE DEFAULT backup directory in the registry, so backup-sql, SSMS and any
#      ad-hoc BACKUP with no path land in the new place too       (skip with -NoRegistry)
#
#   YC-SqlRestoreVerify and restore-sql need no change: the first reads the newest backup
#   from msdb, the second discovers the root by reading it back out of these same task
#   arguments. Change the tasks and the whole toolchain follows. That is deliberate - the
#   scheduled task argument is the single source of truth for "where the backups are".
#
# WHAT IT PROVES BEFORE IT CHANGES ANYTHING
#   The SQL SERVICE - not you, not the admin running this - must be able to write to the
#   new folder. A backup path the service cannot reach fails nightly with "operating system
#   error 5" and nothing says a word until somebody needs a restore. So this creates the
#   folder, grants the service account, and then makes SQL Server itself write a real
#   COPY_ONLY backup of master into it and deletes it again. If that fails, nothing is
#   changed and the old path is still in force.
#
# ROLLBACK
#   Every task definition is exported to C:\Scripts\yc-backuppath-rollback\<timestamp>\
#   BEFORE it is touched. If the re-read after the change does not show the new path, that
#   task is restored from its export automatically. The machine is never left with a
#   backup task that is missing or half-edited.
#
# EXISTING BACKUPS
#   Left where they are by default. -Move moves them with robocopy. Be aware either way:
#   msdb.dbo.backupset still records the OLD full paths until the next full backup runs, so
#   sql-archive and any restore driven from msdb will name files at the old location. If you
#   move them, run backup-sql -Type Full once afterwards and msdb catches up.
#   If you do NOT move them, the old folder is now orphaned: no cleanup points at it any
#   more, so it will never shrink on its own. This script tells you the size and the path.
#
# EXIT CODES
#   0 changed, verified            1 one or more tasks could not be changed
#   2 usage                        3 SQL unreachable
#   4 SQL cannot write there       5 not elevated
#
# Log: C:\Scripts\yc-sqlbackuppath.log, plus the Application event log, source YALLACLOUD.
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'yc-sqlbackuppath'
$ErrorActionPreference = 'Stop'

$HelpText = @"
yc-sqlbackuppath - move the SQL backup location, and change retention, in place.

USAGE:
  sql-backup-path -Report                        where are the backups now, and how long kept
  sql-backup-path -Path D:\dbbackupdaily         move new backups to D:, keep retention as is
  sql-backup-path -Path D:\dbbackupdaily -Move   ...and move the existing files there too
  sql-backup-path -RetainFullDays 60             change retention only, leave the path alone
  sql-backup-path -Path D:\dbbackupdaily -MonthlyPath D:\dbbackupmonthly -KeepMonths 24
  sql-backup-path -Path D:\dbbackupdaily -InstanceName YCWEB
  sql-backup-path -SelfCheck                     assertions only, no admin, changes nothing
  sql-backup-path -Help

PARAMETERS
  -Path <dir>          new backup root. Omit to leave the location alone.
  -RetainFullDays <n>  rolling window for FULL backups, in DAYS. 0 = leave unchanged.
  -RetainDiffDays <n>  same for DIFF.        -RetainLogDays <n>  same for LOG.
  -MonthlyPath <dir>   new root for the retained monthly archive.
  -KeepMonths <n>      how many monthly archives to keep. 0 = leave unchanged.
  -Move                robocopy the existing backups from the old root to the new one.
  -NoRegistry          do not touch the instance default backup directory.
  -Force               proceed even if the target volume looks too small for the current set.

WHY LOCATION AND RETENTION ARE THE SAME COMMAND
  Ola's cleanup deletes old backups from the directory it is given, and only that one. Move
  the path without carrying the retention across and you get a folder that grows forever
  plus an old folder nothing will ever clean. They are one setting wearing two names.

IT WILL NOT GUESS. -Path on its own moves the daily backups; the monthly archive keeps its
own root until you pass -MonthlyPath. Two folders, two decisions, said out loud.
"@
if ($Help) { Write-Output $HelpText; Exit-Yc 0 }

# -------------------------------------------------------------------------------------
# The string surgery. These are the only functions that can silently corrupt a working
# backup task, so they are pure, they are the ones -SelfCheck exercises, and they refuse
# to return a string they did not actually change.
# -------------------------------------------------------------------------------------
function Get-YcArgDirectory {
  param([string]$Arguments)
  if ($Arguments -match "@Directory\s*=\s*N'([^']*)'") { return $Matches[1] }
  return ''
}

function Get-YcArgCleanup {
  param([string]$Arguments)
  if ($Arguments -match '@CleanupTime\s*=\s*(\d+)') { return [int]$Matches[1] }
  return -1
}

function Set-YcArgDirectory {
  param([string]$Arguments, [string]$NewDir)
  # MatchEvaluator, not a replacement string: a Windows path is full of backslashes and can
  # contain a '$' (a named-instance share, a folder somebody called 'DB$'), both of which
  # -replace would interpret. This inserts the path verbatim.
  $rx = New-Object System.Text.RegularExpressions.Regex "@Directory\s*=\s*N'[^']*'"
  return $rx.Replace($Arguments, [System.Text.RegularExpressions.MatchEvaluator]{
    param($m) "@Directory = N'" + $NewDir + "'"
  })
}

function Set-YcArgCleanup {
  param([string]$Arguments, [int]$Hours)
  $rx = New-Object System.Text.RegularExpressions.Regex '@CleanupTime\s*=\s*\d+'
  return $rx.Replace($Arguments, [System.Text.RegularExpressions.MatchEvaluator]{
    param($m) '@CleanupTime = ' + $Hours
  })
}

function Set-YcArgSwitch {
  param([string]$Arguments, [string]$Name, [string]$Value, [bool]$Quote)
  # -MonthlyDir "C:\x"  /  -KeepMonths 12  in the monthly task's powershell.exe command line.
  $pat = '-' + [regex]::Escape($Name) + '\s+(?:"[^"]*"|\S+)'
  $new = if ($Quote) { '-' + $Name + ' "' + $Value + '"' } else { '-' + $Name + ' ' + $Value }
  $rx  = New-Object System.Text.RegularExpressions.Regex $pat
  if (-not $rx.IsMatch($Arguments)) { return $Arguments + ' ' + $new }
  return $rx.Replace($Arguments, [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $new }, 1)
}

# -------------------------------------------------------------------------------------
# -SelfCheck. Runs anywhere, needs nothing, changes nothing.
# -------------------------------------------------------------------------------------
if ($SelfCheck) {
  $pass = 0; $fail = 0
  function T($name, $cond) {
    if ($cond) { Write-Output ('ok   ' + $name); $script:pass++ }
    else       { Write-Output ('FAIL ' + $name); $script:fail++ }
  }

  $full = '-S "." -E -C -b -d DBA -Q "EXEC dbo.DatabaseBackup @Databases = ''ALL_DATABASES'', ' +
          '@Directory = N''C:\dbbackupdaily'', @BackupType = ''FULL'', @Verify = ''Y'', ' +
          '@Compress = ''Y'', @CheckSum = ''Y'', @CleanupTime = 840, @LogToTable = ''Y''"'

  T 'reads the current directory'   ((Get-YcArgDirectory $full) -eq 'C:\dbbackupdaily')
  T 'reads the current cleanup'     ((Get-YcArgCleanup   $full) -eq 840)

  $moved = Set-YcArgDirectory -Arguments $full -NewDir 'D:\dbbackupdaily'
  T 'rewrites the directory'        ((Get-YcArgDirectory $moved) -eq 'D:\dbbackupdaily')
  T 'rewrite touches nothing else'  ((Get-YcArgCleanup $moved) -eq 840 -and $moved -match 'ALL_DATABASES' -and $moved -match ([regex]::Escape("@LogToTable = 'Y'")))
  # the strongest statement available: putting the old path back must reproduce the original
  # string byte for byte, so the rewrite provably touched the directory and nothing else.
  T 'rewrite is reversible'         ((Set-YcArgDirectory -Arguments $moved -NewDir 'C:\dbbackupdaily') -eq $full)

  $cut = Set-YcArgCleanup -Arguments $full -Hours 1440
  T 'rewrites the cleanup'          ((Get-YcArgCleanup $cut) -eq 1440)
  T 'cleanup keeps the directory'   ((Get-YcArgDirectory $cut) -eq 'C:\dbbackupdaily')

  # a path with a dollar and a backslash run - the two things a naive -replace mangles
  $odd = Set-YcArgDirectory -Arguments $full -NewDir 'E:\SQL$PROD\backups'
  T 'dollar in path survives'       ((Get-YcArgDirectory $odd) -eq 'E:\SQL$PROD\backups')
  $unc = Set-YcArgDirectory -Arguments $full -NewDir '\\nas01\sqlbackup$'
  T 'UNC path survives'             ((Get-YcArgDirectory $unc) -eq '\\nas01\sqlbackup$')

  # an argument string with no directory at all must come back untouched, not corrupted
  $noDir = '-S "." -E -C -b -d DBA -Q "EXEC dbo.IndexOptimize @Databases = ''ALL_DATABASES''"'
  T 'no directory = unchanged'      ((Set-YcArgDirectory -Arguments $noDir -NewDir 'D:\x') -eq $noDir)
  T 'no cleanup = unchanged'        ((Set-YcArgCleanup   -Arguments $noDir -Hours 99)      -eq $noDir)
  T 'reports absence honestly'      ((Get-YcArgDirectory $noDir) -eq '' -and (Get-YcArgCleanup $noDir) -eq -1)

  $mon = '-NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Yc-SqlArchive.ps1" ' +
         '-InstanceName MSSQLSERVER -MonthlyDir "C:\dbbackupmonthly" -KeepMonths 12'
  $m2 = Set-YcArgSwitch -Arguments $mon -Name 'MonthlyDir' -Value 'D:\dbbackupmonthly' -Quote $true
  T 'rewrites -MonthlyDir'          ($m2 -match '-MonthlyDir "D:\\dbbackupmonthly"')
  T 'quoted value not split'        (($m2 -split '-KeepMonths').Count -eq 2)
  $m3 = Set-YcArgSwitch -Arguments $m2 -Name 'KeepMonths' -Value '24' -Quote $false
  T 'rewrites -KeepMonths'          ($m3 -match '-KeepMonths 24$')
  T 'and keeps -MonthlyDir'         ($m3 -match '-MonthlyDir "D:\\dbbackupmonthly"')
  T 'file path is untouched'        ($m3 -match '-File "C:\\Scripts\\Yc-SqlArchive\.ps1"')
  $m4 = Set-YcArgSwitch -Arguments '-File "x.ps1"' -Name 'KeepMonths' -Value '6' -Quote $false
  T 'absent switch is appended'     ($m4 -eq '-File "x.ps1" -KeepMonths 6')

  # days -> hours, the conversion that decides how much is deleted
  T 'days to hours'                 ((35 * 24) -eq 840 -and (14 * 24) -eq 336)

  Write-Output ''
  Write-Output ('SelfCheck: ' + $pass + ' passed, ' + $fail + ' failed')
  if ($fail -gt 0) { Exit-Yc 1 'SelfCheck FAILED' } else { Exit-Yc 0 'SelfCheck: all checks passed' }
}

Write-YcInvocation
if (-not (Test-YcAdmin)) { Exit-Yc 5 'Administrator is required to rewrite scheduled tasks and grant folder rights.' 'ERROR' }

$wantPath    = [bool]$Path
$wantMonthly = ([bool]$MonthlyPath) -or ($KeepMonths -gt 0)
$wantRetain  = ($RetainFullDays -gt 0) -or ($RetainDiffDays -gt 0) -or ($RetainLogDays -gt 0)
if (-not $Report -and -not $wantPath -and -not $wantRetain -and -not $wantMonthly) {
  Write-Output $HelpText
  Exit-Yc 2 'nothing to do: pass -Path, a -Retain*Days, -MonthlyPath/-KeepMonths, or -Report.' 'ERROR'
}
foreach ($d in @(@('RetainFullDays',$RetainFullDays), @('RetainDiffDays',$RetainDiffDays), @('RetainLogDays',$RetainLogDays))) {
  if ($d[1] -lt 0 -or $d[1] -gt 3650) { Exit-Yc 2 ('-' + $d[0] + ' must be between 1 and 3650 days (0 = leave unchanged). Got ' + $d[1] + '.') 'ERROR' }
}
if ($KeepMonths -lt 0 -or $KeepMonths -gt 120) { Exit-Yc 2 ('-KeepMonths must be between 1 and 120 (0 = leave unchanged). Got ' + $KeepMonths + '.') 'ERROR' }

$suffix   = if ($InstanceName -eq 'MSSQLSERVER') { '' } else { '-' + $InstanceName }
$server   = if ($InstanceName -eq 'MSSQLSERVER') { '.' } else { '.\' + $InstanceName }
$svcName  = if ($InstanceName -eq 'MSSQLSERVER') { 'MSSQLSERVER' } else { 'MSSQL$' + $InstanceName }
$taskFull = 'YC-SqlBackupFull-'    + $InstanceName
$taskDiff = 'YC-SqlBackupDiff-'    + $InstanceName
$taskLog  = 'YC-SqlBackupLog-'     + $InstanceName
$taskMon  = 'YC-SqlBackupMonthly-' + $InstanceName

# -------------------------------------------------------------------------------------
# what is in force right now
# -------------------------------------------------------------------------------------
function Get-YcTask([string]$Name) { return (Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue) }

$curDir = ''
$state  = @()
foreach ($n in @($taskFull, $taskDiff, $taskLog)) {
  $t = Get-YcTask $n
  if (-not $t) { $state += [pscustomobject]@{ Task=$n; Present=$false; Dir=''; Hours=-1 }; continue }
  $a = [string]$t.Actions[0].Arguments
  $d = Get-YcArgDirectory $a
  if (-not $curDir -and $d) { $curDir = $d }
  $state += [pscustomobject]@{ Task=$n; Present=$true; Dir=$d; Hours=(Get-YcArgCleanup $a) }
}
$monTask  = Get-YcTask $taskMon
$curMonDir = ''; $curKeep = -1
if ($monTask) {
  $ma = [string]$monTask.Actions[0].Arguments
  if ($ma -match '-MonthlyDir\s+"([^"]*)"') { $curMonDir = $Matches[1] }
  elseif ($ma -match '-MonthlyDir\s+(\S+)') { $curMonDir = $Matches[1] }
  if ($ma -match '-KeepMonths\s+(\d+)')     { $curKeep = [int]$Matches[1] }
}

if (-not ($state | Where-Object { $_.Present })) {
  Exit-Yc 2 ('no YC-SqlBackup* scheduled tasks exist for instance ' + $InstanceName +
             '. Either SQL maintenance was never installed here, or the instance name is wrong. ' +
             'Run: Get-ScheduledTask -TaskName YC-Sql* | Select TaskName') 'ERROR'
}

function Get-YcFolderSize([string]$P) {
  if (-not $P -or -not (Test-Path -LiteralPath $P)) { return -1 }
  $s = 0
  foreach ($f in @(Get-ChildItem -LiteralPath $P -Recurse -File -ErrorAction SilentlyContinue)) { $s += $f.Length }
  return $s
}

Write-YcLog '--- current backup policy -----------------------------------------------------' 'INFO'
foreach ($s in $state) {
  if (-not $s.Present) { Write-YcLog ($s.Task + ': NOT PRESENT') 'WARN'; continue }
  $days = if ($s.Hours -ge 0) { [string][math]::Round($s.Hours / 24, 1) + ' days' } else { 'no cleanup set' }
  Write-YcLog ($s.Task + ': ' + $(if ($s.Dir) { $s.Dir } else { '(instance default)' }) + '   keeps ' + $days) 'INFO'
}
if ($monTask) { Write-YcLog ($taskMon + ': ' + $curMonDir + '   keeps ' + $curKeep + ' monthly') 'INFO' }
else          { Write-YcLog ($taskMon + ': NOT PRESENT - no retained monthly on this machine') 'WARN' }

$curSize = Get-YcFolderSize $curDir
if ($curSize -ge 0) { Write-YcLog ('current set: ' + [math]::Round($curSize / 1GB, 2) + ' GB in ' + $curDir) 'INFO' }
if ($curDir -and $curDir -like ($env:SystemDrive + '*')) {
  $sysFree = (Get-PSDrive -Name $env:SystemDrive.TrimEnd(':') -ErrorAction SilentlyContinue).Free
  Write-YcLog ('backups are on the SYSTEM DRIVE (' + $env:SystemDrive + '), free ' +
               [math]::Round($sysFree / 1GB, 1) + ' GB. If this fills, the VM stops - not slows.') 'WARN'
}

if ($Report) {
  Write-YcLog '-Report: nothing was changed.' 'INFO'
  Exit-Yc 0 ('current root ' + $(if ($curDir) { $curDir } else { '(instance default)' }))
}

# -------------------------------------------------------------------------------------
# SQL has to be up: we are about to make it prove it can write to the new folder.
# -------------------------------------------------------------------------------------
$cs = 'Server=' + $server + ';Database=master;Integrated Security=True;Connect Timeout=20'
function Invoke-YcSqlNonQuery([string]$Tsql) {
  $conn = New-Object System.Data.SqlClient.SqlConnection $cs
  $conn.Open()
  try { $cmd = $conn.CreateCommand(); $cmd.CommandText = $Tsql; $cmd.CommandTimeout = 600; [void]$cmd.ExecuteNonQuery() }
  finally { $conn.Close() }
}
try { Invoke-YcSqlNonQuery 'SELECT 1' }
catch { Exit-Yc 3 ('cannot reach SQL Server instance ' + $InstanceName + ': ' + $_.Exception.Message +
                   '. Nothing was changed.') 'ERROR' }

# -------------------------------------------------------------------------------------
# prepare and PROVE the new folder, before a single task is touched
# -------------------------------------------------------------------------------------
function Grant-YcSqlFolder([string]$Folder) {
  if (-not (Test-Path -LiteralPath $Folder)) {
    # A path that cannot even be created - a read-only volume, a drive letter that is really a
    # DVD, a typo'd UNC - must fail HERE with a sentence, not as a stack trace half way through.
    try {
      New-Item -ItemType Directory -Path $Folder -Force -ErrorAction Stop | Out-Null
      Write-YcLog ('created ' + $Folder) 'OK'
    } catch {
      Exit-Yc 4 ('cannot create ' + $Folder + ': ' + ($_.Exception.Message -replace '\s+',' ') +
                 '. NOTHING was changed - the old path is still in force.') 'ERROR'
    }
  }
  # The account the SERVICE actually runs as. A virtual account (NT Service\MSSQLSERVER) is
  # the common case and icacls understands it by name.
  $acct = ''
  try { $acct = (Get-WmiObject -Class Win32_Service -Filter ("Name='" + $svcName + "'") -ErrorAction Stop).StartName } catch {}
  if (-not $acct) { $acct = 'NT SERVICE\' + $svcName }
  if ($acct -eq 'LocalSystem') { $acct = 'NT AUTHORITY\SYSTEM' }
  $ic = & icacls.exe $Folder '/grant' ($acct + ':(OI)(CI)F') '/t' 2>&1
  if ($LASTEXITCODE -ne 0) {
    Write-YcLog ('icacls could not grant ' + $acct + ' on ' + $Folder + ': ' + ($ic -join ' ')) 'WARN'
  } else {
    Write-YcLog ('granted ' + $acct + ' full control on ' + $Folder) 'OK'
  }
  return $acct
}

function Test-YcSqlCanWrite([string]$Folder) {
  # The only test that means anything: SQL Server itself writes a real backup there.
  $probe = Join-Path $Folder ('yc-pathcheck-' + $env:COMPUTERNAME + '.bak')
  $esc   = $probe -replace "'", "''"
  try {
    Invoke-YcSqlNonQuery ("BACKUP DATABASE [master] TO DISK = N'" + $esc + "' WITH COPY_ONLY, INIT, FORMAT, SKIP")
  } catch {
    Write-YcLog ('SQL Server could not write to ' + $Folder + ': ' + ($_.Exception.Message -replace '\s+',' ')) 'ERROR'
    return $false
  } finally {
    Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
  }
  Write-YcLog ('SQL Server wrote and removed a test backup in ' + $Folder + '. The path is usable.') 'OK'
  return $true
}

if ($wantPath) {
  if ($Path -eq $curDir) { Write-YcLog ('-Path is already the current root (' + $Path + '). Retention changes, if any, still apply.') 'WARN' }
  $acct = Grant-YcSqlFolder $Path
  # free space: a move onto a volume that cannot hold what is already there is a slower
  # version of the same outage, so say so before doing it.
  try {
    $vol = (Get-Item -LiteralPath $Path).PSDrive
    if ($vol -and $curSize -gt 0 -and $vol.Free -lt ($curSize * 1.2)) {
      $m = ('the target volume ' + $vol.Name + ': has ' + [math]::Round($vol.Free / 1GB, 1) +
            ' GB free but the current backup set is already ' + [math]::Round($curSize / 1GB, 1) + ' GB')
      if (-not $Force) { Exit-Yc 2 ($m + '. Nothing was changed. Pass -Force if you mean it, or lower retention at the same time with -RetainFullDays.') 'ERROR' }
      Write-YcLog ($m + ' - proceeding because -Force was given.') 'WARN'
    }
  } catch {}
  if (-not (Test-YcSqlCanWrite $Path)) {
    Exit-Yc 4 ('the SQL service account (' + $acct + ') cannot write to ' + $Path +
               '. NOTHING was changed - the old path is still in force. Fix the rights or the volume and run this again.') 'ERROR'
  }
}
if ($MonthlyPath) { [void](Grant-YcSqlFolder $MonthlyPath) }

# -------------------------------------------------------------------------------------
# rewrite the tasks. Export first, verify after, restore on doubt.
# -------------------------------------------------------------------------------------
$rollback = Join-Path 'C:\Scripts\yc-backuppath-rollback' (Get-Date).ToString('yyyyMMdd-HHmmss')
New-Item -ItemType Directory -Path $rollback -Force | Out-Null
Write-YcLog ('task definitions are being exported to ' + $rollback + ' before any change.') 'INFO'

function Set-YcTaskArguments {
  <# Rewrite one task's action arguments in place, preserving its principal, triggers and
     settings exactly - which is why this goes through the exported XML rather than
     rebuilding the task. Returns $true only after re-reading the change back from the OS. #>
  param(
    [string]$Name,
    [string]$Expect,
    [string]$NewDir      = '',
    [int]$Hours          = 0,
    [string]$NewMonthly  = '',
    [int]$NewKeep        = 0
  )
  $t = Get-YcTask $Name
  if (-not $t) { Write-YcLog ($Name + ': not present, skipped.') 'WARN'; return $null }

  $xmlText = Export-ScheduledTask -TaskName $Name
  Set-Content -Path (Join-Path $rollback ($Name + '.xml')) -Value $xmlText -Encoding unicode

  $xml = [xml]$xmlText
  $ns  = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
  $ns.AddNamespace('t', 'http://schemas.microsoft.com/windows/2004/02/mit/task')
  $nodes = @($xml.SelectNodes('//t:Actions/t:Exec/t:Arguments', $ns))
  if ($nodes.Count -eq 0) { Write-YcLog ($Name + ': has no Exec arguments to rewrite.') 'WARN'; return $false }

  $changed = $false
  foreach ($n in $nodes) {
    $old = [string]$n.InnerText
    $new = $old
    if ($NewDir)         { $new = Set-YcArgDirectory -Arguments $new -NewDir $NewDir }
    if ($Hours -gt 0)    { $new = Set-YcArgCleanup   -Arguments $new -Hours $Hours }
    if ($NewMonthly)     { $new = Set-YcArgSwitch    -Arguments $new -Name 'MonthlyDir' -Value $NewMonthly -Quote $true }
    if ($NewKeep -gt 0)  { $new = Set-YcArgSwitch    -Arguments $new -Name 'KeepMonths' -Value ([string]$NewKeep) -Quote $false }
    if ($new -ne $old) { $n.InnerText = $new; $changed = $true }
  }
  if (-not $changed) { Write-YcLog ($Name + ': already exactly as requested, left alone.') 'INFO'; return $true }

  try {
    Register-ScheduledTask -TaskName $Name -Xml $xml.OuterXml -Force -ErrorAction Stop | Out-Null
  } catch {
    Write-YcLog ($Name + ': re-registration failed - ' + ($_.Exception.Message -replace '\s+',' ')) 'ERROR'
    Write-YcLog ($Name + ': the task was NOT changed. Its original definition is at ' + (Join-Path $rollback ($Name + '.xml')) + '.') 'WARN'
    return $false
  }

  # Do not trust the write. Read it back out of the OS.
  $after = Get-YcTask $Name
  $ok = $false
  if ($after) { foreach ($a in $after.Actions) { if ("$($a.Arguments)" -like ('*' + $Expect + '*')) { $ok = $true } } }
  if (-not $ok) {
    Write-YcLog ($Name + ': re-read does NOT show "' + $Expect + '". Restoring the original definition.') 'ERROR'
    try { Register-ScheduledTask -TaskName $Name -Xml $xmlText -Force | Out-Null; Write-YcLog ($Name + ': original restored.') 'WARN' }
    catch { Write-YcLog ($Name + ': COULD NOT RESTORE. The export is at ' + (Join-Path $rollback ($Name + '.xml')) + ' - re-register it by hand.') 'ERROR' }
    return $false
  }
  Write-YcLog ($Name + ': updated and verified.') 'OK'
  return $true
}

$results = @{}
$pairs = @(
  @{ Task = $taskFull; Days = $RetainFullDays },
  @{ Task = $taskDiff; Days = $RetainDiffDays },
  @{ Task = $taskLog;  Days = $RetainLogDays  }
)
foreach ($p in $pairs) {
  $days = [int]$p.Days
  if (-not $wantPath -and $days -le 0) { continue }
  $expect = if ($wantPath) { "@Directory = N'" + $Path + "'" } else { '@CleanupTime = ' + ($days * 24) }
  $r = Set-YcTaskArguments -Name $p.Task -Expect $expect `
         -NewDir $(if ($wantPath) { $Path } else { '' }) `
         -Hours  $(if ($days -gt 0) { $days * 24 } else { 0 })
  if ($null -ne $r) { $results[$p.Task] = $r }
}

if ($wantMonthly) {
  if (-not $monTask) {
    Write-YcLog ($taskMon + ' does not exist, so there is nothing to re-point. The retained monthly is registered by install-sql; if this machine predates it, run sql-archive by hand or re-run install-sql with -MonthlyKeep.') 'WARN'
  } else {
    $expect = if ($MonthlyPath) { '-MonthlyDir "' + $MonthlyPath + '"' } else { '-KeepMonths ' + $KeepMonths }
    $r = Set-YcTaskArguments -Name $taskMon -Expect $expect `
           -NewMonthly $MonthlyPath -NewKeep $KeepMonths
    if ($null -ne $r) { $results[$taskMon] = $r }
  }
}

# -------------------------------------------------------------------------------------
# the instance default, so ad-hoc backups follow too
# -------------------------------------------------------------------------------------
if ($wantPath -and -not $NoRegistry) {
  try {
    $esc = $Path -replace "'", "''"
    Invoke-YcSqlNonQuery ("EXEC master.dbo.xp_instance_regwrite N'HKEY_LOCAL_MACHINE', " +
                          "N'Software\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory', REG_SZ, N'" + $esc + "'")
    Write-YcLog ('instance default backup directory set to ' + $Path + '. SSMS, backup-sql and any BACKUP with no path now default here (SERVERPROPERTY reports the new value after the next service restart; the registry value is live immediately).') 'OK'
  } catch {
    Write-YcLog ('could not set the instance default backup directory: ' + ($_.Exception.Message -replace '\s+',' ') + '. The scheduled tasks were still changed; only ad-hoc backups keep the old default.') 'WARN'
  }
}

# -------------------------------------------------------------------------------------
# existing files
# -------------------------------------------------------------------------------------
function Move-YcBackupRoot {
  # There are TWO roots - the rolling daily set and the retained monthly archive - and both
  # are orphaned by a move: once the task no longer names a folder, nothing will ever clean
  # it again. The first version of this only handled the daily one and quietly left a year
  # of monthly archives sitting on the disk it was called in to empty.
  param([string]$From, [string]$To, [string]$Label)
  if (-not $From -or $From -eq $To) { return }
  if (-not (Test-Path -LiteralPath $From)) { return }
  $bytes = Get-YcFolderSize $From
  if ($bytes -le 0) {
    Write-YcLog ($Label + ': old folder ' + $From + ' is empty, nothing to move.') 'INFO'
    return
  }
  $sz = [math]::Round($bytes / 1GB, 2).ToString() + ' GB'
  if (-not $Move) {
    Write-YcLog ($Label + ': existing backups were LEFT in ' + $From + ' (' + $sz +
                 '). Nothing points at that folder any more, so no cleanup will ever shrink it. ' +
                 'Either move them (add -Move) or delete it once the new location is producing backups.') 'WARN'
    return
  }
  Write-YcLog ($Label + ': moving ' + $sz + ' from ' + $From + ' -> ' + $To + ' with robocopy...') 'INFO'
  & robocopy.exe $From $To '/E' '/MOVE' '/R:1' '/W:1' '/NFL' '/NDL' '/NJH' '/NJS' | Out-Null
  $rc = $LASTEXITCODE
  if ($rc -ge 8) {
    Write-YcLog ($Label + ': robocopy returned ' + $rc + ' - the move did NOT complete cleanly. Check both folders by hand. The task is already pointing at ' + $To + '.') 'ERROR'
  } else {
    Write-YcLog ($Label + ': moved (robocopy rc=' + $rc + ').') 'OK'
  }
}

if ($wantPath) { Move-YcBackupRoot -From $curDir -To $Path -Label 'daily' }
if ($MonthlyPath) { Move-YcBackupRoot -From $curMonDir -To $MonthlyPath -Label 'monthly archive' }
if ($Move -and $wantPath -and $curDir -and $curDir -ne $Path) {
  # Ola writes the path it used into msdb, and sql-archive and restore-sql both read it back.
  # Until the next full backup runs they will name files that are no longer where they say.
  Write-YcLog ('msdb still records the OLD paths until the next full backup runs. Run  backup-sql -Type Full  once so msdb, restore-sql and sql-archive agree with what is actually on disk.') 'WARN'
}

# -------------------------------------------------------------------------------------
# say what is now true, read back from the machine and not from our own intentions
# -------------------------------------------------------------------------------------
Write-YcLog '--- new backup policy ---------------------------------------------------------' 'INFO'
$finalDir = ''
foreach ($n in @($taskFull, $taskDiff, $taskLog)) {
  $t = Get-YcTask $n
  if (-not $t) { continue }
  $a = [string]$t.Actions[0].Arguments
  $d = Get-YcArgDirectory $a
  $h = Get-YcArgCleanup $a
  if (-not $finalDir -and $d) { $finalDir = $d }
  Write-YcLog ($n + ': ' + $d + '   keeps ' + [math]::Round($h / 24, 1) + ' days') 'INFO'
}
$t = Get-YcTask $taskMon
if ($t) { Write-YcLog ($taskMon + ': ' + ([string]$t.Actions[0].Arguments)) 'INFO' }

$summary = [ordered]@{
  host = $env:COMPUTERNAME; instance = $InstanceName
  oldRoot = $curDir; newRoot = $finalDir
  monthlyRoot = $(if ($MonthlyPath) { $MonthlyPath } else { $curMonDir })
  retainFullDays = $RetainFullDays; retainDiffDays = $RetainDiffDays; retainLogDays = $RetainLogDays
  keepMonths = $(if ($KeepMonths -gt 0) { $KeepMonths } else { $curKeep })
  moved = [bool]$Move; rollback = $rollback
  utc = (Get-Date).ToUniversalTime().ToString('s') + 'Z'
}
try { $summary | ConvertTo-Json -Compress | Set-Content -Path 'C:\Scripts\yc-sqlbackuppath.json' -Encoding ascii } catch {}

$bad = @($results.Keys | Where-Object { -not $results[$_] })
if ($bad.Count -gt 0) {
  Exit-Yc 1 ('these tasks could NOT be changed and are unchanged: ' + ($bad -join ', ') +
             '. Everything else was applied. Rollback exports: ' + $rollback) 'ERROR'
}
Exit-Yc 0 ('backup root ' + $(if ($finalDir) { $finalDir } else { '(unchanged)' }) +
           ', ' + $results.Count + ' task(s) updated and verified. Rollback exports: ' + $rollback)
