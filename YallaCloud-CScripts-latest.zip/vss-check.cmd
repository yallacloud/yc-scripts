@echo off
rem vss-check - is VSS actually healthy? READ-ONLY, changes nothing, safe on production.
rem
rem   vss-check                 the only command most people need
rem   vss-check -Full           also list every healthy writer and provider
rem   vss-check -Json           one JSON object per finding, for Salt / an RMM / a monitor
rem   vss-check -EventHours 72  look further back in the event log (default 24)
rem   vss-check -SelfCheck      built-in assertions, no admin needed, changes nothing
rem   vss-check -Help
rem
rem WHY: a backup that says SUCCESS is not the same as a backup you can restore. Acronis, and
rem   PBS through qemu-guest-agent or VMware Tools, all rely on VSS to freeze the machine so
rem   databases are captured cleanly. If VSS is broken the backup STILL SUCCEEDS - it just
rem   quietly stops being application-consistent, and you find out at restore time.
rem
rem EXIT CODES: 0 healthy, 1 warnings, 2 at least one CRITICAL finding, 5 not elevated.
rem Log: C:\Scripts\vss-check.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Vss-Check.ps1" %*
exit /b %ERRORLEVEL%
