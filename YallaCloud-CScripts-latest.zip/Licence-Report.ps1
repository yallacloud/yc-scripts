#Requires -Version 5.1
<#
.SYNOPSIS
    Reports Windows Server and SQL Server licensing state for one machine or a
    list of machines. Read-only. Never prints a product key.

.DESCRIPTION
    Answers the questions an audit actually asks:

      Windows   - which edition, is it an Evaluation image, is it activated,
                  by which licensed method (KMS, ADBA, MAK, retail, OEM),
                  which KMS host, how many days until it must renew, how many
                  rearms remain, and - when it is not activated - the
                  Microsoft-documented reason and fix.

      SQL Server- every installed instance, its edition and edition type,
                  whether it is Evaluation, the build the media installed versus
                  the build it is patched to, and where it sits in the support
                  lifecycle.

    Two deliberate design choices:

      1. SQL data comes from the REGISTRY, not from T-SQL. An expired Evaluation
         instance will not start, and that is precisely the instance you most
         need on the report.

      2. It never calls dbatools' Get-DbaProductKey. That command decodes the
         real product key out of the DigitalProductID registry value, and a
         PowerShell transcript would capture it. Everything this report needs is
         answerable from the edition string, so the key is simply never read.
         Windows' own PartialProductKey (the last five characters, which
         Microsoft publishes as a normal property) is the only key material that
         appears anywhere in the output.

.PARAMETER ComputerName
    One or more machines. Defaults to the local computer. Remote machines are
    queried over a CIM session, which needs WinRM.

.PARAMETER Credential
    Credential for the remote CIM sessions.

.PARAMETER Format
    Text (default), Csv, Json or Html.

.PARAMETER Path
    Write the report to this file instead of the console. The extension is not
    changed for you - match it to -Format.

.PARAMETER SelfCheck
    Run the built-in assertions and exit. Touches nothing.

.EXAMPLE
    licence-report
    The local machine, as text.

.EXAMPLE
    licence-report -ComputerName srv01,srv02,srv03 -Format Html -Path C:\Temp\licensing.html
    A dark/light HTML report for three servers.

.EXAMPLE
    licence-report -Format Csv -Path C:\Temp\licensing.csv
    Flat CSV for a spreadsheet.

.NOTES
    Sources
      SoftwareLicensingProduct https://learn.microsoft.com/en-us/previous-versions/windows/desktop/sppwmi/softwarelicensingproduct
      SoftwareLicensingService https://learn.microsoft.com/en-us/previous-versions/windows/desktop/sppwmi/softwarelicensingservice
      activation error codes   https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes
      SQL registry layout      https://learn.microsoft.com/en-us/sql/sql-server/install/file-locations-for-default-and-named-instances-of-sql-server
      SQL lifecycle            https://learn.microsoft.com/en-us/lifecycle/products/sql-server-2022
      Windows Server lifecycle https://learn.microsoft.com/en-us/lifecycle/products/windows-server-2022
#>
[CmdletBinding()]
param(
    [string[]] $ComputerName = @($env:COMPUTERNAME),
    [System.Management.Automation.PSCredential] $Credential,

    [ValidateSet('Text', 'Csv', 'Json', 'Html')]
    [string] $Format = 'Text',

    [string] $Path,
    [switch] $SelfCheck,

    # -Line: everything another program needs, on ONE line per subject. Added 2026-09-01
    # because Salt, an RMM and a billing script all had to parse the human report, which is
    # laid out for a person at a console and will change shape whenever that person's needs do.
    [switch] $Line,

    # Every other command in this payload answers -Help. This one only had
    # comment-based help, so `licence-report -Help` failed with "A parameter cannot be
    # found that matches parameter name 'Help'" - the one script in the set that broke
    # the convention. Noted 2026-08-31.
    [switch] $Help
)

if ($Help) {
@"
licence-report  -  READ-ONLY Windows + SQL Server licensing report. CHANGES NOTHING.

USAGE:
  licence-report                                            this machine, text to console
  licence-report -Format Html -Path C:\Scripts\lic.html
  licence-report -Format Csv  -Path C:\Scripts\lic.csv
  licence-report -ComputerName srv01,srv02 [-Credential (Get-Credential)]
  licence-report -SelfCheck                                 run the built-in self-test
  licence-report -Help

REPORTS: Windows edition, Evaluation or not, activated or not, by which licensed method
  (KMS / ADBA / MAK / retail / OEM), KMS host, days to renewal, rearms left, and when it is
  NOT activated the Microsoft-documented reason and the fix. Then every SQL Server instance,
  its edition, whether it is Evaluation, base build vs patch level, and lifecycle state.

NO PRODUCT KEY IS EVER PRINTED - only Windows' own PartialProductKey (last five chars).
SQL data is read from the REGISTRY, not over T-SQL, so an expired Evaluation instance that
  will not start still appears - which is the case you need it for.

ALSO REPORTS, since 2026-09-01: sockets, physical cores and logical CPUs. SQL Server
  Standard and Enterprise are licensed PER CORE with a four-core-per-VM minimum, and Windows
  Server per physical core pair, so this is the number the licence actually turns on.

EXIT CODES: 0 nothing critical. 1 at least one machine is CRITICAL - not activated, or it
  could not be read at all. There is no other exit code; this command changes nothing, so
  there is nothing for it to half-do.
LOG: C:\Scripts\licence-report.log   (the REPORT goes to the console, or to -Path)
"@ | Write-Host -ForegroundColor Cyan
    exit 0
}

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$commonPath = Join-Path $PSScriptRoot '_yc-licensing.ps1'
if (-not (Test-Path -LiteralPath $commonPath)) {
    throw ('_yc-licensing.ps1 was not found next to this script (' + $commonPath + '). It ships with it; copy both.')
}
. $commonPath

# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------

function ConvertTo-YcHtmlSafe {
    [CmdletBinding()][OutputType([string])]
    param([AllowNull()][AllowEmptyString()][string] $Text)
    $t = '' + $Text
    $t = $t.Replace('&', '&amp;').Replace('<', '&lt;').Replace('>', '&gt;').Replace('"', '&quot;')
    return $t
}

function Get-YcRiskLevel {
    <#
      .SYNOPSIS
        One word per row, so the report sorts by what needs attention.
      .OUTPUTS
        CRITICAL - not activated, or an expired evaluation
        WARNING  - evaluation still running, out-of-support product, grace state
        OK       - licensed and supported
    #>
    [CmdletBinding()][OutputType([string])]
    param(
        [int] $LicenseStatus = 0,
        [bool] $IsEvaluation = $false,
        [string] $SupportState = 'Unknown'
    )
    if ($LicenseStatus -ne 1) { return 'CRITICAL' }
    if ($IsEvaluation)        { return 'WARNING' }
    if ($SupportState -eq 'OutOfSupport') { return 'WARNING' }
    return 'OK'
}

function Invoke-YcSelfCheck {
    [CmdletBinding()] param()
    $script:n = 0; $script:fail = 0
    function T { param([string] $Name, [bool] $Ok)
        $script:n++
        if ($Ok) { Write-Host ('  ok   ' + $Name) -ForegroundColor Green }
        else     { Write-Host ('  FAIL ' + $Name) -ForegroundColor Red; $script:fail++ }
    }
    Write-Host 'licence-report self-check' -ForegroundColor Cyan

    T 'unlicensed is CRITICAL'            ((Get-YcRiskLevel -LicenseStatus 0) -eq 'CRITICAL')
    T 'notification state is CRITICAL'    ((Get-YcRiskLevel -LicenseStatus 5) -eq 'CRITICAL')
    T 'a running evaluation is WARNING'   ((Get-YcRiskLevel -LicenseStatus 1 -IsEvaluation $true) -eq 'WARNING')
    T 'an out-of-support product is WARNING' ((Get-YcRiskLevel -LicenseStatus 1 -SupportState 'OutOfSupport') -eq 'WARNING')
    T 'licensed and supported is OK'      ((Get-YcRiskLevel -LicenseStatus 1 -SupportState 'Mainstream') -eq 'OK')

    T 'HTML escaping handles angle brackets' ((ConvertTo-YcHtmlSafe -Text '<b>x</b>') -eq '&lt;b&gt;x&lt;/b&gt;')
    T 'HTML escaping handles ampersands'     ((ConvertTo-YcHtmlSafe -Text 'a & b') -eq 'a &amp; b')
    T 'HTML escaping tolerates null'         ((ConvertTo-YcHtmlSafe -Text $null) -eq '')

    T 'status names come from the documented enum' ((Get-YcLicenseStatusName -Status 2) -match 'OOBGrace')
    T 'channel token drives the method'            ((Resolve-YcActivationMethod -Channel 'MAK' -LicenseStatus 1) -eq 'MAK')
    T 'the rearm sentinel is never printed as a count' ((Format-YcRearmCount -Value 4294967295) -notmatch '^4294967295$')

    T 'Windows Server 2016 extended support end is recorded' ((Get-YcWindowsLifecycle -Version '2016').Extended -eq '2027-01-12')
    T 'SQL Server 2022 extended support end is recorded'     ((Get-YcSqlLifecycle -Version '2022').Extended -eq '2033-01-12')

    # The single most important safety property of this script.
    $src = Get-Content -LiteralPath $PSCommandPath -Raw
    $callsGetDbaProductKey = ($src -match '(?m)^\s*[^#\r\n]*Get-DbaProductKey\s')
    T 'licence-report never calls Get-DbaProductKey' (-not $callsGetDbaProductKey)

    Write-Host ''
    if ($script:fail -eq 0) { Write-Host ('SELF-CHECK PASSED: ' + $script:n + ' assertions') -ForegroundColor Green; return 0 }
    Write-Host ('SELF-CHECK FAILED: ' + $script:fail + ' of ' + $script:n + ' assertions') -ForegroundColor Red
    return 1
}

if ($SelfCheck) { exit (Invoke-YcSelfCheck) }

# ---------------------------------------------------------------------------
# Collection
# ---------------------------------------------------------------------------

function Get-YcMachineLicensing {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string] $Computer,
        [System.Management.Automation.PSCredential] $Credential
    )
    $session = $null
    $isLocal = ($Computer -eq $env:COMPUTERNAME -or $Computer -eq '.' -or $Computer -eq 'localhost')
    try {
        if (-not $isLocal) {
            $p = @{ ComputerName = $Computer; ErrorAction = 'Stop' }
            if ($Credential) { $p['Credential'] = $Credential }
            $session = New-CimSession @p
        }

        $cim = @{ ErrorAction = 'Stop' }
        if ($session) { $cim['CimSession'] = $session }

        $os  = Get-CimInstance @cim -ClassName Win32_OperatingSystem
        $cs  = Get-CimInstance @cim -ClassName Win32_ComputerSystem
        $svc = $null
        try { $svc = Get-CimInstance @cim -ClassName SoftwareLicensingService } catch { }
        $prod = $null
        $sppErr = ''
        try {
            $rows = @(Get-CimInstance @cim -ClassName SoftwareLicensingProduct -Filter "PartialProductKey IS NOT NULL AND Name LIKE 'Windows%'")
            if ($rows.Count -gt 0) {
                $prod = $rows[0]
                foreach ($r in $rows) { if (('' + $r.ApplicationID) -eq '55c92734-d682-4d71-983e-d6ec3f16059f') { $prod = $r; break } }
            }
        } catch {
            # A damaged licensing store makes the provider throw rather than
            # return nothing - usually 0xC004D302. Report it, do not swallow it.
            $m = '' + $_.Exception.Message
            $c = ''
            foreach ($t in @(('' + $_.FullyQualifiedErrorId), $m)) {
                if ($t -match '(?i)(0x[0-9a-f]{8})') { $c = $Matches[1].ToLowerInvariant(); break }
            }
            $sppErr = $(if ($c) { $c + ' - ' + $m } else { $m })
        }

        $build = 0
        if ("$($os.BuildNumber)" -match '^\d+$') { $build = [int] $os.BuildNumber }
        $winVersion = 'unknown'
        switch ($build) {
            { $_ -ge 26100 } { $winVersion = '2025';    break }
            { $_ -ge 20348 } { $winVersion = '2022';    break }
            { $_ -ge 17763 } { $winVersion = '2019';    break }
            { $_ -ge 14393 } { $winVersion = '2016';    break }
            { $_ -ge 9600  } { $winVersion = '2012 R2'; break }
            default          { $winVersion = 'unknown' }
        }

        $chan = 'UNKNOWN'; $ls = 0; $reason = $null; $partial = ''; $grace = 0; $kms = ''; $dkms = ''
        if ($prod) {
            $chan = Get-YcActivationChannel -Description $prod.Description
            if ($prod.LicenseStatus -ne $null) { $ls = [int] $prod.LicenseStatus }
            if ($prod.PSObject.Properties['LicenseStatusReason']) { $reason = $prod.LicenseStatusReason }
            $partial = '' + $prod.PartialProductKey
            if ($prod.PSObject.Properties['GracePeriodRemaining'] -and $prod.GracePeriodRemaining) { $grace = [math]::Floor([double] $prod.GracePeriodRemaining / 1440) }
            if ($prod.PSObject.Properties['KeyManagementServiceMachine']) { $kms = '' + $prod.KeyManagementServiceMachine }
            if ($prod.PSObject.Properties['DiscoveredKeyManagementServiceMachineName']) { $dkms = '' + $prod.DiscoveredKeyManagementServiceMachineName }
        }

        $isEval = (('' + $os.Caption) -match '(?i)evaluation') -or ($chan -eq 'TIMEBASED_EVAL')
        $winLc = Get-YcWindowsLifecycle -Version $winVersion
        $winSupport = 'Unknown'
        if ($winLc) {
            $now = Get-Date
            if     ($now -le [datetime]::ParseExact($winLc.Mainstream, 'yyyy-MM-dd', $null)) { $winSupport = 'Mainstream' }
            elseif ($now -le [datetime]::ParseExact($winLc.Extended,   'yyyy-MM-dd', $null)) { $winSupport = 'Extended' }
            else { $winSupport = 'OutOfSupport' }
        }

        $err = $null
        if ($ls -ne 1 -and $reason) { $err = Resolve-YcActivationError -Code $reason }
        if (-not $err -and $sppErr -and $sppErr -match '(?i)(0x[0-9a-f]{8})') { $err = Resolve-YcActivationError -Code $Matches[1] }
        if ($sppErr) { $chan = 'PROVIDER ERROR' }

        # SQL: registry only. Remote machines need the remote registry service.
        $sql = @()
        if ($isLocal) {
            $sql = @(Get-YcSqlInstance)
        } else {
            try {
                $p2 = @{ ComputerName = $Computer; ScriptBlock = ${function:Get-YcSqlInstance}; ErrorAction = 'Stop' }
                if ($Credential) { $p2['Credential'] = $Credential }
                $sql = @(Invoke-Command @p2)
            } catch {
                Write-Warning ('SQL Server details for ' + $Computer + ' are unavailable (needs PowerShell remoting): ' + $_.Exception.Message)
            }
        }

        $sqlRows = New-Object System.Collections.Generic.List[object]
        foreach ($i in $sql) {
            $state = 'Unknown'
            if ($i.Version) { $state = Get-YcSqlSupportState -Version $i.Version }
            $lc = Get-YcSqlLifecycle -Version $i.Version
            $sqlRows.Add([pscustomobject]@{
                InstanceName = $i.InstanceName
                Version      = $(if ($i.Version) { 'SQL Server ' + $i.Version } else { 'major ' + $i.Major })
                Edition      = $i.Edition
                EditionType  = $i.EditionType
                IsEvaluation = (Test-YcSqlIsEvaluation -Edition $i.Edition)
                BaseBuild    = $i.BaseVersion
                PatchLevel   = $i.PatchLevel
                SupportState = $state
                ExtendedEnd  = $(if ($lc) { $lc.Extended } else { '' })
                Risk         = (Get-YcRiskLevel -LicenseStatus 1 -IsEvaluation (Test-YcSqlIsEvaluation -Edition $i.Edition) -SupportState $state)
            })
        }

        # Sockets and cores, because SQL Server Standard and Enterprise are licensed PER CORE and
        # Windows Server per physical core pair - so a licensing report that cannot say how many
        # cores a machine has cannot answer the only question the licence actually turns on.
        # Win32_ComputerSystem gives the socket count; Win32_Processor the cores per socket.
        # On a VM these are what the hypervisor presents, which is exactly what gets billed.
        $sockets = 0; $cores = 0; $logical = 0
        try{
            $sockets = [int] $cs.NumberOfProcessors
            $logical = [int] $cs.NumberOfLogicalProcessors
            foreach($cpu in @(Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue)){
                $cores += [int] $cpu.NumberOfCores
            }
        }catch{}
        if($cores -le 0){ $cores = $logical }

        return [pscustomobject]@{
            ComputerName      = '' + $cs.Name
            Reachable         = $true
            Error             = ''
            Sockets           = $sockets
            Cores             = $cores
            LogicalCpus       = $logical
            Caption           = '' + $os.Caption
            WindowsVersion    = $winVersion
            Build             = $build
            IsEvaluation      = $isEval
            IsDomainJoined    = [bool] $cs.PartOfDomain
            Domain            = '' + $cs.Domain
            Channel           = $chan
            ActivationMethod  = (Resolve-YcActivationMethod -Channel $chan -LicenseStatus $ls -KmsMachine $kms -DiscoveredKmsMachine $dkms)
            LicenseStatus     = $ls
            LicenseStatusName = $(if ($sppErr) { 'licensing provider failed: ' + $sppErr } else { Get-YcLicenseStatusName -Status $ls })
            PartialProductKey = $partial
            RenewInDays       = $grace
            KmsMachine        = $kms
            DiscoveredKms     = $dkms
            RearmCount        = (Format-YcRearmCount -Value $(if ($svc -and $svc.PSObject.Properties['RemainingWindowsReArmCount']) { $svc.RemainingWindowsReArmCount } else { $null }))
            ClientMachineID   = $(if ($svc -and $svc.PSObject.Properties['ClientMachineID']) { '' + $svc.ClientMachineID } else { '' })
            WindowsSupport    = $winSupport
            WindowsExtEnd     = $(if ($winLc) { $winLc.Extended } else { '' })
            ErrorCode         = $(if ($err) { $err.Code } else { '' })
            ErrorMeaning      = $(if ($err) { $err.Meaning } else { '' })
            ErrorFix          = $(if ($err) { $err.Fix } else { '' })
            ErrorUrl          = $(if ($err) { $err.Url } else { '' })
            Risk              = (Get-YcRiskLevel -LicenseStatus $ls -IsEvaluation $isEval -SupportState $winSupport)
            SqlInstances      = $sqlRows.ToArray()
        }
    } catch {
        return [pscustomobject]@{
            ComputerName = $Computer; Reachable = $false; Error = $_.Exception.Message
            Caption = ''; WindowsVersion = ''; Build = 0; IsEvaluation = $false
            IsDomainJoined = $false; Domain = ''; Channel = ''; ActivationMethod = ''
            LicenseStatus = 0; LicenseStatusName = 'unreachable'; PartialProductKey = ''
            RenewInDays = 0; KmsMachine = ''; DiscoveredKms = ''; RearmCount = ''
            ClientMachineID = ''; WindowsSupport = ''; WindowsExtEnd = ''
            ErrorCode = ''; ErrorMeaning = ''; ErrorFix = ''; ErrorUrl = ''
            Risk = 'CRITICAL'; SqlInstances = @()
        }
    } finally {
        if ($session) { try { Remove-CimSession -CimSession $session -ErrorAction SilentlyContinue } catch { } }
    }
}

# ---------------------------------------------------------------------------
# Renderers
# ---------------------------------------------------------------------------

function Format-YcReportText {
    [CmdletBinding()][OutputType([string])]
    param([Parameter(Mandatory = $true)][AllowEmptyCollection()][object[]] $Rows)
    $sb = New-Object System.Text.StringBuilder
    $null = $sb.AppendLine('YallaCloud licensing report')
    $null = $sb.AppendLine('generated ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '   toolkit ' + $script:YcLicVersion)
    $null = $sb.AppendLine('no product key is printed anywhere in this report; PartialProductKey is the last five characters Windows itself publishes')
    $null = $sb.AppendLine(('=' * 100))
    foreach ($r in $Rows) {
        $null = $sb.AppendLine('')
        $null = $sb.AppendLine('[' + $r.Risk + '] ' + $r.ComputerName)
        if (-not $r.Reachable) { $null = $sb.AppendLine('  UNREACHABLE: ' + $r.Error); continue }
        $null = $sb.AppendLine('  OS                : ' + $r.Caption + '  (build ' + $r.Build + ')')
        $null = $sb.AppendLine('  Evaluation image  : ' + $r.IsEvaluation)
        $null = $sb.AppendLine('  Domain joined     : ' + $r.IsDomainJoined + $(if ($r.IsDomainJoined) { '  (' + $r.Domain + ')' } else { '' }))
        $null = $sb.AppendLine('  Channel           : ' + $r.Channel)
        $null = $sb.AppendLine('  Activation method : ' + $r.ActivationMethod)
        $null = $sb.AppendLine('  Licence status    : ' + $r.LicenseStatusName)
        $null = $sb.AppendLine('  Partial key       : ' + $(if ($r.PartialProductKey) { '...' + $r.PartialProductKey } else { '(none)' }))
        if ($r.RenewInDays -gt 0) { $null = $sb.AppendLine('  Renews within     : ' + $r.RenewInDays + ' days') }
        if ($r.KmsMachine)        { $null = $sb.AppendLine('  KMS host (pinned) : ' + $r.KmsMachine) }
        if ($r.DiscoveredKms)     { $null = $sb.AppendLine('  KMS host (DNS)    : ' + $r.DiscoveredKms) }
        $null = $sb.AppendLine('  Rearms remaining  : ' + $r.RearmCount)
        $null = $sb.AppendLine('  Windows support   : ' + $r.WindowsSupport + $(if ($r.WindowsExtEnd) { '  (extended support ends ' + $r.WindowsExtEnd + ')' } else { '' }))
        if ($r.ErrorCode) {
            $null = $sb.AppendLine('  Reason code       : ' + $r.ErrorCode)
            $null = $sb.AppendLine('    meaning         : ' + $r.ErrorMeaning)
            $null = $sb.AppendLine('    fix             : ' + $r.ErrorFix)
            $null = $sb.AppendLine('    source          : ' + $r.ErrorUrl)
        }
        if (@($r.SqlInstances).Count -eq 0) {
            $null = $sb.AppendLine('  SQL Server        : none installed')
        } else {
            $null = $sb.AppendLine('  SQL Server        :')
            foreach ($s in $r.SqlInstances) {
                $null = $sb.AppendLine('    [' + $s.Risk + '] ' + $s.InstanceName + '  ' + $s.Version)
                $null = $sb.AppendLine('        edition     : ' + $s.Edition + $(if ($s.EditionType) { '  [' + $s.EditionType + ']' } else { '' }))
                $null = $sb.AppendLine('        base build  : ' + $s.BaseBuild + '   (what the media installed)')
                $null = $sb.AppendLine('        patch level : ' + $s.PatchLevel + '   (the current build - compare this one)')
                $null = $sb.AppendLine('        support     : ' + $s.SupportState + $(if ($s.ExtendedEnd) { '  (extended support ends ' + $s.ExtendedEnd + ')' } else { '' }))
                if ($s.IsEvaluation) { $null = $sb.AppendLine('        EVALUATION - 180 days from install, then the engine stops starting.') }
            }
        }
    }
    $null = $sb.AppendLine('')
    $null = $sb.AppendLine(('=' * 100))
    $crit = @($Rows | Where-Object { $_.Risk -eq 'CRITICAL' }).Count
    $warn = @($Rows | Where-Object { $_.Risk -eq 'WARNING' }).Count
    $null = $sb.AppendLine('machines: ' + @($Rows).Count + '   critical: ' + $crit + '   warning: ' + $warn)
    return $sb.ToString()
}

function Format-YcReportCsvRows {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][AllowEmptyCollection()][object[]] $Rows)
    $out = New-Object System.Collections.Generic.List[object]
    foreach ($r in $Rows) {
        $out.Add([pscustomobject]@{
            ComputerName = $r.ComputerName; Product = 'Windows'; Instance = ''
            Version = $r.Caption; Edition = ''; IsEvaluation = $r.IsEvaluation
            Status = $r.LicenseStatusName; Method = $r.ActivationMethod
            PartialKey = $r.PartialProductKey; RenewInDays = $r.RenewInDays
            KmsHost = $(if ($r.KmsMachine) { $r.KmsMachine } else { $r.DiscoveredKms })
            Build = $r.Build; PatchLevel = ''
            Support = $r.WindowsSupport; SupportEnds = $r.WindowsExtEnd
            ErrorCode = $r.ErrorCode; Risk = $r.Risk
        })
        foreach ($s in @($r.SqlInstances)) {
            $out.Add([pscustomobject]@{
                ComputerName = $r.ComputerName; Product = 'SQL Server'; Instance = $s.InstanceName
                Version = $s.Version; Edition = $s.Edition; IsEvaluation = $s.IsEvaluation
                Status = ''; Method = ''; PartialKey = ''; RenewInDays = ''
                KmsHost = ''; Build = $s.BaseBuild; PatchLevel = $s.PatchLevel
                Support = $s.SupportState; SupportEnds = $s.ExtendedEnd
                ErrorCode = ''; Risk = $s.Risk
            })
        }
    }
    return $out.ToArray()
}

function Format-YcReportHtml {
    [CmdletBinding()][OutputType([string])]
    param([Parameter(Mandatory = $true)][AllowEmptyCollection()][object[]] $Rows)
    $h = New-Object System.Text.StringBuilder
    $null = $h.AppendLine('<!DOCTYPE html>')
    $null = $h.AppendLine('<html lang="en"><head><meta charset="utf-8">')
    $null = $h.AppendLine('<meta name="viewport" content="width=device-width, initial-scale=1">')
    $null = $h.AppendLine('<title>YallaCloud licensing report</title>')
    $null = $h.AppendLine('<style>')
    $null = $h.AppendLine(':root{color-scheme:light dark;--bg:#ffffff;--fg:#1a1a1a;--muted:#5a5a5a;--line:#d8d8d8;--card:#f6f7f9;--ok:#0a7d3c;--warn:#8a6100;--crit:#b3261e;--accent:#0b5fa5}')
    $null = $h.AppendLine('@media (prefers-color-scheme: dark){:root{--bg:#12151a;--fg:#e6e8ea;--muted:#9aa3ad;--line:#2c333c;--card:#1a1f26;--ok:#4ec27f;--warn:#e0b155;--crit:#f2857c;--accent:#5aa9f0}}')
    $null = $h.AppendLine('*{box-sizing:border-box}body{margin:0;padding:24px;background:var(--bg);color:var(--fg);font:14px/1.55 "Segoe UI",system-ui,-apple-system,Arial,sans-serif}')
    $null = $h.AppendLine('h1{font-size:20px;margin:0 0 4px}h2{font-size:16px;margin:0 0 8px}p.sub{color:var(--muted);margin:0 0 20px}')
    $null = $h.AppendLine('.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:14px 16px;margin:0 0 16px}')
    $null = $h.AppendLine('table{border-collapse:collapse;width:100%;margin:6px 0 0}th,td{border-bottom:1px solid var(--line);padding:6px 8px;text-align:left;vertical-align:top}')
    $null = $h.AppendLine('th{color:var(--muted);font-weight:600;white-space:nowrap;width:190px}')
    $null = $h.AppendLine('.tag{display:inline-block;padding:1px 8px;border-radius:10px;font-size:12px;font-weight:600;border:1px solid currentColor}')
    $null = $h.AppendLine('.OK{color:var(--ok)}.WARNING{color:var(--warn)}.CRITICAL{color:var(--crit)}')
    $null = $h.AppendLine('code{font-family:Consolas,"Courier New",monospace;background:rgba(127,127,127,.14);padding:1px 5px;border-radius:4px}')
    $null = $h.AppendLine('a{color:var(--accent)}.wrap{overflow-x:auto}')
    $null = $h.AppendLine('</style></head><body>')
    $null = $h.AppendLine('<h1>YallaCloud licensing report</h1>')
    $null = $h.AppendLine('<p class="sub">generated ' + (ConvertTo-YcHtmlSafe -Text (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) + ' &middot; toolkit ' + $script:YcLicVersion +
        ' &middot; no product key appears in this report; the partial key is the last five characters Windows itself publishes</p>')

    foreach ($r in $Rows) {
        $null = $h.AppendLine('<div class="card">')
        $null = $h.AppendLine('<h2>' + (ConvertTo-YcHtmlSafe -Text $r.ComputerName) + ' <span class="tag ' + $r.Risk + '">' + $r.Risk + '</span></h2>')
        if (-not $r.Reachable) {
            $null = $h.AppendLine('<p>UNREACHABLE: ' + (ConvertTo-YcHtmlSafe -Text $r.Error) + '</p></div>')
            continue
        }
        $null = $h.AppendLine('<div class="wrap"><table>')
        $add = {
            param($k, $v)
            $null = $h.AppendLine('<tr><th>' + (ConvertTo-YcHtmlSafe -Text $k) + '</th><td>' + (ConvertTo-YcHtmlSafe -Text ('' + $v)) + '</td></tr>')
        }
        & $add 'OS'                $r.Caption
        & $add 'Build'             $r.Build
        & $add 'Evaluation image'  $r.IsEvaluation
        & $add 'Domain'            $(if ($r.IsDomainJoined) { $r.Domain } else { 'workgroup' })
        & $add 'Channel'           $r.Channel
        & $add 'Activation method' $r.ActivationMethod
        & $add 'Licence status'    $r.LicenseStatusName
        & $add 'Partial key'       $(if ($r.PartialProductKey) { '...' + $r.PartialProductKey } else { '(none)' })
        if ($r.RenewInDays -gt 0) { & $add 'Renews within' ($r.RenewInDays.ToString() + ' days') }
        if ($r.KmsMachine)        { & $add 'KMS host (pinned)' $r.KmsMachine }
        if ($r.DiscoveredKms)     { & $add 'KMS host (DNS)' $r.DiscoveredKms }
        & $add 'Rearms remaining'  $r.RearmCount
        & $add 'Windows support'   ($r.WindowsSupport + $(if ($r.WindowsExtEnd) { ' (extended support ends ' + $r.WindowsExtEnd + ')' } else { '' }))
        if ($r.ErrorCode) {
            & $add 'Reason code' $r.ErrorCode
            & $add 'Meaning'     $r.ErrorMeaning
            & $add 'Fix'         $r.ErrorFix
            $null = $h.AppendLine('<tr><th>Source</th><td><a href="' + (ConvertTo-YcHtmlSafe -Text $r.ErrorUrl) + '">' + (ConvertTo-YcHtmlSafe -Text $r.ErrorUrl) + '</a></td></tr>')
        }
        $null = $h.AppendLine('</table></div>')

        if (@($r.SqlInstances).Count -gt 0) {
            $null = $h.AppendLine('<div class="wrap"><table><tr><th style="width:auto">SQL instance</th><th style="width:auto">Version</th><th style="width:auto">Edition</th><th style="width:auto">Base build</th><th style="width:auto">Patch level</th><th style="width:auto">Support</th><th style="width:auto">Risk</th></tr>')
            foreach ($s in $r.SqlInstances) {
                $null = $h.AppendLine('<tr><td>' + (ConvertTo-YcHtmlSafe -Text $s.InstanceName) + '</td><td>' + (ConvertTo-YcHtmlSafe -Text $s.Version) +
                    '</td><td>' + (ConvertTo-YcHtmlSafe -Text ($s.Edition + $(if ($s.EditionType) { ' [' + $s.EditionType + ']' } else { '' }))) +
                    '</td><td><code>' + (ConvertTo-YcHtmlSafe -Text $s.BaseBuild) + '</code></td><td><code>' + (ConvertTo-YcHtmlSafe -Text $s.PatchLevel) +
                    '</code></td><td>' + (ConvertTo-YcHtmlSafe -Text ($s.SupportState + $(if ($s.ExtendedEnd) { ' (ends ' + $s.ExtendedEnd + ')' } else { '' }))) +
                    '</td><td><span class="tag ' + $s.Risk + '">' + $s.Risk + '</span></td></tr>')
            }
            $null = $h.AppendLine('</table></div>')
        } else {
            $null = $h.AppendLine('<p class="sub">No SQL Server instance is installed.</p>')
        }
        $null = $h.AppendLine('</div>')
    }
    $crit = @($Rows | Where-Object { $_.Risk -eq 'CRITICAL' }).Count
    $warn = @($Rows | Where-Object { $_.Risk -eq 'WARNING' }).Count
    $null = $h.AppendLine('<p class="sub">machines: ' + @($Rows).Count + ' &middot; critical: ' + $crit + ' &middot; warning: ' + $warn + '</p>')
    $null = $h.AppendLine('</body></html>')
    return $h.ToString()
}

# --- main -------------------------------------------------------------------

Assert-YcWindows

$rows = New-Object System.Collections.Generic.List[object]
foreach ($c in $ComputerName) {
    Write-Verbose ('collecting ' + $c)
    $rows.Add((Get-YcMachineLicensing -Computer $c -Credential $Credential))
}
$all = $rows.ToArray()

# ------------------------------------------------------------------------------------------
# -Line: ONE LINE PER SUBJECT, for programs rather than people.
#
# Salt, an RMM and a billing script were all going to end up parsing the Text report, which is
# laid out for a person at a console and changes shape whenever that person's needs change.
# This is a stable, versioned contract instead: key=value pairs, space separated, values with
# spaces quoted, one line for the machine and one line per SQL instance. schema= is first on
# every line so a consumer can refuse a version it does not understand rather than
# misinterpreting it.
#
# NO PRODUCT KEY IS EVER EMITTED - partial only, the same rule the human report follows.
# ------------------------------------------------------------------------------------------
if ($Line) {
    function Q { param([string]$V)
        $t = ('' + $V) -replace '"', "'"
        if ($t -match '\s' -or $t -eq '') { return '"' + $t + '"' }
        return $t
    }
    foreach ($r in $all) {
        if (-not $r.Reachable) {
            Write-Output ('schema=yc.licence/1 kind=machine host=' + (Q $r.ComputerName) + ' reachable=false error=' + (Q $r.Error))
            continue
        }
        Write-Output (
            'schema=yc.licence/1 kind=machine' +
            ' host='        + (Q $r.ComputerName) +
            ' reachable=true' +
            ' os='          + (Q $r.Caption) +
            ' osversion='   + (Q $r.WindowsVersion) +
            ' build='       + (Q $r.Build) +
            ' evaluation='  + (Q ([string]([bool]$r.IsEvaluation)).ToLowerInvariant()) +
            ' channel='     + (Q $r.Channel) +
            ' method='      + (Q $r.ActivationMethod) +
            ' licensestatus=' + (Q $r.LicenseStatus) +
            ' licensestatusname=' + (Q $r.LicenseStatusName) +
            ' partialkey='  + (Q $r.PartialProductKey) +
            ' renewindays=' + (Q $r.RenewInDays) +
            ' rearms='      + (Q $r.RearmCount) +
            ' kmshost='     + (Q $r.KmsMachine) +
            ' kmsdiscovered=' + (Q $r.DiscoveredKms) +
            ' clientmachineid=' + (Q $r.ClientMachineID) +
            ' errorcode='   + (Q $r.ErrorCode) +
            ' supportends=' + (Q $r.WindowsExtEnd) +
            ' sockets='     + (Q $r.Sockets) +
            ' cores='       + (Q $r.Cores) +
            ' logicalcpus=' + (Q $r.LogicalCpus) +
            ' domainjoined=' + (Q ([string]([bool]$r.IsDomainJoined)).ToLowerInvariant()) +
            ' supportstate=' + (Q $r.WindowsSupport) +
            ' risk='        + (Q $r.Risk)
        )
        foreach ($i in @($r.SqlInstances)) {
            # Sizes need a live connection; the rest is read from the registry so a dead
            # Evaluation instance still reports. When the engine will not answer, the size
            # fields say unknown rather than zero - zero would read as "an empty instance".
            $dbCount = 'unknown'; $dataMB = 'unknown'; $logMB = 'unknown'; $totalMB = 'unknown'
            if ($r.ComputerName -eq $env:COMPUTERNAME) {
                $tgt = if ($i.InstanceName -eq 'MSSQLSERVER') { '.' } else { '.\' + $i.InstanceName }
                $cn = $null
                try {
                    Add-Type -AssemblyName 'System.Data' -ErrorAction SilentlyContinue
                    $cn = New-Object System.Data.SqlClient.SqlConnection ('Server=' + $tgt + ';Database=master;Integrated Security=SSPI;Connect Timeout=8;Application Name=YallaCloud-licence-line')
                    $cn.Open()
                    $cmd = $cn.CreateCommand()
                    $cmd.CommandText = "SET NOCOUNT ON; SELECT COUNT(DISTINCT database_id) AS N," +
                        "CAST(SUM(CASE WHEN type=0 THEN size END)*8.0/1024 AS decimal(18,1)) AS D," +
                        "CAST(SUM(CASE WHEN type=1 THEN size END)*8.0/1024 AS decimal(18,1)) AS L FROM sys.master_files"
                    $cmd.CommandTimeout = 15
                    $rd = $cmd.ExecuteReader()
                    if ($rd.Read()) {
                        $dbCount = [string]$rd['N']; $dataMB = [string]$rd['D']; $logMB = [string]$rd['L']
                        try { $totalMB = [string]([decimal]$dataMB + [decimal]$logMB) } catch { $totalMB = 'unknown' }
                    }
                    $rd.Close()
                } catch { } finally { if ($null -ne $cn) { try { $cn.Close() } catch {} ; try { $cn.Dispose() } catch {} } }
            }
            Write-Output (
                'schema=yc.licence/1 kind=sql' +
                ' host='        + (Q $r.ComputerName) +
                ' instance='    + (Q $i.InstanceName) +
                ' version='     + (Q $i.Version) +
                ' edition='     + (Q $i.Edition) +
                ' editiontype=' + (Q $i.EditionType) +
                ' evaluation='  + (Q ([string]([bool]$i.IsEvaluation)).ToLowerInvariant()) +
                ' basebuild='   + (Q $i.BaseBuild) +
                ' patchlevel='  + (Q $i.PatchLevel) +
                ' supportstate=' + (Q $i.SupportState) +
                ' supportends=' + (Q $i.ExtendedEnd) +
                ' databases='   + (Q $dbCount) +
                ' datamb='      + (Q $dataMB) +
                ' logmb='       + (Q $logMB) +
                ' totalmb='     + (Q $totalMB) +
                ' risk='        + (Q $i.Risk)
            )
        }
    }
    $critL = @($all | Where-Object { $_.Risk -eq 'CRITICAL' }).Count
    exit $(if ($critL -gt 0) { 1 } else { 0 })
}

switch ($Format) {
    'Text' { $out = Format-YcReportText -Rows $all }
    'Html' { $out = Format-YcReportHtml -Rows $all }
    'Json' { $out = ($all | ConvertTo-Json -Depth 6) }
    'Csv'  { $out = ((Format-YcReportCsvRows -Rows $all) | ConvertTo-Csv -NoTypeInformation) -join "`r`n" }
}

if ($Path) {
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Set-Content -LiteralPath $Path -Value $out -Encoding UTF8
    Write-Host ('report written to ' + $Path) -ForegroundColor Green
} else {
    Write-Output $out
}

$crit = @($all | Where-Object { $_.Risk -eq 'CRITICAL' }).Count
exit $(if ($crit -gt 0) { 1 } else { 0 })
