@echo off
rem osquery-register -FleetUrl <host:443> [-EnrollSecret <s> | -EnrollSecretPath <file>]
rem                  [-MsiPath <msi>] [-MsiUrl <url>] [-Sha256 <hash>] [-TlsServerCerts <pem>]
rem                  [-FleetApiToken <token>] [-VerifySec 180] [-Force] [-Help]
rem
rem The MSI exit code is now captured and decoded, osqueryd must reach Running, osquery.flags
rem is read back from disk, and enroll.secret is locked to SYSTEM + Administrators with the
rem ACL verified by reading it back. Pass -FleetApiToken to prove enrolment server-side.
rem The old version printed "osquery enrolled" unconditionally and left the enroll secret
rem readable by every local user.
rem
rem The enroll secret is a FLEET-WIDE credential: prefer -EnrollSecretPath or
rem   set YC_OSQUERY_ENROLL_SECRET=...
rem over putting it on the command line. Outbound 443 only; no inbound port is opened.
rem Logs to C:\Scripts\osquery-register.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Osquery-Register.ps1" %*
exit /b %ERRORLEVEL%
