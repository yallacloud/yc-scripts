param(
  [string]$ConfigPath = 'C:\ProgramData\YallaCloud\sqltemplate\yc-build.json',
  [switch]$Report,
  [switch]$SelfCheck,
  [switch]$Help
)
# =====================================================================================
# Yc-VmBuild.ps1 - the build state machine, from DOTNET to DONE.
# PowerShell 5.1 only. ASCII only.
#
# WHY THIS IS IN THE PAYLOAD AND NOT IN THE USERDATA
#   CloudStack caps user data at 32 KB base64 and the whole state machine was eating it -
#   31,688 of 32,768, three per cent left. Worse, a bug in any of it could only be fixed
#   by re-registering user data on every cloud and redeploying, because a VM's user data
#   is frozen the moment it boots. Here, a fix is a payload update.
#   What CANNOT move, and stays in the user data: the gateway repair, the wait for
#   internet, and the payload fetch. Those three are the ones that must work BEFORE a
#   payload exists to contain them.
#
# WHY IT IS COPIED TO ProgramData BEFORE IT RUNS
#   Update-YcScripts wipes C:\Scripts. A build that survives three reboots cannot have
#   its own worker deleted underneath it half way through, and it must not silently
#   change version mid-build either. The bootstrap copies this file once, and the copy is
#   what the scheduled task runs for the rest of the build.
#
# THE STATE MACHINE. Each step writes the NEXT state before it acts, so a reboot, a crash
# or a power cut resumes in the right place and never repeats a finished step.
#   DOTNET -> SQL -> SQLLIC -> SSMS -> LIC -> NOTIFY -> DONE
#   NAME+ done   NAME- failed   NAME~ skipped by profile
#
# GVLK TRAP: after an Evaluation -> Standard edition change Windows sits on Volume:GVLK
# with status Notification and LOOKS activated. LicenseStatus alone is not proof. LIC
# re-checks up to 3 passes and only reports success on Volume:MAK AND Licensed.
#
# EXIT CODES  0 finished or nothing to do   1 a step failed   2 usage   5 not elevated
# Log: the build log named in the config, plus Application event 1600, source YALLACLOUD.
# =====================================================================================
$ErrorActionPreference = 'Continue'

$HelpText = @"
yc-vmbuild - run the VM build state machine from DOTNET to DONE.

  yc-vmbuild                     resume the build described by yc-build.json
  yc-vmbuild -Report             print the config and the state. Changes nothing.
  yc-vmbuild -ConfigPath <file>  use a different config
  yc-vmbuild -SelfCheck          assertions only, no admin, changes nothing

You do not normally run this by hand. The user data bootstrap writes the config, copies
this script to C:\ProgramData\YallaCloud\sqltemplate and registers the scheduled task
that calls it. Running it again after a finished build is harmless - the state is DONE
and it exits immediately.
"@
if ($Help) { Write-Output $HelpText; exit 0 }

# -------------------------------------------------------------------------------------
# The pure decisions, so -SelfCheck can exercise them with no SQL, no network, no admin.
# -------------------------------------------------------------------------------------
function Get-YcNextState {
  <# The order is fixed; this only answers "what comes after X". Kept pure so the skip
     logic below can walk forward without duplicating the sequence in five places. #>
  param([string]$State)
  # UPDPRE and UPDPOST are in the order ALWAYS. Whether either runs is a profile question,
  # not a sequence question - a state that is sometimes absent from the list is a state
  # whose skip cannot be recorded.
  $order = @('UPDPRE','DOTNET','SQL','SQLLIC','SSMS','LIC','UPDPOST','NOTIFY','DONE')
  $i = [array]::IndexOf($order, $State)
  if ($i -lt 0 -or $i -ge ($order.Count - 1)) { return 'DONE' }
  return $order[$i + 1]
}

function Test-YcStateWanted {
  <# Does the profile want this state? The clamps live in the bootstrap, so by the time
     the config reaches here the flags are already coherent. #>
  param([string]$State, $Cfg)
  switch ($State) {
    'UPDPRE'  { return ([bool]$Cfg.InstallWindowsUpdates -and $Cfg.WindowsUpdateWhen -eq 'Before') }
    'UPDPOST' { return ([bool]$Cfg.InstallWindowsUpdates -and $Cfg.WindowsUpdateWhen -ne 'Before') }
    'DOTNET' { return [bool]$Cfg.InstallDotNet }
    'SQL'    { return [bool]$Cfg.InstallSql }
    # Express is licensed BY BEING EXPRESS. There is no key, and activate-sql refuses it
    # with exit 6 - which would fail the build on a machine that is completely correct.
    # The bootstrap clamps this too; it is guarded twice because a hand-written
    # yc-build.json is the exact case the clamp upstream does not cover.
    'SQLLIC' { return ([bool]$Cfg.InstallSql -and [bool]$Cfg.LicenseSql -and
                       ([string]$Cfg.SqlEdition -notmatch '(?i)^express$')) }
    'SSMS'   { return [bool]$Cfg.InstallSsms }
    'LIC'    { return [bool]$Cfg.LicenseWindows }
    default  { return $true }
  }
}

function Get-YcSqlArgs {
  <# The install-sql command line. Pure, because getting -Maintenance or the retention
     wrong is silent: you get a SQL Server with no backups and a green exit code. #>
  param($Cfg, [string]$PwFile, [string]$ChadminFile = '')
  # -Edition is passed for EXPRESS ONLY, and that is not an inconsistency.
  # Every licensed edition is installed as Evaluation and moved with activate-sql, because
  # setup.exe /ACTION=editionupgrade is the supported path and it needs the key, not the
  # installer. EXPRESS IS A DIFFERENT PRODUCT, not an edition of this media: there is no
  # upgrade path to it from anything, activate-sql refuses it by design (exit 6), and it
  # has to come off its own package at install time or not at all. So Express is the one
  # case where the edition is an INSTALL argument. Proven 2026-09-13 on VCT22E\SQLEXPRESS.
  $isExpress = ([string]$Cfg.SqlEdition -match '(?i)^express$')
  $a = 'C:\Scripts\install-sql.cmd -Version ' + $Cfg.SqlVersion +
       ' -InstanceName ' + $Cfg.InstanceName +
       $(if ($isExpress) { ' -Edition Express' } else { '' }) +
       ' -SaPasswordFile ' + $PwFile + ' -NoReboot' +
       ' -Maintenance ' + $(if ($Cfg.ConfigureSqlBackup) { 'on' } else { 'off' }) +
       ' -Patch ' + $(if ($Cfg.InstallSqlUpdates) { 'on' } else { 'off' })
  # P2 (2.47.6): the team's shared chadmin password is known at build time - give it to install-sql
  # as the S4U fallback for the maintenance tasks, by FILE, never on the command line.
  if ($ChadminFile) { $a += ' -ChadminPasswordFile ' + $ChadminFile }
  if ($Cfg.ConfigureSqlBackup) {
    $a += ' -BackupDir "' + $Cfg.BackupDir + '"' +
          ' -RetainFullDays ' + $Cfg.RetainFullDays +
          ' -RetainDiffDays ' + $Cfg.RetainDiffDays +
          ' -RetainLogDays '  + $Cfg.RetainLogDays +
          ' -MonthlyDir "' + $Cfg.MonthlyDir + '" -MonthlyKeep ' + $Cfg.MonthlyKeep
  }
  return $a
}

function Test-YcWinPermanent {
  <# WHY /xpr AND NOT /dlv (TSBMFDDB02, 2026-10-24)

     That VM was built WIN-LIC with an EMPTY $WinKey. The LIC step took its "no Windows key"
     branch, logged the truth, and then advanced the state machine - which records LIC+ for
     whatever step it is leaving. So the build reported LIC+ on a machine sitting at
     "Notification mode", channel Volume:GVLK, activation error 0x8007232B. The steps string is
     what a human and the ERP both read as "was this licensed", and it said yes.

     /dlv is not proof: after an Evaluation -> Standard edition change Windows sits on
     Volume:GVLK with status Notification and several of its fields look healthy. /xpr answers
     one question and answers it plainly - "The machine is permanently activated." is the only
     string that means licensed. Anything else (notification mode, a grace period with a date,
     a volume activation expiry) is not.

     Pure, so -SelfCheck can prove every one of those strings without a VM. #>
  param([string]$XprText)
  if (-not $XprText) { return $false }
  return ([bool]($XprText -match '(?i)permanently activated'))
}
function Get-YcWinLicenceLine {
  # One line a human reads without knowing the channel vocabulary. The reason code is included
  # ONLY when it is not licensed, because a code next to "licensed" reads like a problem.
  param([hashtable]$W, [bool]$Wanted, [bool]$HasKey)
  if (-not $Wanted) { return 'windows : left on its trial channel by profile' }
  if (-not $HasKey) { return 'windows : NOT LICENSED - the profile asks for a licence but $WinKey was empty' }
  if (Test-YcWinPermanent $W['xpr']) {
    return ('windows : licensed, ' + $W['channel'] + ', key ...' + $W['partial'])
  }
  $r = ''
  if ($W['reason']) { $r = ', activation error ' + $W['reason'] }
  return ('windows : NOT LICENSED - ' + $(if ($W['status']) { $W['status'] } else { 'unknown status' }) +
          ', ' + $(if ($W['channel']) { $W['channel'] } else { 'unknown channel' }) + $r)
}
function Get-YcBuildLines {
  <# The final notification an operator actually reads, in the SAME sections as the YC-BUILDER
     userdata's yc-notify.ps1 and the Linux kits (E3, 2.47.6): a plain-English line, then
     [ server ], [ build ], [ trace ], each an aligned "label : value". Pure (the machine facts
     come in as -Id / -Ip / -Os), so -SelfCheck asserts the layout. #>
  param([string]$Result, [string]$StepStr, [string]$WinLine, [string]$SqlLine,
        [string]$Took, [string]$PayloadVer, [string]$FailedStep, [string]$ErrText,
        [string]$Say = '', [hashtable]$Id = @{}, [string]$Ip = '', [string]$Os = '', [string]$LogPath = '',
        [datetime]$Now = (Get-Date))
  if (-not $Id) { $Id = @{} }
  $ln = @()
  if ($Say) { $ln += @($Say, '') }
  $ln += '[ server ]'
  if ($Id['vmName']) { $ln += ('vm      : ' + $Id['vmName'] + $(if ($Id['tenant']) { '  (tenant ' + $Id['tenant'] + ')' } else { '' })) }
  $ln += @(('host    : ' + $env:COMPUTERNAME + '  ' + $Ip), ('os      : ' + $Os))
  if ($Id['uuid'])  { $ln += ('uuid    : ' + $Id['uuid']) }
  if ($Id['vmUrl']) { $ln += ('portal  : ' + $Id['vmUrl']) }
  $ln += @('', '[ build ]', ('result  : ' + $Result))
  if ($FailedStep) { $ln += ('failed  : at ' + $FailedStep + $(if ($ErrText) { ' - ' + $ErrText } else { '' })) }
  $ln += @(('steps   : ' + $StepStr), $WinLine, ('sql     : ' + $SqlLine))
  if ($Took) { $ln += ('took    : ' + $Took) }
  $ln += @('', '[ trace ]',
           ('time    : ' + $Now.ToString('yyyy-MM-dd HH:mm:ss') + ' ' + $Now.ToString('zzz') + '  (' + $Now.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ') + ')'),
           ('by      : Yc-VmBuild, payload ' + $(if ($PayloadVer) { $PayloadVer } else { 'unknown' })),
           ('log     : ' + $(if ($LogPath) { $LogPath } else { $Log })))
  return $ln
}
function Get-YcBuildTitle([bool]$Ok, [string]$BuildProfile) {
  # E3: the same words as the Linux kits ("OK BUILD Linux"): what, which OS, which profile.
  return ($(if ($Ok) { 'OK' } else { 'FAILED' }) + ' BUILD Windows ' + $BuildProfile)
}
function Get-YcBuildIdentity {
  # The same identity the userdata's yc-notify.ps1 shows: SMBIOS uuid (= CloudStack VM uuid on KVM),
  # the CloudStack name + tenant from the Salt master's who-file it cached, and the portal link.
  $id = @{ uuid = ''; vmName = ''; tenant = ''; tenantSource = ''; vmUrl = ''; portal = '' }
  try { $id['uuid'] = ([string](Get-CimInstance Win32_ComputerSystemProduct -ErrorAction Stop).UUID).ToLower() } catch {}
  try {
    $who = [string](Get-Content -LiteralPath (Join-Path $Base 'yc-who.txt') -Raw -ErrorAction Stop)
    if ($who -match '(?m)^tenant=(\S+)') { $id['tenant'] = $Matches[1]; $id['tenantSource'] = 'salt-who' }
    if ($who -match '(?m)^name=(\S+)')   { $id['vmName'] = $Matches[1] }
  } catch {}
  if (-not $id['vmName']) { $id['vmName'] = $env:COMPUTERNAME.ToLower() }
  $u = [string]$Cfg.CloudStackUrl
  if ($u -and $id['uuid']) { $id['portal'] = $u; $id['vmUrl'] = $u.TrimEnd('/') + '/#/vm/' + $id['uuid'] }
  return $id
}
function Get-YcHostFacts {
  $ip = ''; $os = ''
  try { $ip = [string](@(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notmatch '^(127\.|169\.254\.)' } | Select-Object -First 1).IPAddress) } catch {}
  try { $os = ((Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Caption -replace 'Microsoft Windows ','') } catch {}
  return @{ ip = $ip; os = $os }
}
function Get-YcIdFields([hashtable]$Id) {
  # -Field pairs Yc-Event.ps1 maps into cloud{} / vm{} and remembers for later day-2 events.
  return @(('vmName=' + $Id['vmName']), ('vmUuid=' + $Id['uuid']), ('tenant=' + $Id['tenant']), ('tenantSource=' + $Id['tenantSource']),
           ('cloudVmUrl=' + $Id['vmUrl']), ('cloudPortal=' + $Id['portal']), 'kit=win-builder', 'log=C:\Scripts\yc-deploy.log')
}
function Get-YcPayloadVersion {
  try {
    $m = Select-String -Path 'C:\Scripts\yc-payload-version.txt' -Pattern '^payload_version\s*=\s*(\S+)' -ErrorAction Stop |
         Select-Object -First 1
    if ($m) { return $m.Matches[0].Groups[1].Value }
  } catch {}
  return ''
}

if ($SelfCheck) {
  $pass = 0; $fail = 0
  function T($n, $c) { if ($c) { Write-Output ('ok   ' + $n); $script:pass++ } else { Write-Output ('FAIL ' + $n); $script:fail++ } }

  T 'DOTNET -> SQL'      ((Get-YcNextState 'DOTNET') -eq 'SQL')
  T 'SQL -> SQLLIC'      ((Get-YcNextState 'SQL')    -eq 'SQLLIC')
  T 'SQLLIC -> SSMS'     ((Get-YcNextState 'SQLLIC') -eq 'SSMS')
  T 'SSMS -> LIC'        ((Get-YcNextState 'SSMS')   -eq 'LIC')
  T 'UPDPRE -> DOTNET'   ((Get-YcNextState 'UPDPRE')  -eq 'DOTNET')
  T 'LIC -> UPDPOST'     ((Get-YcNextState 'LIC')     -eq 'UPDPOST')
  T 'UPDPOST -> NOTIFY'  ((Get-YcNextState 'UPDPOST') -eq 'NOTIFY')
  T 'NOTIFY -> DONE'     ((Get-YcNextState 'NOTIFY') -eq 'DONE')
  T 'DONE stays DONE'    ((Get-YcNextState 'DONE')   -eq 'DONE')
  T 'nonsense -> DONE'   ((Get-YcNextState 'BANANA') -eq 'DONE')

  $updA = [pscustomobject]@{ InstallWindowsUpdates=$true;  WindowsUpdateWhen='After' }
  $updB = [pscustomobject]@{ InstallWindowsUpdates=$true;  WindowsUpdateWhen='Before' }
  $updN = [pscustomobject]@{ InstallWindowsUpdates=$false; WindowsUpdateWhen='After' }
  T 'updates OFF skips both'  ((-not (Test-YcStateWanted 'UPDPRE' $updN)) -and (-not (Test-YcStateWanted 'UPDPOST' $updN)))
  T 'After runs only UPDPOST' ((-not (Test-YcStateWanted 'UPDPRE' $updA)) -and (Test-YcStateWanted 'UPDPOST' $updA))
  T 'Before runs only UPDPRE' ((Test-YcStateWanted 'UPDPRE' $updB) -and (-not (Test-YcStateWanted 'UPDPOST' $updB)))

  $full = [pscustomobject]@{ InstallDotNet=$true; InstallSql=$true; LicenseSql=$true; InstallSsms=$true; LicenseWindows=$true }
  $win  = [pscustomobject]@{ InstallDotNet=$false; InstallSql=$false; LicenseSql=$false; InstallSsms=$false; LicenseWindows=$true }
  $eval = [pscustomobject]@{ InstallDotNet=$true; InstallSql=$true; LicenseSql=$false; InstallSsms=$true; LicenseWindows=$false }
  T 'SQL-FULL wants SQLLIC'      (Test-YcStateWanted 'SQLLIC' $full)
  T 'WIN-LIC skips SQL'          (-not (Test-YcStateWanted 'SQL' $win))
  T 'WIN-LIC skips DOTNET'       (-not (Test-YcStateWanted 'DOTNET' $win))
  T 'WIN-LIC still wants LIC'    (Test-YcStateWanted 'LIC' $win)
  T 'SQL-EVAL skips SQLLIC'      (-not (Test-YcStateWanted 'SQLLIC' $eval))
  T 'SQL-EVAL still installs SQL'(Test-YcStateWanted 'SQL' $eval)
  T 'SQL-EVAL skips windows lic' (-not (Test-YcStateWanted 'LIC' $eval))
  T 'NOTIFY is never skipped'    (Test-YcStateWanted 'NOTIFY' $win)

  $c = [pscustomobject]@{ SqlVersion='2019'; InstanceName='MSSQLSERVER'; ConfigureSqlBackup=$true
                          BackupDir='D:\bak'; RetainFullDays=35; RetainDiffDays=14; RetainLogDays=14
                          MonthlyDir='D:\mon'; MonthlyKeep=12 }
  $a = Get-YcSqlArgs -Cfg $c -PwFile 'C:\x.txt'
  T 'sql args: maintenance on'   ($a -match '-Maintenance on')
  T 'sql args: retention passed' ($a -match '-RetainFullDays 35' -and $a -match '-RetainLogDays 14')
  T 'sql args: monthly passed'   ($a -match '-MonthlyDir "D:\\mon" -MonthlyKeep 12')
  T 'sql args: instance passed'  ($a -match '-InstanceName MSSQLSERVER')
  T 'sql args: no -Edition for a licensed edition' ($a -notmatch '-Edition')
  $cx = [pscustomobject]@{ SqlVersion='2022'; InstanceName='SQLEXPRESS'; SqlEdition='Express'
                           ConfigureSqlBackup=$true; BackupDir='C:\b'; RetainFullDays=35
                           RetainDiffDays=14; RetainLogDays=14; MonthlyDir='C:\m'; MonthlyKeep=12 }
  $ax = Get-YcSqlArgs -Cfg $cx -PwFile 'C:\x.txt'
  T 'sql args: Express passes -Edition Express' ($ax -match '-Edition Express')
  T 'sql args: Express still gets maintenance'  ($ax -match '-Maintenance on')
  $ex = [pscustomobject]@{ InstallSql=$true; LicenseSql=$true; SqlEdition='Express' }
  T 'SQLLIC never runs on Express'  (-not (Test-YcStateWanted 'SQLLIC' $ex))
  $en = [pscustomobject]@{ InstallSql=$true; LicenseSql=$true; SqlEdition='Web' }
  T 'SQLLIC still runs for Web'     (Test-YcStateWanted 'SQLLIC' $en)
  $c3 = [pscustomobject]@{ SqlVersion='2019'; InstanceName='X'; ConfigureSqlBackup=$false; InstallSqlUpdates=$true }
  T 'sql args: -Patch on'        ((Get-YcSqlArgs -Cfg $c3 -PwFile 'C:\x') -match '-Patch on')
  $c4 = [pscustomobject]@{ SqlVersion='2019'; InstanceName='X'; ConfigureSqlBackup=$false; InstallSqlUpdates=$false }
  T 'sql args: -Patch off'       ((Get-YcSqlArgs -Cfg $c4 -PwFile 'C:\x') -match '-Patch off')
  $c2 = [pscustomobject]@{ SqlVersion='2019'; InstanceName='X'; ConfigureSqlBackup=$false }
  T 'sql args: chadmin fallback by file'  ((Get-YcSqlArgs -Cfg $c -PwFile 'C:\x.txt' -ChadminFile 'C:\c.txt') -match '-ChadminPasswordFile C:\\c\.txt')
  T 'sql args: no chadmin file, no switch' ((Get-YcSqlArgs -Cfg $c -PwFile 'C:\x.txt') -notmatch 'Chadmin')
  $a2 = Get-YcSqlArgs -Cfg $c2 -PwFile 'C:\x.txt'
  T 'backup off: maintenance off'($a2 -match '-Maintenance off')
  T 'backup off: no retention'   ($a2 -notmatch 'Retain')

  Write-Output ''
  # ---------------------------------------------------------------------------------
  # LIC must not be recorded as done on a machine that is not licensed. Every string below is
  # real slmgr output; the 0x8007232B case is TSBMFDDB02, 2026-10-24, which reported LIC+.
  # ---------------------------------------------------------------------------------
  T 'xpr: permanently activated is licensed' (Test-YcWinPermanent 'The machine is permanently activated.')
  T 'xpr: wording and case do not matter'    (Test-YcWinPermanent 'Windows(R), ServerStandard edition: The machine is PERMANENTLY ACTIVATED.')
  T 'xpr: notification mode is NOT licensed' (-not (Test-YcWinPermanent 'Windows is in Notification mode'))
  T 'xpr: a grace period is NOT licensed'    (-not (Test-YcWinPermanent 'Volume activation will expire 1/15/2027 3:00:00 PM'))
  T 'xpr: timebased eval is NOT licensed'    (-not (Test-YcWinPermanent 'Timebased activation will expire 2/2/2027 1:00:00 AM'))
  T 'xpr: empty is NOT licensed'             (-not (Test-YcWinPermanent ''))
  T 'xpr: null is NOT licensed'              (-not (Test-YcWinPermanent $null))

  $wOk  = @{ channel='Volume:MAK';  partial='T6QD2'; status='Licensed';     reason='';           xpr='The machine is permanently activated.' }
  $wBad = @{ channel='Volume:GVLK'; partial='';      status='Notification'; reason='0x8007232B'; xpr='Windows is in Notification mode' }
  T 'licence line: licensed says so'        ((Get-YcWinLicenceLine -W $wOk  -Wanted $true  -HasKey $true)  -match '^windows : licensed, Volume:MAK')
  T 'licence line: licensed shows no code'  ((Get-YcWinLicenceLine -W $wOk  -Wanted $true  -HasKey $true)  -notmatch '0x')
  T 'licence line: unlicensed is loud'      ((Get-YcWinLicenceLine -W $wBad -Wanted $true  -HasKey $true)  -match 'NOT LICENSED')
  T 'licence line: carries the code'        ((Get-YcWinLicenceLine -W $wBad -Wanted $true  -HasKey $true)  -match '0x8007232B')
  T 'licence line: an empty key is named'   ((Get-YcWinLicenceLine -W $wBad -Wanted $true  -HasKey $false) -match 'WinKey was empty')
  T 'licence line: a trial is no failure'   ((Get-YcWinLicenceLine -W $wBad -Wanted $false -HasKey $false) -match 'by profile')

  $id0 = @{ vmName = 'testr3-win22'; tenant = 'admin'; uuid = 'aaaa-1'; vmUrl = 'https://cs.example/#/vm/aaaa-1' }
  $bl = Get-YcBuildLines -Result 'build finished' -StepStr 'NET+ SYNC+ LIC-' -WinLine 'windows : NOT LICENSED - x' `
                         -SqlLine '2019 Standard MSSQLSERVER licensed' -Took '37 min' -PayloadVer '2.43.0' `
                         -Say 'Finished - the server is ready.' -Id $id0 -Ip '10.1.1.5' -Os 'Server 2022' -LogPath 'C:\Scripts\yc-deploy.log'
  $blj = (@($bl) -join '|')
  T 'lines: plain English first'      ($bl[0] -eq 'Finished - the server is ready.')
  T 'lines: three sections in order'  ($blj.IndexOf('[ server ]') -lt $blj.IndexOf('[ build ]') -and $blj.IndexOf('[ build ]') -lt $blj.IndexOf('[ trace ]'))
  T 'lines: vm + tenant'              ($blj -match 'vm      : testr3-win22  \(tenant admin\)')
  T 'lines: portal link'              ($blj -match 'portal  : https://cs.example/#/vm/aaaa-1')
  T 'lines: result in build'          ($blj -match 'result  : build finished')
  T 'lines: steps are included'       ($blj -match 'steps   : NET\+ SYNC\+ LIC-')
  T 'lines: the licence line is kept' ($blj -match 'windows : NOT LICENSED')
  T 'lines: sql is labelled'          ($blj -match 'sql     : 2019 Standard')
  T 'lines: took is included'         ($blj -match 'took    : 37 min')
  T 'lines: payload version is named' ($blj -match 'by      : Yc-VmBuild, payload 2\.43\.0')
  T 'lines: host is there'            ($blj -match 'host    : ')
  T 'lines: time is there'            ($blj -match 'time    : ')
  T 'lines: log is the deploy log'    ($blj -match 'log     : C:\\Scripts\\yc-deploy\.log')
  T 'lines: every data line aligned'  ((@($bl | Where-Object { $_ -and $_ -notmatch '^\[ [a-z]+ \]$' -and $_ -ne $bl[0] -and $_ -notmatch '^[a-z]{2,7} +: ' }).Count) -eq 0)
  $bf = Get-YcBuildLines -Result 'BUILD FAILED' -StepStr 'NET+ SQL-' -WinLine 'windows : not reached' `
                         -SqlLine 'none' -Took '' -PayloadVer '' -FailedStep 'SQL' -ErrText 'installer rc=1603'
  $bfj = (@($bf) -join '|')
  T 'lines: a failure names the step' ($bfj -match 'failed  : at SQL - installer rc=1603')
  T 'lines: no took line when unknown' ($bfj -notmatch 'took    :')
  T 'lines: unknown payload is said'  ($bfj -match 'payload unknown')
  T 'lines: no vm line without an id' ($bfj -notmatch 'vm      :')
  T 'title: OK BUILD Windows <profile>' ((Get-YcBuildTitle -Ok $true -BuildProfile 'WIN-TRIAL') -eq 'OK BUILD Windows WIN-TRIAL')
  T 'title: FAILED BUILD Windows'       ((Get-YcBuildTitle -Ok $false -BuildProfile 'SQL-EVAL') -eq 'FAILED BUILD Windows SQL-EVAL')

  Write-Output ('SelfCheck: ' + $pass + ' passed, ' + $fail + ' failed')
  if ($fail -gt 0) { exit 1 } else { exit 0 }
}

# -------------------------------------------------------------------------------------
if (-not (Test-Path -LiteralPath $ConfigPath)) { Write-Output ('no config at ' + $ConfigPath); exit 2 }
$Cfg   = (Get-Content -LiteralPath $ConfigPath -Raw) | ConvertFrom-Json
$Base  = Split-Path -Parent $ConfigPath
$Log   = Join-Path $Base 'yc-sqltemplate.log'
$State = Join-Path $Base 'yc-sqltemplate.state'
$Steps = Join-Path $Base 'yc-sqltemplate.steps'
$Task  = 'YC-SqlTemplate'

function L($m){
  Add-Content -Path $Log -Value ('[' + (Get-Date -f 'yyyy-MM-dd HH:mm:ss') + '] ' + $m) -Encoding ascii
  try { Write-EventLog -LogName Application -Source YALLACLOUD -EntryType Information -EventId 1600 -Message ('[yc-vmbuild] ' + $m) -EA SilentlyContinue } catch {}
}
function Get-State { if (Test-Path $State) { (Get-Content $State -TotalCount 1).Trim() } else { 'DOTNET' } }
function Add-Step($t){ Add-Content -Path $Steps -Value $t -Encoding ascii }
function Get-Steps { if (Test-Path $Steps) { ((Get-Content $Steps) -join ' ') } else { '' } }
function Set-State($s, $mark = '+'){
  $prev = Get-State
  if ($prev -ne $s) { Add-Step ($prev + $mark) }
  Set-Content -Path $State -Value $s -Encoding ascii; L ('state -> ' + $s)
}
function Restart-Now($next){ Set-State $next; L 'restarting'; shutdown /r /t 10 /c "yc-vmbuild"; exit 0 }

function Yc-Event($argline) {
  # Never fatal. A webhook that is down must not cost a build.
  if (-not (Test-Path 'C:\Scripts\yc-event.cmd')) { L 'yc-event not present, skipping'; return }
  try { & cmd /c ('C:\Scripts\yc-event.cmd ' + $argline) *>> $Log; L ('yc-event ' + $argline + ' rc=' + $LASTEXITCODE) }
  catch { L ('yc-event failed: ' + $_.Exception.Message) }
}
function Fail($step, $detail) {
  Add-Step ($step + '-')
  L ('FAILED at ' + $step + ': ' + $detail)
  # Same shape as the completed event, priority 5. A failure that arrives looking like a routine
  # notification is a failure nobody opens.
  $title = Get-YcBuildTitle -Ok $false -BuildProfile ([string]$Cfg.Profile)
  $sqlLine = $(if ($Cfg.InstallSql) { [string]$Cfg.SqlVersion + ' ' + [string]$Cfg.SqlEdition + ' ' + [string]$Cfg.InstanceName } else { 'none' })
  $id = Get-YcBuildIdentity; $hf = Get-YcHostFacts
  $lines = Get-YcBuildLines -Result 'BUILD FAILED - the VM is NOT ready to hand over' `
                            -StepStr (Get-Steps) `
                            -WinLine ('windows : not reached - the build stopped at ' + $step) `
                            -SqlLine $sqlLine -Took '' -PayloadVer (Get-YcPayloadVersion) `
                            -FailedStep $step -ErrText $detail -Say 'Problem - needs attention, see the result and next lines.' `
                            -Id $id -Ip $hf['ip'] -Os $hf['os'] -LogPath 'C:\Scripts\yc-deploy.log'
  Yc-EventRich @{
    Type         = 'vm.deploy.failed'
    FailedStep   = $step
    ErrorText    = $detail
    Step         = (Get-Steps)
    Extra        = $title
    NtfyTitle    = ($title + ' - ' + $env:COMPUTERNAME)
    NtfyPriority = '5'
    NtfyTags     = 'rotating_light,build'
    NtfyLine     = $lines
    Field        = @('area=deploy', 'status=failed', ('summary=' + $title), ('profile=' + [string]$Cfg.Profile),
                     ('failedStep=' + $step), ('error=' + $detail), ('steps=' + (Get-Steps))) + (Get-YcIdFields $id)
  }
  exit 1
}
function Get-WinLic {
  # Not reporting - this is the control flow of LIC. The GVLK trap is decided from it.
  # /xpr is read as well as /dlv because /dlv alone is what let LIC+ be recorded on an
  # unlicensed machine: see Test-YcWinPermanent.
  $d = cscript //nologo C:\Windows\System32\slmgr.vbs /dlv 2>&1 | Out-String
  $ch=''; $pk=''; $st=''; $rs=''
  if ($d -match 'Product Key Channel:\s*(.+)') { $ch = $Matches[1].Trim() }
  if ($d -match 'Partial Product Key:\s*(.+)') { $pk = $Matches[1].Trim() }
  if ($d -match 'License Status:\s*(.+)')      { $st = $Matches[1].Trim() }
  # The code a human can actually look up. 0x8007232B is "DNS name does not exist", which is
  # what an unkeyed GVLK box reports when it tries to find a KMS host that is not there.
  if ($d -match 'Notification Reason:\s*(0x[0-9A-Fa-f]+)') { $rs = $Matches[1].Trim() }
  $xp = ''
  try { $xp = (cscript //nologo C:\Windows\System32\slmgr.vbs /xpr 2>&1 | Out-String).Trim() } catch {}
  return @{ channel=$ch; partial=$pk; status=$st; reason=$rs; xpr=$xp }
}





function Yc-EventRich([hashtable]$Splat) {
  # Never fatal. A webhook that is down must not cost a build.
  # Yc-Event.ps1 is called directly rather than through yc-event.cmd because -NtfyLine and
  # -Field are ARRAYS: pushing them through a cmd command string is a quoting accident waiting
  # to happen, and an aligned line full of colons and spaces is exactly the shape that breaks.
  if (-not (Test-Path 'C:\Scripts\Yc-Event.ps1')) { L 'Yc-Event.ps1 not present, skipping'; return }
  try {
    & 'C:\Scripts\Yc-Event.ps1' @Splat *>> $Log
    # The type and title only. The splat can carry a key fragment, and the log is not the place.
    L ('yc-event ' + [string]$Splat['Type'] + ' "' + [string]$Splat['NtfyTitle'] + '" rc=' + $LASTEXITCODE)
  } catch { L ('yc-event failed: ' + $_.Exception.Message) }
}

$s = Get-State
if ($Report) {
  Write-Output ('state   : ' + $s)
  Write-Output ('steps   : ' + (Get-Steps))
  Write-Output ('profile : ' + $Cfg.Profile)
  foreach ($k in @('InstallDotNet','InstallSql','LicenseSql','InstallSsms','LicenseWindows','ConfigureSqlBackup')) {
    Write-Output ('  ' + $k.PadRight(20) + ' = ' + $Cfg.$k)
  }
  Write-Output ('sql     : ' + $Cfg.SqlVersion + ' ' + $Cfg.SqlEdition + ' instance ' + $Cfg.InstanceName)
  Write-Output ('backup  : ' + $Cfg.BackupDir + '  FULL ' + $Cfg.RetainFullDays + 'd DIFF ' + $Cfg.RetainDiffDays + 'd LOG ' + $Cfg.RetainLogDays + 'd  monthly x' + $Cfg.MonthlyKeep)
  exit 0
}

L ('=== yc-vmbuild resuming at ' + $s + ' ===')
L ('PROFILE ' + $Cfg.Profile + ' -> dotnet=' + $Cfg.InstallDotNet + ' sql=' + $Cfg.InstallSql +
   ' sqlLicence=' + $Cfg.LicenseSql + ' ssms=' + $Cfg.InstallSsms + ' windowsLicence=' + $Cfg.LicenseWindows +
   ' sqlBackup=' + $Cfg.ConfigureSqlBackup)

# Walk any leading states the profile does not want, recording each skip.
while ($s -ne 'NOTIFY' -and $s -ne 'DONE' -and -not (Test-YcStateWanted $s $Cfg)) {
  $next = Get-YcNextState $s
  if ($s -eq 'SQLLIC' -and $Cfg.InstallSql) { L 'SQL LEFT ON EVALUATION by profile. This box is NOT licensed for production.' }
  if ($s -eq 'LIC') { L 'WINDOWS LEFT ON ITS TRIAL CHANNEL by profile.' }
  L ($s + ' skipped by profile ' + $Cfg.Profile)
  Set-State $next '~'; $s = $next
}

function Invoke-YcWindowsUpdate($stateName) {
  # NO -Reboot passed to winupdate. It would restart the box itself, from a state that
  # has not been written yet, and the resume would land in the wrong place. The state
  # machine owns every reboot here - that is the only way a resume can be trusted.
  # Updates arrive in waves: a pass installs what it can, reboots, and then MORE become
  # applicable. Three passes, then move on and say so rather than looping forever.
  $pf = Join-Path $Base ('yc-build.' + $stateName + '.passes')
  $p = 0; if (Test-Path $pf) { $p = [int](Get-Content $pf -TotalCount 1) }
  if ($p -ge 3) { L ($stateName + ': 3 update passes done, moving on'); return $false }
  Set-Content -Path $pf -Value ([string]($p + 1)) -Encoding ascii
  L ($stateName + ': winupdate -Security -Install, pass ' + ($p + 1) + ' of 3')
  & cmd /c 'C:\Scripts\winupdate.cmd -Security -Install' *>> $Log
  L ('winupdate rc=' + $LASTEXITCODE)
  # Ask WINDOWS whether it wants a restart rather than inferring it from an exit code.
  $pending = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') -or
             (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')
  if ($pending) { L ($stateName + ': restart pending - taking it, then returning to this state'); return $true }
  return $false
}

if ($s -eq 'UPDPRE') {
  if (Invoke-YcWindowsUpdate 'UPDPRE') { Restart-Now 'UPDPRE' }
  Set-State 'DOTNET'; $s = 'DOTNET'
  while ($s -ne 'NOTIFY' -and -not (Test-YcStateWanted $s $Cfg)) { $n = Get-YcNextState $s; L ($s + ' skipped'); Set-State $n '~'; $s = $n }
}

if ($s -eq 'DOTNET') {
  L 'install-dotnet -UpgradeChocolatey'
  & cmd /c 'C:\Scripts\install-dotnet.cmd -UpgradeChocolatey' *>> $Log
  $rc = $LASTEXITCODE; L ('install-dotnet rc=' + $rc)
  if ($rc -eq 8) { Restart-Now 'DOTNET' }          # come back and re-check, then fall through
  if ($rc -ne 0) { Fail 'DOTNET' ('install-dotnet rc=' + $rc) }
  Set-State 'SQL'; $s = 'SQL'
  while ($s -ne 'NOTIFY' -and -not (Test-YcStateWanted $s $Cfg)) { $n = Get-YcNextState $s; L ($s + ' skipped'); Set-State $n '~'; $s = $n }
}

if ($s -eq 'SQL') {
  $pwf = Join-Path $Base '.sa-password'
  Set-Content -Path $pwf -Value $Cfg.SaPassword -Encoding ascii
  & icacls $pwf /inheritance:r /grant 'SYSTEM:F' 'Administrators:F' *>> $Log
  $bf = Join-Path $Base 'yc-sqltemplate.sqlreboots'
  $rb = 0; if (Test-Path $bf) { $rb = [int](Get-Content $bf -TotalCount 1) }
  $cpf = ''
  if ([string]$Cfg.ChadminPassword) {
    $cpf = Join-Path $Base '.chadmin-password'
    Set-Content -Path $cpf -Value ([string]$Cfg.ChadminPassword) -Encoding ascii
    & icacls $cpf /inheritance:r /grant 'SYSTEM:F' 'Administrators:F' *>> $Log
  }
  $args = Get-YcSqlArgs -Cfg $Cfg -PwFile $pwf -ChadminFile $cpf
  L $args
  & cmd /c $args *>> $Log
  $rc = $LASTEXITCODE; L ('install-sql rc=' + $rc)
  if (Test-Path 'C:\Scripts\install-sql.reboot-required') {
    Remove-Item 'C:\Scripts\install-sql.reboot-required' -Force -EA SilentlyContinue
    if ($rb -ge 4) { Fail 'SQL' 'install-sql asked for a 5th reboot - refusing, this is a loop' }
    Set-Content -Path $bf -Value ([string]($rb + 1)) -Encoding ascii
    L ('install-sql wants a reboot - restart ' + ($rb + 1) + ' of 4')
    Restart-Now 'SQL'
  }
  Remove-Item $pwf -Force -EA SilentlyContinue
  if ($cpf) { Remove-Item $cpf -Force -EA SilentlyContinue }
  if ($rc -ne 0) { Fail 'SQL' ('install-sql rc=' + $rc) }
  Restart-Now 'SQLLIC'                              # unconditional: the licence needs it
}

if ($s -eq 'SQLLIC') {
  if ($Cfg.SqlKey) {
    L ('activate-sql -TargetEdition ' + $Cfg.SqlEdition)
    & cmd /c ('C:\Scripts\activate-sql.cmd -ProductKey ' + $Cfg.SqlKey + ' -TargetEdition ' + $Cfg.SqlEdition + ' -InstanceName ' + $Cfg.InstanceName) *>> $Log
    $rc = $LASTEXITCODE; L ('activate-sql rc=' + $rc)
    if ($rc -ne 0 -and $rc -ne 3010) { Fail 'SQLLIC' ('activate-sql rc=' + $rc) }
  } else { L 'no SQL key - leaving the instance on Evaluation' }
  Set-State 'SSMS'; $s = 'SSMS'
  while ($s -ne 'NOTIFY' -and -not (Test-YcStateWanted $s $Cfg)) { $n = Get-YcNextState $s; L ($s + ' skipped'); Set-State $n '~'; $s = $n }
}

if ($s -eq 'SSMS') {
  L 'install-ssms'
  & cmd /c 'C:\Scripts\install-ssms.cmd' *>> $Log
  $rc = $LASTEXITCODE; L ('install-ssms rc=' + $rc)
  if ($rc -eq 8) { Restart-Now 'SSMS' }
  Set-State 'LIC'; $s = 'LIC'
  while ($s -ne 'NOTIFY' -and -not (Test-YcStateWanted $s $Cfg)) { $n = Get-YcNextState $s; L ($s + ' skipped'); Set-State $n '~'; $s = $n }
}

if ($s -eq 'LIC') {
  if ($Cfg.WinKey) {
    $lf = Join-Path $Base 'yc-sqltemplate.licpasses'
    $lp = 0; if (Test-Path $lf) { $lp = [int](Get-Content $lf -TotalCount 1) }
    $w = Get-WinLic
    L ('windows now: status=' + $w.status + ' channel=' + $w.channel + ' key=' + $w.partial)
    # Volume:MAK AND Licensed. Either one alone is the GVLK trap.
    if ($w.channel -notmatch 'Volume:MAK' -or $w.status -notmatch 'Licensed') {
      if ($lp -ge 3) { L 'activate-windows has not reached Volume:MAK in 3 passes - reporting what is true' }
      else {
        Set-Content -Path $lf -Value ([string]($lp + 1)) -Encoding ascii
        L ('activate-windows, pass ' + ($lp + 1) + ' of 3')
        & cmd /c ('C:\Scripts\activate-windows.cmd -ProductKey ' + $Cfg.WinKey) *>> $Log
        $rc = $LASTEXITCODE; L ('activate-windows rc=' + $rc)
        if ($rc -eq 3) { Restart-Now 'LIC' }        # edition change staged, finishes after reboot
        for ($i = 1; $i -le 20; $i++) {
          $w = Get-WinLic
          if ($w.channel -match 'Volume:MAK' -and $w.status -match 'Licensed') { break }
          Start-Sleep -Seconds 30
        }
        L ('windows settled: status=' + $w.status + ' channel=' + $w.channel + ' key=' + $w.partial)
      }
    } else { L 'windows already Licensed on Volume:MAK' }
  } else { L 'no Windows key - leaving the trial channel'; $w = Get-WinLic }

  # THE STEP MARKER NOW TELLS THE TRUTH. Set-State records "<step><mark>" for the step it is
  # leaving, and this one used to leave unconditionally with '+'. On TSBMFDDB02 that recorded
  # LIC+ for a WIN-LIC build whose $WinKey was empty - Notification mode, Volume:GVLK,
  # 0x8007232B - and the steps string is what both a human and the ERP read as "was this
  # licensed". /xpr is the only answer that cannot be misread; see Test-YcWinPermanent.
  $script:WinLicOk     = $true
  $script:WinLicReason = ''
  if ($Cfg.LicenseWindows) {
    $script:WinLicOk = (Test-YcWinPermanent $w['xpr'])
    if (-not $script:WinLicOk) {
      $script:WinLicReason = $(if (-not $Cfg.WinKey) { 'no WinKey was supplied' }
                               elseif ($w['reason'])  { $w['status'] + ' ' + $w['channel'] + ' ' + $w['reason'] }
                               else                   { $w['status'] + ' ' + $w['channel'] }).Trim()
      L ('LIC- : windows is NOT licensed (' + $script:WinLicReason + '). slmgr /xpr said: ' + $w['xpr'])
    } else {
      L 'LIC+ : slmgr /xpr confirms the machine is permanently activated'
    }
  }
  # Handed to NOTIFY so its licence line describes the same moment the LIC- marker was decided
  # on. NOTIFY falls back to a fresh read, which is what a build resumed after a reboot needs.
  $script:LastWinLic = $w
  # Not a Fail: an unlicensed Windows must not abandon the rest of the build. It is recorded as
  # LIC- and carried into the final event, which is where somebody will act on it.
  Set-State 'UPDPOST' $(if ($script:WinLicOk) { '+' } else { '-' }); $s = 'UPDPOST'
  while ($s -ne 'NOTIFY' -and -not (Test-YcStateWanted $s $Cfg)) { $n = Get-YcNextState $s; L ($s + ' skipped'); Set-State $n '~'; $s = $n }
}

if ($s -eq 'UPDPOST') {
  if (Invoke-YcWindowsUpdate 'UPDPOST') { Restart-Now 'UPDPOST' }
  Set-State 'NOTIFY'; $s = 'NOTIFY'
}

if ($s -eq 'NOTIFY') {
  # The build's last word, and for most VMs the only thing anybody reads about it. It used to go
  # out in the bare old format while every OTHER event in the build - started, salt, acronis,
  # wsus - came from the userdata's yc-notify.ps1 with a title, a priority, tags and aligned
  # lines. The one message that says whether the machine is fit to hand over was the plainest.
  $ok  = $true
  if ($Cfg.LicenseWindows -and ($null -ne $script:WinLicOk)) { $ok = [bool]$script:WinLicOk }
  $stepStr = Get-Steps
  # A '-' anywhere in the steps string means some step recorded a failure, LIC- included.
  if ($stepStr -match '[A-Z]-(\s|$)') { $ok = $false }

  $sqlLine = $(if ($Cfg.InstallSql) {
                 [string]$Cfg.SqlVersion + ' ' + [string]$Cfg.SqlEdition + ' ' + [string]$Cfg.InstanceName +
                 $(if ($Cfg.LicenseSql) { ' licensed' } else { ' UNLICENSED (evaluation)' })
               } else { 'none' })
  $winLine = Get-YcWinLicenceLine -W $(if ($script:LastWinLic) { $script:LastWinLic } else { Get-WinLic }) `
                                  -Wanted ([bool]$Cfg.LicenseWindows) -HasKey ([bool]$Cfg.WinKey)
  $took = ''
  try {
    $st0 = (Get-Content (Join-Path $Base 'yc-sqltemplate.started') -TotalCount 1).Trim()
    if ($st0) { $took = [string][int]((Get-Date) - [datetime]$st0).TotalMinutes + ' min' }
  } catch {}

  $result = $(if ($ok) { 'build finished' } else { 'build finished WITH PROBLEMS - see the lines below' })
  $id = Get-YcBuildIdentity; $hf = Get-YcHostFacts
  $lines  = Get-YcBuildLines -Result $result -StepStr $stepStr -WinLine $winLine -SqlLine $sqlLine `
                             -Took $took -PayloadVer (Get-YcPayloadVersion) -Id $id -Ip $hf['ip'] -Os $hf['os'] -LogPath 'C:\Scripts\yc-deploy.log' `
                             -Say $(if ($ok) { 'Finished - the server is ready. Logins are in the ERP.' } else { 'Finished with problems - see the build lines.' })
  # -Extra stays the single-line key=value summary the receiver has always parsed. Unchanged on
  # purpose: it is part of the contract with the ERP, and the new detail is in the fields.
  $extra = 'profile=' + $Cfg.Profile +
           ' sql=' + $(if ($Cfg.InstallSql) { [string]$Cfg.SqlVersion + ' ' + [string]$Cfg.SqlEdition } else { 'none' }) +
           ' sqlLicensed=' + $Cfg.LicenseSql +
           ' ssms=' + $Cfg.InstallSsms +
           ' winLicensed=' + $Cfg.LicenseWindows +
           ' sqlBackup=' + $Cfg.ConfigureSqlBackup
  $title = Get-YcBuildTitle -Ok $ok -BuildProfile ([string]$Cfg.Profile)
  $splat = @{
    Type         = 'vm.deploy.completed'
    Step         = $stepStr
    Extra        = $title
    NtfyTitle    = ($title + ' - ' + $env:COMPUTERNAME)
    NtfyPriority = $(if ($ok) { '3' } else { '5' })
    NtfyTags     = $(if ($ok) { 'white_check_mark,build' } else { 'rotating_light,build' })
    NtfyLine     = $lines
    Field        = @('area=deploy', 'status=completed', ('summary=' + $title), ('profile=' + [string]$Cfg.Profile),
                     ('winLicensed=' + [string]$script:WinLicOk), ('buildResult=' + $(if ($ok) { 'ok' } else { 'problems' })),
                     ('steps=' + $stepStr), ('extra=' + $extra)) + (Get-YcIdFields $id)
  }
  if ($script:WinLicReason) { $splat['Field'] += ('winLicenceReason=' + $script:WinLicReason) }
  if ($Cfg.SqlKey -and $Cfg.SqlKey.Length -ge 5) { $splat['SqlKeyLast5'] = $Cfg.SqlKey.Substring($Cfg.SqlKey.Length - 5) }
  Yc-EventRich $splat
  Set-State 'DONE'; $s = 'DONE'
}

if ($s -eq 'DONE') {
  # A durable "this finished" marker. The state file says DONE too, but a state file is
  # a cursor - it is written before every step and is meaningless out of context. This is
  # a record: what was asked for, what ran, when it ended, in one file anyone can read
  # without knowing the state machine.
  $done = Join-Path $Base 'yc-build.completed'
  if (-not (Test-Path $done)) {
    $started = ''
    try { $started = (Get-Content (Join-Path $Base 'yc-sqltemplate.started') -TotalCount 1).Trim() } catch {}
    $mins = ''
    try { if ($started) { $mins = [int]((Get-Date) - [datetime]$started).TotalMinutes } } catch {}
    ([ordered]@{
      profile   = $Cfg.Profile
      steps     = (Get-Steps)
      startedAt = $started
      finishedAt= (Get-Date -f s)
      elapsedMin= $mins
      installSql=$Cfg.InstallSql; licenseSql=$Cfg.LicenseSql; installSsms=$Cfg.InstallSsms
      licenseWindows=$Cfg.LicenseWindows; sqlBackup=$Cfg.ConfigureSqlBackup
      windowsUpdates=$Cfg.InstallWindowsUpdates; windowsUpdateWhen=$Cfg.WindowsUpdateWhen
      sqlUpdates=$Cfg.InstallSqlUpdates
      host      = $env:COMPUTERNAME
    } | ConvertTo-Json) | Set-Content -Path $done -Encoding ascii
    L ('checkpoint written: ' + $done)
  }
  # House rule: cloud-init must not run again after the build (a later boot would reset the Administrator
  # password / re-apply the template's). yc-boot.ps1 does it at the NEXT boot; a build that never reboots
  # (WIN-TRIAL, WIN-LIC without updates) would keep it on until then - so do it here as well.
  try {
    $cb = Get-CimInstance Win32_Service -Filter "Name='cloudbase-init'" -EA Stop
    if ($cb -and $cb.StartMode -ne 'Disabled') { & sc.exe config cloudbase-init start= disabled | Out-Null; L 'cloudbase-init DISABLED (build complete)' }
  } catch { L ('cloudbase-init could not be disabled: ' + $_.Exception.Message) }
  L 'complete - removing the startup task'
  try { Unregister-ScheduledTask -TaskName $Task -Confirm:$false -EA SilentlyContinue } catch {}
}
L '=== yc-vmbuild run end ==='
exit 0
