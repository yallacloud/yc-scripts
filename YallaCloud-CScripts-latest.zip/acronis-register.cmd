@echo off
rem acronis-register - silent install + registration of the Acronis Cyber Protect agent,
rem                    with proof that the agent service is actually Running.
rem
rem CHANGED, AND WHY:
rem   The previous wrapper's example put the registration token straight on the command
rem   line. Anything passed here lands in Win32_Process.CommandLine, in Windows Security
rem   event 4688 (ProcessCreationIncludeCmdLine is on in this estate and the Security
rem   channel is forwarded off-box), and in the PowerShell transcript header, because
rem   PowerShell records the host process command line when Start-Transcript runs.
rem   Use -TokenFile <path>, or set YC_ACRONIS_TOKEN before calling. -Token still works.
rem
rem PREFERRED:
rem   set YC_ACRONIS_TOKEN=...
rem   acronis-register -Region AE
rem
rem   acronis-register -Region AE -TokenFile C:\Scripts\.acronis.token
rem   acronis-register -Region SG -TokenFile C:\Scripts\.acronis.token
rem   acronis-register -Url https://ae01-cloud.acronis.com -TokenFile C:\Scripts\.acronis.token
rem   acronis-register -Diagnose
rem   acronis-register -Help
rem
rem STILL SUPPORTED (visible in the process table - avoid in production):
rem   acronis-register -Token ABC12-DEF34 -Url https://ae01-cloud.acronis.com
rem
rem Regions: AE = https://ae01-cloud.acronis.com    SG = https://sg-cloud.acronis.com
rem
rem Exit codes: 0 installed + MMS Running, 1 install failed, 2 usage/bad URL,
rem             3 installed but reboot required, 4 bad installer binary,
rem             5 not elevated, 6 data center unreachable on 443,
rem             7 installer said OK but MMS never reached Running.
rem Log: C:\Scripts\acronis-register.log   Installer log: C:\Scripts\acronis-install.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Register-Acronis.ps1" %*
exit /b %ERRORLEVEL%
