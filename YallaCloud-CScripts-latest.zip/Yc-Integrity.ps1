param(
  # WHAT TO CHECK. One per run, so a failure in one never hides a failure in another.
  [ValidateSet('','Fast','Full')]
  [string]$Sql = '',           # Fast = CHECKDB PHYSICAL_ONLY. Full = the whole logical check.
  [switch]$Disk,               # chkdsk /scan read-only on every fixed NTFS volume
  [switch]$RestoreVerify,      # RESTORE VERIFYONLY over the newest full in msdb
  [switch]$SuspectPages,       # read msdb.dbo.suspect_pages - instant, free

  [string]$SqlInstance,        # omitted: every instance on this host
  [string[]]$Database,         # omitted: every online user database
  [int]$MinFreeGB = 5,         # the disk gate. CHECKDB builds a snapshot on the same volume.
  [int]$MaxDop = 1,            # the throttle. CHECKDB goes parallel and takes every core otherwise.
  [switch]$NoRerun,            # skip the second pass (the re-run is what suppresses false positives)
  [switch]$NoNotify,           # do not send a yc-event
  [switch]$Report,             # show what would run; change nothing, send nothing
  [switch]$Help
)
# ================================================================================================
# Yc-Integrity.ps1 - YALLACLOUD day-2 command: the ONE place that decides whether this machine's
# data is still intact, and the ONE place that says so out loud.
#
# WHY THIS EXISTS AS A COMMAND AND NOT AS T-SQL IN A TASK ARGUMENT
#   Five scheduled tasks need the same three things: a disk-free gate before they start, a
#   re-run before they cry wolf, and a PASS as well as a FAIL on the way out. Writing that three
#   times in three task argument strings is how the three copies drift.
#
# THE THREE RULES THIS COMMAND EXISTS TO ENFORCE
#
#   1. GATE ON FREE SPACE FIRST.  DBCC CHECKDB builds an internal database snapshot on the SAME
#      volume as the data file. On a volume that is nearly full that snapshot is what finally
#      fills it, and a full data volume stops SQL Server. A check that causes the outage it was
#      meant to prevent is worse than no check, so a tight volume SKIPS with a flag.
#
#   2. RE-RUN BEFORE YOU ALERT.  A single alert that turns out to be transient trains people to
#      ignore alerts, and then the real one is ignored too. Every failure is checked a second
#      time. Clean on the second pass = TRANSIENT, reported as INFO. Dirty twice = ALERT.
#      -NoRerun exists for a human who already knows what they are looking at.
#
#   3. REPORT THE PASS, NOT ONLY THE FAIL.  Silence is not a success signal - a task that was
#      never registered, a service that never started and a check that passed all look identical
#      from the outside. "backups ran, integrity clean" is the message that proves the chain is
#      alive. That is why a clean run still sends an event.
#
# WHAT IT CANNOT DO
#   DBCC CHECKDB finds corruption. It does not repair it: REPAIR_ALLOW_DATA_LOSS does exactly
#   what its name says. Detection buys you a clean backup to restore from, nothing more. That is
#   the whole reason retention has to outlive detection latency.
#
# EXIT CODES
#   0  every check passed
#   1  a check FAILED TWICE - real finding, escalate
#   2  skipped: the disk gate refused, or there was nothing to check
#   3  a check failed once and was clean on the re-run (TRANSIENT) - looked at, not escalated
#   5  not elevated
#   6  SQL could not be reached
#
# LOG  C:\Scripts\yc-integrity.log     STATE  C:\Scripts\yc-integrity.json
# ================================================================================================

$ErrorActionPreference = 'Continue'
$ScriptsDir = 'C:\Scripts'
$Tag        = 'yc-integrity'

$Usage = @'
yc-integrity  -  is this machine's data still intact, and say so either way.

USAGE
  yc-integrity -Sql Fast            CHECKDB PHYSICAL_ONLY on every database   (the daily pass)
  yc-integrity -Sql Full            the whole logical CHECKDB                 (the weekly pass)
  yc-integrity -Disk                chkdsk /scan read-only on every fixed NTFS volume
  yc-integrity -RestoreVerify       RESTORE VERIFYONLY over the newest full backup
  yc-integrity -SuspectPages        read msdb.dbo.suspect_pages. Instant, free, changes nothing.
  yc-integrity -Report              say what WOULD run. Changes nothing, sends nothing.

OPTIONS
  -SqlInstance <n>   one instance. Omitted: every instance on this host.
  -Database <a,b>    named databases. Omitted: every online user database.
  -MinFreeGB <n>     the disk gate, default 5. CHECKDB snapshots onto the data volume.
  -MaxDop <n>        default 1. CHECKDB goes parallel and takes every core otherwise.
  -NoRerun           do not re-check a failure. Use when you already know what you are seeing.
  -NoNotify          do not send a yc-event.

WHY Fast IS NOT ENOUGH ON ITS OWN
  PHYSICAL_ONLY verifies page checksums. A database that ran with PAGE_VERIFY NONE has pages with
  NO CHECKSUM, and PHYSICAL_ONLY has nothing to compare those against - it reports clean on
  damaged data. Full CHECKDB does the logical checks and finds damage either way. Fast daily,
  Full weekly, and Full is the one to trust on a newly migrated box.

THE RE-RUN
  Any failure is checked a second time before anybody is told:
    clean            -> PASS, event sent, exit 0
    failed then clean-> TRANSIENT, INFO event, exit 3
    failed twice     -> ALERT event, exit 1

Log:
  C:\Scripts\yc-integrity.log    every line, and the Application event log, source YALLACLOUD
  C:\Scripts\yc-integrity.json   the last result of every check, for a dashboard to read

EXIT  0 all passed | 1 failed twice, escalate | 2 skipped (disk gate / nothing to check)
      3 transient  | 5 not elevated | 6 SQL unreachable
'@

# The house library is present on any machine that has been through adopt or a fresh build. If it
# is not, this still has to log something - a checker that goes silent because its logger is
# missing is the exact failure this command exists to prevent.
$script:LibOK = $false
$lib = Join-Path $ScriptsDir '_yc-lib.ps1'
if (Test-Path -LiteralPath $lib) {
  try { . $lib
        if (Get-Command Start-YcLog -ErrorAction SilentlyContinue) { Start-YcLog -Name $Tag -Dir $ScriptsDir | Out-Null }
        $script:LibOK = $true } catch {}
}
function L {
  param([string]$Message,[string]$Level='INFO')
  if ($script:LibOK -and (Get-Command Write-YcLog -ErrorAction SilentlyContinue)) { Write-YcLog $Message $Level; return }
  $line = ('{0}  {1}  [YALLACLOUD][{2}] [{3}] {4}' -f (Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK'), $env:COMPUTERNAME, $Tag, $Level, $Message)
  switch ($Level) { 'ERROR'{Write-Host $line -ForegroundColor Red} 'WARN'{Write-Host $line -ForegroundColor Yellow}
                    'OK'{Write-Host $line -ForegroundColor Green} default{Write-Host $line} }
  try { Add-Content -LiteralPath (Join-Path $ScriptsDir ($Tag + '.log')) -Value $line -Encoding Ascii -ErrorAction SilentlyContinue } catch {}
}


# Every exit path closes the transcript. A bare 'exit' leaves it open with no [END] line and the
# exit code unrecorded, which yc-compliance EXITDISC blocks on - rightly, because a checker whose
# own log is truncated is a checker you cannot audit.
function Exit-Integrity {
  param([int]$Code)
  if ($script:LibOK -and (Get-Command Stop-YcLog -ErrorAction SilentlyContinue)) { Stop-YcLog $Code }
  exit $Code
}

if ($Help) { Write-Host $Usage; Exit-Integrity 0 }
if (-not ($Sql -or $Disk -or $RestoreVerify -or $SuspectPages)) { Write-Host $Usage; Exit-Integrity 0 }

function Test-Elevated {
  try { return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch { return $false }
}
# powershell.exe -File passes every argument as a plain string, so "-Database a,b" arrives as ONE
# element containing a comma rather than two. Every .cmd wrapper in this payload uses -File.
if ($Database) { $Database = @($Database | ForEach-Object { ([string]$_) -split ',' } | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }

if (-not (Test-Elevated) -and -not $Report) { L 'not elevated - chkdsk and SQL both need it.' 'ERROR'; Exit-Integrity 5 }

$script:Results = New-Object System.Collections.Generic.List[object]
function Add-Result {
  param([string]$Check,[string]$Target,[string]$Status,[string]$Detail,[int]$Attempts=1)
  $script:Results.Add([ordered]@{ check=$Check; target=$Target; status=$Status; detail=$Detail
                                  attempts=$Attempts; at=(Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK') }) | Out-Null
  switch ($Status) {
    'PASS'      { L ($Check + ' ' + $Target + ': PASS') 'OK' }
    'TRANSIENT' { L ($Check + ' ' + $Target + ': failed once, CLEAN on the re-run - transient, not escalated. ' + $Detail) 'WARN' }
    'FAIL'      { L ($Check + ' ' + $Target + ': FAILED TWICE. ' + $Detail) 'ERROR' }
    'SKIP'      { L ($Check + ' ' + $Target + ': skipped - ' + $Detail) 'WARN' }
  }
}

# Rule 2 in one place: run it, and if it fails, run it once more before anybody is told.
function Invoke-Checked {
  param([string]$Check,[string]$Target,[scriptblock]$Probe)
  if ($Report) { L ('WOULD RUN  ' + $Check + ' on ' + $Target); return }
  $first = & $Probe
  if ($first.ok) { Add-Result $Check $Target 'PASS' '' 1; return }
  if ($NoRerun) { Add-Result $Check $Target 'FAIL' $first.detail 1; return }
  L ($Check + ' ' + $Target + ': first pass reported a problem - re-running before anyone is told.') 'WARN'
  Start-Sleep -Seconds 5
  $second = & $Probe
  if ($second.ok) { Add-Result $Check $Target 'TRANSIENT' ('first pass said: ' + $first.detail) 2 }
  else            { Add-Result $Check $Target 'FAIL'      ($second.detail) 2 }
}

# ------------------------------------------------------------------------------------------------
# SQL plumbing. sqlcmd, not the SqlServer module: it is on every box that has SQL, it needs no
# module import, and it is what install-sql's own scheduled tasks already use.
# ------------------------------------------------------------------------------------------------
function Get-SqlCmdPath {
  if ($script:SqlCmd) { return $script:SqlCmd }
  $c = Get-Command sqlcmd.exe -ErrorAction SilentlyContinue
  if ($c) { $script:SqlCmd = $c.Source; return $script:SqlCmd }
  foreach ($g in @('C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\*\Tools\Binn\sqlcmd.exe',
                   'C:\Program Files\Microsoft SQL Server\*\Tools\Binn\sqlcmd.exe')) {
    $f = @(Get-ChildItem -Path $g -ErrorAction SilentlyContinue | Sort-Object FullName -Descending)
    if ($f.Count) { $script:SqlCmd = $f[0].FullName; return $script:SqlCmd }
  }
  return $null
}

function Invoke-Sql {
  param([string]$Target,[string]$Query,[int]$TimeoutSec = 0)
  $exe = Get-SqlCmdPath
  if (-not $exe) { return @{ ok=$false; text='sqlcmd is not on this host'; code=-1 } }
  # -b makes a T-SQL error set the exit code. Without it a CHECKDB that reports corruption exits 0
  # and every caller believes the database is fine - the single most dangerous default here.
  $a = @('-S',$Target,'-E','-b','-h','-1','-W','-Q',$Query)
  if ($TimeoutSec -gt 0) { $a += @('-t',[string]$TimeoutSec) }
  try {
    $out = & $exe @a 2>&1
    $code = $LASTEXITCODE
    return @{ ok = ($code -eq 0); code = $code
              text = (($out | Where-Object { $_ -and ($_ -notmatch '^\s*$') }) -join "`n").Trim() }
  } catch { return @{ ok=$false; text=$_.Exception.Message; code=-1 } }
}

function Get-SqlTargets {
  if ($SqlInstance) { return @($SqlInstance) }
  $root = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL'
  if (-not (Test-Path -LiteralPath $root)) { return @() }
  $out = @()
  try {
    $names = Get-ItemProperty -LiteralPath $root -ErrorAction Stop
    foreach ($p in $names.PSObject.Properties) {
      if ($p.Name -match '^PS') { continue }
      $svc = Get-Service -Name $(if ($p.Name -eq 'MSSQLSERVER') { 'MSSQLSERVER' } else { 'MSSQL$' + $p.Name }) -ErrorAction SilentlyContinue
      if ($svc -and $svc.Status -eq 'Running') {
        $out += $(if ($p.Name -eq 'MSSQLSERVER') { '.' } else { '.\' + $p.Name })
      }
    }
  } catch {}
  return $out
}

function Get-Databases {
  param([string]$Target)
  if ($Database) { return @($Database) }
  $r = Invoke-Sql -Target $Target -Query "SET NOCOUNT ON; SELECT name FROM sys.databases WHERE database_id > 4 AND state = 0 AND is_read_only = 0;"
  if (-not $r.ok -or -not $r.text) { return @() }
  @($r.text -split "`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ })
}

# Rule 1. Which volume does this database actually live on, and is there room for the snapshot?
function Test-DbVolumeFree {
  param([string]$Target,[string]$Db)
  $q = "SET NOCOUNT ON; SELECT DISTINCT LEFT(physical_name,1) FROM sys.master_files WHERE database_id = DB_ID('" + ($Db -replace "'","''") + "');"
  $r = Invoke-Sql -Target $Target -Query $q
  if (-not $r.ok -or -not $r.text) { return @{ ok=$true; detail='volume could not be determined, proceeding' } }
  foreach ($letter in @($r.text -split "`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ })) {
    $free = $null
    try { $free = [math]::Round((Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $letter + ":'") -ErrorAction Stop).FreeSpace/1GB,1) } catch {}
    if ($null -ne $free -and $free -lt $MinFreeGB) {
      return @{ ok=$false; detail=($letter + ': has ' + [string]$free + ' GB free, below the ' + [string]$MinFreeGB + ' GB gate. CHECKDB snapshots onto this volume and would risk filling it.') }
    }
    # Scale with the database. MEASURED: a real box had a 539 GB database on a volume with 134 GB
    # free - which clears any flat floor comfortably and is still a bad place to start a CHECKDB,
    # because the snapshot grows with every page written while the check runs.
    $sz = Invoke-Sql -Target $Target -Query ("SET NOCOUNT ON; SELECT CONVERT(varchar(20),CAST(SUM(size)*8.0/1024/1024 AS decimal(18,1))) FROM sys.master_files WHERE database_id = DB_ID('" + ($Db -replace "'","''") + "');")
    $dbGB = 0.0; [void][double]::TryParse(([string]$sz).Trim(), [ref]$dbGB)
    if ($dbGB -gt 0 -and $null -ne $free) {
      $want = [math]::Round($dbGB * 0.10, 1)      # 10% of the data size, a working rule of thumb
      if ($free -lt $want) {
        return @{ ok=$false; detail=($letter + ': has ' + [string]$free + ' GB free and this database is ' + [string]$dbGB + ' GB. CHECKDB snapshots onto this volume and grows with write activity; about ' + [string]$want + ' GB headroom is the working minimum. Skipping rather than risking the volume.') }
      }
    }
  }
  return @{ ok=$true; detail='' }
}

function Invoke-SqlIntegrity {
  param([string]$Mode)
  $targets = Get-SqlTargets
  if ($targets.Count -eq 0) { L 'no running SQL Server instance on this host.' 'WARN'; return }
  foreach ($t in $targets) {
    $probe = Invoke-Sql -Target $t -Query 'SELECT 1'
    if (-not $probe.ok) { Add-Result ('CHECKDB-' + $Mode) $t 'SKIP' ('cannot reach the instance: ' + $probe.text); $script:SqlUnreachable = $true; continue }
    $dbs = Get-Databases -Target $t
    if ($dbs.Count -eq 0) { L ($t + ': no online, writable user database to check.'); continue }
    foreach ($db in $dbs) {
      $gate = Test-DbVolumeFree -Target $t -Db $db
      if (-not $gate.ok) { Add-Result ('CHECKDB-' + $Mode) ($t + '/' + $db) 'SKIP' $gate.detail; continue }
      $opts = @('NO_INFOMSGS','ALL_ERRORMSGS')
      if ($Mode -eq 'Fast') { $opts += 'PHYSICAL_ONLY' }
      if ($MaxDop -gt 0)    { $opts += ('MAXDOP = ' + $MaxDop) }
      $q = 'DBCC CHECKDB (' + "N'" + ($db -replace "'","''") + "'" + ') WITH ' + ($opts -join ', ') + ';'
      Invoke-Checked -Check ('CHECKDB-' + $Mode) -Target ($t + '/' + $db) -Probe {
        $r = Invoke-Sql -Target $t -Query $q
        @{ ok = $r.ok; detail = $r.text }
      }.GetNewClosure()
    }
  }
}

function Invoke-SuspectPages {
  foreach ($t in Get-SqlTargets) {
    # Free, instant, and the most under-used table in SQL Server: every page SQL has already found
    # damaged is in here, whether or not anybody was watching at the time.
    $q = "SET NOCOUNT ON; SELECT CONVERT(varchar(10),COUNT(*)) FROM msdb.dbo.suspect_pages WHERE event_type IN (1,2,3);"
    $r = Invoke-Sql -Target $t -Query $q
    if (-not $r.ok) { Add-Result 'suspect_pages' $t 'SKIP' $r.text; continue }
    $n = 0; [void][int]::TryParse(($r.text -replace '[^0-9]',''), [ref]$n)
    if ($n -eq 0) { Add-Result 'suspect_pages' $t 'PASS' '' 1; continue }
    $d = Invoke-Sql -Target $t -Query "SET NOCOUNT ON; SELECT TOP 20 CONVERT(varchar(20),database_id) + ' file ' + CONVERT(varchar(20),file_id) + ' page ' + CONVERT(varchar(20),page_id) + ' type ' + CONVERT(varchar(10),event_type) FROM msdb.dbo.suspect_pages WHERE event_type IN (1,2,3);"
    # No re-run here: suspect_pages is a RECORD of damage already found, not a test that can flap.
    Add-Result 'suspect_pages' $t 'FAIL' ([string]$n + ' damaged page(s) on record. ' + $d.text) 1
  }
}

function Invoke-RestoreVerify {
  foreach ($t in Get-SqlTargets) {
    # A backup that is never restore-tested is not a backup.
    $q = 'DECLARE @f nvarchar(4000); SELECT TOP 1 @f = mf.physical_device_name FROM msdb.dbo.backupmediafamily mf ' +
         'JOIN msdb.dbo.backupset bs ON bs.media_set_id = mf.media_set_id WHERE bs.type = ''D'' ' +
         'ORDER BY bs.backup_finish_date DESC; ' +
         'IF @f IS NULL RAISERROR(''No full backup is recorded in msdb'',16,1); ELSE RESTORE VERIFYONLY FROM DISK = @f WITH CHECKSUM;'
    Invoke-Checked -Check 'RestoreVerify' -Target $t -Probe {
      $r = Invoke-Sql -Target $t -Query $q
      @{ ok = $r.ok; detail = $r.text }
    }.GetNewClosure()
  }
}

# ------------------------------------------------------------------------------------------------
# Disk. chkdsk /scan is the ONLINE, READ-ONLY scan: it does not dismount the volume, does not need
# a reboot, and does not repair. That is deliberate - this command detects, it never fixes.
# Anything that needs /f or /spotfix is a decision for a human in a change window.
# ------------------------------------------------------------------------------------------------
function Invoke-DiskScan {
  $vols = @()
  try {
    $vols = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction Stop |
              Where-Object { $_.FileSystem -eq 'NTFS' })
  } catch { L ('could not enumerate volumes: ' + $_.Exception.Message) 'WARN'; return }
  if ($vols.Count -eq 0) { L 'no fixed NTFS volume found.' 'WARN'; return }

  foreach ($v in $vols) {
    $d = $v.DeviceID          # 'C:'
    # The dirty bit is the cheap signal: Windows itself has already decided this volume needs
    # repair. Report it, do NOT repair it - a /spotfix here would be an unannounced change.
    $dirty = $false
    try { $dirty = ((cmd /c ('fsutil dirty query ' + $d) 2>&1) -join ' ') -match 'is Dirty' } catch {}
    if ($dirty) {
      Add-Result 'DirtyBit' $d 'FAIL' 'the volume dirty bit is SET - Windows has already decided this volume needs repair. Schedule chkdsk /f in a change window (boot-repair -ScheduleChkdsk).' 1
    } else {
      Add-Result 'DirtyBit' $d 'PASS' '' 1
    }

    $free = [math]::Round($v.FreeSpace/1GB,1)
    $pct  = if ($v.Size -gt 0) { [math]::Round(($v.FreeSpace/$v.Size)*100,1) } else { 0 }
    L ($d + ' ' + $free + ' GB free (' + $pct + '%)')
    # A volume this close to full is a failure in its own right: SQL cannot grow a file, a backup
    # cannot land, and CHECKDB cannot snapshot. Saying it here means somebody sees it before the
    # outage rather than during it.
    if ($free -lt $MinFreeGB) {
      Add-Result 'FreeSpace' $d 'FAIL' ([string]$free + ' GB free, below the ' + $MinFreeGB + ' GB floor.') 1
    } else {
      Add-Result 'FreeSpace' $d 'PASS' ([string]$free + ' GB free (' + [string]$pct + '%)') 1
    }

    Invoke-Checked -Check 'chkdsk-scan' -Target $d -Probe {
      # Exit 0 = clean. Anything else means findings; chkdsk reports them on stdout.
      $txt = ''
      try { $txt = ((cmd /c ('chkdsk ' + $d + ' /scan') 2>&1) -join "`n") } catch { return @{ ok=$false; detail=$_.Exception.Message } }
      $code = $LASTEXITCODE
      @{ ok = ($code -eq 0); detail = ('chkdsk exit ' + $code + '. ' + (($txt -split "`n" | Select-Object -Last 6) -join ' ')) }
    }.GetNewClosure()
  }
}

# ------------------------------------------------------------------------------------------------
# Say so, either way. Rule 3.
# ------------------------------------------------------------------------------------------------
function Send-Result {
  param([int]$Code)
  $fails      = @($script:Results | Where-Object { $_.status -eq 'FAIL' })
  $transients = @($script:Results | Where-Object { $_.status -eq 'TRANSIENT' })
  $skips      = @($script:Results | Where-Object { $_.status -eq 'SKIP' })
  $passes     = @($script:Results | Where-Object { $_.status -eq 'PASS' })

  $state = [ordered]@{
    schema='ycintegrity.result/1'; host=$env:COMPUTERNAME
    ran=(Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK')
    checks=@('Sql=' + $Sql; 'Disk=' + [bool]$Disk; 'RestoreVerify=' + [bool]$RestoreVerify; 'SuspectPages=' + [bool]$SuspectPages)
    exitCode=$Code
    summary=@{ pass=$passes.Count; fail=$fails.Count; transient=$transients.Count; skip=$skips.Count }
    results=@($script:Results)
  }
  try { $state | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $ScriptsDir 'yc-integrity.json') -Encoding Ascii } catch {}

  if ($NoNotify -or $Report) { return }
  $ev = Join-Path $ScriptsDir 'Yc-Event.ps1'
  if (-not (Test-Path -LiteralPath $ev)) { L 'Yc-Event.ps1 is not in the payload, so nothing was notified.' 'WARN'; return }

  # The TYPE carries the verdict, so a receiver can route on it without parsing prose.
  $type = 'vm.integrity.passed'
  if ($fails.Count -gt 0)          { $type = 'vm.integrity.failed' }
  elseif ($transients.Count -gt 0) { $type = 'vm.integrity.transient' }
  elseif ($skips.Count -gt 0)      { $type = 'vm.integrity.skipped' }

  $step = ('pass=' + $passes.Count + ' fail=' + $fails.Count + ' transient=' + $transients.Count + ' skip=' + $skips.Count)
  if ($fails.Count -gt 0) {
    $step += '  FAILED: ' + (($fails | ForEach-Object { $_.check + ' ' + $_.target }) -join ', ')
  }
  try {
    Start-Process -FilePath 'powershell.exe' -NoNewWindow -Wait -ArgumentList @(
      '-NoProfile','-ExecutionPolicy','Bypass','-File',$ev,'-Type',$type,'-Step',$step) | Out-Null
    L ('event sent: ' + $type) 'OK'
  } catch { L ('could not send the event: ' + $_.Exception.Message) 'WARN' }
}

# ================================================================================================
# Main
# ================================================================================================
L ('START  sql=' + $(if($Sql){$Sql}else{'-'}) + ' disk=' + [bool]$Disk +
   ' restoreverify=' + [bool]$RestoreVerify + ' suspectpages=' + [bool]$SuspectPages +
   ' report=' + [bool]$Report + '  host=' + $env:COMPUTERNAME)

$script:SqlUnreachable = $false
if ($SuspectPages)   { L '--- suspect_pages ---'; Invoke-SuspectPages }
if ($Sql)            { L ('--- CHECKDB ' + $Sql + ' ---'); Invoke-SqlIntegrity -Mode $Sql }
if ($RestoreVerify)  { L '--- RESTORE VERIFYONLY ---'; Invoke-RestoreVerify }
if ($Disk)           { L '--- disk ---'; Invoke-DiskScan }

if ($Report) { L 'REPORT ONLY - nothing was run, nothing was sent.' 'OK'; L 'END exit=0'; Exit-Integrity 0 }

$fail      = @($script:Results | Where-Object { $_.status -eq 'FAIL' }).Count
$transient = @($script:Results | Where-Object { $_.status -eq 'TRANSIENT' }).Count
$skip      = @($script:Results | Where-Object { $_.status -eq 'SKIP' }).Count
$pass      = @($script:Results | Where-Object { $_.status -eq 'PASS' }).Count

$code = 0
if ($fail -gt 0)                                   { $code = 1 }
elseif ($transient -gt 0)                          { $code = 3 }
elseif ($pass -eq 0 -and $script:SqlUnreachable)   { $code = 6 }
elseif ($pass -eq 0)                               { $code = 2 }

Send-Result -Code $code

L ('SUMMARY  pass=' + $pass + '  fail=' + $fail + '  transient=' + $transient + '  skip=' + $skip) `
  $(if ($fail -gt 0) {'ERROR'} elseif ($transient -gt 0 -or $skip -gt 0) {'WARN'} else {'OK'})
if ($fail -gt 0) {
  L 'A check failed TWICE. This is a real finding - do not wait for it to clear.' 'ERROR'
  L 'Restore from a backup taken BEFORE the corruption. CHECKDB detects; it does not safely repair.' 'ERROR'
}
L ('END exit=' + $code)
Exit-Integrity $code
