param(
  # ---- names preserved from snmp-register.cmd and the catalog ----
  [string]$Community = '',                           # READ-ONLY community string. DEFAULT CHANGED: was 'public'.
  [string[]]$Managers,                               # NOW MANDATORY. Was optional and defaulted to "any host".
  [string]$Trap,                                     # trap destination
  [string]$TrapCommunity,                            # community used for traps (default = -Community)
  [string]$Location,                                 # sysLocation
  [string]$Contact,                                  # sysContact
  # ---- ADDED in this revision ----
  [switch]$NoFirewall,                               # configure SNMP but create no firewall rule
  [int]$SysServices = 79,                            # RFC1156Agent sysServices bitmask (79 = the Windows default)
  [switch]$Help
)
# =====================================================================================
# Snmp-Register.ps1 - enable and configure the built-in Windows SNMP agent (v1/v2c).
# PowerShell 5.1, ASCII only. Runs unattended (cloud-init / SYSTEM / RMM).
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P0-23] THIS SCRIPT PUBLISHED THE HOST TO THE INTERNET WITH COMMUNITY 'public'.
#   Old line 42 wrote PermittedManagers ONLY when -Managers was supplied. -Managers was
#   optional, the default was nothing, and the help's own first example was
#   "snmp-register -Community public". An EMPTY PermittedManagers list is not "no managers
#   allowed" - Windows reads it as ACCEPT SNMP PACKETS FROM ANY HOST. Old line 47 then
#   opened inbound UDP 161 on -Profile Any with no -RemoteAddress. On a public IaaS VM
#   that is unauthenticated remote disclosure of interfaces, routes, the ARP table, the
#   running process list, installed software, services, users and storage - to anyone who
#   can send a UDP packet, because SNMP v1/v2c has no authentication and no encryption.
#   NOW:
#     * -Managers is MANDATORY. No managers, no run. (Parameter semantics changed.)
#     * -Community has no default and the script REFUSES 'public' and 'private'.
#       (Default changed from 'public' to empty. Reported as a parameter change.)
#     * The inbound rule is scoped -RemoteAddress $Managers and is created LAST, only
#       after the service is proven Running and the registry has been read back.
#     * PermittedManagers is written on EVERY run and the whole subkey is rewritten, so
#       re-running with a shorter list actually removes the old entries.
#
# [P0-23b] THE FEATURE INSTALL WAS THREE SWALLOWED ATTEMPTS, ONE OF THEM FICTIONAL.
#   Old lines 31-37: Install-WindowsFeature in a try, then Add-WindowsCapability with
#   -EA SilentlyContinue, then `dism /online /enable-feature /featurename:SNMP`. There is
#   no DISM feature called SNMP - that command returns 0x800f080c "Feature name SNMP is
#   unknown" and the output was piped to Out-Null anyway. Nothing checked whether the
#   service existed afterwards, and the script then wrote registry values under
#   HKLM\...\Services\SNMP\Parameters for a service that may not exist (creating the keys
#   is silently successful, which is why this defect survived), and printed green.
#   NOW: the install path is chosen from what the OS actually offers, each step uses
#   -ErrorAction Stop, and if Get-Service SNMP still returns nothing the script exits 11
#   WITHOUT writing a single registry value and WITHOUT touching the firewall.
#
# VENDOR VERIFICATION - WINDOWS SERVER vs WINDOWS CLIENT
#   Windows Server 2016 / 2019 / 2022 / 2025: SNMP is a Server Manager FEATURE.
#       Install-WindowsFeature -Name SNMP-Service -IncludeManagementTools
#       Install-WindowsFeature -Name SNMP-WMI-Provider          (sub-feature, optional)
#     Confirmed still present on Server 2022 (Microsoft Q&A / Tech Community) and not
#     listed in "Features removed or no longer developed starting with Windows Server 2022":
#       https://learn.microsoft.com/en-us/windows-server/get-started/removed-deprecated-features-windows-server-2022
#   Windows 10 / 11 (and Server images that expose SNMP only as a capability): SNMP is a
#     deprecated Feature on Demand CAPABILITY, not a feature, and the legacy DISM name
#     fails with 0x800f080c:
#       Add-WindowsCapability -Online -Name 'SNMP.Client~~~~0.0.1.0'
#       Add-WindowsCapability -Online -Name 'WMI-SNMP-Provider.Client~~~~0.0.1.0'
#       https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/cannot-install-snmp-wmisnmpprovider
#   This script tries the FEATURE path first when Install-WindowsFeature is available and
#   Get-WindowsFeature actually lists SNMP-Service, and falls back to the CAPABILITY path.
#   Both paths are attempted before giving up, and which one succeeded is logged.
#
#   Registry contract (HKLM\SYSTEM\CurrentControlSet\Services\SNMP\Parameters):
#     ValidCommunities\<community>  REG_DWORD rights: 1 NONE, 2 NOTIFY, 4 READ ONLY,
#       8 READ WRITE, 16 READ CREATE. This script only ever writes 4 (READ ONLY).
#       https://learn.microsoft.com/en-us/windows-hardware/customize/desktop/unattend/microsoft-windows-snmp-agent-service-validcommunities-validcommunity-value
#     PermittedManagers\1..n        REG_SZ, one manager per value. EMPTY = ANY HOST.
#     RFC1156Agent\sysLocation, sysContact (REG_SZ), sysServices (REG_DWORD)
#     TrapConfiguration\<community>\1..n  REG_SZ trap destinations
#
# SNMPv3 - READ THIS
#   The Windows SNMP agent implements SNMP v1 and v2c ONLY. There is no v3, therefore no
#   authentication and no encryption: the community string is a cleartext password sent in
#   every packet, and UDP source addresses are trivially spoofed, so PermittedManagers is
#   a speed bump and not a security control. Windows SNMP MUST NEVER be reachable from
#   anything but a dedicated management network. If you need authenticated, encrypted
#   polling on Windows, use SNMPv3 via Net-SNMP (snmpd for Windows) or - better in this
#   estate - use the Zabbix agent (zabbix-register, PSK/cert encrypted) or windows_exporter
#   behind TLS. This command exists for switch-style NMS platforms that can only speak SNMP.
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was configured. Re-deploy the C:\Scripts payload and re-run.   ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'snmp-register'

$Usage = @'
snmp-register  -  enable + configure the built-in Windows SNMP agent (v1/v2c) for monitoring.
                  Run at DEPLOY, as Administrator.   Log: C:\Scripts\snmp-register.log

USAGE:
  snmp-register -Community <read-community> -Managers <ip[,ip]> [-Trap <ip> [-TrapCommunity <c>]]
                [-Location <l>] [-Contact <c>] [-SysServices 79] [-NoFirewall]
  snmp-register -Help

-Managers IS MANDATORY AND -Community 'public' IS REFUSED.
  An empty PermittedManagers list means ACCEPT FROM ANY HOST - that is how this command
  used to ship, together with community 'public' and an inbound UDP 161 rule on every
  profile. On a public IaaS VM that hands any passer-by your interfaces, routes, ARP
  table, running processes, installed software and services. There is no version of this
  command that opens SNMP to the world any more.

WINDOWS SNMP IS v1/v2c ONLY - THERE IS NO SNMPv3 HERE.
  The community string is a cleartext password in every UDP packet and UDP sources are
  spoofable, so -Managers is a speed bump, not authentication. Only ever expose this on a
  dedicated management network. For authenticated, encrypted monitoring use zabbix-register
  (PSK/cert) or winexporter-register behind TLS, or Net-SNMP if you truly need SNMPv3.

PARAMETERS:
  -Community      READ-ONLY community string. MANDATORY. 'public' and 'private' are refused.
                  It is a secret: prefer the YC_SNMP_COMMUNITY environment variable, because
                  anything on the command line is visible in the process table and in 4688
                  events. This script never prints it.
  -Managers       MANDATORY. Permitted manager IP addresses, comma separated. Written to
                  PermittedManagers AND used as the -RemoteAddress scope of the inbound rule.
  -Trap           Trap destination IP (adds an OUTBOUND UDP 162 rule scoped to it).
  -TrapCommunity  Community used for traps. Default: -Community.
  -Location       sysLocation value.
  -Contact        sysContact value.
  -SysServices    RFC1156Agent sysServices bitmask. Default 79 (the Windows default).
  -NoFirewall     Configure SNMP but create no firewall rule at all.
  -Help           Show this help and exit.

PROOF OF SUCCESS (nothing below is assumed):
  the SNMP feature/capability install is checked with Get-Service (not assumed from an
  exit code), the service must reach Running, every registry value is READ BACK from the
  registry and compared, UDP 161 must actually be bound, and only then is the scoped
  inbound rule created. No registry value is written if the service does not exist.

EXAMPLES:
  snmp-register -Community 4Wp2xR9nQ -Managers 10.20.0.5
  snmp-register -Community 4Wp2xR9nQ -Managers 10.20.0.5,10.20.0.6 -Trap 10.20.0.9 -Location 'DC1 rack 12'
  $env:YC_SNMP_COMMUNITY='4Wp2xR9nQ'; snmp-register -Managers 10.20.0.5
  snmp-register -Help

EXIT CODES:
  0   SNMP running, configured, verified by readback, and scoped in the firewall
  1   generic failure
  2   usage error (no -Managers, no -Community, or a refused community)
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  5   not running as Administrator
  7   the SNMP service exists but did not reach Running
  11  the SNMP feature/capability could not be installed - no SNMP service on this host
  13  the registry does not read back the values that were written
  14  the service is Running but nothing is listening on UDP 161

Log: C:\Scripts\snmp-register.log   (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

# ------------------------------------------------------------------------------------
# Validate BEFORE touching the machine. Manual validation, not [Parameter(Mandatory)],
# because an interactive prompt under cloud-init/SYSTEM hangs the deployment forever.
# ------------------------------------------------------------------------------------
if(-not $Community -and $env:YC_SNMP_COMMUNITY){
  $Community = [string]$env:YC_SNMP_COMMUNITY
  Write-YcLog 'community taken from the YC_SNMP_COMMUNITY environment variable (it is not on the command line - good)'
}
if(-not $Community){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 'no community string was supplied. Pass -Community, or set YC_SNMP_COMMUNITY. It used to default to "public"; it does not any more. Nothing was configured.' 'ERROR'
}
$weak = @('public','private','community','snmp','default')
if($weak -contains $Community.ToLowerInvariant()){
  Exit-Yc 2 ('REFUSED: the community string you supplied is one of the universally scanned defaults (' + ($weak -join ', ') + '). Windows SNMP has no authentication beyond this string. Choose a long random value. Nothing was configured.') 'ERROR'
}
if($Community.Length -lt 8){
  Write-YcLog 'the community string is shorter than 8 characters. It is the ONLY credential SNMP v1/v2c has, and it crosses the wire in cleartext.' 'WARN'
}
$Mgrs = @()
if($Managers){
  foreach($m in $Managers){
    foreach($p in ([string]$m -split ',')){
      $t = $p.Trim()
      if($t){ $Mgrs += $t }
    }
  }
}
if($Mgrs.Count -eq 0){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 '-Managers is REQUIRED. An empty PermittedManagers list means "accept SNMP from ANY host", which is how this command used to ship. Nothing was configured.' 'ERROR'
}
foreach($m in $Mgrs){
  if($m -eq '0.0.0.0' -or $m -eq '*' -or $m -eq 'any' -or $m -eq '::'){
    Exit-Yc 2 ('REFUSED: -Managers contains "' + $m + '", which is the same as opening SNMP to every host. Name the manager addresses explicitly. Nothing was configured.') 'ERROR'
  }
}
if($SysServices -lt 0 -or $SysServices -gt 127){ Exit-Yc 2 ('-SysServices must be 0-127 (got ' + $SysServices + ')') 'ERROR' }
$TrapComm = $Community
if($TrapCommunity){ $TrapComm = $TrapCommunity }

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
Write-YcLog ('managers: ' + ($Mgrs -join ', ') + ' (the community string is deliberately not logged)')

# ------------------------------------------------------------------------------------
# 1. Make the SNMP service exist. Server FEATURE first, client CAPABILITY second.
#    Nothing below runs unless Get-Service SNMP returns a service afterwards.
# ------------------------------------------------------------------------------------
function Test-YcSnmpPresent{
  $s = $null
  try{ $s = Get-Service -Name 'SNMP' -ErrorAction SilentlyContinue }catch{ $s = $null }
  return [bool]$s
}

if(Test-YcSnmpPresent){
  Write-YcLog 'the SNMP service is already present - skipping the feature/capability install'
}else{
  $installed = $false
  $tried     = @()

  # --- Server path: Install-WindowsFeature SNMP-Service (Server 2016 through 2025) ---
  if(Get-Command -Name 'Install-WindowsFeature' -ErrorAction SilentlyContinue){
    $featAvailable = $false
    try{
      $f = Get-WindowsFeature -Name 'SNMP-Service' -ErrorAction Stop
      if($f){ $featAvailable = $true }
    }catch{
      Write-YcLog ('Get-WindowsFeature SNMP-Service failed: ' + $_.Exception.Message) 'WARN'
    }
    if($featAvailable){
      $tried += 'Install-WindowsFeature SNMP-Service'
      try{
        $r = Install-WindowsFeature -Name 'SNMP-Service' -IncludeManagementTools -ErrorAction Stop
        Write-YcLog ('Install-WindowsFeature SNMP-Service -> Success=' + $r.Success + ' ExitCode=' + $r.ExitCode + ' RestartNeeded=' + $r.RestartNeeded)
        if($r.RestartNeeded -and [string]$r.RestartNeeded -ne 'No'){ Write-YcLog 'Windows reports a restart is needed to finish the SNMP feature install' 'WARN' }
      }catch{
        Write-YcLog ('Install-WindowsFeature SNMP-Service FAILED: ' + $_.Exception.Message) 'WARN'
      }
      # The WMI provider is a separate sub-feature and is optional for polling.
      try{
        $wf = Get-WindowsFeature -Name 'SNMP-WMI-Provider' -ErrorAction SilentlyContinue
        if($wf -and -not $wf.Installed){
          $r2 = Install-WindowsFeature -Name 'SNMP-WMI-Provider' -ErrorAction Stop
          Write-YcLog ('Install-WindowsFeature SNMP-WMI-Provider -> Success=' + $r2.Success)
        }
      }catch{
        Write-YcLog ('SNMP-WMI-Provider not installed (optional): ' + $_.Exception.Message) 'WARN'
      }
      if(Test-YcSnmpPresent){ $installed = $true; Write-YcLog 'SNMP installed via the Server feature path (Install-WindowsFeature SNMP-Service)' 'OK' }
    }else{
      Write-YcLog 'this OS does not offer the SNMP-Service Windows feature - trying the Features on Demand capability path'
    }
  }else{
    Write-YcLog 'Install-WindowsFeature is not available (client OS) - using the Features on Demand capability path'
  }

  # --- Capability path: Windows 10/11 and Server images that only expose the capability.
  #     The legacy `dism /online /enable-feature /featurename:SNMP` the old script ran is
  #     NOT a real feature name and always fails with 0x800f080c - it is gone.
  if(-not $installed){
    foreach($cap in @('SNMP.Client~~~~0.0.1.0','WMI-SNMP-Provider.Client~~~~0.0.1.0')){
      $tried += ('Add-WindowsCapability ' + $cap)
      try{
        $state = $null
        try{ $state = Get-WindowsCapability -Online -Name $cap -ErrorAction Stop }catch{}
        if($state -and [string]$state.State -eq 'Installed'){
          Write-YcLog ('capability already installed: ' + $cap)
          continue
        }
        $rc = Add-WindowsCapability -Online -Name $cap -ErrorAction Stop
        Write-YcLog ('Add-WindowsCapability ' + $cap + ' -> Online=' + $rc.Online + ' RestartNeeded=' + $rc.RestartNeeded) 'OK'
        if($rc.RestartNeeded){ Write-YcLog ('a restart is needed to finish ' + $cap) 'WARN' }
      }catch{
        # SNMP.Client is the load-bearing one; the WMI provider is optional.
        $lvl = 'ERROR'
        if($cap -like 'WMI-SNMP*'){ $lvl = 'WARN' }
        Write-YcLog ('Add-WindowsCapability ' + $cap + ' FAILED: ' + $_.Exception.Message + '. On an offline or WSUS-restricted host a Features on Demand source (-Source) or internet access is required.') $lvl
      }
    }
    if(Test-YcSnmpPresent){ $installed = $true; Write-YcLog 'SNMP installed via the Features on Demand capability path' 'OK' }
  }

  if(-not $installed -and -not (Test-YcSnmpPresent)){
    Exit-Yc 11 ('the SNMP service does NOT exist after trying: ' + ($tried -join '; ') + '. NO registry value was written and NO firewall rule was created - the old script wrote SNMP configuration under a service that was not there and printed success. Install the SNMP feature/capability (a Features on Demand source may be required on an offline host) and re-run.') 'ERROR'
  }
}

# ------------------------------------------------------------------------------------
# 2. Configure. Only reached when the SNMP service really exists.
# ------------------------------------------------------------------------------------
$P = 'HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters'
try{
  foreach($sub in @('ValidCommunities','PermittedManagers','RFC1156Agent')){
    $full = Join-Path $P $sub
    if(-not (Test-Path -LiteralPath $full)){ New-Item -Path $full -Force -ErrorAction Stop | Out-Null }
  }
}catch{
  Exit-Yc 1 ('could not create the SNMP parameter keys under ' + $P + ': ' + $_.Exception.Message) 'ERROR'
}

# ValidCommunities: rewrite the whole set so an old 'public' entry from a previous run of
# THIS SCRIPT is removed instead of being left behind next to the new one.
try{
  $vcPath = Join-Path $P 'ValidCommunities'
  $existingVc = @()
  $props = Get-ItemProperty -LiteralPath $vcPath -ErrorAction SilentlyContinue
  if($props){
    foreach($n in ($props.PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' })){ $existingVc += $n.Name }
  }
  foreach($old in $existingVc){
    if($old -ne $Community){
      Remove-ItemProperty -LiteralPath $vcPath -Name $old -Force -ErrorAction Stop
      Write-YcLog ('removed a pre-existing community entry (name not logged) from ValidCommunities') 'WARN'
    }
  }
  New-ItemProperty -LiteralPath $vcPath -Name $Community -Value 4 -PropertyType DWord -Force -ErrorAction Stop | Out-Null
  Write-YcLog 'community written as READ ONLY (rights value 4)' 'OK'
}catch{
  Exit-Yc 1 ('could not write ValidCommunities: ' + $_.Exception.Message) 'ERROR'
}

# PermittedManagers: rewrite the WHOLE subkey every run, so shrinking the list works.
try{
  $pmPath = Join-Path $P 'PermittedManagers'
  $props = Get-ItemProperty -LiteralPath $pmPath -ErrorAction SilentlyContinue
  if($props){
    foreach($n in ($props.PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' })){
      Remove-ItemProperty -LiteralPath $pmPath -Name $n.Name -Force -ErrorAction Stop
    }
  }
  $i = 1
  foreach($m in $Mgrs){
    New-ItemProperty -LiteralPath $pmPath -Name ([string]$i) -Value $m -PropertyType String -Force -ErrorAction Stop | Out-Null
    $i++
  }
  Write-YcLog ('PermittedManagers set to ' + ($Mgrs -join ', ') + ' (' + $Mgrs.Count + ' entr' + $(if($Mgrs.Count -eq 1){'y'}else{'ies'}) + ') - an EMPTY list here would mean ANY HOST') 'OK'
}catch{
  Exit-Yc 1 ('could not write PermittedManagers: ' + $_.Exception.Message) 'ERROR'
}

try{
  $agentPath = Join-Path $P 'RFC1156Agent'
  if($Location){ New-ItemProperty -LiteralPath $agentPath -Name 'sysLocation' -Value $Location -PropertyType String -Force -ErrorAction Stop | Out-Null }
  if($Contact) { New-ItemProperty -LiteralPath $agentPath -Name 'sysContact'  -Value $Contact  -PropertyType String -Force -ErrorAction Stop | Out-Null }
  New-ItemProperty -LiteralPath $agentPath -Name 'sysServices' -Value $SysServices -PropertyType DWord -Force -ErrorAction Stop | Out-Null
}catch{
  Exit-Yc 1 ('could not write RFC1156Agent: ' + $_.Exception.Message) 'ERROR'
}

if($Trap){
  try{
    $tPath = Join-Path (Join-Path $P 'TrapConfiguration') $TrapComm
    if(-not (Test-Path -LiteralPath $tPath)){ New-Item -Path $tPath -Force -ErrorAction Stop | Out-Null }
    New-ItemProperty -LiteralPath $tPath -Name '1' -Value $Trap -PropertyType String -Force -ErrorAction Stop | Out-Null
    Write-YcLog ('trap destination set: ' + $Trap) 'OK'
  }catch{
    Exit-Yc 1 ('could not write TrapConfiguration: ' + $_.Exception.Message) 'ERROR'
  }
}

# ------------------------------------------------------------------------------------
# 3. Start the service and PROVE it, before anything is opened in the firewall.
# ------------------------------------------------------------------------------------
try{ Set-Service -Name 'SNMP' -StartupType Automatic -ErrorAction Stop }
catch{ Write-YcLog ('could not set SNMP to Automatic start: ' + $_.Exception.Message) 'WARN' }
try{ Restart-Service -Name 'SNMP' -Force -ErrorAction Stop; Write-YcLog 'SNMP service restarted to load the new configuration' }
catch{ Write-YcLog ('could not restart SNMP: ' + $_.Exception.Message) 'WARN' }

if(-not (Assert-YcService -Name 'SNMP' -TimeoutSec 90 -StartIfStopped -Because 'nothing is monitored if the agent is not running')){
  Exit-Yc 7 'the SNMP service is not Running. No firewall rule was created.' 'ERROR'
}

# ------------------------------------------------------------------------------------
# 4. READ BACK. The old script wrote with -EA SilentlyContinue and verified nothing.
# ------------------------------------------------------------------------------------
$bad = @()
try{
  $vc = Get-ItemProperty -LiteralPath (Join-Path $P 'ValidCommunities') -ErrorAction Stop
  $rights = $null
  if($vc.PSObject.Properties[$Community]){ $rights = [int]$vc.$Community }
  if($rights -ne 4){ $bad += ('ValidCommunities: the community is not present as READ ONLY (rights read back: ' + $rights + ')') }
  else{ Write-YcLog '  verified: the community is registered READ ONLY (4)' }

  $pm = Get-ItemProperty -LiteralPath (Join-Path $P 'PermittedManagers') -ErrorAction Stop
  $seen = @()
  foreach($n in ($pm.PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' })){ $seen += [string]$n.Value }
  if($seen.Count -eq 0){ $bad += 'PermittedManagers is EMPTY after being written - that would accept SNMP from ANY host' }
  foreach($m in $Mgrs){ if($seen -notcontains $m){ $bad += ('PermittedManagers is missing ' + $m) } }
  foreach($s in $seen){ if($Mgrs -notcontains $s){ $bad += ('PermittedManagers contains an unexpected entry: ' + $s) } }
  if($seen.Count -gt 0){ Write-YcLog ('  verified: PermittedManagers = ' + ($seen -join ', ')) }

  if($Trap){
    $tp = Get-ItemProperty -LiteralPath (Join-Path (Join-Path $P 'TrapConfiguration') $TrapComm) -ErrorAction Stop
    if([string]$tp.'1' -ne $Trap){ $bad += ('TrapConfiguration does not read back ' + $Trap) }
    else{ Write-YcLog ('  verified: trap destination ' + $Trap) }
  }
}catch{
  $bad += ('registry readback failed: ' + $_.Exception.Message)
}
if($bad.Count -gt 0){
  Exit-Yc 13 ('the SNMP configuration does NOT read back correctly: ' + ($bad -join '; ') + '. NO firewall rule was created.') 'ERROR'
}

# UDP 161 must actually be bound, otherwise the rule would open a port nothing serves.
$bound = $false
for($i=0; $i -lt 10; $i++){
  try{
    $u = @(Get-NetUDPEndpoint -LocalPort 161 -ErrorAction SilentlyContinue)
    if($u.Count -gt 0){ $bound = $true; break }
  }catch{}
  Start-Sleep -Seconds 2
}
if($bound){ Write-YcLog 'the SNMP agent is bound to UDP 161' 'OK' }
else{
  Exit-Yc 14 'the SNMP service is Running but nothing is bound to UDP 161 - polling would time out. NO firewall rule was created.' 'ERROR'
}

# ------------------------------------------------------------------------------------
# 5. Firewall LAST, SCOPED, and converged on every run.
# ------------------------------------------------------------------------------------
if($NoFirewall){
  Write-YcLog '-NoFirewall: no firewall rule was created or changed. SNMP will only answer hosts your existing rules already permit.'
}else{
  $rn = 'SNMP 161 UDP'
  try{
    $existingRule = Get-NetFirewallRule -DisplayName $rn -ErrorAction SilentlyContinue
    if($existingRule){
      Remove-NetFirewallRule -DisplayName $rn -ErrorAction Stop
      Write-YcLog ('removed the previous "' + $rn + '" rule (the old version of this script created it unscoped, on every profile, open to the world)') 'WARN'
    }
    New-NetFirewallRule -DisplayName $rn -Direction Inbound -Action Allow -Protocol UDP `
                        -LocalPort 161 -RemoteAddress $Mgrs -Profile Any -ErrorAction Stop | Out-Null
    Write-YcLog ('inbound allow UDP 161 scoped to ' + ($Mgrs -join ',') + ' ONLY (rule "' + $rn + '")') 'OK'
  }catch{
    Exit-Yc 1 ('SNMP is configured and running but the SCOPED firewall rule could not be created: ' + $_.Exception.Message + '. Do not leave an unscoped rule in its place.') 'ERROR'
  }

  if($Trap){
    $rno = 'SNMP Trap 162 UDP'
    try{
      $existingO = Get-NetFirewallRule -DisplayName $rno -ErrorAction SilentlyContinue
      if($existingO){ Remove-NetFirewallRule -DisplayName $rno -ErrorAction Stop }
      New-NetFirewallRule -DisplayName $rno -Direction Outbound -Action Allow -Protocol UDP `
                          -RemotePort 162 -RemoteAddress $Trap -Profile Any -ErrorAction Stop | Out-Null
      Write-YcLog ('outbound allow UDP 162 scoped to ' + $Trap + ' (rule "' + $rno + '")') 'OK'
    }catch{
      Write-YcLog ('could not create the outbound trap rule: ' + $_.Exception.Message) 'WARN'
    }
  }
}

Exit-Yc 0 ('SNMP is Running, READ ONLY, and answers ONLY ' + ($Mgrs -join ', ') + $(if($Trap){'; traps to ' + $Trap}else{''}) + '. Remember: this is v1/v2c - the community crosses the wire in cleartext, so keep UDP 161 on the management network only.') 'OK'
