@echo off
rem transfer-s3 [-Profile <name>] [-Path <file|folder>] [-Key <k>] [-Direction Upload|Download]
rem             [-Recurse] [-Prefix <p>] [-StorageClass <c>] [-Retries <n>] [-PartSizeMB <n>]
rem             [-Checksum] [-DeleteSourceOnSuccess] [-List] [-Engine auto|builtin|module] [-WhatIf] [-Help]
rem Upload/download to the S3-compatible endpoint stored by set-s3config. Multipart above 5 GB,
rem retries with backoff, and every transfer PROVED by an independent HEAD of the object afterwards.
rem Logs to C:\Scripts\transfer-s3.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Transfer-S3.ps1" %*
exit /b %ERRORLEVEL%
