<#
  Set-LocalWsus.ps1 - point this machine at the YallaCloud local update server, or put it
  back on Microsoft. One script, four verbs, nothing to remember.

      set-local-wsus -Status        what am I pointed at right now?
      set-local-wsus -Test          can I actually reach the local server?
      set-local-wsus -Install       use the local server
      set-local-wsus -Uninstall     go back to Microsoft Update

  WHY: every VM that patches from Microsoft pulls the same gigabytes over the same link.
  Pointed at ycwsus01 they pull it once, from inside.

  THE FALLBACK IS A TASK, NOT A SETTING. -Install registers YC-WsusGuard, which tests the
  server daily and puts this machine back on Microsoft Update after two consecutive failures.
  -NoFallback skips it; -Uninstall removes it. Why it has to be done that way:

  READ THIS BEFORE YOU USE IT - WINDOWS ITSELF HAS NO AUTOMATIC FALLBACK.
  Windows does not "try WSUS and then try Microsoft". Once a machine is pointed at a WSUS
  server, that server IS the source: if it is unreachable, the scan FAILS (0x8024401C /
  0x80244022) and the machine silently stops patching. It does not quietly go to Microsoft.
  That is a Windows behaviour, not a gap in this script, and it is why:
    - -Install REFUSES on a server it cannot reach (use -Force only if you know why),
    - -Status exits 1 on the dangerous state (configured but unreachable),
    - going back is ONE command, and that command is the fallback.

  Windows Server 2016-2025, PowerShell 5.1, ASCII only.
#>
param(
  [switch]$Install,
  [switch]$Uninstall,
  [switch]$Status,
  [switch]$Test,
  [string]$Server = '93.177.125.166',
  [int]$Port      = 8530,
  [switch]$Force,
  [switch]$NoFallback,   # -Install: do NOT register the guard that reverts to Microsoft
  [switch]$GuardRun,     # internal: what the YC-WsusGuard task calls. Not for people.
  [switch]$Help
)

. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'set-local-wsus'
$ErrorActionPreference = 'Continue'

if($Help -or -not ($Install -or $Uninstall -or $Status -or $Test -or $GuardRun)){
@"
set-local-wsus  -  use the YallaCloud local update server (ycwsus01) instead of Microsoft.

USAGE:
  set-local-wsus -Status                     what this machine is pointed at, and is it healthy
  set-local-wsus -Test                       can this machine reach the local server (changes nothing)
  set-local-wsus -Install                    point this machine at the local server
  set-local-wsus -Uninstall                  put it back on Microsoft Update
  set-local-wsus -Install -Server 10.0.0.5   a different server (default $Server)
  set-local-wsus -Install -Port 8531         a different port (default 8530)
  set-local-wsus -Install -NoFallback        do NOT register the automatic revert (read below)
  set-local-wsus -Help

PARAMETERS:
  -Install     Point Windows Update at the local server. Runs -Test first and REFUSES if the
               server does not answer, because a machine pointed at an unreachable update
               server stops patching WITHOUT SAYING SO.
               Saves the current settings first, so -Uninstall can put them back exactly.
  -Uninstall   Remove the local-server policy and go back to Microsoft Update. THIS IS THE
               FALLBACK. Safe to run on a machine that was never configured.
  -Status      Print what is configured, whether the server answers, and when this machine
               last successfully scanned. Changes nothing.
  -Test        Reachability only: TCP to the port, then the WSUS web service. Changes nothing.
  -Server      Update server IP or hostname. Default $Server (ycwsus01).
  -Port        8530 for HTTP (default), 8531 for HTTPS.
  -Force       With -Install: configure even though the server did not answer. You are
               choosing to stop this machine patching until the server is back.
  -NoFallback  With -Install: do not register the YC-WsusGuard task. Without the guard this
               machine will NOT revert on its own if the server goes away - it just stops
               patching, silently. Only use this if something else watches the machine.

EXAMPLES:
  set-local-wsus -Status                     start here: what is it pointed at, and is that healthy
  set-local-wsus -Test                       can this machine reach ycwsus01 at all
  set-local-wsus -Install                    use the local server, and register the revert guard
  set-local-wsus -Install -Force             configure ahead of the server being up
  set-local-wsus -Install -NoFallback        no guard - only if something else watches this machine
  set-local-wsus -Uninstall                  back to Microsoft Update, and remove the guard

WINDOWS HAS NO AUTOMATIC FALLBACK - SO ONE IS MADE, NOT CONFIGURED:
  -Install registers a daily task, YC-WsusGuard, which tests the server. After TWO consecutive
  failures it runs -Uninstall for you and this machine goes back to Microsoft Update, so it
  keeps patching instead of sitting silently unpatched. Two rather than one, because a single
  failed test is usually a reboot, and flapping between sources is worse than either. The guard
  is removed by -Uninstall, and skipped by -NoFallback. That task IS the fallback. The rest of
  this section is why it has to work that way:

  Windows does not try the local server and then Microsoft. Once pointed at it, that server
  IS the source. If it goes away, scans fail and patching silently stops - so -Status exits 1
  on that state, and 'set-local-wsus -Uninstall' is how you go back. One command.

EXIT CODES:
  0  did what you asked / configured and healthy
  1  -Status: configured but the server does NOT answer (patching is silently dead)
     -Test:   the server does not answer
  2  refused - bad arguments
  3  something failed part-way; the log says which step
  5  not running as Administrator
  6  -Install: this machine already uses ANOTHER update server (often a company Group Policy).
     Left exactly as it is - a human decides. -Force replaces it.
  7  -Install: the local server did not answer. Nothing was changed; this machine stays on
     Microsoft Update and keeps patching. -Force configures it anyway.

THE REVERSE PLAN (keep it simple):
  automatic   YC-WsusGuard, daily: if the local server does not answer twice in a row, OR
              this machine has not completed an update check for 8 days while pointed at it,
              it goes back to Microsoft Update by itself and says so (vm.wsus.failed).
  one VM      set-local-wsus -Uninstall
  all VMs     on the Salt master:  salt -G 'os:Windows' cmd.run 'C:\Scripts\Set-LocalWsus.ps1 -Uninstall' shell=powershell
  new VMs     a deployment only switches when the local server answers - stop the WSUS
              service and every new VM stays on Microsoft; existing ones revert via the guard.
  back again  fix-deploy -Only wsus   (or set-local-wsus -Install) once the server is healthy.

LOG:  C:\Scripts\set-local-wsus.log        UNDO: C:\Scripts\set-local-wsus.undo.json
"@ | Write-Host
  Exit-Yc 0
}

$picked = @($Install,$Uninstall,$Status,$Test | Where-Object { $_ }).Count
if($picked -gt 1){ Exit-Yc 2 'Pick ONE of -Install, -Uninstall, -Status, -Test.' 'ERROR' }
if($Port -lt 1 -or $Port -gt 65535){ Exit-Yc 2 ("-Port $Port is not a port.") 'ERROR' }

if(-not (Get-Command Get-YcRegValueOrNull -EA SilentlyContinue)){
  function Get-YcRegValueOrNull{
    param([string]$Path,[string]$Name)
    try{ (Get-ItemProperty -Path $Path -Name $Name -EA Stop).$Name }catch{ $null }
  }
}

$WU     = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
$AU     = "$WU\AU"
$UNDO   = 'C:\Scripts\set-local-wsus.undo.json'
$MUID   = '7971f918-a847-4430-9279-4a52d1efe18d'   # the Microsoft Update service id
$BaseUrl= 'http://' + $Server + ':' + $Port
if($Port -eq 8531){ $BaseUrl = 'https://' + $Server + ':' + $Port }

# ---------------------------------------------------------------- reachability
function Test-YcWsus {
  param([string]$Url,[string]$Target,[int]$Tcp)
  $r = [ordered]@{ tcp = $false; http = $false; ms = $null; detail = '' }
  try {
    $c = New-Object Net.Sockets.TcpClient
    $ia = $c.BeginConnect($Target,$Tcp,$null,$null)
    $r.tcp = $ia.AsyncWaitHandle.WaitOne(5000,$false) -and $c.Connected
    $c.Close()
  } catch { $r.detail = $_.Exception.Message }
  if(-not $r.tcp){ $r.detail = "TCP $Tcp did not open"; return $r }
  # The client web service is what a real Windows Update scan talks to, so it is the only
  # test worth trusting - an open port proves a listener, not a working WSUS.
  try {
    Set-YcTls | Out-Null
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $resp = Invoke-WebRequest -Uri ($Url + '/ClientWebService/client.asmx') -UseBasicParsing -TimeoutSec 15
    $sw.Stop()
    $r.http = ($resp.StatusCode -eq 200)
    $r.ms   = [int]$sw.ElapsedMilliseconds
    if(-not $r.http){ $r.detail = 'HTTP ' + $resp.StatusCode }
  } catch { $r.detail = 'web service: ' + $_.Exception.Message }
  return $r
}

function Get-YcWsusState {
  [ordered]@{
    WUServer       = Get-YcRegValueOrNull -Path $WU -Name 'WUServer'
    WUStatusServer = Get-YcRegValueOrNull -Path $WU -Name 'WUStatusServer'
    UseWUServer    = Get-YcRegValueOrNull -Path $AU -Name 'UseWUServer'
    AUOptions      = Get-YcRegValueOrNull -Path $AU -Name 'AUOptions'
    NoAutoUpdate   = Get-YcRegValueOrNull -Path $AU -Name 'NoAutoUpdate'
  }
}

function Get-YcLastScan {
  $p = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\Results\Detect'
  Get-YcRegValueOrNull -Path $p -Name 'LastSuccessTime'
}

# The last SUCCESSFUL update check, UTC, or $null. The COM answer works on 2016-2025; the
# registry value is gone on newer builds and is only a fallback.
function Get-YcLastScanUtc {
  try {
    $d = (New-Object -ComObject Microsoft.Update.AutoUpdate).Results.LastSearchSuccessDate
    if ($d -and ([datetime]$d).Year -gt 2000) { return ([datetime]$d) }
  } catch {}
  try { $r = Get-YcLastScan; if ($r) { return [datetime]::SpecifyKind([datetime]$r, 'Utc') } } catch {}
  return $null
}

# Pure: is the machine already pointed at an update server that is NOT ours?
function Test-YcForeignWsus {
  param([string]$Current, [string]$OurHost)
  if (-not $Current) { return $false }
  $h = ''
  try { $h = ([uri]$Current).Host } catch { $h = ($Current -replace '^\w+://','' -replace '[:/].*$','') }
  return ($h -and ($h -ne $OurHost))
}

# Pure: what the daily guard decides. 'ok' | 'down' (server not answering) | 'stale' (it answers,
# but this machine has not completed an update check for $MaxDays since it was pointed at it -
# the server is up and the machine is still not getting updates, which is worse than down).
function Get-YcGuardVerdict {
  param([bool]$Answers, $LastScanUtc, $ConfiguredUtc, [datetime]$NowUtc, [int]$MaxDays = 8, [double]$UptimeHours = 999)
  if (-not $Answers) { return 'down' }
  # A machine that was switched off for days has an old last-check for an innocent reason: give
  # it a day of uptime to check in before calling it stale.
  if ($UptimeHours -lt 24) { return 'ok' }
  if ($ConfiguredUtc -and (($NowUtc - [datetime]$ConfiguredUtc).TotalDays -ge $MaxDays)) {
    if ((-not $LastScanUtc) -or (($NowUtc - [datetime]$LastScanUtc).TotalDays -ge $MaxDays)) { return 'stale' }
  }
  return 'ok'
}

function Restart-YcWu {
  # A policy change is not seen until the service restarts, and a scan is not attempted until
  # something asks for one. Doing neither is the classic "I set it and nothing happened".
  try { Stop-Service wuauserv -Force -EA Stop; Start-Service wuauserv -EA Stop; Write-YcLog 'wuauserv restarted.' 'OK' }
  catch { Write-YcLog ('could not restart wuauserv: ' + $_.Exception.Message) 'WARN' }
  try { (New-Object -ComObject Microsoft.Update.AutoUpdate).DetectNow(); Write-YcLog 'scan requested.' 'OK' }
  catch {
    try { & "$env:SystemRoot\System32\UsoClient.exe" StartScan 2>&1 | Out-Null; Write-YcLog 'scan requested (UsoClient).' 'OK' }
    catch { Write-YcLog 'could not request a scan; it will happen on the normal schedule.' 'WARN' }
  }
}

# ---------------------------------------------------------------- TEST
# ------------------------------------------------------------------------------------------
# THE FALLBACK, and why it is a scheduled task rather than a setting.
#
# "Use WSUS, fall back to Microsoft" is not a thing Windows does. Once WUServer is set, that
# server IS the source: if it stops answering, the scan fails with 0x8024401C / 0x80244022 and
# the machine SILENTLY STOPS PATCHING. There is no registry value that says "and if that fails,
# try Microsoft" - people look for one, and the absence of it is why machines sit unpatched for
# months behind a WSUS box somebody decommissioned.
#
# So the fallback is made, not configured: a daily task tests the server, and after two
# CONSECUTIVE failures it runs the ordinary -Uninstall and the machine goes back to Microsoft
# Update. Two rather than one, because a single failed test is usually a reboot or a blip, and
# flapping between sources is worse than either source.
#
# It reuses -Uninstall rather than reimplementing the revert: one revert path, already tested.
# ------------------------------------------------------------------------------------------
$GuardTask  = 'YC-WsusGuard'
$GuardState = 'C:\Scripts\.wsus-guard-fails'
$GuardLimit = 2

function Register-YcWsusGuard {
  param([string]$Url)
  $me = $PSCommandPath
  if(-not $me){ $me = 'C:\Scripts\Set-LocalWsus.ps1' }
  $arg = '-NoProfile -ExecutionPolicy Bypass -File "' + $me + '" -GuardRun'
  # PROVE THE SERVER ANSWERS BEFORE CREATING THE TASK. A guard registered against a server that
  # is not actually serving leaves the host carrying the artefact of a working setup with nothing
  # behind it - which is exactly what makes a failure look like a success in a spot check.
  if(-not (Assert-YcHttp -Uri $Url -TimeoutSec 20)){
    Write-YcLog ('not registering the fallback guard: ' + $Url + ' did not answer just now. Re-run -Install once it does.') 'WARN'
    return $false
  }
  try {
    $a = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arg
    # RepetitionDuration is explicit: Server 2016 rejects a repeating -Once trigger without one.
    $t = New-ScheduledTaskTrigger -Once -At ((Get-Date).Date.AddHours(6).AddMinutes(20)) `
           -RepetitionInterval (New-TimeSpan -Hours 24) -RepetitionDuration (New-TimeSpan -Days 3650)
    Register-ScheduledTask -TaskName $GuardTask -Action $a -Trigger $t -User 'SYSTEM' -RunLevel Highest -Force -ErrorAction Stop | Out-Null
    if(-not (Get-ScheduledTask -TaskName $GuardTask -ErrorAction SilentlyContinue)){ throw 'not present after creating it' }
    Write-YcLog ('fallback guard registered: task "' + $GuardTask + '" tests the server daily and reverts this machine to Microsoft Update after ' + $GuardLimit + ' consecutive failures.') 'OK'
    return $true
  } catch {
    Write-YcLog ('could not register the fallback guard "' + $GuardTask + '": ' + $_.Exception.Message + ' - this machine will NOT revert on its own if the server goes away.') 'WARN'
    return $false
  }
}

function Unregister-YcWsusGuard {
  try {
    if(Get-ScheduledTask -TaskName $GuardTask -ErrorAction SilentlyContinue){
      Unregister-ScheduledTask -TaskName $GuardTask -Confirm:$false -ErrorAction Stop
      Write-YcLog ('fallback guard "' + $GuardTask + '" removed') 'OK'
    }
  } catch { Write-YcLog ('could not remove the guard task: ' + $_.Exception.Message) 'WARN' }
  Remove-Item -LiteralPath $GuardState -Force -ErrorAction SilentlyContinue
}

if($GuardRun){
  $s = Get-YcWsusState
  if(-not $s.WUServer){ $script:YcMsSent = $true; Unregister-YcWsusGuard; Exit-Yc 0 'not pointed at a local server any more - guard removed.' 'OK' }
  # Test the server this machine is ACTUALLY pointed at, not the script's default.
  $gHost = $Server; $gPort = $Port
  try { $u = [uri]$s.WUServer; $gHost = $u.Host; if($u.Port -gt 0){ $gPort = $u.Port } } catch {}
  $t = Test-YcWsus -Url $s.WUServer -Target $gHost -Tcp $gPort
  $cfgUtc = $null
  try { if(Test-Path -LiteralPath $UNDO){ $cfgUtc = (Get-Item -LiteralPath $UNDO).LastWriteTimeUtc } } catch {}
  $last = Get-YcLastScanUtc
  $upH = 999
  try { $upH = ((Get-Date) - (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime).TotalHours } catch {}
  $v = Get-YcGuardVerdict -Answers ([bool]$t.http) -LastScanUtc $last -ConfiguredUtc $cfgUtc -NowUtc ([datetime]::UtcNow) -UptimeHours $upH
  if($v -eq 'ok'){
    Remove-Item -LiteralPath $GuardState -Force -ErrorAction SilentlyContinue
    $script:YcMsSent = $true    # a healthy daily check is not news: no webhook, no ntfy
    Exit-Yc 0 ('guard: ' + $s.WUServer + ' answers and the last update check succeeded ' + $(if($last){ ([datetime]$last).ToString('yyyy-MM-dd HH:mm') + ' UTC' } else { '(not yet - just configured)' }) + ' - nothing to do.') 'OK'
  }
  if($v -eq 'stale'){
    # The server is up but this machine is not getting updates from it: no point waiting a
    # second day - revert now.
    $n = $GuardLimit
    Write-YcLog ('guard: ' + $s.WUServer + ' answers, but this machine has not completed an update check for 8 days (last success ' + $(if($last){ ([datetime]$last).ToString('yyyy-MM-dd HH:mm') + ' UTC' } else { 'never' }) + '). It is not fetching updates from it.') 'ERROR'
  } else {
    $n = 0
    try { if(Test-Path $GuardState){ $n = [int](Get-Content -LiteralPath $GuardState -Raw).Trim() } } catch {}
    $n++
    try { Set-Content -LiteralPath $GuardState -Value ([string]$n) -Encoding ascii } catch {}
    Write-YcLog ('guard: ' + $s.WUServer + ' did not answer (' + $t.detail + '). Consecutive failures: ' + [string]$n + ' of ' + [string]$GuardLimit) 'WARN'
    if($n -lt $GuardLimit){ $script:YcMsSent = $true; Exit-Yc 1 'guard: one more failure and this machine goes back to Microsoft Update.' 'WARN' }
  }
  Write-YcLog ('guard: reverting to Microsoft Update so this machine keeps patching (' + $v + ').') 'ERROR'
  $me = $PSCommandPath; if(-not $me){ $me = 'C:\Scripts\Set-LocalWsus.ps1' }
  try {
    $p = Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$me,'-Uninstall') -Wait -PassThru -NoNewWindow
    # Compared, not just logged: a revert that half-worked leaves the machine pointed at a dead
    # server, which is the state this guard exists to get it out of.
    if($p.ExitCode -ne 0){
      Exit-Yc 3 ('guard: -Uninstall returned ' + [string]$p.ExitCode + ' - this machine may STILL be pointed at ' + $s.WUServer + ' and not patching. Run  set-local-wsus -Uninstall  by hand and check -Status.') 'ERROR'
    }
    Write-YcLog 'guard: -Uninstall returned 0' 'OK'
  } catch { Exit-Yc 3 ('guard: could not run -Uninstall: ' + $_.Exception.Message) 'ERROR' }
  Remove-Item -LiteralPath $GuardState -Force -ErrorAction SilentlyContinue
  Exit-Yc 1 ('guard: this machine was pointed at ' + $s.WUServer + ', ' + $(if($v -eq 'stale'){ 'it was not getting updates from it' } else { 'that server stopped answering' }) + ', and it has been put back on Microsoft Update so it keeps patching. Point it back with: set-local-wsus -Install') 'WARN'
}

if($Test){
  Write-YcLog ('testing ' + $BaseUrl)
  $t = Test-YcWsus -Url $BaseUrl -Target $Server -Tcp $Port
  Write-Host ''
  Write-Host ('  local update server : ' + $BaseUrl)
  Write-Host ('  TCP ' + $Port + '            : ' + $(if($t.tcp){'OPEN'}else{'CLOSED'}))
  Write-Host ('  WSUS web service    : ' + $(if($t.http){'ANSWERS (' + $t.ms + ' ms)'}else{'NO'}))
  if($t.detail){ Write-Host ('  detail              : ' + $t.detail) }
  Write-Host ''
  if($t.http){ Exit-Yc 0 'Local update server is reachable.' 'OK' }
  Exit-Yc 1 ('Local update server NOT reachable - ' + $t.detail + '. Check the firewall allows this machine to ' + $Server + ':' + $Port + '.') 'ERROR'
}

# ---------------------------------------------------------------- STATUS
if($Status){
  $s = Get-YcWsusState
  $on = ($s.UseWUServer -eq 1 -and $s.WUServer)
  $t  = $null
  if($on){
    $u = [uri]$s.WUServer
    $t = Test-YcWsus -Url $s.WUServer -Target $u.Host -Tcp $u.Port
  }
  Write-Host ''
  Write-Host ('  source          : ' + $(if($on){'LOCAL - ' + $s.WUServer}else{'MICROSOFT UPDATE (default)'}))
  if($on){
    Write-Host ('  server answers  : ' + $(if($t.http){'YES (' + $t.ms + ' ms)'}else{'NO - ' + $t.detail}))
  }
  Write-Host ('  UseWUServer     : ' + $(if($null -eq $s.UseWUServer){'(not set)'}else{$s.UseWUServer}))
  $scan = Get-YcLastScan
  Write-Host ('  last good scan  : ' + $(if($scan){$scan}else{'never / not recorded'}))
  Write-Host ('  undo file       : ' + $(if(Test-Path $UNDO){'present'}else{'none'}))
  Write-Host ''
  if(-not $on){ Exit-Yc 0 'Pointed at Microsoft Update.' 'OK' }
  if($t.http){ Exit-Yc 0 ('Pointed at the local update server and it answers: ' + $s.WUServer) 'OK' }
  # The dangerous state: configured, unreachable, patching silently dead.
  Exit-Yc 1 ('POINTED AT ' + $s.WUServer + ' AND IT DOES NOT ANSWER - this machine is not patching. Run: set-local-wsus -Uninstall') 'ERROR'
}

# ---- everything below changes the machine ----
if(-not (Test-YcAdmin)){ Exit-Yc 5 'Run this from an elevated prompt (Run as Administrator).' 'ERROR' }

# ---------------------------------------------------------------- INSTALL
if($Install){
  Write-YcLog ('install: ' + $BaseUrl)
  # A machine that already uses ANOTHER update server - usually a customer's own WSUS set by
  # their Group Policy - is not ours to repoint. Replacing it silently would take it off the
  # patches its owner approves. Left as it is; a human decides.
  $cur = Get-YcWsusState
  if((Test-YcForeignWsus -Current ([string]$cur.WUServer) -OurHost $Server) -and -not $Force){
    Exit-Yc 6 ('LEFT AS IT IS: this machine already uses another update server, ' + $cur.WUServer + ' (often a company Group Policy). It was not changed. To replace it on purpose: set-local-wsus -Install -Force') 'WARN'
  }
  $t = Test-YcWsus -Url $BaseUrl -Target $Server -Tcp $Port
  if(-not $t.http){
    if(-not $Force){
      Exit-Yc 7 ('NOT CHANGED: ' + $BaseUrl + ' did not answer (' + $t.detail + '). This machine stays on ' +
                 'Microsoft Update and keeps patching. A machine pointed at an unreachable update server ' +
                 'STOPS PATCHING and says nothing, which is why this refuses. -Force configures it anyway.') 'WARN'
    }
    Write-YcLog ('-Force: configuring anyway, but ' + $BaseUrl + ' did not answer - this machine will not patch until it does.') 'WARN'
  } else {
    Write-YcLog ('server answers in ' + $t.ms + ' ms.') 'OK'
  }

  # Undo BEFORE the change, never after - if the change goes wrong there is still a way back.
  try {
    (Get-YcWsusState | ConvertTo-Json -Depth 4) | Set-Content -Path $UNDO -Encoding ascii
    Write-YcLog ('previous settings saved to ' + $UNDO) 'OK'
  } catch { Write-YcLog ('could not write the undo file: ' + $_.Exception.Message) 'WARN' }

  $fail = 0
  try {
    foreach($k in @($WU,$AU)){ if(-not (Test-Path $k)){ New-Item -Path $k -Force | Out-Null } }
    New-ItemProperty $WU -Name 'WUServer'       -Value $BaseUrl -PropertyType String -Force | Out-Null
    New-ItemProperty $WU -Name 'WUStatusServer' -Value $BaseUrl -PropertyType String -Force | Out-Null
    # 0 = do NOT cut this machine off from Microsoft's internet endpoints. The local server is
    # the source of WHAT to install; content and Microsoft Update products can still come from
    # Microsoft. Setting this to 1 is what people mean by "it broke everything".
    New-ItemProperty $WU -Name 'DoNotConnectToWindowsUpdateInternetLocations' -Value 0 -PropertyType DWord -Force | Out-Null
    # Without these four, 1809+ "dual scan" can quietly send some update classes to Microsoft
    # anyway, which is exactly the bandwidth we are trying not to spend.
    foreach($c in 'QualityUpdates','FeatureUpdates','DriverUpdates','OtherUpdates'){
      New-ItemProperty $WU -Name ('SetPolicyDrivenUpdateSourceFor' + $c) -Value 1 -PropertyType DWord -Force | Out-Null
    }
    New-ItemProperty $AU -Name 'UseWUServer'  -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty $AU -Name 'NoAutoUpdate' -Value 0 -PropertyType DWord -Force | Out-Null
    # 3 = download automatically, notify to install. Servers do not get surprise reboots.
    New-ItemProperty $AU -Name 'AUOptions'    -Value 3 -PropertyType DWord -Force | Out-Null
    Write-YcLog ('policy written: WUServer=' + $BaseUrl) 'OK'
  } catch { $fail++; Write-YcLog ('writing the policy failed: ' + $_.Exception.Message) 'ERROR' }

  # SQL Server CUs and other Microsoft products arrive through Microsoft Update, which is a
  # separate opt-in from Windows Update. Without this, "sql update" finds nothing.
  try {
    $sm = New-Object -ComObject Microsoft.Update.ServiceManager
    $sm.AddService2($MUID,7,'') | Out-Null
    Write-YcLog 'Microsoft Update registered (SQL Server and other MS products).' 'OK'
  } catch { Write-YcLog ('could not register Microsoft Update: ' + $_.Exception.Message) 'WARN' }

  Restart-YcWu
  if($fail){ Exit-Yc 3 ($fail.ToString() + ' step(s) failed - see the log.') 'ERROR' }
  if($NoFallback){ Write-YcLog '-NoFallback: no guard registered. If this server goes away, this machine stops patching and says nothing.' 'WARN' }
  else { [void](Register-YcWsusGuard -Url $BaseUrl) }
  Exit-Yc 0 ('Now using the local update server ' + $BaseUrl + '. Go back any time with: set-local-wsus -Uninstall') 'OK'
}

# ---------------------------------------------------------------- UNINSTALL
if($Uninstall){
  Write-YcLog 'uninstall: back to Microsoft Update'
  $before = Get-YcWsusState
  if(-not $before.WUServer -and $null -eq $before.UseWUServer){
    Write-YcLog 'nothing to undo - this machine was already on Microsoft Update.' 'OK'
  }
  $fail = 0
  try {
    # Remove the values rather than zeroing them: absent is the real Windows default, and a
    # leftover UseWUServer=0 confuses the next person reading the registry.
    foreach($n in 'WUServer','WUStatusServer','DoNotConnectToWindowsUpdateInternetLocations',
                  'SetPolicyDrivenUpdateSourceForQualityUpdates','SetPolicyDrivenUpdateSourceForFeatureUpdates',
                  'SetPolicyDrivenUpdateSourceForDriverUpdates','SetPolicyDrivenUpdateSourceForOtherUpdates'){
      Remove-ItemProperty -Path $WU -Name $n -Force -EA SilentlyContinue
    }
    foreach($n in 'UseWUServer','AUOptions','NoAutoUpdate'){
      Remove-ItemProperty -Path $AU -Name $n -Force -EA SilentlyContinue
    }
    Write-YcLog 'local-server policy removed.' 'OK'
  } catch { $fail++; Write-YcLog ('removing the policy failed: ' + $_.Exception.Message) 'ERROR' }

  if(Test-Path $UNDO){
    try { Remove-Item $UNDO -Force -EA Stop; Write-YcLog 'undo file cleared.' 'OK' } catch {}
  }
  Restart-YcWu
  Unregister-YcWsusGuard
  if($fail){ Exit-Yc 3 'Partly reverted - see the log.' 'ERROR' }
  Exit-Yc 0 'Back on Microsoft Update.' 'OK'
}

Exit-Yc 2 'Nothing to do.' 'ERROR'
