@echo off
rem backup-sql [-SqlInstance <inst>] [-Database <db>[,<db>]] [-Type Full|Diff|Log] [-Directory <path>]
rem            [-Compress] [-Checksum] [-Verify] [-CopyOnly] [-RetentionHours <n>] [-S3Profile <name>]
rem            [-S3Prefix <p>] [-DeleteLocalAfterUpload] [-SqlLogin <l>] [-SqlPasswordFile <path>]
rem            [-WhatIf] [-Help]
rem Verified SQL Server backups: WITH CHECKSUM, then RESTORE VERIFYONLY, then optional offload to S3.
rem Uses Ola Hallengren's dbo.DatabaseBackup when install-sql deployed it, native T-SQL BACKUP if not.
rem Logs to C:\Scripts\backup-sql.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Backup-Sql.ps1" %*
exit /b %ERRORLEVEL%
