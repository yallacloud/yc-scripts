param(
  [string]$ConfigPath = 'C:\ProgramData\YallaCloud\sqltemplate\yc-build.json',
  [switch]$Report,
  [switch]$SelfCheck,
  [switch]$Help
)
# =====================================================================================
# Yc-VmBuild.ps1 - the build state machine, from DOTNET to DONE.
# PowerShell 5.1 only. ASCII only.
#
# WHY THIS IS IN THE PAYLOAD AND NOT IN THE USERDATA
#   CloudStack caps user data at 32 KB base64 and the whole state machine was eating it -
#   31,688 of 32,768, three per cent left. Worse, a bug in any of it could only be fixed
#   by re-registering user data on every cloud and redeploying, because a VM's user data
#   is frozen the moment it boots. Here, a fix is a payload update.
#   What CANNOT move, and stays in the user data: the gateway repair, the wait for
#   internet, and the payload fetch. Those three are the ones that must work BEFORE a
#   payload exists to contain them.
#
# WHY IT IS COPIED TO ProgramData BEFORE IT RUNS
#   Update-YcScripts wipes C:\Scripts. A build that survives three reboots cannot have
#   its own worker deleted underneath it half way through, and it must not silently
#   change version mid-build either. The bootstrap copies this file once, and the copy is
#   what the scheduled task runs for the rest of the build.
#
# THE STATE MACHINE. Each step writes the NEXT state before it acts, so a reboot, a crash
# or a power cut resumes in the right place and never repeats a finished step.
#   DOTNET -> SQL -> SQLLIC -> SSMS -> LIC -> NOTIFY -> DONE
#   NAME+ done   NAME- failed   NAME~ skipped (by profile, or because a step it needs failed)
#
# A FAILED STEP DOES NOT END THE BUILD (2.47.9, P1-P4). It is recorded with its own reason (the
# first [ERROR] of its script's run, from last-<tag>.json), the steps that need it are skipped and
# reported vm.<stage>.skipped, the rest still runs - a SQL failure still ends with a licensed
# Windows - and NOTIFY sends FAILED BUILD with "<step>: <reason>". Every step's start, end, result,
# reason and reboots are kept in yc-build.journal.json; the hand-over (P13) is built from it.
#
# GVLK TRAP: after an Evaluation -> Standard edition change Windows sits on Volume:GVLK
# with status Notification and LOOKS activated. LicenseStatus alone is not proof. LIC
# re-checks up to 3 passes and only reports success on Volume:MAK AND Licensed.
#
# EXIT CODES  0 finished or nothing to do   1 a step failed   2 usage   5 not elevated
# Log: the build log named in the config, plus Application event 1600, source YALLACLOUD.
# =====================================================================================
$ErrorActionPreference = 'Continue'

$HelpText = @"
yc-vmbuild - run the VM build state machine from DOTNET to DONE.

  yc-vmbuild                     resume the build described by yc-build.json
  yc-vmbuild -Report             print the config and the state. Changes nothing.
  yc-vmbuild -ConfigPath <file>  use a different config
  yc-vmbuild -SelfCheck          assertions only, no admin, changes nothing

You do not normally run this by hand. The user data bootstrap writes the config, copies
this script to C:\ProgramData\YallaCloud\sqltemplate and registers the scheduled task
that calls it. Running it again after a finished build is harmless - the state is DONE
and it exits immediately.
"@
if ($Help) { Write-Output $HelpText; exit 0 }

# -------------------------------------------------------------------------------------
# The pure decisions, so -SelfCheck can exercise them with no SQL, no network, no admin.
# -------------------------------------------------------------------------------------
function Get-YcNextState {
  <# The order is fixed; this only answers "what comes after X". Kept pure so the skip
     logic below can walk forward without duplicating the sequence in five places. #>
  param([string]$State)
  # UPDPRE and UPDPOST are in the order ALWAYS. Whether either runs is a profile question,
  # not a sequence question - a state that is sometimes absent from the list is a state
  # whose skip cannot be recorded.
  $order = @('UPDPRE','DOTNET','SQL','SQLLIC','SSMS','LIC','UPDPOST','NOTIFY','DONE')
  $i = [array]::IndexOf($order, $State)
  if ($i -lt 0 -or $i -ge ($order.Count - 1)) { return 'DONE' }
  return $order[$i + 1]
}

function Test-YcStateWanted {
  <# Does the profile want this state? The clamps live in the bootstrap, so by the time
     the config reaches here the flags are already coherent. #>
  param([string]$State, $Cfg)
  switch ($State) {
    'UPDPRE'  { return ([bool]$Cfg.InstallWindowsUpdates -and $Cfg.WindowsUpdateWhen -eq 'Before') }
    'UPDPOST' { return ([bool]$Cfg.InstallWindowsUpdates -and $Cfg.WindowsUpdateWhen -ne 'Before') }
    'DOTNET' { return [bool]$Cfg.InstallDotNet }
    'SQL'    { return [bool]$Cfg.InstallSql }
    # Express is licensed BY BEING EXPRESS. There is no key, and activate-sql refuses it
    # with exit 6 - which would fail the build on a machine that is completely correct.
    # The bootstrap clamps this too; it is guarded twice because a hand-written
    # yc-build.json is the exact case the clamp upstream does not cover.
    'SQLLIC' { return ([bool]$Cfg.InstallSql -and [bool]$Cfg.LicenseSql -and
                       ([string]$Cfg.SqlEdition -notmatch '(?i)^express$')) }
    'SSMS'   { return [bool]$Cfg.InstallSsms }
    'LIC'    { return [bool]$Cfg.LicenseWindows }
    default  { return $true }
  }
}

function Get-YcSqlArgs {
  <# The install-sql command line. Pure, because getting -Maintenance or the retention
     wrong is silent: you get a SQL Server with no backups and a green exit code. #>
  param($Cfg, [string]$PwFile, [string]$ChadminFile = '')
  # -Edition is passed for EXPRESS ONLY, and that is not an inconsistency.
  # Every licensed edition is installed as Evaluation and moved with activate-sql, because
  # setup.exe /ACTION=editionupgrade is the supported path and it needs the key, not the
  # installer. EXPRESS IS A DIFFERENT PRODUCT, not an edition of this media: there is no
  # upgrade path to it from anything, activate-sql refuses it by design (exit 6), and it
  # has to come off its own package at install time or not at all. So Express is the one
  # case where the edition is an INSTALL argument. Proven 2026-09-13 on VCT22E\SQLEXPRESS.
  $isExpress = ([string]$Cfg.SqlEdition -match '(?i)^express$')
  $a = 'C:\Scripts\install-sql.cmd -Version ' + $Cfg.SqlVersion +
       ' -InstanceName ' + $Cfg.InstanceName +
       $(if ($isExpress) { ' -Edition Express' } else { '' }) +
       ' -SaPasswordFile ' + $PwFile + ' -NoReboot' +
       ' -Maintenance ' + $(if ($Cfg.ConfigureSqlBackup) { 'on' } else { 'off' }) +
       ' -Patch ' + $(if ($Cfg.InstallSqlUpdates) { 'on' } else { 'off' })
  # P2 (2.47.6): the team's shared chadmin password is known at build time - give it to install-sql
  # as the S4U fallback for the maintenance tasks, by FILE, never on the command line.
  if ($ChadminFile) { $a += ' -ChadminPasswordFile ' + $ChadminFile }
  if ($Cfg.ConfigureSqlBackup) {
    $a += ' -BackupDir "' + $Cfg.BackupDir + '"' +
          ' -RetainFullDays ' + $Cfg.RetainFullDays +
          ' -RetainDiffDays ' + $Cfg.RetainDiffDays +
          ' -RetainLogDays '  + $Cfg.RetainLogDays +
          ' -MonthlyDir "' + $Cfg.MonthlyDir + '" -MonthlyKeep ' + $Cfg.MonthlyKeep
  }
  return $a
}

function Test-YcWinPermanent {
  <# WHY /xpr AND NOT /dlv (TSBMFDDB02, 2026-10-24)

     That VM was built WIN-LIC with an EMPTY $WinKey. The LIC step took its "no Windows key"
     branch, logged the truth, and then advanced the state machine - which records LIC+ for
     whatever step it is leaving. So the build reported LIC+ on a machine sitting at
     "Notification mode", channel Volume:GVLK, activation error 0x8007232B. The steps string is
     what a human and the ERP both read as "was this licensed", and it said yes.

     /dlv is not proof: after an Evaluation -> Standard edition change Windows sits on
     Volume:GVLK with status Notification and several of its fields look healthy. /xpr answers
     one question and answers it plainly - "The machine is permanently activated." is the only
     string that means licensed. Anything else (notification mode, a grace period with a date,
     a volume activation expiry) is not.

     Pure, so -SelfCheck can prove every one of those strings without a VM. #>
  param([string]$XprText)
  if (-not $XprText) { return $false }
  return ([bool]($XprText -match '(?i)permanently activated'))
}
function Get-YcWinLicenceLine {
  # One line a human reads without knowing the channel vocabulary. The reason code is included
  # ONLY when it is not licensed, because a code next to "licensed" reads like a problem.
  param([hashtable]$W, [bool]$Wanted, [bool]$HasKey)
  if (-not $Wanted) { return 'windows : left on its trial channel by profile' }
  if (-not $HasKey) { return 'windows : NOT LICENSED - the profile asks for a licence but $WinKey was empty' }
  if (Test-YcWinPermanent $W['xpr']) {
    return ('windows : licensed, ' + $W['channel'] + ', key ...' + $W['partial'])
  }
  $r = ''
  if ($W['reason']) { $r = ', activation error ' + $W['reason'] }
  return ('windows : NOT LICENSED - ' + $(if ($W['status']) { $W['status'] } else { 'unknown status' }) +
          ', ' + $(if ($W['channel']) { $W['channel'] } else { 'unknown channel' }) + $r)
}
function Get-YcBuildLines {
  <# The final notification an operator actually reads - THE hand-over (P13, 2.47.9): a plain-English
     line, then [ server ] (where it is and how to reach it), [ logins ] (owner rule 2026-11-05: the
     passwords as they are), [ what was added ] (one row per step: result, version, how long it took,
     failed rows first) and [ trace ]. Pure: every machine fact comes in as a parameter, so -SelfCheck
     asserts the layout. Yc-Event.ps1 puts "deployment : <id>  <link>" above the first line. #>
  param([string]$Say, [hashtable]$Server = @{}, [System.Collections.IDictionary]$Logins = $null,
        [string[]]$Rows = @(), [string]$Took = '', [string]$StepStr = '', [string]$PayloadVer = '', [string]$LogPath = '')
  if (-not $Server) { $Server = @{} }
  $ln = @($Say, '', '[ server ]')
  if ($Server['vmName']) {
    $ln += ('vm      : ' + $Server['vmName'] + $(if ($Server['tenant']) { ' (tenant ' + $Server['tenant'] + ')' } else { '' }) +
            $(if ($Server['uuid']) { '   uuid ' + $Server['uuid'] } else { '' }))
  }
  $ln += ('host    : ' + $Server['host'])
  $ln += ('ip      : ' + $(if ($Server['ipLine']) { $Server['ipLine'] } else { 'unknown' }))
  $ln += ('os      : ' + $Server['os'])
  if ($Server['portal']) { $ln += ('portal  : ' + $Server['portal']) }
  if ($Server['access']) { $ln += ('access  : ' + $Server['access']) }
  if ($Logins -and $Logins.Count) {
    $ln += @('', '[ logins ]')
    foreach ($k in @($Logins.Keys)) { $ln += ($k.PadRight(13) + ' : ' + [string]$Logins[$k]) }
  }
  if (@($Rows).Count) { $ln += @('', '[ what was added ]  (step - result - version - took)') + @($Rows) }
  $ln += @('', '[ trace ]')
  if ($Took) { $ln += ('took    : ' + $Took) }
  if ($StepStr) { $ln += ('steps   : ' + $StepStr) }
  $ln += @(('by      : Yc-VmBuild, payload ' + $(if ($PayloadVer) { $PayloadVer } else { 'unknown' })),
           ('log     : ' + $(if ($LogPath) { $LogPath } else { 'C:\Scripts\yc-deploy.log' })))
  return $ln
}
function Get-YcBuildTitle([bool]$Ok, [string]$BuildProfile) {
  # E3: the same words as the Linux kits ("OK BUILD Linux"): what, which OS, which profile.
  return ($(if ($Ok) { 'OK' } else { 'FAILED' }) + ' BUILD Windows ' + $BuildProfile)
}
# ---- 2.47.9: the step journal, the hand-over rows and the skip rules (all pure) -------------------
# One name per step on every channel: the stage is the area the step's own script reports as
# (_yc-lib Get-YcMsArea), so the portal's stage table puts started / ok / failed / skipped on one row.
$script:YcStepMeta = [ordered]@{
  UPDPRE  = @{ stage = 'winupdate';      label = 'Updates';      tag = 'winupdate' }
  DOTNET  = @{ stage = 'install-dotnet'; label = '.NET 4.8';     tag = 'install-dotnet' }
  SQL     = @{ stage = 'sql';            label = 'SQL Server';   tag = 'install-sql' }
  SQLLIC  = @{ stage = 'sqllicense';     label = 'SQL licence';  tag = 'activate-sql' }
  SSMS    = @{ stage = 'install-ssms';   label = 'SSMS';         tag = 'install-ssms' }
  LIC     = @{ stage = 'license';        label = 'Windows lic.'; tag = 'activate-windows' }
  UPDPOST = @{ stage = 'winupdate';      label = 'Updates';      tag = 'winupdate' }
}
function Get-YcSkipReason {
  <# Why a state does not run, or '' when it does (P3/P4). A failed step stops only what NEEDS it:
     no .NET -> no SQL, no SQL -> no SQL licence and no SSMS. Windows licensing and updates never
     depend on SQL - a SQL failure still ends with a licensed Windows. #>
  param([string]$State, $Cfg, [hashtable]$Results = @{})
  if (-not $Results) { $Results = @{} }
  if (-not (Test-YcStateWanted $State $Cfg)) { return ('by profile ' + [string]$Cfg.Profile) }
  if (@('SQL','SQLLIC','SSMS') -contains $State -and $Results['DOTNET'] -eq 'failed') { return 'not run - build stopped at DOTNET' }
  if (@('SQLLIC','SSMS') -contains $State -and $Results['SQL'] -eq 'failed') { return 'not run - build stopped at SQL' }
  return ''
}
function Get-YcFailText {
  # Pure: "<step>: <reason>" for every failed step, in build order (P2).
  param([System.Collections.IDictionary]$Journal)
  $f = @()
  foreach ($k in @($script:YcStepMeta.Keys)) {
    if ($Journal -and $Journal.Contains($k) -and [string]$Journal[$k]['result'] -eq 'failed') {
      $f += ($k + ': ' + $(if ($Journal[$k]['detail']) { [string]$Journal[$k]['detail'] } else { 'failed' }))
    }
  }
  return ($f -join '; ')
}
function Test-YcPrivateIp([string]$Ip) {
  return [bool]($Ip -match '^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.)')
}
function Get-YcIpInfo {
  <# Pure: which address is public and which private. On a shared public network the public address
     is on the NIC; behind a virtual router the NIC is private and the metadata knows the public one. #>
  param([string]$NicIp, [string]$PublicIp = '', [string]$Gateway = '')
  $pub = ''; $prv = ''
  if ($NicIp -and -not (Test-YcPrivateIp $NicIp)) { $pub = $NicIp }
  else { $prv = $NicIp; if ($PublicIp -and $PublicIp -ne $NicIp) { $pub = $PublicIp } }
  $p = @()
  if ($pub) { $p += ($pub + ' (public)') }
  if ($prv) { $p += ($prv + ' (private)') }
  $t = $(if ($p.Count) { $p -join '  / ' } else { 'unknown' })
  if ($Gateway) { $t += '   gateway ' + $Gateway }
  $acc = $(if ($pub) { $pub } else { $prv })
  return @{ public = $pub; private = $prv; line = $t; access = $(if ($acc) { 'RDP ' + $acc + ':3389   SSH ' + $acc + ':3222' } else { '' }) }
}
function Format-YcTook($Span) {
  # Pure: m:ss, or h:mm:ss from an hour.
  if ($null -eq $Span) { return '' }
  $t = [timespan]$Span
  if ($t.TotalSeconds -lt 0) { return '' }
  if ($t.TotalHours -ge 1) { return ('{0}:{1:00}:{2:00}' -f [int][math]::Floor($t.TotalHours), $t.Minutes, $t.Seconds) }
  return ('{0}:{1:00}' -f [int][math]::Floor($t.TotalMinutes), $t.Seconds)
}
function Get-YcStepTook([System.Collections.IDictionary]$Entry) {
  # Pure: how long a journal entry took (start -> end, reboots included).
  if (-not $Entry -or -not $Entry['start'] -or -not $Entry['end']) { return '' }
  try { return (Format-YcTook ([datetime]$Entry['end'] - [datetime]$Entry['start'])) } catch { return '' }
}
function Get-YcAddedRow([string]$Label, [string]$Result, [string]$Text = '', [string]$Took = '') {
  # Pure: one aligned row of [ what was added ].
  $r = ('{0,-13} {1,-8} {2}' -f $Label, $Result, $Text).TrimEnd()
  if ($Took) { $r += '   ' + $Took }
  return $r
}
function Get-YcSummaryValue([string[]]$Summary, [string]$Key) {
  # Pure: the value of a "Key<pad>: value" line of a script's summary (install-sql's).
  foreach ($l in @($Summary)) { if ([string]$l -match ('^' + [regex]::Escape($Key) + '\s*: (.*)$')) { return $Matches[1].Trim() } }
  return ''
}
function Get-YcDotNetName([int]$Release) {
  if ($Release -ge 533320) { return '4.8.1' }
  if ($Release -ge 528040) { return '4.8' }
  if ($Release -ge 461808) { return '4.7.2' }
  if ($Release -gt 0) { return ('older than 4.7.2 (' + $Release + ')') }
  return 'not found'
}

if ($SelfCheck) {
  $pass = 0; $fail = 0
  function T($n, $c) { if ($c) { Write-Output ('ok   ' + $n); $script:pass++ } else { Write-Output ('FAIL ' + $n); $script:fail++ } }

  T 'DOTNET -> SQL'      ((Get-YcNextState 'DOTNET') -eq 'SQL')
  T 'SQL -> SQLLIC'      ((Get-YcNextState 'SQL')    -eq 'SQLLIC')
  T 'SQLLIC -> SSMS'     ((Get-YcNextState 'SQLLIC') -eq 'SSMS')
  T 'SSMS -> LIC'        ((Get-YcNextState 'SSMS')   -eq 'LIC')
  T 'UPDPRE -> DOTNET'   ((Get-YcNextState 'UPDPRE')  -eq 'DOTNET')
  T 'LIC -> UPDPOST'     ((Get-YcNextState 'LIC')     -eq 'UPDPOST')
  T 'UPDPOST -> NOTIFY'  ((Get-YcNextState 'UPDPOST') -eq 'NOTIFY')
  T 'NOTIFY -> DONE'     ((Get-YcNextState 'NOTIFY') -eq 'DONE')
  T 'DONE stays DONE'    ((Get-YcNextState 'DONE')   -eq 'DONE')
  T 'nonsense -> DONE'   ((Get-YcNextState 'BANANA') -eq 'DONE')

  $updA = [pscustomobject]@{ InstallWindowsUpdates=$true;  WindowsUpdateWhen='After' }
  $updB = [pscustomobject]@{ InstallWindowsUpdates=$true;  WindowsUpdateWhen='Before' }
  $updN = [pscustomobject]@{ InstallWindowsUpdates=$false; WindowsUpdateWhen='After' }
  T 'updates OFF skips both'  ((-not (Test-YcStateWanted 'UPDPRE' $updN)) -and (-not (Test-YcStateWanted 'UPDPOST' $updN)))
  T 'After runs only UPDPOST' ((-not (Test-YcStateWanted 'UPDPRE' $updA)) -and (Test-YcStateWanted 'UPDPOST' $updA))
  T 'Before runs only UPDPRE' ((Test-YcStateWanted 'UPDPRE' $updB) -and (-not (Test-YcStateWanted 'UPDPOST' $updB)))

  $full = [pscustomobject]@{ InstallDotNet=$true; InstallSql=$true; LicenseSql=$true; InstallSsms=$true; LicenseWindows=$true }
  $win  = [pscustomobject]@{ InstallDotNet=$false; InstallSql=$false; LicenseSql=$false; InstallSsms=$false; LicenseWindows=$true }
  $eval = [pscustomobject]@{ InstallDotNet=$true; InstallSql=$true; LicenseSql=$false; InstallSsms=$true; LicenseWindows=$false }
  T 'SQL-FULL wants SQLLIC'      (Test-YcStateWanted 'SQLLIC' $full)
  T 'WIN-LIC skips SQL'          (-not (Test-YcStateWanted 'SQL' $win))
  T 'WIN-LIC skips DOTNET'       (-not (Test-YcStateWanted 'DOTNET' $win))
  T 'WIN-LIC still wants LIC'    (Test-YcStateWanted 'LIC' $win)
  T 'SQL-EVAL skips SQLLIC'      (-not (Test-YcStateWanted 'SQLLIC' $eval))
  T 'SQL-EVAL still installs SQL'(Test-YcStateWanted 'SQL' $eval)
  T 'SQL-EVAL skips windows lic' (-not (Test-YcStateWanted 'LIC' $eval))
  T 'NOTIFY is never skipped'    (Test-YcStateWanted 'NOTIFY' $win)

  $c = [pscustomobject]@{ SqlVersion='2019'; InstanceName='MSSQLSERVER'; ConfigureSqlBackup=$true
                          BackupDir='D:\bak'; RetainFullDays=35; RetainDiffDays=14; RetainLogDays=14
                          MonthlyDir='D:\mon'; MonthlyKeep=12 }
  $a = Get-YcSqlArgs -Cfg $c -PwFile 'C:\x.txt'
  T 'sql args: maintenance on'   ($a -match '-Maintenance on')
  T 'sql args: retention passed' ($a -match '-RetainFullDays 35' -and $a -match '-RetainLogDays 14')
  T 'sql args: monthly passed'   ($a -match '-MonthlyDir "D:\\mon" -MonthlyKeep 12')
  T 'sql args: instance passed'  ($a -match '-InstanceName MSSQLSERVER')
  T 'sql args: no -Edition for a licensed edition' ($a -notmatch '-Edition')
  $cx = [pscustomobject]@{ SqlVersion='2022'; InstanceName='SQLEXPRESS'; SqlEdition='Express'
                           ConfigureSqlBackup=$true; BackupDir='C:\b'; RetainFullDays=35
                           RetainDiffDays=14; RetainLogDays=14; MonthlyDir='C:\m'; MonthlyKeep=12 }
  $ax = Get-YcSqlArgs -Cfg $cx -PwFile 'C:\x.txt'
  T 'sql args: Express passes -Edition Express' ($ax -match '-Edition Express')
  T 'sql args: Express still gets maintenance'  ($ax -match '-Maintenance on')
  $ex = [pscustomobject]@{ InstallSql=$true; LicenseSql=$true; SqlEdition='Express' }
  T 'SQLLIC never runs on Express'  (-not (Test-YcStateWanted 'SQLLIC' $ex))
  $en = [pscustomobject]@{ InstallSql=$true; LicenseSql=$true; SqlEdition='Web' }
  T 'SQLLIC still runs for Web'     (Test-YcStateWanted 'SQLLIC' $en)
  $c3 = [pscustomobject]@{ SqlVersion='2019'; InstanceName='X'; ConfigureSqlBackup=$false; InstallSqlUpdates=$true }
  T 'sql args: -Patch on'        ((Get-YcSqlArgs -Cfg $c3 -PwFile 'C:\x') -match '-Patch on')
  $c4 = [pscustomobject]@{ SqlVersion='2019'; InstanceName='X'; ConfigureSqlBackup=$false; InstallSqlUpdates=$false }
  T 'sql args: -Patch off'       ((Get-YcSqlArgs -Cfg $c4 -PwFile 'C:\x') -match '-Patch off')
  $c2 = [pscustomobject]@{ SqlVersion='2019'; InstanceName='X'; ConfigureSqlBackup=$false }
  T 'sql args: chadmin fallback by file'  ((Get-YcSqlArgs -Cfg $c -PwFile 'C:\x.txt' -ChadminFile 'C:\c.txt') -match '-ChadminPasswordFile C:\\c\.txt')
  T 'sql args: no chadmin file, no switch' ((Get-YcSqlArgs -Cfg $c -PwFile 'C:\x.txt') -notmatch 'Chadmin')
  $a2 = Get-YcSqlArgs -Cfg $c2 -PwFile 'C:\x.txt'
  T 'backup off: maintenance off'($a2 -match '-Maintenance off')
  T 'backup off: no retention'   ($a2 -notmatch 'Retain')

  Write-Output ''
  # ---------------------------------------------------------------------------------
  # LIC must not be recorded as done on a machine that is not licensed. Every string below is
  # real slmgr output; the 0x8007232B case is TSBMFDDB02, 2026-10-24, which reported LIC+.
  # ---------------------------------------------------------------------------------
  T 'xpr: permanently activated is licensed' (Test-YcWinPermanent 'The machine is permanently activated.')
  T 'xpr: wording and case do not matter'    (Test-YcWinPermanent 'Windows(R), ServerStandard edition: The machine is PERMANENTLY ACTIVATED.')
  T 'xpr: notification mode is NOT licensed' (-not (Test-YcWinPermanent 'Windows is in Notification mode'))
  T 'xpr: a grace period is NOT licensed'    (-not (Test-YcWinPermanent 'Volume activation will expire 1/15/2027 3:00:00 PM'))
  T 'xpr: timebased eval is NOT licensed'    (-not (Test-YcWinPermanent 'Timebased activation will expire 2/2/2027 1:00:00 AM'))
  T 'xpr: empty is NOT licensed'             (-not (Test-YcWinPermanent ''))
  T 'xpr: null is NOT licensed'              (-not (Test-YcWinPermanent $null))

  $wOk  = @{ channel='Volume:MAK';  partial='T6QD2'; status='Licensed';     reason='';           xpr='The machine is permanently activated.' }
  $wBad = @{ channel='Volume:GVLK'; partial='';      status='Notification'; reason='0x8007232B'; xpr='Windows is in Notification mode' }
  T 'licence line: licensed says so'        ((Get-YcWinLicenceLine -W $wOk  -Wanted $true  -HasKey $true)  -match '^windows : licensed, Volume:MAK')
  T 'licence line: licensed shows no code'  ((Get-YcWinLicenceLine -W $wOk  -Wanted $true  -HasKey $true)  -notmatch '0x')
  T 'licence line: unlicensed is loud'      ((Get-YcWinLicenceLine -W $wBad -Wanted $true  -HasKey $true)  -match 'NOT LICENSED')
  T 'licence line: carries the code'        ((Get-YcWinLicenceLine -W $wBad -Wanted $true  -HasKey $true)  -match '0x8007232B')
  T 'licence line: an empty key is named'   ((Get-YcWinLicenceLine -W $wBad -Wanted $true  -HasKey $false) -match 'WinKey was empty')
  T 'licence line: a trial is no failure'   ((Get-YcWinLicenceLine -W $wBad -Wanted $false -HasKey $false) -match 'by profile')

  # ---------------------------------------------------------------------------------
  # 2.47.9 hand-over (P13) and failure flow (P1-P4)
  # ---------------------------------------------------------------------------------
  $srv = @{ vmName = 'sqlwintest01'; tenant = 'admin'; uuid = 'd339eadb-1'; host = 'SQLWINTEST01'; ipLine = '178.23.187.21 (public)   gateway 178.23.187.1'
            os = 'Windows Server 2022 Standard (licensed, Volume:MAK ...QJ6K8)'; portal = 'https://cs.example/#/vm/d339eadb-1'; access = 'RDP 178.23.187.21:3389   SSH 178.23.187.21:3222' }
  $lg = [ordered]@{ 'Administrator' = 'Pw-Admin-1'; 'chadmin' = 'Pw-Ch-2'; 'sa' = 'Pw-Sa-3     (SQL auth)'; 'sql tls' = 'abc123' }
  $rows = @((Get-YcAddedRow 'SQL Server' 'ok' '2019 Standard 15.0.2000.5, MSSQLSERVER' '14:02'), (Get-YcAddedRow 'Updates' 'skipped' '(profile)'))
  $bl = Get-YcBuildLines -Say 'Finished - the server is ready.' -Server $srv -Logins $lg -Rows $rows -Took '52 min (started 15:58:09, finished 16:50:11 IST), reboots 2' `
                         -StepStr 'NET+ SYNC+ SQL+' -PayloadVer '2.47.9' -LogPath 'C:\Scripts\yc-deploy.log'
  $blj = (@($bl) -join '|')
  T 'lines: plain English first'        ($bl[0] -eq 'Finished - the server is ready.')
  T 'lines: four sections in order'     ($blj.IndexOf('[ server ]') -lt $blj.IndexOf('[ logins ]') -and $blj.IndexOf('[ logins ]') -lt $blj.IndexOf('[ what was added ]') -and $blj.IndexOf('[ what was added ]') -lt $blj.IndexOf('[ trace ]'))
  T 'lines: vm + tenant + uuid'         ($blj -match 'vm      : sqlwintest01 \(tenant admin\)   uuid d339eadb-1')
  T 'lines: public ip and gateway'      ($blj -match 'ip      : 178\.23\.187\.21 \(public\)   gateway 178\.23\.187\.1')
  T 'lines: access RDP + SSH'           ($blj -match 'access  : RDP 178\.23\.187\.21:3389   SSH 178\.23\.187\.21:3222')
  T 'lines: os carries the licence'     ($blj -match 'os      : Windows Server 2022 Standard \(licensed')
  T 'lines: logins as they are'         ($blj -match 'Administrator : Pw-Admin-1' -and $blj -match 'chadmin       : Pw-Ch-2' -and $blj -match 'sa            : Pw-Sa-3')
  T 'lines: sql tls thumbprint'         ($blj -match 'sql tls       : abc123')
  T 'lines: a row has its took'         ($blj -match 'SQL Server    ok       2019 Standard 15\.0\.2000\.5, MSSQLSERVER   14:02')
  T 'lines: a skipped row'              ($blj -match 'Updates       skipped  \(profile\)')
  T 'lines: total time and reboots'     ($blj -match 'took    : 52 min \(started .*\), reboots 2')
  T 'lines: payload version is named'   ($blj -match 'by      : Yc-VmBuild, payload 2\.47\.9')
  T 'lines: log is the deploy log'      ($blj -match 'log     : C:\\Scripts\\yc-deploy\.log')
  T 'lines: server lines aligned'       ((@($bl | Select-Object -Skip 3 -First 6 | Where-Object { $_ -notmatch '^[a-z]{2,7} +: ' }).Count) -eq 0)
  $b0 = Get-YcBuildLines -Say 'x' -Server @{ host = 'H'; os = 'o' }
  T 'lines: no logins block when none'  ((@($b0) -join '|') -notmatch '\[ logins \]')
  T 'lines: unknown payload is said'    ((@($b0) -join '|') -match 'payload unknown')
  T 'lines: no vm line without an id'   ((@($b0) -join '|') -notmatch 'vm      :')
  T 'title: OK BUILD Windows <profile>' ((Get-YcBuildTitle -Ok $true -BuildProfile 'WIN-TRIAL') -eq 'OK BUILD Windows WIN-TRIAL')
  T 'title: FAILED BUILD Windows'       ((Get-YcBuildTitle -Ok $false -BuildProfile 'SQL-EVAL') -eq 'FAILED BUILD Windows SQL-EVAL')

  # P3/P4: a failed step stops only what needs it
  $fc = [pscustomobject]@{ Profile = 'SQL-FULL'; InstallDotNet = $true; InstallSql = $true; LicenseSql = $true; InstallSsms = $true; LicenseWindows = $true; SqlEdition = 'Standard' }
  T 'skip: nothing failed, SQLLIC runs'      ((Get-YcSkipReason 'SQLLIC' $fc @{}) -eq '')
  T 'skip: SQL failed -> no SQL licence'     ((Get-YcSkipReason 'SQLLIC' $fc @{ SQL = 'failed' }) -eq 'not run - build stopped at SQL')
  T 'skip: SQL failed -> no SSMS'            ((Get-YcSkipReason 'SSMS' $fc @{ SQL = 'failed' }) -eq 'not run - build stopped at SQL')
  T 'skip: SQL failed -> Windows lic. runs'  ((Get-YcSkipReason 'LIC' $fc @{ SQL = 'failed' }) -eq '')
  T 'skip: DOTNET failed -> no SQL'          ((Get-YcSkipReason 'SQL' $fc @{ DOTNET = 'failed' }) -eq 'not run - build stopped at DOTNET')
  T 'skip: profile wins and names itself'    ((Get-YcSkipReason 'SQL' $win @{ DOTNET = 'failed' }) -eq 'by profile ')
  $jn = [ordered]@{ DOTNET = @{ result = 'ok' }; SQL = @{ result = 'failed'; detail = '-SaPasswordFile is empty: C:\x\.sa-password' }; LIC = @{ result = 'failed'; detail = 'Notification Volume:GVLK 0x8007232B' } }
  T 'fail text: <step>: <reason> in order'   ((Get-YcFailText $jn) -eq 'SQL: -SaPasswordFile is empty: C:\x\.sa-password; LIC: Notification Volume:GVLK 0x8007232B')
  T 'fail text: empty when nothing failed'   ((Get-YcFailText ([ordered]@{ SQL = @{ result = 'ok' } })) -eq '')

  # where the VM is
  $ipP = Get-YcIpInfo -NicIp '178.23.187.21' -PublicIp '' -Gateway '178.23.187.1'
  T 'ip: a public NIC is the public ip'      ($ipP.public -eq '178.23.187.21' -and -not $ipP.private -and $ipP.access -eq 'RDP 178.23.187.21:3389   SSH 178.23.187.21:3222')
  $ipN = Get-YcIpInfo -NicIp '10.1.1.5' -PublicIp '93.177.125.140' -Gateway '10.1.1.254'
  T 'ip: behind a router, both are shown'    ($ipN.line -eq '93.177.125.140 (public)  / 10.1.1.5 (private)   gateway 10.1.1.254' -and $ipN.access -match '^RDP 93\.177\.125\.140:3389')
  T 'ip: 172.16/12 and 100.64/10 are private' ((Test-YcPrivateIp '172.20.0.4') -and (Test-YcPrivateIp '100.100.1.1') -and -not (Test-YcPrivateIp '172.32.0.1'))
  T 'took: m:ss'                             ((Format-YcTook ([timespan]::FromSeconds(842))) -eq '14:02')
  T 'took: h:mm:ss'                          ((Format-YcTook ([timespan]::FromSeconds(3725))) -eq '1:02:05')
  T 'took: from a journal entry'             ((Get-YcStepTook @{ start = '2026-11-05T15:58:09'; end = '2026-11-05T16:12:11' }) -eq '14:02')
  T 'took: unknown end is empty'             ((Get-YcStepTook @{ start = '2026-11-05T15:58:09' }) -eq '')
  T 'summary: value of a key'                ((Get-YcSummaryValue @('Build                 : 15.0.4385.2 (CU28)', 'Maintenance           : on - 4/4 procedures verified') 'Maintenance') -eq 'on - 4/4 procedures verified')
  T 'dotnet: 528449 is 4.8'                  ((Get-YcDotNetName 528449) -eq '4.8')
  T 'dotnet: 533325 is 4.8.1'                ((Get-YcDotNetName 533325) -eq '4.8.1')
  T 'meta: one stage per step'               ($script:YcStepMeta['SQL']['stage'] -eq 'sql' -and $script:YcStepMeta['LIC']['stage'] -eq 'license' -and $script:YcStepMeta['SQLLIC']['tag'] -eq 'activate-sql')

  Write-Output ('SelfCheck: ' + $pass + ' passed, ' + $fail + ' failed')
  if ($fail -gt 0) { exit 1 } else { exit 0 }
}

# -------------------------------------------------------------------------------------
if (-not (Test-Path -LiteralPath $ConfigPath)) { Write-Output ('no config at ' + $ConfigPath); exit 2 }
$Cfg   = (Get-Content -LiteralPath $ConfigPath -Raw) | ConvertFrom-Json
$Base  = Split-Path -Parent $ConfigPath
$Log   = Join-Path $Base 'yc-sqltemplate.log'
$State = Join-Path $Base 'yc-sqltemplate.state'
$Steps = Join-Path $Base 'yc-sqltemplate.steps'
$JFile = Join-Path $Base 'yc-build.journal.json'
$Task  = 'YC-SqlTemplate'
$LastDir = 'C:\ProgramData\YallaCloud\logs'

function L($m){
  Add-Content -Path $Log -Value ('[' + (Get-Date -f 'yyyy-MM-dd HH:mm:ss') + '] ' + $m) -Encoding ascii -EA SilentlyContinue
  try { Write-EventLog -LogName Application -Source YALLACLOUD -EntryType Information -EventId 1600 -Message ('[yc-vmbuild] ' + $m) -EA SilentlyContinue } catch {}
}
function Get-State { if (Test-Path $State) { (Get-Content $State -TotalCount 1).Trim() } else { 'DOTNET' } }
function Add-Step($t){ Add-Content -Path $Steps -Value $t -Encoding ascii }
function Get-Steps { if (Test-Path $Steps) { ((Get-Content $Steps) -join ' ') } else { '' } }
function Set-State($s, $mark = '+'){
  $prev = Get-State
  if ($prev -ne $s) { Add-Step ($prev + $mark) }
  Set-Content -Path $State -Value $s -Encoding ascii; L ('state -> ' + $s)
}

# ---- the step journal (2.47.9): start, end, result, reason and details of every step ---------------
# A state file is a cursor; this is the record the hand-over is built from. Survives every reboot.
function Get-Journal {
  $j = [ordered]@{}
  if (Test-Path -LiteralPath $JFile) {
    try {
      $o = (Get-Content -LiteralPath $JFile -Raw) | ConvertFrom-Json
      foreach ($p in $o.PSObject.Properties) { $e = @{}; foreach ($q in $p.Value.PSObject.Properties) { $e[$q.Name] = $q.Value }; $j[$p.Name] = $e }
    } catch { L ('journal unreadable, starting a new one: ' + $_.Exception.Message) }
  }
  return $j
}
function Save-Journal($j) { try { ([pscustomobject]$j | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $JFile -Encoding ascii } catch { L ('journal not saved: ' + $_.Exception.Message) } }
function Get-Results { $r = @{}; $j = Get-Journal; foreach ($k in @($j.Keys)) { $r[$k] = [string]$j[$k]['result'] }; return $r }
function Step-Event([string]$step, [string]$word, [string]$detail) {
  # ERP + Tech + portal stage table, never the phone: the phone gets the step's own result (its
  # script reports ok / failed itself) and the hand-over at the end.
  $m = $script:YcStepMeta[$step]; if (-not $m) { return }
  $sp = @{ Type = ('vm.' + $m['stage'] + '.' + $word); Extra = $(if ($detail) { $detail } else { $m['label'] + ' ' + $word }); NoNtfy = $true
           Step = (Get-Steps); Field = @('kit=win-builder', ('step=' + $step)) }
  Yc-EventRich $sp
}
function Step-Begin([string]$step, [hashtable]$Extra = @{}) {
  $j = Get-Journal
  if ($j.Contains($step) -and $j[$step]['start']) { return }      # resumed after a reboot: same step, same start
  $e = @{ start = (Get-Date -f s); reboots = 0 }
  foreach ($k in @($Extra.Keys)) { $e[$k] = $Extra[$k] }
  $j[$step] = $e; Save-Journal $j
  Step-Event $step 'started' ''
}
function Step-End([string]$step, [string]$result, [string]$detail = '', [hashtable]$Extra = @{}) {
  $j = Get-Journal
  if (-not $j.Contains($step)) { $j[$step] = @{ start = (Get-Date -f s); reboots = 0 } }
  $j[$step]['end'] = (Get-Date -f s); $j[$step]['result'] = $result; $j[$step]['detail'] = $detail
  foreach ($k in @($Extra.Keys)) { $j[$step][$k] = $Extra[$k] }
  Save-Journal $j
}
function Step-Skip([string]$step, [string]$why) {
  Step-End $step 'skipped' $why
  # one winupdate stage: UPDPRE skipped by profile says nothing, UPDPOST speaks for both
  if ($step -ne 'UPDPRE') { Step-Event $step 'skipped' $why }
}
function Get-StepReason([string]$step, [string]$fallback) {
  <# P1: the step's OWN reason - the first [ERROR] of its run, from the last-<tag>.json its script wrote
     (_yc-lib 2.5.0) - when that run belongs to this step; else the exit code. #>
  $m = $script:YcStepMeta[$step]
  $r = Get-LastResult $m['tag'] $step
  if ($r -and [string]$r.state -eq 'failed' -and [string]$r.reason) { return (([string]$r.reason) -replace '^exit \d+: ','') }
  return $fallback
}
function Get-LastResult([string]$tag, [string]$step) {
  try {
    $f = Join-Path $LastDir ('last-' + $tag + '.json')
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    $r = (Get-Content -LiteralPath $f -Raw) | ConvertFrom-Json
    $j = Get-Journal
    if ($step -and $j.Contains($step) -and $j[$step]['start'] -and ([datetime]$r.time -lt [datetime]$j[$step]['start'])) { return $null }
    return $r
  } catch { return $null }
}
function Restart-Now($next) {
  # Every reboot the build takes is counted: for the step that took it, and in total.
  $cur = Get-State
  $j = Get-Journal
  if ($j.Contains($cur) -and -not $j[$cur]['end']) { $j[$cur]['reboots'] = [int]$j[$cur]['reboots'] + 1; Save-Journal $j }
  $rf = Join-Path $Base 'yc-build.reboots'; $n = 0; try { $n = [int](Get-Content $rf -TotalCount 1 -EA Stop) } catch {}
  Set-Content -Path $rf -Value ([string]($n + 1)) -Encoding ascii
  Set-State $next; L 'restarting'; shutdown /r /t 10 /c "yc-vmbuild"; exit 0
}
function Move-Next([string]$from, [string]$mark = '+') {
  <# Leave $from with its mark and walk every state that does not run - by profile, or because a step
     it needs failed (P3/P4) - recording each as skipped with its reason. Returns the state to run. #>
  $n = Get-YcNextState $from
  Set-State $n $mark
  while ($n -ne 'NOTIFY' -and $n -ne 'DONE') {
    $why = Get-YcSkipReason $n $Cfg (Get-Results)
    if (-not $why) { break }
    if ($n -eq 'SQLLIC' -and $Cfg.InstallSql -and $why -like 'by profile*') { L 'SQL LEFT ON EVALUATION by profile. This box is NOT licensed for production.' }
    if ($n -eq 'LIC' -and $why -like 'by profile*') { L 'WINDOWS LEFT ON ITS TRIAL CHANNEL by profile.' }
    L ($n + ' skipped - ' + $why)
    Step-Skip $n $why
    $m = Get-YcNextState $n
    Set-State $m '~'; $n = $m
  }
  return $n
}
function Send-StepFailed([string]$step, [string]$why) {
  # The step's own script reports its failure (lib run-end event). When no script ran (no key) or the
  # build decided it (Windows not permanently activated), the build reports it, so no stage is left open.
  $r = Get-LastResult $script:YcStepMeta[$step]['tag'] $step
  if (-not $r -or [string]$r.state -ne 'failed') { Step-Event $step 'failed' $why }
}
function Fail([string]$step, [string]$fallback) {
  <# 2.47.9: a failed step no longer ends the build. It is recorded with its own reason (P1), the steps
     that need it are skipped (P4), the rest still runs (P3) and NOTIFY sends FAILED BUILD with
     "<step>: <reason>" (P2). Returns the next state to run. #>
  $why = Get-StepReason $step $fallback
  L ('FAILED at ' + $step + ': ' + $why)
  Step-End $step 'failed' $why
  Send-StepFailed $step $why
  return (Move-Next $step '-')
}

function Yc-EventRich([hashtable]$Splat) {
  # Never fatal. A webhook that is down must not cost a build.
  # Yc-Event.ps1 is called directly rather than through yc-event.cmd because -NtfyLine and
  # -Field are ARRAYS: pushing them through a cmd command string is a quoting accident waiting
  # to happen, and an aligned line full of colons and spaces is exactly the shape that breaks.
  if (-not (Test-Path 'C:\Scripts\Yc-Event.ps1')) { L 'Yc-Event.ps1 not present, skipping'; return }
  try {
    & 'C:\Scripts\Yc-Event.ps1' @Splat *>> $Log
    # The type and title only. The splat carries the logins, and the log is not the place.
    L ('yc-event ' + [string]$Splat['Type'] + ' "' + [string]$Splat['NtfyTitle'] + '" rc=' + $LASTEXITCODE)
  } catch { L ('yc-event failed: ' + $_.Exception.Message) }
}
function Get-WinLic {
  # Not reporting - this is the control flow of LIC. The GVLK trap is decided from it.
  # /xpr is read as well as /dlv because /dlv alone is what let LIC+ be recorded on an
  # unlicensed machine: see Test-YcWinPermanent.
  $d = cscript //nologo C:\Windows\System32\slmgr.vbs /dlv 2>&1 | Out-String
  $ch=''; $pk=''; $st=''; $rs=''
  if ($d -match 'Product Key Channel:\s*(.+)') { $ch = $Matches[1].Trim() }
  if ($d -match 'Partial Product Key:\s*(.+)') { $pk = $Matches[1].Trim() }
  if ($d -match 'License Status:\s*(.+)')      { $st = $Matches[1].Trim() }
  # The code a human can actually look up. 0x8007232B is "DNS name does not exist", which is
  # what an unkeyed GVLK box reports when it tries to find a KMS host that is not there.
  if ($d -match 'Notification Reason:\s*(0x[0-9A-Fa-f]+)') { $rs = $Matches[1].Trim() }
  $xp = ''
  try { $xp = (cscript //nologo C:\Windows\System32\slmgr.vbs /xpr 2>&1 | Out-String).Trim() } catch {}
  return @{ channel=$ch; partial=$pk; status=$st; reason=$rs; xpr=$xp }
}
function Get-EditionId { try { return [string](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name EditionID -EA Stop).EditionID } catch { return '' } }
function Get-OsNow {
  # P11: read fresh, AFTER the edition change. Caption keeps "Evaluation"; EditionID is the truth.
  $c = ''; try { $c = [string](Get-CimInstance Win32_OperatingSystem -EA Stop).Caption } catch {}
  $e = Get-EditionId
  if ($e -and $e -notmatch '(?i)eval') { $c = ($c -replace '(?i)\s+Evaluation\b','') }
  return ($c -replace '^Microsoft ','').Trim()
}
function Get-UninstallVersion([string]$Like) {
  foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')) {
    $hit = @(Get-ItemProperty $k -EA SilentlyContinue | Where-Object { [string]$_.DisplayName -like $Like -and $_.DisplayVersion } | Sort-Object { [string]$_.DisplayVersion } -Descending)
    if ($hit.Count) { return [string]$hit[0].DisplayVersion }
  }
  return ''
}
function Get-SqlInstanceFacts([string]$Inst) {
  $f = @{ id = ''; edition = ''; version = ''; patch = ''; collation = ''; tls = ''; cer = '' }
  try {
    $root = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server'
    $f['id'] = [string](Get-ItemProperty ($root + '\Instance Names\SQL') -Name $Inst -EA Stop).$Inst
    $s = Get-ItemProperty ($root + '\' + $f['id'] + '\Setup') -EA Stop
    $f['edition'] = ([string]$s.Edition -replace ' Edition','' -replace ':.*$','').Trim()
    $f['version'] = [string]$s.Version; $f['patch'] = [string]$s.PatchLevel; $f['collation'] = [string]$s.Collation
    $f['tls'] = [string](Get-ItemProperty ($root + '\' + $f['id'] + '\MSSQLServer\SuperSocketNetLib') -Name Certificate -EA SilentlyContinue).Certificate
  } catch {}
  $c = 'C:\ProgramData\YallaCloud\sql-tls-' + $env:COMPUTERNAME + '.cer'
  if (Test-Path -LiteralPath $c) { $f['cer'] = $c }
  return $f
}
function Get-AgentWord([string]$a, [bool]$on) {
  # The agents run from the builder's own startup tasks; their FINAL result is in agents\<a>.sent.
  $w = ''
  try { $w = ([string](Get-Content -LiteralPath ('C:\ProgramData\YallaCloud\agents\' + $a + '.sent') -Raw -EA Stop)).Trim() } catch {}
  if ($w) { return $w }
  if ($on) { return 'pending' }
  return 'off'
}
function Get-YcBuildIdentity {
  # The same identity the userdata's yc-notify.ps1 shows: SMBIOS uuid (= CloudStack VM uuid on KVM),
  # the CloudStack name + tenant from the Salt master's who-file it cached, and the portal link.
  $id = @{ uuid = ''; vmName = ''; tenant = ''; tenantSource = ''; vmUrl = ''; portal = '' }
  try { $id['uuid'] = ([string](Get-CimInstance Win32_ComputerSystemProduct -ErrorAction Stop).UUID).ToLower() } catch {}
  try {
    $who = [string](Get-Content -LiteralPath (Join-Path $Base 'yc-who.txt') -Raw -ErrorAction Stop)
    if ($who -match '(?m)^tenant=(\S+)') { $id['tenant'] = $Matches[1]; $id['tenantSource'] = 'salt-who' }
    if ($who -match '(?m)^name=(\S+)')   { $id['vmName'] = $Matches[1] }
  } catch {}
  if (-not $id['vmName']) { $id['vmName'] = $env:COMPUTERNAME.ToLower() }
  $u = [string]$Cfg.CloudStackUrl
  if ($u -and $id['uuid']) { $id['portal'] = $u; $id['vmUrl'] = $u.TrimEnd('/') + '/#/vm/' + $id['uuid'] }
  return $id
}
function Get-YcHostFacts {
  $ip = ''; $pub = ''; $gw = ''
  try { $ip = [string](@(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notmatch '^(127\.|169\.254\.)' } | Select-Object -First 1).IPAddress) } catch {}
  try { $gw = [string](@(Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | Sort-Object RouteMetric | Select-Object -First 1).NextHop) } catch {}
  if (-not $gw) { try { $gw = ([string](Get-Content (Join-Path $Base 'yc-gateway.txt') -Raw -EA Stop)).Trim() } catch {} }
  # the public address CloudStack's metadata gave Yc-Event (vm-facts.json), for a NIC behind a router
  try { $pub = [string]((Get-Content 'C:\ProgramData\YallaCloud\vm-facts.json' -Raw -EA Stop | ConvertFrom-Json).publicIp) } catch {}
  return @{ ip = $ip; publicIp = $pub; gateway = $gw; os = (Get-OsNow) }
}
function Get-YcIdFields([hashtable]$Id) {
  # -Field pairs Yc-Event.ps1 maps into cloud{} / vm{} and remembers for later day-2 events.
  return @(('vmName=' + $Id['vmName']), ('vmUuid=' + $Id['uuid']), ('tenant=' + $Id['tenant']), ('tenantSource=' + $Id['tenantSource']),
           ('cloudVmUrl=' + $Id['vmUrl']), ('cloudPortal=' + $Id['portal']), 'kit=win-builder', 'log=C:\Scripts\yc-deploy.log')
}
function Get-YcPayloadVersion {
  try {
    $m = Select-String -Path 'C:\Scripts\yc-payload-version.txt' -Pattern '^payload_version\s*=\s*(\S+)' -ErrorAction Stop |
         Select-Object -First 1
    if ($m) { return $m.Matches[0].Groups[1].Value }
  } catch {}
  return ''
}
function ConvertTo-Ist([datetime]$t) {
  try { return [TimeZoneInfo]::ConvertTimeBySystemTimeZoneId($t, 'India Standard Time').ToString('HH:mm:ss') + ' IST' } catch { return $t.ToString('HH:mm:ss zzz') }
}

$s = Get-State
if ($Report) {
  Write-Output ('state   : ' + $s)
  Write-Output ('steps   : ' + (Get-Steps))
  Write-Output ('profile : ' + $Cfg.Profile)
  foreach ($k in @('InstallDotNet','InstallSql','LicenseSql','InstallSsms','LicenseWindows','ConfigureSqlBackup')) {
    Write-Output ('  ' + $k.PadRight(20) + ' = ' + $Cfg.$k)
  }
  Write-Output ('sql     : ' + $Cfg.SqlVersion + ' ' + $Cfg.SqlEdition + ' instance ' + $Cfg.InstanceName)
  Write-Output ('backup  : ' + $Cfg.BackupDir + '  FULL ' + $Cfg.RetainFullDays + 'd DIFF ' + $Cfg.RetainDiffDays + 'd LOG ' + $Cfg.RetainLogDays + 'd  monthly x' + $Cfg.MonthlyKeep)
  $j = Get-Journal
  foreach ($k in @($j.Keys)) { Write-Output ('journal : ' + $k.PadRight(8) + ' ' + ([string]$j[$k]['result']).PadRight(8) + ' ' + (Get-YcStepTook $j[$k]) + '  ' + [string]$j[$k]['detail']) }
  exit 0
}

L ('=== yc-vmbuild resuming at ' + $s + ' ===')
L ('PROFILE ' + $Cfg.Profile + ' -> dotnet=' + $Cfg.InstallDotNet + ' sql=' + $Cfg.InstallSql +
   ' sqlLicence=' + $Cfg.LicenseSql + ' ssms=' + $Cfg.InstallSsms + ' windowsLicence=' + $Cfg.LicenseWindows +
   ' sqlBackup=' + $Cfg.ConfigureSqlBackup)

# Walk any leading states that do not run, recording each skip with its reason.
while ($s -ne 'NOTIFY' -and $s -ne 'DONE') {
  $why = Get-YcSkipReason $s $Cfg (Get-Results)
  if (-not $why) { break }
  if ($s -eq 'SQLLIC' -and $Cfg.InstallSql -and $why -like 'by profile*') { L 'SQL LEFT ON EVALUATION by profile. This box is NOT licensed for production.' }
  if ($s -eq 'LIC' -and $why -like 'by profile*') { L 'WINDOWS LEFT ON ITS TRIAL CHANNEL by profile.' }
  L ($s + ' skipped - ' + $why)
  Step-Skip $s $why
  $next = Get-YcNextState $s
  Set-State $next '~'; $s = $next
}

function Invoke-YcWindowsUpdate($stateName) {
  # NO -Reboot passed to winupdate. It would restart the box itself, from a state that
  # has not been written yet, and the resume would land in the wrong place. The state
  # machine owns every reboot here - that is the only way a resume can be trusted.
  # Updates arrive in waves: a pass installs what it can, reboots, and then MORE become
  # applicable. Three passes, then move on and say so rather than looping forever.
  $pf = Join-Path $Base ('yc-build.' + $stateName + '.passes')
  $p = 0; if (Test-Path $pf) { $p = [int](Get-Content $pf -TotalCount 1) }
  if ($p -ge 3) { L ($stateName + ': 3 update passes done, moving on'); return $false }
  Set-Content -Path $pf -Value ([string]($p + 1)) -Encoding ascii
  L ($stateName + ': winupdate -Security -Install, pass ' + ($p + 1) + ' of 3')
  & cmd /c 'C:\Scripts\winupdate.cmd -Security -Install' *>> $Log
  $script:WuRc = $LASTEXITCODE
  L ('winupdate rc=' + $script:WuRc)
  # Ask WINDOWS whether it wants a restart rather than inferring it from an exit code.
  $pending = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') -or
             (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')
  if ($pending) { L ($stateName + ': restart pending - taking it, then returning to this state'); return $true }
  return $false
}
function Complete-Updates([string]$step) {
  $pf = Join-Path $Base ('yc-build.' + $step + '.passes'); $p = 0; try { $p = [int](Get-Content $pf -TotalCount 1 -EA Stop) } catch {}
  $ok = (@(0, 3010) -contains [int]$script:WuRc) -or ($null -eq $script:WuRc)
  if ($ok) { Step-End $step 'ok' ('security updates, ' + $p + ' pass(es)'); return (Move-Next $step '+') }
  return (Fail $step ('winupdate rc=' + $script:WuRc))
}

if ($s -eq 'UPDPRE') {
  Step-Begin 'UPDPRE'
  if (Invoke-YcWindowsUpdate 'UPDPRE') { Restart-Now 'UPDPRE' }
  $s = Complete-Updates 'UPDPRE'
}

if ($s -eq 'DOTNET') {
  Step-Begin 'DOTNET'
  L 'install-dotnet -UpgradeChocolatey'
  & cmd /c 'C:\Scripts\install-dotnet.cmd -UpgradeChocolatey' *>> $Log
  $rc = $LASTEXITCODE; L ('install-dotnet rc=' + $rc)
  if ($rc -eq 8) { Restart-Now 'DOTNET' }          # come back and re-check, then fall through
  if ($rc -ne 0) { $s = Fail 'DOTNET' ('install-dotnet rc=' + $rc) }
  else { Step-End 'DOTNET' 'ok'; $s = Move-Next 'DOTNET' }
}

if ($s -eq 'SQL') {
  Step-Begin 'SQL'
  $pwf = Join-Path $Base '.sa-password'
  Set-Content -Path $pwf -Value $Cfg.SaPassword -Encoding ascii
  & icacls $pwf /inheritance:r /grant 'SYSTEM:F' 'Administrators:F' *>> $Log
  $bf = Join-Path $Base 'yc-sqltemplate.sqlreboots'
  $rb = 0; if (Test-Path $bf) { $rb = [int](Get-Content $bf -TotalCount 1) }
  $cpf = ''
  if ([string]$Cfg.ChadminPassword) {
    $cpf = Join-Path $Base '.chadmin-password'
    Set-Content -Path $cpf -Value ([string]$Cfg.ChadminPassword) -Encoding ascii
    & icacls $cpf /inheritance:r /grant 'SYSTEM:F' 'Administrators:F' *>> $Log
  }
  $args = Get-YcSqlArgs -Cfg $Cfg -PwFile $pwf -ChadminFile $cpf
  L $args
  & cmd /c $args *>> $Log
  $rc = $LASTEXITCODE; L ('install-sql rc=' + $rc)
  $loop = $false
  if (Test-Path 'C:\Scripts\install-sql.reboot-required') {
    Remove-Item 'C:\Scripts\install-sql.reboot-required' -Force -EA SilentlyContinue
    if ($rb -ge 4) { $loop = $true }
    else {
      Set-Content -Path $bf -Value ([string]($rb + 1)) -Encoding ascii
      L ('install-sql wants a reboot - restart ' + ($rb + 1) + ' of 4')
      Restart-Now 'SQL'
    }
  }
  Remove-Item $pwf -Force -EA SilentlyContinue
  if ($cpf) { Remove-Item $cpf -Force -EA SilentlyContinue }
  if ($loop) { $s = Fail 'SQL' 'install-sql asked for a 5th reboot - refusing, this is a loop' }
  elseif ($rc -ne 0) { $s = Fail 'SQL' ('install-sql rc=' + $rc) }
  else {
    Step-End 'SQL' 'ok'
    # unconditional: the licence needs it. Restart-Now writes the next state, so a licence that is not
    # wanted is skipped (and recorded) after the reboot by the walk at the top.
    $nx = Move-Next 'SQL'
    Restart-Now $nx
  }
}

if ($s -eq 'SQLLIC') {
  Step-Begin 'SQLLIC' @{ from = (Get-SqlInstanceFacts ([string]$Cfg.InstanceName))['edition'] }
  if ($Cfg.SqlKey) {
    L ('activate-sql -TargetEdition ' + $Cfg.SqlEdition)
    & cmd /c ('C:\Scripts\activate-sql.cmd -ProductKey ' + $Cfg.SqlKey + ' -TargetEdition ' + $Cfg.SqlEdition + ' -InstanceName ' + $Cfg.InstanceName) *>> $Log
    $rc = $LASTEXITCODE; L ('activate-sql rc=' + $rc)
    if ($rc -ne 0 -and $rc -ne 3010) { $s = Fail 'SQLLIC' ('activate-sql rc=' + $rc) }
    else { Step-End 'SQLLIC' 'ok'; $s = Move-Next 'SQLLIC' }
  } else {
    L 'no SQL key - leaving the instance on Evaluation'
    $s = Fail 'SQLLIC' 'no SqlKey was supplied - SQL stays on Evaluation'
  }
}

if ($s -eq 'SSMS') {
  Step-Begin 'SSMS'
  L 'install-ssms'
  & cmd /c 'C:\Scripts\install-ssms.cmd' *>> $Log
  $rc = $LASTEXITCODE; L ('install-ssms rc=' + $rc)
  if ($rc -eq 8) { Restart-Now 'SSMS' }
  # An SSMS that did not install is a failed step now (it used to be recorded SSMS+ whatever happened).
  if ($rc -ne 0 -and $rc -ne 3010) { $s = Fail 'SSMS' ('install-ssms rc=' + $rc) }
  else { Step-End 'SSMS' 'ok'; $s = Move-Next 'SSMS' }
}

if ($s -eq 'LIC') {
  Step-Begin 'LIC' @{ from = (Get-EditionId) }
  if ($Cfg.WinKey) {
    $lf = Join-Path $Base 'yc-sqltemplate.licpasses'
    $lp = 0; if (Test-Path $lf) { $lp = [int](Get-Content $lf -TotalCount 1) }
    $w = Get-WinLic
    L ('windows now: status=' + $w.status + ' channel=' + $w.channel + ' key=' + $w.partial)
    # Volume:MAK AND Licensed. Either one alone is the GVLK trap.
    if ($w.channel -notmatch 'Volume:MAK' -or $w.status -notmatch 'Licensed') {
      if ($lp -ge 3) { L 'activate-windows has not reached Volume:MAK in 3 passes - reporting what is true' }
      else {
        Set-Content -Path $lf -Value ([string]($lp + 1)) -Encoding ascii
        L ('activate-windows, pass ' + ($lp + 1) + ' of 3')
        & cmd /c ('C:\Scripts\activate-windows.cmd -ProductKey ' + $Cfg.WinKey) *>> $Log
        $rc = $LASTEXITCODE; L ('activate-windows rc=' + $rc)
        # 3 = edition change staged (vm.license.waiting, P8): finishes after the reboot
        if ($rc -eq 3) { Restart-Now 'LIC' }
        for ($i = 1; $i -le 20; $i++) {
          $w = Get-WinLic
          if ($w.channel -match 'Volume:MAK' -and $w.status -match 'Licensed') { break }
          Start-Sleep -Seconds 30
        }
        L ('windows settled: status=' + $w.status + ' channel=' + $w.channel + ' key=' + $w.partial)
      }
    } else { L 'windows already Licensed on Volume:MAK' }
  } else { L 'no Windows key - leaving the trial channel'; $w = Get-WinLic }

  # THE STEP MARKER TELLS THE TRUTH. On TSBMFDDB02 an unconditional '+' recorded LIC+ for a WIN-LIC
  # build whose $WinKey was empty - Notification mode, Volume:GVLK, 0x8007232B. /xpr is the only
  # answer that cannot be misread; see Test-YcWinPermanent.
  $ok = (Test-YcWinPermanent $w['xpr'])
  $lx = @{ edition = (Get-EditionId); channel = [string]$w['channel']; partial = [string]$w['partial'] }
  if ($ok) {
    L 'LIC+ : slmgr /xpr confirms the machine is permanently activated'
    Step-End 'LIC' 'ok' '' $lx; $s = Move-Next 'LIC'
  } else {
    $why = $(if (-not $Cfg.WinKey) { 'no WinKey was supplied' }
             elseif ($w['reason'])  { $w['status'] + ' ' + $w['channel'] + ' ' + $w['reason'] }
             else                   { $w['status'] + ' ' + $w['channel'] }).Trim()
    $own = Get-StepReason 'LIC' ''
    if ($own -and $own -ne $why) { $why = $why + ' (activate-windows: ' + $own + ')' }
    L ('LIC- : windows is NOT licensed (' + $why + '). slmgr /xpr said: ' + $w['xpr'])
    Step-End 'LIC' 'failed' $why $lx
    Send-StepFailed 'LIC' $why
    $s = Move-Next 'LIC' '-'
  }
}

if ($s -eq 'UPDPOST') {
  Step-Begin 'UPDPOST'
  if (Invoke-YcWindowsUpdate 'UPDPOST') { Restart-Now 'UPDPOST' }
  $s = Complete-Updates 'UPDPOST'
}

if ($s -eq 'NOTIFY') {
  # THE HAND-OVER (P13): OK BUILD or FAILED BUILD, the same block either way - where the VM is, how to
  # log in, what each step added (version + time), and how long the whole build took.
  $j = Get-Journal
  $res = Get-Results
  function JD([string]$k) { if ($j.Contains($k)) { return [string]$j[$k]['detail'] }; return '' }
  $stepStr = Get-Steps
  $failText = Get-YcFailText $j
  $ok = (-not $failText) -and ($stepStr -notmatch '[A-Z]-(\s|$)')     # SYNC- etc. from the builder counts too
  if (-not $ok -and -not $failText) { $failText = 'builder: a builder step failed (' + $stepStr + ')' }
  $firstFail = ''; foreach ($k in @($j.Keys)) { if ([string]$j[$k]['result'] -eq 'failed') { $firstFail = $k; break } }

  $id = Get-YcBuildIdentity; $hf = Get-YcHostFacts
  $ipi = Get-YcIpInfo -NicIp $hf['ip'] -PublicIp $hf['publicIp'] -Gateway $hf['gateway']
  $w = Get-WinLic
  $winOk = Test-YcWinPermanent $w['xpr']
  $osLine = $hf['os'] + ' (' + $(if ($winOk) { 'licensed, ' + $w['channel'] + ' ...' + $w['partial'] }
                                 elseif (-not $Cfg.LicenseWindows) { 'trial channel by profile, ' + $w['channel'] }
                                 else { 'NOT licensed, ' + $w['status'] + ' ' + $w['channel'] + $(if ($w['reason']) { ' ' + $w['reason'] } else { '' }) }) + ')'
  $sq = $(if ($Cfg.InstallSql) { Get-SqlInstanceFacts ([string]$Cfg.InstanceName) } else { @{} })
  $lsql = Get-LastResult 'install-sql' 'SQL'
  $sum = $(if ($lsql) { @($lsql.summary) } else { @() })

  $logins = [ordered]@{}
  $logins['Administrator'] = $(if ([string]$Cfg.AdminPassword) { [string]$Cfg.AdminPassword } else { '(the CloudStack deploy password - the ERP has it)' })
  if ([string]$Cfg.ChadminPassword) { $logins['chadmin'] = [string]$Cfg.ChadminPassword }
  if ($Cfg.InstallSql -and [string]$Cfg.SaPassword) { $logins['sa'] = [string]$Cfg.SaPassword + '     (SQL auth)' }
  if ($sq['tls']) {
    $logins['sql tls'] = $sq['tls'] + '  (trusted on the VM; remote: import ' + $(if ($sq['cer']) { $sq['cer'] } else { 'the certificate' }) + ' or tick Trust server certificate)'
  }

  # [ what was added ] - failed rows first (P13), then in build order
  $rows = @(); $later = @()
  function Add-Row([string]$step, [string]$text) {
    if (-not $j.Contains($step)) { return }
    $e = $j[$step]
    $res = [string]$e['result']; if (-not $res) { $res = 'unknown' }
    # a step the profile never wanted is not news on a hand-over - updates excepted (owner layout)
    if ($res -eq 'skipped' -and [string]$e['detail'] -like 'by profile*' -and $step -notlike 'UPD*') { return }
    $t = $text
    if ($res -eq 'failed') { $t = [string]$e['detail'] }
    elseif ($res -eq 'skipped') { $t = $(if ([string]$e['detail'] -like 'by profile*') { '(profile)' } else { [string]$e['detail'] }) }
    $r = Get-YcAddedRow $script:YcStepMeta[$step]['label'] $res $t $(if ($res -eq 'skipped') { '' } else { Get-YcStepTook $e })
    if ($res -eq 'failed') { $script:rowsF += $r } else { $script:rowsO += $r }
  }
  $script:rowsF = @(); $script:rowsO = @()
  $rel = 0; try { $rel = [int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release -EA Stop).Release } catch {}
  Add-Row 'DOTNET' (Get-YcDotNetName $rel)
  $build = Get-YcSummaryValue $sum 'Build'
  $sqlText = ([string]$Cfg.SqlVersion + ' ' + $(if ($sq['edition']) { $sq['edition'] } else { [string]$Cfg.SqlEdition }) + ' ' +
              $(if ($build) { $build } elseif ($sq['patch']) { $sq['patch'] } else { $sq['version'] }) + ', ' + [string]$Cfg.InstanceName +
              $(if ($sq['collation']) { ', ' + $sq['collation'] } else { '' })).Trim()
  Add-Row 'SQL' $sqlText
  if ($Cfg.InstallSql -and $res['SQL'] -eq 'ok') {
    $tools = @()
    $v = Get-UninstallVersion 'Microsoft ODBC Driver 18 for SQL Server*'; if ($v) { $tools += ('ODBC 18 ' + $v) }
    $v = Get-UninstallVersion 'Microsoft OLE DB Driver*for SQL Server*'; if ($v) { $tools += ('OLE DB ' + $v) }
    if (Get-YcSummaryValue $sum 'sqlcmd') { $tools += 'sqlcmd' }
    foreach ($mn in @('SqlServer','dbatools')) {
      $mv = @(Get-Module -ListAvailable -Name $mn -EA SilentlyContinue | Sort-Object Version -Descending | Select-Object -First 1)
      if ($mv.Count) { $tools += ($mn + ' ' + [string]$mv[0].Version) }
    }
    $script:rowsO += (Get-YcAddedRow 'SQL tools' $(if ($tools.Count) { 'ok' } else { 'unknown' }) ($tools -join ' / '))
  }
  $ssv = Get-UninstallVersion '*SQL Server Management Studio*'
  Add-Row 'SSMS' $(if ($ssv) { $ssv } else { 'installed' })
  $sl = $(if ($j.Contains('SQLLIC')) { $j['SQLLIC'] } else { $null })
  Add-Row 'SQLLIC' ($(if ($sl -and $sl['from']) { [string]$sl['from'] } else { 'Evaluation' }) + ' -> ' + $(if ($sq['edition']) { $sq['edition'] } else { [string]$Cfg.SqlEdition }))
  $wl = $(if ($j.Contains('LIC')) { $j['LIC'] } else { $null })
  if ($wl) {
    $rbt = [int]$wl['reboots']
    Add-Row 'LIC' (($(if ($wl['from']) { [string]$wl['from'] } else { '?' }) + ' -> ' + (Get-EditionId) + ' -> ' + ([string]$w['channel'] -replace '^Volume:','')) +
                   ', ' + $rbt + ' reboot' + $(if ($rbt -ne 1) { 's' } else { '' }))
  }
  if ($Cfg.InstallSql -and $Cfg.ConfigureSqlBackup) {
    $bres = $(if ($res['SQL'] -eq 'ok') { 'ok' } else { 'skipped' })
    $script:rowsO += (Get-YcAddedRow 'Backups' $bres ([string]$Cfg.BackupDir + ' full ' + $Cfg.RetainFullDays + ' d / diff ' + $Cfg.RetainDiffDays + ' d / log ' + $Cfg.RetainLogDays + ' d, monthly ' + $Cfg.MonthlyKeep))
    $mt = Get-YcSummaryValue $sum 'Maintenance'
    $script:rowsO += (Get-YcAddedRow 'Maintenance' $(if ($mt -match '4/4') { 'ok' } elseif ($bres -eq 'skipped') { 'skipped' } else { 'check' }) $(if ($mt -match '4/4') { '4/4 procedures' } else { $mt }))
  }
  $up = $(if ($res['UPDPOST'] -and $res['UPDPOST'] -ne 'skipped') { 'UPDPOST' } elseif ($res['UPDPRE'] -and $res['UPDPRE'] -ne 'skipped') { 'UPDPRE' } else { 'UPDPOST' })
  Add-Row $up (JD $up)
  $ag = @('salt','glpi','acronis','wsus' | ForEach-Object {
          $on = switch ($_) { 'salt' { [bool]$Cfg.JoinSalt } 'glpi' { [bool]$Cfg.GlpiAgentPassword } 'acronis' { [bool]$Cfg.AcronisToken } 'wsus' { [bool]$Cfg.UseLocalWsus } }
          Get-AgentWord $_ $on })
  $script:rowsO += (Get-YcAddedRow 'Agents' '' ('salt ' + $ag[0] + ' / glpi ' + $ag[1] + ' / acronis ' + $ag[2] + ' / wsus ' + $ag[3]))
  $rows = @($script:rowsF) + @($script:rowsO)

  # [ trace ]: the whole build, from the builder's first boot to now, and every reboot it took
  $tookLine = ''; $startedAt = ''; $now = Get-Date
  try {
    $startedAt = (Get-Content (Join-Path $Base 'yc-sqltemplate.started') -TotalCount 1).Trim()
    $t0 = [datetime]$startedAt
    $boots = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = 6005; StartTime = $t0 } -EA SilentlyContinue).Count
    if (-not $boots) { try { $boots = [int](Get-Content (Join-Path $Base 'yc-build.reboots') -TotalCount 1 -EA Stop) } catch { $boots = 0 } }
    $script:Reboots = $boots
    $tookLine = ([string][int]($now - $t0).TotalMinutes + ' min (started ' + (ConvertTo-Ist $t0) -replace ' IST$','') + ', finished ' + (ConvertTo-Ist $now) + '), reboots ' + $boots
  } catch {}

  $title = Get-YcBuildTitle -Ok $ok -BuildProfile ([string]$Cfg.Profile)
  $say = $(if ($ok) { 'Finished - the server is ready.' } else { 'FAILED - ' + $failText })
  $srv = @{ vmName = $id['vmName']; tenant = $id['tenant']; uuid = $id['uuid']; host = $env:COMPUTERNAME; ipLine = $ipi['line']
            os = $osLine; portal = $id['vmUrl']; access = $ipi['access'] }
  $lines = Get-YcBuildLines -Say $say -Server $srv -Logins $logins -Rows $rows -Took $tookLine -StepStr $stepStr `
                            -PayloadVer (Get-YcPayloadVersion) -LogPath 'C:\Scripts\yc-deploy.log'
  # -Extra stays the single-line key=value summary the receiver has always parsed (contract with the ERP).
  $extra = 'profile=' + $Cfg.Profile +
           ' sql=' + $(if ($Cfg.InstallSql) { [string]$Cfg.SqlVersion + ' ' + [string]$Cfg.SqlEdition } else { 'none' }) +
           ' sqlLicensed=' + $Cfg.LicenseSql +
           ' ssms=' + $Cfg.InstallSsms +
           ' winLicensed=' + $Cfg.LicenseWindows +
           ' sqlBackup=' + $Cfg.ConfigureSqlBackup
  # The same keys as fields on ERP + Tech (P5/P13): logins unredacted (owner rule 2026-11-05).
  $did = ''; try { $did = [string]$Cfg.DeployId } catch {}
  $hand = @(('vmPassword=' + [string]$Cfg.AdminPassword), ('adminPassword=' + [string]$Cfg.AdminPassword), ('chadminPassword=' + [string]$Cfg.ChadminPassword),
            ('saPassword=' + $(if ($Cfg.InstallSql) { [string]$Cfg.SaPassword } else { '' })),
            ('statusUrl=' + $(if ($did -like 'YCD-2*') { 'https://cloudinit.mgmt.yallacloud.net/deployments?id=' + $did } else { '' })),
            ('sqlTlsThumbprint=' + [string]$sq['tls']), ('sqlTlsCert=' + [string]$sq['cer']),
            ('publicIp=' + $ipi['public']), ('privateIp=' + $ipi['private']), ('gateway=' + $hf['gateway']), ('access=' + $ipi['access']),
            ('osEdition=' + $osLine), ('took=' + $tookLine), ('reboots=' + [string]$script:Reboots), ('startedAt=' + $startedAt), ('finishedAt=' + $now.ToString('s')),
            ('handover=' + (@($lines) -join "`n")))
  $splat = @{
    Type         = $(if ($ok) { 'vm.deploy.completed' } else { 'vm.deploy.failed' })
    Step         = $stepStr
    Extra        = $title
    NtfyTitle    = ($title + ' - ' + $env:COMPUTERNAME)
    NtfyPriority = $(if ($ok) { '3' } else { '5' })
    NtfyTags     = $(if ($ok) { 'white_check_mark,build' } else { 'rotating_light,build' })
    NtfyLine     = $lines
    Field        = @('area=deploy', ('status=' + $(if ($ok) { 'completed' } else { 'failed' })), ('summary=' + $title), ('profile=' + [string]$Cfg.Profile),
                     ('winLicensed=' + [string]$winOk), ('buildResult=' + $(if ($ok) { 'ok' } else { 'failed' })),
                     ('steps=' + $stepStr), ('extra=' + $extra)) + (Get-YcIdFields $id) + $hand
  }
  if (-not $ok) {
    $splat['FailedStep'] = $(if ($firstFail) { $firstFail } else { 'builder' })
    $splat['ErrorText']  = $failText
    $splat['Field'] += @(('failedStep=' + $splat['FailedStep']), ('error=' + $failText))
  }
  if ($Cfg.LicenseWindows -and -not $winOk) { $splat['Field'] += ('winLicenceReason=' + (JD 'LIC')) }
  if ($Cfg.SqlKey -and $Cfg.SqlKey.Length -ge 5) { $splat['SqlKeyLast5'] = $Cfg.SqlKey.Substring($Cfg.SqlKey.Length - 5) }
  Yc-EventRich $splat
  $script:BuildFailed = (-not $ok)
  Set-State 'DONE'; $s = 'DONE'
}

if ($s -eq 'DONE') {
  # A durable "this finished" marker. The state file says DONE too, but a state file is
  # a cursor - it is written before every step and is meaningless out of context. This is
  # a record: what was asked for, what ran, when it ended, in one file anyone can read
  # without knowing the state machine.
  $done = Join-Path $Base 'yc-build.completed'
  if (-not (Test-Path $done)) {
    $started = ''
    try { $started = (Get-Content (Join-Path $Base 'yc-sqltemplate.started') -TotalCount 1).Trim() } catch {}
    $mins = ''
    try { if ($started) { $mins = [int]((Get-Date) - [datetime]$started).TotalMinutes } } catch {}
    ([ordered]@{
      profile   = $Cfg.Profile
      steps     = (Get-Steps)
      result    = $(if ((Get-YcFailText (Get-Journal)) -or ((Get-Steps) -match '[A-Z]-(\s|$)')) { 'failed' } else { 'ok' })
      failed    = (Get-YcFailText (Get-Journal))
      startedAt = $started
      finishedAt= (Get-Date -f s)
      elapsedMin= $mins
      installSql=$Cfg.InstallSql; licenseSql=$Cfg.LicenseSql; installSsms=$Cfg.InstallSsms
      licenseWindows=$Cfg.LicenseWindows; sqlBackup=$Cfg.ConfigureSqlBackup
      windowsUpdates=$Cfg.InstallWindowsUpdates; windowsUpdateWhen=$Cfg.WindowsUpdateWhen
      sqlUpdates=$Cfg.InstallSqlUpdates
      host      = $env:COMPUTERNAME
    } | ConvertTo-Json) | Set-Content -Path $done -Encoding ascii
    L ('checkpoint written: ' + $done)
  }
  # House rule: cloud-init must not run again after the build (a later boot would reset the Administrator
  # password / re-apply the template's). yc-boot.ps1 does it at the NEXT boot; a build that never reboots
  # (WIN-TRIAL, WIN-LIC without updates) would keep it on until then - so do it here as well.
  try {
    $cb = Get-CimInstance Win32_Service -Filter "Name='cloudbase-init'" -EA Stop
    if ($cb -and $cb.StartMode -ne 'Disabled') { & sc.exe config cloudbase-init start= disabled | Out-Null; L 'cloudbase-init DISABLED (build complete)' }
  } catch { L ('cloudbase-init could not be disabled: ' + $_.Exception.Message) }
  L 'complete - removing the startup task'
  try { Unregister-ScheduledTask -TaskName $Task -Confirm:$false -EA SilentlyContinue } catch {}
}
L '=== yc-vmbuild run end ==='
if ($script:BuildFailed) { exit 1 }
exit 0
