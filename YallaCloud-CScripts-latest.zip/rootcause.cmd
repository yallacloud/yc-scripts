@echo off
rem rootcause [-Latest] [-Analyze [-AnalyzeTimeoutSec 120] [-SymbolPath <p>] [-DumpPath <dmp>]]
rem           [-Force] [-Help]
rem
rem Classifies the last crash/issue (disk / OS / driver / network) + BSOD STOP code into
rem C:\Scripts\rootcause-*.txt
rem
rem THE KERNEL DEBUGGER IS OFF BY DEFAULT. cdb only runs with -Analyze, with an explicit -y
rem symbol path and a hard timeout that KILLS it. Without that gate this task hung at every
rem boot (yc-health calls it) and the next boot stacked another copy on top. A named mutex
rem now makes a second instance exit immediately with code 11.
rem Logs to C:\Scripts\rootcause.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Root-Cause.ps1" %*
exit /b %ERRORLEVEL%
