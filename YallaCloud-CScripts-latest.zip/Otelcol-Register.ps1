param(
  [string]$ConfigUrl,
  [string]$ConfigFile,
  [string]$ArchivePath,
  [string]$DownloadUrl,
  [string]$Sha256,
  [string]$InstallDir = 'C:\Program Files\otelcol-contrib',
  [string]$ServiceName = 'otelcol-contrib',
  [int]$TelemetryPort = 8888,
  [switch]$SkipMetricsProbe,
  [switch]$Force,
  [switch]$Help
)
# =====================================================================================
# Otelcol-Register.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
# Installs otelcol-contrib as a Windows service, validates the config with the VENDOR
# validator, and PROVES the collector is up and serving telemetry before exiting 0.
#
# WHAT CHANGED AND WHY
# --------------------
#  1. IT NO LONGER LIES (was the group-wide P0). The old ending was
#         New-Service ... -EA SilentlyContinue | Out-Null
#         Start-Service $svcName -EA SilentlyContinue
#         Write-YcLog 'done - OpenTelemetry Collector installed' 'OK'; Stop-YcLog 0; exit 0
#     Both failures were swallowed and the script exited 0 regardless. Proof is now, in
#     order: the binary reports its version; the vendor validator passes; the service
#     exists and reaches Running; it is STILL Running after a settle window; and
#     http://127.0.0.1:8888/metrics answers 200 with Prometheus text. Every
#     -ErrorAction SilentlyContinue on a load-bearing call is gone.
#  2. [P0-26 vendor validator] THE VALIDATOR IS RUN, BEFORE THE SERVICE IS TOUCHED:
#         otelcol-contrib.exe validate --config="<path>"
#     A bad config used to make the collector exit immediately while the script reported
#     success. Now a non-zero validate exit aborts, the previous config is rolled back, and
#     the running collector is left alone.
#  3. [P0-26b] THE hostmetrics 'processes' SCRAPER IS REFUSED. Upstream's platform table
#     lists 'processes' as Linux/Mac/FreeBSD/OpenBSD ONLY - on Windows the collector fails
#     at startup. The singular 'process' scraper is the Windows one. Any config handed to
#     this command is checked for a 'processes:' scraper and rejected with that explanation
#     BEFORE the service is restarted. (Setup-Observability.ps1 no longer emits it.)
#  4. THE CONFIG IS FETCHED SAFELY AND TREATED AS A SECRET. Was Invoke-WebRequest with no
#     timeout, no -ErrorAction Stop and no content check, so a 404/portal page became
#     config.yaml. Now Get-YcFile (TLS 1.2+, retries, HTML detection, optional -Sha256),
#     a YAML sanity check, and an ACL of SYSTEM + Administrators only on the installed
#     config - OTLP bearer tokens and Authorization headers live in that file.
#  5. SERVICE RE-CREATION IS NO LONGER RACY OR SILENT. sc.exe delete only MARKS a service
#     for deletion; the old 'sc delete; Start-Sleep 2; New-Service' left the OLD binary and
#     OLD config running whenever a handle was open. The script now polls for the service to
#     really disappear (60s) and hard-fails otherwise, and reuses the service in place when
#     the binPath already matches.
#  6. SERVER 2016 IS SUPPORTED AGAIN. tar.exe does not exist on Server 2016, and the old
#     script hard-exited 1 there even though 2016 is in the support matrix. The releases
#     repo publishes a .zip asset as well; this script accepts either and uses
#     Expand-Archive for the zip.
#  7. START TYPE AND FAILURE ACTIONS MATCH THE TOOLKIT. delayed-auto (sysprep-safe) via
#     sc.exe config, plus sc.exe failure restart/5000 - the old script used plain Automatic
#     and no failure actions, contradicting the rest of the toolkit.
#  8. ONE SERVICE NAME, ONE INSTALL DIR. Setup-Observability.ps1 used to create a SECOND
#     collector called YC-OtelCollector from the same binary in another directory with
#     another config. Setup-Observability.ps1 now delegates to THIS script, so there is one
#     service (otelcol-contrib), one binary and one config on the box.
#  9. Version-aware installer selection: the old Sort-Object Name -Descending is a LEXICAL
#     sort, so 0.9.0 beat 0.157.0. Versions are now parsed and compared as [version].
# 10. Unhandled-exception guard + temp cleanup on every path.
#
# PARAMETERS ADDED (none renamed, none removed): -ArchivePath, -DownloadUrl, -Sha256,
#     -InstallDir, -ServiceName, -TelemetryPort, -SkipMetricsProbe, -Force.
#
# VERIFIED AGAINST THE CURRENT RELEASE (docs/source, not memory):
#   validate subcommand + --config URI forms (file:, env:, yaml:, http:)
#     https://opentelemetry.io/docs/collector/configuration/
#   hostmetrics scraper platform table ('processes' = Linux/Mac/FreeBSD/OpenBSD)
#     https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/main/receiver/hostmetricsreceiver/README.md
#   the collector implements the Windows service dispatcher natively (svc.Handler / svc.Run)
#     https://github.com/open-telemetry/opentelemetry-collector/blob/main/otelcol/collector_windows.go
#   sc.exe create ... binPath="<exe> --config <yaml>" is the documented service form
#     https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sc-create
#
# Log: C:\Scripts\otelcol-register.log
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'otelcol-register'
$ErrorActionPreference = 'Stop'

$HelpText = @"
otelcol-register - SILENT install + configure the OpenTelemetry Collector (otelcol-contrib) as a
                   Windows service, validate the config with 'otelcol-contrib validate', and prove
                   the collector is running and serving its own telemetry before reporting success.
                   AGENT = push OUT: no inbound rule is created.

USAGE:
  otelcol-register -ConfigUrl <http-url-to-config.yaml>
  otelcol-register -ConfigFile <C:\path\config.yaml>
  otelcol-register -Help

PARAMETERS:
  -ConfigUrl          (required unless -ConfigFile) fetch config.yaml from this URL. Downloaded with
                      TLS 1.2+, retries and an HTML/error-page check.
  -ConfigFile         Use this local config.yaml instead.
  -ArchivePath        Explicit staged archive. Default: newest
                      C:\Scripts\otelcol-contrib_*_windows_amd64.tar.gz (or .zip), by PARSED version.
  -DownloadUrl        Download the release archive instead of using a staged one.
  -Sha256             Expected SHA256 of the archive. Strongly recommended.
  -InstallDir         Install folder. Default C:\Program Files\otelcol-contrib.
  -ServiceName        Windows service name. Default otelcol-contrib.
  -TelemetryPort      Port of the collector's own internal telemetry endpoint, used for the liveness
                      proof. Default 8888.
  -SkipMetricsProbe   Skip the /metrics proof. Only for a config that deliberately disables the
                      collector's internal telemetry; the service-state proof still runs.
  -Force              Rewrite config.yaml even if the content is unchanged.
  -Help               Show this help and exit 0.

NOTES:
  If your config defines OTLP receivers (4317/4318) that must accept inbound traffic, add a SCOPED
  inbound rule yourself (-RemoteAddress <your senders>). This command opens NO inbound port.
  A config carrying an Authorization header or a bearer token is written with inheritance stripped
  and SYSTEM + Administrators access only.

EXAMPLES:
  otelcol-register -ConfigFile C:\Scripts\otel-config.yaml
  otelcol-register -ConfigUrl http://10.0.0.10/otel/win.yaml -Sha256 <hash>
  otelcol-register -Help

PROOF PERFORMED (in this order - any failure is a non-zero exit):
  1. otelcol-contrib.exe --version                       -> version recorded in the log
  2. the config is scanned for the hostmetrics 'processes' scraper, which does not exist on Windows
  3. otelcol-contrib.exe validate --config="<cfg>"       -> exit 0, BEFORE the service is touched
  4. service Running, polled, then re-checked after a settle window
  5. GET http://127.0.0.1:<TelemetryPort>/metrics        -> 200, Prometheus exposition text

EXIT CODES:
  0  Verified: validator passed, service Running, internal telemetry served.
  1  Failure at any step.
  2  Usage error (neither -ConfigUrl nor -ConfigFile, or both).
  5  Not elevated.
  6  No outbound internet when -ConfigUrl / -DownloadUrl was used.

Log: C:\Scripts\otelcol-register.log
"@

if($Help){ Write-Host $HelpText -ForegroundColor Cyan; Exit-Yc 0 'help shown' 'OK' }
if(-not $ConfigUrl -and -not $ConfigFile){
  Write-Host $HelpText -ForegroundColor Cyan
  Exit-Yc 2 'One of -ConfigUrl or -ConfigFile is required.' 'ERROR'
}
if($ConfigUrl -and $ConfigFile){
  Write-Host $HelpText -ForegroundColor Cyan
  Exit-Yc 2 '-ConfigUrl and -ConfigFile are mutually exclusive - pick one.' 'ERROR'
}

Assert-YcPrereqs -NeedAdmin
$script:YcExit = 1
$script:YcTemp = $null
$script:YcBackup = $null
$script:YcCfgPath = $null

# ------------------------------------------------------------------ helpers

function Write-YcAsciiFile{
  param([string]$Path,[string]$Content)
  $sw = New-Object System.IO.StreamWriter($Path,$false,(New-Object System.Text.ASCIIEncoding))
  try{ $sw.Write($Content) } finally{ $sw.Close() }
}

function Invoke-YcNative{
  param([string]$File,[string[]]$Arguments)
  $ErrorActionPreference = 'Continue'
  $out = & $File @Arguments 2>&1
  $rc  = $LASTEXITCODE
  $txt = @()
  foreach($o in $out){ if($null -ne $o){ $txt += ([string]$o) } }
  return (New-Object psobject -Property @{ Output = $txt; ExitCode = $rc })
}

function Protect-YcFileAcl{
  param([string]$Path)
  $r1 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/inheritance:r')
  $r2 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/grant','*S-1-5-18:(F)','*S-1-5-32-544:(F)')
  if($r1.ExitCode -ne 0 -or $r2.ExitCode -ne 0){
    Write-YcLog ('icacls FAILED on ' + $Path + ' (inheritance rc=' + $r1.ExitCode + ', grant rc=' +
      $r2.ExitCode + '): ' + (($r1.Output + $r2.Output) -join ' ')) 'ERROR'
    return $false
  }
  $allowed = @('S-1-5-18','S-1-5-32-544')
  $acl = Get-Acl -LiteralPath $Path
  if(-not $acl.AreAccessRulesProtected){
    Write-YcLog ('VERIFICATION FAILED: inheritance is still enabled on ' + $Path) 'ERROR'
    return $false
  }
  $bad = @()
  foreach($ace in $acl.Access){
    $sid = $null
    try{ $sid = $ace.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch{ $sid = [string]$ace.IdentityReference }
    if($allowed -notcontains $sid){ $bad += ([string]$ace.IdentityReference + ' (' + $sid + ')') }
  }
  if($bad.Count -gt 0){
    Write-YcLog ('VERIFICATION FAILED: ' + $Path + ' is still accessible to: ' + ($bad -join ', ') +
      '. A collector config normally carries an exporter Authorization header.') 'ERROR'
    return $false
  }
  Write-YcLog ('ACL verified on ' + $Path + ': inheritance removed, trustees are exactly SYSTEM ' +
    'and BUILTIN\Administrators.') 'OK'
  return $true
}

function Set-YcManagedFile{
  param([string]$Path,[string]$Content,[switch]$Always)
  if(Test-Path -LiteralPath $Path){
    $cur = Get-Content -LiteralPath $Path -Raw
    if($null -eq $cur){ $cur = '' }
    if($cur -eq $Content -and -not $Always){
      Write-YcLog ('Unchanged, left in place: ' + $Path)
      return $true
    }
    $bak = $Path + '.bak-' + (Get-Date).ToString('yyyyMMddHHmmss')
    Copy-Item -LiteralPath $Path -Destination $bak -Force
    $script:YcBackup = $bak
    Write-YcLog ('Content changed; previous config backed up to ' + $bak) 'WARN'
  }
  Write-YcAsciiFile -Path $Path -Content $Content
  Write-YcLog ('Wrote ' + $Path)
  return $true
}

function Restore-YcBackup{
  if($script:YcBackup -and $script:YcCfgPath -and (Test-Path -LiteralPath $script:YcBackup)){
    try{
      Copy-Item -LiteralPath $script:YcBackup -Destination $script:YcCfgPath -Force
      Write-YcLog ('Rolled the previous config back into ' + $script:YcCfgPath + '.') 'WARN'
    }catch{ Write-YcLog ('Could not roll back: ' + $_.Exception.Message) 'ERROR' }
  }
}

function Get-YcServiceObject([string]$Name){
  return (Get-Service | Where-Object { $_.Name -eq $Name } | Select-Object -First 1)
}

function Remove-YcServiceAndWait{
  param([string]$Name,[int]$TimeoutSec = 60)
  $svc = Get-YcServiceObject $Name
  if(-not $svc){ return $true }
  if($svc.Status -ne 'Stopped'){
    try{ Stop-Service -Name $Name -Force -ErrorAction Stop }
    catch{ Write-YcLog ('Stop-Service ' + $Name + ' failed: ' + $_.Exception.Message) 'WARN' }
  }
  $d = Invoke-YcNative -File 'sc.exe' -Arguments @('delete',$Name)
  if($d.ExitCode -ne 0){
    Write-YcLog ('sc.exe delete ' + $Name + ' returned ' + $d.ExitCode + ': ' + ($d.Output -join ' ')) 'WARN'
  }
  $deadline = (Get-Date).AddSeconds($TimeoutSec)
  while((Get-Date) -lt $deadline){
    if(-not (Get-YcServiceObject $Name)){ Write-YcLog ('Service ' + $Name + ' removed.'); return $true }
    Start-Sleep -Seconds 2
  }
  Write-YcLog ('Service ' + $Name + ' is still present ' + $TimeoutSec + 's after sc.exe delete ' +
    '(deletion pending - something holds an open handle, e.g. services.msc). Refusing to continue ' +
    'and silently leave the OLD binary and OLD config running.') 'ERROR'
  return $false
}

function Test-YcOtelConfigText{
  param([string]$Text,[string]$Origin)
  if($null -eq $Text){ $Text = '' }
  if($Text.Trim().Length -eq 0){
    Write-YcLog ('The configuration from ' + $Origin + ' is EMPTY. Refusing to install it.') 'ERROR'
    return $false
  }
  if($Text -match '(?i)<\s*(html|!doctype html|head|body)\b'){
    Write-YcLog ('The configuration from ' + $Origin + ' looks like an HTML page, not collector YAML.') 'ERROR'
    return $false
  }
  if($Text -notmatch '(?m)^\s*service\s*:'){
    Write-YcLog ('The configuration from ' + $Origin + ' has no top-level "service:" section, so the ' +
      'collector would start no pipeline at all.') 'ERROR'
    return $false
  }
  # P0-26b: the hostmetrics 'processes' scraper is Linux/Mac/FreeBSD/OpenBSD only.
  if($Text -match '(?m)^\s*processes\s*:'){
    Write-YcLog ('The configuration from ' + $Origin + ' enables the hostmetrics "processes" scraper. ' +
      'Upstream documents that scraper as Linux, Mac, FreeBSD and OpenBSD ONLY - on Windows the ' +
      'collector fails at startup, which is exactly how this estate shipped a collector that never ' +
      'ran. Use the singular "process" scraper for per-process metrics on Windows, or remove it. ' +
      'Refusing to install this configuration.') 'ERROR'
    return $false
  }
  return $true
}

function Get-YcOtelArchive{
  if($ArchivePath){
    if(-not (Test-Path -LiteralPath $ArchivePath)){
      Write-YcLog ('-ArchivePath not found: ' + $ArchivePath) 'ERROR'; return $null
    }
    return (Get-Item -LiteralPath $ArchivePath)
  }
  if($DownloadUrl){
    Assert-YcPrereqs -NeedInternet
    if(-not $script:YcTemp){
      $script:YcTemp = Join-Path $env:TEMP ('otel_' + [guid]::NewGuid().ToString('N'))
      New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
    }
    $ext = '.tar.gz'
    if($DownloadUrl -match '\.zip($|\?)'){ $ext = '.zip' }
    $dst = Join-Path $script:YcTemp ('otelcol-contrib' + $ext)
    $got = Get-YcFile -Uri $DownloadUrl -OutFile $dst -Sha256 $Sha256 -MinBytes 1048576
    if(-not $got){ return $null }
    return (Get-Item -LiteralPath $dst)
  }
  $all = @()
  foreach($pat in @('C:\Scripts\otelcol-contrib_*_windows_amd64.tar.gz','C:\Scripts\otelcol-contrib_*_windows_amd64.zip')){
    $found = Get-ChildItem -Path $pat -File -ErrorAction Ignore
    if($found){ $all += $found }
  }
  if($all.Count -eq 0){ return $null }
  # Parse the version so 0.157.0 beats 0.9.0 (the old lexical sort got this backwards).
  $pick = $all | Sort-Object {
      $m = [regex]::Match($_.Name,'(\d+\.\d+\.\d+)')
      if($m.Success){ [version]$m.Groups[1].Value } else { [version]'0.0.0' }
    } -Descending | Select-Object -First 1
  return $pick
}

# ------------------------------------------------------------------ main

function Invoke-Main{

  # --- 1. config content, obtained safely BEFORE anything changes ---------------------
  $cfgText = $null
  if($ConfigUrl){
    Assert-YcPrereqs -NeedInternet
    if(-not $script:YcTemp){
      $script:YcTemp = Join-Path $env:TEMP ('otel_' + [guid]::NewGuid().ToString('N'))
      New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
    }
    $dl = Join-Path $script:YcTemp 'config.yaml'
    $got = Get-YcFile -Uri $ConfigUrl -OutFile $dl -MinBytes 8 -AllowText
    if(-not $got){ Write-YcLog ('Could not fetch ' + $ConfigUrl) 'ERROR'; $script:YcExit = 1; return }
    $cfgText = Get-Content -LiteralPath $dl -Raw
    if(-not (Test-YcOtelConfigText -Text $cfgText -Origin $ConfigUrl)){ $script:YcExit = 1; return }
  }else{
    if(-not (Test-Path -LiteralPath $ConfigFile)){
      Write-YcLog ('-ConfigFile not found: ' + $ConfigFile) 'ERROR'; $script:YcExit = 1; return
    }
    $cfgText = Get-Content -LiteralPath $ConfigFile -Raw
    if(-not (Test-YcOtelConfigText -Text $cfgText -Origin $ConfigFile)){ $script:YcExit = 1; return }
  }
  Write-YcLog ('Configuration accepted (' + $cfgText.Length + ' chars): has a service section and no ' +
    'Linux-only hostmetrics scraper.') 'OK'

  # --- 2. the archive -----------------------------------------------------------------
  $arc = Get-YcOtelArchive
  if(-not $arc){
    Write-YcLog ('No otelcol-contrib archive. Stage C:\Scripts\otelcol-contrib_<ver>_windows_amd64.tar.gz ' +
      '(or the .zip asset, which is what Server 2016 needs because tar.exe does not exist there), or ' +
      'pass -ArchivePath / -DownloadUrl.') 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcFile -Path $arc.FullName -MinBytes 1048576 -Because 'otelcol-contrib archive')){
    $script:YcExit = 1; return
  }
  if($Sha256 -and -not $DownloadUrl){
    $h = (Get-FileHash -LiteralPath $arc.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
    if($h -ne $Sha256.Trim().ToUpperInvariant()){
      Write-YcLog ('SHA256 MISMATCH on ' + $arc.Name + ': expected ' + $Sha256.Trim().ToUpperInvariant() +
        ', got ' + $h + '. Refusing to install.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('SHA256 verified: ' + $h) 'OK'
  }else{
    $h = (Get-FileHash -LiteralPath $arc.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
    Write-YcLog ('No -Sha256 pin supplied. Archive hash is ' + $h + ' - pin it on the next run.') 'WARN'
  }

  if(-not $script:YcTemp){
    $script:YcTemp = Join-Path $env:TEMP ('otel_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
  }
  $ex = Join-Path $script:YcTemp 'x'
  New-Item -ItemType Directory -Path $ex -Force | Out-Null
  if($arc.Name.ToLowerInvariant().EndsWith('.zip')){
    Expand-Archive -Path $arc.FullName -DestinationPath $ex -Force
  }else{
    $tar = Get-Command tar.exe -ErrorAction SilentlyContinue
    if(-not $tar){
      Write-YcLog ('tar.exe is not present on this host (Windows Server 2016 has no in-box tar), and ' +
        'the staged archive is a .tar.gz. Stage the .zip asset from the same release instead - the ' +
        'releases repo publishes both. Refusing to continue.') 'ERROR'
      $script:YcExit = 1; return
    }
    $t = Invoke-YcNative -File $tar.Source -Arguments @('-xf',$arc.FullName,'-C',$ex)
    if($t.ExitCode -ne 0){
      Write-YcLog ('tar -xf FAILED (exit ' + $t.ExitCode + '): ' + ($t.Output -join ' ')) 'ERROR'
      $script:YcExit = 1; return
    }
  }
  $src = Get-ChildItem -Path $ex -Recurse -Filter 'otelcol-contrib.exe' -File | Select-Object -First 1
  if(-not $src){
    Write-YcLog ('otelcol-contrib.exe not found inside ' + $arc.Name) 'ERROR'
    $script:YcExit = 1; return
  }

  if(-not (Test-Path -LiteralPath $InstallDir)){ New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
  $exePath = Join-Path $InstallDir 'otelcol-contrib.exe'
  $existing = Get-YcServiceObject $ServiceName
  if($existing -and $existing.Status -eq 'Running'){
    Write-YcLog ('Existing service ' + $ServiceName + ' is Running; stopping it to replace the binary ' +
      '(upgrade path).')
    Stop-Service -Name $ServiceName -Force -ErrorAction Stop
    Start-Sleep -Seconds 2
  }
  Copy-Item -LiteralPath $src.FullName -Destination $exePath -Force
  if(-not (Assert-YcFile -Path $exePath -MinBytes 1048576 -Because 'installed collector binary')){
    $script:YcExit = 1; return
  }

  # --- 3. PROOF: the binary runs -------------------------------------------------------
  $ver = Invoke-YcNative -File $exePath -Arguments @('--version')
  $verLine = ($ver.Output | Where-Object { $_.Trim().Length -gt 0 } | Select-Object -First 1)
  if($ver.ExitCode -ne 0 -and -not $verLine){
    Write-YcLog ('otelcol-contrib.exe --version failed (exit ' + $ver.ExitCode + '). The extracted ' +
      'binary is not runnable on this host.') 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Installed binary: ' + $exePath + ' -- ' + ([string]$verLine).Trim()) 'OK'

  # --- 4. the config ------------------------------------------------------------------
  $script:YcCfgPath = Join-Path $InstallDir 'config.yaml'
  Set-YcManagedFile -Path $script:YcCfgPath -Content $cfgText -Always:$Force | Out-Null
  if(-not (Protect-YcFileAcl -Path $script:YcCfgPath)){ $script:YcExit = 1; return }

  # --- 5. PROOF: the VENDOR validator, before the service is touched ------------------
  # https://opentelemetry.io/docs/collector/configuration/  ("otelcol validate --config=...")
  Write-YcLog ('Validating with the vendor validator: "' + $exePath + '" validate --config="' +
    $script:YcCfgPath + '"')
  $chk = Invoke-YcNative -File $exePath -Arguments @('validate',('--config=' + $script:YcCfgPath))
  foreach($l in $chk.Output){ if($l.Trim().Length -gt 0){ Write-Host ('    ' + (Protect-YcSecret $l)) } }
  if($chk.ExitCode -ne 0){
    Write-YcLog ('VERIFICATION FAILED: otelcol-contrib validate exited ' + $chk.ExitCode + '. The ' +
      'configuration is invalid; the service was NOT created or restarted.') 'ERROR'
    Restore-YcBackup
    $script:YcExit = 1; return
  }
  Write-YcLog 'Vendor config validation passed (validate --config exit 0).' 'OK'

  # --- 6. the service (native dispatcher - no NSSM/WinSW needed here) ------------------
  $bin = '"' + $exePath + '" --config "' + $script:YcCfgPath + '"'
  $svc = Get-YcServiceObject $ServiceName
  $needCreate = $true
  if($svc){
    $curBin = ''
    $k = 'HKLM:\SYSTEM\CurrentControlSet\Services\' + $ServiceName
    if(Test-Path $k){ try{ $curBin = [string](Get-ItemProperty -Path $k).ImagePath }catch{} }
    if($curBin -eq $bin){
      Write-YcLog ('Service ' + $ServiceName + ' already exists with the correct binPath - reusing it ' +
        '(idempotent).')
      $needCreate = $false
    }else{
      Write-YcLog ('Service ' + $ServiceName + ' exists with a different binPath; recreating.')
      Write-YcLog ('  old: ' + $curBin)
      Write-YcLog ('  new: ' + $bin)
      if(-not (Remove-YcServiceAndWait -Name $ServiceName)){ $script:YcExit = 1; return }
    }
  }
  if($needCreate){
    try{
      New-Service -Name $ServiceName -BinaryPathName $bin `
                  -DisplayName 'OpenTelemetry Collector (contrib) - YallaCloud' `
                  -Description 'Collects host metrics and Windows event logs and exports them. Managed by C:\Scripts\Otelcol-Register.ps1.' `
                  -StartupType Automatic -ErrorAction Stop | Out-Null
    }catch{
      Write-YcLog ('New-Service ' + $ServiceName + ' FAILED: ' + $_.Exception.Message) 'ERROR'
      $script:YcExit = 1; return
    }
    if(-not (Get-YcServiceObject $ServiceName)){
      Write-YcLog ('VERIFICATION FAILED: service ' + $ServiceName + ' does not exist after New-Service ' +
        'returned.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('Service ' + $ServiceName + ' created.') 'OK'
  }
  # The collector writes to the Application log under a source named after the service.
  try{
    if(-not [System.Diagnostics.EventLog]::SourceExists($ServiceName)){
      New-EventLog -LogName 'Application' -Source $ServiceName -ErrorAction Stop
      Write-YcLog ('Registered Application event-log source "' + $ServiceName + '".')
    }
  }catch{ Write-YcLog ('Could not register the event-log source: ' + $_.Exception.Message) 'WARN' }

  $sc1 = Invoke-YcNative -File 'sc.exe' -Arguments @('config',$ServiceName,'start=','delayed-auto')
  if($sc1.ExitCode -ne 0){
    Write-YcLog ('sc.exe config start= delayed-auto returned ' + $sc1.ExitCode + ': ' + ($sc1.Output -join ' ')) 'WARN'
  }
  $sc2 = Invoke-YcNative -File 'sc.exe' -Arguments @('failure',$ServiceName,'reset=','60','actions=','restart/5000/restart/5000/restart/30000')
  if($sc2.ExitCode -ne 0){
    Write-YcLog ('sc.exe failure returned ' + $sc2.ExitCode + ': ' + ($sc2.Output -join ' ')) 'WARN'
  }

  # --- 7. PROOF: it runs and STAYS running --------------------------------------------
  try{ Start-Service -Name $ServiceName -ErrorAction Stop }
  catch{
    Write-YcLog ('Start-Service ' + $ServiceName + ' FAILED: ' + $_.Exception.Message +
      '. Check the Application event log, source ' + $ServiceName + '.') 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcService -Name $ServiceName -TimeoutSec 60 -Because 'OpenTelemetry Collector')){
    $script:YcExit = 1; return
  }
  Start-Sleep -Seconds 15
  $svc2 = Get-YcServiceObject $ServiceName
  if((-not $svc2) -or ($svc2.Status -ne 'Running')){
    $st = 'absent'; if($svc2){ $st = [string]$svc2.Status }
    Write-YcLog ('VERIFICATION FAILED: ' + $ServiceName + ' reached Running but is now "' + $st +
      '" 15s later - the collector exited on the configuration it just loaded (a receiver or exporter ' +
      'that validates but cannot start, e.g. a port already bound). Application event log, source ' +
      $ServiceName + '.') 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Service ' + $ServiceName + ' is Running and stayed Running.') 'OK'

  # --- 8. PROOF: it serves its own telemetry ------------------------------------------
  if($SkipMetricsProbe){
    Write-YcLog ('-SkipMetricsProbe was passed: the /metrics liveness proof was skipped. The only ' +
      'remaining evidence is the validator and the service state.') 'WARN'
  }else{
    $url = 'http://127.0.0.1:' + $TelemetryPort + '/metrics'
    if(-not (Assert-YcHttp -Uri $url -ExpectStatus 200 -TimeoutSec 90 -MatchContent '# HELP')){
      Write-YcLog ('VERIFICATION FAILED: ' + $url + ' did not return Prometheus text. The collector is ' +
        'running but its internal telemetry endpoint is not serving. If your config deliberately ' +
        'disables service::telemetry::metrics, re-run with -SkipMetricsProbe.') 'ERROR'
      $script:YcExit = 1; return
    }
  }

  Write-YcLog ('DONE. ' + $ServiceName + ' Running, config validated by "validate --config", internal ' +
    'telemetry served on 127.0.0.1:' + $TelemetryPort + '. No inbound port opened (egress agent).') 'OK'
  $script:YcExit = 0
}

try{
  Invoke-Main | Out-Null
}catch{
  Write-YcLog ('UNHANDLED EXCEPTION: ' + (Protect-YcSecret $_.Exception.Message)) 'ERROR'
  if($_.ScriptStackTrace){ Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}finally{
  if($script:YcTemp -and (Test-Path -LiteralPath $script:YcTemp)){
    try{ Remove-Item -LiteralPath $script:YcTemp -Recurse -Force }
    catch{ Write-YcLog ('Could not remove temp dir ' + $script:YcTemp + ': ' + $_.Exception.Message) 'WARN' }
  }
}

if($script:YcExit -eq 0){ Exit-Yc 0 'otelcol-register verified' 'OK' }
Exit-Yc $script:YcExit 'otelcol-register FAILED - nothing was reported as working that is not proven' 'ERROR'
