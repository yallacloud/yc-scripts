@echo off
rem ============================================================================
rem  doseal.cmd - strip build tooling, THEN sysprep. One atomic step.
rem  BUILD VM ONLY. Refuses to run anywhere else.
rem
rem  WHY THIS EXISTS
rem    Clean-Scripts.ps1 deletes the seal tooling, but C3-C7 need it back, so the
rem    runbook restores it from C:\sealkit right after the clean. Nothing removed
rem    it again before sysprep - so Seal-Manual.ps1 shipped INSIDE the sealed
rem    2026-08-12 images (454 files instead of ~400). Deleting here closes the
rem    window: the tooling exists right up to the moment sysprep starts.
rem
rem  WHAT CHANGED (2026-08-16 audit: P0-1, P0-2, P0-21) AND WHY
rem    1. REFUSES to run unless C:\Scripts\.goldenimage exists. doseal.cmd shipped
rem       in C:\Scripts on every clone and C:\Scripts is on PATH, so typing
rem       "doseal" on a production VM deleted the tooling and generalized the VM
rem       with no prompt. The marker is created by the build runbook on the build
rem       VM only, and is deleted below, so a clone can never seal itself.
rem    2. Asks for confirmation (type SEAL). /y keeps an automated build working.
rem    3. Unattend-Seal.xml and sysprep.exe are verified BEFORE the first delete.
rem       Previously a missing answer file was only discovered after 21 deletes
rem       had run, leaving a VM that was neither sealed nor rebuildable.
rem    4. Deletes C:\ProgramData\ssh\ssh_host_* (P0-1). sysprep /generalize resets
rem       the machine SID but does not touch files, so the build VM's host keys
rem       shipped in the image and every clone in the fleet answered with the SAME
rem       host key - one stolen image impersonates the whole fleet, and the
rem       host-key-mismatch warning never fires because the key never changes.
rem       SSH-FirstBoot.ps1 generates per-clone keys once these are gone.
rem    5. Deletes the builder's public key (P0-2): administrators_authorized_keys,
rem       the hidden .authorized_keys.baked backup and the .provisioned marker.
rem       Otherwise every clone ships with the builder authorized and YC-KeyGuard
rem       restores that key within the hour - the tenant cannot revoke it.
rem    6. sysprep runs with /quit and its EXIT CODE IS CHECKED; the VM is powered
rem       off only on exit code 0. /shutdown powered the VM off whether sysprep
rem       succeeded or failed, which is how an unsealed disk reaches the template
rem       store. On failure we stop, keep the VM up and point at the sysprep log.
rem    7. doseal.cmd deletes ITSELF as the last statement, so it is not in the
rem       image at all. It is deleted last because cmd.exe reads a batch file as
rem       it runs it; by then the shutdown is already scheduled.
rem
rem  NOT deleted on purpose:
rem    Unattend-Seal.xml     - sysprep reads it seconds later and copies it to
rem                            C:\Windows\Panther itself.
rem    set-admin-console.cmd - the answer file calls it in the specialize and
rem                            oobeSystem passes.
rem  Sysprep generalize-pass logs (read these if step 6 fails):
rem    %WINDIR%\System32\Sysprep\Panther\setupact.log
rem    %WINDIR%\System32\Sysprep\Panther\setuperr.log
rem ============================================================================
setlocal EnableExtensions

set "SCRIPTS=C:\Scripts"
set "SSHDIR=C:\ProgramData\ssh"
set "MARKER=%SCRIPTS%\.goldenimage"
set "UNATTEND=%SCRIPTS%\Unattend-Seal.xml"
set "SYSPREP=%WINDIR%\System32\Sysprep\sysprep.exe"

rem ---- guard 1: build VM only (P0-21) ----------------------------------------
if not exist "%MARKER%" (
  echo [doseal] REFUSING TO RUN.
  echo [doseal] "%MARKER%" not found, so this is not the golden-image build VM.
  echo [doseal] doseal wipes C:\Scripts and generalizes the machine with sysprep;
  echo [doseal] on a production VM that destroys the VM's identity and tooling.
  echo [doseal] The build runbook creates the marker on the BUILD VM only.
  exit /b 3
)

rem ---- guard 2: everything sysprep needs, checked BEFORE any delete (P0-21) --
if not exist "%UNATTEND%" (
  echo [doseal] MISSING ANSWER FILE: "%UNATTEND%"
  echo [doseal] nothing deleted. Restore the answer file and re-run.
  exit /b 4
)
if not exist "%SYSPREP%" (
  echo [doseal] MISSING SYSPREP: "%SYSPREP%"
  echo [doseal] nothing deleted. This Windows install cannot be sealed.
  exit /b 5
)

rem ---- guard 3: confirmation (P0-21) ----------------------------------------
set "CONFIRM="
if /i "%~1"=="/y" set "CONFIRM=SEAL"
if /i "%~1"=="-y" set "CONFIRM=SEAL"
if not defined CONFIRM (
  echo.
  echo [doseal] This DELETES the build/seal tooling and GENERALIZES this VM.
  echo [doseal] The VM powers off and must then be CAPTURED as a template,
  echo [doseal] never booted again as itself.
  echo [doseal] Anything other than SEAL aborts.
  set /p "CONFIRM=Type SEAL to continue: "
)
if /i not "%CONFIRM%"=="SEAL" (
  echo [doseal] aborted - nothing deleted.
  exit /b 6
)

rem ---- strip build/seal tooling ---------------------------------------------
echo [doseal] removing build/seal tooling from %SCRIPTS%
del /f /q "%SCRIPTS%\Seal-Manual.ps1"       2>nul
del /f /q "%SCRIPTS%\Fix-PreSeal.ps1"       2>nul
del /f /q "%SCRIPTS%\AppX-Strip.ps1"        2>nul
del /f /q "%SCRIPTS%\Install-YcTasks.ps1"   2>nul
del /f /q "%SCRIPTS%\Clean-Scripts.ps1"     2>nul
del /f /q "%SCRIPTS%\PreSeal-Agents.ps1"    2>nul
del /f /q "%SCRIPTS%\Enable-VirtioBoot.ps1" 2>nul
del /f /q "%SCRIPTS%\Fix-DiagTools.ps1"     2>nul
del /f /q "%SCRIPTS%\Install-YcPayload.ps1" 2>nul
del /f /q "%SCRIPTS%\GoldenImage*.ps1"      2>nul
del /f /q "%SCRIPTS%\yc-check.ps1"          2>nul
del /f /q "%SCRIPTS%\yc-folders.ps1"        2>nul
del /f /q "%SCRIPTS%\yc-id.ps1"             2>nul
del /f /q "%SCRIPTS%\ycpayload-v*.zip"      2>nul
del /f /q "%SCRIPTS%\ycpayload-v*.zip.sha256" 2>nul
del /f /q "%SCRIPTS%\*.log"                 2>nul
del /f /q "%SCRIPTS%\clean-discarded.txt"   2>nul
del /f /q "%SCRIPTS%\virtio-win.iso"        2>nul
rmdir /s /q "C:\sealkit"                    2>nul
rmdir /s /q "%SCRIPTS%\.done"               2>nul
rmdir /s /q "%SCRIPTS%\_stage"              2>nul

rem ---- P0-1: the build VM's SSH HOST KEYS must not ship in the image ---------
rem  ssh-keygen -A only creates keys that are ABSENT, so leaving these here is
rem  what made the SSH-FirstBoot guard a no-op on every clone ever deployed.
echo [doseal] removing SSH host keys (each clone generates its own at first boot)
attrib -h -s -r "%SSHDIR%\ssh_host_*" 2>nul
del /f /q "%SSHDIR%\ssh_host_*"             2>nul

rem ---- P0-2: the builder's PUBLIC KEY and its baked backup must not ship -----
echo [doseal] removing builder SSH authorized_keys and the baked backup
attrib -h -s -r "%SSHDIR%\administrators_authorized_keys" 2>nul
del /f /q "%SSHDIR%\administrators_authorized_keys" 2>nul
attrib -h -s -r "%SCRIPTS%\.authorized_keys.baked" 2>nul
del /f /q "%SCRIPTS%\.authorized_keys.baked" 2>nul
attrib -h -s -r "%SCRIPTS%\.provisioned"    2>nul
del /f /q "%SCRIPTS%\.provisioned"          2>nul
attrib -h -s -r "%SCRIPTS%\.sshhostkeys"    2>nul
del /f /q "%SCRIPTS%\.sshhostkeys"          2>nul

rem ---- sysprep, with the exit code actually checked (P0-21) ------------------
echo [doseal] launching sysprep (generalize + oobe, answer file: %UNATTEND%)
"%SYSPREP%" /generalize /oobe /quit /unattend:"%UNATTEND%"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo [doseal] SYSPREP FAILED with exit code %RC% - THIS VM IS NOT SEALED.
  echo [doseal] The VM is deliberately left running so you can read:
  echo [doseal]   %WINDIR%\System32\Sysprep\Panther\setuperr.log
  echo [doseal]   %WINDIR%\System32\Sysprep\Panther\setupact.log
  echo [doseal] Do NOT capture this disk as a template.
  exit /b 7
)

echo [doseal] sysprep OK - powering off in 10s for capture
del /f /q "%MARKER%" 2>nul
shutdown /s /t 10 /c "YC: sealed - capture this disk as a template"

rem ---- last statement: remove doseal.cmd itself from the image (P0-21) -------
del /f /q "%~f0" 2>nul
