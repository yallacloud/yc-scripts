# Regression test for the Activate-Sql.ps1 line-524 crash seen live on X19B
# (2026-08-29 19:45:13): "Cannot bind argument to parameter 'Path' because it is
# an empty string". Pulls the real function out of the real file by AST so the
# test cannot drift from the shipped code.
$ErrorActionPreference = 'Stop'
$src = Join-Path $PSScriptRoot 'Activate-Sql.ps1'
$errs = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($src, [ref]$null, [ref]$errs)
if ($errs) { throw ('parse errors in ' + $src) }
foreach ($n in @('Get-YcSetupSummaryPath')) {
    $f = $ast.Find({ param($x) $x -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $x.Name -eq $n }, $true)
    if (-not $f) { throw ("function $n not found in the script") }
    . ([scriptblock]::Create($f.Extent.Text))
}

$n = 0; $fail = 0
function T { param([string]$Name, [bool]$Ok)
    $script:n++
    if ($Ok) { Write-Host ('  ok   ' + $Name) -ForegroundColor Green }
    else { Write-Host ('  FAIL ' + $Name) -ForegroundColor Red; $script:fail++ }
}
$script:n = 0; $script:fail = 0
Write-Host 'Activate-Sql line-524 regression test' -ForegroundColor Cyan

# 1. Prove the ORIGINAL expression really does throw on media at a drive root.
$oldThrew = $false
try {
    $setup = 'E:\setup.exe'
    $null = Join-Path (Split-Path -Parent (Split-Path -Parent $setup)) 'Log\Summary.txt'
} catch { $oldThrew = $true }
T 'the ORIGINAL expression throws on E:\setup.exe (this was the live bug)' $oldThrew

# 2. The fix must not throw on the same input.
$threw = $false; $r = ''
try { $r = Get-YcSetupSummaryPath -SetupExe 'E:\setup.exe' -MajorVersion 13 } catch { $threw = $true }
T 'the fix does not throw on E:\setup.exe' (-not $threw)
T 'and returns the documented 130 fallback'  ($r -match '130' -and $r -match 'Summary\.txt')

# 3. Every other shape that used to be able to produce an empty string.
foreach ($case in @(
    @{ p = 'E:\setup.exe';    m = 16; label = 'media at a drive root' },
    @{ p = 'C:\setup.exe';    m = 15; label = 'setup.exe on C:\' },
    @{ p = '';                m = 14; label = 'empty setup path' },
    @{ p = $null;             m = 13; label = 'null setup path' },
    @{ p = 'E:\setup.exe';    m = 0;  label = 'no major version' },
    @{ p = '';                m = 0;  label = 'empty path AND no version' }
)) {
    $t = $false; $out = ''
    try { $out = Get-YcSetupSummaryPath -SetupExe $case.p -MajorVersion $case.m } catch { $t = $true }
    T ('no throw: ' + $case.label) (-not $t)
    T ('non-empty result: ' + $case.label) ([string]::IsNullOrWhiteSpace($out) -eq $false)
}

# 4. The normal bootstrap layout still resolves two levels up when it exists.
$tmp = Join-Path ([System.IO.Path]::GetTempPath()) ('yctest-' + [guid]::NewGuid().ToString('N').Substring(0,8))
$boot = Join-Path $tmp 'Setup Bootstrap'
$null = New-Item -ItemType Directory -Path (Join-Path $boot 'SQL2016') -Force
$null = New-Item -ItemType Directory -Path (Join-Path $boot 'Log') -Force
Set-Content -LiteralPath (Join-Path $boot 'Log\Summary.txt') -Value 'Final result: Passed'
$fake = Join-Path $boot 'SQL2016\setup.exe'
Set-Content -LiteralPath $fake -Value 'x'
$r2 = Get-YcSetupSummaryPath -SetupExe $fake -MajorVersion 13
# The script is Windows-only and emits backslashes; normalise both sides so this
# test also passes when it is run on Linux PowerShell during the build.
$expected = (Join-Path $boot 'Log') + [System.IO.Path]::DirectorySeparatorChar + 'Summary.txt'
$a = ([string]$r2).Replace('\','/')
$b = ([string]$expected).Replace('\','/')
T 'the real bootstrap layout still resolves two levels up' ($a -eq $b)
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

# 5. The failure path must not be reachable without a summary path.
T 'a derived path is always a string, never $null' ((Get-YcSetupSummaryPath -SetupExe $null -MajorVersion 0) -is [string])

Write-Host ''
if ($script:fail -eq 0) { Write-Host ('PASSED: ' + $script:n + ' assertions') -ForegroundColor Green; exit 0 }
Write-Host ('FAILED: ' + $script:fail + ' of ' + $script:n) -ForegroundColor Red; exit 1
