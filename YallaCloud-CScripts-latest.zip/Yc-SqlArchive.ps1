param(
  [string]$InstanceName = 'MSSQLSERVER',
  [string]$MonthlyDir   = 'C:\dbbackupmonthly',
  [int]$KeepMonths      = 12,
  [switch]$NoVerify,
  [switch]$Report,
  [switch]$SelfCheck,
  [switch]$Help
)
# =====================================================================================
# Yc-SqlArchive.ps1 - keep ONE full backup per calendar month, for KeepMonths months.
# PowerShell 5.1 only. ASCII only.
#
# WHY THIS EXISTS
#   Ola's @CleanupTime gives you a rolling window and nothing else. Set it to a year and
#   you keep 365 daily fulls, which fills the disk; set it to a month and you can never
#   answer "restore the state at the end of March". The usual answer is grandfather-
#   father-son: a short rolling window for the dailies, plus ONE retained copy per month.
#   Ola has no concept of the second half, so this does it.
#
# WHY IT RUNS DAILY AND NOT MONTHLY
#   A monthly trigger fires once. If the VM is off, patching, or the SQL service is down
#   on the 1st, that month is simply lost and nothing says so. This runs every day and
#   asks a different question - "does the CURRENT month already have an archived copy?" -
#   so the answer is self-healing: it archives on the 1st, and on the 2nd if the 1st was
#   missed, and does nothing at all for the rest of the month. Idempotent by construction,
#   which also means running it by hand can never create a duplicate or a mess.
#
# WHAT IT ARCHIVES
#   The newest SUCCESSFUL full backup of each user database, taken from msdb.dbo.backupset
#   rather than by globbing the directory - msdb is SQL Server's own record of what it
#   actually wrote, and it survives a rename of the backup folder. A file listed in msdb
#   that is no longer on disk is reported, not silently skipped.
#
# WHAT IT DOES NOT DO
#   It does not shrink retention when the disk fills. Deleting backups because a disk is
#   filling is how you discover, six weeks later, that the month you needed is gone. The
#   disk is yc-guard's job: it raises RED on low free space and somebody decides. Retention
#   here changes only when a human changes -KeepMonths.
#
# LAYOUT
#   <MonthlyDir>\<host>\<instance>\<database>\<database>_MONTHLY_<yyyy-MM>.bak
#   Flat inside the database folder, one file per month, sortable by name.
#
# EXIT CODES
#   0 nothing to do, or archived and verified   1 one or more databases failed
#   2 usage                                     3 SQL unreachable
#   5 not elevated
#
# Log: C:\Scripts\yc-sqlarchive.log, plus the Application event log, source YALLACLOUD.
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'yc-sqlarchive'
$ErrorActionPreference = 'Stop'

$HelpText = @"
yc-sqlarchive - keep ONE full backup per calendar month, for KeepMonths months.

USAGE:
  sql-archive                              archive this month if not already done, then prune
  sql-archive -Report                      show what exists and what would happen. Changes nothing.
  sql-archive -KeepMonths 24               keep two years instead of one
  sql-archive -MonthlyDir D:\monthly       archive to a data volume instead of C:
  sql-archive -InstanceName YCWEB          a named instance
  sql-archive -NoVerify                    skip RESTORE VERIFYONLY on the copy (not advised)
  sql-archive -SelfCheck                   assertions only, no admin needed, changes nothing
  sql-archive -Help

WHAT IT PROVES BEFORE REPORTING SUCCESS:
  1. the source file named in msdb.dbo.backupset still exists on disk
  2. the copy landed and its length matches the source byte for byte
  3. RESTORE VERIFYONLY reads the copy back (unless -NoVerify)
Only then is the month recorded as archived.

RUN IT DAILY. It is idempotent: the second run in a month does nothing. That is what makes
a missed 1st-of-the-month harmless.
"@
if ($Help) { Write-Output $HelpText; Exit-Yc 0 }

# -------------------------------------------------------------------------------------
# helpers
# -------------------------------------------------------------------------------------
function Get-YcArchiveMonthTag([datetime]$When) { return $When.ToString('yyyy-MM') }

function Get-YcArchiveName([string]$Db, [string]$MonthTag) {
  # Keep the database name first so a directory listing sorts by database then month.
  return ($Db + '_MONTHLY_' + $MonthTag + '.bak')
}

function Select-YcArchivesToPrune {
  <#
    Given the archive file names present for one database and how many months to keep,
    return the ones to delete. Newest-first by the yyyy-MM tag embedded in the name, NOT
    by file timestamp - a copy or a restore rewrites the timestamp and would silently
    reorder the set, deleting the wrong month.
  #>
  param([string[]]$Names, [int]$Keep)
  if ($Keep -lt 1) { return @() }
  $parsed = @()
  foreach ($n in $Names) {
    if ($n -match '_MONTHLY_(\d{4}-\d{2})\.bak$') { $parsed += [pscustomobject]@{ Name = $n; Tag = $Matches[1] } }
  }
  $sorted = @($parsed | Sort-Object -Property Tag -Descending)
  if ($sorted.Count -le $Keep) { return @() }
  return @($sorted[$Keep..($sorted.Count - 1)] | ForEach-Object { $_.Name })
}

# -------------------------------------------------------------------------------------
# -SelfCheck: the two pieces of logic that can silently delete the wrong backup
# -------------------------------------------------------------------------------------
if ($SelfCheck) {
  $pass = 0; $fail = 0
  function T($name, $cond) {
    if ($cond) { Write-Output ('ok   ' + $name); $script:pass++ }
    else       { Write-Output ('FAIL ' + $name); $script:fail++ }
  }

  T 'month tag'            ((Get-YcArchiveMonthTag ([datetime]'2026-03-09')) -eq '2026-03')
  T 'archive name'         ((Get-YcArchiveName 'PAYROLL' '2026-03') -eq 'PAYROLL_MONTHLY_2026-03.bak')

  $six = @('D_MONTHLY_2026-01.bak','D_MONTHLY_2026-02.bak','D_MONTHLY_2026-03.bak',
           'D_MONTHLY_2026-04.bak','D_MONTHLY_2026-05.bak','D_MONTHLY_2026-06.bak')
  T 'keep 12 of 6 prunes nothing'   ((Select-YcArchivesToPrune -Names $six -Keep 12).Count -eq 0)
  T 'keep 6 of 6 prunes nothing'    ((Select-YcArchivesToPrune -Names $six -Keep 6).Count  -eq 0)
  $p3 = Select-YcArchivesToPrune -Names $six -Keep 3
  T 'keep 3 of 6 prunes 3'          ($p3.Count -eq 3)
  T 'keep 3 prunes the OLDEST'      (($p3 | Sort-Object) -join ',' -eq 'D_MONTHLY_2026-01.bak,D_MONTHLY_2026-02.bak,D_MONTHLY_2026-03.bak')
  T 'keep 3 keeps the NEWEST'       (-not ($p3 -contains 'D_MONTHLY_2026-06.bak'))

  # order of the INPUT must not matter - a directory listing is not sorted by month
  $shuffled = @('D_MONTHLY_2026-04.bak','D_MONTHLY_2026-01.bak','D_MONTHLY_2026-06.bak',
                'D_MONTHLY_2026-03.bak','D_MONTHLY_2026-05.bak','D_MONTHLY_2026-02.bak')
  T 'input order is irrelevant'     ((((Select-YcArchivesToPrune -Names $shuffled -Keep 3) | Sort-Object) -join ',') -eq 'D_MONTHLY_2026-01.bak,D_MONTHLY_2026-02.bak,D_MONTHLY_2026-03.bak')

  # a year boundary must sort by tag, not lexically-by-accident
  $yr = @('D_MONTHLY_2025-11.bak','D_MONTHLY_2025-12.bak','D_MONTHLY_2026-01.bak')
  T 'year boundary sorts correctly' ((((Select-YcArchivesToPrune -Names $yr -Keep 2) ) -join ',') -eq 'D_MONTHLY_2025-11.bak')

  # anything that is not one of ours is left alone, never deleted
  $mixed = @('D_MONTHLY_2026-01.bak','notes.txt','D_FULL_20260101_010101.bak','D_MONTHLY_2026-02.bak')
  T 'foreign files are never pruned' (((Select-YcArchivesToPrune -Names $mixed -Keep 1) -join ',') -eq 'D_MONTHLY_2026-01.bak')

  T 'Keep 0 is refused, not a wipe'  ((Select-YcArchivesToPrune -Names $six -Keep 0).Count -eq 0)

  Write-Output ''
  Write-Output ('SelfCheck: ' + $pass + ' passed, ' + $fail + ' failed')
  if ($fail -gt 0) { Exit-Yc 1 'SelfCheck FAILED' } else { Exit-Yc 0 'SelfCheck: all checks passed' }
}

Write-YcInvocation
if (-not (Test-YcAdmin)) { Exit-Yc 5 'Administrator is required to write the archive directory.' 'ERROR' }
if ($KeepMonths -lt 1)   { Exit-Yc 2 ('-KeepMonths must be 1 or more. Got ' + $KeepMonths + '. Refusing: 0 would mean "delete every archive".') 'ERROR' }

$server = if ($InstanceName -eq 'MSSQLSERVER') { '.' } else { '.\' + $InstanceName }
$cs     = 'Server=' + $server + ';Database=master;Integrated Security=True;Connect Timeout=20'

function Invoke-YcSqlRows([string]$Tsql) {
  $rows = @()
  $conn = New-Object System.Data.SqlClient.SqlConnection $cs
  $conn.Open()
  try {
    $cmd = $conn.CreateCommand(); $cmd.CommandText = $Tsql; $cmd.CommandTimeout = 600
    $rd  = $cmd.ExecuteReader()
    while ($rd.Read()) {
      $o = @{}
      for ($i = 0; $i -lt $rd.FieldCount; $i++) { $o[$rd.GetName($i)] = $rd.GetValue($i) }
      $rows += [pscustomobject]$o
    }
    $rd.Close()
  } finally { $conn.Close() }
  return $rows
}

try { [void](Invoke-YcSqlRows 'SELECT 1 AS ok') }
catch { Exit-Yc 3 ('cannot reach SQL Server instance ' + $InstanceName + ': ' + $_.Exception.Message) 'ERROR' }

$host_ = $env:COMPUTERNAME
$root  = Join-Path (Join-Path $MonthlyDir $host_) $InstanceName
$month = Get-YcArchiveMonthTag (Get-Date)

# The newest SUCCESSFUL full of each ONLINE user database, with the file it was written to.
$newest = Invoke-YcSqlRows @"
SELECT d.name AS db, x.physical_device_name AS path, b.backup_finish_date AS finished
FROM sys.databases d
CROSS APPLY (
  SELECT TOP 1 bs.media_set_id, bs.backup_finish_date
  FROM msdb.dbo.backupset bs
  WHERE bs.database_name = d.name AND bs.type = 'D' AND bs.is_copy_only = 0
  ORDER BY bs.backup_finish_date DESC
) b
JOIN msdb.dbo.backupmediafamily x ON x.media_set_id = b.media_set_id
WHERE d.database_id > 4 AND d.state = 0 AND d.name <> 'DBA'
"@

$newest = @($newest)
if ($newest.Count -eq 0) {
  Write-YcLog 'no user database has a full backup in msdb yet - nothing to archive. This is normal on a fresh template.' 'INFO'
  Exit-Yc 0 'nothing to archive'
}

$archived = 0; $already = 0; $pruned = 0; $failed = 0
foreach ($r in $newest) {
  $db   = [string]$r.db
  $src  = [string]$r.path
  $dir  = Join-Path $root $db
  $dest = Join-Path $dir (Get-YcArchiveName $db $month)

  if (Test-Path -LiteralPath $dest) {
    Write-YcLog ($db + ': ' + $month + ' already archived.') 'INFO'
    $already++
  }
  elseif ($Report) {
    Write-YcLog ($db + ': WOULD archive ' + $src + ' -> ' + $dest) 'INFO'
  }
  else {
    try {
      if (-not (Test-Path -LiteralPath $src)) {
        # msdb says it wrote this file and the file is gone. That is a real finding, not a skip.
        throw ('the newest full for ' + $db + ' is recorded in msdb as ' + $src + ' but that file does not exist on disk')
      }
      if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
      Copy-Item -LiteralPath $src -Destination $dest -Force
      $sl = (Get-Item -LiteralPath $src).Length
      $dl = (Get-Item -LiteralPath $dest).Length
      if ($sl -ne $dl) { throw ('the copy is ' + $dl + ' bytes but the source is ' + $sl) }
      if (-not $NoVerify) {
        [void](Invoke-YcSqlRows ("RESTORE VERIFYONLY FROM DISK = N'" + ($dest -replace "'", "''") + "'"))
      }
      Write-YcLog ($db + ': archived ' + $month + ' (' + [math]::Round($dl / 1MB, 2) + ' MB' + $(if ($NoVerify) { '' } else { ', VERIFYONLY passed' }) + ')') 'OK'
      $archived++
    } catch {
      Write-YcLog ($db + ': archive FAILED - ' + $_.Exception.Message) 'ERROR'
      Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue
      $failed++
      continue
    }
  }

  # prune - only ever our own <db>_MONTHLY_<yyyy-MM>.bak files, never anything else in the folder
  if (Test-Path -LiteralPath $dir) {
    $names = @(Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
    foreach ($old in (Select-YcArchivesToPrune -Names $names -Keep $KeepMonths)) {
      if ($Report) { Write-YcLog ($db + ': WOULD prune ' + $old) 'INFO' }
      else {
        try { Remove-Item -LiteralPath (Join-Path $dir $old) -Force; Write-YcLog ($db + ': pruned ' + $old) 'INFO'; $pruned++ }
        catch { Write-YcLog ($db + ': could not prune ' + $old + ' - ' + $_.Exception.Message) 'WARN' }
      }
    }
  }
}

# A machine-readable line for whatever collects from these VMs, and for yc-guard.
$summary = [ordered]@{
  host = $host_; instance = $InstanceName; month = $month; root = $root
  databases = $newest.Count; archived = $archived; already = $already
  pruned = $pruned; failed = $failed; keepMonths = $KeepMonths
  utc = (Get-Date).ToUniversalTime().ToString('s') + 'Z'
}
try { $summary | ConvertTo-Json -Compress | Set-Content -Path 'C:\Scripts\yc-sqlarchive.json' -Encoding ascii } catch {}

$msg = ('databases ' + $newest.Count + ', archived ' + $archived + ', already had this month ' + $already + ', pruned ' + $pruned + ', failed ' + $failed)
if ($failed -gt 0) { Exit-Yc 1 $msg 'ERROR' }
Exit-Yc 0 $msg
