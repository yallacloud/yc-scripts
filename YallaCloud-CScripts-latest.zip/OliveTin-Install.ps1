param(
  # ---- names preserved from olivetin-install.cmd and the catalog ----
  [string]$InstallDir = 'C:\Tools\OliveTin',         # where OliveTin.exe and webui\ are placed
  [int]$Port = 1337,                                 # OliveTin web port
  # ---- ADDED in this revision ----
  [switch]$IUnderstandTheRisk,                       # required: see the risk statement below
  [string]$ListenAddress = '127.0.0.1',              # bind address. LOOPBACK BY DEFAULT.
  [switch]$AllowRemote,                              # bind 0.0.0.0 and open a SCOPED inbound rule
  [string[]]$MgmtCidr,                               # required with -AllowRemote
  [string]$ConfigPath = 'C:\ProgramData\OliveTin\config.yaml',
  [string]$ServiceAccount = 'NT AUTHORITY\LocalService',
  [switch]$AllowSystemServiceAccount,                # ADDED: required to run the service as LocalSystem
  [string]$ZipPath,                                  # explicit OliveTin-windows-amd64.zip
  [string]$Url,                                      # download it from here if nothing is staged
  [string]$Sha256,
  [switch]$NoFirewall,
  [switch]$Force,                                    # re-extract over an existing install
  [switch]$Help
)
# =====================================================================================
# OliveTin-Install.ps1 - install OliveTin (a web UI that RUNS PREDEFINED SHELL COMMANDS).
# PowerShell 5.1, ASCII only.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# This file was audited under the same lens as WebJEA (P0-8): it is the same category of
# component - a web UI that executes commands on the host - and it had the same defects.
#
# 1. THE PREMISE WAS OUT OF DATE. Old line 7 asserted "OliveTin ships NO native Windows
#    binary (Linux/container only)" and the whole script was built around staging a Linux
#    tarball. OliveTin now publishes OliveTin-windows-amd64.zip and documents a first-class
#    Windows service mode (serviceHostMode: "winsvc-standard" plus sc.exe create).
#      https://docs.olivetin.app/install/windows.html
#      https://docs.olivetin.app/install/windows_service.html
#    This script now installs the native build properly, and REFUSES the Linux tarball path
#    instead of "staging" a payload that can never run and reporting OK.
#
# 2. THE OLD NATIVE PATH WAS AN UNAUTHENTICATED REMOTE COMMAND RUNNER AS SYSTEM.
#    Old line 52: New-Service ... (no -Credential) -> LocalSystem.
#    Old line 56: New-NetFirewallRule -Profile Any, no -RemoteAddress, on port 1337.
#    Old line 59: "done - OliveTin native service at http://<host>:1337/" 'OK' - printed
#                 without ever checking that the service was running or answering.
#    OliveTin's documented default posture is wide open: "if you do not set a defaultPolicy,
#    then all policies will be set to true by default", i.e. an unauthenticated guest can
#    view AND execute every configured action.
#      https://docs.olivetin.app/security/acl.html
#    OliveTin also has NO TLS of its own - the configuration reference has no certificate
#    or key options at all, and the hardening guidance is "place a reverse proxy in front of
#    OliveTin, or better, a web application firewall".
#      https://docs.olivetin.app/config.html   https://docs.olivetin.app/security/design_choices.html
#    So the old script published a cleartext, unauthenticated command-execution UI running
#    as LocalSystem to every network profile. That is remote code execution as SYSTEM.
#    NOW:
#      * -IUnderstandTheRisk is mandatory.
#      * The listener is 127.0.0.1 BY DEFAULT and NO firewall rule is created. Reaching it
#        remotely is a deliberate act: -AllowRemote plus -MgmtCidr.
#      * -AllowRemote is REFUSED unless the configuration actually enables an authentication
#        method AND closes the default-allow policy. The check is on the config file text.
#      * The service runs as NT AUTHORITY\LocalService by default, not LocalSystem. Choosing
#        LocalSystem is possible but is logged as an ERROR-level warning.
#      * Success requires the service to be Running AND the UI to answer on the loopback.
#      * Any pre-existing unscoped 'OliveTin in <port>' rule from the old script is REMOVED.
#
# 3. Generated configuration is safe by default: guests must log in, default permissions are
#    view:false / exec:false, and no actions are defined. An operator adds users and actions
#    deliberately. (Argon2id password hashes: https://docs.olivetin.app/security/local.html)
#
# ----------------------------- IS THIS SAFE TO SHIP? ---------------------------------
# Only as a loopback-bound, authentication-required, operator-invoked tool behind a TLS
# reverse proxy. NOT as an enabled, network-reachable component of a tenant-facing image:
# OliveTin terminates plain HTTP with no TLS of its own, and its default ACL is allow-all.
# Anything it can run, an unauthenticated caller can run, with the service account's rights.
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was installed. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'olivetin-install'

$Usage = @'
olivetin-install - install OliveTin, a web UI that RUNS PREDEFINED SHELL COMMANDS on this host.
                   Staged payload: C:\Scripts\OliveTin-windows-amd64.zip
                   Log: C:\Scripts\olivetin-install.log

READ THIS BEFORE YOU RUN IT
  OliveTin executes commands as its service account. It has NO TLS of its own (plain HTTP)
  and its documented default ACL allows an UNAUTHENTICATED guest to view and execute every
  configured action. The previous version of this command ran it as LocalSystem and opened
  TCP 1337 inbound on every firewall profile - unauthenticated remote code execution as
  SYSTEM. This version cannot do that:
    - -IUnderstandTheRisk is mandatory.
    - The listener is 127.0.0.1 unless you pass -AllowRemote, and -AllowRemote requires
      -MgmtCidr AND a configuration that actually enables authentication.
    - The service runs as NT AUTHORITY\LocalService by default.
    - Put a TLS-terminating reverse proxy in front of it. OliveTin never speaks TLS itself.

USAGE:
  olivetin-install -IUnderstandTheRisk [-InstallDir C:\Tools\OliveTin] [-Port 1337]
                   [-ConfigPath C:\ProgramData\OliveTin\config.yaml] [-ServiceAccount <acct>]
                   [-ZipPath <zip> | -Url <url> [-Sha256 <hash>]] [-Force]
  olivetin-install -IUnderstandTheRisk -AllowRemote -MgmtCidr 10.20.0.0/24 [-Port 1337]
  olivetin-install -Help

PARAMETERS:
  -IUnderstandTheRisk  MANDATORY. Acknowledges that this publishes command execution.
  -InstallDir          Where OliveTin.exe and webui\ go (default C:\Tools\OliveTin).
                       Upstream uses C:\Program Files\OliveTin; either works.
  -Port                Web port (default 1337).
  -ListenAddress       Bind address (default 127.0.0.1). -AllowRemote sets it to 0.0.0.0.
  -AllowRemote         Bind all interfaces and create a SCOPED inbound rule. Requires
                       -MgmtCidr and a configuration with authentication enabled.
  -MgmtCidr            Management network(s) allowed to reach the port. Required with -AllowRemote.
  -ConfigPath          config.yaml location (default C:\ProgramData\OliveTin\config.yaml, the
                       documented Windows location). A safe default is generated if absent.
  -ServiceAccount      Service account (default NT AUTHORITY\LocalService). LocalSystem /
                       NT AUTHORITY\SYSTEM is REFUSED unless -AllowSystemServiceAccount is
                       also passed - actions run as that account.
  -AllowSystemServiceAccount
                       Explicit opt-in required to run the service as LocalSystem/SYSTEM.
                       Logs a loud WARN. Do not ship this.
  -ZipPath / -Url / -Sha256   Explicit payload, or download it.
  -NoFirewall          Create no firewall rule at all.
  -Force               Re-extract over an existing installation.
  -Help                Show this help and exit.

PROOF OF SUCCESS (nothing below is assumed):
  OliveTin.exe and webui\ present + config.yaml written and read back + the OliveTin service
  created with the requested account and reaching Running + the port actually LISTENING on
  the requested address + an HTTP GET on the loopback returning 200. The old script printed
  "done - OliveTin native service at http://<host>:1337/" without checking any of that.

EXAMPLES:
  olivetin-install -IUnderstandTheRisk
  olivetin-install -IUnderstandTheRisk -Port 1337 -ServiceAccount 'NT AUTHORITY\LocalService'
  olivetin-install -IUnderstandTheRisk -ConfigPath C:\ProgramData\OliveTin\config.yaml
  olivetin-install -IUnderstandTheRisk -AllowRemote -MgmtCidr 10.20.0.0/24
  olivetin-install -IUnderstandTheRisk -Url https://github.com/OliveTin/OliveTin/releases/latest/download/OliveTin-windows-amd64.zip -Sha256 <hash>
  olivetin-install -Help

EXIT CODES:
  0   OliveTin installed, service Running, UI answering on the loopback
  1   generic failure
  2   usage error / refused (no -IUnderstandTheRisk, -AllowRemote without -MgmtCidr or
      without authentication configured, LocalSystem service account without
      -AllowSystemServiceAccount)
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4   payload missing, or it is not the native Windows build
  5   not running as Administrator
  7   the OliveTin service could not be created or is not Running
  8   the service is Running but the UI does not answer / is not listening
  9   the payload download failed

Log: C:\Scripts\olivetin-install.log   (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

if(-not $IUnderstandTheRisk){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 ('REFUSED: -IUnderstandTheRisk was not given. OliveTin is a web UI that executes commands on this host, it has no TLS of its own, and its default ACL permits unauthenticated guests to run every configured action. Nothing was changed.') 'ERROR'
}
if($Port -lt 1 -or $Port -gt 65535){ Exit-Yc 2 ('-Port out of range: ' + $Port) 'ERROR' }

$Cidrs = @()
if($MgmtCidr){
  foreach($c in $MgmtCidr){
    foreach($p in ([string]$c -split ',')){
      $t = $p.Trim()
      if($t){ $Cidrs += $t }
    }
  }
}
if($AllowRemote){
  if($Cidrs.Count -eq 0){
    Exit-Yc 2 'REFUSED: -AllowRemote requires -MgmtCidr. This command does not open a command-execution UI to unnamed networks. Nothing was changed.' 'ERROR'
  }
  foreach($c in $Cidrs){
    if($c -eq 'Any' -or $c -eq '*' -or $c -eq '0.0.0.0/0' -or $c -eq '0.0.0.0'){
      Exit-Yc 2 ('REFUSED: -MgmtCidr contains "' + $c + '", which is every host on the internet. Nothing was changed.') 'ERROR'
    }
  }
  $ListenAddress = '0.0.0.0'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

if($ServiceAccount -match '(?i)^(LocalSystem|NT AUTHORITY\\SYSTEM|\.\\SYSTEM)$'){
  # This used to log ERROR and then carry straight on to sc create obj= LocalSystem and Exit-Yc 0,
  # i.e. it declared unauthenticated RCE as SYSTEM and then installed it while reporting success.
  # A declared refusal must refuse. The default (LocalService) is already safe, so this costs nothing.
  if(-not $AllowSystemServiceAccount){
    Exit-Yc 2 ('REFUSED: -ServiceAccount is ' + $ServiceAccount + '. EVERY action OliveTin runs would run as SYSTEM, and OliveTin has no TLS and an allow-all default ACL - that is unauthenticated remote code execution as SYSTEM the moment the port is reachable. Use the default NT AUTHORITY\LocalService, or a dedicated least-privilege account. Pass -AllowSystemServiceAccount if you genuinely accept that. Nothing was changed.') 'ERROR'
  }
  Write-YcLog ('-AllowSystemServiceAccount was passed with -ServiceAccount ' + $ServiceAccount + '. EVERY action OliveTin runs will run as SYSTEM, and OliveTin has no TLS and an allow-all default ACL. This is unauthenticated remote code execution as SYSTEM the moment the port is reachable. RECORD THIS AS AN ACCEPTED RISK.') 'WARN'
}

# ------------------------------------------------------------------------------------
# 1. Payload. Native Windows build only.
# ------------------------------------------------------------------------------------
$zip = ''
if($ZipPath){
  $zip = $ZipPath
}else{
  $cands = @(Get-ChildItem -Path 'C:\Scripts\*.zip' -ErrorAction SilentlyContinue |
             Where-Object { -not $_.PSIsContainer -and $_.Name -match '(?i)olivetin.*windows' } |
             Sort-Object LastWriteTime -Descending)
  if($cands.Count -gt 0){ $zip = $cands[0].FullName }
}
if(-not $zip -and $Url){
  Assert-YcPrereqs -NeedInternet
  $dest = 'C:\Scripts\OliveTin-windows-amd64.zip'
  $got = Get-YcFile -Uri $Url -OutFile $dest -Sha256 $Sha256 -MinBytes 1MB -Retries 4
  if(-not $got){ Exit-Yc 9 ('could not download the OliveTin payload from ' + $Url) 'ERROR' }
  $zip = $got
}
if(-not $zip){
  $tarball = @(Get-ChildItem -Path 'C:\Scripts\OliveTin-linux-*.tar.gz' -ErrorAction SilentlyContinue)
  if($tarball.Count -gt 0){
    Exit-Yc 4 ('only a LINUX payload is staged (' + $tarball[0].Name + '). The old version of this command "staged" that tarball on a Windows host and reported success, which installed nothing that could ever run. OliveTin now publishes a native Windows build - stage OliveTin-windows-amd64.zip from https://github.com/OliveTin/OliveTin/releases/latest into C:\Scripts, or pass -Url. Nothing was changed.') 'ERROR'
  }
  Exit-Yc 4 'no OliveTin Windows payload found. Stage OliveTin-windows-amd64.zip into C:\Scripts, or pass -ZipPath / -Url. Nothing was changed.' 'ERROR'
}
if(-not (Assert-YcFile -Path $zip -MinBytes 1MB -Because 'OliveTin native Windows build')){
  Exit-Yc 4 ('unusable OliveTin payload: ' + $zip) 'ERROR'
}

$exePath = Join-Path $InstallDir 'OliveTin.exe'
if((Test-Path -LiteralPath $exePath) -and -not $Force){
  Write-YcLog ('OliveTin.exe is already present at ' + $exePath + ' - not re-extracting (use -Force). Configuration and service state are still reconciled below.')
}else{
  try{
    if(-not (Test-Path -LiteralPath $InstallDir)){ New-Item -ItemType Directory -Path $InstallDir -Force -ErrorAction Stop | Out-Null }
    Expand-Archive -LiteralPath $zip -DestinationPath $InstallDir -Force -ErrorAction Stop
  }catch{
    Exit-Yc 4 ('could not expand ' + $zip + ' into ' + $InstallDir + ': ' + $_.Exception.Message) 'ERROR'
  }
}
if(-not (Test-Path -LiteralPath $exePath)){
  # Some archives carry a top-level folder; find the executable and flatten the path we use.
  $found = @(Get-ChildItem -Path $InstallDir -Recurse -Filter 'OliveTin.exe' -ErrorAction SilentlyContinue | Select-Object -First 1)
  if($found.Count -eq 0){
    Exit-Yc 4 ('OliveTin.exe is not present under ' + $InstallDir + ' after extraction - this is not the native Windows build. Nothing is installed.') 'ERROR'
  }
  $exePath   = $found[0].FullName
  $InstallDir = Split-Path -Parent $exePath
}
if(-not (Test-Path -LiteralPath (Join-Path $InstallDir 'webui'))){
  Write-YcLog ('the webui folder is missing from ' + $InstallDir + ' - the UI will not render. Check the payload.') 'WARN'
}
Write-YcLog ('OliveTin binary: ' + $exePath) 'OK'

# ------------------------------------------------------------------------------------
# 2. Configuration. Generated safe-by-default if absent; validated before remote exposure.
# ------------------------------------------------------------------------------------
$cfgDir = Split-Path -Parent $ConfigPath
try{ if(-not (Test-Path -LiteralPath $cfgDir)){ New-Item -ItemType Directory -Path $cfgDir -Force -ErrorAction Stop | Out-Null } }
catch{ Exit-Yc 1 ('could not create ' + $cfgDir + ': ' + $_.Exception.Message) 'ERROR' }

$generated = $false
if(-not (Test-Path -LiteralPath $ConfigPath)){
  $cfg = @'
# config.yaml - generated by olivetin-install (YallaCloud).
# SAFE BY DEFAULT: nothing is exposed and nothing can be executed until an operator
# deliberately adds users and actions below.
#
# OliveTin has NO TLS of its own. If this is ever reachable off-host, terminate TLS on a
# reverse proxy in front of it. See https://docs.olivetin.app/security/design_choices.html
logLevel: "INFO"

# Windows service mode - documented at https://docs.olivetin.app/install/windows_service.html
serviceHostMode: "winsvc-standard"

# Listener. LOOPBACK unless olivetin-install was run with -AllowRemote.
listenAddressSingleHTTPFrontend: "LISTEN_PLACEHOLDER"

# Everyone must log in, and a logged-in user starts with NO permissions.
# Without these two blocks OliveTin's documented default is allow-all for guests:
# https://docs.olivetin.app/security/acl.html
authRequireGuestsToLogin: true

defaultPolicy:
  view: false
  exec: false
  logs: false

# Local users. Passwords are Argon2id hashes - generate one with the OliveTin
# POST /api/PasswordHash endpoint or the argon2 CLI, then add entries here:
#   authLocalUsers:
#     enabled: true
#     users:
#       - username: operator
#         usergroup: admins
#         password: "$argon2id$..."
authLocalUsers:
  enabled: false
  users: []

accessControlLists:
  - name: admins
    matchUsergroups:
      - admins
    permissions:
      view: true
      exec: true
      logs: true

# No actions are defined. Every action you add here can be executed by anyone the ACLs
# above permit, running as the OliveTin service account.
actions: []
'@
  $cfg = $cfg.Replace('LISTEN_PLACEHOLDER',($ListenAddress + ':' + $Port))
  try{ [IO.File]::WriteAllText($ConfigPath,$cfg,(New-Object System.Text.ASCIIEncoding)) }
  catch{ Exit-Yc 1 ('could not write ' + $ConfigPath + ': ' + $_.Exception.Message) 'ERROR' }
  $generated = $true
  Write-YcLog ('generated a safe-by-default ' + $ConfigPath + ': loopback listener, guests must log in, default policy view/exec/logs = false, no actions defined') 'OK'
}else{
  Write-YcLog ('using the existing ' + $ConfigPath + ' - it is NOT rewritten')
}

$cfgText = ''
try{ $cfgText = [string](Get-Content -LiteralPath $ConfigPath -Raw -ErrorAction Stop) }
catch{ Exit-Yc 1 ('could not read back ' + $ConfigPath + ': ' + $_.Exception.Message) 'ERROR' }
if($cfgText -notmatch '(?im)^\s*serviceHostMode\s*:'){
  Write-YcLog ('serviceHostMode is not set in ' + $ConfigPath + ' - OliveTin will not behave as a Windows service. Add: serviceHostMode: "winsvc-standard"') 'WARN'
}
if($cfgText -match '(?im)^\s*listenAddressSingleHTTPFrontend\s*:\s*"?([^"\r\n]+)'){
  Write-YcLog ('config listener: ' + $Matches[1].Trim())
}

# Is <Child> set to true INSIDE the <Parent> block? A flat "-match 'enabled:\s*true'" would
# happily match an 'enabled: true' belonging to some unrelated block, so the child is looked
# for only in the lines indented under the parent. This is the check that decides whether a
# command-execution UI is allowed onto the network, so it does not get to be approximate.
function Test-YcYamlChildTrue{
  param([string]$Text,[string]$Parent,[string]$Child)
  if(-not $Text){ return $false }
  $lines = $Text -split "`r?`n"
  $pIndent = -1
  foreach($l in $lines){
    if($l -match '^(\s*)#'){ continue }
    if($pIndent -lt 0){
      if($l -match ('^(\s*)' + [regex]::Escape($Parent) + '\s*:')){ $pIndent = $Matches[1].Length }
      continue
    }
    if($l.Trim().Length -eq 0){ continue }
    $ind = 0
    if($l -match '^(\s*)'){ $ind = $Matches[1].Length }
    if($ind -le $pIndent){ return $false }          # left the parent block
    if($l -match ('^\s*' + [regex]::Escape($Child) + '\s*:\s*true\s*$')){ return $true }
  }
  return $false
}

# Remote exposure is only allowed if the config actually authenticates somebody.
if($AllowRemote){
  $hasAuth = (Test-YcYamlChildTrue -Text $cfgText -Parent 'authLocalUsers' -Child 'enabled') `
             -or ($cfgText -match '(?im)^\s*authOAuth2') `
             -or ($cfgText -match '(?im)^\s*authHttpHeaderUsername') `
             -or ($cfgText -match '(?im)^\s*authJwt')
  $closed = ($cfgText -match '(?im)^\s*authRequireGuestsToLogin\s*:\s*true') `
            -or ($cfgText -match '(?ims)defaultPolicy\s*:.*?exec\s*:\s*false')
  if(-not $hasAuth -or -not $closed){
    Exit-Yc 2 ('REFUSED: -AllowRemote was requested but ' + $ConfigPath + ' does not both (a) enable an authentication method (authLocalUsers enabled: true, authOAuth2, authHttpHeaderUsername or authJwt) and (b) close the allow-all default (authRequireGuestsToLogin: true or defaultPolicy exec: false). OliveTin''s documented default lets an unauthenticated guest execute every action. Configure authentication first. The service was NOT exposed and no firewall rule was created.' + $(if($generated){' A safe default config was just generated at ' + $ConfigPath + ' - add users to it and re-run.'}else{''})) 'ERROR'
  }
  Write-YcLog 'the configuration enables authentication and closes the default allow-all policy - remote exposure permitted' 'OK'
}

# ------------------------------------------------------------------------------------
# 3. The service. LocalService by default, not LocalSystem.
# ------------------------------------------------------------------------------------
$svcName = 'OliveTin'
$existing = Get-Service -Name $svcName -ErrorAction SilentlyContinue
if($existing){
  try{ Stop-Service -Name $svcName -Force -ErrorAction SilentlyContinue }catch{}
  & sc.exe delete $svcName 2>&1 | Out-Null
  Start-Sleep -Seconds 3
  Write-YcLog ('removed the pre-existing ' + $svcName + ' service so it can be recreated with the requested account')
}

# Grant the service account what it needs, and nothing more.
foreach($p in @($InstallDir,$cfgDir)){
  $rights = 'RX'
  if($p -eq $cfgDir){ $rights = 'M' }
  try{
    # No hand-added quotes: PowerShell quotes a native argument containing spaces itself, and
    # icacls rejects an ACE string that arrives with literal quote characters in it.
    & icacls $p /grant ($ServiceAccount + ':(OI)(CI)' + $rights) 2>&1 | Out-Null
    if($LASTEXITCODE -ne 0){ Write-YcLog ('icacls could not grant ' + $rights + ' on ' + $p + ' to ' + $ServiceAccount + ' (exit ' + $LASTEXITCODE + ')') 'WARN' }
  }catch{
    Write-YcLog ('icacls failed on ' + $p + ': ' + $_.Exception.Message) 'WARN'
  }
}

# sc.exe create <name> binPath= "<exe>" start= auto obj= "<account>"
# https://docs.olivetin.app/install/windows_service.html
$scArgs = @('create',$svcName,'binPath=',('"' + $exePath + '"'),'start=','auto','DisplayName=','OliveTin','obj=',$ServiceAccount)
$scOut = ''
try{ $scOut = (& sc.exe @scArgs 2>&1 | Out-String).Trim() }catch{ $scOut = $_.Exception.Message }
Write-YcLog ('sc.exe create -> ' + ($scOut -replace '[\r\n]+',' '))
if(-not (Get-Service -Name $svcName -ErrorAction SilentlyContinue)){
  Exit-Yc 7 ('the ' + $svcName + ' service could not be created: ' + $scOut + '. Nothing is running and no port was opened.') 'ERROR'
}
try{ & sc.exe description $svcName 'OliveTin - web UI for predefined commands (YallaCloud)' 2>&1 | Out-Null }catch{}

if(-not (Assert-YcService -Name $svcName -TimeoutSec 90 -StartIfStopped -Because 'OliveTin must be running to serve anything')){
  Exit-Yc 7 ('the ' + $svcName + ' service will not start. Check ' + (Join-Path $env:ProgramData 'OliveTin\logs') + ' and ' + $ConfigPath + '. NO firewall rule was created.') 'ERROR'
}

# ------------------------------------------------------------------------------------
# 4. PROVE it is listening where it was told to, and that it answers.
# ------------------------------------------------------------------------------------
$listening = @()
for($i=0; $i -lt 15; $i++){
  try{ $listening = @(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue) }catch{}
  if($listening.Count -gt 0){ break }
  Start-Sleep -Seconds 2
}
if($listening.Count -eq 0){
  Exit-Yc 8 ('the ' + $svcName + ' service is Running but nothing is listening on TCP ' + $Port + '. NO firewall rule was created.') 'ERROR'
}
$addrs = @()
foreach($l in $listening){ if($addrs -notcontains [string]$l.LocalAddress){ $addrs += [string]$l.LocalAddress } }
Write-YcLog ('listening on TCP ' + $Port + ' at ' + ($addrs -join ', ')) 'OK'
if(-not $AllowRemote){
  foreach($a in $addrs){
    if($a -ne '127.0.0.1' -and $a -ne '::1'){
      Write-YcLog ('OliveTin is listening on ' + $a + ':' + $Port + ', which is NOT loopback, even though -AllowRemote was not given. ' + $ConfigPath + ' overrides this script. No firewall rule was created, but check that listenAddressSingleHTTPFrontend is what you intend.') 'WARN'
    }
  }
}

if(-not (Assert-YcHttp -Uri ('http://127.0.0.1:' + $Port + '/') -TimeoutSec 90 -ExpectStatus 200)){
  Exit-Yc 8 ('OliveTin is listening but http://127.0.0.1:' + $Port + '/ did not answer 200. NO firewall rule was created.') 'ERROR'
}

# ------------------------------------------------------------------------------------
# 5. Firewall. Only with -AllowRemote, only scoped - and the old unscoped rule is removed.
# ------------------------------------------------------------------------------------
foreach($old in @('OliveTin in ' + $Port,'OliveTin in 1337')){
  try{
    $ex = Get-NetFirewallRule -DisplayName $old -ErrorAction SilentlyContinue
    if($ex){
      Remove-NetFirewallRule -DisplayName $old -ErrorAction Stop
      Write-YcLog ('removed the pre-existing rule "' + $old + '" (the old version of this script created it on -Profile Any with no -RemoteAddress, in front of an unauthenticated command runner)') 'WARN'
    }
  }catch{
    Write-YcLog ('could not remove the old rule "' + $old + '": ' + $_.Exception.Message) 'WARN'
  }
}

if($NoFirewall -or -not $AllowRemote){
  Write-YcLog 'no inbound rule was created. OliveTin is reachable on the loopback only - put a TLS-terminating reverse proxy in front of it if it needs to be reached from elsewhere.'
}else{
  $rn = 'OliveTin http in ' + $Port
  try{
    New-NetFirewallRule -DisplayName $rn -Direction Inbound -Action Allow -Protocol TCP `
                        -LocalPort $Port -RemoteAddress $Cidrs -Profile Domain,Private -ErrorAction Stop | Out-Null
    Write-YcLog ('inbound allow TCP ' + $Port + ' scoped to ' + ($Cidrs -join ',') + ' on the Domain and Private profiles ONLY (rule "' + $rn + '"). This is PLAIN HTTP - OliveTin has no TLS. Front it with a reverse proxy.') 'WARN'
  }catch{
    Exit-Yc 1 ('OliveTin is running but the SCOPED firewall rule could not be created: ' + $_.Exception.Message + '. Do not replace it with an unscoped rule.') 'ERROR'
  }
}

Exit-Yc 0 ('OliveTin ' + $svcName + ' service Running as ' + $ServiceAccount + ', answering on http://127.0.0.1:' + $Port + '/, config ' + $ConfigPath + ', ' + $(if($AllowRemote){'inbound scoped to ' + ($Cidrs -join ',')}else{'LOOPBACK ONLY (no inbound rule)'}) + '. OliveTin speaks plain HTTP only - never expose it without a TLS reverse proxy and authentication.') 'OK'
