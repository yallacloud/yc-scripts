#!/usr/bin/env bash
# =============================================================================
# deploy-bytebase.sh  -  YallaCloud  -  Bytebase database-DevOps console
# =============================================================================
#
# WHAT THIS IS
#   Deploys and PROVES a pinned, self-hosted Bytebase server as a Docker
#   container on a Linux host (a KVM guest on CloudStack, or a PVE-managed
#   host). Bytebase is a database DevOps platform: schema-migration review and
#   change workflow, SQL review/lint, SQL Editor with query control, RBAC and
#   audit across MySQL, PostgreSQL, SQL Server, Oracle, MongoDB, Snowflake and
#   ~30 other engines.
#
# WHY THIS IS A BASH SCRIPT AND NOT A WINDOWS INSTALLER
#   Because Bytebase HAS NO WINDOWS SERVER DEPLOYMENT. This is not an opinion,
#   it is what the artefacts say:
#
#   1. The published image is Linux-only. The multi-arch manifest for
#      docker.io/bytebase/bytebase:3.21.1 (index digest
#      sha256:6bc68141455da4964f3e469b606955906290602afb1f8fc4c9c584457b053b40,
#      byte-identical to the :latest tag at time of writing) advertises exactly
#      two platforms: linux/amd64 and linux/arm64. There is no windows/amd64
#      manifest, so Windows containers cannot run it at all.
#   2. The vendor says so in prose:
#      "The image only supports linux/amd64 and linux/arm64 architectures."
#      https://docs.bytebase.com/get-started/self-host/deploy-with-docker
#   3. The only documented self-host methods are Docker and Kubernetes (plus an
#      official Helm chart). There is no Windows binary, no MSI, no Windows
#      service, and no bytebase.exe release asset.
#      https://docs.bytebase.com/get-started/self-host/deploy-with-docker
#      https://docs.bytebase.com/get-started/self-host/deploy-with-kubernetes
#
#   Option (b) - "deploy it on Windows via Docker Desktop / Windows containers"
#   was tested against the evidence and REJECTED. A Linux image on Windows only
#   runs inside a WSL2 Linux VM under Docker Desktop; that is a licensed
#   desktop product, needs an interactive user session, cannot be sealed into a
#   Server 2016 golden image, and would make a production database-change
#   console depend on a nested Linux VM inside a Windows VM inside KVM. This
#   estate already runs Linux KVM/PVE hosts. The server goes on Linux.
#
#   The Windows side of this toolkit therefore gets Set-BytebaseClient.ps1,
#   which configures CLIENT access to a server deployed by THIS script and
#   installs no server component whatsoever.
#
# WHAT THIS SCRIPT DELIBERATELY DOES NOT DO
#   - It does NOT terminate TLS. Bytebase has no native HTTPS
#     ("Bytebase service itself does not provide native HTTPS support" -
#     https://docs.bytebase.com/get-started/self-host/external-access ).
#     This estate already runs HAProxy + keepalived with an internal ACME CA,
#     so the script binds Bytebase to LOOPBACK by default and EMITS the correct
#     HAProxy backend stanza (--emit-haproxy) for that existing ingress. It
#     will not install nginx, Caddy, certbot, or any new front door.
#   - It does NOT open a port to the world. Default bind is 127.0.0.1. Any
#     firewall rule it writes is scoped to --mgmt-cidr.
#   - It does NOT install Docker, and it does NOT install PostgreSQL.
#   - It does NOT upgrade across versions silently. A version change is an
#     explicit --allow-upgrade with a proven metadata backup first, because
#     this datastore holds the migration history of every managed database.
#   - It does NOT create Bytebase projects, users, instances or licences. The
#     first-run admin is created in the browser; the licence is uploaded under
#     Settings > Subscription.
#   - It does NOT put the PostgreSQL DSN on a command line, ever.
#
# =============================================================================

set -euo pipefail

SCRIPT_NAME="$(basename "$0")"
LOG_TAG="bytebase-deploy"
LOG_DIR="/var/log/yallacloud"
LOG_FILE="${LOG_DIR}/${LOG_TAG}.log"

# --- Pinned defaults ---------------------------------------------------------
# 3.21.1 is the newest tag published to docker.io/bytebase/bytebase at the time
# this script was written (pushed 2026-08-13). NEVER change this to "latest".
DEFAULT_VERSION="3.21.1"
DEFAULT_VERSION_DIGEST="sha256:6bc68141455da4964f3e469b606955906290602afb1f8fc4c9c584457b053b40"

IMAGE_REPO="bytebase/bytebase"
VERSION="${DEFAULT_VERSION}"
CONTAINER_NAME="bytebase"
BIND_ADDR="127.0.0.1"
HOST_PORT="8080"
CONTAINER_PORT="8080"          # fixed by the image; --port maps the host side
DATA_DIR="/var/lib/bytebase/data"
CONTAINER_DATA_DIR="/var/opt/bytebase"   # documented volume path inside image
BACKUP_DIR="/var/backups/bytebase"
EXTERNAL_URL=""
PG_URL_FILE=""
EXPECT_DIGEST=""
HAPROXY_OUT=""
MGMT_CIDRS=()
HEALTH_TIMEOUT="300"
ALLOW_LATEST="no"
ALLOW_UPGRADE="no"
SKIP_BACKUP="no"
NO_FIREWALL="no"
DIAGNOSE="no"
DRY_RUN="no"

# Runtime state
PG_URL_VALUE=""
ENV_FILE=""
WANT_IMAGE_ID=""
WANT_REPO_DIGEST=""

# --- Logging -----------------------------------------------------------------

_ts() { date '+%Y-%m-%d %H:%M:%S'; }

# redact <string> - masks anything that looks like a DSN password or a secret
# assignment, so no log line can leak the metadata credential.
redact() {
    local s="${1-}"
    # Any scheme's userinfo, not just postgres:// - an --external-url with an
    # embedded credential must be masked in the very message that rejects it.
    s="$(printf '%s' "$s" | sed -E 's#([a-zA-Z][a-zA-Z0-9+.-]*://[^:/@[:space:]]+):[^@[:space:]]*@#\1:****@#g')"
    s="$(printf '%s' "$s" | sed -E 's#([Pp][Gg]_?[Uu][Rr][Ll][[:space:]]*=[[:space:]]*)[^[:space:]]+#\1****#g')"
    s="$(printf '%s' "$s" | sed -E 's#((password|passwd|secret|token|apikey|api_key)[[:space:]]*=[[:space:]]*)[^[:space:];&|]+#\1****#gI')"
    printf '%s' "$s"
}

log() {
    local level="${2:-INFO}" msg
    msg="$(redact "${1-}")"
    local line
    line="$(_ts)  [YALLACLOUD][${LOG_TAG}] [${level}] ${msg}"
    # STDERR on purpose. Log lines must never be captured by a command
    # substitution around a function that also returns a value, and must never
    # contaminate the HAProxy stanza that --emit-haproxy writes to stdout.
    printf '%s\n' "$line" >&2
    if [ -d "$LOG_DIR" ] && [ -w "$LOG_DIR" ]; then
        printf '%s\n' "$line" >> "$LOG_FILE" 2>/dev/null || true
    fi
}

die() {
    local code="${2:-1}"
    log "${1-}" "ERROR"
    log "END exit=${code}" "INFO"
    exit "$code"
}

finish() {
    local code="${1:-0}" msg="${2-}"
    if [ -n "$msg" ]; then
        if [ "$code" -eq 0 ]; then log "$msg" "OK"; else log "$msg" "ERROR"; fi
    fi
    log "END exit=${code}" "INFO"
    exit "$code"
}

cleanup() {
    if [ -n "${ENV_FILE}" ] && [ -f "${ENV_FILE}" ]; then
        rm -f "${ENV_FILE}" 2>/dev/null || true
    fi
}
trap cleanup EXIT

# --- Help --------------------------------------------------------------------

usage() {
cat <<'YC_USAGE_EOF'
=============================================================================
deploy-bytebase.sh - deploy and PROVE a pinned Bytebase server on Docker
=============================================================================

USAGE
  ./deploy-bytebase.sh --external-url <URL> [options]
  ./deploy-bytebase.sh --diagnose
  ./deploy-bytebase.sh --help

  Must run as root on a Linux host that already has Docker (>= 20.10.24).
  Bytebase has NO Windows server build: the published image advertises only
  linux/amd64 and linux/arm64. See the header of this file for the evidence.

PARAMETERS
  --external-url <URL>     REQUIRED. The URL your users actually type, e.g.
                           https://bytebase.corp.example.com
                           This becomes the container's --external-url flag.
                           WHY IT IS REQUIRED AND VALIDATED:
                           Bytebase is deployed behind your HAProxy VIP, so
                           the server never sees the public hostname or the
                           https scheme on its own. Every absolute link it
                           generates - the OAuth/OIDC redirect_uri, SSO and
                           SCIM endpoints, webhook callback URLs, and the
                           links in issue/approval notifications - is built
                           from this value. Leave it wrong or unset and users
                           get mailed http://localhost:8080 links and SSO
                           fails at the redirect. Docs: "the external URL
                           where user visits Bytebase, must start with
                           http:// or https://" and it "is required for SSO
                           and SCIM".
                           Rejected: missing scheme, a path/query component,
                           whitespace. Warned: http:// in production,
                           localhost/127.0.0.1, a trailing slash (stripped).

  --version <TAG>          Image tag to deploy. Default: 3.21.1
                           "latest" is REFUSED unless --allow-latest is also
                           given, and is still logged as a WARN. An unpinned
                           console that silently jumps a major version is how
                           you lose an afternoon.
  --allow-latest           Permit --version latest. Not recommended.
  --expect-digest <sha256:...>
                           Fail if the pulled tag does not resolve to this
                           manifest digest. Supply-chain pin. For the default
                           3.21.1 a known-good digest is built in and any
                           mismatch is reported as a WARN.

  --port <N>               HOST port to publish. Default 8080. The container
                           always listens on 8080 internally.
  --bind <ADDR>            Host address to bind. Default 127.0.0.1.
                           Loopback is the correct answer when HAProxy runs on
                           the same host. Use the internal NIC address only if
                           HAProxy is on a different box, and then
                           --mgmt-cidr becomes mandatory.
  --mgmt-cidr <CIDR>       Management network allowed to reach the port.
                           Repeatable. Required when --bind is not loopback.
                           No rule is ever written for 0.0.0.0/0.
  --no-firewall            Do not touch the firewall; just print what is
                           needed. Use when rules are managed centrally.

  --data <DIR>             Host directory bind-mounted at /var/opt/bytebase.
                           Default /var/lib/bytebase/data. Used by the
                           EMBEDDED PostgreSQL when --pg-url-file is absent.
  --pg-url-file <FILE>     Path to a root-owned 0600 file whose single line is
                           the external PostgreSQL DSN, e.g.
                             postgresql://bytebase:PASSWORD@pg01:5432/bytebase
                           The value is passed to the container through a
                           0600 --env-file as PG_URL and is NEVER placed on a
                           command line, in this log, or in a shell history.
                           Needs PostgreSQL 14+, a UTF-8 database named
                           bytebase, and a bytebase role that owns it.
                           Docs: https://docs.bytebase.com/get-started/self-host/external-postgres

  --container-name <NAME>  Default: bytebase
  --image <REPO>           Default: bytebase/bytebase
  --backup-dir <DIR>       Default /var/backups/bytebase
  --health-timeout <SEC>   Seconds to wait for HTTP 200 on /healthz.
                           Default 300 (the vendor's own Kubernetes liveness
                           probe uses initialDelaySeconds: 300).

  --allow-upgrade          Permit replacing a container that is running a
                           DIFFERENT image than requested. Without this the
                           script refuses and exits 9 rather than surprise you
                           with a version bump.
  --skip-backup            Proceed with an upgrade without a metadata backup.
                           Say this out loud before you use it: the metadata
                           store holds the migration history of every database
                           Bytebase manages.

  --emit-haproxy [FILE]    Print (or write) the HAProxy backend stanza for the
                           EXISTING HAProxy + keepalived pair. This script
                           never terminates TLS itself.
  --diagnose               Install and change NOTHING. Report current state:
                           docker, container, image identity vs requested,
                           health, data dir, backups, firewall, external URL.
  --dry-run                Print the docker command that would run, then stop.
  --help, -h               This text.

EXAMPLES
  # Embedded PostgreSQL, loopback, behind the existing HAProxy VIP
  ./deploy-bytebase.sh --external-url https://bytebase.corp.example.com

  # External PostgreSQL, secret from a file, emit the HAProxy stanza
  install -m 0600 /dev/null /etc/yallacloud/bytebase-pg.url
  printf 'postgresql://bytebase:S3cr3t@pg01.corp:5432/bytebase\n' \
      > /etc/yallacloud/bytebase-pg.url
  ./deploy-bytebase.sh \
      --external-url https://bytebase.corp.example.com \
      --version 3.21.1 \
      --pg-url-file /etc/yallacloud/bytebase-pg.url \
      --emit-haproxy /etc/haproxy/conf.d/bytebase.cfg

  # HAProxy on another host: bind the internal NIC, scope the firewall
  ./deploy-bytebase.sh --external-url https://bytebase.corp.example.com \
      --bind 10.20.0.15 --mgmt-cidr 10.20.0.0/24 --mgmt-cidr 10.20.9.0/24

  # Upgrade 3.20.1 -> 3.21.1 with a proven backup
  ./deploy-bytebase.sh --external-url https://bytebase.corp.example.com \
      --version 3.21.1 --allow-upgrade

  # Read-only state report
  ./deploy-bytebase.sh --diagnose

EXIT CODES
  0   success - container running, /healthz returned 200, running image
      digest matches the requested tag
  1   usage or argument validation error
  2   not running as root
  3   missing dependency (docker, curl, tar)
  4   image pull or digest resolution failed
  5   container did not start or is crash-looping
  6   health endpoint did not return HTTP 200 within --health-timeout
  7   the running container is NOT the requested version
  8   external PostgreSQL secret file is missing, unreadable, or malformed
  9   upgrade refused - a different version is running and --allow-upgrade
      was not supplied
  10  metadata backup failed and --skip-backup was not supplied

LOG
  stdout, and /var/log/yallacloud/bytebase-deploy.log
  Every line is tagged [YALLACLOUD][bytebase-deploy] [LEVEL]. The PostgreSQL
  DSN is redacted on every path that writes.
=============================================================================
YC_USAGE_EOF
}

# --- Argument parsing --------------------------------------------------------

while [ "$#" -gt 0 ]; do
    case "$1" in
        --external-url)    EXTERNAL_URL="${2-}";   shift 2 ;;
        --version)         VERSION="${2-}";        shift 2 ;;
        --allow-latest)    ALLOW_LATEST="yes";     shift ;;
        --expect-digest)   EXPECT_DIGEST="${2-}";  shift 2 ;;
        --port)            HOST_PORT="${2-}";      shift 2 ;;
        --bind)            BIND_ADDR="${2-}";      shift 2 ;;
        --mgmt-cidr)       MGMT_CIDRS+=("${2-}");  shift 2 ;;
        --no-firewall)     NO_FIREWALL="yes";      shift ;;
        --data)            DATA_DIR="${2-}";       shift 2 ;;
        --pg-url-file)     PG_URL_FILE="${2-}";    shift 2 ;;
        --container-name)  CONTAINER_NAME="${2-}"; shift 2 ;;
        --image)           IMAGE_REPO="${2-}";     shift 2 ;;
        --backup-dir)      BACKUP_DIR="${2-}";     shift 2 ;;
        --health-timeout)  HEALTH_TIMEOUT="${2-}"; shift 2 ;;
        --allow-upgrade)   ALLOW_UPGRADE="yes";    shift ;;
        --skip-backup)     SKIP_BACKUP="yes";      shift ;;
        --emit-haproxy)
            if [ "$#" -ge 2 ] && [ -n "${2-}" ] && [ "${2#--}" = "${2}" ]; then
                HAPROXY_OUT="${2}"; shift 2
            else
                HAPROXY_OUT="-"; shift
            fi ;;
        --diagnose)        DIAGNOSE="yes";         shift ;;
        --dry-run)         DRY_RUN="yes";          shift ;;
        -h|--help)         usage; exit 0 ;;
        *) printf 'Unknown argument: %s\n\n' "$1" >&2; usage >&2; exit 1 ;;
    esac
done

IMAGE_REF="${IMAGE_REPO}:${VERSION}"

# --- Preflight ---------------------------------------------------------------

mkdir -p "$LOG_DIR" 2>/dev/null || true
chmod 0750 "$LOG_DIR" 2>/dev/null || true

log "START host=$(hostname) user=$(id -un) script=${SCRIPT_NAME}" "INFO"
log "invocation: $(redact "${SCRIPT_NAME} $*")" "INFO"

if [ "$(id -u)" -ne 0 ]; then
    die "This script must run as root (it manages Docker, /var/lib, and firewall rules)." 2
fi

need_cmd() {
    if ! command -v "$1" >/dev/null 2>&1; then
        die "Required command not found: $1. ${2-}" 3
    fi
}
need_cmd docker "Install Docker Engine 20.10.24 or newer, then re-run."
need_cmd curl   "curl is used to prove the health endpoint answers."
need_cmd tar    "tar is used for the metadata backup on upgrade."

if ! docker info >/dev/null 2>&1; then
    die "The Docker daemon is not reachable. Start it (systemctl start docker) and re-run." 3
fi
log "docker: $(docker --version 2>/dev/null | head -n1)" "INFO"

# --- URL validation ----------------------------------------------------------

# Validates and normalises the global EXTERNAL_URL IN PLACE. It deliberately
# does NOT return the value on stdout: a value-returning function has to be
# called inside $( ), and inside a command substitution `die` would only exit
# the subshell - the error message would be swallowed and the real exit code
# lost. Every rejection below must be able to stop the whole script.
validate_external_url() {
    local u="${EXTERNAL_URL-}"
    [ -n "$u" ] || die "--external-url is REQUIRED. See --help for why it cannot be guessed." 1
    case "$u" in
        *" "*|*$'\t'*) die "--external-url must not contain whitespace: '${u}'" 1 ;;
    esac
    case "$u" in
        http://*|https://*) : ;;
        *) die "--external-url must start with http:// or https:// (got '${u}'). Docs: it 'must start with http:// or https://'." 1 ;;
    esac
    # A userinfo component would put a credential into the container's argv and
    # into every log line that echoes the URL. Reject it, redacted.
    case "${u#*://}" in
        *@*) die "--external-url contains embedded credentials (a user:password@ component): $(redact "$u") . It is an origin, not a credential carrier, and it would land in the container argv where anyone with 'ps' or 'docker inspect' can read it." 1 ;;
    esac
    # Strip a single trailing slash; Bytebase stores the origin.
    while [ "${u%/}" != "$u" ]; do u="${u%/}"; done
    if [ "$u" != "$EXTERNAL_URL" ]; then
        log "stripped the trailing slash from --external-url; using '${u}'" "INFO"
    fi
    local rest="${u#*://}"
    [ -n "$rest" ] || die "--external-url has no host component: '${EXTERNAL_URL}'" 1
    case "$rest" in
        */*) die "--external-url must be scheme://host[:port] only - no path. Got '${EXTERNAL_URL}'. Bytebase stores an origin, and a path here breaks every generated SSO redirect and notification link." 1 ;;
        *\?*|*\#*) die "--external-url must not contain a query or fragment. Got '${EXTERNAL_URL}'." 1 ;;
    esac
    local hostonly="${rest%%:*}"
    [ -n "$hostonly" ] || die "--external-url has an empty hostname: '${EXTERNAL_URL}'" 1
    case "$u" in
        http://*) log "--external-url uses plain http. This estate terminates TLS on HAProxy with the internal ACME CA; users will get mixed-content and insecure-cookie behaviour on http. Use https unless this is a lab." "WARN" ;;
    esac
    case "$hostonly" in
        localhost|127.0.0.1|0.0.0.0|::1)
            log "--external-url host is '${hostonly}'. Every link Bytebase generates (SSO redirect_uri, webhooks, notification links) will point at the loopback of whatever machine renders it. Only acceptable for a throwaway lab." "WARN" ;;
    esac
    EXTERNAL_URL="$u"
}

# --- Image identity ----------------------------------------------------------

resolve_image() {
    log "pulling ${IMAGE_REF} ..." "INFO"
    if ! docker pull "$IMAGE_REF" >/dev/null 2>&1; then
        docker pull "$IMAGE_REF" || true
        die "docker pull ${IMAGE_REF} failed. Check egress to registry-1.docker.io and that the tag exists." 4
    fi
    WANT_IMAGE_ID="$(docker image inspect "$IMAGE_REF" --format '{{.Id}}' 2>/dev/null || true)"
    WANT_REPO_DIGEST="$(docker image inspect "$IMAGE_REF" --format '{{if .RepoDigests}}{{index .RepoDigests 0}}{{end}}' 2>/dev/null || true)"
    [ -n "$WANT_IMAGE_ID" ] || die "Could not resolve the image ID of ${IMAGE_REF} after pulling it." 4
    log "requested ${IMAGE_REF} resolves to image id ${WANT_IMAGE_ID}" "INFO"
    if [ -n "$WANT_REPO_DIGEST" ]; then
        log "requested ${IMAGE_REF} repo digest ${WANT_REPO_DIGEST}" "INFO"
    fi

    local got="${WANT_REPO_DIGEST#*@}"
    if [ -n "$EXPECT_DIGEST" ]; then
        if [ "$got" != "$EXPECT_DIGEST" ]; then
            die "Digest pin FAILED: ${IMAGE_REF} resolved to '${got}' but --expect-digest demanded '${EXPECT_DIGEST}'. The tag was re-pushed or the registry is not what you think it is. Nothing was deployed." 4
        fi
        log "digest pin satisfied: ${got}" "OK"
    elif [ "$VERSION" = "$DEFAULT_VERSION" ] && [ -n "$got" ]; then
        if [ "$got" != "$DEFAULT_VERSION_DIGEST" ]; then
            log "the built-in known digest for ${DEFAULT_VERSION} is ${DEFAULT_VERSION_DIGEST} but this pull resolved ${got}. The tag may have been re-pushed since this script was written. Continuing (use --expect-digest to make this fatal)." "WARN"
        else
            log "digest matches the built-in known-good value for ${DEFAULT_VERSION}" "OK"
        fi
    fi
}

container_exists() { docker inspect "$CONTAINER_NAME" >/dev/null 2>&1; }
container_running_image_id() { docker inspect "$CONTAINER_NAME" --format '{{.Image}}' 2>/dev/null || true; }
container_state() { docker inspect "$CONTAINER_NAME" --format '{{.State.Status}}' 2>/dev/null || printf 'absent'; }
container_external_url() {
    docker inspect "$CONTAINER_NAME" --format '{{range .Args}}{{println .}}{{end}}' 2>/dev/null \
        | grep -A0 -E '^https?://' | head -n1 || true
}
container_uses_external_pg() {
    if docker inspect "$CONTAINER_NAME" --format '{{range .Config.Env}}{{println .}}{{end}}' 2>/dev/null \
        | grep -q '^PG_URL='; then printf 'yes'; else printf 'no'; fi
}

# --- Secret handling ---------------------------------------------------------

load_pg_secret() {
    [ -n "$PG_URL_FILE" ] || return 0
    [ -f "$PG_URL_FILE" ] || die "--pg-url-file '${PG_URL_FILE}' does not exist." 8
    local mode owner
    mode="$(stat -c '%a' "$PG_URL_FILE" 2>/dev/null || printf '')"
    owner="$(stat -c '%U' "$PG_URL_FILE" 2>/dev/null || printf '')"
    if [ -n "$mode" ] && [ "$mode" != "600" ] && [ "$mode" != "400" ]; then
        log "'${PG_URL_FILE}' is mode ${mode}. A metadata DSN must be 0600 root-owned. Tightening it now." "WARN"
        chmod 0600 "$PG_URL_FILE" || true
    fi
    [ "$owner" = "root" ] || log "'${PG_URL_FILE}' is owned by '${owner}', not root." "WARN"

    PG_URL_VALUE="$(head -n1 "$PG_URL_FILE" | tr -d '\r\n')"
    [ -n "$PG_URL_VALUE" ] || die "--pg-url-file '${PG_URL_FILE}' is empty." 8
    case "$PG_URL_VALUE" in
        postgresql://*|postgres://*) : ;;
        *) die "The DSN in '${PG_URL_FILE}' must start with postgresql:// or postgres:// . Value not shown." 8 ;;
    esac
    local hostpart dbname
    hostpart="${PG_URL_VALUE#*@}"; hostpart="${hostpart%%/*}"
    dbname="${PG_URL_VALUE##*/}";  dbname="${dbname%%\?*}"
    [ -n "$hostpart" ] || die "The DSN in '${PG_URL_FILE}' has no host component. Value not shown." 8
    [ -n "$dbname" ]   || die "The DSN in '${PG_URL_FILE}' names no database. Bytebase needs a UTF-8 database (conventionally 'bytebase') for its OWN metadata. Value not shown." 8
    log "external PostgreSQL configured: host=${hostpart} db=${dbname} password=**** (DSN never logged, never on a command line)" "OK"
    if [ "$dbname" != "bytebase" ]; then
        log "the metadata database is named '${dbname}'. The vendor convention is 'bytebase'; this database holds Bytebase's OWN metadata, not a database you manage with it." "WARN"
    fi
}

write_env_file() {
    ENV_FILE="$(mktemp /run/.bytebase-env.XXXXXXXX)"
    chmod 0600 "$ENV_FILE"
    if [ -n "$PG_URL_VALUE" ]; then
        printf 'PG_URL=%s\n' "$PG_URL_VALUE" > "$ENV_FILE"
        log "wrote a 0600 --env-file for PG_URL (removed on exit). The DSN is not an argv element, so it never appears in ps, in the shell history, or in this log." "INFO"
        log "NOTE: 'docker inspect ${CONTAINER_NAME}' will still show PG_URL in .Config.Env - that is inherent to how the image takes the setting. Keep docker group membership restricted." "WARN"
    else
        : > "$ENV_FILE"
    fi
}

# --- Backup ------------------------------------------------------------------

backup_metadata() {
    local reason="${1:-upgrade}"
    mkdir -p "$BACKUP_DIR"
    chmod 0700 "$BACKUP_DIR"
    local stamp; stamp="$(date +%Y%m%d-%H%M%S)"

    if [ "$(container_uses_external_pg)" = "yes" ] || [ -n "$PG_URL_VALUE" ]; then
        if command -v pg_dump >/dev/null 2>&1 && [ -n "$PG_URL_VALUE" ]; then
            local out="${BACKUP_DIR}/bytebase-meta-${stamp}.sql.gz"
            log "backing up the external PostgreSQL metadata database before ${reason} ..." "INFO"
            if PGCONNECT_TIMEOUT=15 pg_dump --dbname="$PG_URL_VALUE" --no-owner --no-privileges 2>/dev/null | gzip -9 > "$out"; then
                if [ -s "$out" ]; then
                    chmod 0600 "$out"
                    log "metadata backup written: ${out} ($(stat -c '%s' "$out") bytes)" "OK"
                    return 0
                fi
            fi
            rm -f "$out" 2>/dev/null || true
            if [ "$SKIP_BACKUP" = "yes" ]; then
                log "pg_dump FAILED but --skip-backup was given. Proceeding without a backup of the migration history." "WARN"
                return 0
            fi
            die "pg_dump of the metadata database FAILED and no backup exists. Refusing to ${reason}. Take a manual dump, or re-run with --skip-backup if you accept losing the migration history on a bad upgrade." 10
        fi
        if [ "$SKIP_BACKUP" = "yes" ]; then
            log "pg_dump is not installed; --skip-backup given, proceeding. Back up the metadata database out of band." "WARN"
            return 0
        fi
        die "This deployment uses external PostgreSQL and pg_dump is not installed, so no backup can be taken. Install postgresql-client, or re-run with --skip-backup. Refusing to ${reason} unbacked - this database holds the migration history of every managed instance." 10
    fi

    # Embedded PostgreSQL: the vendor's documented method is to copy the data
    # directory WHILE STOPPED. https://docs.bytebase.com/get-started/self-host/upgrade
    if [ ! -d "$DATA_DIR" ]; then
        log "no data directory at ${DATA_DIR} yet - nothing to back up." "INFO"
        return 0
    fi
    if [ "$(container_state)" = "running" ]; then
        die "Internal error: refusing to archive ${DATA_DIR} while the container is running. A copy taken from a running instance captures PostgreSQL mid-write and may not restore." 10
    fi
    local out="${BACKUP_DIR}/bytebase-data-${stamp}.tar.gz"
    log "archiving the embedded-PostgreSQL data directory ${DATA_DIR} before ${reason} (container is stopped) ..." "INFO"
    if tar czf "$out" -C "$DATA_DIR" . 2>/dev/null && [ -s "$out" ]; then
        chmod 0600 "$out"
        log "metadata backup written: ${out} ($(stat -c '%s' "$out") bytes). Restore with: tar xzf <file> -C ${DATA_DIR} (as root, to preserve ownership)." "OK"
        return 0
    fi
    rm -f "$out" 2>/dev/null || true
    if [ "$SKIP_BACKUP" = "yes" ]; then
        log "tar of ${DATA_DIR} FAILED but --skip-backup was given. Proceeding unbacked." "WARN"
        return 0
    fi
    die "Backup of ${DATA_DIR} FAILED. Refusing to ${reason}." 10
}

# --- Firewall ----------------------------------------------------------------

configure_firewall() {
    if [ "$BIND_ADDR" = "127.0.0.1" ] || [ "$BIND_ADDR" = "localhost" ] || [ "$BIND_ADDR" = "::1" ]; then
        log "bound to ${BIND_ADDR}:${HOST_PORT} - not reachable off-box, so no firewall rule is needed. HAProxy on this host connects over loopback." "OK"
        return 0
    fi
    if [ "${#MGMT_CIDRS[@]}" -eq 0 ]; then
        die "--bind ${BIND_ADDR} exposes the console off-box but no --mgmt-cidr was given. This script will not world-open a database DevOps console. Supply --mgmt-cidr, or bind to 127.0.0.1." 1
    fi
    if [ "$NO_FIREWALL" = "yes" ]; then
        log "--no-firewall: not touching the firewall. Rules required for ${MGMT_CIDRS[*]} -> ${BIND_ADDR}:${HOST_PORT}/tcp must exist centrally." "WARN"
        return 0
    fi
    local c
    if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
        for c in "${MGMT_CIDRS[@]}"; do
            local rule="rule family=ipv4 source address=${c} port port=${HOST_PORT} protocol=tcp accept"
            if firewall-cmd --permanent --query-rich-rule="$rule" >/dev/null 2>&1; then
                log "firewalld rich rule already present for ${c}:${HOST_PORT}/tcp" "OK"
            else
                firewall-cmd --permanent --add-rich-rule="$rule" >/dev/null 2>&1 \
                    && log "firewalld: allowed ${c} -> ${HOST_PORT}/tcp" "OK" \
                    || log "firewalld: FAILED to add the rule for ${c}" "WARN"
            fi
        done
        firewall-cmd --reload >/dev/null 2>&1 || true
        return 0
    fi
    if command -v ufw >/dev/null 2>&1 && ufw status >/dev/null 2>&1; then
        for c in "${MGMT_CIDRS[@]}"; do
            if ufw status | grep -q "${HOST_PORT}.*${c}"; then
                log "ufw rule already present for ${c}:${HOST_PORT}/tcp" "OK"
            else
                ufw allow from "$c" to any port "$HOST_PORT" proto tcp >/dev/null 2>&1 \
                    && log "ufw: allowed ${c} -> ${HOST_PORT}/tcp" "OK" \
                    || log "ufw: FAILED to add the rule for ${c}" "WARN"
            fi
        done
        return 0
    fi
    log "no firewalld or ufw detected. Add these rules yourself and add NOTHING wider:" "WARN"
    for c in "${MGMT_CIDRS[@]}"; do
        log "  iptables -A INPUT -p tcp -s ${c} --dport ${HOST_PORT} -j ACCEPT" "WARN"
    done
    log "  iptables -A INPUT -p tcp --dport ${HOST_PORT} -j DROP" "WARN"
}

# --- HAProxy snippet ---------------------------------------------------------

emit_haproxy() {
    local host_for_backend="$BIND_ADDR"
    [ "$host_for_backend" = "0.0.0.0" ] && host_for_backend="127.0.0.1"
    local fqdn="${EXTERNAL_URL#*://}"; fqdn="${fqdn%%:*}"
    local tmp; tmp="$(mktemp)"
cat > "$tmp" <<HAP
# =============================================================================
# YallaCloud - HAProxy backend for Bytebase ${VERSION}
# Generated by deploy-bytebase.sh on $(date '+%Y-%m-%d %H:%M:%S')
#
# TLS IS TERMINATED HERE, NOT BY BYTEBASE.
#   "Bytebase service itself does not provide native HTTPS support. We
#    recommend using a reverse proxy ... for Docker deployments."
#   https://docs.bytebase.com/get-started/self-host/external-access
# Use the existing keepalived VIP and the internal ACME CA certificate for
# ${fqdn}. Do NOT stand up a second ingress for this service.
#
# The container is published on ${host_for_backend}:${HOST_PORT} and the
# server was started with --external-url ${EXTERNAL_URL}. If you change the
# frontend hostname you MUST re-run deploy-bytebase.sh with the new
# --external-url, or SSO redirects and notification links will point at the
# old name.
# =============================================================================

# --- add these two lines to your EXISTING https frontend ---------------------
#   acl  host_bytebase  hdr(host) -i ${fqdn}
#   use_backend be_bytebase if host_bytebase

backend be_bytebase
    mode http
    balance roundrobin

    # SQL Editor autocomplete and admin mode use WebSocket on
    # /v1:adminExecute and /lsp. Without a long tunnel timeout the editor
    # drops every 30-60s. The vendor's nginx sample sets 3600s.
    timeout tunnel  3600s
    timeout server  3600s
    timeout connect 5s

    # Bytebase builds absolute URLs from --external-url, but these headers keep
    # proxy-aware middleware honest about the original scheme and port.
    http-request set-header X-Forwarded-Proto https
    http-request set-header X-Forwarded-Port  443

    # Liveness. /healthz is the same endpoint the vendor uses as the
    # Kubernetes livenessProbe.
    # https://docs.bytebase.com/get-started/self-host/deploy-with-kubernetes
    option httpchk
    http-check send meth GET uri /healthz
    http-check expect status 200
    # HAProxy < 2.2 syntax instead of the two lines above:
    #   option httpchk GET /healthz

    server bytebase1 ${host_for_backend}:${HOST_PORT} check inter 10s fall 3 rise 2
HAP
    if [ "$HAPROXY_OUT" = "-" ]; then
        printf '\n'; cat "$tmp"; printf '\n'
        log "HAProxy backend stanza printed above. This script did not install or reload HAProxy." "OK"
    else
        install -m 0640 "$tmp" "$HAPROXY_OUT"
        log "HAProxy backend stanza written to ${HAPROXY_OUT}. Validate and reload yourself: haproxy -c -f /etc/haproxy/haproxy.cfg && systemctl reload haproxy" "OK"
    fi
    rm -f "$tmp"
}

# --- Proof -------------------------------------------------------------------

probe_host() {
    if [ "$BIND_ADDR" = "0.0.0.0" ] || [ "$BIND_ADDR" = "::" ]; then printf '127.0.0.1'
    else printf '%s' "$BIND_ADDR"; fi
}

http_status() {
    curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$1" 2>/dev/null || printf '000'
}

prove_deployment() {
    local base="http://$(probe_host):${HOST_PORT}"

    # 1. The container is actually running and not crash-looping.
    local st restarting
    st="$(container_state)"
    restarting="$(docker inspect "$CONTAINER_NAME" --format '{{.State.Restarting}}' 2>/dev/null || printf 'unknown')"
    if [ "$st" != "running" ]; then
        log "container '${CONTAINER_NAME}' state is '${st}', not 'running'. Last 40 log lines:" "ERROR"
        docker logs --tail 40 "$CONTAINER_NAME" 2>&1 | sed 's/^/    /' || true
        finish 5 "Deployment FAILED: the container is not running."
    fi
    if [ "$restarting" = "true" ]; then
        log "container '${CONTAINER_NAME}' is in a restart loop. Last 40 log lines:" "ERROR"
        docker logs --tail 40 "$CONTAINER_NAME" 2>&1 | sed 's/^/    /' || true
        finish 5 "Deployment FAILED: the container is crash-looping."
    fi
    log "container '${CONTAINER_NAME}' state=running restarting=false" "OK"

    # 2. The running image IS the requested version. This is the check that
    #    cannot be faked by a zero exit code from docker run.
    local run_id; run_id="$(container_running_image_id)"
    if [ -z "$run_id" ] || [ "$run_id" != "$WANT_IMAGE_ID" ]; then
        log "VERSION MISMATCH: the running container uses image id '${run_id}' but ${IMAGE_REF} is '${WANT_IMAGE_ID}'." "ERROR"
        finish 7 "Deployment FAILED: the running container is not ${IMAGE_REF}."
    fi
    log "version proof: running image id ${run_id} == ${IMAGE_REF} (${WANT_REPO_DIGEST:-no repo digest recorded})" "OK"

    # 3. /healthz answers HTTP 200. Documented as the vendor's own liveness
    #    probe: https://docs.bytebase.com/get-started/self-host/deploy-with-kubernetes
    local waited=0 code=000
    log "waiting up to ${HEALTH_TIMEOUT}s for ${base}/healthz to return 200 ..." "INFO"
    while [ "$waited" -lt "$HEALTH_TIMEOUT" ]; do
        code="$(http_status "${base}/healthz")"
        [ "$code" = "200" ] && break
        sleep 5; waited=$((waited + 5))
    done
    if [ "$code" != "200" ]; then
        log "${base}/healthz returned '${code}' after ${waited}s, not 200. Last 40 log lines:" "ERROR"
        docker logs --tail 40 "$CONTAINER_NAME" 2>&1 | sed 's/^/    /' || true
        finish 6 "Deployment FAILED: the health endpoint never returned 200."
    fi
    log "${base}/healthz returned 200 after ${waited}s" "OK"

    # 4. The UI root actually serves.
    local rootcode; rootcode="$(http_status "${base}/")"
    if [ "$rootcode" = "200" ]; then
        log "${base}/ returned 200 - the console is serving" "OK"
    else
        log "${base}/ returned '${rootcode}'. /healthz is green, so the server is up, but the console root did not answer 200." "WARN"
    fi

    # 5. Best-effort corroboration from the server's own version report. This
    #    endpoint is not in the published docs, so a miss is INFO, not a
    #    failure - the image-id comparison in step 2 is the authority.
    local info; info="$(curl -s --max-time 10 "${base}/v1/actuator/info" 2>/dev/null || printf '')"
    if printf '%s' "$info" | grep -q '"version"'; then
        local rv; rv="$(printf '%s' "$info" | sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)"
        if [ -n "$rv" ] && [ "$rv" = "$VERSION" ]; then
            log "server self-reports version '${rv}', matching the requested tag" "OK"
        elif [ -n "$rv" ]; then
            log "server self-reports version '${rv}' but the requested tag was '${VERSION}'. The image-id proof above passed, so treat this as a tag/build-label discrepancy and investigate before trusting the console." "WARN"
        fi
    else
        log "the server did not return a parseable version document at /v1/actuator/info (undocumented endpoint). Version is proven by the image-id comparison above." "INFO"
    fi
}

# --- Diagnose ----------------------------------------------------------------

do_diagnose() {
    log "DIAGNOSE MODE - nothing will be installed, started, stopped, or changed." "INFO"
    log "docker: $(docker --version 2>/dev/null | head -n1)" "INFO"
    log "requested tag for comparison: ${IMAGE_REF}" "INFO"

    local st; st="$(container_state)"
    log "container '${CONTAINER_NAME}': ${st}" "INFO"
    if [ "$st" = "absent" ]; then
        log "no Bytebase container on this host. Deploy with: ${SCRIPT_NAME} --external-url https://bytebase.example.com" "WARN"
    else
        local run_id local_id started restarts
        run_id="$(container_running_image_id)"
        local_id="$(docker image inspect "$IMAGE_REF" --format '{{.Id}}' 2>/dev/null || printf 'not-pulled')"
        started="$(docker inspect "$CONTAINER_NAME" --format '{{.State.StartedAt}}' 2>/dev/null || printf '?')"
        restarts="$(docker inspect "$CONTAINER_NAME" --format '{{.RestartCount}}' 2>/dev/null || printf '?')"
        log "  running image id : ${run_id}" "INFO"
        log "  ${IMAGE_REF} local image id : ${local_id}" "INFO"
        if [ "$local_id" != "not-pulled" ] && [ "$run_id" = "$local_id" ]; then
            log "  the running container IS ${IMAGE_REF}" "OK"
        elif [ "$local_id" = "not-pulled" ]; then
            log "  ${IMAGE_REF} is not present locally, so no comparison is possible without pulling (diagnose does not pull)." "WARN"
        else
            log "  the running container is NOT ${IMAGE_REF}" "WARN"
        fi
        log "  started at: ${started}  restart count: ${restarts}" "INFO"
        log "  image tags on the running image: $(docker inspect "$CONTAINER_NAME" --format '{{.Config.Image}}' 2>/dev/null || printf '?')" "INFO"
        log "  configured external URL: $(container_external_url || printf '(none found in args)')" "INFO"
        log "  metadata store: $( [ "$(container_uses_external_pg)" = "yes" ] && printf 'external PostgreSQL (PG_URL set; value not shown)' || printf 'embedded PostgreSQL in the mounted data directory' )" "INFO"
        log "  published ports: $(docker inspect "$CONTAINER_NAME" --format '{{json .NetworkSettings.Ports}}' 2>/dev/null || printf '?')" "INFO"

        local base="http://$(probe_host):${HOST_PORT}"
        log "  ${base}/healthz -> HTTP $(http_status "${base}/healthz")" "INFO"
        log "  ${base}/        -> HTTP $(http_status "${base}/")" "INFO"
    fi

    if [ -d "$DATA_DIR" ]; then
        log "data dir ${DATA_DIR}: $(du -sh "$DATA_DIR" 2>/dev/null | cut -f1) used" "INFO"
    else
        log "data dir ${DATA_DIR} does not exist" "INFO"
    fi
    if [ -d "$BACKUP_DIR" ]; then
        local n; n="$(find "$BACKUP_DIR" -maxdepth 1 -type f -name 'bytebase-*' 2>/dev/null | wc -l)"
        log "backups in ${BACKUP_DIR}: ${n}" "INFO"
        find "$BACKUP_DIR" -maxdepth 1 -type f -name 'bytebase-*' -printf '    %f  %s bytes  %TY-%Tm-%Td\n' 2>/dev/null | tail -n 5 || true
        [ "$n" -eq 0 ] && log "NO metadata backups exist. This datastore holds the migration history of every managed database." "WARN"
    else
        log "backup dir ${BACKUP_DIR} does not exist - NO metadata backups have ever been taken here." "WARN"
    fi

    if [ -n "$PG_URL_FILE" ] && [ -f "$PG_URL_FILE" ]; then
        log "pg url file ${PG_URL_FILE}: mode $(stat -c '%a' "$PG_URL_FILE") owner $(stat -c '%U' "$PG_URL_FILE") (contents never shown)" "INFO"
    fi

    if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
        log "firewalld rich rules mentioning port ${HOST_PORT}:" "INFO"
        firewall-cmd --list-rich-rules 2>/dev/null | grep "port=\"${HOST_PORT}\"" | sed 's/^/    /' || log "    (none)" "INFO"
    elif command -v ufw >/dev/null 2>&1 && ufw status >/dev/null 2>&1; then
        log "ufw rules mentioning port ${HOST_PORT}:" "INFO"
        ufw status 2>/dev/null | grep "${HOST_PORT}" | sed 's/^/    /' || log "    (none)" "INFO"
    else
        log "no firewalld/ufw detected; cannot report firewall state." "INFO"
    fi
    finish 0 "Diagnose complete. Nothing was changed."
}

# --- Main --------------------------------------------------------------------

if [ "$DIAGNOSE" = "yes" ]; then
    do_diagnose
fi

validate_external_url
log "external URL validated: ${EXTERNAL_URL}" "OK"

if [ "$VERSION" = "latest" ] && [ "$ALLOW_LATEST" != "yes" ]; then
    die "--version latest is refused. Pin a tag (default ${DEFAULT_VERSION}) so that a re-run cannot silently jump versions on a console holding your migration history. Pass --allow-latest only if you truly mean it." 1
fi
[ "$VERSION" = "latest" ] && log "deploying the MOVING tag 'latest'. A future re-run of this identical command may deploy a different build." "WARN"

case "$HOST_PORT" in ''|*[!0-9]*) die "--port must be a number, got '${HOST_PORT}'" 1 ;; esac
case "$HEALTH_TIMEOUT" in ''|*[!0-9]*) die "--health-timeout must be a number, got '${HEALTH_TIMEOUT}'" 1 ;; esac

load_pg_secret

if [ -n "$PG_URL_VALUE" ]; then
    log "metadata store: EXTERNAL PostgreSQL (PG_URL). The --data mount is still created but the embedded PostgreSQL will not be used." "INFO"
else
    log "metadata store: EMBEDDED PostgreSQL under ${DATA_DIR} -> ${CONTAINER_DATA_DIR}. Fine for a single node; HA requires external PostgreSQL." "INFO"
fi

resolve_image

# --- Idempotency and upgrade gate -------------------------------------------
NEED_RECREATE="yes"
if container_exists; then
    RUN_ID="$(container_running_image_id)"
    ST="$(container_state)"
    if [ "$RUN_ID" = "$WANT_IMAGE_ID" ] && [ "$ST" = "running" ]; then
        log "container '${CONTAINER_NAME}' is already running exactly ${IMAGE_REF}. Not recreating - re-running only re-proves the deployment." "OK"
        NEED_RECREATE="no"
    elif [ "$RUN_ID" = "$WANT_IMAGE_ID" ]; then
        log "container '${CONTAINER_NAME}' is the right version but state is '${ST}'. Starting it." "WARN"
        if [ "$DRY_RUN" = "yes" ]; then finish 0 "--dry-run: would run 'docker start ${CONTAINER_NAME}'."; fi
        docker start "$CONTAINER_NAME" >/dev/null 2>&1 || die "docker start ${CONTAINER_NAME} failed." 5
        NEED_RECREATE="no"
    else
        CUR_TAG="$(docker inspect "$CONTAINER_NAME" --format '{{.Config.Image}}' 2>/dev/null || printf 'unknown')"
        if [ "$ALLOW_UPGRADE" != "yes" ]; then
            die "Container '${CONTAINER_NAME}' is running '${CUR_TAG}' (image id ${RUN_ID}) but you asked for ${IMAGE_REF} (${WANT_IMAGE_ID}). REFUSING to replace it. This is a version change on a datastore that holds your migration history. Re-run with --allow-upgrade to take a backup and proceed, or with --version ${CUR_TAG##*:} to leave it alone." 9
        fi
        log "UPGRADE: '${CUR_TAG}' -> '${IMAGE_REF}'. Stopping the container so the metadata can be backed up cleanly." "WARN"
        if [ "$DRY_RUN" = "yes" ]; then finish 0 "--dry-run: would back up, then replace ${CUR_TAG} with ${IMAGE_REF}."; fi
        docker stop "$CONTAINER_NAME" >/dev/null 2>&1 || log "docker stop returned non-zero; continuing to the backup check." "WARN"
        backup_metadata "upgrade"
        docker rm "$CONTAINER_NAME" >/dev/null 2>&1 || die "Could not remove the old container '${CONTAINER_NAME}'." 5
        log "old container removed. The data directory ${DATA_DIR} was NOT touched - it is a host bind mount and survives the replacement, which is exactly how the vendor's upgrade path works." "INFO"
    fi
fi

if [ "$NEED_RECREATE" = "yes" ]; then
    mkdir -p "$DATA_DIR"
    chmod 0750 "$DATA_DIR" 2>/dev/null || true
    write_env_file

    DOCKER_ARGS=(
        run -d
        --name "$CONTAINER_NAME"
        --init
        --restart unless-stopped
        --env-file "$ENV_FILE"
        --publish "${BIND_ADDR}:${HOST_PORT}:${CONTAINER_PORT}"
        --volume "${DATA_DIR}:${CONTAINER_DATA_DIR}"
        "$IMAGE_REF"
        --data "$CONTAINER_DATA_DIR"
        --port "$CONTAINER_PORT"
        --external-url "$EXTERNAL_URL"
    )

    log "docker run -d --name ${CONTAINER_NAME} --init --restart unless-stopped --env-file <0600 tmpfile: PG_URL=****> --publish ${BIND_ADDR}:${HOST_PORT}:${CONTAINER_PORT} --volume ${DATA_DIR}:${CONTAINER_DATA_DIR} ${IMAGE_REF} --data ${CONTAINER_DATA_DIR} --port ${CONTAINER_PORT} --external-url ${EXTERNAL_URL}" "INFO"

    if [ "$DRY_RUN" = "yes" ]; then
        finish 0 "--dry-run: the command above is what would run. Nothing was changed."
    fi

    if ! docker "${DOCKER_ARGS[@]}" >/dev/null 2>&1; then
        docker "${DOCKER_ARGS[@]}" 2>&1 | sed 's/^/    /' || true
        die "docker run failed for ${IMAGE_REF}. Nothing is deployed." 5
    fi
    log "container created from ${IMAGE_REF}" "INFO"
fi

cleanup
ENV_FILE=""

configure_firewall
prove_deployment

if [ -n "$HAPROXY_OUT" ]; then
    emit_haproxy
else
    log "TLS: this script terminated nothing. Bytebase has no native HTTPS. Publish it through the existing HAProxy + keepalived VIP with the internal ACME CA certificate - run again with --emit-haproxy to get the exact backend stanza." "INFO"
fi

log "console (through the reverse proxy): ${EXTERNAL_URL}" "INFO"
log "licence: the Community plan is free for up to 20 users and 10 instances; SSO/OIDC/LDAP, approval workflow, dynamic data masking, custom roles and HA are Enterprise-gated and are uploaded under Settings > Subscription. See BYTEBASE-NOTES.md before reselling access to tenants." "INFO"
finish 0 "Bytebase ${VERSION} deployed and PROVEN: container running, image id matches ${IMAGE_REF}, /healthz returned 200."
