param(
  [string]$Tenant,   # optional: CloudStack domain, or a full tag with a dot (infra.<role>). Default: found automatically
  [switch]$Report,   # say what would happen, change nothing
  [switch]$Status,   # show this machine's GLPI agent: service, server, tag, last inventory
  [string]$SetupUrl = 'https://repo.oasisstack.io/glpi/glpi-agent-setup.ps1',
  [switch]$Help
)
# =====================================================================================
# Glpi-Join.ps1 - put this Windows server in GLPI (https://glpi.oasisstack.io). The C:\Scripts
# front door to the estate's GLPI kit (STACK4-66, glpi-agent-setup.ps1): the SAME script L1 runs
# by hand, so there is one way to install the agent, not two.
# PowerShell 5.1, ASCII only. Used by the adopt script (phase GLPI) and by hand.
#
# THE PASSWORD IS NEVER A PARAMETER. Parameters land in the PowerShell history, the process list
# and this command's transcript. It comes from the environment, set on the line before:
#     $env:GLPI_AGENT_PASSWORD = '<password manager: GLPI agent glpi-agent>'
# and is handed to the kit through the environment, never on its command line.
#
# The tenant is found automatically (VM UUID / MAC -> repo.oasisstack.io/salt/who, published by
# the Salt master from CloudStack). The kit sets the tag <domain>.cs.kvm / <domain>.cs.vcenter,
# which puts the server in its tenant's GLPI entity. Our own servers: -Tenant infra.<role>.
#
# REPORTING: this command reports for the kit - vm.glpi.registered | waiting | failed to the ERP
# webhook, the second webhook, ntfy and the milestone journal (_yc-lib.ps1, WEBHOOK MILESTONES).
# The kit's own ntfy and webhook posts are switched off for the child run so nothing arrives twice.
#
# Exit codes are the kit's: 0 registered | 1 not admin | 2 password missing / bad tag |
#   3 download failed | 5 installer failed | 7 agent did not run | 8 VM not known to CloudStack.
#   This command adds 4: the kit could not be fetched or is not the kit.
# =====================================================================================
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){ Write-Host 'FATAL: C:\Scripts\_yc-lib.ps1 missing - payload incomplete' -ForegroundColor Red; exit 3 }
. $YcLib
Start-YcLog 'glpi-join'

if($Help){
@"
glpi-join  -  put this server in GLPI (https://glpi.oasisstack.io). Only the agent password.

USAGE:
  `$env:GLPI_AGENT_PASSWORD = '<password>'      on the line BEFORE, never as an option
  glpi-join                         install / repair the agent, tenant found automatically
  glpi-join -Tenant infra.mgmt-wsus our own server: give its role tag
  glpi-join -Status                 agent service, GLPI server, tag, last inventory
  glpi-join -Report                 say what would happen, change nothing

PARAMETERS:
  -Tenant    CloudStack domain (e.g. chapp) or a full tag with a dot (infra.<role>).
             Default: looked up from this VM's UUID / MAC, like the Salt join.
  -Status    read-only: what is installed and where it reports
  -Report    read-only: checks the password is set and the kit can be fetched
  -SetupUrl  the kit (default https://repo.oasisstack.io/glpi/glpi-agent-setup.ps1)
  -Help      this text

EXAMPLES:
  `$env:GLPI_AGENT_PASSWORD = '<password>'; glpi-join
  `$env:GLPI_AGENT_PASSWORD = '<password>'; glpi-join -Tenant infra.mgmt-wsus
  glpi-join -Status

RESULTS (exit code):
  0 REGISTERED  inventory sent; it reports again once a day by itself
  8 WAITING     VM not known to CloudStack: our server -> -Tenant infra.<role>
  2 FAILED      password missing or bad tag        3 / 4  the kit or agent could not be fetched
  5 FAILED      the agent installer failed         7      the agent did not reach GLPI (port 443)
  Every result is also in C:\ProgramData\YallaCloud\logs\yc-milestones.log (search YC-FAILED).
Log: C:\Scripts\glpi-join.log   Kit log: C:\ProgramData\YallaCloud\logs\yallacloud.log
"@ | Write-Host
  Exit-Yc 0
}

$Work = Join-Path $env:ProgramData 'YallaCloud\glpi'
$Kit  = Join-Path $Work 'glpi-agent-setup.ps1'

function Get-GlpiAgentState {
  $s = [ordered]@{ installed = $false; status = 'absent'; server = ''; tag = ''; version = ''; lastRun = '' }
  $svc = Get-Service -Name 'glpi-agent' -ErrorAction SilentlyContinue
  if($svc){ $s.installed = $true; $s.status = [string]$svc.Status }
  foreach($k in 'HKLM:\SOFTWARE\GLPI-Agent','HKLM:\SOFTWARE\WOW6432Node\GLPI-Agent'){
    try{
      if(Test-Path -LiteralPath $k){
        $p = Get-ItemProperty -LiteralPath $k -ErrorAction Stop
        if($p.server){ $s.server = ([string]$p.server -replace '//[^/@]*@','//') }   # never echo embedded credentials
        if($p.tag){ $s.tag = [string]$p.tag }
        break
      }
    }catch{}
  }
  try{
    $exe = Get-Item -LiteralPath 'C:\Program Files\GLPI-Agent\glpi-agent.bat' -ErrorAction Stop
    $s.installed = $true
  }catch{}
  try{
    $l = Get-Item -LiteralPath 'C:\Program Files\GLPI-Agent\logs\glpi-agent.log' -ErrorAction Stop
    $s.lastRun = $l.LastWriteTime.ToString('yyyy-MM-dd HH:mm')
  }catch{}
  return $s
}

# Pure: is this file the GLPI kit? A 403 page, a proxy login page or a half download is not.
function Test-GlpiKit {
  param([string]$Text)
  if(-not $Text){ return $false }
  if($Text -notmatch 'glpi-agent-setup\.ps1 \d+\.\d+\.\d+'){ return $false }
  $e = $null
  [void][System.Management.Automation.Language.Parser]::ParseInput($Text, [ref]$null, [ref]$e)
  return (@($e).Count -eq 0)
}

if($Status){
  $s = Get-GlpiAgentState
  Write-YcLog ('agent    : ' + $(if($s.installed){ 'installed, service ' + $s.status } else { 'NOT installed' })) $(if($s.installed -and $s.status -eq 'Running'){'OK'}else{'WARN'})
  Write-YcLog ('server   : ' + $(if($s.server){ $s.server } else { '(none)' }))
  Write-YcLog ('tag      : ' + $(if($s.tag){ $s.tag } else { '(none)' }))
  Write-YcLog ('last run : ' + $(if($s.lastRun){ $s.lastRun } else { '(no agent log)' }))
  Exit-Yc 0
}

Assert-YcPrereqs -NeedAdmin

$hasPw = [bool]("$env:GLPI_AGENT_PASSWORD".Length -ge 12)
if($Tenant -and $Tenant -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]{0,62}$'){
  Exit-Yc 2 ('-Tenant "' + $Tenant + '" is not a CloudStack domain or a tag like infra.<role>.') 'ERROR'
}
if($SetupUrl -notmatch '^https://[^\s"'']+$'){ Exit-Yc 2 ('-SetupUrl must be an https URL: ' + $SetupUrl) 'ERROR' }

if($Report){
  $s = Get-GlpiAgentState
  Write-YcLog ('agent now      : ' + $(if($s.installed){ 'installed, service ' + $s.status + ', tag ' + $s.tag } else { 'not installed' }))
  Write-YcLog ('password given : ' + $(if($hasPw){ 'yes (GLPI_AGENT_PASSWORD)' } else { 'NO - set $env:GLPI_AGENT_PASSWORD first' })) $(if($hasPw){'OK'}else{'WARN'})
  Write-YcLog ('would fetch    : ' + $SetupUrl)
  Write-YcLog ('would run      : the kit with tenant ' + $(if($Tenant){ $Tenant } else { '(automatic)' }))
  Exit-Yc 0 'REPORT ONLY - nothing was changed.' 'OK'
}

if(-not $hasPw){
  Exit-Yc 2 'no GLPI agent password. Set it on the line before (never as an option):  $env:GLPI_AGENT_PASSWORD = ''<password>''   then run glpi-join again.' 'ERROR'
}

# --- fetch the kit ----------------------------------------------------------------------------
try{
  New-Item -ItemType Directory -Force -Path $Work | Out-Null
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
  Invoke-WebRequest -Uri $SetupUrl -OutFile ($Kit + '.part') -UseBasicParsing -TimeoutSec 120 -ErrorAction Stop
}catch{
  $why = $_.Exception.Message
  $code = ''; try{ if($_.Exception.Response){ $code = ' (HTTP ' + [int]$_.Exception.Response.StatusCode + ')' } }catch{}
  Exit-Yc 4 ('could not fetch the GLPI kit from ' + $SetupUrl + $code + ': ' + $why + '. repo.oasisstack.io answers only the YallaCloud ranges - a VM outside them gets 403.') 'ERROR'
}
$txt = ''
try{ $txt = [IO.File]::ReadAllText($Kit + '.part') }catch{}
if(-not (Test-GlpiKit $txt)){
  Remove-Item -LiteralPath ($Kit + '.part') -Force -ErrorAction SilentlyContinue
  Exit-Yc 4 ('what ' + $SetupUrl + ' returned is not the GLPI kit (no version header, or it does not parse). Nothing was run.') 'ERROR'
}
Move-Item -LiteralPath ($Kit + '.part') -Destination $Kit -Force
$kitVer = ([regex]::Match($txt, 'glpi-agent-setup\.ps1 (\d+\.\d+\.\d+)')).Groups[1].Value
Write-YcLog ('kit glpi-agent-setup.ps1 ' + $kitVer + ' fetched and parsed') 'OK'

# --- run it: password through the environment only; the kit's own ntfy/webhook off -------------
$keep = @{ NTFY_TOPIC = $env:NTFY_TOPIC; EXTRA_WEBHOOK_URL = $env:EXTRA_WEBHOOK_URL }
$env:NTFY_TOPIC = 'off'; $env:EXTRA_WEBHOOK_URL = ''
$out = @(); $rc = -1
try{
  $a = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$Kit)
  if($Tenant){ $a += '-Tenant'; $a += $Tenant }   # by NAME: the password stays unbound, so the kit takes it from the environment
  $out = @(& (Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe') @a 2>&1 | ForEach-Object { [string]$_ })
  $rc = $LASTEXITCODE
}catch{
  $out += ('could not start the kit: ' + $_.Exception.Message)
}finally{
  $env:NTFY_TOPIC = $keep.NTFY_TOPIC; $env:EXTRA_WEBHOOK_URL = $keep.EXTRA_WEBHOOK_URL
}
foreach($l in $out){ if($l.Trim()){ Write-YcLog ('  kit: ' + $l.TrimEnd()) } }

$mean = ''
foreach($l in $out){ if($l -match '^\s*Meaning\s*:\s*(.+)$'){ $mean = $Matches[1].Trim() } }
$tag = ''
foreach($l in $out){ if($l -match 'tag=(\S+)'){ $tag = $Matches[1] } }
switch($rc){
  0 { Exit-Yc 0 ('REGISTERED in GLPI' + $(if($tag){ ' with tag ' + $tag } else { '' }) + '. It reports again once a day by itself.') 'OK' }
  8 { Exit-Yc 8 ('WAITING: ' + $(if($mean){ $mean } else { 'this VM is not known to CloudStack' }) + '. Our own server: glpi-join -Tenant infra.<role>.') 'WARN' }
  -1 { Exit-Yc 4 'the kit did not run at all - see the lines above.' 'ERROR' }
  default { Exit-Yc $rc ('FAILED (kit exit ' + $rc + '): ' + $(if($mean){ $mean } else { 'see the kit lines above' })) 'ERROR' }
}
