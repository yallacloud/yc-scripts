@echo off
REM ==================================================================================
REM  migration-check  -  CAN THIS VM BE MIGRATED, AND WHAT WILL COME WITH IT?
REM
REM  RUN THIS ON THE SOURCE VM, BEFORE THE MIGRATION WINDOW, WHILE IT IS STILL RUNNING.
REM  It changes NOTHING: no install, no scheduled task, no registry write, no repair.
REM  Read-only throughout, so it is safe on a live production machine.
REM
REM  It scans EVERY attached drive with chkdsk /scan (online and read-only - the volume
REM  stays in use), checks SQL Server if it is installed, and checks VSS - the thing
REM  that decides whether any backup of this machine is application-consistent.
REM
REM    migration-check                 run every check and print the verdict
REM    migration-check -SkipChkdsk     skip the volume scans (they read the whole disk)
REM    migration-check -SkipSql        do not touch SQL Server at all
REM    migration-check -Help           everything else
REM
REM  THE ANSWER
REM    GO              nothing found that should stop the move
REM    GO WITH RISK    it can move, but something travels with it. Each item is named.
REM    DO NOT MIGRATE  fix something first. Moving now risks data you cannot get back.
REM
REM  EXIT  0 GO | 1 GO WITH RISK | 2 DO NOT MIGRATE | 5 not elevated (nothing checked)
REM  The report and its JSON are written to your TEMP, with a SHA256. Keep both: they
REM  are the record of what this VM was like BEFORE it moved.
REM ==================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Test-MigrationReadiness.ps1" %*
exit /b %ERRORLEVEL%
