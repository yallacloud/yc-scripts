@echo off
rem zabbix-register -Server <ip> [-ServerActive <ip[:port]>] [-Hostname <n>] [-ListenPort 10050]
rem                 [-HostMetadata <s>] [-HostInterface <s>] [-ActiveOnly|-PassiveOnly]
rem                 [-Tls none|psk|cert] [-TlsPskIdentity <id>] [-TlsPskFile <f>]
rem                 [-TlsCaFile <f>] [-TlsCertFile <f>] [-TlsKeyFile <f>]
rem                 [-RemoteCommands | -AllowDenyKey '<AllowKey=..;DenyKey=..>']
rem                 [-MsiPath <msi>] [-MsiUrl <url>] [-Sha256 <hash>] [-InstallFolder <d>]
rem                 [-StartupType automatic|delayed|manual] [-Timeout <s>] [-NoFirewall] [-Force] [-Help]
rem Zabbix Agent 2, silent MSI. The PSK is NEVER a command-line value: use -TlsPskFile or the
rem YC_ZABBIX_PSK environment variable. Inbound 10050 is opened to -Server ONLY, and only after
rem the agent answers agent.ping. Logs to C:\Scripts\zabbix-register.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Zabbix-Register.ps1" %*
exit /b %ERRORLEVEL%
