# yc-boot.ps1 - one boot task replacing GIGrowDisk + GINetwork + YCDEPLOY + YCGUARD.
# Creates access rules ONCE if absent. Never re-enables anything an admin turned off.
$ErrorActionPreference='SilentlyContinue'
$log='C:\Scripts\yc-boot.log'
function L($m){ Add-Content $log ("[{0}] {1}" -f (Get-Date -f 'yyyy-MM-dd HH:mm:ss'), $m) -Encoding ascii }
L '--- yc-boot start ---'

# 1. grow C: into unallocated space (portal disk resize lands live)
try { & powershell -NoProfile -ExecutionPolicy Bypass -File C:\Scripts\Grow-Disk.ps1 | Out-Null; L 'grow-disk ran' } catch { L "grow-disk: $($_.Exception.Message)" }

# 2. remove ghost NICs left behind when CloudStack hands the clone a new MAC
try { & powershell -NoProfile -ExecutionPolicy Bypass -File C:\Scripts\Set-Nic.ps1 -CleanGhosts | Out-Null; L 'set-nic -CleanGhosts ran' } catch { L "set-nic: $($_.Exception.Message)" }

# 3. access rules - CREATE ONLY IF ABSENT. -Profile Any so the Private/Public
#    classification never decides reachability. An admin who disables a rule
#    keeps it disabled; we only ever add a rule that does not exist at all.
$want = @(
  @{ n='YC-SSH-3222';  p='TCP';    port='3222' },
  @{ n='YC-RDP-3389';  p='TCP';    port='3389' },
  @{ n='YC-WinRM-5985';p='TCP';    port='5985' },
  @{ n='YC-WinRM-5986';p='TCP';    port='5986' }
)
foreach($r in $want){
  if(-not (Get-NetFirewallRule -DisplayName $r.n -EA SilentlyContinue)){
    New-NetFirewallRule -DisplayName $r.n -Direction Inbound -Action Allow -Protocol $r.p -LocalPort $r.port -Profile Any | Out-Null
    L ("created firewall rule " + $r.n)
  }
}
if(-not (Get-NetFirewallRule -DisplayName 'YC-ICMPv4' -EA SilentlyContinue)){
  New-NetFirewallRule -DisplayName 'YC-ICMPv4' -Direction Inbound -Protocol ICMPv4 -IcmpType 8 -Action Allow -Profile Any | Out-Null
  L 'created firewall rule YC-ICMPv4'
}

# 4. CloudinitAdmin: hidden always; DISABLED once first boot finished so it
#    cannot keep re-issuing the Administrator password on later boots.
#    chadmin is deliberately NOT touched - if an admin disabled it, it stays so.
$ul='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList'
if(-not (Test-Path $ul)){ New-Item -Path $ul -Force | Out-Null }
New-ItemProperty -Path $ul -Name 'CloudinitAdmin' -PropertyType DWord -Value 0 -Force | Out-Null
Remove-ItemProperty -Path $ul -Name 'chadmin' -EA 0
$fb='C:\Scripts\yc-firstboot.log'
if((Test-Path $fb) -and ((Get-Content $fb -Raw -EA 0) -match 'yc-firstboot end')){
  $c = Get-CimInstance Win32_UserAccount -Filter "LocalAccount=true and Name='CloudinitAdmin'" -EA 0
  if($c -and -not $c.Disabled){ & net user CloudinitAdmin /active:no 2>&1 | Out-Null; L 'CloudinitAdmin disabled (first boot complete)' }
}

# 5. deploy audit line
$os=(Get-CimInstance Win32_OperatingSystem).Caption
$ip=(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' } | Select-Object -First 1).IPAddress
$xpr=(& cscript //nologo C:\Windows\System32\slmgr.vbs /xpr 2>&1) -join ' '
L ("host=$env:COMPUTERNAME ip=$ip os=$os lic=$xpr")
L '--- yc-boot end ---'
