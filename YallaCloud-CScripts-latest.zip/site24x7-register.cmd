@echo off
rem site24x7-register [-DeviceKeyFile <file> | -DeviceKey <k>] [-Name <display-name>]
rem                   [-MsiPath <msi>] [-VerifySec 300] [-Force] [-Help]
rem
rem The msiexec exit code is now captured and decoded, with a 10-second minimum plausible
rem duration because this MSI registers with the Site24x7 cloud while it installs. The agent
rem service must reach Running, <install dir>\monitoring\conf must be populated, and
rem plus.site24x7.com:443 must be reachable. The old version exited with msiexec's code and
rem verified nothing - a silent failure here means nobody is watching the VM.
rem
rem Prefer -DeviceKeyFile or
rem   set YC_SITE24X7_DEVICE_KEY=...
rem Site24x7 offers no alternative to the EDITA1 property, so the key is unavoidably on the
rem msiexec command line during the install; it is never written to the log.
rem AUTOMATION=TRUE (remote command execution from the console) is deliberately NOT enabled.
rem Outbound 443 only; no inbound port is opened. Logs to C:\Scripts\site24x7-register.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Site24x7-Register.ps1" %*
exit /b %ERRORLEVEL%
