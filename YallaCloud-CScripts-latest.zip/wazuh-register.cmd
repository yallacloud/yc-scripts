@echo off
rem wazuh-register -Manager <manager-ip-or-fqdn>
rem                [-RegPasswordFile <file> | -RegPassword <pw>] [-Group <g>] [-Name <n>]
rem                [-ManagerPort 1514] [-RegistrationPort 1515] [-Protocol tcp|udp]
rem                [-MsiPath <msi>] [-VerifySec 180] [-Force] [-SkipFirewall] [-AllowAnyRemote]
rem                [-Help]
rem
rem The msiexec exit code is now captured and decoded, WazuhSvc must reach Running, and
rem client.keys must appear before this command reports success - client.keys only exists once
rem the manager has ACCEPTED this agent. The outbound 1514/1515 rules are created only after
rem enrolment is proven and are scoped to the manager's addresses, not -Profile Any. The old
rem version created them on the failed path and exited with whatever msiexec returned.
rem
rem The enrolment password is a MANAGER-WIDE credential and is no longer put on the msiexec
rem command line: it is written to <agent dir>\authd.pass, locked to SYSTEM + Administrators
rem with the ACL verified. Prefer -RegPasswordFile or
rem   set YC_WAZUH_REGISTRATION_PASSWORD=...
rem Outbound only; no inbound port is opened. Logs to C:\Scripts\wazuh-register.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Wazuh-Register.ps1" %*
exit /b %ERRORLEVEL%
