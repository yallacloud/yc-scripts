param(
  [switch]$Security,[switch]$Critical,[switch]$All,[switch]$Drivers,
  [switch]$Download,[switch]$Install,[switch]$Reboot,[switch]$List,
  [string[]]$IncludeKB,[string[]]$ExcludeKB,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'winupdate'
$ErrorActionPreference='Continue'
if($Help){
@"
winupdate  -  Windows Update with a CHOOSABLE scope, unattended (built-in COM API - no extra modules).
USAGE:
  winupdate -Security [-Install] [-Reboot]      (DEFAULT scope = Security if none given)
  winupdate -Critical -Install -Reboot          Critical (MSRC) only, install, reboot if needed
  winupdate -All -Install                        all software updates (not drivers)
  winupdate -Drivers -Install                    driver updates only
  winupdate -List                                list applicable updates for the scope, do nothing
  winupdate -Security -ExcludeKB KB5001234       skip specific KBs   (-IncludeKB to restrict to some)
  winupdate -Help
SCOPE (pick one; default -Security):
  -Security   MSRC Critical+Important OR category 'Security Updates'
  -Critical   MSRC Critical severity only
  -All        every applicable software update (excludes drivers)
  -Drivers    driver updates only
ACTIONS:  -Download (download only)   -Install (download+install)   -List (report only)   -Reboot (reboot if required)
NOTES: unattended - NO prompts. If neither -List/-Download/-Install given, defaults to -List (safe).
       Works against Windows Update or your WSUS (whatever the machine is pointed at).
Log: C:\Scripts\winupdate.log
"@ | Write-Host -ForegroundColor Cyan; Stop-YcLog 0; exit 0
}

Assert-YcPrereqs -NeedAdmin
if(-not ($Security -or $Critical -or $All -or $Drivers)){ $Security=$true; Write-YcLog 'No scope given - defaulting to -Security.' 'WARN' }
if(-not ($List -or $Download -or $Install)){ $List=$true; Write-YcLog 'No action given - defaulting to -List (report only).' 'WARN' }

try{ $session = New-Object -ComObject Microsoft.Update.Session }catch{ Write-YcLog ('Cannot create Update session: ' + $_.Exception.Message) 'ERROR'; Stop-YcLog 1; exit 1 }
$searcher = $session.CreateUpdateSearcher()
$crit = if($Drivers){ "IsInstalled=0 AND Type='Driver'" } else { "IsInstalled=0 AND Type='Software'" }
Write-YcLog ("Searching updates: " + $crit)
try{ $res = $searcher.Search($crit) }catch{ Write-YcLog ('Search failed: ' + $_.Exception.Message) 'ERROR'; Stop-YcLog 1; exit 1 }

function In-Scope($u){
  if($Drivers){ return $true }
  if($All){ return $true }
  $sev = "$($u.MsrcSeverity)"
  $cats = @(); foreach($c in $u.Categories){ $cats += "$($c.Name)" }
  $isSec = ($cats -contains 'Security Updates')
  if($Critical){ return ($sev -eq 'Critical') }
  if($Security){ return ($isSec -or $sev -eq 'Critical' -or $sev -eq 'Important') }
  return $false
}
function KB-Of($u){ $k=@(); foreach($id in $u.KBArticleIDs){ $k += ('KB'+$id) }; return ($k -join ',') }

$sel = New-Object -ComObject Microsoft.Update.UpdateColl
$count=0
foreach($u in $res.Updates){
  if(-not (In-Scope $u)){ continue }
  $kb = KB-Of $u
  if($IncludeKB){ $hit=$false; foreach($x in $IncludeKB){ if($kb -match ($x -replace 'KB','')){ $hit=$true } }; if(-not $hit){ continue } }
  if($ExcludeKB){ $skip=$false; foreach($x in $ExcludeKB){ if($kb -match ($x -replace 'KB','')){ $skip=$true } }; if($skip){ Write-YcLog ("skip (excluded) " + $kb + " " + $u.Title); continue } }
  $count++
  Write-Host ("  [{0}] {1}  sev={2}  {3}" -f $count,$kb,$u.MsrcSeverity,$u.Title)
  if(-not $u.EulaAccepted){ try{ $u.AcceptEula() }catch{} }
  [void]$sel.Add($u)
}
Write-YcLog ("In-scope updates: " + $sel.Count)
if($sel.Count -eq 0){ Write-YcLog 'Nothing to do for this scope.' 'OK'; Stop-YcLog 0; exit 0 }
if($List){ Write-YcLog 'List-only (no download/install). Re-run with -Install to apply.' 'OK'; Stop-YcLog 0; exit 0 }

Write-YcLog 'Downloading...'
$dl = $session.CreateUpdateDownloader(); $dl.Updates = $sel
try{ $dr = $dl.Download(); Write-YcLog ('Download result code=' + $dr.ResultCode) }catch{ Write-YcLog ('Download error: ' + $_.Exception.Message) 'ERROR' }
if(-not $Install){ Write-YcLog 'Downloaded (no -Install).' 'OK'; Stop-YcLog 0; exit 0 }

$toInstall = New-Object -ComObject Microsoft.Update.UpdateColl
foreach($u in $sel){ if($u.IsDownloaded){ [void]$toInstall.Add($u) } }
Write-YcLog ('Installing ' + $toInstall.Count + ' update(s)...')
$inst = $session.CreateUpdateInstaller(); $inst.Updates = $toInstall
try{ $ir = $inst.Install(); Write-YcLog ('Install result code=' + $ir.ResultCode + '  rebootRequired=' + $ir.RebootRequired) 'OK' }
catch{ Write-YcLog ('Install error: ' + $_.Exception.Message) 'ERROR'; Stop-YcLog 1; exit 1 }

if($ir.RebootRequired){
  if($Reboot){ Write-YcLog 'Reboot required - rebooting in 20s...' 'WARN'; Stop-YcLog 0; shutdown /r /t 20 /c "winupdate reboot" | Out-Null; exit 0 }
  else { Write-YcLog 'Reboot REQUIRED to finish (re-run with -Reboot or reboot manually).' 'WARN' }
}
Write-YcLog 'winupdate complete.' 'OK'
Stop-YcLog 0
exit 0
