# _yc-lib.ps1 v2 - shared helper for YALLACLOUD C:\Scripts commands.
# PowerShell 5.1 compatible, ASCII only, dot-sourceable, emits NOTHING at dot-source time.
#
# ============================ WHAT CHANGED IN v2, AND WHY ============================
# v2 is a BACKWARD-COMPATIBLE SUPERSET of v1. Every function v1 exported still exists with
# a parameter set that accepts every call shape the 50 shipped callers use today. Nothing
# that worked before throws now. Where a caller does something wrong, v2 handles it
# gracefully and LOUDLY instead of silently doing the wrong thing.
#
# [P0] LOG DIRECTORY WAS A WORLD-READABLE CREDENTIAL STORE (audit L2)
#   v1: New-Item 'C:\Scripts' inherited the ACL of C:\, which includes BUILTIN\Users:(RX).
#       Start-Transcript then wrote a "Host Application:" header containing the FULL command
#       line of powershell.exe - so every -Token / -Password / -SaPassword / -OOAuth that a
#       .cmd wrapper forwarded with %* landed verbatim in C:\Scripts\<name>.log, readable by
#       every account on the box. Day2/README.txt additionally puts C:\Scripts on the system
#       PATH and gives it a Defender exclusion; a Users-readable/writable, PATH-listed,
#       AV-excluded directory on a host where these run as SYSTEM is a privilege-escalation
#       primitive, not just an information leak.
#   v2: Start-YcLog breaks inheritance and grants SYSTEM + Administrators only ON CREATE, and
#       idempotently REPAIRS an already-existing loose C:\Scripts (v263 images are sealed with
#       the loose ACL), logging exactly which identities it removed. It also scrubs the log of
#       secrets BEFORE starting the transcript (removing every header accumulated by -Append
#       from previous runs), attempts an immediate same-length in-place scrub of the header it
#       just wrote, and scrubs again - deterministically, because the file is then closed - in
#       Stop-YcLog and in the engine-exit hook. See the note on Write-YcRedacted for why the
#       immediate scrub is best-effort: PowerShell holds the transcript open with FileShare.Read,
#       so a write handle is usually refused until the transcript stops. The ACL is what makes
#       that window harmless; the scrub is what makes the file safe at rest.
#       Protect-YcSecret redacts any string a caller is about to log.
#
# [P1] Write-YcLog ACCEPTED A NUMERIC LEVEL AND FILED FAILURES AS INFO (audit L1)
#   v1: [string]$Level coerced an event ID to '1002', matched no switch branch, fell to
#       default, and wrote EventId 1001 / EntryType Information. Bitdefender-Register.ps1:42
#       does exactly this today, so the one advisory that script exists to raise is invisible
#       to any rule filtering on Warning.
#   v2: Write-YcLog NORMALISES the level. 1003/ERR/FATAL/CRITICAL -> ERROR, 1002/WARNING ->
#       WARN, 1000/1001/1099/DEBUG/VERBOSE -> INFO, SUCCESS -> OK. It emits ONE WARN per
#       distinct bad value naming the calling script and line so it gets fixed, then carries
#       on. It does NOT throw: a [ValidateSet] here would turn a cosmetic bug into a hard
#       binding error in 50 unattended scripts.
#
# [P0] Assert-YcPrereqs -SelfElevate RELAUNCHED WITH NO ARGUMENTS AND RETURNED 0 (audit L3)
#   v1: $script:YcArgs and $script:MyScriptPath were never assigned anywhere in the payload.
#       The elevated child started with every parameter unbound, printed usage into a UAC
#       console that closed instantly and exited 1, while the parent exited 0 without waiting
#       and without calling Stop-YcLog. Cloud-init recorded SUCCESS and nothing was installed.
#   v2: -SelfElevate REQUIRES -BoundParameters $PSBoundParameters. Without it the library
#       refuses to relaunch and exits 5 loudly - wrong usage is impossible, not silent. With
#       it, the argument list is rebuilt element-by-element (string[], never a concatenated
#       string), the child is run -Wait -PassThru, and the CHILD's exit code is propagated.
#       Self-elevation is also refused outright in a non-interactive session (cloud-init /
#       SYSTEM / RMM), where -Verb RunAs cannot work.
#
# [P1] NOTHING ENFORCED Stop-YcLog (audit L4)
#   v1: about 20 of 51 scripts never call it, leaving the transcript open with no [END] line
#       and no EventId 1099, so start/end pairing health checks are useless.
#   v2: Start-YcLog registers a PowerShell.Exiting engine handler that closes the transcript
#       and writes [END] with the last known exit code if Stop-YcLog was never reached.
#       Stop-YcLog is idempotent, so the 30 scripts that DO call it are unaffected. The engine
#       event is documented as best-effort across hosts, so Exit-Yc remains the sanctioned
#       exit path and the compliance gate enforces it.
#
# [P2] MISSING HELPERS 50 CALLERS REIMPLEMENTED BADLY OR NOT AT ALL (audit L5/L7)
#   Added: Assert-YcService, Invoke-YcInstaller, Get-YcFile, Assert-YcHttp, Assert-YcFile,
#   Exit-Yc, Protect-YcSecret, Write-YcRedacted, Write-YcInvocation, Set-YcTls, Test-YcService,
#   Test-YcWorldOpen.
#   Invoke-YcInstaller is the function whose absence caused the Acronis incident: it captures
#   the exit code, decodes 0/1641/3010 as success-ish, decodes known vendor failures including
#   Acronis 6452566 ("installer rejected the command line"), logs the argument list with
#   secrets redacted, enforces a timeout and a minimum plausible duration, and returns a result
#   OBJECT so a caller physically cannot print an exit code and ignore it.
#   Test-YcInternet no longer accepts HTTP 403/407 (captive portal / blocking proxy) as
#   "internet OK" and no longer CLOBBERS the process TLS policy - it ORs Tls12/Tls13 in.
#
# RETROFIT (unchanged from v1, still the documented usage):
#     . 'C:\Scripts\_yc-lib.ps1'
#     Start-YcLog 'command-name'
#     Assert-YcPrereqs -NeedAdmin
#     ... work ...
#     Exit-Yc 0 'done' 'OK'
# Self-elevating callers MUST pass their bound parameters:
#     Assert-YcPrereqs -NeedAdmin -SelfElevate -BoundParameters $PSBoundParameters
#
# Logging: timestamped transcript (all output + errors) at C:\Scripts\<command>.log, every
#          structured line tagged [YALLACLOUD][<command>], mirrored to the Windows Application
#          event log under source 'YallaCloud' (1000 start, 1001 info, 1002 warn, 1003 error,
#          1099 end).
# ====================================================================================

# --- PSModulePath sanity -------------------------------------------------------------
# MEASURED 2026-08-30 on a fresh clone. sshd's default shell on this image is pwsh 7, so
# every wrapper launched over SSH runs "powershell.exe" as a CHILD of pwsh and inherits
# pwsh's PSModulePath - which puts C:\Program Files\PowerShell\7\Modules AHEAD of the
# Windows PowerShell ones. Windows PowerShell 5.1 then finds PowerShell 7's copy of
# Microsoft.PowerShell.Security first and refuses to load it:
#
#   Error in TypeData "System.Security.AccessControl.ObjectSecurity":
#   The member AuditToString is already present.
#
# From that point every cmdlet in that module is dead - Get-Acl, and by extension
# Get-PackageProvider, Install-Module and anything that needs the gallery. That is what
# made install-sql fail with exit 9 ("dbatools is unusable") on BOTH 2019 and 2022 clones,
# and it would do the same to any L1 who SSHes in and runs a wrapper by hand.
#
# Drop the PowerShell 7 entries when we are running under Windows PowerShell. Nothing in
# this toolkit is PS7-only; everything here is 5.1 by contract.
if($PSVersionTable.PSEdition -ne 'Core'){
    try{
        $keep = @($env:PSModulePath -split ';' | Where-Object {
            $_ -and ($_ -notmatch '(?i)\\PowerShell\\7(\\|$)') -and ($_ -notmatch '(?i)\\Program Files\\PowerShell\\Modules$') -and ($_ -notmatch '(?i)\\Documents\\PowerShell\\Modules$')
        })
        $must = @("$env:ProgramFiles\WindowsPowerShell\Modules", "$env:WINDIR\System32\WindowsPowerShell\v1.0\Modules")
        foreach($m in $must){ if($keep -notcontains $m){ $keep += $m } }
        $env:PSModulePath = ($keep -join ';')
    }catch{}
}

$script:YcLibVersion   = '2.0.0'
$script:YcLogFile      = $null
$script:YcLogDir       = 'C:\Scripts'
$script:YcTag          = 'yallacloud'
$script:YcEvtSource    = 'YallaCloud'
$script:YcEvtLog       = 'Application'
$script:YcEvtOK        = $false
$script:YcStopped      = $true
$script:YcStarted      = $false
$script:YcExitHook     = $false
$script:YcTranscriptOK = $false
$script:YcHeaderDirty  = $false
$script:YcLastCode     = 0
$script:YcLevelWarned  = @{}
$script:YcScriptPath   = $null
$script:MyScriptPath   = $null      # v1 declared this and never assigned it; v2 assigns it.
$script:YcArgs         = @()        # v1 declared this and never assigned it; v2 assigns it.

# Parameter names whose VALUE must never reach a log, a console, or an event.
$script:YcSecretParams = @(
    'Token','Password','Pass','Secret','Key','ApiKey','EnrollSecret','PSK','Community',
    'SaPassword','MyPassword','PgPassword','SqlPassword','OOPass','OOAuth','SqlPass',
    'RegPassword','DeviceKey','ProductKey','AdminPassword','DSN','DataSourceName',
    'Credential','AuthToken','BearerToken','ClientSecret','AccessKey','SecretKey',
    'PrivateKey','LicenseKey','TrapCommunity','ConnectionString'
)

# Two patterns, built once. P1 catches installer-style 'name=value' and '--reg-token=value'.
# P2 catches PowerShell-style '-Name value'. P2 is anchored with a lookahead so that
# '-PassThru' does NOT match 'Pass' and swallow the next token.
$script:YcSecretRxAssign = '(?i)([\w./-]*(?:token|password|passwd|secret|apikey|api-key|psk|community|enrollsecret|devicekey|productkey|credential|privatekey|accesskey|secretkey|oopass|ooauth|sapassword|mypassword|pgpassword|sqlpassword|sqlpass|regpassword|connectionstring|datasourcename|dsn)[\w.-]*)(\s*[:=]\s*)("[^"]*"|''[^'']*''|[^\s;,&|]+)'
# A bare 5x5 product key. slmgr /ipk answers in PROSE - "Installed product key
# XXXXX-XXXXX-XXXXX-XXXXX-XXXXX successfully" - so it carries no name=value and no
# -Parameter for the two patterns above to catch, and the key went into the log, the
# transcript and the Application event log in full. Masking keeps the LAST FIVE, which
# is exactly what Windows itself publishes as PartialProductKey, and the replacement is
# the same length as the match so the in-place scrub can never change a file's size.
$script:YcSecretRxProductKey = '\b[A-Z0-9]{5}(?:-[A-Z0-9]{5}){4}\b'
$script:YcSecretRxParam  = $null
$script:YcSecretRxParam  = '(?i)(-(?:' + (($script:YcSecretParams | Sort-Object { $_.Length } -Descending) -join '|') + ')(?=[\s:=]))(\s*[:=]?\s+)("[^"]*"|''[^'']*''|[^\s;,&|]+)'

# Well-known SIDs that are ALLOWED to have access to the log directory.
$script:YcAclAllowedSids = @(
    'S-1-5-18',                                                                    # NT AUTHORITY\SYSTEM
    'S-1-5-32-544',                                                                # BUILTIN\Administrators
    'S-1-3-0',                                                                     # CREATOR OWNER
    'S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464'               # TrustedInstaller
)

# ------------------------------------------------------------------------------------
# Secret handling
# ------------------------------------------------------------------------------------

# Protect-YcSecret -Value <string> [-Keep <int>] [-Whole]
#   Default: scans $Value for secret-looking parameters and masks their VALUES, returning a
#            string that is safe to log. Use on any string before logging it.
#   -Whole : treats the WHOLE of $Value as one raw secret and returns '****' + last -Keep chars.
function Protect-YcSecret{
    param([string]$Value,[int]$Keep=0,[switch]$Whole)
    if($null -eq $Value){ return '' }
    if($Value.Length -eq 0){ return '' }
    if($Whole){
        if($Keep -gt 0 -and $Value.Length -gt $Keep){ return ('****' + $Value.Substring($Value.Length - $Keep)) }
        return '****'
    }
    $out = $Value
    try{
        $out = [regex]::Replace($out,$script:YcSecretRxAssign,{ param($m) $m.Groups[1].Value + $m.Groups[2].Value + '****' })
        $out = [regex]::Replace($out,$script:YcSecretRxParam ,{ param($m) $m.Groups[1].Value + ' ****' })
        $out = [regex]::Replace($out,$script:YcSecretRxProductKey,{ param($m)
                    '*****-*****-*****-*****-' + $m.Value.Substring($m.Value.Length - 5) })
    }catch{}
    return $out
}

# Write-YcRedacted -Path <file> [-Quiet]
#   Masks every secret value in a log file IN PLACE, replacing each value character with '*'
#   so the file's BYTE LENGTH NEVER CHANGES. That matters: PowerShell keeps its own write
#   position in an open transcript, so truncating or growing the file underneath it would
#   corrupt the log. Returns the number of characters masked, or -1 if the file could not be
#   opened for writing (which is the normal result while a transcript is active, because
#   PowerShell 5.1 opens the transcript with FileShare.Read - the deferred scrub in
#   Stop-YcLog then runs against a closed file and always succeeds).
function Write-YcRedacted{
    param([string]$Path,[switch]$Quiet)
    if(-not $Path){ return 0 }
    if(-not (Test-Path -LiteralPath $Path)){ return 0 }
    $fs = $null
    $changed = 0
    try{
        $fs = New-Object System.IO.FileStream($Path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::ReadWrite)
    }catch{
        if(-not $Quiet){ $script:YcHeaderDirty = $true }
        return -1
    }
    try{
        $len = [int]$fs.Length
        if($len -le 0){ return 0 }
        $buf = New-Object byte[] $len
        [void]$fs.Read($buf,0,$len)
        $enc = [System.Text.Encoding]::UTF8
        $isUtf16 = $false
        if($len -ge 2 -and $buf[0] -eq 0xFF -and $buf[1] -eq 0xFE){ $enc = [System.Text.Encoding]::Unicode; $isUtf16 = $true }
        $txt = $enc.GetString($buf)
        $new = $txt
        $new = [regex]::Replace($new,$script:YcSecretRxAssign,{ param($m)
                    $v = $m.Groups[3].Value
                    $q = ''
                    if($v.Length -ge 2 -and ($v[0] -eq '"' -or $v[0] -eq "'")){ $q = [string]$v[0] }
                    $inner = $v
                    if($q -ne ''){ $inner = $v.Substring(1,$v.Length-2) }
                    $m.Groups[1].Value + $m.Groups[2].Value + $q + ('*' * $inner.Length) + $q })
        $new = [regex]::Replace($new,$script:YcSecretRxParam,{ param($m)
                    $v = $m.Groups[3].Value
                    $q = ''
                    if($v.Length -ge 2 -and ($v[0] -eq '"' -or $v[0] -eq "'")){ $q = [string]$v[0] }
                    $inner = $v
                    if($q -ne ''){ $inner = $v.Substring(1,$v.Length-2) }
                    $m.Groups[1].Value + $m.Groups[2].Value + $q + ('*' * $inner.Length) + $q })
        $new = [regex]::Replace($new,$script:YcSecretRxProductKey,{ param($m)
                    '*****-*****-*****-*****-' + $m.Value.Substring($m.Value.Length - 5) })
        if($new -eq $txt){ return 0 }
        for($i=0;$i -lt $txt.Length -and $i -lt $new.Length;$i++){ if($txt[$i] -ne $new[$i]){ $changed++ } }
        $outBytes = $enc.GetBytes($new)
        if($isUtf16){
            # GetBytes() on the Unicode encoding drops the BOM; put it back so length matches.
            $tmp = New-Object byte[] ($outBytes.Length + 2)
            $tmp[0] = 0xFF; $tmp[1] = 0xFE
            [Array]::Copy($outBytes,0,$tmp,2,$outBytes.Length)
            $outBytes = $tmp
        }
        if($outBytes.Length -ne $len){ return 0 }   # refuse to change the file length, ever
        $fs.Position = 0
        $fs.Write($outBytes,0,$outBytes.Length)
        $fs.Flush()
        $script:YcHeaderDirty = $false
    }catch{
        return -1
    }finally{
        if($fs){ try{ $fs.Close() }catch{} }
    }
    return $changed
}

# ------------------------------------------------------------------------------------
# Event log (v1 behaviour preserved exactly)
# ------------------------------------------------------------------------------------

function Initialize-YcEvent{
    if($script:YcEvtOK){ return }
    try{
        if(-not [System.Diagnostics.EventLog]::SourceExists($script:YcEvtSource)){
            New-EventLog -LogName $script:YcEvtLog -Source $script:YcEvtSource -ErrorAction Stop
        }
        $script:YcEvtOK = $true
    }catch{ $script:YcEvtOK = $false }   # not admin / not permitted: file log still works
}

function Write-YcEvent([string]$Message,[string]$Level,[int]$EventId){
    if(-not $script:YcEvtOK){ return }
    $type = switch($Level){ 'ERROR'{'Error'} 'WARN'{'Warning'} default{'Information'} }
    $safe = Protect-YcSecret $Message
    try{ Write-EventLog -LogName $script:YcEvtLog -Source $script:YcEvtSource -EntryType $type -EventId $EventId -Message (("[{0}] " -f $script:YcTag) + $safe) -ErrorAction SilentlyContinue }catch{}
}

# ------------------------------------------------------------------------------------
# Level normalisation (audit L1)
# ------------------------------------------------------------------------------------

# Internal. Returns 'INFO' | 'OK' | 'WARN' | 'ERROR' for anything a caller might pass,
# and reports (once per distinct bad value) where the bad value came from.
function ConvertTo-YcLevel{
    param([string]$Level)
    if($null -eq $Level){ $Level = '' }
    $raw = $Level.Trim()
    if($raw.Length -eq 0){ return 'INFO' }
    $u = $raw.ToUpperInvariant()
    switch($u){
        'INFO'  { return 'INFO' }
        'OK'    { return 'OK' }
        'WARN'  { return 'WARN' }
        'ERROR' { return 'ERROR' }
    }
    $mapped = $null
    switch($u){
        'WARNING'  { $mapped = 'WARN' }
        'ERR'      { $mapped = 'ERROR' }
        'FATAL'    { $mapped = 'ERROR' }
        'CRITICAL' { $mapped = 'ERROR' }
        'CRIT'     { $mapped = 'ERROR' }
        'FAIL'     { $mapped = 'ERROR' }
        'SUCCESS'  { $mapped = 'OK' }
        'PASS'     { $mapped = 'OK' }
        'DONE'     { $mapped = 'OK' }
        'DEBUG'    { $mapped = 'INFO' }
        'VERBOSE'  { $mapped = 'INFO' }
        'TRACE'    { $mapped = 'INFO' }
        'NOTICE'   { $mapped = 'INFO' }
        '1000'     { $mapped = 'INFO' }
        '1001'     { $mapped = 'INFO' }
        '1002'     { $mapped = 'WARN' }
        '1003'     { $mapped = 'ERROR' }
        '1099'     { $mapped = 'INFO' }
    }
    if(-not $mapped){
        $n = 0
        if([int]::TryParse($raw,[ref]$n)){
            if($n -ge 1003){ $mapped = 'ERROR' }
            elseif($n -eq 1002){ $mapped = 'WARN' }
            else{ $mapped = 'INFO' }
        }else{
            $mapped = 'INFO'
        }
    }
    # One-time, non-fatal report naming the offending call site so it gets fixed.
    if(-not $script:YcLevelWarned.ContainsKey($u)){
        $script:YcLevelWarned[$u] = $true
        $where = 'unknown call site'
        try{
            $st = Get-PSCallStack
            foreach($f in $st){
                if($f.ScriptName -and ($f.ScriptName -notlike '*_yc-lib.ps1')){
                    $where = ('{0}:{1}' -f (Split-Path -Leaf $f.ScriptName),$f.ScriptLineNumber)
                    break
                }
            }
        }catch{}
        $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        $nn = 0
        $hint = "'" + $raw + "' is not a recognised level"
        if([int]::TryParse($raw,[ref]$nn)){ $hint = "'" + $raw + "' is an EVENT ID, not a level - the level argument is the SECOND positional argument of Write-YcLog" }
        $msg = ("BAD LOG LEVEL passed to Write-YcLog at {0} - treated as {1}. Levels are INFO/OK/WARN/ERROR; {2}. Fix the call site." -f $where,$mapped,$hint)
        Write-Host ("{0}  [YALLACLOUD][{1}] [WARN] {2}" -f $ts,$script:YcTag,$msg) -ForegroundColor Yellow
        Write-YcEvent $msg 'WARN' 1002
    }
    return $mapped
}

# ------------------------------------------------------------------------------------
# Log directory hardening (audit L2)
# ------------------------------------------------------------------------------------

# Internal. Returns a short description of what it changed, or '' if nothing changed.
function Protect-YcLogDir{
    param([string]$Dir)
    $created = $false
    $note    = ''
    if(-not (Test-Path -LiteralPath $Dir)){
        New-Item -ItemType Directory -Path $Dir -Force | Out-Null
        $created = $true
    }
    $needFix = $created
    $loose   = @()
    if(-not $created){
        try{
            $acl = Get-Acl -Path $Dir
            if(-not $acl.AreAccessRulesProtected){ $needFix = $true }
            foreach($ace in $acl.Access){
                $sid = $null
                try{ $sid = $ace.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value }
                catch{ $sid = [string]$ace.IdentityReference }
                if($script:YcAclAllowedSids -notcontains $sid){
                    $needFix = $true
                    $nm = [string]$ace.IdentityReference
                    if($loose -notcontains $nm){ $loose += $nm }
                }
            }
        }catch{
            $needFix = $true
            $flat = ([string]$_.Exception.Message) -replace '[\r\n]+',' '
            $loose += ('ACL unreadable: ' + $flat)
        }
    }
    if(-not $needFix){ return '' }

    $ok = $false
    try{
        # Names first (matches the documented fix); SIDs as a locale-safe fallback.
        & icacls $Dir /inheritance:r /grant 'NT AUTHORITY\SYSTEM:(OI)(CI)F' 'BUILTIN\Administrators:(OI)(CI)F' 2>&1 | Out-Null
        if($LASTEXITCODE -eq 0){ $ok = $true }
        if(-not $ok){
            & icacls $Dir /inheritance:r /grant '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' 2>&1 | Out-Null
            if($LASTEXITCODE -eq 0){ $ok = $true }
        }
    }catch{ $ok = $false }

    if($created){
        if($ok){ $note = ("created {0} with inheritance broken; SYSTEM + Administrators Full only" -f $Dir) }
        else   { $note = ("created {0} but FAILED to harden its ACL - it may be readable by BUILTIN\Users" -f $Dir) }
    }else{
        if($ok){
            $note = ("REPAIRED ACL on existing {0}: inheritance broken, SYSTEM + Administrators Full only" -f $Dir)
            if($loose.Count -gt 0){ $note += ("; removed access for: " + ($loose -join ', ')) }
            $note += ". Non-admin accounts can no longer read the transcripts in this directory (this directory is on the system PATH)."
        }else{
            $note = ("FAILED to repair the loose ACL on {0} (needs Administrator). Transcripts here may be readable by: {1}" -f $Dir,(($loose -join ', ')))
        }
    }
    return $note
}

# ------------------------------------------------------------------------------------
# Network scope
# ------------------------------------------------------------------------------------

# Test-YcWorldOpen [-Scope] <string[]>
#   THE single implementation of "is this firewall scope open to the whole internet?".
#   Promoted out of Set-Firewall.ps1 because three exporter registrars had each grown their
#   own version that only recognised the literal string 'Any', so -RemoteAddress 0.0.0.0/0
#   walked straight past the guard. True when the scope is null/empty, when ANY element is
#   empty, or when ANY element is a wildcard keyword. EVERY element is tested - a caller must
#   never assume a multi-element list is automatically safe.
function Test-YcWorldOpen{
    param([string[]]$Scope)
    if($null -eq $Scope -or $Scope.Count -eq 0){ return $true }
    foreach($s in $Scope){
        if([string]::IsNullOrEmpty($s)){ return $true }
        $t = $s.Trim()
        if($t -eq 'Any' -or $t -eq '*' -or $t -eq '0.0.0.0/0' -or $t -eq '::/0' -or $t -eq 'Internet'){ return $true }
    }
    return $false
}

# ------------------------------------------------------------------------------------
# TLS
# ------------------------------------------------------------------------------------

# Set-YcTls - ORs Tls12 (and Tls13 where the platform has it) into the CURRENT policy
# instead of replacing it. v1 assigned Tls12, which dropped Tls13 on Server 2022/2025.
function Set-YcTls{
    try{
        $cur = [Net.ServicePointManager]::SecurityProtocol
        $want = [Net.SecurityProtocolType]::Tls12
        if([int]$cur -ne 0){ $want = $cur -bor [Net.SecurityProtocolType]::Tls12 }
        if([enum]::GetNames([Net.SecurityProtocolType]) -contains 'Tls13'){
            try{ $want = $want -bor ([Net.SecurityProtocolType]'Tls13') }catch{}
        }
        try{ [Net.ServicePointManager]::SecurityProtocol = $want }
        catch{ [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
    }catch{}
}

# ------------------------------------------------------------------------------------
# Start / Write / Stop
# ------------------------------------------------------------------------------------

# Start-YcLog [-Name] <string> [[-Dir] <string> = 'C:\Scripts'] [[-MaxLogMB] <int> = 5] [-SkipAclHarden]
#   Hardens/creates the log directory, rotates an oversized log, starts the transcript (with a
#   LOUD banner if it fails - v1 swallowed that and ran completely unlogged), scrubs secrets out
#   of the transcript header, registers the exit hook that guarantees an [END] line, initialises
#   the event source and writes START / EventId 1000.
#   -Name is positional 1, exactly as v1: Start-YcLog 'acronis-register' still works.
function Start-YcLog{
    param([string]$Name,[string]$Dir='C:\Scripts',[int]$MaxLogMB=5,[switch]$SkipAclHarden)

    if(-not $Name){ $Name = 'yallacloud' }
    $script:YcTag     = $Name
    $script:YcLogDir  = $Dir
    $script:YcStopped = $false
    $script:YcStarted = $true
    $script:YcLastCode = 0

    # Record where the caller lives so -SelfElevate and diagnostics have a real path.
    try{
        $p = $MyInvocation.PSCommandPath
        if(-not $p){
            $st = Get-PSCallStack
            foreach($f in $st){ if($f.ScriptName -and ($f.ScriptName -notlike '*_yc-lib.ps1')){ $p = $f.ScriptName; break } }
        }
        $script:YcScriptPath = $p
        $script:MyScriptPath = $p
    }catch{}

    $aclNote = ''
    if(-not $SkipAclHarden){
        try{ $aclNote = Protect-YcLogDir -Dir $Dir }catch{ $aclNote = 'ACL hardening threw: ' + $_.Exception.Message }
    }

    $script:YcLogFile = Join-Path $Dir ($Name + '.log')

    # Rotate before appending, so a single command cannot grow an unbounded secret archive.
    try{
        if(Test-Path -LiteralPath $script:YcLogFile){
            $sz = (Get-Item -LiteralPath $script:YcLogFile).Length
            if($MaxLogMB -gt 0 -and $sz -gt ($MaxLogMB * 1MB)){
                $bak = $script:YcLogFile + '.1'
                if(Test-Path -LiteralPath $bak){ Remove-Item -LiteralPath $bak -Force -ErrorAction SilentlyContinue }
                Move-Item -LiteralPath $script:YcLogFile -Destination $bak -Force -ErrorAction SilentlyContinue
            }
        }
    }catch{}

    # Scrub secrets left by PREVIOUS runs' transcript headers before we append another one.
    try{ [void](Write-YcRedacted -Path $script:YcLogFile -Quiet) }catch{}

    $script:YcTranscriptOK = $false
    try{
        Start-Transcript -Path $script:YcLogFile -Append -ErrorAction Stop | Out-Null
        $script:YcTranscriptOK = $true
    }catch{
        $script:YcTranscriptOK = $false
    }
    if(-not $script:YcTranscriptOK){
        # v1 swallowed this and left the command running with NO log and no warning.
        Write-Host ''
        Write-Host '*** TRANSCRIPT FAILED - THIS RUN IS NOT BEING LOGGED TO DISK ***' -ForegroundColor Red
        Write-Host ("*** target: {0}  (a transcript may already be running in this process, or the file is locked) ***" -f $script:YcLogFile) -ForegroundColor Red
        Write-Host ''
        $script:YcLogFile = $null
    }

    # The PS 5.1 transcript header always contains the host process command line, which is
    # where wrapper-forwarded secrets land. Best-effort immediate scrub; guaranteed at Stop.
    if($script:YcTranscriptOK){
        $r = -1
        try{ $r = Write-YcRedacted -Path $script:YcLogFile }catch{ $r = -1 }
        if($r -lt 0){ $script:YcHeaderDirty = $true }
    }

    Initialize-YcEvent

    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $m  = ("START  host={0} user={1} ps={2} lib={3}" -f $env:COMPUTERNAME,$env:USERNAME,$PSVersionTable.PSVersion,$script:YcLibVersion)
    Write-Host ("{0}  [YALLACLOUD][{1}] [START] {2}" -f $ts,$Name,$m)
    Write-YcEvent $m 'INFO' 1000

    if($aclNote){
        $lvl = 'INFO'
        if($aclNote -like 'FAILED*' -or $aclNote -like '*FAILED*'){ $lvl = 'WARN' }
        Write-YcLog ('log dir ACL: ' + $aclNote) $lvl
    }

    # A redacted, auditable record of how this command was actually invoked.
    try{
        $cl = [Environment]::CommandLine
        if($cl){ Write-YcLog ('invocation: ' + (Protect-YcSecret $cl)) 'INFO' }
        $script:YcArgs = @()
        if($cl -match '(?i)\s-File\s+"?[^"]*\.ps1"?\s*(.*)$'){ $script:YcArgs = @($Matches[1]) }
        if($cl -and ($cl -match $script:YcSecretRxParam -or $cl -match $script:YcSecretRxAssign)){
            Write-YcLog 'SECRET ON THE COMMAND LINE: this value is visible in the process table and in 4688 events, and was written into this transcript header by PowerShell (now masked). Prefer a secret file or an environment variable.' 'WARN'
        }
    }catch{}

    if($script:YcHeaderDirty){
        Write-YcLog 'Transcript header could not be scrubbed while the transcript is open (PowerShell holds it with FileShare.Read). It will be scrubbed when this command exits; until then the directory ACL is what protects it.' 'INFO'
    }

    # Guarantee an [END] line even for the ~20 scripts that never call Stop-YcLog.
    if(-not $script:YcExitHook){
        try{
            $null = Register-EngineEvent -SourceIdentifier PowerShell.Exiting -SupportEvent -Action {
                try{
                    if(-not $script:YcStopped){
                        $c = $script:YcLastCode
                        try{ if($null -ne $global:LASTEXITCODE){ $c = [int]$global:LASTEXITCODE } }catch{}
                        Stop-YcLog -Code $c -Unclean
                    }
                }catch{}
            }
            $script:YcExitHook = $true
        }catch{}
    }
}

# Write-YcLog [-Message] <string> [[-Level] <string> = 'INFO']
#   One tagged console line + one Application event. $Level is normalised, never rejected:
#   a numeric event id such as 1002 is MAPPED to WARN and reported once, not filed as INFO.
#   Secrets in $Message are masked before they reach the console or the event log.
function Write-YcLog{
    param([string]$Message,[string]$Level='INFO')
    $lvl  = ConvertTo-YcLevel $Level
    $safe = Protect-YcSecret $Message
    $ts   = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = ("{0}  [YALLACLOUD][{1}] [{2}] {3}" -f $ts,$script:YcTag,$lvl,$safe)
    switch($lvl){
        'ERROR' { Write-Host $line -ForegroundColor Red;    Write-YcEvent $safe 'ERROR' 1003 }
        'WARN'  { Write-Host $line -ForegroundColor Yellow; Write-YcEvent $safe 'WARN'  1002 }
        'OK'    { Write-Host $line -ForegroundColor Green;  Write-YcEvent $safe 'INFO'  1001 }
        default { Write-Host $line;                         Write-YcEvent $safe 'INFO'  1001 }
    }
}

# Write-YcInvocation [-BoundParameters] <hashtable> [[-SecretNames] <string[]>]
#   Logs a redacted one-line record of how the command was invoked.
function Write-YcInvocation{
    param([hashtable]$BoundParameters,[string[]]$SecretNames)
    if(-not $SecretNames){ $SecretNames = $script:YcSecretParams }
    $parts = @()
    if($BoundParameters){
        foreach($k in ($BoundParameters.Keys | Sort-Object)){
            $v = $BoundParameters[$k]
            $isSecret = $false
            foreach($s in $SecretNames){ if($k -eq $s){ $isSecret = $true; break } }
            if(-not $isSecret){
                foreach($s in @('Token','Password','Secret','ApiKey','Psk','Credential','ProductKey','DeviceKey','Dsn')){
                    if($k -like ('*' + $s + '*')){ $isSecret = $true; break }
                }
            }
            if($v -is [System.Management.Automation.SwitchParameter]){
                if($v.IsPresent){ $parts += ('-' + $k) }
            }elseif($isSecret){
                $parts += ('-' + $k + ' ' + (Protect-YcSecret ([string]$v) -Whole -Keep 0))
            }else{
                $parts += ('-' + $k + ' ' + (Protect-YcSecret ([string]$v)))
            }
        }
    }
    Write-YcLog ('invoked: ' + $script:YcTag + ' ' + ($parts -join ' ')) 'INFO'
}

# Stop-YcLog [[-Code] <int> = 0] [-Unclean]
#   Writes END exit=<n> + EventId 1099, stops the transcript, and scrubs any secret the
#   transcript header left behind (the file is closed at that point, so this always works).
#   IDEMPOTENT: a second call is a no-op, so the ~30 scripts that already call it are
#   unaffected and the PowerShell.Exiting hook cannot produce a duplicate [END].
#   -Unclean is set only by the exit hook, for a script that never reached Stop-YcLog or
#   Exit-Yc. In that path the [END] line is ALSO appended to the log file directly, because
#   output written from an engine-exiting handler is not reliably captured by the transcript -
#   and a missing [END] is precisely the signal (audit L4) this exists to guarantee.
function Stop-YcLog{
    param([int]$Code=0,[switch]$Unclean)
    if($script:YcStopped){ return }
    $script:YcStopped  = $true
    $script:YcLastCode = $Code
    $ts   = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $note = ''
    if($Unclean){ $note = ' UNCLEAN - the script exited without calling Stop-YcLog or Exit-Yc; this exit code is the last one the library saw, not necessarily the process exit code' }
    $line = ("{0}  [YALLACLOUD][{1}] [END] exit={2}{3}" -f $ts,$script:YcTag,$Code,$note)
    Write-Host $line
    Write-YcEvent ("END exit=" + $Code + $note) 'INFO' 1099
    $f = $script:YcLogFile
    try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null } catch {}
    $script:YcTranscriptOK = $false
    if($f){
        if($Unclean){
            try{
                $seen = $false
                $tail = Get-Content -LiteralPath $f -Tail 25 -ErrorAction SilentlyContinue
                # NOT -like: '[END]' is a -like character class (one of E,N,D) and never matches
                # the literal text, so the duplicate-END guard silently never fired. .Contains() is literal.
                foreach($t in $tail){ if($t -and $t.Contains('[END] exit=')){ $seen = $true } }
                if(-not $seen){ Add-Content -LiteralPath $f -Value $line -Encoding ascii -ErrorAction SilentlyContinue }
            }catch{}
        }
        try{ [void](Write-YcRedacted -Path $f -Quiet) }catch{}
    }
}

# Exit-Yc [-Code] <int> [[-Message] <string>] [[-Level] <string>]
#   THE single sanctioned exit path: logs at the right level, Stop-YcLog, exit with the code.
#   Level defaults to OK for 0 and ERROR for anything else.
function Exit-Yc{
    param([int]$Code=0,[string]$Message,[string]$Level)
    if(-not $Level){ if($Code -eq 0){ $Level = 'OK' } else { $Level = 'ERROR' } }
    if($Message){ Write-YcLog $Message $Level }
    $script:YcLastCode = $Code
    Stop-YcLog $Code
    exit $Code
}

# ------------------------------------------------------------------------------------
# Preflight (v1 names and behaviour preserved)
# ------------------------------------------------------------------------------------

function Test-YcAdmin{
    try{
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = New-Object Security.Principal.WindowsPrincipal($id)
        return $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }catch{ return $false }
}

# Test-YcInternet [[-Url] <string>] [[-TimeoutSec] <int> = 8]
#   True only on an HTTP status BELOW 400. v1 accepted anything under 500, so a captive portal
#   or a blocking proxy answering 403/407 counted as "internet OK".
function Test-YcInternet([string]$Url='https://www.microsoft.com',[int]$TimeoutSec=8){
    Set-YcTls
    try{
        $r = Invoke-WebRequest -Uri $Url -UseBasicParsing -Method Head -TimeoutSec $TimeoutSec -ErrorAction Stop
        if($r.StatusCode -ge 200 -and $r.StatusCode -lt 400){ return $true }
    }catch{}
    try{
        $r2 = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec $TimeoutSec -ErrorAction Stop
        if($r2.StatusCode -ge 200 -and $r2.StatusCode -lt 400){ return $true }
    }catch{}
    foreach($h in @('www.microsoft.com','packages.broadcom.com','8.8.8.8')){
        try{ if((Test-NetConnection -ComputerName $h -Port 443 -WarningAction SilentlyContinue -InformationLevel Quiet)){ return $true } }catch{}
    }
    return $false
}

# Assert-YcPrereqs [-NeedAdmin] [-SelfElevate] [-NeedInternet] [-InternetUrl <s>] [-BoundParameters <hashtable>]
#   -NeedAdmin     require elevation (exit 5)
#   -SelfElevate   relaunch elevated. REQUIRES -BoundParameters $PSBoundParameters; without it
#                  the library refuses to relaunch and exits 5 rather than starting an
#                  argument-less child and reporting SUCCESS (v1's P0 defect).
#   -NeedInternet  require outbound internet (exit 6)
function Assert-YcPrereqs{
    param([switch]$NeedAdmin,[switch]$SelfElevate,[switch]$NeedInternet,
          [string]$InternetUrl='https://www.microsoft.com',
          [hashtable]$BoundParameters)
    Set-YcTls
    if($NeedAdmin -and -not (Test-YcAdmin)){
        if($SelfElevate){
            $spath = $MyInvocation.PSCommandPath
            if(-not $spath){ $spath = $script:YcScriptPath }
            if(-not $spath){ $spath = $script:MyScriptPath }
            if(-not $spath){
                Exit-Yc 5 'SelfElevate requested but the calling script path could not be determined - refusing to relaunch. Re-run from an elevated PowerShell.' 'ERROR'
            }
            if(-not $BoundParameters){
                Exit-Yc 5 ('SelfElevate requested WITHOUT -BoundParameters. Relaunching without the original arguments would start an argument-less elevated copy that prints usage and exits 1 while this copy reported success - refusing. Call: Assert-YcPrereqs -NeedAdmin -SelfElevate -BoundParameters $PSBoundParameters') 'ERROR'
            }
            $interactive = $true
            try{ $interactive = [Environment]::UserInteractive }catch{}
            if(-not $interactive){
                Exit-Yc 5 'SelfElevate is impossible in a non-interactive session (cloud-init / SYSTEM / RMM): -Verb RunAs has no desktop to prompt on. Run this command as Administrator.' 'ERROR'
            }
            $a = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $spath + '"'))
            foreach($k in $BoundParameters.Keys){
                if($k -eq 'BoundParameters'){ continue }
                $v = $BoundParameters[$k]
                if($v -is [System.Management.Automation.SwitchParameter]){
                    if($v.IsPresent){ $a += ('-' + $k) }
                }elseif($v -is [array]){
                    $items = @()
                    foreach($x in $v){ $items += ('"' + ([string]$x -replace '"','""') + '"') }
                    if($items.Count -gt 0){ $a += ('-' + $k); $a += ($items -join ',') }
                }else{
                    $a += ('-' + $k)
                    $a += ('"' + ([string]$v -replace '"','""') + '"')
                }
            }
            Write-YcLog ('Not elevated - relaunching as Administrator (accept the UAC prompt): ' + (Protect-YcSecret ($a -join ' '))) 'WARN'
            $child = $null
            try{
                $child = Start-Process -FilePath 'powershell.exe' -ArgumentList $a -Verb RunAs -Wait -PassThru -ErrorAction Stop
            }catch{
                Exit-Yc 5 ('Self-elevate failed: ' + $_.Exception.Message + '. Run this command as Administrator.') 'ERROR'
            }
            $cc = 5
            try{ $cc = [int]$child.ExitCode }catch{}
            if($cc -eq 0){ Exit-Yc 0 ('Elevated run completed (child exit=' + $cc + ').') 'OK' }
            Exit-Yc $cc ('Elevated run FAILED (child exit=' + $cc + ').') 'ERROR'
        }
        Exit-Yc 5 'This command must run as Administrator. Open PowerShell as administrator and re-run.' 'ERROR'
    }
    if($NeedInternet -and -not (Test-YcInternet -Url $InternetUrl)){
        Exit-Yc 6 ('No outbound internet (tested ' + $InternetUrl + '). Check egress/proxy and retry.') 'ERROR'
    }
    Write-YcLog 'Preflight OK'
}

# ------------------------------------------------------------------------------------
# v2 additions - the helpers 50 callers reimplemented badly or not at all
# ------------------------------------------------------------------------------------

# Assert-YcService [-Name] <string> [[-TimeoutSec] <int> = 60] [[-State] <string> = 'Running']
#                  [-StartIfStopped] [[-Because] <string>] [-Fatal]
#   Proves a service EXISTS and reaches $State within $TimeoutSec. Returns $true/$false and
#   logs the truth (never "assumed OK"). -Fatal turns a failure into Exit-Yc 7.
#   This is the post-condition 34 scripts omit - the difference between "the installer ran"
#   and "the agent is installed and running".
function Assert-YcService{
    param([string]$Name,[int]$TimeoutSec=60,[string]$State='Running',[switch]$StartIfStopped,[string]$Because,[switch]$Fatal)
    $why = ''
    if($Because){ $why = ' (' + $Because + ')' }
    if(-not $Name){
        Write-YcLog ('Assert-YcService called with no service name' + $why) 'ERROR'
        if($Fatal){ Exit-Yc 7 'Assert-YcService: no service name' 'ERROR' }
        return $false
    }
    $svc = $null
    try{ $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue }catch{ $svc = $null }
    if(-not $svc){
        Write-YcLog ("service '" + $Name + "' DOES NOT EXIST - the installer did not create it" + $why) 'ERROR'
        if($Fatal){ Exit-Yc 7 ("required service missing: " + $Name) 'ERROR' }
        return $false
    }
    if($StartIfStopped -and $State -eq 'Running' -and $svc.Status -ne 'Running'){
        try{ Start-Service -Name $Name -ErrorAction Stop }catch{ Write-YcLog ("could not start service '" + $Name + "': " + $_.Exception.Message) 'WARN' }
    }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $last = ''
    while($sw.Elapsed.TotalSeconds -lt $TimeoutSec){
        try{ $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue }catch{ $svc = $null }
        if(-not $svc){ break }
        $last = [string]$svc.Status
        if($last -eq $State){
            $st = ''
            try{ $st = ' / StartType ' + $svc.StartType }catch{}
            Write-YcLog ("service '" + $Name + "' is " + $last + $st + " after " + [int]$sw.Elapsed.TotalSeconds + "s" + $why) 'OK'
            return $true
        }
        Start-Sleep -Seconds 2
    }
    Write-YcLog ("service '" + $Name + "' did NOT reach " + $State + " within " + $TimeoutSec + "s (last state: " + $last + ")" + $why) 'ERROR'
    if($Fatal){ Exit-Yc 7 ("service not " + $State + ": " + $Name) 'ERROR' }
    return $false
}

# Test-YcService - alias-shaped wrapper for Assert-YcService, for call sites that read better
# as a test than as an assertion. Same contract, always non-fatal.
function Test-YcService{
    param([string]$Name,[string]$State='Running',[int]$TimeoutSec=60,[switch]$StartIfStopped)
    return (Assert-YcService -Name $Name -State $State -TimeoutSec $TimeoutSec -StartIfStopped:$StartIfStopped)
}

# Assert-YcFile [-Path] <string> [[-MinBytes] <long> = 1] [-RequireSignature]
#               [[-Because] <string>] [-Fatal]
#   A required file exists, is at least -MinBytes, and (optionally) carries a VALID Authenticode
#   signature. Returns $true/$false; -Fatal turns a failure into Exit-Yc 4.
function Assert-YcFile{
    param([string]$Path,[long]$MinBytes=1,[switch]$RequireSignature,[string]$Because,[switch]$Fatal)
    $why = ''
    if($Because){ $why = ' (' + $Because + ')' }
    if(-not $Path -or -not (Test-Path -LiteralPath $Path)){
        Write-YcLog ('required file MISSING: ' + $Path + $why) 'ERROR'
        if($Fatal){ Exit-Yc 4 ('required file missing: ' + $Path) 'ERROR' }
        return $false
    }
    $len = 0
    try{ $len = (Get-Item -LiteralPath $Path).Length }catch{}
    if($len -lt $MinBytes){
        Write-YcLog ('required file TOO SMALL: ' + $Path + ' is ' + $len + ' bytes, expected at least ' + $MinBytes + $why) 'ERROR'
        if($Fatal){ Exit-Yc 4 ('required file too small: ' + $Path) 'ERROR' }
        return $false
    }
    if($RequireSignature){
        $status = 'Unavailable'
        try{ $status = [string](Get-AuthenticodeSignature -LiteralPath $Path -ErrorAction Stop).Status }
        catch{ $status = 'Unavailable: ' + $_.Exception.Message }
        if($status -ne 'Valid'){
            Write-YcLog ('Authenticode signature on ' + $Path + ' is ' + $status + ' (expected Valid)' + $why) 'ERROR'
            if($Fatal){ Exit-Yc 4 ('unsigned or untrusted file: ' + $Path) 'ERROR' }
            return $false
        }
        Write-YcLog ('file OK: ' + $Path + ' (' + $len + ' bytes, Authenticode Valid)' + $why) 'OK'
        return $true
    }
    Write-YcLog ('file OK: ' + $Path + ' (' + $len + ' bytes)' + $why) 'OK'
    return $true
}

# Assert-YcHttp [-Uri] <string> [[-TimeoutSec] <int> = 60] [[-ExpectStatus] <int> = 200]
#               [[-MatchContent] <string>] [[-IntervalSec] <int> = 3] [-Fatal]
#   GETs $Uri until it answers $ExpectStatus (optionally containing $MatchContent) or the
#   timeout expires. Liveness proof for the exporter scripts: an installed windows_exporter
#   that is not serving /metrics is not a working windows_exporter.
function Assert-YcHttp{
    param([string]$Uri,[int]$TimeoutSec=60,[int]$ExpectStatus=200,[string]$MatchContent,[int]$IntervalSec=3,[switch]$Fatal)
    Set-YcTls
    if(-not $Uri){
        Write-YcLog 'Assert-YcHttp called with no URI' 'ERROR'
        if($Fatal){ Exit-Yc 8 'Assert-YcHttp: no URI' 'ERROR' }
        return $false
    }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $last = 'no response'
    while($sw.Elapsed.TotalSeconds -lt $TimeoutSec){
        try{
            $r = Invoke-WebRequest -Uri $Uri -UseBasicParsing -TimeoutSec 15 -ErrorAction Stop
            $last = 'HTTP ' + $r.StatusCode
            if([int]$r.StatusCode -eq $ExpectStatus){
                if($MatchContent){
                    $body = ''
                    try{ $body = [string]$r.Content }catch{}
                    if($body -like ('*' + $MatchContent + '*')){
                        Write-YcLog ($Uri + ' answered ' + $ExpectStatus + ' and contains "' + $MatchContent + '" after ' + [int]$sw.Elapsed.TotalSeconds + 's') 'OK'
                        return $true
                    }
                    $last = 'HTTP ' + $r.StatusCode + ' but body does not contain "' + $MatchContent + '"'
                }else{
                    Write-YcLog ($Uri + ' answered ' + $ExpectStatus + ' after ' + [int]$sw.Elapsed.TotalSeconds + 's') 'OK'
                    return $true
                }
            }
        }catch{
            $last = $_.Exception.Message
            try{
                $resp = $_.Exception.Response
                if($resp){ $last = 'HTTP ' + [int]$resp.StatusCode }
            }catch{}
        }
        Start-Sleep -Seconds $IntervalSec
    }
    Write-YcLog ($Uri + ' did NOT answer ' + $ExpectStatus + ' within ' + $TimeoutSec + 's (last: ' + $last + ')') 'ERROR'
    if($Fatal){ Exit-Yc 8 ('endpoint not healthy: ' + $Uri) 'ERROR' }
    return $false
}

# Internal. Returns 'PE' | 'MSI' | 'ZIP' | 'GZ' | '7Z' | 'CAB' | 'HTML' | 'TEXT' | 'EMPTY' | 'OTHER'
function Get-YcFileKind{
    param([string]$Path)
    try{
        $fs = New-Object System.IO.FileStream($Path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
        try{
            $n = [int][Math]::Min(512,$fs.Length)
            if($n -le 0){ return 'EMPTY' }
            $b = New-Object byte[] $n
            [void]$fs.Read($b,0,$n)
        }finally{ $fs.Close() }
    }catch{ return 'OTHER' }
    if($n -ge 2 -and $b[0] -eq 0x4D -and $b[1] -eq 0x5A){ return 'PE' }
    if($n -ge 8 -and $b[0] -eq 0xD0 -and $b[1] -eq 0xCF -and $b[2] -eq 0x11 -and $b[3] -eq 0xE0){ return 'MSI' }
    if($n -ge 2 -and $b[0] -eq 0x50 -and $b[1] -eq 0x4B){ return 'ZIP' }
    if($n -ge 2 -and $b[0] -eq 0x1F -and $b[1] -eq 0x8B){ return 'GZ' }
    if($n -ge 2 -and $b[0] -eq 0x37 -and $b[1] -eq 0x7A){ return '7Z' }
    if($n -ge 4 -and $b[0] -eq 0x4D -and $b[1] -eq 0x53 -and $b[2] -eq 0x43 -and $b[3] -eq 0x46){ return 'CAB' }
    $head = ''
    try{ $head = ([System.Text.Encoding]::ASCII.GetString($b)).TrimStart() }catch{}
    if($head -match '(?i)^\s*(<!doctype\s+html|<html|<\?xml|<head|<body)'){ return 'HTML' }
    if($head -match '(?i)<html|</html>|<title>'){ return 'HTML' }
    return 'TEXT'
}

# Get-YcFile [-Uri] <string> [-OutFile] <string> [[-Sha256] <string>] [[-Retries] <int> = 4]
#            [[-TimeoutSec] <int> = 300] [[-MinBytes] <long> = 1024] [-AllowText] [-Fatal]
#   Downloads with TLS 1.2 (1.3 where available) forced, retries with exponential backoff,
#   verifies SHA256 when supplied, and REFUSES an HTML error page saved with a .exe/.msi/.zip
#   name - the classic "the proxy returned a login page and we installed it" failure.
#   Returns the output path on success, $null on failure. -Fatal turns failure into Exit-Yc 9.
function Get-YcFile{
    param([string]$Uri,[string]$OutFile,[string]$Sha256,[int]$Retries=4,[int]$TimeoutSec=300,[long]$MinBytes=1024,[switch]$AllowText,[switch]$Fatal)
    Set-YcTls
    if(-not $Uri -or -not $OutFile){
        Write-YcLog 'Get-YcFile requires -Uri and -OutFile' 'ERROR'
        if($Fatal){ Exit-Yc 9 'Get-YcFile: bad arguments' 'ERROR' }
        return $null
    }
    $dir = Split-Path -Parent $OutFile
    if($dir -and -not (Test-Path -LiteralPath $dir)){ New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $safeUri = Protect-YcSecret $Uri
    $attempt = 0
    $delay   = 3
    while($attempt -lt $Retries){
        $attempt++
        if(Test-Path -LiteralPath $OutFile){ Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue }
        Write-YcLog ('download attempt ' + $attempt + '/' + $Retries + ': ' + $safeUri)
        $failed = $null
        try{
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -TimeoutSec $TimeoutSec -ErrorAction Stop
        }catch{
            $failed = $_.Exception.Message
        }
        if(-not $failed){
            $len = 0
            try{ $len = (Get-Item -LiteralPath $OutFile).Length }catch{}
            if($len -lt $MinBytes){
                $failed = 'downloaded ' + $len + ' bytes, expected at least ' + $MinBytes
            }else{
                $kind = Get-YcFileKind -Path $OutFile
                $ext  = ''
                try{ $ext = ([IO.Path]::GetExtension($OutFile)).ToLowerInvariant() }catch{}
                $binaryExt = @('.exe','.msi','.msu','.zip','.7z','.cab','.gz','.tgz','.dll')
                if($kind -eq 'HTML'){
                    $failed = 'the server returned an HTML page, not a file (proxy/captive portal/404 page saved as ' + $ext + ')'
                }elseif(($binaryExt -contains $ext) -and $kind -eq 'TEXT' -and -not $AllowText){
                    $failed = 'the downloaded content is plain text but the target is ' + $ext + ' - refusing to treat it as a binary'
                }
                if(-not $failed -and $Sha256){
                    $actual = ''
                    try{ $actual = (Get-FileHash -LiteralPath $OutFile -Algorithm SHA256 -ErrorAction Stop).Hash }catch{ $actual = '' }
                    if($actual -and ($actual.ToUpperInvariant() -eq $Sha256.ToUpperInvariant())){
                        Write-YcLog ('SHA256 verified: ' + $actual) 'OK'
                    }else{
                        Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
                        Write-YcLog ('SHA256 MISMATCH for ' + $safeUri + ' - expected ' + $Sha256 + ', got ' + $actual + '. Partial file deleted.') 'ERROR'
                        if($Fatal){ Exit-Yc 9 'download hash mismatch' 'ERROR' }
                        throw ('SHA256 mismatch for ' + $safeUri)
                    }
                }
                if(-not $failed){
                    Write-YcLog ('downloaded ' + $len + ' bytes to ' + $OutFile + ' (content looks like ' + $kind + ')') 'OK'
                    return $OutFile
                }
            }
        }
        Write-YcLog ('download failed (attempt ' + $attempt + '/' + $Retries + '): ' + $failed) 'WARN'
        if(Test-Path -LiteralPath $OutFile){ Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue }
        if($attempt -lt $Retries){ Start-Sleep -Seconds $delay; $delay = $delay * 2 }
    }
    Write-YcLog ('download of ' + $safeUri + ' FAILED after ' + $Retries + ' attempts') 'ERROR'
    if($Fatal){ Exit-Yc 9 ('download failed: ' + $safeUri) 'ERROR' }
    return $null
}

# Internal. Human meaning for an installer exit code.
function Get-YcExitMeaning{
    param([int]$Code)
    switch($Code){
        0       { return 'success' }
        1641    { return 'success - the installer initiated a reboot' }
        3010    { return 'success - a reboot is required to complete' }
        1        { return 'generic failure (many bootstrappers use 1 for "bad command line")' }
        2        { return 'ERROR_FILE_NOT_FOUND / installer aborted' }
        5        { return 'ERROR_ACCESS_DENIED - not elevated, or the target is locked' }
        1602    { return 'ERROR_INSTALL_USEREXIT - the installation was cancelled' }
        1603    { return 'ERROR_INSTALL_FAILURE - fatal error during installation' }
        1605    { return 'ERROR_UNKNOWN_PRODUCT - that product is not installed' }
        1618    { return 'ERROR_INSTALL_ALREADY_RUNNING - another installation is in progress' }
        1619    { return 'ERROR_INSTALL_PACKAGE_OPEN_FAILED - the package could not be opened' }
        1620    { return 'ERROR_INSTALL_PACKAGE_INVALID - the package is corrupt' }
        1622    { return 'ERROR_INSTALL_LOG_FAILURE - the log location is not writable' }
        1623    { return 'ERROR_INSTALL_LANGUAGE_UNSUPPORTED' }
        1624    { return 'ERROR_INSTALL_TRANSFORM_FAILURE' }
        1625    { return 'ERROR_INSTALL_PACKAGE_REJECTED - system policy forbids this install' }
        1633    { return 'ERROR_INSTALL_PLATFORM_UNSUPPORTED - wrong architecture' }
        1638    { return 'ERROR_PRODUCT_VERSION - another version of this product is already installed' }
        1639    { return 'ERROR_INVALID_COMMAND_LINE - the installer rejected a switch' }
        1642    { return 'ERROR_PATCH_TARGET_NOT_FOUND' }
        6452566 { return 'ACRONIS: the installer REJECTED the command line (unknown or malformed switch). Nothing was installed. This is the failure the --log= switch produced.' }
        6452565 { return 'ACRONIS: installation failed - see the Acronis bootstrapper log' }
        29949963 { return 'ACRONIS 0x1C9000B: the command line was ACCEPTED and the agent installed, but REGISTRATION FAILED, so the MSI rolled back (result 1603). The token is wrong, expired, already consumed, or issued for a different data centre. Get a fresh token from the Acronis console and check -Url matches the tenant.' }
        7       { return 'NSIS/Salt: installation aborted' }
        -196608 { return 'powershell.exe -File pointed at a script that does not exist' }
    }
    if($Code -lt 0){ return ('negative/native exit code 0x' + ('{0:X8}' -f $Code)) }
    return 'unrecognised installer exit code'
}

# Invoke-YcInstaller [-FilePath] <string> [-ArgumentList] <string[]> [[-SuccessCodes] <int[]> = 0]
#                    [[-RebootCodes] <int[]> = 3010,1641] [[-TimeoutSec] <int> = 1800]
#                    [[-MinSeconds] <int> = 0] [[-WorkingDirectory] <string>] [-Fatal]
#   Runs an installer, waits with a TIMEOUT (killing it if it hangs), captures the exit code,
#   decodes it, logs the ARGUMENT LIST WITH SECRETS REDACTED, and returns a result OBJECT:
#     @{ FilePath; Arguments; ExitCode; Status; Success; RebootRequired; DurationSec; TimedOut; Meaning }
#   Status is Success | SuccessRebootRequired | Failed | TimedOut | Suspicious.
#   'Suspicious' is returned when the installer reports success but finished faster than
#   -MinSeconds: a web bootstrapper that exits in 4 seconds did not download and install
#   anything, which is exactly the Acronis signature nothing in v1 could see.
#   -Fatal calls Exit-Yc with the installer's own exit code on anything that is not success.
function Invoke-YcInstaller{
    param(
        [string]$FilePath,
        [string[]]$ArgumentList,
        [int[]]$SuccessCodes=@(0),
        [int[]]$RebootCodes=@(3010,1641),
        [int]$TimeoutSec=1800,
        [int]$MinSeconds=0,
        [string]$WorkingDirectory,
        [switch]$Fatal
    )
    $argStr  = ''
    if($ArgumentList){ $argStr = ($ArgumentList -join ' ') }
    $safeArg = Protect-YcSecret $argStr
    $res = [pscustomobject]@{
        FilePath       = $FilePath
        Arguments      = $safeArg
        ExitCode       = -1
        Status         = 'Failed'
        Success        = $false
        RebootRequired = $false
        DurationSec    = 0
        TimedOut       = $false
        Meaning        = ''
    }
    if(-not $FilePath -or -not (Test-Path -LiteralPath $FilePath)){
        $res.Meaning = 'installer not found: ' + $FilePath
        Write-YcLog $res.Meaning 'ERROR'
        if($Fatal){ Exit-Yc 4 $res.Meaning 'ERROR' }
        return $res
    }
    Write-YcLog ('running installer: ' + $FilePath + ' ' + $safeArg)
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $proc = $null
    try{
        $sp = @{ FilePath = $FilePath; PassThru = $true; ErrorAction = 'Stop' }
        if($ArgumentList -and $ArgumentList.Count -gt 0){ $sp['ArgumentList'] = $ArgumentList }
        if($WorkingDirectory){ $sp['WorkingDirectory'] = $WorkingDirectory }
        $proc = Start-Process @sp
    }catch{
        $sw.Stop()
        $res.Meaning = 'could not start the installer: ' + $_.Exception.Message
        $res.DurationSec = [int]$sw.Elapsed.TotalSeconds
        Write-YcLog $res.Meaning 'ERROR'
        if($Fatal){ Exit-Yc 4 $res.Meaning 'ERROR' }
        return $res
    }
    $exited = $false
    try{ $exited = $proc.WaitForExit($TimeoutSec * 1000) }catch{ $exited = $false }
    $sw.Stop()
    $res.DurationSec = [int]$sw.Elapsed.TotalSeconds
    if(-not $exited){
        $res.TimedOut = $true
        $res.Status   = 'TimedOut'
        $res.Meaning  = 'the installer did not exit within ' + $TimeoutSec + 's and was killed'
        try{ Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }catch{}
        Write-YcLog ('installer TIMEOUT after ' + $res.DurationSec + 's: ' + $FilePath) 'ERROR'
        if($Fatal){ Exit-Yc 10 $res.Meaning 'ERROR' }
        return $res
    }
    $code = -1
    try{ $code = [int]$proc.ExitCode }catch{ $code = -1 }
    $res.ExitCode = $code
    $res.Meaning  = Get-YcExitMeaning $code

    if($RebootCodes -contains $code){
        $res.Success = $true; $res.RebootRequired = $true; $res.Status = 'SuccessRebootRequired'
    }elseif($SuccessCodes -contains $code){
        $res.Success = $true; $res.Status = 'Success'
    }else{
        $res.Success = $false; $res.Status = 'Failed'
    }

    if($res.Success -and $MinSeconds -gt 0 -and $res.DurationSec -lt $MinSeconds){
        $res.Status  = 'Suspicious'
        $res.Success = $false
        $res.Meaning = ('exit code ' + $code + ' (' + $res.Meaning + ') but the installer finished in ' + $res.DurationSec + 's, under the ' + $MinSeconds + 's minimum for this package - it almost certainly rejected the command line and installed nothing')
    }

    $lvl = 'ERROR'
    if($res.Status -eq 'Success'){ $lvl = 'OK' }
    elseif($res.Status -eq 'SuccessRebootRequired'){ $lvl = 'WARN' }
    elseif($res.Status -eq 'Suspicious'){ $lvl = 'ERROR' }
    Write-YcLog ('installer ' + (Split-Path -Leaf $FilePath) + ' -> exit ' + $code + ' [' + $res.Status + '] in ' + $res.DurationSec + 's: ' + $res.Meaning) $lvl

    if($Fatal -and -not $res.Success){
        $ec = $code
        if($ec -eq 0){ $ec = 1 }
        Exit-Yc $ec ('installer FAILED: ' + (Split-Path -Leaf $FilePath) + ' -> ' + $res.Meaning) 'ERROR'
    }
    return $res
}
