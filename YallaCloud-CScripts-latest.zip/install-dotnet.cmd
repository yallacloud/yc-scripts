@echo off
rem install-dotnet - bring .NET Framework up to 4.8 (or 4.8.1) and PROVE the Release value.
rem
rem Two things on this estate are blocked by the same missing prerequisite, and this closes
rem the gap from the payload instead of reopening and re-sealing the golden images:
rem   1. SSMS      - SSMS 20 needs .NET 4.7.2 (Release 461808), SSMS 21/22 need 4.8 (528040)
rem   2. Chocolatey - choco 2.x needs .NET 4.8, which is why 2016/2019 are stuck on 1.4.0
rem
rem Stock: 2016 = 4.6.2 (394802), 2019 = 4.7.2 (461814), 2022 = 4.8 (528449), 2025 = 4.8.1 (533509).
rem So this does work on 2016 and 2019, and exits 0 on 2022 and 2025.
rem
rem   install-dotnet                      ensure .NET 4.8
rem   install-dotnet -Target 4.8.1        Server 2022+ only
rem   install-dotnet -UpgradeChocolatey   then upgrade choco 1.x to 2.x
rem   install-dotnet -SelfCheck           assertions only, changes nothing
rem   install-dotnet -Help
rem
rem .NET 4.8 ALWAYS requires a restart, so a successful install ends at exit 8 rather than
rem pretending the framework is live. Reboot, then re-run what needed it.
rem
rem Exit codes: 0 already satisfied, 1 failed, 2 usage, 3 no Chocolatey, 5 not elevated,
rem             6 no internet, 8 installed - reboot and re-run.
rem Log: C:\Scripts\install-dotnet.log
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-DotNet.ps1" %*
exit /b %ERRORLEVEL%
