@echo off
rem install-ssms - install SQL Server Management Studio and PROVE Ssms.exe exists.
rem
rem Chocolatey supplies the package (sql-server-management-studio). This wrapper does not
rem re-implement the download; it applies the one rule that matters and then checks the disk:
rem   Windows Server 2019/2022/2025 -> SSMS 22 (current)
rem   Windows Server 2016           -> SSMS 20 (SSMS 21/22 return 8010 on 2016)
rem
rem   install-ssms                        auto-select by OS build
rem   install-ssms -SsmsVersion 20        force SSMS 20
rem   install-ssms -SsmsVersion 22
rem   install-ssms -Force                 reinstall even if SSMS is present
rem   install-ssms -SelfCheck             assertions only, changes nothing
rem   install-ssms -Help
rem
rem Success is decided by locating Ssms.exe, not by the installer exit code - the
rem Visual Studio Installer bundle behind SSMS 21/22 can exit 0 having installed nothing.
rem
rem Exit codes: 0 verified, 1 install/verify failed, 2 usage, 3 no Chocolatey, 4 .NET too old,
rem             5 not elevated, 6 no internet, 7 installer said OK but Ssms.exe absent,
rem             8 .NET 4.8 was installed - reboot and re-run.
rem
rem .NET is the real blocker: stock Server 2016 has .NET 4.6.2 and stock 2019 has 4.7.2.
rem SSMS 20 needs 4.7.2 (Release 461808), SSMS 21/22 need 4.8 (Release 528040). This
rem installs netfx-4.8 when needed and exits 8 - reboot, then run install-ssms again.
rem Log: C:\Scripts\install-ssms.log
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Ssms.ps1" %*
exit /b %ERRORLEVEL%
