param(
  [string]$InfluxUrl,
  [string]$Token,
  [string]$Org,
  [string]$Bucket = 'telegraf',
  [string]$ConfigUrl,
  [string]$ConfigFile,
  [string]$TokenFile,
  [string]$ZipPath,
  [string]$DownloadUrl,
  [string]$Sha256,
  [string]$InstallDir = 'C:\Program Files\Telegraf',
  [string]$ServiceName = 'telegraf',
  [switch]$AddOutboundRule,
  [switch]$Force,
  [switch]$Help
)
# =====================================================================================
# Telegraf-Register.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
# Installs Telegraf as a Windows service, validates the config with the VENDOR validator,
# keeps the InfluxDB token out of every command line, and PROVES the agent runs.
#
# WHAT CHANGED AND WHY
# --------------------
#  1. IT NO LONGER LIES (was the group-wide P0). The old ending was: run the service
#     installer, log its OUTPUT but never its EXIT STATUS, then
#         Set-Service -EA SilentlyContinue ; Start-Service -EA SilentlyContinue
#         Write-YcLog 'done - telegraf pushing metrics out' 'OK' ; Stop-YcLog 0 ; exit 0
#     which exits 0 whether or not anything was installed. Proof is now, in order: the
#     binary reports its version; 'telegraf --config <f> --test' exits 0 AND emits at least
#     one metric line; the service exists and reaches Running; it is STILL Running after a
#     settle window; and (when -InfluxUrl was used) the InfluxDB /health endpoint answers.
#     Every -ErrorAction SilentlyContinue on a load-bearing call is gone.
#  2. [P0-26 vendor validator] 'telegraf --config <file> --test' IS RUN BEFORE THE SERVICE
#     IS TOUCHED. It parses the whole config and runs every input once, so a bad plugin
#     name, a malformed TOML table or an unreadable counter is caught in one second instead
#     of being discovered never. (--test exercises INPUTS; the output endpoint is proven
#     separately by the /health probe.)
#  3. THE INFLUXDB TOKEN LEAVES THE COMMAND LINE AND THE WORLD-READABLE FILE.
#     - Preferred input is -TokenFile <path> or the environment variable YC_TELEGRAF_TOKEN.
#       Neither appears in the process table, in a Windows 4688 ProcessCreation event, or in
#       the PowerShell transcript header. An InfluxDB v2 API token is a bearer credential
#       for the whole org - it was previously typed on a .cmd command line and written
#       cleartext into a Users-readable telegraf.conf.
#     - -Token still works for compatibility but logs a loud WARN naming the exposure.
#     - telegraf.conf now contains  token = "${INFLUX_TOKEN}"  and the real value is stored
#       in the SERVICE's own Environment REG_MULTI_SZ under
#       HKLM\SYSTEM\CurrentControlSet\Services\<service>, which only SYSTEM and
#       Administrators can read and which the SCM injects at every service start. Telegraf's
#       documented ${VAR} substitution resolves it. The config file is additionally ACL'd to
#       SYSTEM + Administrators and the ACL is verified.
#     - The validator run gets the token through this process's own environment block, which
#       is inherited by that child only.
#  4. THE DEPRECATED SERVICE FLAG FORM IS GONE. 'telegraf --service install' prints "The use
#     of --service is deprecated, please use the 'service' command instead!". The documented
#     current form is used:  telegraf.exe --config "<conf>" service install
#  5. IT NO LONGER DESTROYS AN EXISTING SERVICE CONFIGURATION. The old script ran
#     '--service uninstall' unconditionally, even on a first install (spurious error) and
#     even when an operator had configured a custom service name or restart policy. The
#     service is now only removed when it exists AND its binPath is wrong.
#  6. [[inputs.win_perf_counters]] HAD NO OBJECT SUB-TABLES, so the plugin loaded and
#     collected NOTHING. Real object tables (Processor, Memory, LogicalDisk, System) are
#     emitted now.
#  7. THE OUTBOUND FIREWALL RULE IS OPT-IN AND SCOPED. Windows' default outbound action is
#     Allow, so the old unconditional rule changed nothing on a stock image; and if outbound
#     WERE blocked by policy, a rule scoped only by RemotePort (no -Program, no
#     -RemoteAddress) was far too broad. It is now -AddOutboundRule, scoped to telegraf.exe
#     and to the resolved endpoint host/port, and created only AFTER the agent is proven.
#     The port is parsed with [uri] so https://host/ correctly means 443, not 8086.
#  8. -ConfigUrl is fetched with TLS 1.2+, retries and an HTML/error-page check (Get-YcFile);
#     the old Invoke-WebRequest had no timeout, no -ErrorAction Stop and no content check.
#  9. delayed-auto start type + sc.exe failure actions, consistent with the toolkit; and a
#     version-aware staged-zip pick ([version] parse, not the old lexical sort where
#     telegraf-1.9.0 beat telegraf-1.28.0).
# 10. Unhandled-exception guard + temp cleanup on every path.
#
# PARAMETERS ADDED (none renamed, none removed): -TokenFile, -ZipPath, -DownloadUrl,
#     -Sha256, -InstallDir, -ServiceName, -AddOutboundRule, -Force.
# BEHAVIOUR CHANGE TO REPORT: the outbound firewall rule is no longer created by default.
#
# VERIFIED AGAINST THE CURRENT RELEASE (docs, not memory):
#   'service install|uninstall|start|stop|status' + --config placement + --service-name
#     https://github.com/influxdata/telegraf/blob/master/docs/WINDOWS_SERVICE.md
#   --test ("Run only inputs, output to stdout, and exit"), --config, --config-directory
#     https://github.com/influxdata/telegraf/blob/master/docs/COMMANDS_AND_FLAGS.md
#   ${VAR} environment substitution in the config; [[outputs.influxdb_v2]] urls/token/
#     organization/bucket; [[inputs.win_perf_counters.object]] ObjectName/Instances/
#     Counters/Measurement
#     https://github.com/influxdata/telegraf/blob/master/docs/CONFIGURATION.md
#
# Log: C:\Scripts\telegraf-register.log
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'telegraf-register'
$ErrorActionPreference = 'Stop'

$HelpText = @"
telegraf-register - SILENT install + configure Telegraf (InfluxData metrics agent) as a Windows
                    service, validate the config with 'telegraf --config <f> --test', and prove the
                    agent runs before reporting success. Pushes metrics OUT: no inbound rule.

USAGE:
  telegraf-register -InfluxUrl <url> -TokenFile <file> -Org <o> [-Bucket telegraf]
  telegraf-register -ConfigUrl <http-url-to-telegraf.conf>
  telegraf-register -ConfigFile <C:\path\telegraf.conf>
  telegraf-register -Help

PARAMETERS:
  -InfluxUrl        (required unless -ConfigUrl/-ConfigFile) InfluxDB v2 URL the agent pushes to.
  -TokenFile        PREFERRED. File whose first line is the InfluxDB v2 API token. Never appears in
                    the process table, in a 4688 event, or in the transcript header.
  -Token            DEPRECATED, kept for compatibility. An InfluxDB v2 API token is a bearer
                    credential for the whole organization; passed here it is visible in
                    Win32_Process.CommandLine and in Windows Security event 4688 (this estate can
                    enable ProcessCreationIncludeCmdLine and forward Security off-box). Use
                    -TokenFile or the environment variable YC_TELEGRAF_TOKEN instead.
  -Org              InfluxDB v2 organization.
  -Bucket           InfluxDB v2 bucket (default telegraf).
  -ConfigUrl        Fetch a complete telegraf.conf from this URL instead of generating one.
  -ConfigFile       Use this local telegraf.conf instead of generating one.
  -ZipPath          Explicit staged telegraf zip. Default: newest C:\Scripts\telegraf-*_windows_amd64.zip
                    by PARSED version.
  -DownloadUrl      Download the zip instead of using a staged one (TLS 1.2+, retried).
  -Sha256           Expected SHA256 of the zip. Strongly recommended.
  -InstallDir       Install folder. Default C:\Program Files\Telegraf.
  -ServiceName      Windows service name. Default telegraf.
  -AddOutboundRule  Create an outbound allow rule scoped to telegraf.exe and the endpoint host/port,
                    AFTER the agent is proven. Off by default: Windows allows outbound by default,
                    so the old unconditional rule was noise.
  -Force            Rewrite telegraf.conf even if the content is unchanged.
  -Help             Show this help and exit 0.

EXAMPLES:
  set YC_TELEGRAF_TOKEN=...
  telegraf-register -InfluxUrl http://10.0.0.7:8086 -Org yc -Bucket win
  telegraf-register -InfluxUrl http://10.0.0.7:8086 -TokenFile C:\Scripts\.influx.token -Org yc
  telegraf-register -ConfigFile C:\Scripts\telegraf.conf
  telegraf-register -Help

PROOF PERFORMED (in this order - any failure is a non-zero exit):
  1. telegraf.exe --version                              -> version recorded in the log
  2. telegraf.exe --config "<conf>" --test               -> exit 0 AND at least one metric line
  3. service Running, polled, then re-checked after a settle window
  4. GET <InfluxUrl>/health                              -> 200 (endpoint reachability), when the
                                                            config was generated from -InfluxUrl

EXIT CODES:
  0  Verified: config validated, service Running, endpoint reachable.
  1  Failure at any step.
  2  Usage error (no -InfluxUrl and no -ConfigUrl/-ConfigFile, or -InfluxUrl with no token/org).
  5  Not elevated.
  6  No outbound internet when -ConfigUrl / -DownloadUrl was used.

Log: C:\Scripts\telegraf-register.log
"@

if($Help){ Write-Host $HelpText -ForegroundColor Cyan; Exit-Yc 0 'help shown' 'OK' }
if(-not $InfluxUrl -and -not $ConfigUrl -and -not $ConfigFile){
  Write-Host $HelpText -ForegroundColor Cyan
  Exit-Yc 2 'One of -InfluxUrl, -ConfigUrl or -ConfigFile is required.' 'ERROR'
}
if(($ConfigUrl -and $ConfigFile) -or ($InfluxUrl -and ($ConfigUrl -or $ConfigFile))){
  Write-Host $HelpText -ForegroundColor Cyan
  Exit-Yc 2 '-InfluxUrl, -ConfigUrl and -ConfigFile are mutually exclusive - pick one.' 'ERROR'
}

Assert-YcPrereqs -NeedAdmin
$script:YcExit   = 1
$script:YcTemp   = $null
$script:YcSecret = $null
$script:YcBackup = $null
$script:YcCfgPath = $null

# ------------------------------------------------------------------ helpers

function Write-YcAsciiFile{
  param([string]$Path,[string]$Content)
  $sw = New-Object System.IO.StreamWriter($Path,$false,(New-Object System.Text.ASCIIEncoding))
  try{ $sw.Write($Content) } finally{ $sw.Close() }
}

function Invoke-YcNative{
  param([string]$File,[string[]]$Arguments)
  $ErrorActionPreference = 'Continue'
  $out = & $File @Arguments 2>&1
  $rc  = $LASTEXITCODE
  $txt = @()
  foreach($o in $out){ if($null -ne $o){ $txt += ([string]$o) } }
  return (New-Object psobject -Property @{ Output = $txt; ExitCode = $rc })
}

function Get-YcRedacted([string]$Text){
  $t = $Text
  if($script:YcSecret){ $t = ($t -replace [regex]::Escape($script:YcSecret),'***REDACTED***') }
  return (Protect-YcSecret $t)
}

function Protect-YcFileAcl{
  param([string]$Path)
  $r1 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/inheritance:r')
  $r2 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/grant','*S-1-5-18:(F)','*S-1-5-32-544:(F)')
  if($r1.ExitCode -ne 0 -or $r2.ExitCode -ne 0){
    Write-YcLog ('icacls FAILED on ' + $Path + ' (inheritance rc=' + $r1.ExitCode + ', grant rc=' +
      $r2.ExitCode + '): ' + (($r1.Output + $r2.Output) -join ' ')) 'ERROR'
    return $false
  }
  $allowed = @('S-1-5-18','S-1-5-32-544')
  $acl = Get-Acl -LiteralPath $Path
  if(-not $acl.AreAccessRulesProtected){
    Write-YcLog ('VERIFICATION FAILED: inheritance is still enabled on ' + $Path) 'ERROR'
    return $false
  }
  $bad = @()
  foreach($ace in $acl.Access){
    $sid = $null
    try{ $sid = $ace.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch{ $sid = [string]$ace.IdentityReference }
    if($allowed -notcontains $sid){ $bad += ([string]$ace.IdentityReference + ' (' + $sid + ')') }
  }
  if($bad.Count -gt 0){
    Write-YcLog ('VERIFICATION FAILED: ' + $Path + ' is still accessible to: ' + ($bad -join ', ')) 'ERROR'
    return $false
  }
  Write-YcLog ('ACL verified on ' + $Path + ': inheritance removed, trustees are exactly SYSTEM ' +
    'and BUILTIN\Administrators.') 'OK'
  return $true
}

function Set-YcManagedFile{
  param([string]$Path,[string]$Content,[switch]$Always)
  if(Test-Path -LiteralPath $Path){
    $cur = Get-Content -LiteralPath $Path -Raw
    if($null -eq $cur){ $cur = '' }
    if($cur -eq $Content -and -not $Always){ Write-YcLog ('Unchanged, left in place: ' + $Path); return $true }
    $bak = $Path + '.bak-' + (Get-Date).ToString('yyyyMMddHHmmss')
    Copy-Item -LiteralPath $Path -Destination $bak -Force
    $script:YcBackup = $bak
    Write-YcLog ('Content changed; previous config backed up to ' + $bak) 'WARN'
  }
  Write-YcAsciiFile -Path $Path -Content $Content
  Write-YcLog ('Wrote ' + $Path)
  return $true
}

function Get-YcServiceObject([string]$Name){
  return (Get-Service | Where-Object { $_.Name -eq $Name } | Select-Object -First 1)
}

function Get-YcTelegrafToken{
  if($TokenFile){
    if(-not (Test-Path -LiteralPath $TokenFile)){
      Write-YcLog ('-TokenFile not found: ' + $TokenFile) 'ERROR'; return $null
    }
    foreach($l in (Get-Content -LiteralPath $TokenFile)){
      if($null -ne $l -and $l.Trim().Length -gt 0){
        Write-YcLog ('Token read from ' + $TokenFile + ' (never on a command line).')
        return $l.Trim()
      }
    }
    Write-YcLog ('-TokenFile ' + $TokenFile + ' is empty.') 'ERROR'
    return $null
  }
  if($env:YC_TELEGRAF_TOKEN){
    Write-YcLog 'Token read from environment variable YC_TELEGRAF_TOKEN.'
    return $env:YC_TELEGRAF_TOKEN
  }
  if($Token){
    Write-YcLog ('-Token was passed on the command line. An InfluxDB v2 API token is a bearer ' +
      'credential for the whole organization, and that value is visible in Win32_Process.CommandLine, ' +
      'in Windows Security event 4688, and in the PowerShell transcript header. Use -TokenFile or ' +
      'YC_TELEGRAF_TOKEN instead. The value is scrubbed from this log when the run ends.') 'WARN'
    return $Token
  }
  return $null
}

# Per-service environment, read by the SCM at every service start. Not the machine environment:
# that is HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment, which every
# authenticated user can read and which is injected into every new process on the box.
function Set-YcServiceEnvironment{
  param([string]$Name,[string[]]$Values)
  $k = 'HKLM:\SYSTEM\CurrentControlSet\Services\' + $Name
  if(-not (Test-Path $k)){
    Write-YcLog ('Service key ' + $k + ' does not exist - cannot set the per-service environment.') 'ERROR'
    return $false
  }
  New-ItemProperty -Path $k -Name 'Environment' -PropertyType MultiString -Value $Values -Force | Out-Null
  $back = @((Get-ItemProperty -Path $k).Environment)
  if($back.Count -ne $Values.Count){
    Write-YcLog 'VERIFICATION FAILED: the per-service Environment value did not take.' 'ERROR'
    return $false
  }
  $names = @()
  foreach($v in $back){ $names += (([string]$v) -split '=')[0] }
  Write-YcLog ('Per-service Environment set under ' + $k + ' (names only: ' + ($names -join ', ') +
    '). Readable by SYSTEM and Administrators only; injected by the SCM at service start.') 'OK'
  return $true
}

function Get-YcTelegrafZip{
  if($ZipPath){
    if(-not (Test-Path -LiteralPath $ZipPath)){ Write-YcLog ('-ZipPath not found: ' + $ZipPath) 'ERROR'; return $null }
    return (Get-Item -LiteralPath $ZipPath)
  }
  if($DownloadUrl){
    Assert-YcPrereqs -NeedInternet
    if(-not $script:YcTemp){
      $script:YcTemp = Join-Path $env:TEMP ('tgraf_' + [guid]::NewGuid().ToString('N'))
      New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
    }
    $dst = Join-Path $script:YcTemp 'telegraf.zip'
    $got = Get-YcFile -Uri $DownloadUrl -OutFile $dst -Sha256 $Sha256 -MinBytes 1048576
    if(-not $got){ return $null }
    return (Get-Item -LiteralPath $dst)
  }
  $all = Get-ChildItem -Path 'C:\Scripts\telegraf-*_windows_amd64.zip' -File -ErrorAction Ignore
  if(-not $all){ return $null }
  return ($all | Sort-Object {
      $m = [regex]::Match($_.Name,'(\d+\.\d+\.\d+)')
      if($m.Success){ [version]$m.Groups[1].Value } else { [version]'0.0.0' }
    } -Descending | Select-Object -First 1)
}

# ------------------------------------------------------------------ main

function Invoke-Main{

  # --- 0. inputs -----------------------------------------------------------------------
  $tok = $null
  if($InfluxUrl){
    if(-not $Org){
      Write-YcLog '-InfluxUrl requires -Org (the InfluxDB v2 organization).' 'ERROR'
      $script:YcExit = 2; return
    }
    $tok = Get-YcTelegrafToken
    if(-not $tok){
      Write-YcLog ('-InfluxUrl was given with no token. Supply -TokenFile <file>, set ' +
        'YC_TELEGRAF_TOKEN, or (not recommended) pass -Token. Without a token every write to ' +
        'InfluxDB returns 401 and the agent would ship nothing while this command reported OK.') 'ERROR'
      $script:YcExit = 2; return
    }
    $script:YcSecret = $tok
  }

  # --- 1. the binary -------------------------------------------------------------------
  $zip = Get-YcTelegrafZip
  if(-not $zip){
    Write-YcLog ('No telegraf installer. Stage C:\Scripts\telegraf-<ver>_windows_amd64.zip, or pass ' +
      '-ZipPath / -DownloadUrl.') 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcFile -Path $zip.FullName -MinBytes 1048576 -Because 'telegraf zip')){ $script:YcExit = 1; return }
  $h = (Get-FileHash -LiteralPath $zip.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
  if($Sha256 -and -not $DownloadUrl){
    if($h -ne $Sha256.Trim().ToUpperInvariant()){
      Write-YcLog ('SHA256 MISMATCH on ' + $zip.Name + ': expected ' + $Sha256.Trim().ToUpperInvariant() +
        ', got ' + $h + '. Refusing to install.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('SHA256 verified: ' + $h) 'OK'
  }elseif(-not $DownloadUrl){
    Write-YcLog ('No -Sha256 pin supplied. Archive hash is ' + $h + ' - pin it on the next run.') 'WARN'
  }

  if(-not $script:YcTemp){
    $script:YcTemp = Join-Path $env:TEMP ('tgraf_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
  }
  $ex = Join-Path $script:YcTemp 'x'
  New-Item -ItemType Directory -Path $ex -Force | Out-Null
  Expand-Archive -Path $zip.FullName -DestinationPath $ex -Force
  $src = Get-ChildItem -Path $ex -Recurse -Filter 'telegraf.exe' -File | Select-Object -First 1
  if(-not $src){ Write-YcLog ('telegraf.exe not found inside ' + $zip.Name) 'ERROR'; $script:YcExit = 1; return }

  if(-not (Test-Path -LiteralPath $InstallDir)){ New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
  $exePath = Join-Path $InstallDir 'telegraf.exe'
  $existing = Get-YcServiceObject $ServiceName
  if($existing -and $existing.Status -eq 'Running'){
    Write-YcLog ('Existing service ' + $ServiceName + ' is Running; stopping it to replace the binary.')
    Stop-Service -Name $ServiceName -Force -ErrorAction Stop
    Start-Sleep -Seconds 2
  }
  Copy-Item -LiteralPath $src.FullName -Destination $exePath -Force
  if(-not (Assert-YcFile -Path $exePath -MinBytes 1048576 -Because 'installed telegraf binary')){ $script:YcExit = 1; return }

  $ver = Invoke-YcNative -File $exePath -Arguments @('--version')
  $verLine = ($ver.Output | Where-Object { $_.Trim().Length -gt 0 } | Select-Object -First 1)
  if($ver.ExitCode -ne 0 -and -not $verLine){
    Write-YcLog ('telegraf.exe --version failed (exit ' + $ver.ExitCode + ').') 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Installed binary: ' + $exePath + ' -- ' + ([string]$verLine).Trim()) 'OK'

  # --- 2. the configuration ------------------------------------------------------------
  $script:YcCfgPath = Join-Path $InstallDir 'telegraf.conf'
  $conf = $null
  $probeHealth = $false
  if($ConfigUrl){
    Assert-YcPrereqs -NeedInternet
    $dl = Join-Path $script:YcTemp 'telegraf.conf'
    $got = Get-YcFile -Uri $ConfigUrl -OutFile $dl -MinBytes 8 -AllowText
    if(-not $got){ Write-YcLog ('Could not fetch ' + $ConfigUrl) 'ERROR'; $script:YcExit = 1; return }
    $conf = Get-Content -LiteralPath $dl -Raw
  }elseif($ConfigFile){
    if(-not (Test-Path -LiteralPath $ConfigFile)){
      Write-YcLog ('-ConfigFile not found: ' + $ConfigFile) 'ERROR'; $script:YcExit = 1; return
    }
    $conf = Get-Content -LiteralPath $ConfigFile -Raw
  }else{
    $probeHealth = $true
    $lines = @(
      '# Managed by YallaCloud telegraf-register. Regenerated when the content changes;',
      '# the previous file is kept as telegraf.conf.bak-<timestamp>.',
      '# The InfluxDB token is NOT in this file. It is stored in the service''s own',
      '# Environment REG_MULTI_SZ (HKLM\SYSTEM\CurrentControlSet\Services\' + $ServiceName + '),',
      '# which only SYSTEM and Administrators can read, and resolved by Telegraf''s',
      '# documented ${VAR} substitution.',
      '[agent]',
      '  interval = "10s"',
      '  round_interval = true',
      '  metric_batch_size = 1000',
      '  metric_buffer_limit = 10000',
      '  collection_jitter = "2s"',
      '  flush_interval = "10s"',
      '  flush_jitter = "3s"',
      '  hostname = "' + $env:COMPUTERNAME + '"',
      '  omit_hostname = false',
      '',
      '[[inputs.cpu]]',
      '  percpu = false',
      '  totalcpu = true',
      '  report_active = true',
      '',
      '[[inputs.mem]]',
      '[[inputs.system]]',
      '',
      '[[inputs.disk]]',
      '  ignore_fs = ["tmpfs", "devtmpfs"]',
      '',
      '[[inputs.diskio]]',
      '',
      '# win_perf_counters WITHOUT object sub-tables collects nothing at all - the old',
      '# generated config had exactly that. Real objects below.',
      '[[inputs.win_perf_counters]]',
      '  [[inputs.win_perf_counters.object]]',
      '    ObjectName = "Processor"',
      '    Instances = ["_Total"]',
      '    Counters = ["% Processor Time", "% Idle Time", "% Interrupt Time"]',
      '    Measurement = "win_cpu"',
      '  [[inputs.win_perf_counters.object]]',
      '    ObjectName = "Memory"',
      '    Instances = ["------"]',
      '    Counters = ["Available Bytes", "Committed Bytes", "Pages/sec"]',
      '    Measurement = "win_mem"',
      '  [[inputs.win_perf_counters.object]]',
      '    ObjectName = "LogicalDisk"',
      '    Instances = ["*"]',
      '    Counters = ["% Free Space", "Free Megabytes", "Avg. Disk sec/Read", "Avg. Disk sec/Write"]',
      '    Measurement = "win_disk"',
      '  [[inputs.win_perf_counters.object]]',
      '    ObjectName = "System"',
      '    Instances = ["------"]',
      '    Counters = ["Context Switches/sec", "System Calls/sec", "Processor Queue Length"]',
      '    Measurement = "win_system"',
      '',
      '[[outputs.influxdb_v2]]',
      '  urls = ["' + $InfluxUrl + '"]',
      '  token = "${INFLUX_TOKEN}"',
      '  organization = "' + $Org + '"',
      '  bucket = "' + $Bucket + '"'
    )
    $conf = ($lines -join "`r`n") + "`r`n"
  }
  if($null -eq $conf -or $conf.Trim().Length -eq 0){
    Write-YcLog 'The configuration is empty. Refusing to install it.' 'ERROR'; $script:YcExit = 1; return
  }
  if($conf -match '(?i)<\s*(html|!doctype html|head|body)\b'){
    Write-YcLog 'The configuration looks like an HTML page, not TOML. Refusing to install it.' 'ERROR'
    $script:YcExit = 1; return
  }
  Set-YcManagedFile -Path $script:YcCfgPath -Content $conf -Always:$Force | Out-Null
  if(-not (Protect-YcFileAcl -Path $script:YcCfgPath)){ $script:YcExit = 1; return }

  # --- 3. PROOF: the VENDOR validator, before the service is touched ------------------
  # https://github.com/influxdata/telegraf/blob/master/docs/COMMANDS_AND_FLAGS.md
  # The token reaches the validator through THIS process's environment block, which is
  # inherited by that child only - it never appears on a command line.
  if($tok){ $env:INFLUX_TOKEN = $tok }
  Write-YcLog ('Validating with the vendor validator: "' + $exePath + '" --config "' +
    $script:YcCfgPath + '" --test')
  $chk = Invoke-YcNative -File $exePath -Arguments @('--config',$script:YcCfgPath,'--test')
  if($tok){ Remove-Item Env:\INFLUX_TOKEN -ErrorAction SilentlyContinue }
  $metricLines = 0
  foreach($l in $chk.Output){
    $s = [string]$l
    if($s.Trim().Length -eq 0){ continue }
    if($s -match '^(win_|cpu|mem|disk|diskio|system|swap)[,\s]'){ $metricLines++ }
  }
  foreach($l in ($chk.Output | Select-Object -First 25)){
    if($l.Trim().Length -gt 0){ Write-Host ('    ' + (Get-YcRedacted $l)) }
  }
  if($chk.ExitCode -ne 0){
    Write-YcLog ('VERIFICATION FAILED: telegraf --test exited ' + $chk.ExitCode + '. The configuration ' +
      'is invalid or an input cannot run; the service was NOT installed or started.') 'ERROR'
    $script:YcExit = 1; return
  }
  if($metricLines -lt 1){
    Write-YcLog ('VERIFICATION FAILED: telegraf --test exited 0 but produced NO metric lines, so every ' +
      'input collected nothing (this is what an empty [[inputs.win_perf_counters]] with no object ' +
      'sub-tables looks like). Refusing to install a collector that collects nothing.') 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Vendor config validation passed: --test exit 0 and ' + $metricLines + ' metric lines ' +
    'produced by the inputs.') 'OK'

  # --- 4. the service ------------------------------------------------------------------
  # https://github.com/influxdata/telegraf/blob/master/docs/WINDOWS_SERVICE.md
  $wantBin = '"' + $exePath + '" --config "' + $script:YcCfgPath + '" --service-name "' + $ServiceName + '"'
  $svc = Get-YcServiceObject $ServiceName
  $needInstall = $true
  if($svc){
    $curBin = ''
    $k = 'HKLM:\SYSTEM\CurrentControlSet\Services\' + $ServiceName
    if(Test-Path $k){ try{ $curBin = [string](Get-ItemProperty -Path $k).ImagePath }catch{} }
    if($curBin -like ('*' + $exePath + '*') -and $curBin -like ('*' + $script:YcCfgPath + '*')){
      Write-YcLog ('Service ' + $ServiceName + ' already points at the right binary and config - ' +
        'reusing it (the old script uninstalled and reinstalled unconditionally, destroying any ' +
        'custom service settings).')
      $needInstall = $false
    }else{
      Write-YcLog ('Service ' + $ServiceName + ' exists with a different ImagePath; reinstalling it.')
      Write-YcLog ('  old: ' + $curBin)
      $u = Invoke-YcNative -File $exePath -Arguments @('--service-name',$ServiceName,'service','uninstall')
      if($u.ExitCode -ne 0){
        Write-YcLog ('telegraf service uninstall returned ' + $u.ExitCode + ': ' + ($u.Output -join ' ')) 'WARN'
      }
      $deadline = (Get-Date).AddSeconds(60)
      while((Get-Date) -lt $deadline -and (Get-YcServiceObject $ServiceName)){ Start-Sleep -Seconds 2 }
      if(Get-YcServiceObject $ServiceName){
        Write-YcLog ('Service ' + $ServiceName + ' is still present 60s after uninstall. Refusing to ' +
          'continue and silently leave the OLD binary running.') 'ERROR'
        $script:YcExit = 1; return
      }
    }
  }
  if($needInstall){
    $ins = Invoke-YcNative -File $exePath -Arguments @('--config',$script:YcCfgPath,'--service-name',$ServiceName,'service','install','--auto-restart')
    if($ins.ExitCode -ne 0){
      Write-YcLog ('telegraf "service install --auto-restart" returned ' + $ins.ExitCode + ': ' +
        ($ins.Output -join ' ') + ' - retrying without --auto-restart.') 'WARN'
      $ins = Invoke-YcNative -File $exePath -Arguments @('--config',$script:YcCfgPath,'--service-name',$ServiceName,'service','install')
    }
    if($ins.ExitCode -ne 0){
      Write-YcLog ('VERIFICATION FAILED: telegraf "service install" exited ' + $ins.ExitCode + ': ' +
        ($ins.Output -join ' ') + '. The old script logged this output and then reported OK anyway.') 'ERROR'
      $script:YcExit = 1; return
    }
    if(-not (Get-YcServiceObject $ServiceName)){
      Write-YcLog ('VERIFICATION FAILED: service ' + $ServiceName + ' does not exist after "service ' +
        'install" returned 0.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('Service ' + $ServiceName + ' installed.') 'OK'
  }

  # The token goes into the SERVICE's environment, not the machine environment.
  if($tok){
    if(-not (Set-YcServiceEnvironment -Name $ServiceName -Values @('INFLUX_TOKEN=' + $tok))){
      $script:YcExit = 1; return
    }
  }

  $sc1 = Invoke-YcNative -File 'sc.exe' -Arguments @('config',$ServiceName,'start=','delayed-auto')
  if($sc1.ExitCode -ne 0){
    Write-YcLog ('sc.exe config start= delayed-auto returned ' + $sc1.ExitCode + ': ' + ($sc1.Output -join ' ')) 'WARN'
  }
  $sc2 = Invoke-YcNative -File 'sc.exe' -Arguments @('failure',$ServiceName,'reset=','60','actions=','restart/5000/restart/5000/restart/30000')
  if($sc2.ExitCode -ne 0){
    Write-YcLog ('sc.exe failure returned ' + $sc2.ExitCode + ': ' + ($sc2.Output -join ' ')) 'WARN'
  }

  # --- 5. PROOF: it runs and STAYS running --------------------------------------------
  $svc = Get-YcServiceObject $ServiceName
  try{
    if($svc.Status -eq 'Running'){ Restart-Service -Name $ServiceName -Force -ErrorAction Stop }
    else{ Start-Service -Name $ServiceName -ErrorAction Stop }
  }catch{
    Write-YcLog ('Start-Service ' + $ServiceName + ' FAILED: ' + $_.Exception.Message) 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcService -Name $ServiceName -TimeoutSec 60 -Because 'Telegraf agent')){ $script:YcExit = 1; return }
  Start-Sleep -Seconds 15
  $svc2 = Get-YcServiceObject $ServiceName
  if((-not $svc2) -or ($svc2.Status -ne 'Running')){
    $st = 'absent'; if($svc2){ $st = [string]$svc2.Status }
    Write-YcLog ('VERIFICATION FAILED: ' + $ServiceName + ' reached Running but is now "' + $st +
      '" 15s later - it exited on the configuration it just loaded.') 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Service ' + $ServiceName + ' is Running and stayed Running.') 'OK'

  # --- 6. PROOF: the output endpoint is actually reachable ----------------------------
  if($probeHealth){
    $health = ($InfluxUrl.TrimEnd('/')) + '/health'
    if(-not (Assert-YcHttp -Uri $health -ExpectStatus 200 -TimeoutSec 45)){
      Write-YcLog ('VERIFICATION FAILED: ' + $health + ' did not answer 200. Telegraf is running but ' +
        'the InfluxDB endpoint it writes to is not reachable from this host, so no metric will ever ' +
        'land. Fix egress/DNS/the URL and re-run.') 'ERROR'
      $script:YcExit = 1; return
    }
  }

  # --- 7. side effects ONLY after the thing they support is proven --------------------
  if($AddOutboundRule){
    $rport = 0
    $rhost = ''
    try{
      $u = [uri]$InfluxUrl
      $rhost = $u.Host
      $rport = $u.Port
    }catch{ $rport = 0 }
    if($rport -le 0){
      Write-YcLog ('-AddOutboundRule: could not parse a host/port out of "' + $InfluxUrl + '" - no rule ' +
        'created.') 'WARN'
    }else{
      $rn = 'YallaCloud telegraf out ' + $rport
      if(Get-NetFirewallRule -DisplayName $rn -ErrorAction Ignore){
        Write-YcLog ('Outbound rule already present: ' + $rn)
      }else{
        try{
          New-NetFirewallRule -DisplayName $rn -Direction Outbound -Action Allow -Protocol TCP `
            -RemotePort $rport -RemoteAddress $rhost -Program $exePath -Profile Any `
            -Description 'Telegraf egress to InfluxDB. Managed by YallaCloud.' -ErrorAction Stop | Out-Null
          Write-YcLog ('Outbound allow added, scoped to telegraf.exe and ' + $rhost + ':' + $rport) 'OK'
        }catch{
          Write-YcLog ('Outbound rule creation FAILED: ' + $_.Exception.Message) 'WARN'
        }
      }
    }
  }

  Write-YcLog ('DONE. ' + $ServiceName + ' Running, config validated by "--test" with ' + $metricLines +
    ' metric lines' + $(if($probeHealth){', InfluxDB /health 200'}else{''}) + ', token stored in the ' +
    'per-service Environment (never on a command line). No inbound port opened.') 'OK'
  $script:YcExit = 0
}

try{
  Invoke-Main | Out-Null
}catch{
  Write-YcLog ('UNHANDLED EXCEPTION: ' + (Get-YcRedacted $_.Exception.Message)) 'ERROR'
  if($_.ScriptStackTrace){ Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}finally{
  if($env:INFLUX_TOKEN){ Remove-Item Env:\INFLUX_TOKEN -ErrorAction SilentlyContinue }
  if($script:YcTemp -and (Test-Path -LiteralPath $script:YcTemp)){
    try{ Remove-Item -LiteralPath $script:YcTemp -Recurse -Force }
    catch{ Write-YcLog ('Could not remove temp dir ' + $script:YcTemp + ': ' + $_.Exception.Message) 'WARN' }
  }
}

if($script:YcExit -eq 0){ Exit-Yc 0 'telegraf-register verified' 'OK' }
Exit-Yc $script:YcExit 'telegraf-register FAILED - nothing was reported as working that is not proven' 'ERROR'
