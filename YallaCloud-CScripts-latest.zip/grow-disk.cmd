@echo off
rem grow-disk [-DriveLetter C,D] [-MinGrowMB 64] [-WhatIf] [-Help]
rem
rem Rescans storage and extends a partition into ADJACENT unallocated space after the hypervisor
rem has grown the virtual disk. Online, no reboot. THIS REWRITES THE PARTITION TABLE, so run
rem   grow-disk -WhatIf
rem first: it reports exactly what would change and changes nothing.
rem A partition is REFUSED with the reason named when the disk is offline or read-only, the
rem volume is not NTFS/ReFS, or another partition on the same disk starts after it (in which
rem case the free space is not adjacent). Every resize is proven by reading the partition and
rem volume size back - the old version printed "extended D:" whenever Resize-Partition did not
rem throw, with $ErrorActionPreference set to SilentlyContinue.
rem Logs to C:\Scripts\grow-disk.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Grow-Disk.ps1" %*
exit /b %ERRORLEVEL%
