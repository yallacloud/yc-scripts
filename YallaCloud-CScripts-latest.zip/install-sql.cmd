@echo off
setlocal
rem ================================================================================================
rem install-sql - unattended SQL Server Evaluation OR Express install + patch + client tooling +
rem               configuration + VERIFIED Ola Hallengren backups. Wrapper for C:\Scripts\Install-Sql.ps1.
rem
rem WHAT CHANGED, AND WHY:
rem   - The usage comment now lists every parameter, including the ones the old wrapper omitted
rem     (-ChadminPassword, -Edition) and the many new ones.
rem   - It no longer advertises -SaPassword as the normal way to set the sa password. Anything on
rem     this command line is readable by any local user through the process table, and in the
rem     cloud-init path it also sits in CloudStack user-data. Use -SaPasswordFile instead.
rem   - Explicit "exit /b %ERRORLEVEL%" so the real exit code reaches cloud-init / the RMM instead
rem     of relying on cmd's implicit propagation.
rem
rem THE ONLY COMMAND MOST PEOPLE NEED:
rem
rem   install-sql -Version 2019
rem
rem That is the whole thing. Engine, patching, ODBC/OLE DB/sqlcmd, SSMS, firewall, tuning, verified
rem Ola Hallengren backups and their scheduled tasks. It reboots if it has to and carries on by
rem itself afterwards. It exits non-zero if any of that could not be PROVED.
rem
rem Second command, for a change window where YOU want to do the restart:
rem
rem   install-sql -Version 2019 -NoReboot
rem
rem THE WAY BACK OUT:
rem
rem   install-sql -InstanceName YCEXP -Uninstall
rem
rem Removes that instance and PROVES it is gone - no registry entry, no service. It uses the
rem instance's own setup.exe from Program Files, so it still works long after the install media was
rem cleaned up. It REFUSES if the instance holds user databases (it names them) or if it cannot be
rem reached to ask, unless you add -Force. The six maintenance scheduled tasks for that instance are
rem removed first, so they cannot keep firing at an engine that is not there.
rem Data and backup folders are KEPT unless you also pass -RemoveData.
rem
rem SQL SERVER EXPRESS - free, no product key, same command:
rem
rem   install-sql -Version 2019 -Edition Express -InstanceName YCEXPRESS
rem
rem Express is a separate free product with its own installer, so this fetches and unpacks the
rem Express package instead of the Evaluation ISO - no manual download, nothing to stage. From
rem there it is the SAME run: firewall, TCP port, data directories, mixed mode, SSMS, ODBC/OLE DB/
rem sqlcmd, dbatools, the Ola Hallengren procedures and their scheduled tasks.
rem   Express has NO SQL Server Agent, so the Agent settings are dropped from the answer file.
rem   Backups, integrity checks and index maintenance still run - the schedule was already Windows
rem   scheduled tasks running as SYSTEM, never Agent jobs. backup-sql drops COMPRESSION by itself
rem   on an edition that cannot compress, so nothing needs passing for that either.
rem   Product limits you are choosing: 10 GB per database, ~1410 MB buffer pool, 1 socket/4 cores.
rem   No product key exists for Express and none can be applied - do not run activate-sql on it.
rem
rem Everything below is an override for a case where the defaults are wrong. If you do not know
rem that you need one, you do not need one.
rem
rem USAGE:
rem   install-sql -Version <2016|2017|2019|2022|2025> [options]
rem   install-sql -Help
rem
rem CORE OPTIONS:
rem   -Version <2016|2017|2019|2022|2025>   -Edition Evaluation|Express   -InstanceName <name>
rem   -Features <comma list>                -DataDir <path>          -BackupDir <path>
rem   -IsoPath <path>                       -WorkDir <path>          -Collation <name>
rem   -SysadminAccounts <a,b>               -Maintenance on|off      -Help
rem   -Unattended is accepted but no longer needed: supplying any parameter already suppresses the
rem   prompts. -AllowReboot is accepted but no longer needed: rebooting is the default.
rem
rem SECRETS (prefer the file form - a command line is world-readable on this machine):
rem   -SaPasswordFile <path>    file whose first line is the sa password    (PREFERRED)
rem   -SaPassword <pwd>         accepted for compatibility, but visible in the process table
rem   -ChadminPassword <pwd>    only needed when S4U batch logon is blocked by policy on the image
rem
rem AFTER-THE-ENGINE OPTIONS (the "requires ssms after" half):
rem   -ClientTools on|off   ODBC Driver 18 + OLE DB Driver 19 + sqlcmd/bcp + SqlServer PS module
rem   -Ssms on|off          -SsmsVersion auto|22|21|20
rem   -Patch on|off         -CuPath <staged CU exe>
rem
rem RETENTION (the rolling window Ola prunes, stated in DAYS - was a hardcoded 7):
rem   -RetainFullDays 35    -RetainDiffDays 14    -RetainLogDays 14
rem   -MonthlyKeep 12       ONE retained full per calendar month, kept outside the window. 0 disables.
rem   -MonthlyDir <path>    default C:\dbbackupmonthly
rem   The monthly is a 7th task, YC-SqlBackupMonthly-<inst>, running sql-archive daily at 05:15.
rem
rem INSTANCE / NETWORK OPTIONS:
rem   -Port <n>             -ManagementCidr <cidr[,cidr]>   -Firewall on|off
rem   -MaxDop <n>           -MaxServerMemoryMB <n>          -CostThreshold <n>
rem   -TempDbFileCount <n>  -TempDbFileSizeMB <n>
rem   -InstantFileInit on|off   -LockPagesInMemory on|off   -PowerPlan on|off
rem   -OlaZipPath <zip>     -LogBackupMinutes <n>
rem   -NoReboot (= -ManualReboot)           -KeepMedia               -Force
rem     REBOOTING IS THE DEFAULT. When a reboot is genuinely required the run restarts the machine
rem     and RESUMES ITSELF afterwards via a SYSTEM startup task, so a first-boot install finishes on
rem     its own. -NoReboot turns that off: the run stops instead and records the reason in
rem     C:\Scripts\install-sql.reboot-required, for a change window where you restart by hand.
rem     The automatic resume is skipped, with a WARN, if -SaPassword or -ChadminPassword was passed
rem     in plaintext, because the task definition would persist it - use -SaPasswordFile instead.
rem
rem EXIT CODES: 0 ok | 1 generic | 2 preflight refused | 3 media | 4 setup | 5 not admin |
rem             6 no internet | 7 sqlcmd missing | 8 engine verification | 9 backups not installed |
rem             10 final verification | 99 unhandled
rem
rem Logs to C:\Scripts\install-sql.log (and the Application event log, source YallaCloud).
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Install-Sql.ps1" %*
exit /b %ERRORLEVEL%
