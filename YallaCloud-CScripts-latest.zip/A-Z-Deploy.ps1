# =============================================================
# A-Z-Deploy.ps1  v2.42  (2026-08-16)
# YALLACLOUD post-deploy "A-Z" run for a freshly deployed clone.
# Run elevated on the VM AFTER first boot + cloudbase-init.
# Fixes SSH, sets firewall, rotates password, verifies yallacloud.
#
# WHAT CHANGED IN v2.42 (and WHY)
#   1. P0-12 SECRET LEAK: the cleartext Administrator password was passed to
#      Write-YcLog (which mirrors every line into the Application event log under
#      source 'YallaCloud', readable by Event Log Readers and shipped to the
#      tenant SIEM) and was printed inside a live Start-Transcript, so it was
#      appended permanently to C:\Scripts\a-z-deploy.log. Every password ever set
#      on the VM was recoverable from one file. The password is now NEVER passed
#      to Write-YcLog, and the single Write-Host that shows it to the operator is
#      wrapped in Stop-Transcript / Start-Transcript so it never lands on disk.
#   2. P0-13 SSH BREAKAGE REPORTED AS SUCCESS: sshd_config was rewritten TWICE;
#      the second pass undid the Match-aware placement of the first and blindly
#      inserted Port/Subsystem before the last line of the file. Inside a Match
#      block that is fatal ("Directive 'Port' is not allowed within a Match
#      block") and sshd refuses to start; the restart used -EA SilentlyContinue
#      and the script logged "sshd restarted (Automatic)" anyway. Remote access
#      was gone and the log said it was fine, and each re-run made it worse. The
#      second pass is deleted, edits are idempotent (replace in place, never
#      append a duplicate, always ABOVE the first Match block), sshd_config is
#      backed up before editing, the result is validated with "sshd.exe -t" and
#      the backup is restored + the service recovered on any failure.
#   3. P0-14 A PASSWORD THAT IS NOT THE ACCOUNT'S PASSWORD: the generator used an
#      alphabet with no symbols and no guaranteed class coverage, so "net user"
#      often failed the complexity policy; net.exe returning non-zero does not
#      throw, so the catch never fired and the script logged success and printed
#      a password that did not work. wmic (used for PasswordExpires) is disabled
#      by default on Server 2025 so that silently did nothing either. Now:
#      Set-LocalUser -ErrorAction Stop, a CSPRNG generator that guarantees one
#      upper + one lower + one digit + one cmd-safe symbol, and the new password
#      is PROVEN with PrincipalContext.ValidateCredentials before it is reported.
#   4. The password no longer reaches the command line of a child process
#      (net.exe / wmic.exe arguments are visible in the process table and in
#      Windows 4688 audit events); Set-LocalUser takes a SecureString in-process.
#   5. Every exit path now calls Stop-YcLog <code> before "exit <code>", and the
#      exit code now reflects what actually happened instead of always 0.
#
# PowerShell 5.1 only. ASCII only. Windows Server 2016-2025. Idempotent.
# =============================================================
param(
  [string]$Hostname = "",
  [string]$AdminPassword = "",
  [switch]$SkipFirewall,
  [switch]$SkipSshFix,
  [switch]$Help
)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'a-z-deploy'
$ErrorActionPreference = 'Continue'
$GIVER = '2.42'

if($Help){
@"
a-z-deploy  -  post-deploy A-Z setup for YALLACLOUD clones (v$GIVER)

WHAT IT DOES:
  A. SSH service fix   - make sshd_config directives idempotent and ALWAYS above
                         the first Match block, back it up, validate it with
                         'sshd -t', restart sshd and confirm it is Running
  B. Firewall          - outbound open + inbound app/agent ports (set-firewall)
  C. Password          - set/rotate local Administrator password (generates a
                         strong one if not given) and VERIFY it actually works
  D. Yallacloud        - verify yallacloud.cmd responds + -Version
  E. Hostname          - set computer name (if -Hostname given, then reboot)
  F. Tasks             - re-register first-boot tasks if missing (PwSetOnce etc.)

USAGE:
  a-z-deploy [-Hostname name] [-AdminPassword 'pass'] [-SkipFirewall] [-SkipSshFix] [-Help]

PARAMETERS:
  -Hostname        New computer name. A reboot is required to finish the rename.
  -AdminPassword   Password to set on the built-in Administrator account.
                   If omitted a strong random one is generated and PRINTED ONCE
                   to the console only - it is never written to the log file and
                   never written to the Windows event log. Capture it now.
  -SkipFirewall    Do not run C:\Scripts\Set-Firewall.ps1.
  -SkipSshFix      Do not touch sshd_config or the sshd service.
  -Help            Show this help and exit.

EXAMPLES:
  a-z-deploy
  a-z-deploy -Hostname win-app01
  a-z-deploy -AdminPassword 'Correct-Horse-9' -SkipFirewall
  a-z-deploy -SkipSshFix
  a-z-deploy -Help

EXIT CODES:
  0  all requested steps succeeded
  1  sshd_config failed validation, or the Administrator password could not be
     set/verified - do NOT treat the VM as ready
  5  not elevated (see _yc-lib.ps1 preflight)

Log: C:\Scripts\a-z-deploy.log   (the Administrator password is NOT in this file)
"@ | Write-Host -ForegroundColor Cyan
  Stop-YcLog 0; exit 0
}

Assert-YcPrereqs -NeedAdmin
Write-YcLog ("A-Z-Deploy v$GIVER starting on " + $env:COMPUTERNAME)

# Resolve the log path used for the transcript stop/start dance around the one
# Write-Host that shows the password. $script:YcLogFile is set by the library
# (dot-sourced, so it lands in this script scope); fall back if it is not there.
$YcLogPath = $script:YcLogFile
if(-not $YcLogPath){ $YcLogPath = 'C:\Scripts\a-z-deploy.log' }

# =============================================================
# Helpers
# =============================================================

# Unbiased index in [0,$Count) from a CSPRNG. Get-Random is not
# cryptographically secure and "(Get-Random) % n" is modulo-biased.
function Get-YcRandomIndex{
  param($Rng,[int]$Count)
  $bytes = New-Object 'byte[]' 2
  $max = 65536 - (65536 % $Count)
  do{
    $Rng.GetBytes($bytes)
    $v = ([int]$bytes[0] * 256) + [int]$bytes[1]
  } while($v -ge $max)
  return ($v % $Count)
}

# Strong password that is GUARANTEED to satisfy the Windows complexity policy
# (3 of 4 categories required; we always supply all 4) and that avoids every
# character that breaks cmd/batch quoting or PowerShell expansion:
#   excluded: " ' ` $ % & | < > ^ ( ) ! , ; = [ ] { } \ and space
# Look-alike characters (0 O o 1 l I) are excluded so an operator can retype it.
function New-YcStrongPassword{
  param([int]$Length = 20)
  if($Length -lt 14){ $Length = 14 }
  if($Length -gt 120){ $Length = 120 }
  $upper  = 'ABCDEFGHJKLMNPQRSTUVWXYZ'
  $lower  = 'abcdefghijkmnpqrstuvwxyz'
  $digit  = '23456789'
  $symbol = '#*-._+?@~'
  $all    = $upper + $lower + $digit + $symbol
  $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
  try{
    $chars = New-Object 'System.Collections.Generic.List[char]'
    foreach($set in @($upper,$lower,$digit,$symbol)){
      $chars.Add($set[(Get-YcRandomIndex $rng $set.Length)])
    }
    while($chars.Count -lt $Length){
      $chars.Add($all[(Get-YcRandomIndex $rng $all.Length)])
    }
    for($i = $chars.Count - 1; $i -gt 0; $i--){
      $j = Get-YcRandomIndex $rng ($i + 1)
      $t = $chars[$i]; $chars[$i] = $chars[$j]; $chars[$j] = $t
    }
    # Keep a letter first so the value is never mistaken for a switch by a
    # wrapper that forwards it unquoted.
    if("$($chars[0])" -notmatch '[A-Za-z]'){
      for($i = 1; $i -lt $chars.Count; $i++){
        if("$($chars[$i])" -match '[A-Za-z]'){
          $t = $chars[0]; $chars[0] = $chars[$i]; $chars[$i] = $t
          break
        }
      }
    }
    return (-join $chars)
  } finally { $rng.Dispose() }
}

# Place one sshd_config directive idempotently: replace the first existing
# (or commented) occurrence IN PLACE, drop any later duplicates, and never
# emit it at or below the first Match block.
#
# -StripBelowMatch additionally DELETES active occurrences found at or below the
# first Match block. Only pass it for keywords that sshd forbids inside a Match
# block (per sshd_config(5), Port and Subsystem are not in the permitted list;
# PasswordAuthentication and PubkeyAuthentication ARE permitted there and must
# be left alone, they are legitimate per-user overrides). Without this, a host
# already broken by v2.41 - which appended Port/Subsystem underneath a Match
# block - could never be repaired: sshd would keep refusing to start with
# "Directive 'Port' is not allowed within a Match block". Commented lines below
# the Match block are left intact so documentation is not destroyed.
function Set-YcSshDirective{
  param([string[]]$Lines,[string]$Name,[string]$Value,[switch]$StripBelowMatch)
  $re     = '^\s*#?\s*' + [regex]::Escape($Name) + '\b'
  $reLive = '^\s*' + [regex]::Escape($Name) + '\b'
  $matchIdx = -1
  for($i = 0; $i -lt $Lines.Count; $i++){
    if($Lines[$i] -match '^\s*Match\s'){ $matchIdx = $i; break }
  }
  $end = $Lines.Count
  if($matchIdx -ge 0){ $end = $matchIdx }
  $out = New-Object 'System.Collections.Generic.List[string]'
  $placed = $false
  for($i = 0; $i -lt $Lines.Count; $i++){
    if(($i -lt $end) -and ($Lines[$i] -match $re)){
      if(-not $placed){ $out.Add($Value); $placed = $true }
      continue
    }
    if(($i -eq $end) -and (-not $placed)){ $out.Add($Value); $placed = $true }
    if(($i -ge $end) -and $StripBelowMatch -and ($Lines[$i] -match $reLive)){ continue }
    $out.Add($Lines[$i])
  }
  if(-not $placed){ $out.Add($Value) }
  return ,$out.ToArray()
}

# Keywords sshd forbids inside a Match block. Anything else we manage is legal
# there and is left untouched.
$script:YcSshMatchIllegal = @('Port','Subsystem')

function Get-YcSshdExe{
  $cands = @(
    (Join-Path $env:ProgramFiles 'OpenSSH\OpenSSH-Win64\sshd.exe'),
    (Join-Path $env:ProgramFiles 'OpenSSH\sshd.exe'),
    (Join-Path $env:WINDIR 'System32\OpenSSH\sshd.exe')
  )
  foreach($p in $cands){ if(Test-Path $p){ return $p } }
  return $null
}

# Resolve the built-in Administrator by well-known RID -500 so a renamed
# account is still found; fall back to the literal name.
function Get-YcAdminAccount{
  $a = Get-LocalUser -ErrorAction SilentlyContinue | Where-Object { $_.SID.Value -match '-500$' } | Select-Object -First 1
  if(-not $a){ $a = Get-LocalUser -Name 'Administrator' -ErrorAction SilentlyContinue }
  return $a
}

$script:YcFailed = $false

# =============================================================
# A. SSH service fix  (P0-13)
# =============================================================
if(-not $SkipSshFix){
  Write-YcLog 'A) SSH service fix...'
  $cfg = 'C:\ProgramData\ssh\sshd_config'
  $bak = $cfg + '.yc.bak'
  $svc = Get-Service sshd -ErrorAction SilentlyContinue
  if(-not $svc){
    Write-YcLog 'sshd service not installed - SSH step skipped (nothing to break).' 'WARN'
  } elseif(-not (Test-Path $cfg)){
    Write-YcLog ('sshd_config not found at ' + $cfg + ' - SSH config step skipped.') 'WARN'
  } else {
    $wrote = $false
    try{
      $lines = @(Get-Content -Path $cfg -ErrorAction Stop)
      $directives = New-Object System.Collections.Specialized.OrderedDictionary
      $directives.Add('Port','Port 3222')
      $directives.Add('PasswordAuthentication','PasswordAuthentication no')
      $directives.Add('PubkeyAuthentication','PubkeyAuthentication yes')
      $directives.Add('Subsystem','Subsystem sftp "C:/Program Files/OpenSSH/OpenSSH-Win64/sftp-server.exe"')

      # Report any fatal leftovers from an earlier v2.41 run before repairing them.
      $firstMatch = -1
      for($i = 0; $i -lt $lines.Count; $i++){
        if($lines[$i] -match '^\s*Match\s'){ $firstMatch = $i; break }
      }
      if($firstMatch -ge 0){
        for($i = $firstMatch; $i -lt $lines.Count; $i++){
          foreach($bad in $script:YcSshMatchIllegal){
            if($lines[$i] -match ('^\s*' + $bad + '\b')){
              Write-YcLog ("Found '" + $bad + "' inside a Match block (line " + ($i+1) + ") - sshd cannot start with this. Removing it.") 'WARN'
            }
          }
        }
      }

      $new = $lines
      foreach($k in @($directives.Keys)){
        $strip = ($script:YcSshMatchIllegal -contains $k)
        $new = Set-YcSshDirective -Lines $new -Name $k -Value $directives[$k] -StripBelowMatch:$strip
      }

      if(($new -join "`n") -ne ($lines -join "`n")){
        Copy-Item -Path $cfg -Destination $bak -Force -ErrorAction Stop
        Write-YcLog ('sshd_config backed up to ' + $bak)
        Set-Content -Path $cfg -Value $new -Encoding ascii -ErrorAction Stop
        $wrote = $true
        Write-YcLog 'sshd_config updated (directives placed above the first Match block, duplicates removed).'
      } else {
        Write-YcLog 'sshd_config already correct - no change (idempotent).'
      }
    }catch{
      Write-YcLog ('SSH cfg edit error: ' + $_.Exception.Message) 'ERROR'
      Stop-YcLog 1; exit 1
    }

    # Validate BEFORE restarting. A bad config here means no remote access at all.
    $sshdExe = Get-YcSshdExe
    if(-not $sshdExe){
      Write-YcLog 'sshd.exe not found - cannot validate sshd_config before restart.' 'ERROR'
      if($wrote -and (Test-Path $bak)){
        Copy-Item -Path $bak -Destination $cfg -Force -ErrorAction SilentlyContinue
        Write-YcLog 'sshd_config restored from backup (unvalidated change reverted).' 'WARN'
      }
      Stop-YcLog 1; exit 1
    }

    # "sshd -t" also fails when no host keys exist yet (e.g. a migrated VM, or a
    # clone where the GISSHInit first-boot task never ran), which would look
    # exactly like a config syntax error and abort the deploy for the wrong
    # reason. Generate them the same way SSH-FirstBoot.ps1 does. Idempotent.
    if(-not (Test-Path 'C:\ProgramData\ssh\ssh_host_ed25519_key')){
      $kg = @((Join-Path $env:WINDIR 'System32\OpenSSH\ssh-keygen.exe'),
              (Join-Path $env:ProgramFiles 'OpenSSH\OpenSSH-Win64\ssh-keygen.exe'),
              (Join-Path $env:ProgramFiles 'OpenSSH\ssh-keygen.exe')) |
            Where-Object { Test-Path $_ } | Select-Object -First 1
      if($kg){
        & $kg -A 2>&1 | Out-Null
        Write-YcLog 'sshd host keys were missing - generated them (ssh-keygen -A).' 'WARN'
      }
    }

    # Sentinel: if sshd.exe cannot even be launched, LASTEXITCODE stays non-zero
    # so we fail SAFE (restore + stop) rather than restarting on an unchecked config.
    $global:LASTEXITCODE = 1
    $tOut = & $sshdExe -t -f $cfg 2>&1
    if($LASTEXITCODE -ne 0){
      Write-YcLog ('sshd_config FAILED validation: ' + (($tOut | Out-String).Trim())) 'ERROR'
      if($wrote -and (Test-Path $bak)){
        Copy-Item -Path $bak -Destination $cfg -Force -ErrorAction SilentlyContinue
        Write-YcLog 'sshd_config restored from backup.' 'WARN'
        try{ Restart-Service sshd -Force -ErrorAction Stop; Write-YcLog 'sshd restarted on the restored config.' 'WARN' }catch{}
      } else {
        Write-YcLog 'Config was NOT modified by this run - the existing sshd_config is already invalid. Not restarting sshd.' 'ERROR'
      }
      Stop-YcLog 1; exit 1
    }
    Write-YcLog 'sshd_config validated OK (sshd -t).' 'OK'

    try{
      Set-Service sshd -StartupType Automatic -ErrorAction Stop
      Restart-Service sshd -Force -ErrorAction Stop
    }catch{
      Write-YcLog ('sshd restart failed: ' + $_.Exception.Message) 'ERROR'
      Stop-YcLog 1; exit 1
    }

    $running = $false
    for($i = 0; $i -lt 15; $i++){
      Start-Sleep -Seconds 1
      $s = Get-Service sshd -ErrorAction SilentlyContinue
      if($s -and $s.Status -eq 'Running'){ $running = $true; break }
    }
    if(-not $running){
      Write-YcLog 'sshd is NOT Running after restart - remote access is down.' 'ERROR'
      Stop-YcLog 1; exit 1
    }
    Write-YcLog 'sshd restarted and confirmed Running (StartupType Automatic).' 'OK'
  }
}

# =============================================================
# B. Firewall
# =============================================================
if(-not $SkipFirewall){
  Write-YcLog 'B) firewall...'
  try{
    if(Test-Path 'C:\Scripts\Set-Firewall.ps1'){
      # 'exit N' inside a script invoked with & sets $LASTEXITCODE and throws NOTHING, so the
      # catch below can never fire on a refusal. Read the code immediately (any other command
      # would overwrite it) and route a non-zero into the COMPLETED WITH ERRORS path.
      $global:LASTEXITCODE = 0
      & 'C:\Scripts\Set-Firewall.ps1'
      $fwCode = $LASTEXITCODE
      if($null -eq $fwCode){ $fwCode = 0 }
      if($fwCode -ne 0){
        Write-YcLog ('Set-Firewall.ps1 exited ' + $fwCode + ' (2=refused unsafe/missing arguments, 3=one or more rules failed, 5=not elevated). The firewall policy was NOT fully applied - see C:\Scripts\set-firewall.log.') 'ERROR'
        $script:YcFailed = $true
      }else{
        Write-YcLog 'Set-Firewall.ps1 exited 0 (firewall policy applied).' 'OK'
      }
    }
    else{ Write-YcLog 'Set-Firewall.ps1 not present - skipped.' 'WARN' }
  }catch{ Write-YcLog ('firewall error: ' + $_.Exception.Message) 'WARN' }
}

# =============================================================
# C. Administrator password  (P0-12 + P0-14)
# =============================================================
Write-YcLog 'C) setting Administrator password...'
$pwGenerated = $false
if(-not $AdminPassword){ $pwGenerated = $true }

$adm = Get-YcAdminAccount
if(-not $adm){
  Write-YcLog 'Built-in Administrator account (RID 500) not found - password not set.' 'ERROR'
  $script:YcFailed = $true
} else {
  $admName = $adm.Name
  $pwOk    = $false
  $attempts = 1
  if($pwGenerated){ $attempts = 3 }   # a stricter local policy may reject a candidate

  for($try = 1; $try -le $attempts -and -not $pwOk; $try++){
    if($pwGenerated){ $AdminPassword = New-YcStrongPassword 20 }
    try{
      $sec = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
      Set-LocalUser -Name $admName -Password $sec -ErrorAction Stop
      Set-LocalUser -Name $admName -PasswordNeverExpires $true -ErrorAction Stop
      $pwOk = $true
    }catch{
      # The exception text never contains the password itself.
      Write-YcLog ('Set-LocalUser attempt ' + $try + ' failed: ' + $_.Exception.Message) 'WARN'
    }
  }

  if(-not $pwOk){
    Write-YcLog ('Could not set the ' + $admName + ' password (complexity/length policy?). The account password is UNCHANGED.') 'ERROR'
    $script:YcFailed = $true
  } else {
    # PROVE the password works before telling anyone it does. A disabled account
    # always fails ValidateCredentials, so only assert when it is enabled.
    $adm = Get-YcAdminAccount
    if($adm -and $adm.Enabled){
      $verified = $false
      try{
        Add-Type -AssemblyName System.DirectoryServices.AccountManagement -ErrorAction Stop
        $ctx = New-Object DirectoryServices.AccountManagement.PrincipalContext 'Machine'
        try{ $verified = $ctx.ValidateCredentials($admName, $AdminPassword) } finally { $ctx.Dispose() }
      }catch{
        Write-YcLog ('Password verification could not run: ' + $_.Exception.Message) 'WARN'
      }
      if($verified){
        Write-YcLog ($admName + ' password set and VERIFIED (PasswordNeverExpires=true).') 'OK'
      } else {
        Write-YcLog ($admName + ' password was accepted but FAILED verification - do not rely on it.') 'ERROR'
        $script:YcFailed = $true
        $pwOk = $false
      }
    } else {
      Write-YcLog ($admName + ' password set (PasswordNeverExpires=true). Account is DISABLED so the credential could not be verified.') 'WARN'
    }
  }
}

# =============================================================
# D. Yallacloud verify
# =============================================================
Write-YcLog 'D) verifying yallacloud...'
try{
  if(Test-Path 'C:\Scripts\Yallacloud.ps1'){
    $v = & 'C:\Scripts\Yallacloud.ps1' -Version 2>&1
    Write-YcLog ("yallacloud: " + ($v -join ' '))
  } else {
    Write-YcLog 'Yallacloud.ps1 not present - skipped.' 'WARN'
  }
}catch{ Write-YcLog ('yallacloud error: ' + $_.Exception.Message) 'WARN' }

# =============================================================
# E. Hostname
# =============================================================
if($Hostname){
  Write-YcLog ("E) setting hostname -> $Hostname")
  if($env:COMPUTERNAME -eq $Hostname){
    Write-YcLog 'Hostname already correct - no change (idempotent).'
  } else {
    try{
      Rename-Computer -NewName $Hostname -Force -ErrorAction Stop
      Write-YcLog 'Hostname staged - REBOOT required to finish the rename.' 'WARN'
    }catch{ Write-YcLog ('rename error: ' + $_.Exception.Message) 'WARN' }
  }
}

# =============================================================
# F. tasks
# =============================================================
Write-YcLog 'F) checking first-boot tasks...'
foreach($tn in 'PwSetOnce','InstallVMTools','FinalReboot'){
  try{
    if(-not (Get-ScheduledTask -TaskName $tn -ErrorAction SilentlyContinue)){
      Write-YcLog ("  $tn missing (already ran - ok on clones)")
    }
  }catch{}
}

# =============================================================
# Summary. The password is NEVER passed to Write-YcLog (event log + transcript)
# and the one Write-Host that shows it runs with the transcript stopped.
# =============================================================
if($script:YcFailed){
  Write-YcLog 'A-Z-Deploy COMPLETED WITH ERRORS - see above. VM is NOT ready.' 'ERROR'
  Write-Host ''
  Write-Host '  YALLACLOUD A-Z finished with ERRORS - review C:\Scripts\a-z-deploy.log' -ForegroundColor Red
  Stop-YcLog 1
  exit 1
}

Write-YcLog 'A-Z-Deploy COMPLETE.' 'OK'
Write-Host ''
Write-Host '  YALLACLOUD A-Z complete.' -ForegroundColor Cyan
if($pwGenerated -and $pwOk){
  # --- transcript OFF: this single line must not reach a-z-deploy.log ---
  try { Stop-Transcript | Out-Null } catch {}
  Write-Host ("  New Administrator password: " + $AdminPassword)
  try { Start-Transcript -Path $YcLogPath -Append | Out-Null } catch {}
  # --- transcript ON ---
  Write-Host '  Save this password NOW - it is shown once and is not in the log.' -ForegroundColor Yellow
} elseif($pwOk){
  Write-Host '  Administrator password set to the value supplied via -AdminPassword.' -ForegroundColor DarkGray
}
Write-Host '  Reboot if hostname was set.' -ForegroundColor DarkGray
Stop-YcLog 0
exit 0
