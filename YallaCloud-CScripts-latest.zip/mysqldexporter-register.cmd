@echo off
setlocal
rem ================================================================================================
rem mysqldexporter-register - install mysqld_exporter UNDER THE WinSW SERVICE WRAPPER and prove
rem                           mysql_up 1.  Wrapper for C:\Scripts\MysqldExporter-Register.ps1.
rem
rem WHAT CHANGED, AND WHY:
rem   - Added "exit /b %ERRORLEVEL%".
rem   - mysqld_exporter is a plain Go binary with NO Windows service dispatcher: registered directly
rem     with New-Service the SCM kills it after 30 seconds with error 1053. The old script did
rem     exactly that with -EA SilentlyContinue on both calls and then logged success, so this
rem     exporter never ran on any VM. It now runs under WinSW - stage C:\Scripts\WinSW-x64.exe.
rem   - The old examples put the DB password on this command line, where it is visible in the
rem     process table, in Windows event 4688 and in the transcript header. Use -MyPasswordFile, or
rem     set YC_MYSQLD_EXPORTER_PASSWORD before calling.
rem   - The inbound rule is scoped and is created only AFTER /metrics has been proven.
rem
rem PREFERRED:
rem   set YC_MYSQLD_EXPORTER_PASSWORD=...
rem   mysqldexporter-register -MyHost 10.0.0.6 -MyUser exporter -RemoteAddress 10.20.0.11
rem   mysqldexporter-register -MyHost localhost -MyUser exporter -MyPasswordFile C:\Scripts\.mysql.pw
rem   mysqldexporter-register -Help
rem
rem EXIT CODES: 0 verified | 1 failed | 2 usage | 5 not elevated | 6 no internet
rem Log: C:\Scripts\mysqldexporter-register.log
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\MysqldExporter-Register.ps1" %*
exit /b %ERRORLEVEL%
