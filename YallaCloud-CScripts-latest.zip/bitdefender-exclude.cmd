@echo off
rem bitdefender-exclude [<path> ...] [-OutFile <f>] [-Replace] [-Verify] [-AcceptPrivEscRisk] [-Help]
rem Prepares + verifies the GravityZone folder-exclusion list (console policy still applies them).
rem REFUSES to list a directory that non-administrators can write to unless -AcceptPrivEscRisk.
rem Logs to C:\Scripts\bitdefender-exclude.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Bitdefender-Exclude.ps1" %*
exit /b %ERRORLEVEL%
