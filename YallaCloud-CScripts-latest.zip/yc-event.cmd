@echo off
setlocal
rem ================================================================================================
rem yc-event - work out what this VM is, and tell the outside world about it.
rem            Wrapper for C:\Scripts\Yc-Event.ps1.
rem
rem WHY IT EXISTS: ntfy tells a human, it does not tell a system. This posts a structured event to
rem the YallaCloud webhook AND the ntfy line from one place, so the SQL template userdata, a day-2
rem script and a person at a console all report the same shape.
rem
rem   yc-event -Report                       what this VM knows about itself. Sends NOTHING.
rem   yc-event -Test                         post type=webhook.test and print the HTTP code
rem   yc-event -Type vm.deploy.started
rem   yc-event -Type vm.deploy.step      -Step "NET+ SYNC+"
rem   yc-event -Type vm.deploy.completed -Step "NET+ SYNC+ DOTNET+ SQL+ SQLLIC+ SSMS+ LIC+"
rem   yc-event -Type vm.deploy.failed    -FailedStep SQL -ErrorText "install-sql rc=1"
rem   yc-event -Type vm.error            -ErrorText "ssms returned 1603"
rem   yc-event -Drain                        retry everything that never got through
rem   yc-event -SelfCheck   |   yc-event -Help
rem
rem CONFIGURE ONCE - stored in C:\ProgramData\YallaCloud\yc-event.json, NOT C:\Scripts, because
rem the payload update wipes that folder and would take the queue and the facts with it:
rem   yc-event -SetUrl https://api.yallacloud.net/api/v1/webhooks/cloudstack
rem   yc-event -SetSecret <webhook secret>      X-Webhook-Secret
rem   yc-event -SetToken  <jwt>                 Authorization: Bearer   (use instead of a secret)
rem   yc-event -SetNtfy   https://ntfy.sh/9890122212
rem   Pass '-' as the value to clear one. Auth is whichever field is filled; both sends both.
rem
rem KNOWING WHO YOU ARE IS THE HARD PART. CloudStack tells a guest through two doors and neither
rem is open all the time: the VIRTUAL ROUTER metadata service (only while networked) and the
rem CONFIG DRIVE (present at first boot, then ejected - on a 3-day-old VM there is nothing left
rem but an empty D:). cloudbase-init keeps no log, so it cannot be asked afterwards.
rem So this ACCUMULATES identity instead of fetching it: every run merges whatever door is open
rem into vm-facts.json and NEVER overwrites a known value with a blank. Underneath both is the
rem SMBIOS UUID, which on CloudStack/KVM is exactly the CloudStack VM UUID - no network, no disc.
rem
rem DOMAIN AND ACCOUNT ARE NOT VISIBLE FROM INSIDE A GUEST. They live only in the CloudStack
rem database. This sends vmId; the receiver resolves them with listVirtualMachines id=<uuid>.
rem
rem WHEN DELIVERY FAILS: a webhook cannot report its own silence. A failed POST is retried, then
rem written to yc-event-queue.jsonl; every later run drains the queue first; and every payload
rem carries a "delivery" block saying how many are queued and what the last error was - so the
rem first message that gets through tells the backend exactly what it missed. If the webhook is
rem down the ntfy line still goes, tagged WEBHOOK-FAILED. If both are down it is written to disk
rem and to the Application event log, id 1602. Nothing here is ever fatal.
rem
rem EXIT CODES: 0 delivered or nothing to do | 1 queued, not delivered | 2 usage | 5 not elevated
rem
rem Logs to C:\Scripts\yc-event.log. Facts, config and queue in C:\ProgramData\YallaCloud\.
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Yc-Event.ps1" %*
exit /b %ERRORLEVEL%
