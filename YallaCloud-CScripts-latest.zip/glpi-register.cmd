@echo off
rem glpi-register -Server <https://glpi.example.com/front/inventory.php>
rem               [-ServerFile <file>] [-Tag <customer-id>] [-CaCertFile <pem>]
rem               [-MsiPath <msi>] [-VerifySec 180] [-Force] [-Help]
rem
rem The msiexec exit code is now captured and decoded, the agent service is discovered and must
rem reach Running, and HKLM\SOFTWARE\GLPI-Agent is READ BACK and its 'server' value compared
rem with the URL that was requested. The GLPI host must also be reachable. The old version
rem printed "GLPI Agent msiexec exit: 0" and exited with it, having verified nothing.
rem
rem A GLPI URL can embed HTTP basic credentials; use -ServerFile or
rem   set YC_GLPI_SERVER=...
rem so it never reaches a command line. -Tag maps the asset to a GLPI entity for per-tenant
rem billing (also readable from YC_GLPI_TAG).
rem Outbound only; no inbound port is opened. Logs to C:\Scripts\glpi-register.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\GLPI-Register.ps1" %*
exit /b %ERRORLEVEL%
