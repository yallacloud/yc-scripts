@echo off
setlocal
rem ================================================================================================
rem fix-gateway - move a PRIVATE default gateway off the CloudStack .254 bug onto .1.
rem               Wrapper for C:\Scripts\Yc-FixGateway.ps1.
rem
rem   fix-gateway -Report      what it WOULD do. Changes nothing. Safe on production.
rem   fix-gateway              detect and rectify
rem   fix-gateway -Force       also reset the adapter afterwards (drops connections briefly)
rem   fix-gateway -SelfCheck   assertions only, no admin, changes nothing
rem   fix-gateway -Help
rem
rem IT REFUSES MORE THAN IT ACTS, on purpose - a wrong default route on a remote VM is
rem unrecoverable without console access:
rem   1. PRIVATE IPv4 ONLY (10/8, 172.16-31/12, 192.168/16). A public address is NEVER touched.
rem   2. Only a gateway whose last octet is EXACTLY 254.
rem   3. The candidate .1 must ANSWER a ping first - it is on the same subnet, so that test needs
rem      no working gateway. No answer, no change.
rem   4. Automatic rollback: if off-subnet reachability is worse after the swap, the original
rem      route is restored and the run reports failure.
rem
rem IT DOES NOT BOUNCE THE NIC. A route change is immediate; Restart-NetAdapter would drop every
rem connection on the box including the session running it. -Force does that only if you ask.
rem
rem DHCP CAVEAT: a lease renewal re-applies the bad gateway. This is idempotent and cheap, which is
rem why the userdata runs it at boot. THE PERMANENT FIX IS IN CLOUDSTACK - this is a workaround.
rem
rem EXIT CODES: 0 nothing needed or fixed and verified | 1 a fix failed and was rolled back |
rem             2 usage | 5 not elevated
rem
rem Logs to C:\Scripts\yc-fixgateway.log.
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Yc-FixGateway.ps1" %*
exit /b %ERRORLEVEL%
