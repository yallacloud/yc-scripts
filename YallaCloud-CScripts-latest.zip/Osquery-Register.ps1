param(
  # ---- names preserved from osquery-register.cmd and the catalog ----
  [string]$FleetUrl,                                 # Fleet server host[:port]
  [string]$EnrollSecret,                             # Fleet enroll secret (see -EnrollSecretPath)
  # ---- ADDED in this revision ----
  [string]$EnrollSecretPath,                         # read the secret from a FILE instead of the command line
  [string]$MsiPath,                                  # explicit osquery MSI
  [string]$MsiUrl,                                   # download the MSI if none is staged
  [string]$Sha256,                                   # expected SHA256 of the downloaded MSI
  [string]$TlsServerCerts,                           # PEM bundle for the Fleet CA (omitted if absent)
  [string]$FleetApiToken,                            # optional: prove enrolment against the Fleet API
  [int]$VerifySec = 180,                             # how long to wait for enrolment evidence
  [switch]$Force,                                    # re-run the MSI even if osquery is installed
  [switch]$Help
)
# =====================================================================================
# Osquery-Register.ps1 - SILENT install + Fleet enrolment of osquery. OUTBOUND ONLY.
# PowerShell 5.1, ASCII only. Runs unattended (cloud-init / SYSTEM / RMM).
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P0-24] THE SCRIPT REPORTED ENROLMENT UNCONDITIONALLY.
#   Old line 30: Start-Process msiexec.exe -ArgumentList @('/i',...,'/quiet') -Wait
#   with NO -PassThru. There was no process object, therefore no exit code, therefore
#   nothing to check even in principle. Old line 55 was Restart-Service -EA SilentlyContinue
#   (a no-op if the service does not exist), and old lines 56-57 printed
#   "osquery enrolled (service osqueryd, outbound to Fleet)" and exited 0 with NO condition
#   attached whatsoever. The MSI could have failed, osqueryd could be absent, the Fleet URL
#   could be garbage and the deployment still recorded SUCCESS.
#   NOW: Invoke-YcInstaller captures and decodes the msiexec exit code with a timeout;
#   osqueryd must EXIST and reach Running; the flags file is READ BACK from disk; the Fleet
#   endpoint must be reachable; the osquery log is scanned for enrolment failures; and with
#   -FleetApiToken the host is looked up in the Fleet API - real, server-side proof.
#
# [P0-24b] THE ENROLL SECRET WAS WORLD-READABLE.
#   Old line 53 wrote C:\Program Files\osquery\enroll.secret with the directory's inherited
#   ACL, which grants BUILTIN\Users read. Any local user could read the secret and enroll a
#   rogue host into your Fleet - a fleet-wide credential handed to every account on the box.
#   NOW: the file is written, then
#     icacls "<dir>\enroll.secret" /inheritance:r /grant *S-1-5-18:F *S-1-5-32-544:F
#   and the resulting ACL is READ BACK and asserted: inheritance off, no identity other than
#   SYSTEM / Administrators / CREATOR OWNER / TrustedInstaller. If the ACL cannot be proven,
#   the secret file is DELETED and the script fails - it does not leave a readable secret.
#   -EnrollSecretPath and the YC_OSQUERY_ENROLL_SECRET environment variable exist so the
#   secret never has to appear on a command line (process table, 4688 events, transcripts).
#
# OTHER DEFECTS FIXED HERE
#   - --tls_server_certs was hard-coded to <dir>\certs\certs.pem whether or not that file
#     exists. A non-existent CA bundle makes every TLS request fail. It is now emitted ONLY
#     when the file is really there (or -TlsServerCerts is given), otherwise osquery uses
#     the Windows certificate store.
#   - The flags file is written with a trailing newline and read back and compared.
#   - The MSI is located like every other repaired script: -MsiPath, then the highest
#     staged C:\Scripts\osquery-*.msi, then -MsiUrl with SHA256 verification.
#   - No firewall rule is created. osquery is outbound-only: nothing should listen.
#
# VENDOR VERIFICATION - every flag and path below is documented:
#   Windows package layout, service name osqueryd, C:\Program Files\osquery,
#   osquery.flags, manage-osqueryd.ps1, and the ACL expectation that no non-privileged
#   account has write access:
#     https://osquery.readthedocs.io/en/stable/installation/install-windows/
#   TLS remote flags (--enroll_secret_path, --enroll_tls_endpoint, --tls_hostname,
#   --tls_server_certs, --config_plugin, --config_tls_endpoint, --logger_plugin,
#   --logger_tls_endpoint, --distributed_plugin, --disable_enrollment) and the node_key
#   enrolment exchange:
#     https://osquery.readthedocs.io/en/stable/deployment/remote/
#   Fleet REST API, Bearer token, GET /api/v1/fleet/hosts:
#     https://fleetdm.com/docs/rest-api/rest-api
#   Windows Installer standard options /i /qn /l*v REBOOT=ReallySuppress:
#     https://learn.microsoft.com/en-us/windows/win32/msi/standard-installer-command-line-options
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was installed. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'osquery-register'

$dir = 'C:\Program Files\osquery'

$Usage = @'
osquery-register  -  SILENT install + Fleet enrolment of osquery (OUTBOUND ONLY, TLS 443 to Fleet).
                     Staged installer: C:\Scripts\osquery-*.msi   Log: C:\Scripts\osquery-register.log

USAGE:
  osquery-register -FleetUrl <fleet.example.com:443> -EnrollSecret <secret>
  osquery-register -FleetUrl <fleet.example.com:443> -EnrollSecretPath C:\Scripts\fleet.secret
  osquery-register -FleetUrl <host:port> -EnrollSecretPath <file> [-MsiPath <msi> | -MsiUrl <url> [-Sha256 <h>]]
                   [-TlsServerCerts <pem>] [-FleetApiToken <token>] [-VerifySec 180] [-Force]
  osquery-register -Help

PARAMETERS:
  -FleetUrl          Fleet server host[:port] for TLS enrolment (required).
  -EnrollSecret      Fleet enroll secret. Get it from Fleet > Settings > Agent options.
                     PREFER -EnrollSecretPath or the YC_OSQUERY_ENROLL_SECRET environment
                     variable: a secret on the command line is visible in the process table
                     and in 4688 audit events for as long as the process lives.
  -EnrollSecretPath  File containing the enroll secret. Read, then locked to SYSTEM + Admins.
  -MsiPath           Explicit MSI. Default: the highest-version C:\Scripts\osquery-*.msi.
  -MsiUrl            Download the MSI when none is staged (requires egress). Pair with -Sha256.
  -Sha256            Expected SHA256 of the downloaded MSI.
  -TlsServerCerts    PEM bundle for the Fleet CA. Emitted ONLY if the file exists; otherwise
                     osquery validates against the Windows certificate store. The old script
                     always pointed at <install>\certs\certs.pem even when it did not exist,
                     which makes every TLS call fail.
  -FleetApiToken     Fleet API token. If supplied, this command proves enrolment for real by
                     looking this host up through GET /api/v1/fleet/hosts. Without it,
                     enrolment is proven only as far as the agent side can prove it.
  -VerifySec         How long to wait for enrolment evidence (default 180).
  -Force             Re-run the MSI even if osquery is already installed.
  -Help              Show this help and exit.

PROOF OF SUCCESS (nothing below is assumed):
  msiexec exit code captured and decoded (the old script could not see it at all)
  + osqueryd.exe present + the osqueryd service Running
  + osquery.flags read back from disk and confirmed to point at THIS Fleet server
  + enroll.secret ACL read back and confirmed to exclude every non-admin identity
  + TCP reachability to the Fleet host:port
  + the osquery log scanned for enrolment failures
  + with -FleetApiToken, the host found in the Fleet API.
  If enrolment cannot be proven the command FAILS. It never prints "osquery enrolled" on hope.

SECURITY:
  Outbound 443 only. No inbound port is opened and no firewall rule is created.
  The enroll secret is a FLEET-WIDE credential: anyone who can read it can enroll a rogue
  host. It is stored at C:\Program Files\osquery\enroll.secret, locked to SYSTEM and
  Administrators, and the lock is verified.

EXAMPLES:
  osquery-register -FleetUrl fleet.example.com:443 -EnrollSecretPath C:\Scripts\fleet.secret
  $env:YC_OSQUERY_ENROLL_SECRET='...'; osquery-register -FleetUrl fleet.example.com:443
  osquery-register -FleetUrl fleet.example.com:443 -EnrollSecretPath C:\Scripts\fleet.secret -FleetApiToken <token>
  osquery-register -Help

EXIT CODES:
  0   osquery installed, osqueryd Running, configuration verified, enrolment proven
  1   generic failure
  2   usage error (no -FleetUrl / no enroll secret)
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4   osquery MSI missing / too small / not a valid package
  5   not running as Administrator
  6   -MsiUrl was needed but there is no outbound internet
  7   the osqueryd service does not exist or is not Running
  8   enrolment could not be proven (unreachable Fleet, or Fleet rejected this host)
  9   the MSI download failed
  10  msiexec did not exit within its timeout and was killed
  13  the enroll.secret ACL could not be proven - the secret file was DELETED
  14  osquery.flags does not read back the requested configuration
  <n> any other value is msiexec's own exit code

Log: C:\Scripts\osquery-register.log   MSI log: C:\Scripts\osquery-msi.log
     (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

# ------------------------------------------------------------------------------------
# Resolve the secret without ever printing it.
# ------------------------------------------------------------------------------------
$secret = ''
if($EnrollSecretPath){
  if(-not (Test-Path -LiteralPath $EnrollSecretPath)){
    Write-Host $Usage -ForegroundColor Cyan
    Exit-Yc 2 ('-EnrollSecretPath not found: ' + $EnrollSecretPath + '. Nothing was installed.') 'ERROR'
  }
  try{ $secret = (('' + (Get-Content -LiteralPath $EnrollSecretPath -Raw -ErrorAction Stop))).Trim() }
  catch{ Exit-Yc 2 ('could not read -EnrollSecretPath: ' + $_.Exception.Message) 'ERROR' }
}elseif($EnrollSecret){
  $secret = $EnrollSecret.Trim()
}elseif($env:YC_OSQUERY_ENROLL_SECRET){
  $secret = ([string]$env:YC_OSQUERY_ENROLL_SECRET).Trim()
  Write-YcLog 'enroll secret taken from the YC_OSQUERY_ENROLL_SECRET environment variable (it is not on the command line - good)'
}

if(-not $FleetUrl -or -not $secret){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 'a Fleet URL and an enroll secret are required. Pass -FleetUrl, and one of -EnrollSecretPath, -EnrollSecret, or the YC_OSQUERY_ENROLL_SECRET environment variable. Nothing was installed.' 'ERROR'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

# Split host:port. osquery's --tls_hostname takes host[:port], no scheme, no path.
$hostPort = ($FleetUrl -replace '^https?://','') -replace '/.*$',''
$fleetHost = $hostPort
$fleetPort = 443
if($hostPort -match '^(.+):(\d+)$'){ $fleetHost = $Matches[1]; $fleetPort = [int]$Matches[2] }
if(-not $fleetHost){ Exit-Yc 2 ('-FleetUrl does not contain a host: ' + $FleetUrl) 'ERROR' }
Write-YcLog ('Fleet target: ' + $fleetHost + ':' + $fleetPort + ' (tls_hostname=' + $hostPort + ')')

# ------------------------------------------------------------------------------------
# 1. Locate the MSI and install it - with an exit code this time.
# ------------------------------------------------------------------------------------
$MsiLog  = 'C:\Scripts\osquery-msi.log'
$daemon  = Join-Path $dir 'osqueryd\osqueryd.exe'
$already = Test-Path -LiteralPath $daemon

if($already -and -not $Force){
  Write-YcLog ('osqueryd.exe is already present at ' + $daemon + ' - skipping the MSI (use -Force to reinstall) and reconciling the configuration instead')
}else{
  $msi = ''
  if($MsiPath){
    $msi = $MsiPath
  }else{
    $cands = @(Get-ChildItem -Path 'C:\Scripts\osquery-*.msi' -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer })
    if($cands.Count -gt 0){
      $ranked = @()
      foreach($f in $cands){
        $v = [version]'0.0'
        if($f.Name -match 'osquery-(\d+(?:\.\d+){1,3})'){ try{ $v = [version]$Matches[1] }catch{ $v = [version]'0.0' } }
        $ranked += (New-Object psobject -Property @{ File = $f; Ver = $v })
      }
      $ranked = @($ranked | Sort-Object -Property Ver -Descending)
      if($ranked.Count -gt 1){ Write-YcLog ('several staged osquery MSIs found - using the highest version: ' + $ranked[0].File.Name) 'WARN' }
      $msi = $ranked[0].File.FullName
    }elseif($MsiUrl){
      Assert-YcPrereqs -NeedInternet
      $dest = Join-Path 'C:\Scripts' (Split-Path -Leaf ($MsiUrl -split '\?')[0])
      if($dest -notlike '*.msi'){ $dest = 'C:\Scripts\osquery.msi' }
      $got = Get-YcFile -Uri $MsiUrl -OutFile $dest -Sha256 $Sha256 -MinBytes 1MB -Retries 4
      if(-not $got){ Exit-Yc 9 ('could not download the osquery MSI from ' + $MsiUrl) 'ERROR' }
      $msi = $got
    }else{
      Exit-Yc 4 'osquery MSI not found (C:\Scripts\osquery-*.msi). Stage it, or pass -MsiPath / -MsiUrl. Nothing was installed.' 'ERROR'
    }
  }
  if(-not (Assert-YcFile -Path $msi -MinBytes 1MB -Because 'osquery MSI')){
    Exit-Yc 4 ('unusable osquery MSI: ' + $msi) 'ERROR'
  }
  $sig = 'Unavailable'
  try{ $sig = [string](Get-AuthenticodeSignature -LiteralPath $msi -ErrorAction Stop).Status }catch{ $sig = 'Unavailable' }
  if($sig -eq 'Valid'){ Write-YcLog ('MSI Authenticode signature: Valid (' + (Split-Path -Leaf $msi) + ')') 'OK' }
  else{ Write-YcLog ('MSI Authenticode signature is ' + $sig + ' for ' + $msi + ' - continuing, but this package is not proven to be the vendor build') 'WARN' }

  $a = @('/i', ('"' + $msi + '"'), '/qn', 'REBOOT=ReallySuppress', '/l*v', ('"' + $MsiLog + '"'))
  $inst = Invoke-YcInstaller -FilePath 'msiexec.exe' -ArgumentList $a -SuccessCodes @(0) -RebootCodes @(3010,1641) -TimeoutSec 1800
  if($inst.TimedOut){ Exit-Yc 10 ('msiexec did not finish in time - see ' + $MsiLog) 'ERROR' }
  if($inst.ExitCode -eq 1638){
    Write-YcLog 'msiexec returned 1638 (another version of this product is already installed) - continuing to configure the EXISTING installation' 'WARN'
  }elseif(-not $inst.Success){
    $code = $inst.ExitCode
    if($code -eq 0){ $code = 1 }
    Exit-Yc $code ('the osquery MSI FAILED: ' + $inst.Meaning + '. See ' + $MsiLog + '. Nothing is enrolled.') 'ERROR'
  }
}

if(-not (Test-Path -LiteralPath $daemon)){
  Exit-Yc 7 ('the installer reported success but ' + $daemon + ' does not exist. osquery is NOT installed. See ' + $MsiLog + '.') 'ERROR'
}

# ------------------------------------------------------------------------------------
# 2. The enroll secret: write it, LOCK it, and PROVE the lock.
# ------------------------------------------------------------------------------------
$secretFile = Join-Path $dir 'enroll.secret'
try{
  if(-not (Test-Path -LiteralPath $dir)){ New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null }
  [IO.File]::WriteAllText($secretFile,$secret,(New-Object System.Text.ASCIIEncoding))
}catch{
  Exit-Yc 1 ('could not write ' + $secretFile + ': ' + $_.Exception.Message) 'ERROR'
}

$aclOk = $false
try{
  & icacls $secretFile /inheritance:r /grant '*S-1-5-18:F' '*S-1-5-32-544:F' 2>&1 | Out-Null
  if($LASTEXITCODE -eq 0){ $aclOk = $true }
  if(-not $aclOk){
    & icacls $secretFile /inheritance:r /grant 'NT AUTHORITY\SYSTEM:(F)' 'BUILTIN\Administrators:(F)' 2>&1 | Out-Null
    if($LASTEXITCODE -eq 0){ $aclOk = $true }
  }
}catch{ $aclOk = $false }

# READ THE ACL BACK. An icacls exit code is not proof that the ACL is what we want.
$allowedSids = @('S-1-5-18','S-1-5-32-544','S-1-3-0','S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464')
$aclProven = $false
$offenders = @()
try{
  $acl = Get-Acl -LiteralPath $secretFile -ErrorAction Stop
  if(-not $acl.AreAccessRulesProtected){ $offenders += 'inheritance is still ENABLED' }
  foreach($ace in $acl.Access){
    $sid = ''
    try{ $sid = $ace.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value }
    catch{ $sid = [string]$ace.IdentityReference }
    if($allowedSids -notcontains $sid){ $offenders += ([string]$ace.IdentityReference + ' (' + $sid + ')') }
  }
  if($offenders.Count -eq 0){ $aclProven = $true }
}catch{
  $offenders += ('the ACL could not be read back: ' + $_.Exception.Message)
}

if(-not $aclProven){
  try{ Remove-Item -LiteralPath $secretFile -Force -ErrorAction SilentlyContinue }catch{}
  Exit-Yc 13 ('the enroll.secret ACL could NOT be proven (icacls ok=' + $aclOk + '; still permitted: ' + ($offenders -join ', ') + '). The secret file has been DELETED rather than left readable - the Fleet enroll secret lets anyone who reads it enroll a rogue host. Fix the permissions on ' + $dir + ' and re-run.') 'ERROR'
}
Write-YcLog ('enroll.secret written and locked: inheritance broken, SYSTEM + Administrators only, verified by reading the ACL back (value ' + (Protect-YcSecret $secret -Whole -Keep 0) + ')') 'OK'

# ------------------------------------------------------------------------------------
# 3. osquery.flags - and only reference a CA bundle that exists.
# ------------------------------------------------------------------------------------
$certFile = ''
if($TlsServerCerts){
  if(Test-Path -LiteralPath $TlsServerCerts){ $certFile = $TlsServerCerts }
  else{ Exit-Yc 2 ('-TlsServerCerts not found: ' + $TlsServerCerts) 'ERROR' }
}else{
  $default = Join-Path $dir 'certs\certs.pem'
  if(Test-Path -LiteralPath $default){ $certFile = $default }
  else{ Write-YcLog ('no CA bundle at ' + $default + ' - omitting --tls_server_certs so osquery uses the Windows certificate store. The old script emitted this flag unconditionally, which breaks every TLS call when the file is absent.') 'WARN' }
}

$flagList = New-Object System.Collections.Generic.List[string]
$flagList.Add('--tls_hostname=' + $hostPort)
if($certFile){ $flagList.Add('--tls_server_certs=' + $certFile) }
$flagList.Add('--host_identifier=uuid')
$flagList.Add('--enroll_secret_path=' + $secretFile)
$flagList.Add('--enroll_tls_endpoint=/api/osquery/enroll')
$flagList.Add('--config_plugin=tls')
$flagList.Add('--config_tls_endpoint=/api/osquery/config')
$flagList.Add('--config_refresh=60')
$flagList.Add('--disable_distributed=false')
$flagList.Add('--distributed_plugin=tls')
$flagList.Add('--distributed_interval=60')
$flagList.Add('--distributed_tls_max_attempts=3')
$flagList.Add('--distributed_tls_read_endpoint=/api/osquery/distributed/read')
$flagList.Add('--distributed_tls_write_endpoint=/api/osquery/distributed/write')
$flagList.Add('--logger_plugin=tls')
$flagList.Add('--logger_tls_endpoint=/api/osquery/log')
$flagList.Add('--logger_tls_period=60')
$flags = ($flagList.ToArray() -join "`r`n") + "`r`n"

$flagsFile = Join-Path $dir 'osquery.flags'
try{ [IO.File]::WriteAllText($flagsFile,$flags,(New-Object System.Text.ASCIIEncoding)) }
catch{ Exit-Yc 14 ('could not write ' + $flagsFile + ': ' + $_.Exception.Message) 'ERROR' }

# Read it back from disk. This is proof the configuration is applied, not assumed.
$readback = @()
try{ $readback = @(Get-Content -LiteralPath $flagsFile -ErrorAction Stop) }
catch{ Exit-Yc 14 ('could not re-read ' + $flagsFile + ': ' + $_.Exception.Message) 'ERROR' }
$missing = @()
foreach($f in $flagList){ if($readback -notcontains $f){ $missing += $f } }
if($missing.Count -gt 0){
  Exit-Yc 14 ('osquery.flags does not read back the requested configuration; missing: ' + ($missing -join ', ')) 'ERROR'
}
Write-YcLog ('osquery.flags verified on disk: ' + $flagList.Count + ' flags, pointing at ' + $hostPort) 'OK'

# ------------------------------------------------------------------------------------
# 4. The service must exist and run. -EA SilentlyContinue on Restart-Service was how the
#    old script "restarted" a service that was not there.
# ------------------------------------------------------------------------------------
if(-not (Get-Service -Name 'osqueryd' -ErrorAction SilentlyContinue)){
  Exit-Yc 7 ('the osqueryd service does NOT exist even though the MSI reported success. Nothing is enrolled. See ' + $MsiLog + '.') 'ERROR'
}
try{ Set-Service -Name 'osqueryd' -StartupType Automatic -ErrorAction Stop }
catch{ Write-YcLog ('could not set osqueryd to Automatic start: ' + $_.Exception.Message) 'WARN' }
try{ Restart-Service -Name 'osqueryd' -Force -ErrorAction Stop; Write-YcLog 'osqueryd restarted to pick up the new flags' }
catch{ Write-YcLog ('could not restart osqueryd: ' + $_.Exception.Message) 'WARN' }
if(-not (Assert-YcService -Name 'osqueryd' -TimeoutSec 120 -StartIfStopped -Because 'the agent must be running to enroll and report')){
  Exit-Yc 7 'the osqueryd service is not Running - osquery is installed but not working, and NOT enrolled.' 'ERROR'
}

# ------------------------------------------------------------------------------------
# 5. PROVE ENROLMENT.
# ------------------------------------------------------------------------------------
Set-YcTls
$reachable = $false
try{ $reachable = [bool](Test-NetConnection -ComputerName $fleetHost -Port $fleetPort -WarningAction SilentlyContinue -InformationLevel Quiet) }catch{ $reachable = $false }
if($reachable){ Write-YcLog ('Fleet endpoint ' + $fleetHost + ':' + $fleetPort + ' is reachable from this host') 'OK' }
else{
  Exit-Yc 8 ('Fleet endpoint ' + $fleetHost + ':' + $fleetPort + ' is NOT reachable from this host. osqueryd is running but it cannot enroll, so this host is NOT in Fleet. Check egress/proxy/DNS and re-run.') 'ERROR'
}

# Agent-side evidence: scan the osquery log for the enrolment exchange.
$logDirs = @((Join-Path $dir 'log'), (Join-Path $env:ProgramData 'osquery\log'))
$badLog  = @()
$goodLog = $false
$deadline = (Get-Date).AddSeconds($VerifySec)
while((Get-Date) -lt $deadline){
  foreach($ld in $logDirs){
    if(-not (Test-Path -LiteralPath $ld)){ continue }
    $files = @(Get-ChildItem -Path (Join-Path $ld '*') -Include 'osqueryd.INFO*','osqueryd.WARNING*','osqueryd.ERROR*','osqueryd.results.log' -ErrorAction SilentlyContinue)
    foreach($lf in $files){
      $tail = @()
      try{ $tail = @(Get-Content -LiteralPath $lf.FullName -Tail 200 -ErrorAction SilentlyContinue) }catch{}
      foreach($ln in $tail){
        if($ln -match '(?i)enroll(ment)? failed|failed enrollment|enrollment key|invalid enroll secret|node key|Error connecting|certificate'){
          if($ln -match '(?i)fail|invalid|error'){ if($badLog -notcontains $ln){ $badLog += $ln } }
          else{ $goodLog = $true }
        }
      }
    }
  }
  if($goodLog -or $badLog.Count -gt 0){ break }
  Start-Sleep -Seconds 5
}
foreach($b in $badLog){ Write-YcLog ('  osquery log: ' + $b.Trim()) 'WARN' }
if($goodLog){ Write-YcLog 'the osquery log shows a node key / enrolment exchange with Fleet' 'OK' }

# Server-side evidence: ask Fleet whether it has this host. This is the only real proof.
$proven = $false
if($FleetApiToken){
  $me = $env:COMPUTERNAME
  $api = 'https://' + $hostPort + '/api/v1/fleet/hosts?query=' + [uri]::EscapeDataString($me)
  $hdr = @{ 'Authorization' = ('Bearer ' + $FleetApiToken) }
  $deadline2 = (Get-Date).AddSeconds($VerifySec)
  $lastErr = ''
  while((Get-Date) -lt $deadline2){
    try{
      $resp = Invoke-RestMethod -Uri $api -Headers $hdr -Method Get -TimeoutSec 30 -ErrorAction Stop
      $hosts = @()
      if($resp -and $resp.hosts){ $hosts = @($resp.hosts) }
      foreach($h in $hosts){
        $hn = ''
        try{ $hn = [string]$h.hostname }catch{}
        $cn = ''
        try{ $cn = [string]$h.computer_name }catch{}
        if(($hn -and $hn -like ($me + '*')) -or ($cn -and $cn -like ($me + '*'))){
          $proven = $true
          Write-YcLog ('Fleet API confirms this host is enrolled: hostname="' + $hn + '" computer_name="' + $cn + '"') 'OK'
          break
        }
      }
    }catch{
      $lastErr = $_.Exception.Message
    }
    if($proven){ break }
    Start-Sleep -Seconds 10
  }
  if(-not $proven){
    Exit-Yc 8 ('the Fleet API does NOT list this host (' + $env:COMPUTERNAME + ') after ' + $VerifySec + 's. osqueryd is running and configured, but enrolment was REJECTED or has not completed. Last API error: ' + $(if($lastErr){$lastErr}else{'none - the host was simply absent'}) + '. Check the enroll secret and the Fleet agent options.') 'ERROR'
  }
}else{
  Write-YcLog 'no Fleet API token was supplied, so enrolment is proven only as far as the agent side allows: the service is Running, the flags read back and point at this Fleet server, the enroll secret is present and locked, and the Fleet endpoint is reachable. Re-run with -FleetApiToken, to prove server-side registration.' 'WARN'
}

if($badLog.Count -gt 0 -and -not $proven){
  Exit-Yc 8 ('the osquery log reports an enrolment problem: ' + ($badLog[0].Trim()) + '. This host is NOT enrolled.') 'ERROR'
}

Exit-Yc 0 ('osquery installed, osqueryd Running, flags verified against ' + $hostPort + ', enroll.secret locked to SYSTEM + Administrators' + $(if($proven){', and enrolment CONFIRMED by the Fleet API'}else{' (server-side enrolment not verified - no -FleetApiToken)'}) + '. Outbound only: no port was opened.') 'OK'
