<#
    _yc-licensing.ps1 - shared licensing data and helpers for the YallaCloud
    C:\Scripts set. Sits beside _yc-lib.ps1 and follows the same conventions.

    Dot-source this file; do not run it directly:
        . (Join-Path $PSScriptRoot '_yc-licensing.ps1')

    Used by: convert-edition, licence-report. The key tables, the activation
    error table and the SQL edition-upgrade matrix here are the corrected ones -
    see "Windows and SQL Server Licensing Toolkit v1.0" for the sources and for
    the three assumptions the research overturned.

    Scope   : Windows PowerShell 5.1 and later. ASCII only.
    Licence : Microsoft-documented, licensed activation paths ONLY -
              KMS (your own KMS host), MAK, ADBA (Active Directory-Based
              Activation), and Microsoft-published
              GVLK client setup keys. No bypass technique of any kind is used,
              referenced or supported by this toolkit.

    Every key table below is transcribed from Microsoft Learn. Source URLs are on
    the table definitions. SQL Server product keys are NEVER embedded - they come
    from VLSC or your CSP and are supplied by the operator at run time.
#>

Set-StrictMode -Version 2.0

$script:YcLicVersion = '1.0.0'

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

$script:YcLogPath = $null

function Initialize-YcLog {
    <#
      .SYNOPSIS
        Open the house log for a command: C:\Scripts\<command>.log, appended.
      .DESCRIPTION
        Matches _yc-lib.ps1 rather than inventing a second convention. There is
        no C:\Scripts\logs directory on any YallaCloud VM and there should not
        be one - every house command appends to a single named log so an L1 can
        find it without hunting through timestamps.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string] $Name,
        [string] $Directory = 'C:\Scripts'
    )
    try {
        if (-not (Test-Path -LiteralPath $Directory)) {
            New-Item -ItemType Directory -Path $Directory -Force -ErrorAction Stop -WhatIf:$false | Out-Null
        }
        $script:YcLogPath = Join-Path $Directory ($Name + '.log')
        if (-not (Test-Path -LiteralPath $script:YcLogPath)) {
            Set-Content -LiteralPath $script:YcLogPath -Value '' -Encoding ASCII -ErrorAction Stop -WhatIf:$false
        }
        Add-Content -LiteralPath $script:YcLogPath -Encoding ASCII -ErrorAction Stop -WhatIf:$false -Value (
            '=== ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Name + ' start (user ' +
            [Security.Principal.WindowsIdentity]::GetCurrent().Name + ') ===')
    } catch {
        # A read-only or missing C:\Scripts must never stop the actual work.
        $script:YcLogPath = $null
        Write-Warning ('Could not open ' + $Directory + '\' + $Name + '.log: ' + $_.Exception.Message)
    }
    return $script:YcLogPath
}

function Write-YcLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, Position = 0)][AllowEmptyString()][string] $Message,
        # Position 1 is load-bearing: every caller writes  Write-YcLog 'msg' 'WARN'.
        # Without it PowerShell binds nothing positionally past $Message and every
        # such call dies with "A positional parameter cannot be found".
        [Parameter(Position = 1)][ValidateSet('INFO', 'WARN', 'FAIL', 'OK', 'STEP')][string] $Level = 'INFO'
    )
    $tag = 'yc'
    if ($script:YcLogPath) { $tag = [System.IO.Path]::GetFileNameWithoutExtension($script:YcLogPath) }
    $line = '{0}  [YALLACLOUD][{1}] [{2}] {3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $tag, $Level, $Message
    switch ($Level) {
        'FAIL' { Write-Host $line -ForegroundColor Red }
        'WARN' { Write-Host $line -ForegroundColor Yellow }
        'OK'   { Write-Host $line -ForegroundColor Green }
        'STEP' { Write-Host $line -ForegroundColor Cyan }
        default { Write-Host $line }
    }
    if ($script:YcLogPath) {
        try { Add-Content -LiteralPath $script:YcLogPath -Value $line -Encoding ASCII -ErrorAction Stop -WhatIf:$false } catch { }
    }
}

# ---------------------------------------------------------------------------
# Secret masking
# ---------------------------------------------------------------------------

function Get-YcMaskedKey {
    <#
      .SYNOPSIS
        Renders a 5x5 product key as XXXXX-XXXXX-XXXXX-XXXXX-<last5>.
      .DESCRIPTION
        Every product key this toolkit touches - MAK, retail, or a SQL
        Server PID - passes through here before it reaches a console, a log, or
        a report. Only the final five characters survive, which is the same
        amount Windows itself publishes as PartialProductKey.
        A GVLK is public by Microsoft's own statement and is shown in full when
        -AllowGvlk is set; nothing else ever is.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [AllowNull()][AllowEmptyString()][string] $Key,
        [switch] $AllowGvlk
    )
    if ([string]::IsNullOrWhiteSpace($Key)) { return '(none)' }
    $k = $Key.Trim().ToUpperInvariant()
    if ($AllowGvlk -and (Test-YcIsPublishedGvlk -Key $k)) { return $k }
    if ($k -match '^[A-Z0-9]{5}(-[A-Z0-9]{5}){4}$') {
        return ('XXXXX-XXXXX-XXXXX-XXXXX-' + $k.Substring($k.Length - 5, 5))
    }
    return '(masked)'
}

function Get-YcMaskedCommandLine {
    <#
      .SYNOPSIS
        Masks every secret-bearing argument in a setup.exe style command line.
      .DESCRIPTION
        Used for the "here is the command I am about to run" line. /PID, /SAPWD
        and every *SVCPASSWORD are replaced before the line is printed or logged.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param([Parameter(Mandatory = $true)][AllowEmptyCollection()][string[]] $Arguments)

    $secret = '(/PID|/SAPWD|/[A-Z]*SVCPASSWORD|/ProductKey|/PASSWORD)'
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($a in $Arguments) {
        if ($a -match ('^(?i)' + $secret + '[:=]')) {
            $sep = $a.Substring($Matches[1].Length, 1)
            $val = $a.Substring($Matches[1].Length + 1).Trim('"')
            $out.Add($Matches[1] + $sep + '"' + (Get-YcMaskedKey -Key $val -AllowGvlk) + '"')
        } else {
            $out.Add($a)
        }
    }
    return ($out -join ' ')
}

function ConvertTo-YcPlainText {
    <#
      .SYNOPSIS
        Unwraps a SecureString for the one moment a native EXE needs it.
      .DESCRIPTION
        The plain value is only ever handed straight to a process argument list
        and is never logged. Callers must not keep the return value in a variable
        that outlives the call.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param([Parameter(Mandatory = $true)][System.Security.SecureString] $Secure)
    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { return [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

# ---------------------------------------------------------------------------
# Microsoft-published GVLK client setup keys (Windows Server)
#   Source: https://learn.microsoft.com/en-us/windows-server/get-started/kms-client-activation-keys
#   Microsoft: "GVLKs are the only product keys that don't need to be kept
#   confidential." A GVLK activates only against YOUR KMS host or ADBA object -
#   it is not a licence and never activates against Microsoft's servers.
# ---------------------------------------------------------------------------

$script:YcGvlk = @(
    [pscustomobject]@{ Version = '2025';    Build = 26100; Edition = 'Standard';                  EditionId = 'ServerStandard';   Key = 'TVRH6-WHNXV-R9WG3-9XRFY-MY832' }
    [pscustomobject]@{ Version = '2025';    Build = 26100; Edition = 'Datacenter';                EditionId = 'ServerDatacenter'; Key = 'D764K-2NDRG-47T6Q-P8T8W-YP6DF' }
    [pscustomobject]@{ Version = '2025';    Build = 26100; Edition = 'Datacenter: Azure Edition'; EditionId = 'ServerTurbine';    Key = 'XGN3F-F394H-FD2MY-PP6FD-8MCRC' }
    [pscustomobject]@{ Version = '2022';    Build = 20348; Edition = 'Standard';                  EditionId = 'ServerStandard';   Key = 'VDYBN-27WPP-V4HQT-9VMD4-VMK7H' }
    [pscustomobject]@{ Version = '2022';    Build = 20348; Edition = 'Datacenter';                EditionId = 'ServerDatacenter'; Key = 'WX4NM-KYWYW-QJJR4-XV3QB-6VM33' }
    [pscustomobject]@{ Version = '2022';    Build = 20348; Edition = 'Datacenter: Azure Edition'; EditionId = 'ServerTurbine';    Key = 'NTBV8-9K7Q8-V27C6-M2BTV-KHMXV' }
    [pscustomobject]@{ Version = '2019';    Build = 17763; Edition = 'Standard';                  EditionId = 'ServerStandard';   Key = 'N69G4-B89J2-4G8F4-WWYCC-J464C' }
    [pscustomobject]@{ Version = '2019';    Build = 17763; Edition = 'Datacenter';                EditionId = 'ServerDatacenter'; Key = 'WMDGN-G9PQG-XVVXX-R3X43-63DFG' }
    [pscustomobject]@{ Version = '2019';    Build = 17763; Edition = 'Essentials';                EditionId = 'ServerSolution';   Key = 'WVDHN-86M7X-466P6-VHXV7-YY726' }
    [pscustomobject]@{ Version = '2016';    Build = 14393; Edition = 'Standard';                  EditionId = 'ServerStandard';   Key = 'WC2BQ-8NRM3-FDDYY-2BFGV-KHKQY' }
    [pscustomobject]@{ Version = '2016';    Build = 14393; Edition = 'Datacenter';                EditionId = 'ServerDatacenter'; Key = 'CB7KF-BWN84-R7R2Y-793K2-8XDDG' }
    [pscustomobject]@{ Version = '2016';    Build = 14393; Edition = 'Essentials';                EditionId = 'ServerSolution';   Key = 'JCKRF-N37P4-C2D82-9YXRT-4M63B' }
    [pscustomobject]@{ Version = '2012 R2'; Build = 9600;  Edition = 'Standard';                  EditionId = 'ServerStandard';   Key = 'D2N9P-3P6X9-2R39C-7RTCD-MDVJX' }
    [pscustomobject]@{ Version = '2012 R2'; Build = 9600;  Edition = 'Datacenter';                EditionId = 'ServerDatacenter'; Key = 'W3GGN-FT8W3-Y4M27-J84CP-Q3VJ9' }
    [pscustomobject]@{ Version = '2012 R2'; Build = 9600;  Edition = 'Essentials';                EditionId = 'ServerSolution';   Key = 'KNC87-3J2TX-XB4WP-VCPJV-M4FWM' }
)
# The host-based automatic activation table was REMOVED 2026-08-30.
# This estate is KVM/CloudStack and VMware/vCenter only, that mechanism cannot be used
# here, and shipping its keys beside the GVLK table invited picking the wrong one.
# Channel DETECTION is kept below - it is what lets the report say a box is on a channel
# it should not be on. Only the key table is gone.


function Get-YcGvlkTable { [CmdletBinding()] param() ; return $script:YcGvlk }

function Test-YcIsPublishedGvlk {
    [CmdletBinding()]
    [OutputType([bool])]
    param([AllowNull()][AllowEmptyString()][string] $Key)
    if ([string]::IsNullOrWhiteSpace($Key)) { return $false }
    $k = $Key.Trim().ToUpperInvariant()
    foreach ($row in $script:YcGvlk) { if ($row.Key -eq $k) { return $true } }
    return $false
}

function Test-YcProductKeyFormat {
    [CmdletBinding()]
    [OutputType([bool])]
    param([AllowNull()][AllowEmptyString()][string] $Key)
    if ([string]::IsNullOrWhiteSpace($Key)) { return $false }
    return ($Key.Trim().ToUpperInvariant() -match '^[A-Z0-9]{5}(-[A-Z0-9]{5}){4}$')
}

function Get-YcGvlkForEdition {
    <#
      .SYNOPSIS
        Returns the Microsoft-published GVLK for a Windows Server version and edition.
      .PARAMETER Build
        OS build number. 26100 = 2025, 20348 = 2022, 17763 = 2019, 14393 = 2016, 9600 = 2012 R2.
      .PARAMETER Edition
        'Standard', 'Datacenter', 'Datacenter: Azure Edition' or 'Essentials'.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory = $true)][int] $Build,
        [Parameter(Mandatory = $true)][string] $Edition
    )
    $e = ('' + $Edition).Trim()
    if ($e -match '(?i)azure')      { $e = 'Datacenter: Azure Edition' }
    elseif ($e -match '(?i)datacenter') { $e = 'Datacenter' }
    elseif ($e -match '(?i)essential|solution') { $e = 'Essentials' }
    elseif ($e -match '(?i)standard')   { $e = 'Standard' }
    foreach ($row in $script:YcGvlk) {
        if ($row.Build -eq $Build -and $row.Edition -eq $e) { return $row.Key }
    }
    return ''
}


# ---------------------------------------------------------------------------
# OS facts
# ---------------------------------------------------------------------------

function Get-YcOsFacts {
    <#
      .SYNOPSIS
        One CIM round trip for everything the licensing scripts need to decide.
      .OUTPUTS
        Caption, Build, Version (2025/2022/2019/2016/2012 R2/unknown), EditionId,
        InstallationType (Server / Server Core), IsCore, IsEvaluation,
        IsDomainController, IsDomainJoined, Domain, ProductType.
    #>
    [CmdletBinding()]
    param()
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem  -ErrorAction Stop

    $build = 0
    if ($os.BuildNumber -match '^\d+$') { $build = [int] $os.BuildNumber }

    $version = 'unknown'
    switch ($build) {
        { $_ -ge 26100 } { $version = '2025';    break }
        { $_ -ge 20348 } { $version = '2022';    break }
        { $_ -ge 17763 } { $version = '2019';    break }
        { $_ -ge 14393 } { $version = '2016';    break }
        { $_ -ge 9600  } { $version = '2012 R2'; break }
        default          { $version = 'unknown' }
    }

    $cv = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    $editionId = ''
    $installType = ''
    try { $editionId   = [string] (Get-ItemProperty -LiteralPath $cv -Name EditionID        -ErrorAction Stop).EditionID } catch { }
    try { $installType = [string] (Get-ItemProperty -LiteralPath $cv -Name InstallationType -ErrorAction Stop).InstallationType } catch { }

    # Microsoft's own eval test is "the current edition name includes Eval".
    # https://learn.microsoft.com/en-us/windows-server/get-started/upgrade-conversion-options
    $isEval = ($editionId -match '(?i)eval') -or (('' + $os.Caption) -match '(?i)evaluation')

    # DomainRole 4 = backup DC, 5 = primary DC.
    # https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-computersystem
    $role = 0
    if ($cs.DomainRole -ne $null) { $role = [int] $cs.DomainRole }

    [pscustomobject]@{
        Caption            = [string] $os.Caption
        Build              = $build
        Version            = $version
        EditionId          = $editionId
        InstallationType   = $installType
        IsCore             = ($installType -match '(?i)core')
        IsEvaluation       = $isEval
        ProductType        = [int] $os.ProductType     # 1 workstation, 2 DC, 3 server
        DomainRole         = $role
        IsDomainController = ($role -ge 4)
        IsDomainJoined     = [bool] $cs.PartOfDomain
        Domain             = [string] $cs.Domain
        ComputerName       = [string] $cs.Name
    }
}

# Get-YcHypervisorHint was removed in the v265 audit. It had no callers: its only
# purpose was gating a Hyper-V-only activation path this estate does not use.
# YallaCloud runs KVM and vCenter.
function Get-YcLicenseStatusName {
    [CmdletBinding()]
    [OutputType([string])]
    param([int] $Status)
    if ($script:YcLicenseStatusName.ContainsKey($Status)) { return $script:YcLicenseStatusName[$Status] }
    return ('Unknown (' + $Status + ')')
}

$script:YcLastSppError = ''

function Get-YcLastSppError {
    <#
      .SYNOPSIS
        The error the Software Protection Platform WMI provider last threw, or ''.
      .DESCRIPTION
        On a machine whose licensing store is damaged the provider does not return
        an empty result - it throws, typically with HRESULT 0xC004D302. That is a
        finding, not a crash, so it is recorded here rather than dropped.
    #>
    [CmdletBinding()][OutputType([string])] param()
    return $script:YcLastSppError
}

function Get-YcWindowsLicenseProduct {
    <#
      .SYNOPSIS
        The single SoftwareLicensingProduct instance that represents the
        installed Windows SKU.
      .DESCRIPTION
        Microsoft documents PartialProductKey as "Returns a null value if a
        product key is not installed", so that predicate alone filters out the
        dozens of inert SKU stubs present on every machine.
    #>
    [CmdletBinding()]
    param([CimSession] $CimSession)
    $splat = @{
        ClassName   = 'SoftwareLicensingProduct'
        Filter      = "PartialProductKey IS NOT NULL AND Name LIKE 'Windows%'"
        ErrorAction = 'Stop'
    }
    if ($CimSession) { $splat['CimSession'] = $CimSession }
    $script:YcLastSppError = ''
    $rows = @()
    try {
        $rows = @(Get-CimInstance @splat)
    } catch {
        # Seen live on YallaCloud template VMs: the provider throws
        # "The security processor reported that the trusted data store was
        # rearmed" with HRESULT 0xC004D302 instead of returning rows. Record the
        # code so the caller can report the documented remediation.
        $msg = '' + $_.Exception.Message
        $code = ''
        foreach ($t in @(('' + $_.FullyQualifiedErrorId), $msg)) {
            if ($t -match '(?i)(0x[0-9a-f]{8})') { $code = $Matches[1].ToLowerInvariant(); break }
        }
        $script:YcLastSppError = $(if ($code) { $code + ' - ' + $msg } else { $msg })
        return $null
    }
    if ($rows.Count -eq 0) { return $null }
    if ($rows.Count -eq 1) { return $rows[0] }
    # More than one Windows-named SKU carries a key: prefer the OS ApplicationID.
    foreach ($r in $rows) {
        if (('' + $r.ApplicationID) -eq '55c92734-d682-4d71-983e-d6ec3f16059f') { return $r }
    }
    return $rows[0]
}

function Get-YcActivationChannel {
    <#
      .SYNOPSIS
        Reads the activation channel out of the product Description.
      .DESCRIPTION
        SoftwareLicensingProduct has no ProductKeyChannel property. Microsoft's
        own ADBA troubleshooting guidance is to read the Description field, which
        carries the channel token (VOLUME_KMSCLIENT, RETAIL, MAK,
        VIRTUAL_MACHINE_ACTIVATION, OEM_*).
        https://learn.microsoft.com/en-us/troubleshoot/windows-server/licensing-and-activation/troubleshoot-adba-clients-not-activate
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param([AllowNull()][AllowEmptyString()][string] $Description)
    $d = '' + $Description
    if ($d -match '(?i)VOLUME_KMSCLIENT')           { return 'VOLUME_KMSCLIENT' }
    if ($d -match '(?i)VOLUME_MAK|\bMAK\b')         { return 'MAK' }
    if ($d -match '(?i)TIMEBASED_EVAL')             { return 'TIMEBASED_EVAL' }
    if ($d -match '(?i)\bRETAIL\b')                 { return 'RETAIL' }
    if ($d -match '(?i)OEM_')                       { return 'OEM' }
    return 'UNKNOWN'
}

function Resolve-YcActivationMethod {
    <#
      .SYNOPSIS
        Infers which licensed activation method a machine is actually using.
      .DESCRIPTION
        Channel token decides the family; the presence of a KMS host name then
        separates KMS from ADBA. A VOLUME_KMSCLIENT machine that is Licensed with
        no KMS host set and none discovered is activated by an Active Directory
        activation object.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [AllowNull()][AllowEmptyString()][string] $Channel,
        [int] $LicenseStatus = 0,
        [AllowNull()][AllowEmptyString()][string] $KmsMachine,
        [AllowNull()][AllowEmptyString()][string] $DiscoveredKmsMachine
    )
    $hasKms = -not ([string]::IsNullOrWhiteSpace($KmsMachine) -and [string]::IsNullOrWhiteSpace($DiscoveredKmsMachine))
    switch ('' + $Channel) {
        'MAK'              { return 'MAK' }
        'RETAIL'           { return 'Retail / MSDN media (cannot use KMS or ADBA)' }
        'OEM'              { return 'OEM' }
        'TIMEBASED_EVAL'   { return 'Evaluation (time-based, not licensed)' }
        'VOLUME_KMSCLIENT' {
            if ($hasKms) { return 'KMS' }
            if ($LicenseStatus -eq 1) { return 'ADBA (Active Directory-Based Activation)' }
            return 'Volume client, not yet activated (no KMS host reached, no AD object)'
        }
        default { return 'Unknown' }
    }
}

function Format-YcRearmCount {
    <#
      .SYNOPSIS
        Renders RemainingWindowsReArmCount honestly.
      .DESCRIPTION
        The property is uint32. 0xFFFFFFFF is the all-bits-set sentinel that
        Microsoft uses elsewhere in this class to mean "not applicable"
        (KeyManagementServiceCurrentCount documents -1 on a uint32 for exactly
        that). Microsoft does NOT publish the meaning for this property, so the
        toolkit says so rather than printing 4.29 billion rearms remaining.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param([AllowNull()] $Value)
    if ($null -eq $Value) { return 'not reported' }
    $d = [double] $Value
    if ($d -ge 4294967295) {
        return '4294967295 (0xFFFFFFFF sentinel - not applicable/not tracked; meaning not published by Microsoft. A licensing store in this state is usually damaged.)'
    }
    return ('' + [int64] $d)
}

# ---------------------------------------------------------------------------
# Activation error codes
#   Table: https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes
#   Codes marked Documented = $false have NO Microsoft-published meaning. The
#   toolkit says so instead of inventing one.
# ---------------------------------------------------------------------------

$script:YcActErrors = @(
    [pscustomobject]@{ Code='0xC004F074'; Documented=$true;  Meaning='No Key Management Service (KMS) could be contacted. Every KMS host that answered returned an error.'; Fix='Read Application event log ID 12288 for the embedded HRESULT of each attempt. Common causes: clock skew over 4 hours (w32tm /resync); sppsvc stopped on the KMS host; TCP 1688 blocked (Test-NetConnection <kmshost> -Port 1688); stale _vlmcs SRV or host A record; KMS host OS too old for this client. Then rerun slmgr /ato.'; Url='https://learn.microsoft.com/en-us/troubleshoot/windows-server/licensing-and-activation/error-0xc004f074-activate-windows' }
    [pscustomobject]@{ Code='0xC004F038'; Documented=$true;  Meaning='The count reported by your KMS host is insufficient.'; Fix='KMS needs at least 5 unique Windows Server clients (25 for Windows client) within the last 30 days. Check the host with slmgr /dli. Add machines to the pool, or use MAK/ADBA for a small estate.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004F015'; Documented=$true;  Meaning='The specified KMS cannot be used (sub-code 0xC004F042, SL_E_VL_KEY_MANAGEMENT_SERVICE_ID_MISMATCH). The wrong CSVLK is installed on the KMS host for this client OS.'; Fix='Install the correct KMS host key (CSVLK) for the client OS on the KMS host, from VLSC: License > Relationship Summary > License ID > Product Keys.'; Url='https://learn.microsoft.com/en-us/troubleshoot/windows-server/licensing-and-activation/error-0xc004f015-activate-windows-10' }
    [pscustomobject]@{ Code='0x8007232B'; Documented=$true;  Meaning='DNS name does not exist. The client could not resolve a KMS host.'; Fix='Confirm the _vlmcs._tcp SRV record exists (nslookup -type=all _vlmcs._tcp). If DNS cannot publish it, point the client explicitly: slmgr /skms <kmshost>:1688. If there is no KMS host at all, use a MAK.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/common-troubleshooting-procedures-kms-dns' }
    [pscustomobject]@{ Code='0x8007007B'; Documented=$true;  Meaning='DNS name does not exist.'; Fix='Same as 0x8007232B - DNS/SRV troubleshooting.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004E015'; Documented=$true;  Meaning='SL_E_EUL_CONSUMPTION_FAILED. C:\Windows\System32\spp\store\2.0\tokens.dat is corrupted.'; Fix='Run the documented tokens.dat rebuild: net stop sppsvc, rename tokens.dat, net start sppsvc, slmgr /rilc, reboot TWICE, then slmgr /ipk <key> and slmgr /ato. The house command activate-windows does this automatically when it sees this code.'; Url='https://learn.microsoft.com/en-us/troubleshoot/windows-server/licensing-and-activation/rebuild-tokens-dotdat-file' }
    [pscustomobject]@{ Code='0xC004F050'; Documented=$true;  Meaning='The product key is invalid.'; Fix='Verify the key matches the exact Windows edition and version. Check for typos and for hyphens auto-corrected into en/em dashes on paste. Do not use beta keys on a GA build.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004F035'; Documented=$true;  Meaning='Invalid Volume License Key - the machine has no Windows BIOS marker identifying it as an OEM system with a qualifying OS.'; Fix='Install a valid MAK or Retail key and activate. If activation then fails with 0x80072EE2, activate by phone: slmgr /dti, get the Confirmation ID from the Microsoft Licensing Activation Center, then slmgr /atp <ConfirmationID>.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004C003'; Documented=$true;  Meaning='The activation server determined the specified product key is blocked.'; Fix='Contact the Microsoft Licensing Activation Center for a replacement MAK, then reinstall the key and reactivate.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004C008'; Documented=$true;  Meaning='The specified product key could not be used - the KMS host key exceeded its activation limit.'; Fix='A CSVLK activates at most 6 KMS hosts and can be reactivated up to 9 times. Contact the Licensing Activation Center for more activations.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004C020'; Documented=$true;  Meaning='The MAK has exceeded its activation limit.'; Fix='Request additional activations from the Microsoft Licensing Activation Center.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004F009'; Documented=$true;  Meaning='The grace period expired; the system is in Notification state.'; Fix='Install a valid key and activate. Contact the Licensing Activation Center if activation is refused.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004F00F'; Documented=$true;  Meaning='Hardware ID binding is beyond the level of tolerance.'; Fix='MAK: reactivate online or by phone during the out-of-tolerance grace period. KMS: restart Windows, or run slmgr /ato from an elevated prompt.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004F014'; Documented=$true;  Meaning='The product key is not available.'; Fix='No key is installed. Install one: slmgr /ipk <key>. For a KMS host, the setup key is in Pid.txt in the \sources folder of the installation media.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004F039'; Documented=$true;  Meaning='The Key Management Service is not enabled.'; Fix='The KMS host is not responding. Check the host<->client network path and that nothing blocks TCP 1688.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004F041'; Documented=$true;  Meaning='The KMS host itself is not activated.'; Fix='Activate the KMS host, online or by telephone, before clients can use it.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004F042'; Documented=$true;  Meaning='The specified KMS cannot be used - the client reached a KMS host that cannot activate this product.'; Fix='Common in estates with both application-specific and OS-specific KMS hosts. Point the client at the correct host with slmgr /skms, or fix the SRV records.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004F051'; Documented=$true;  Meaning='The product key is blocked.'; Fix='Obtain a replacement MAK or KMS key, install it, and reactivate.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004F06C'; Documented=$true;  Meaning='The KMS determined the request timestamp is invalid.'; Fix='Client and host clocks differ by more than 4 hours. Sync time (w32tm /resync, or point at the domain hierarchy). KMS uses UTC, so the time zone is irrelevant.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0x800706BA'; Documented=$true;  Meaning='The RPC server is unavailable.'; Fix='Open TCP 1688 on the KMS host firewall, verify the SRV record points at a live host, and check basic connectivity.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0x80070005'; Documented=$true;  Meaning='Access denied - the action needs elevation.'; Fix='Re-run the command from an elevated PowerShell or Command Prompt.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0x80070490'; Documented=$true;  Meaning='The product key you entered did not work.'; Fix='Reinstall the key from an elevated prompt: slmgr /ipk <5x5 key>. Verify the key is the right one for this edition.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0x8004FE21'; Documented=$true;  Meaning='This computer is not running genuine Windows.'; Fix='Documented remedy is to reinstall the OS. Can be caused by MUI language packs on unlicensed editions, malware, or corrupted system files.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0x80072EE2'; Documented=$true;  Meaning='Network timeout reaching the Microsoft activation service (WinINet ERROR_INTERNET_TIMEOUT). Documented only as a sub-condition of 0xC004F035.'; Fix='Check outbound connectivity and proxy configuration to the Microsoft activation endpoints, or activate by phone: slmgr /dti then slmgr /atp <ConfirmationID>.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0xC004D302'; Documented=$false; Meaning='NOT PUBLISHED BY MICROSOFT. Absent from every Microsoft activation error table. Third-party sources name it SL_REMAPPING_SP_PUB_TS_REARMED (trusted data store rearmed / tampered), but that is not a primary source.'; Fix='Treat as trusted-store corruption. Apply the documented tokens.dat rebuild - activate-windows does this by itself when it hits this code - then reboot twice, reinstall the key and activate. If it recurs on every VM from one template, the template itself is damaged and must be rebuilt and resealed - no in-guest repair fixes a bad image.'; Url='https://learn.microsoft.com/en-us/troubleshoot/windows-server/licensing-and-activation/rebuild-tokens-dotdat-file' }
    [pscustomobject]@{ Code='0xC004F069'; Documented=$false; Meaning='NOT PUBLISHED BY MICROSOFT. No entry in any activation error table. The "run slui.exe 0x2a 0xC004F069" text you see is the generic message-lookup fallback shown when the SKU has no localised description, which is normal on Server Core.'; Fix='Render the text on a machine with the Desktop Experience: slui.exe 0x2a 0xC004F069. Otherwise treat it as an edition/key mismatch and apply the 0xC004F050 and 0xC004F015 remedies.'; Url='https://learn.microsoft.com/en-us/windows-server/get-started/activation-error-codes' }
    [pscustomobject]@{ Code='0x8A010101'; Documented=$false; Meaning='NOT A WINDOWS ACTIVATION CODE. Microsoft publishes this only as an Office for Mac activation error. It does not appear in any Windows volume activation table and must not be mapped into a Windows report.'; Fix='If it appears during a Windows edition conversion you are almost certainly looking at DISM error 1168 instead ("The specified product key could not be validated"). See the convert-edition command.'; Url='https://support.microsoft.com/en-us/office/error-0x8a010101-when-activating-office-for-mac-804de2bd-12d8-40a9-95fd-03dc3e4d262f' }
)

function Get-YcActivationErrorTable { [CmdletBinding()] param() ; return $script:YcActErrors }

function Resolve-YcActivationError {
    <#
      .SYNOPSIS
        Maps an HRESULT (int, uint or 0x string) to the Microsoft-documented fix.
      .DESCRIPTION
        Accepts LicenseStatusReason straight off SoftwareLicensingProduct, or a
        code scraped from slmgr output. Returns $null when the code is not in the
        table, so the caller can say "unmapped" rather than guess.
    #>
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][AllowNull()] $Code)
    if ($null -eq $Code) { return $null }
    $hex = ''
    if ($Code -is [string]) {
        if ($Code -match '(?i)(0x[0-9a-f]{8})') { $hex = $Matches[1].ToUpperInvariant() }
        elseif ($Code -match '^\d+$')            { $hex = ('0x{0:X8}' -f ([uint32] [uint64] $Code)) }
    } else {
        # 4294967295, not 0xFFFFFFFF: PowerShell parses that hex literal as [int] -1,
        # which turns the mask into a no-op and then blows up on the uint32 cast.
        $hex = ('0x{0:X8}' -f ([uint32] ([int64] $Code -band 4294967295L)))
    }
    if (-not $hex) { return $null }
    $hex = $hex.ToUpperInvariant().Replace('0X', '0x')
    foreach ($e in $script:YcActErrors) {
        if ($e.Code.ToUpperInvariant() -eq $hex.ToUpperInvariant()) { return $e }
    }
    return $null
}

# ---------------------------------------------------------------------------
# Process helpers
# ---------------------------------------------------------------------------

function Invoke-YcProcess {
    <#
      .SYNOPSIS
        Runs a native executable and captures stdout, stderr and the exit code.
      .DESCRIPTION
        Arguments are passed as an array so that a password or PID never gets
        interpolated into a single command string that a transcript could catch.
        The echoed command line is masked.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string] $FilePath,
        [Parameter(Mandatory = $true)][AllowEmptyCollection()][string[]] $Arguments,
        [int] $TimeoutSeconds = 0,
        [switch] $Quiet
    )
    if (-not $Quiet) {
        Write-YcLog ('run: ' + $FilePath + ' ' + (Get-YcMaskedCommandLine -Arguments $Arguments)) 'STEP'
    }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName               = $FilePath
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute        = $false
    $psi.CreateNoWindow         = $true
    # Callers pass one array element per token and quote any value that can
    # contain a space themselves (e.g. '/SQLUSERDBDIR="D:\SQL Data"'). Joining
    # here rather than re-quoting keeps setup.exe's /NAME=value syntax intact -
    # wrapping the whole pair in quotes is what breaks it.
    $psi.Arguments = ($Arguments -join ' ')

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    $null = $p.Start()
    $out = $p.StandardOutput.ReadToEnd()
    $err = $p.StandardError.ReadToEnd()
    if ($TimeoutSeconds -gt 0) {
        if (-not $p.WaitForExit($TimeoutSeconds * 1000)) {
            try { $p.Kill() } catch { }
            return [pscustomobject]@{ ExitCode = -1; StdOut = $out; StdErr = 'TIMEOUT after ' + $TimeoutSeconds + 's'; TimedOut = $true }
        }
    } else {
        $p.WaitForExit()
    }
    return [pscustomobject]@{ ExitCode = $p.ExitCode; StdOut = $out; StdErr = $err; TimedOut = $false }
}

function Invoke-YcSlmgr {
    <#
      .SYNOPSIS
        Runs slmgr.vbs through cscript so its output lands on stdout instead of
        in a MsgBox nobody will ever click.
      .LINK
        https://learn.microsoft.com/en-us/windows-server/get-started/activation-slmgr-vbs-options
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][AllowEmptyCollection()][string[]] $Arguments,
        [int] $TimeoutSeconds = 180,
        [switch] $Quiet
    )
    $slmgr = Join-Path ([Environment]::GetFolderPath('System')) 'slmgr.vbs'
    if (-not (Test-Path -LiteralPath $slmgr)) { $slmgr = 'C:\Windows\System32\slmgr.vbs' }
    $slArgs = @('//nologo', ('"' + $slmgr + '"')) + $Arguments
    $r = Invoke-YcProcess -FilePath 'cscript.exe' -Arguments $slArgs -TimeoutSeconds $TimeoutSeconds -Quiet:$Quiet
    $text = ($r.StdOut + "`n" + $r.StdErr)
    $code = ''
    if ($text -match '(?i)(0x[0-9A-F]{8})') { $code = $Matches[1] }
    return [pscustomobject]@{
        ExitCode  = $r.ExitCode
        Text      = $text
        ErrorCode = $code
        Succeeded = ($r.ExitCode -eq 0 -and -not $code)
    }
}

function Test-YcElevated {
    [CmdletBinding()]
    [OutputType([bool])]
    param()
    try {
        $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $pr.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Assert-YcWindows {
    <#
      .SYNOPSIS
        Refuses to run the machine-touching parts anywhere but Windows.
        -SelfCheck paths call nothing that needs this, so they stay portable.
    #>
    [CmdletBinding()]
    param()
    $isWin = $true
    if (Get-Variable -Name IsWindows -Scope Global -ErrorAction SilentlyContinue) { $isWin = [bool] $global:IsWindows }
    if (-not $isWin) { throw 'This script changes Windows licensing state and only runs on Windows.' }
}

# ---------------------------------------------------------------------------
# SQL Server discovery - registry first, because it works with the engine down
#   https://learn.microsoft.com/en-us/sql/sql-server/install/file-locations-for-default-and-named-instances-of-sql-server
# ---------------------------------------------------------------------------

$script:YcSqlMajorToVersion = @{
    13 = '2016'; 14 = '2017'; 15 = '2019'; 16 = '2022'; 17 = '2025'
}
$script:YcSqlVersionToMajor = @{
    '2016' = 13; '2017' = 14; '2019' = 15; '2022' = 16; '2025' = 17
}

function Get-YcSqlMajorFromVersion {
    [CmdletBinding()][OutputType([int])]
    param([Parameter(Mandatory = $true)][string] $Version)
    if ($script:YcSqlVersionToMajor.ContainsKey($Version)) { return $script:YcSqlVersionToMajor[$Version] }
    return 0
}

function Get-YcSqlVersionFromMajor {
    [CmdletBinding()][OutputType([string])]
    param([Parameter(Mandatory = $true)][int] $Major)
    if ($script:YcSqlMajorToVersion.ContainsKey($Major)) { return $script:YcSqlMajorToVersion[$Major] }
    return ''
}

function Get-YcSqlInstance {
    <#
      .SYNOPSIS
        Enumerates installed SQL Server instances from the registry.
      .DESCRIPTION
        Registry, not T-SQL, because an expired Evaluation instance will not
        start and is exactly the case that has to be reported on.
        Note the documented difference between the two version values:
          Version    = the build the media originally installed (frozen)
          PatchLevel = the build the instance has since been patched to
        Compare PatchLevel - never Version - against a required build.
    #>
    [CmdletBinding()]
    param([string] $InstanceName)
    $root = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL'
    if (-not (Test-Path -LiteralPath $root)) { return @() }
    $names = $null
    try { $names = Get-ItemProperty -LiteralPath $root -ErrorAction Stop } catch { return @() }

    $out = New-Object System.Collections.Generic.List[object]
    foreach ($p in $names.PSObject.Properties) {
        if ($p.Name -like 'PS*') { continue }
        if ($InstanceName -and $p.Name -ne $InstanceName) { continue }
        $instanceId = [string] $p.Value
        $setup = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\' + $instanceId + '\Setup'
        $s = $null
        try { $s = Get-ItemProperty -LiteralPath $setup -ErrorAction Stop } catch { }
        $get = {
            param($obj, $name)
            if ($obj -and $obj.PSObject.Properties[$name]) { return [string] $obj.PSObject.Properties[$name].Value }
            return ''
        }
        $major = 0
        if ($instanceId -match '^MSSQL(\d+)\.') { $major = [int] $Matches[1] }
        $out.Add([pscustomobject]@{
            InstanceName = $p.Name
            InstanceId   = $instanceId
            Major        = $major
            Version      = (Get-YcSqlVersionFromMajor -Major $major)
            Edition      = (& $get $s 'Edition')
            EditionType  = (& $get $s 'EditionType')
            BaseVersion  = (& $get $s 'Version')
            PatchLevel   = (& $get $s 'PatchLevel')
            Collation    = (& $get $s 'Collation')
            SqlPath      = (& $get $s 'SQLPath')
            SqlDataRoot  = (& $get $s 'SQLDataRoot')
            FeatureList  = (& $get $s 'FeatureList')
            ServiceName  = $(if ($p.Name -eq 'MSSQLSERVER') { 'MSSQLSERVER' } else { 'MSSQL$' + $p.Name })
        })
    }
    return $out.ToArray()
}

function Test-YcSqlIsEvaluation {
    <#
      .SYNOPSIS
        True when the edition string says Evaluation.
      .DESCRIPTION
        Edition string only. EngineEdition cannot do this job: it returns 3 for
        Enterprise, Evaluation AND Developer alike.
    #>
    [CmdletBinding()][OutputType([bool])]
    param([AllowNull()][AllowEmptyString()][string] $Edition)
    return (('' + $Edition) -match '(?i)evaluation')
}

# ---------------------------------------------------------------------------
# SQL Server supported edition-upgrade matrix
#   2017/2019/2022: https://learn.microsoft.com/en-us/sql/database-engine/install-windows/supported-version-and-edition-upgrades-2022
#   2025          : https://learn.microsoft.com/en-us/sql/database-engine/install-windows/supported-version-and-edition-upgrades-2025
#   2016 has no live article; it followed the 2017 matrix and additionally
#   shipped Business Intelligence, whose only documented target is Enterprise.
# ---------------------------------------------------------------------------

$script:YcSqlUpgradeMatrix = @(
    [pscustomobject]@{ Versions='2016,2017,2019,2022'; From='Evaluation';              To=@('Enterprise','Standard','Developer','Web') }
    [pscustomobject]@{ Versions='2016,2017,2019,2022'; From='Developer';               To=@('Enterprise','Standard','Web') }
    [pscustomobject]@{ Versions='2016,2017,2019,2022'; From='Express';                 To=@('Enterprise','Developer','Standard','Web') }
    [pscustomobject]@{ Versions='2016,2017,2019,2022'; From='Web';                     To=@('Enterprise','Standard') }
    [pscustomobject]@{ Versions='2016,2017,2019,2022'; From='Standard';                To=@('Enterprise') }
    [pscustomobject]@{ Versions='2016,2017,2019,2022'; From='Enterprise';              To=@('Enterprise') }
    [pscustomobject]@{ Versions='2016';               From='Business Intelligence';   To=@('Enterprise') }
    [pscustomobject]@{ Versions='2025';               From='Evaluation';              To=@('Enterprise','Standard','Developer') }
    [pscustomobject]@{ Versions='2025';               From='Developer';               To=@('Enterprise','Standard') }
    [pscustomobject]@{ Versions='2025';               From='Express';                 To=@('Enterprise','Developer','Standard') }
    [pscustomobject]@{ Versions='2025';               From='Standard';                To=@('Enterprise') }
    [pscustomobject]@{ Versions='2025';               From='Enterprise';              To=@('Enterprise') }
)

function Get-YcSqlUpgradeMatrix { [CmdletBinding()] param() ; return $script:YcSqlUpgradeMatrix }

function Get-YcSqlEditionFamily {
    <#
      .SYNOPSIS
        Reduces a full edition string to the family name used by the matrix.
      .EXAMPLE
        'Enterprise Evaluation Edition (64-bit)' -> 'Evaluation'
        'Enterprise Edition: Core-based Licensing' -> 'Enterprise'
    #>
    [CmdletBinding()][OutputType([string])]
    param([AllowNull()][AllowEmptyString()][string] $Edition)
    $e = '' + $Edition
    if ($e -match '(?i)evaluation')            { return 'Evaluation' }
    if ($e -match '(?i)developer')             { return 'Developer' }
    if ($e -match '(?i)express')               { return 'Express' }
    if ($e -match '(?i)\bweb\b')               { return 'Web' }
    if ($e -match '(?i)business intelligence') { return 'Business Intelligence' }
    if ($e -match '(?i)enterprise')            { return 'Enterprise' }
    if ($e -match '(?i)standard')              { return 'Standard' }
    return ''
}

function Test-YcSqlEditionUpgradeSupported {
    <#
      .SYNOPSIS
        Is From -> To a Microsoft-supported edition upgrade on this SQL version?
      .OUTPUTS
        Supported (bool), Reason (string), Allowed (string[]).
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string] $SqlVersion,
        [Parameter(Mandatory = $true)][string] $FromEdition,
        [Parameter(Mandatory = $true)][string] $ToEdition
    )
    $from = Get-YcSqlEditionFamily -Edition $FromEdition
    $to   = Get-YcSqlEditionFamily -Edition $ToEdition
    if (-not $from) { return [pscustomobject]@{ Supported=$false; Reason=('Could not classify the current edition: ' + $FromEdition); Allowed=@() } }
    if (-not $to)   { return [pscustomobject]@{ Supported=$false; Reason=('Could not classify the target edition: ' + $ToEdition);  Allowed=@() } }

    foreach ($row in $script:YcSqlUpgradeMatrix) {
        if (($row.Versions -split ',') -notcontains $SqlVersion) { continue }
        if ($row.From -ne $from) { continue }
        if ($row.To -contains $to) {
            return [pscustomobject]@{ Supported=$true; Reason=($from + ' -> ' + $to + ' is supported on SQL Server ' + $SqlVersion); Allowed=$row.To }
        }
        return [pscustomobject]@{ Supported=$false; Reason=($from + ' -> ' + $to + ' is NOT a supported edition upgrade on SQL Server ' + $SqlVersion); Allowed=$row.To }
    }
    return [pscustomobject]@{ Supported=$false; Reason=('No documented upgrade path from ' + $from + ' on SQL Server ' + $SqlVersion); Allowed=@() }
}

# ---------------------------------------------------------------------------
# SQL Server lifecycle
#   https://learn.microsoft.com/en-us/lifecycle/products/sql-server-2016 (and 2017/2019/2022/2025)
# ---------------------------------------------------------------------------

$script:YcSqlLifecycle = @(
    [pscustomobject]@{ Version='2016'; Major=13; Mainstream='2021-07-14'; Extended='2026-07-15' }
    [pscustomobject]@{ Version='2017'; Major=14; Mainstream='2022-10-12'; Extended='2027-10-13' }
    [pscustomobject]@{ Version='2019'; Major=15; Mainstream='2025-03-01'; Extended='2030-01-09' }
    [pscustomobject]@{ Version='2022'; Major=16; Mainstream='2028-01-12'; Extended='2033-01-12' }
    [pscustomobject]@{ Version='2025'; Major=17; Mainstream='2031-01-07'; Extended='2036-01-07' }
)

function Get-YcSqlLifecycle {
    [CmdletBinding()]
    param([string] $Version)
    if (-not $Version) { return $script:YcSqlLifecycle }
    foreach ($r in $script:YcSqlLifecycle) { if ($r.Version -eq $Version) { return $r } }
    return $null
}

function Get-YcSqlSupportState {
    <#
      .SYNOPSIS
        'Mainstream', 'Extended' or 'OutOfSupport' for a SQL Server version.
    #>
    [CmdletBinding()][OutputType([string])]
    param(
        [Parameter(Mandatory = $true)][string] $Version,
        [datetime] $AsOf = (Get-Date)
    )
    $r = Get-YcSqlLifecycle -Version $Version
    if (-not $r) { return 'Unknown' }
    if ($AsOf -le [datetime]::ParseExact($r.Mainstream, 'yyyy-MM-dd', $null)) { return 'Mainstream' }
    if ($AsOf -le [datetime]::ParseExact($r.Extended,   'yyyy-MM-dd', $null)) { return 'Extended' }
    return 'OutOfSupport'
}

# ---------------------------------------------------------------------------
# Windows Server lifecycle (extended support end)
#   https://learn.microsoft.com/en-us/lifecycle/products/windows-server-2016 (and 2019/2022/2025)
# ---------------------------------------------------------------------------

$script:YcWinLifecycle = @(
    [pscustomobject]@{ Version='2012 R2'; Mainstream='2018-10-09'; Extended='2023-10-10' }
    [pscustomobject]@{ Version='2016';    Mainstream='2022-01-11'; Extended='2027-01-12' }
    [pscustomobject]@{ Version='2019';    Mainstream='2024-01-09'; Extended='2029-01-09' }
    [pscustomobject]@{ Version='2022';    Mainstream='2026-10-13'; Extended='2031-10-14' }
    [pscustomobject]@{ Version='2025';    Mainstream='2029-10-09'; Extended='2034-10-10' }
)

function Get-YcWindowsLifecycle {
    [CmdletBinding()]
    param([string] $Version)
    if (-not $Version) { return $script:YcWinLifecycle }
    foreach ($r in $script:YcWinLifecycle) { if ($r.Version -eq $Version) { return $r } }
    return $null
}

# End of _yc-licensing.ps1
