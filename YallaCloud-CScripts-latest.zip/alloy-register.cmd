@echo off
setlocal
rem ================================================================================================
rem alloy-register - install Grafana Alloy, put the config WHERE THE SERVICE READS IT, validate it
rem                  with 'alloy validate', and prove /-/ready and /-/healthy.
rem                  Wrapper for C:\Scripts\Alloy-Register.ps1.
rem
rem WHAT CHANGED, AND WHY:
rem   - Added "exit /b %ERRORLEVEL%" so the real exit code reaches cloud-init / the RMM.
rem   - -ConfigUrl / -ConfigFile now actually take effect: the old script wrote the config to
rem     %ProgramData%\GrafanaLabs\Alloy, which nothing reads (the service loads the path recorded
rem     in HKLM\SOFTWARE\GrafanaLabs\Alloy -> Arguments, under %ProgramFiles%).
rem   - Credentials belong INSIDE the config file you pass, never on this command line.
rem
rem USAGE:
rem   alloy-register -ConfigFile <C:\path\config.alloy> [-Environment '<extra flags>']
rem   alloy-register -ConfigUrl <http-url-to-config.alloy> [-Sha256 <hash>]
rem   alloy-register -Help
rem
rem EXIT CODES: 0 verified | 1 failed | 2 usage | 5 not elevated | 6 no internet
rem Log: C:\Scripts\alloy-register.log
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Alloy-Register.ps1" %*
exit /b %ERRORLEVEL%
