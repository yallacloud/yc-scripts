# yc-activate.ps1 - self-verifying activation. PS 5.1, ASCII only.
# Runs from the YCActivate scheduled task after the rearm reboot.
# Post-rearm Windows sits in "Initial grace period" (~9 days) until /ato succeeds;
# /ato needs the network, which is often not ready at first boot - so RETRY, and
# only delete the task once /dlv actually reports Licensed. v253 deleted the task
# unconditionally, so a single early failure was permanent.
$ErrorActionPreference = 'Continue'
$log = 'C:\Scripts\yc-firstboot.log'
function Log($m) { $t = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'; Add-Content -Path $log -Value ("[$t] activate: " + $m) -Encoding ascii }
$slmgr = 'C:\Windows\System32\slmgr.vbs'

for ($i = 1; $i -le 10; $i++) {
    $dlv = (& cscript //nologo $slmgr /dlv 2>&1) -join "`n"
    if ($dlv -match 'License Status:\s*Licensed') {
        $xpr = (& cscript //nologo $slmgr /xpr 2>&1) -join ' '
        Log ('LICENSED - ' + $xpr.Trim())
        & schtasks /delete /tn YCActivate /f 2>&1 | Out-Null
        Log 'YCActivate task removed'
        exit 0
    }
    Log ("attempt $i - not licensed yet, running /ato")
    & cscript //nologo $slmgr /ato 2>&1 | Out-File -FilePath $log -Append -Encoding ascii
    Start-Sleep -Seconds 30
}
Log 'still not Licensed after 10 attempts - task left in place, will retry next boot'
