@echo off
rem restore-sql - restore a database from the backup-sql chain, and PROVE it came back.
rem
rem   restore-sql -Database SALES                                newest full + matching diff + logs
rem   restore-sql -Database SALES -AsName SALES_COPY             restore BESIDE the live database
rem   restore-sql -Database SALES -StopAt "2026-09-01 01:04:23"  point in time
rem   restore-sql -Database SALES -WhatIf                        print the plan, restore nothing
rem   restore-sql -Database SALES -Force                         overwrite an existing database
rem   restore-sql -SelfCheck  |  restore-sql -Help
rem
rem The differential is chosen by DatabaseBackupLSN matching the full's CheckpointLSN, never by
rem timestamp, and logs are applied in FirstLSN order. A gap in the log chain is refused BEFORE
rem anything is restored. -StopAt is truncated to whole seconds because STOPAT takes a datetime -
rem a datetime2(7) value fails with Msg 3217 and silently leaves only the full restored.
rem
rem EXIT CODES: 0 restored and verified, 1 failure, 2 refused by preflight (no chain, broken
rem             chain, database exists without -Force, unparseable -StopAt), 5 not elevated,
rem             99 unhandled.  Log: C:\Scripts\restore-sql.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Restore-Sql.ps1" %*
exit /b %ERRORLEVEL%
