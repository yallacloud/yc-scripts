param(
  # ---- name preserved from diagtools-install.cmd and the catalog ----
  [switch]$Help,
  # ---- ADDED in this revision ----
  [string]$ToolsDir = 'C:\Scripts\DiagTools',   # where the installers/portables are staged
  [switch]$Force,                               # re-run an installer even if the tool is present
  [int]$TimeoutSec = 900                        # per-installer timeout
)
# =====================================================================================
# DiagTools-Install.ps1 - install the STAGED diagnostic tools on a deployed VM, and PROVE
# each one is present afterwards. PowerShell 5.1, ASCII only, unattended.
#
# 2026-08-19: repaired. Added the library guard + Exit-Yc on every path (two bare exits and
#             no Stop-YcLog anywhere); both installers now run through Invoke-YcInstaller so
#             their exit code is captured, decoded and timed; and EVERY tool must be proven
#             present after the install - smartctl by running it and reading its version,
#             LogParser.exe by file + FileVersion read-back, and the portable tools by
#             locating their binaries. Added -ToolsDir, -Force, -TimeoutSec.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P0] IT PRINTED "diagtools-install done." IN GREEN NO MATTER WHAT HAPPENED.
#   Old lines 21-22:
#     Start-Process $s -ArgumentList '/S' -Wait
#     Start-Process msiexec.exe -ArgumentList "/i `"$l`" /qn" -Wait
#   Neither had -PassThru, so there was no process object and therefore no exit code to
#   check even in principle - the same shape as the Acronis failure. An NSIS installer that
#   refuses its command line exits non-zero in under a second and the old script could not
#   see it. Then it printed success and did not call Stop-YcLog, so the transcript had no
#   [END] line either.
#   NOW: Invoke-YcInstaller captures and decodes each exit code with a timeout and a minimum
#   plausible duration, and NOTHING is reported as installed until its binary has been
#   located and interrogated.
#
# [P1] IT ALSO PASSED THE MSI ARGUMENTS AS ONE STRING.
#   -ArgumentList "/i `"$l`" /qn" is a single argument containing spaces and embedded
#   quotes. It happens to work with msiexec, but a staged path containing a space is
#   re-split by the shell rather than by us. The argument list is now a string ARRAY, which
#   is what Invoke-YcInstaller and Start-Process expect.
#
# IDEMPOTENT: a tool that is already present is NOT reinstalled unless -Force is given, and
# it is still verified, so a second run is a no-op that re-proves the host. Running this as
# an upgrade over an existing install is safe: msiexec 1638 ("another version of this
# product is already installed") is reported and the existing install is verified instead.
#
# VENDOR VERIFICATION - every switch below is documented:
#   smartmontools ships an NSIS installer; /S is the NSIS silent switch and /D=<dir> sets
#   the target ($INSTDIR default $PROGRAMFILES\smartmontools, smartctl.exe under \bin):
#     https://nsis.sourceforge.io/Docs/Chapter3.html      (section 3.2, /S and /D)
#     https://github.com/smartmontools/smartmontools/blob/master/os_win32/installer.nsi
#   Log Parser 2.2 is distributed as LogParser.msi and takes the standard Windows Installer
#   options (/i, /qn, REBOOT=ReallySuppress, /l*v):
#     https://www.microsoft.com/en-us/download/details.aspx?id=24659
#     https://learn.microsoft.com/en-us/windows/win32/msi/standard-installer-command-line-options
#   No pentest tooling is staged or installed by this command.
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was installed. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'diagtools-install'

$Usage = @'
diagtools-install  -  install the STAGED diagnostic tools on THIS (deployed) VM and prove
                      each one is really there afterwards.

  Silent installs : smartmontools (NSIS /S), Log Parser 2.2 (LogParser.msi /qn).
  Portable tools  : testdisk, photorec and iperf3 are already extracted under
                    C:\Scripts\DiagTools and need no install - they are only VERIFIED.
  No nmap or other pentest tooling is included.

USAGE:
  diagtools-install
  diagtools-install -ToolsDir D:\stage\DiagTools
  diagtools-install -Force
  diagtools-install -Help

PARAMETERS:
  -ToolsDir    Folder holding the staged installers and portable tools.
               Default C:\Scripts\DiagTools. Must exist.
  -Force       Re-run an installer even when the tool is already present. Without it, an
               already-installed tool is left alone and simply re-verified.
  -TimeoutSec  Per-installer timeout in seconds (default 900). An installer that hangs is
               killed and reported, not waited on for ever.
  -Help        Show this help and exit.

EXAMPLES:
  diagtools-install
  diagtools-install -ToolsDir D:\stage\DiagTools
  diagtools-install -Force
  diagtools-install -Help

PROOF OF SUCCESS (nothing is assumed):
  smartmontools : smartctl.exe located, then RUN with --version and its banner captured
  Log Parser    : LogParser.exe located and its FileVersion read back from the binary
  portable tools: testdisk.exe / photorec.exe / iperf3.exe located under -ToolsDir
  Every installer exit code is captured, decoded and timed. A staged installer that exits
  in under two seconds is reported as suspicious rather than as a success, because that is
  what "the installer rejected the command line and installed nothing" looks like.

EXIT CODES:
  0  every tool that could be installed is present and verified
  1  at least one tool could not be installed or could not be proven present, or -ToolsDir
     holds no recognised staged tool and none of them is already installed
  2  usage error (-TimeoutSec below 1)
  3  C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4  -ToolsDir does not exist (nothing was attempted)
  5  not running as Administrator
  The individual installers' own exit codes are decoded in the log; they are not returned
  as this command's exit code, because one command installs several packages.

Log: C:\Scripts\diagtools-install.log   MSI log: C:\Scripts\logparser-msi.log
     (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

if($TimeoutSec -lt 1){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 ('-TimeoutSec must be at least 1, got ' + $TimeoutSec) 'ERROR'
}
if(-not (Test-Path -LiteralPath $ToolsDir)){
  Exit-Yc 4 ('no staged tools at ' + $ToolsDir + ' - stage them or pass -ToolsDir. Nothing was installed.') 'ERROR'
}
Write-YcLog ('staged tools directory: ' + $ToolsDir)

$installed = @()
$verified  = @()
$failedT   = @()
$skipped   = @()

function Find-YcTool{
  param([string[]]$Candidates,[string]$OnPath)
  foreach($c in $Candidates){
    if($c -and (Test-Path -LiteralPath $c)){ return $c }
  }
  if($OnPath){
    $g = Get-Command $OnPath -ErrorAction Ignore     # presence probe, not load-bearing
    if($g -and $g.Source -and (Test-Path -LiteralPath $g.Source)){ return $g.Source }
  }
  return ''
}

function Get-YcStaged{
  param([string]$Pattern)
  $f = @(Get-ChildItem -Path (Join-Path $ToolsDir $Pattern) -File -ErrorAction Ignore | Sort-Object Name -Descending)
  if($f.Count -eq 0){ return '' }
  if($f.Count -gt 1){ Write-YcLog ('several staged files match ' + $Pattern + ' - using ' + $f[0].Name) 'WARN' }
  return $f[0].FullName
}

# -------------------------------------------------------------------------------------
# 1. smartmontools (NSIS installer, /S)
# -------------------------------------------------------------------------------------
$smartPaths = @(
  'C:\Program Files\smartmontools\bin\smartctl.exe',
  'C:\Program Files (x86)\smartmontools\bin\smartctl.exe',
  'C:\Program Files\smartmontools\bin64\smartctl.exe'
)
$smartctl = Find-YcTool -Candidates $smartPaths -OnPath 'smartctl'
$setup    = Get-YcStaged 'smartmontools*.exe'
$smartFailed  = $false
$smartStaged  = [bool]$setup

if($smartctl -and -not $Force){
  Write-YcLog ('smartmontools is already installed (' + $smartctl + ') - not reinstalling (use -Force). It will still be verified.')
  $skipped += 'smartmontools (already present)'
}elseif(-not $setup){
  Write-YcLog ('no smartmontools installer staged in ' + $ToolsDir + ' (expected smartmontools*.exe) - skipping SMART tooling') 'WARN'
  $skipped += 'smartmontools (no staged installer)'
}else{
  if(-not (Assert-YcFile -Path $setup -MinBytes 200KB -Because 'staged smartmontools installer')){
    $failedT += 'smartmontools (staged installer is missing or truncated)'; $smartFailed = $true
  }else{
    # /S is the NSIS silent switch. The installer's own defaults place smartctl.exe in
    # $PROGRAMFILES\smartmontools\bin; we do NOT pass /D, so an existing custom location
    # recorded by a previous install is honoured.
    $r = Invoke-YcInstaller -FilePath $setup -ArgumentList @('/S') -SuccessCodes @(0) -RebootCodes @(3010,1641) -TimeoutSec $TimeoutSec -MinSeconds 2
    if($r.TimedOut){
      $failedT += ('smartmontools (installer killed after ' + $TimeoutSec + 's)'); $smartFailed = $true
    }elseif(-not $r.Success){
      $failedT += ('smartmontools (installer exit ' + $r.ExitCode + ': ' + $r.Meaning + ')'); $smartFailed = $true
    }else{
      $installed += 'smartmontools'
    }
  }
}

# PROOF: find smartctl and make it TELL us its version. A present file is not a working tool.
if(-not $smartFailed){
  $smartctl = Find-YcTool -Candidates $smartPaths -OnPath 'smartctl'
  if(-not $smartctl){
    if($smartStaged){
      Write-YcLog ('smartctl.exe cannot be found after the install. smartmontools is NOT usable. Searched: ' + ($smartPaths -join '; ') + ' and PATH.') 'ERROR'
      $failedT += 'smartmontools (smartctl.exe not found after install)'
    }
  }elseif(Assert-YcFile -Path $smartctl -MinBytes 20KB -Because 'smartctl.exe'){
    $banner = ''
    try{ $banner = ((& $smartctl --version 2>&1) | Out-String) }catch{ $banner = '' }
    $first = ''
    if($banner){ $first = (($banner -split "`r?`n") | Where-Object { $_.Trim() } | Select-Object -First 1) }
    if($first -match '(?i)smartctl'){
      Write-YcLog ('smartmontools VERIFIED: ' + $smartctl + ' reports "' + $first.Trim() + '"') 'OK'
      $verified += ('smartctl (' + $first.Trim() + ')')
    }else{
      Write-YcLog ('smartctl.exe exists at ' + $smartctl + ' but "smartctl --version" produced no recognisable banner: ' + $first) 'ERROR'
      $failedT += 'smartmontools (smartctl runs but does not identify itself)'
    }
  }else{
    $failedT += 'smartmontools (smartctl.exe is present but unusable)'
  }
}

# -------------------------------------------------------------------------------------
# 2. Log Parser 2.2 (Windows Installer package)
# -------------------------------------------------------------------------------------
$lpPaths = @(
  'C:\Program Files (x86)\Log Parser 2.2\LogParser.exe',
  'C:\Program Files\Log Parser 2.2\LogParser.exe'
)
$MsiLog   = 'C:\Scripts\logparser-msi.log'
$logparser = Find-YcTool -Candidates $lpPaths -OnPath 'logparser'
$lpMsi     = Get-YcStaged 'LogParser*.msi'
$lpFailed  = $false
$lpStaged  = [bool]$lpMsi

if($logparser -and -not $Force){
  Write-YcLog ('Log Parser is already installed (' + $logparser + ') - not reinstalling (use -Force). It will still be verified.')
  $skipped += 'logparser (already present)'
}elseif(-not $lpMsi){
  Write-YcLog ('no Log Parser package staged in ' + $ToolsDir + ' (expected LogParser*.msi) - skipping Log Parser') 'WARN'
  $skipped += 'logparser (no staged package)'
}else{
  if(-not (Assert-YcFile -Path $lpMsi -MinBytes 500KB -Because 'staged LogParser.msi')){
    $failedT += 'logparser (staged package is missing or truncated)'; $lpFailed = $true
  }else{
    $a = @('/i', ('"' + $lpMsi + '"'), '/qn', 'REBOOT=ReallySuppress', '/l*v', ('"' + $MsiLog + '"'))
    $r = Invoke-YcInstaller -FilePath 'msiexec.exe' -ArgumentList $a -SuccessCodes @(0) -RebootCodes @(3010,1641) -TimeoutSec $TimeoutSec -MinSeconds 2
    if($r.TimedOut){
      $failedT += ('logparser (msiexec killed after ' + $TimeoutSec + 's - see ' + $MsiLog + ')'); $lpFailed = $true
    }elseif($r.ExitCode -eq 1638 -or $r.ExitCode -eq 1605){
      Write-YcLog ('msiexec returned ' + $r.ExitCode + ' (' + $r.Meaning + ') - verifying the EXISTING Log Parser install instead') 'WARN'
      $skipped += 'logparser (already installed at this or another version)'
    }elseif(-not $r.Success){
      $failedT += ('logparser (msiexec exit ' + $r.ExitCode + ': ' + $r.Meaning + ' - see ' + $MsiLog + ')'); $lpFailed = $true
    }else{
      $installed += 'logparser'
    }
  }
}

# PROOF: the binary exists and the BINARY says which version it is.
if(-not $lpFailed){
  $logparser = Find-YcTool -Candidates $lpPaths -OnPath 'logparser'
  if(-not $logparser){
    if($lpStaged){
      Write-YcLog ('LogParser.exe cannot be found after the install. Log Parser is NOT usable. Searched: ' + ($lpPaths -join '; ') + ' and PATH.') 'ERROR'
      $failedT += 'logparser (LogParser.exe not found after install)'
    }
  }elseif(Assert-YcFile -Path $logparser -MinBytes 100KB -Because 'LogParser.exe'){
    $ver = ''
    try{ $ver = [string](Get-Item -LiteralPath $logparser -ErrorAction Stop).VersionInfo.FileVersion }catch{ $ver = '' }
    if($ver){
      Write-YcLog ('Log Parser VERIFIED: ' + $logparser + ' FileVersion ' + $ver) 'OK'
      $verified += ('logparser ' + $ver)
    }else{
      Write-YcLog ('LogParser.exe exists at ' + $logparser + ' but carries no FileVersion - the package is not the Microsoft build') 'ERROR'
      $failedT += 'logparser (no FileVersion on the binary)'
    }
  }else{
    $failedT += 'logparser (LogParser.exe is present but unusable)'
  }
}

# -------------------------------------------------------------------------------------
# 3. Portable tools - nothing to install, everything to verify.
# -------------------------------------------------------------------------------------
foreach($tool in @('testdisk.exe','photorec.exe','iperf3.exe')){
  $hit = @(Get-ChildItem -Path $ToolsDir -Filter $tool -Recurse -File -ErrorAction Ignore | Select-Object -First 1)
  if($hit.Count -eq 1 -and (Assert-YcFile -Path $hit[0].FullName -MinBytes 10KB -Because ('portable tool ' + $tool))){
    $verified += ($tool + ' (portable)')
  }else{
    Write-YcLog ('portable tool ' + $tool + ' is NOT under ' + $ToolsDir + ' - the staged payload is incomplete for that tool') 'WARN'
    $skipped += ($tool + ' (not staged)')
  }
}

$summary = ('installed: ' + $(if($installed.Count){($installed -join ', ')}else{'nothing (all present already or nothing staged)'}) +
            ' | verified: ' + $(if($verified.Count){($verified -join ', ')}else{'NOTHING'}) +
            ' | skipped: ' + $(if($skipped.Count){($skipped -join ', ')}else{'none'}) +
            ' | failed: ' + $(if($failedT.Count){($failedT -join '; ')}else{'none'}))

if($failedT.Count -gt 0){
  Exit-Yc 1 ('diagtools-install FAILED for ' + [string]$failedT.Count + ' tool(s). ' + $summary) 'ERROR'
}
# "nothing was staged, nothing was installed, nothing was verified" is the quiet non-event this
# programme exists to stop being reported as success.
if($verified.Count -eq 0){
  Exit-Yc 1 ('nothing could be verified: ' + $ToolsDir + ' holds no recognised staged tool ' +
    '(expected smartmontools*.exe, LogParser*.msi, testdisk.exe, photorec.exe, iperf3.exe) and ' +
    'none of these tools is already installed. ' + $summary) 'ERROR'
}
Exit-Yc 0 ('diagtools-install complete. ' + $summary) 'OK'
