param(
  # ---- names preserved from webjea-install.cmd and the catalog ----
  [string]$SiteName   = 'WebJEA',                    # IIS site name
  [int]$Port          = 8443,                        # HTTPS listen port (inbound rule added, SCOPED)
  [string]$InstallDir = 'C:\inetpub\WebJEA',         # web site physical path
  [string]$ScriptsDir = 'C:\WebJEA\scripts',         # folder that holds the published PowerShell scripts
  # ---- ADDED in this revision - the first three are MANDATORY ----
  [switch]$IUnderstandTheRisk,                       # required: see the risk statement below
  [string]$CertificateThumbprint,                    # required: LocalMachine\My thumbprint for the HTTPS binding
  [string[]]$MgmtCidr,                               # required: the ONLY addresses the inbound rule allows
  [string]$ServiceAccount,                           # gMSA (DOMAIN\name$) or service account for the app pool
  [string]$ZipPath,                                  # explicit WebJEA release zip
  [string]$SettingsFile,                             # a settings.jsonc you have already prepared
  [switch]$AllowSelfSignedCert,                      # accept an untrusted cert during the local verification GET
  [switch]$NoFirewall,
  [switch]$Help
)
# =====================================================================================
# WebJEA-Install.ps1 - deploy WebJEA (an IIS web front end that RUNS POWERSHELL SCRIPTS).
# PowerShell 5.1, ASCII only.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P0-8] THIS SCRIPT STOOD UP AN UNAUTHENTICATED, CLEARTEXT, REMOTE POWERSHELL CONSOLE.
#   Old line 73: New-Website ... -Port $Port  - an HTTP binding. No -Ssl, no certificate.
#   Old line 48: the IIS feature list omitted Web-Windows-Auth, so Windows Authentication
#                was not even INSTALLABLE and IIS fell back to Anonymous.
#   Old lines 70-71: the app pool was left as ApplicationPoolIdentity with no guidance.
#   Old lines 77-81: New-NetFirewallRule -Profile Any, no -RemoteAddress.
#   Net effect: a web UI whose entire purpose is executing PowerShell, served in the clear,
#   to anyone who could reach the port, with no authentication at all. Every parameter of
#   every published script - including anything the operator typed into a form - crossed
#   the wire in plaintext. This is the single most severe finding in the toolkit.
#   Old line 12 also globbed C:\Scripts\webjea-*.zip, which nothing in this payload stages,
#   and old line 56 required a site\ folder that the WebJEA release does not contain - so
#   even when it "worked" it deployed nothing. It was a security hole that did not function.
#   NOW:
#     * The command REFUSES to run without -IUnderstandTheRisk, -CertificateThumbprint and
#       -MgmtCidr. There is no default that produces a listening service.
#     * Web-Windows-Auth is installed; Windows Authentication is ENABLED and Anonymous
#       Authentication is DISABLED, both verified by reading the IIS configuration back.
#     * HTTPS only: any http binding on the site is REMOVED, and an https binding carrying
#       -CertificateThumbprint must exist before the script will report success.
#     * The vendor's own Deploy.ps1 is run (see below) instead of hand-rolling a site.
#     * The inbound rule is -Profile Domain,Private, -RemoteAddress <MgmtCidr>, created LAST.
#     * Verification is an ANONYMOUS GET that MUST be rejected (401/403) plus an
#       authenticated GET. If anonymous access is not rejected, the script fails and the
#       firewall rule is not created.
#
# ----------------------------- IS THIS SAFE TO SHIP? ---------------------------------
# NO - not as an enabled component of a tenant-facing golden image. The upstream project
# is clear about what it requires, and a stock YallaCloud KVM tenant VM meets none of it:
#   * "Authentication still requires Windows Integrated Auth, so domain joined"
#     -> a workgroup tenant VM can only authenticate LOCAL accounts over NTLM. There is no
#        AD group to authorise against, which is WebJEA's entire access-control model.
#   * "Scripts run in the context of the App Pool" and "Don't configure the MSA as a local
#     administrator on the server" -> every published script runs with the app pool
#     identity's rights, so the blast radius of one bad script is that account.
#   * "By default, local administrators of the machine have access to all pages."
#     -> on a fresh image that is the tenant's own admin, which is the intended state; but
#        combined with an HTTP binding and Anonymous auth (the old behaviour) it was RCE.
#   * Deploy.ps1 uses Invoke-DscResource, warns about LCM state, and the documented install
#     needs a REBOOT and a SECOND run to complete.
#   Sources: https://github.com/markdomansky/WebJEA/wiki/Installation
#            https://github.com/markdomansky/WebJEA/blob/master/readme.md
# THEREFORE: this command is gated behind -IUnderstandTheRisk and must never be run from
# the unattended image build. It is an operator-invoked, domain-joined, management-network
# deployment tool. The .cmd wrapper carries the same warning.
#
# EXTERNAL COMMAND LINES EMITTED BY THIS SCRIPT (all vendor-documented):
#   Install-WindowsFeature Web-Server, Web-Windows-Auth, Web-Asp-Net45, ...
#     https://learn.microsoft.com/en-us/iis/install/installing-iis-85/installing-iis-85-on-windows-server-2012-r2
#   powershell.exe -File <release>\Deploy.ps1 -settingsfile <settings.jsonc>
#     https://github.com/markdomansky/WebJEA/wiki/Installation
#   appcmd.exe set config "<site>" -section:system.webServer/security/authentication/windowsAuthentication /enabled:"True"  /commit:apphost
#   appcmd.exe set config "<site>" -section:system.webServer/security/authentication/anonymousAuthentication /enabled:"False" /commit:apphost
#     https://learn.microsoft.com/en-us/iis/configuration/system.webserver/security/authentication/windowsauthentication/
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was installed. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'webjea-install'

$Usage = @'
webjea-install - deploy WebJEA, an IIS web front end that RUNS POWERSHELL SCRIPTS.
                 Staged release: C:\Scripts\WebJEA*.zip   Log: C:\Scripts\webjea-install.log

READ THIS BEFORE YOU RUN IT
  WebJEA publishes PowerShell scripts as web forms and runs them as the IIS app pool
  identity. Anyone who can reach the site and authenticate can run those scripts. The
  previous version of this command served that over PLAIN HTTP with NO AUTHENTICATION and
  opened the port on every firewall profile. It is now impossible to reproduce that:
    - -IUnderstandTheRisk is mandatory.
    - -CertificateThumbprint is mandatory. There is no HTTP binding, ever.
    - -MgmtCidr is mandatory. The inbound rule is scoped to it, on Domain+Private only.
    - Windows Authentication is enabled and Anonymous is disabled, both verified.
    - An anonymous GET must be REJECTED before this command reports success.
  Upstream requires a DOMAIN JOINED server (Windows Integrated Auth is the only tested
  authentication method) and recommends a gMSA for the app pool. Do NOT enable this in a
  tenant-facing golden image; it is an operator tool for a management network.

USAGE:
  webjea-install -IUnderstandTheRisk -CertificateThumbprint <thumbprint> -MgmtCidr <cidr[,cidr]>
                 [-ServiceAccount DOMAIN\gmsa$] [-SiteName WebJEA] [-Port 8443]
                 [-InstallDir C:\inetpub\WebJEA] [-ScriptsDir C:\WebJEA\scripts]
                 [-ZipPath <zip>] [-SettingsFile <settings.jsonc>] [-AllowSelfSignedCert] [-NoFirewall]
  webjea-install -Help

PARAMETERS:
  -IUnderstandTheRisk   MANDATORY. Acknowledges that this publishes PowerShell execution
                        over the network. Without it the command refuses and changes nothing.
  -CertificateThumbprint MANDATORY. Thumbprint of a certificate in LocalMachine\My, with a
                        private key. Used for the HTTPS binding. No certificate, no service.
  -MgmtCidr             MANDATORY. Management network(s) allowed to reach the site, e.g.
                        10.20.0.0/24. Used as -RemoteAddress on the inbound rule.
  -ServiceAccount       gMSA (DOMAIN\name$) or service account for the app pool. Strongly
                        recommended by upstream; it must NOT be a local administrator.
  -SiteName             IIS site name (default WebJEA). 2026+ releases deploy at the site root.
  -Port                 HTTPS port (default 8443). If the vendor deployment binds a different
                        port, the rule follows the port that actually got bound.
  -InstallDir           Physical path for the web site files (default C:\inetpub\WebJEA).
  -ScriptsDir           Folder for the published PowerShell scripts (default C:\WebJEA\scripts).
  -ZipPath              Explicit WebJEA release zip. Default: the newest C:\Scripts\WebJEA*.zip
                        (the old code globbed webjea-*.zip, which nothing stages).
  -SettingsFile         A settings.jsonc you have already prepared. Otherwise this command
                        copies settings.template.jsonc and injects the thumbprint/account.
  -AllowSelfSignedCert  Accept an untrusted certificate during the LOCAL verification GET only.
  -NoFirewall           Create no firewall rule at all.
  -Help                 Show this help and exit.

PROOF OF SUCCESS (nothing below is assumed):
  the vendor Deploy.ps1 exit code + the site exists + it has an https binding carrying
  -CertificateThumbprint + it has NO http binding + anonymousAuthentication reads back
  false + windowsAuthentication reads back true + an ANONYMOUS GET is rejected 401/403.
  Only then is the scoped inbound rule created.

EXAMPLES:
  webjea-install -IUnderstandTheRisk -CertificateThumbprint 9A3F...C1 -MgmtCidr 10.20.0.0/24
  webjea-install -IUnderstandTheRisk -CertificateThumbprint 9A3F...C1 -MgmtCidr 10.20.0.0/24 -ServiceAccount CONTOSO\svc-webjea$
  webjea-install -IUnderstandTheRisk -CertificateThumbprint 9A3F...C1 -MgmtCidr 10.20.0.0/24,10.20.1.0/24 -Port 443
  webjea-install -IUnderstandTheRisk -CertificateThumbprint 9A3F...C1 -MgmtCidr 10.20.0.0/24 -SettingsFile C:\Scripts\webjea-settings.jsonc
  webjea-install -Help

EXIT CODES:
  0   WebJEA deployed over HTTPS, anonymous access proven rejected, rule scoped to -MgmtCidr
  1   generic failure
  2   usage error / refused (missing -IUnderstandTheRisk, certificate or -MgmtCidr)
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4   release zip missing, or it is not a WebJEA release (no Deploy.ps1 inside)
  5   not running as Administrator
  8   the site does not answer, or ANONYMOUS ACCESS WAS NOT REJECTED
  10  the vendor Deploy.ps1 did not finish within its timeout and was killed
  11  a required IIS feature could not be installed
  15  no usable certificate for -CertificateThumbprint
  16  the site has no HTTPS binding with that certificate after deployment
  <n> any other value is Deploy.ps1's own exit code

Log: C:\Scripts\webjea-install.log   (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

# ------------------------------------------------------------------------------------
# REFUSALS. All of them happen before anything on this machine is touched.
# ------------------------------------------------------------------------------------
if(-not $IUnderstandTheRisk){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 ('REFUSED: -IUnderstandTheRisk was not given. WebJEA publishes PowerShell script execution as web forms, running as the IIS app pool identity. Upstream supports Windows Integrated Auth ONLY and expects a domain-joined server with a gMSA; a workgroup tenant VM cannot satisfy that. This command must not be part of an unattended image build. Nothing was changed.') 'ERROR'
}
if(-not $CertificateThumbprint){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 ('REFUSED: -CertificateThumbprint is required. This command will not create an HTTP binding under any circumstances - the previous version did, and served an unauthenticated PowerShell console in cleartext. Nothing was changed.') 'ERROR'
}
if(-not $MgmtCidr -or $MgmtCidr.Count -eq 0){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 ('REFUSED: -MgmtCidr is required. The inbound rule is scoped to it; there is no "open to everyone" mode any more. Nothing was changed.') 'ERROR'
}
$Cidrs = @()
foreach($c in $MgmtCidr){
  foreach($p in ([string]$c -split ',')){
    $t = $p.Trim()
    if($t){ $Cidrs += $t }
  }
}
foreach($c in $Cidrs){
  if($c -eq 'Any' -or $c -eq '*' -or $c -eq '0.0.0.0/0' -or $c -eq '0.0.0.0'){
    Exit-Yc 2 ('REFUSED: -MgmtCidr contains "' + $c + '", which is the whole internet. Name your management network. Nothing was changed.') 'ERROR'
  }
}
if($Port -lt 1 -or $Port -gt 65535){ Exit-Yc 2 ('-Port out of range: ' + $Port) 'ERROR' }

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

$domainJoined = $false
try{ $domainJoined = [bool](Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop).PartOfDomain }catch{}
if(-not $domainJoined){
  Write-YcLog 'THIS HOST IS NOT DOMAIN JOINED. WebJEA authenticates with Windows Integrated Auth and authorises against AD groups; on a workgroup host only LOCAL accounts can log in and AD group authorisation is unavailable. Upstream states domain join is required. Continuing because -IUnderstandTheRisk was given, but this is not a supported configuration.' 'WARN'
}
if(-not $ServiceAccount){
  Write-YcLog 'no -ServiceAccount was given: the app pool will run as whatever the vendor deployment configures (ApplicationPoolIdentity by default). Every published script then runs with that identity. Upstream strongly recommends a gMSA that is NOT a local administrator.' 'WARN'
}

# ------------------------------------------------------------------------------------
# 1. The certificate has to be real before anything else happens.
# ------------------------------------------------------------------------------------
$thumb = ($CertificateThumbprint -replace '[^0-9A-Fa-f]','').ToUpperInvariant()
$cert  = $null
try{ $cert = Get-Item -LiteralPath ('Cert:\LocalMachine\My\' + $thumb) -ErrorAction Stop }catch{}
if(-not $cert){
  Exit-Yc 15 ('no certificate with thumbprint ' + $thumb + ' in Cert:\LocalMachine\My. Install the certificate (with its private key) first. Nothing was changed.') 'ERROR'
}
if(-not $cert.HasPrivateKey){
  Exit-Yc 15 ('the certificate ' + $thumb + ' has NO PRIVATE KEY, so it cannot terminate TLS. Nothing was changed.') 'ERROR'
}
if($cert.NotAfter -lt (Get-Date)){
  Exit-Yc 15 ('the certificate ' + $thumb + ' EXPIRED on ' + $cert.NotAfter + '. Nothing was changed.') 'ERROR'
}
$certCn = ''
try{ $certCn = [string]$cert.GetNameInfo([System.Security.Cryptography.X509Certificates.X509NameType]::DnsName,$false) }catch{}
Write-YcLog ('certificate OK: subject "' + $cert.Subject + '" dns "' + $certCn + '" expires ' + $cert.NotAfter) 'OK'

# ------------------------------------------------------------------------------------
# 2. Locate the vendor release and find ITS Deploy.ps1.
#    The old code looked for a site\ folder that the WebJEA release does not contain.
# ------------------------------------------------------------------------------------
$zip = ''
if($ZipPath){
  $zip = $ZipPath
}else{
  $cands = @(Get-ChildItem -Path 'C:\Scripts\*.zip' -ErrorAction SilentlyContinue |
             Where-Object { -not $_.PSIsContainer -and $_.Name -match '(?i)webjea' } |
             Sort-Object LastWriteTime -Descending)
  if($cands.Count -gt 0){ $zip = $cands[0].FullName }
}
if(-not $zip){
  Exit-Yc 4 'no WebJEA release found. Stage the release zip from https://github.com/markdomansky/WebJEA/releases into C:\Scripts (any name containing "WebJEA"), or pass -ZipPath. Nothing was changed.' 'ERROR'
}
if(-not (Assert-YcFile -Path $zip -MinBytes 100KB -Because 'WebJEA release zip')){
  Exit-Yc 4 ('unusable WebJEA release zip: ' + $zip) 'ERROR'
}

$tmp = Join-Path $env:TEMP ('webjea_' + [guid]::NewGuid().ToString('N'))
try{
  New-Item -ItemType Directory -Path $tmp -Force -ErrorAction Stop | Out-Null
  Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force -ErrorAction Stop
}catch{
  Exit-Yc 4 ('could not expand ' + $zip + ': ' + $_.Exception.Message) 'ERROR'
}
$deploy = @(Get-ChildItem -Path $tmp -Recurse -Filter 'Deploy.ps1' -ErrorAction SilentlyContinue | Select-Object -First 1)
if($deploy.Count -eq 0){
  Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
  Exit-Yc 4 ('this archive contains no Deploy.ps1, so it is not a WebJEA release: ' + $zip + '. (The old script instead required a site\ folder, which the WebJEA release has never had - which is why it could never actually deploy WebJEA.) Nothing was changed.') 'ERROR'
}
$deployPs1 = $deploy[0].FullName
$relRoot   = Split-Path -Parent $deployPs1
Write-YcLog ('WebJEA release expanded to ' + $relRoot + '; vendor deployment script: ' + $deployPs1) 'OK'

# ------------------------------------------------------------------------------------
# 3. IIS features INCLUDING Web-Windows-Auth. Failures are reported, not swallowed.
# ------------------------------------------------------------------------------------
$feats = @('Web-Server','Web-Windows-Auth','Web-Asp-Net45','Web-Net-Ext45','Web-ISAPI-Ext',
           'Web-ISAPI-Filter','Web-Mgmt-Console','Web-Scripting-Tools','NET-Framework-45-ASPNET')
$critical = @('Web-Server','Web-Windows-Auth','Web-Asp-Net45')
$failed = @()
if(Get-Command -Name 'Install-WindowsFeature' -ErrorAction SilentlyContinue){
  foreach($f in $feats){
    try{
      $r = Install-WindowsFeature -Name $f -ErrorAction Stop
      if($r -and -not $r.Success){ $failed += $f }
    }catch{
      $failed += $f
      Write-YcLog ('Install-WindowsFeature ' + $f + ' failed: ' + $_.Exception.Message) 'WARN'
    }
  }
}else{
  Write-YcLog 'Install-WindowsFeature is not available (client OS) - enable the IIS features, INCLUDING Windows Authentication (IIS-WindowsAuthentication), by hand' 'WARN'
}
foreach($c in $critical){
  if($failed -contains $c){
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Exit-Yc 11 ('the required IIS feature ' + $c + ' could not be installed. Web-Windows-Auth in particular is what the old script omitted, which is why IIS fell back to Anonymous. Nothing was deployed.') 'ERROR'
  }
}
Write-YcLog ('IIS features present (including Web-Windows-Auth)' + $(if($failed.Count -gt 0){'; non-critical failures: ' + ($failed -join ', ')}else{''})) 'OK'

# ------------------------------------------------------------------------------------
# 4. settings.jsonc, then the VENDOR's Deploy.ps1. We do not hand-roll a site any more.
# ------------------------------------------------------------------------------------
$settings = ''
if($SettingsFile){
  if(-not (Test-Path -LiteralPath $SettingsFile)){
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Exit-Yc 2 ('-SettingsFile not found: ' + $SettingsFile) 'ERROR'
  }
  $settings = $SettingsFile
}else{
  $tpl = @(Get-ChildItem -Path $relRoot -Recurse -Filter 'settings.template.jsonc' -ErrorAction SilentlyContinue | Select-Object -First 1)
  if($tpl.Count -eq 0){
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Exit-Yc 4 ('the release contains no settings.template.jsonc, so this command cannot generate a settings file. Prepare one by hand and pass -SettingsFile. Vendor instructions: https://github.com/markdomansky/WebJEA/wiki/Installation') 'ERROR'
  }
  $settings = Join-Path $relRoot 'settings.jsonc'
  try{ Copy-Item -LiteralPath $tpl[0].FullName -Destination $settings -Force -ErrorAction Stop }
  catch{
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Exit-Yc 1 ('could not copy settings.template.jsonc: ' + $_.Exception.Message) 'ERROR'
  }
  # Inject the thumbprint and the service account. jsonc has comments, so ConvertFrom-Json
  # is not safe here; the values are replaced textually and the result is read back.
  $txt = ''
  try{ $txt = [string](Get-Content -LiteralPath $settings -Raw -ErrorAction Stop) }catch{}
  $before = $txt
  # MatchEvaluator, NOT a replacement string: a gMSA name ends in '$' (DOMAIN\gmsa$) and a
  # thumbprint or account can contain any character that .NET would read as a substitution
  # ($1, ${3}, $$ ...). Evaluators are not parsed, so the value lands verbatim.
  $thumbValue = $thumb
  $txt = [regex]::Replace($txt,'(?im)("[^"]*thumbprint[^"]*"\s*:\s*")([^"]*)(")',
            { param($m) $m.Groups[1].Value + $thumbValue + $m.Groups[3].Value })
  if($ServiceAccount){
    # Backslashes must survive into JSON as \\ .
    $acctValue = $ServiceAccount -replace '\\','\\'
    $txt = [regex]::Replace($txt,'(?im)("[^"]*(?:serviceaccount|apppooluser|username|account)[^"]*"\s*:\s*")([^"]*)(")',
              { param($m) $m.Groups[1].Value + $acctValue + $m.Groups[3].Value })
  }
  if($txt -eq $before){
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Exit-Yc 2 ('settings.template.jsonc does not contain a recognisable thumbprint key, so this command will not guess. Prepare settings.jsonc by hand (copy settings.template.jsonc, set the certificate thumbprint and the service account) and re-run with -SettingsFile. Nothing was deployed.') 'ERROR'
  }
  try{ Set-Content -LiteralPath $settings -Value $txt -Encoding ascii -ErrorAction Stop }
  catch{
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Exit-Yc 1 ('could not write ' + $settings + ': ' + $_.Exception.Message) 'ERROR'
  }
  $check = [string](Get-Content -LiteralPath $settings -Raw -ErrorAction SilentlyContinue)
  if($check -notmatch [regex]::Escape($thumb)){
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Exit-Yc 1 'the certificate thumbprint did not survive being written into settings.jsonc.' 'ERROR'
  }
  Write-YcLog ('settings.jsonc generated from the vendor template with thumbprint ' + $thumb + $(if($ServiceAccount){' and service account ' + $ServiceAccount}else{''})) 'OK'
}

Write-YcLog ('running the vendor deployment: ' + $deployPs1 + ' -settingsfile ' + $settings)
$dep = Invoke-YcInstaller -FilePath 'powershell.exe' `
        -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $deployPs1 + '"'),'-settingsfile',('"' + $settings + '"')) `
        -SuccessCodes @(0) -RebootCodes @(3010,1641) -TimeoutSec 3600 -WorkingDirectory $relRoot
if($dep.TimedOut){
  Exit-Yc 10 'the vendor Deploy.ps1 did not finish within 3600s and was killed. No firewall rule was created.' 'ERROR'
}
if(-not $dep.Success){
  $code = $dep.ExitCode
  if($code -eq 0){ $code = 1 }
  Write-YcLog ('Deploy.ps1 returned ' + $dep.ExitCode + '. Upstream documents an ordering issue that needs a REBOOT and a second run of Deploy.ps1; if this is the first run, reboot and re-run this command.') 'WARN'
  Exit-Yc $code ('the WebJEA vendor deployment FAILED (' + $dep.Meaning + '). Nothing was opened in the firewall.') 'ERROR'
}
if($dep.RebootRequired){ Write-YcLog 'the deployment reports a reboot is required; upstream also documents re-running Deploy.ps1 after that reboot' 'WARN' }

# ------------------------------------------------------------------------------------
# 5. Lock the site down and PROVE it. The vendor script configures a lot of this; this
#    section does not trust that it did.
# ------------------------------------------------------------------------------------
Import-Module WebAdministration -ErrorAction SilentlyContinue
$site = $null
try{ $site = Get-Website -Name $SiteName -ErrorAction SilentlyContinue }catch{}
if(-not $site){
  # 2026+ releases create the site at the root; it may not carry our -SiteName.
  $all = @(Get-Website -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '(?i)webjea' })
  if($all.Count -gt 0){
    $site = $all[0]
    Write-YcLog ('the deployment created the site as "' + $site.Name + '", not "' + $SiteName + '" - following the site that actually exists') 'WARN'
    $SiteName = [string]$site.Name
  }
}
if(-not $site){
  Exit-Yc 16 ('Deploy.ps1 returned success but no WebJEA IIS site exists. Nothing was opened in the firewall.') 'ERROR'
}

# HTTP bindings are removed outright. There is no cleartext path to this site.
$httpRemoved = 0
try{
  foreach($b in @(Get-WebBinding -Name $SiteName -ErrorAction SilentlyContinue)){
    if([string]$b.protocol -eq 'http'){
      Remove-WebBinding -Name $SiteName -Protocol 'http' -BindingInformation ([string]$b.bindingInformation) -ErrorAction Stop
      $httpRemoved++
    }
  }
}catch{
  Write-YcLog ('could not remove an http binding: ' + $_.Exception.Message) 'WARN'
}
if($httpRemoved -gt 0){ Write-YcLog ('removed ' + $httpRemoved + ' cleartext HTTP binding(s) from ' + $SiteName) 'OK' }

# Ensure an https binding on -Port carrying our certificate.
$httpsPort = 0
$boundThumb = ''
try{
  foreach($b in @(Get-WebBinding -Name $SiteName -ErrorAction SilentlyContinue)){
    if([string]$b.protocol -ne 'https'){ continue }
    $bi = [string]$b.bindingInformation
    $pp = 0
    if($bi -match '^[^:]*:(\d+):'){ $pp = [int]$Matches[1] }
    $th = ''
    try{ if($b.certificateHash){ $th = (($b.certificateHash | ForEach-Object { '{0:X2}' -f $_ }) -join '') } }catch{}
    if(-not $th){ try{ $th = ([string]$b.certificateHash).ToUpperInvariant() }catch{} }
    if($pp -gt 0 -and ($httpsPort -eq 0 -or $pp -eq $Port)){ $httpsPort = $pp; $boundThumb = $th }
  }
}catch{
  Write-YcLog ('could not enumerate the site bindings: ' + $_.Exception.Message) 'WARN'
}

if($httpsPort -eq 0){
  Write-YcLog ('no https binding on ' + $SiteName + ' after the vendor deployment - creating one on port ' + $Port + ' with certificate ' + $thumb) 'WARN'
  try{
    New-WebBinding -Name $SiteName -Protocol 'https' -Port $Port -IPAddress '*' -ErrorAction Stop
    $nb = Get-WebBinding -Name $SiteName -Protocol 'https' -Port $Port -ErrorAction Stop
    $nb.AddSslCertificate($thumb,'My')
    $httpsPort  = $Port
    $boundThumb = $thumb
    Write-YcLog ('https binding created on port ' + $Port) 'OK'
  }catch{
    Exit-Yc 16 ('could not create an HTTPS binding on port ' + $Port + ': ' + $_.Exception.Message + '. This command will not fall back to HTTP. Nothing was opened in the firewall.') 'ERROR'
  }
}
if($boundThumb -and ($boundThumb.ToUpperInvariant() -ne $thumb)){
  Write-YcLog ('the https binding on port ' + $httpsPort + ' uses certificate ' + $boundThumb + ', not the -CertificateThumbprint you supplied (' + $thumb + '). The vendor settings file wins; verify that is what you intended.') 'WARN'
}
if($httpsPort -ne $Port){
  Write-YcLog ('the deployment bound HTTPS on port ' + $httpsPort + ', not -Port ' + $Port + '. The firewall rule will follow the port that is actually bound.') 'WARN'
}

# Authentication: Windows ON, Anonymous OFF, then read both back.
$appcmd = Join-Path $env:windir 'system32\inetsrv\appcmd.exe'
$authOk = $false
if(Test-Path -LiteralPath $appcmd){
  try{
    & $appcmd set config $SiteName '-section:system.webServer/security/authentication/windowsAuthentication' '/enabled:True' '/commit:apphost' 2>&1 | Out-Null
    & $appcmd set config $SiteName '-section:system.webServer/security/authentication/anonymousAuthentication' '/enabled:False' '/commit:apphost' 2>&1 | Out-Null
    $winCfg = (& $appcmd list config $SiteName '-section:system.webServer/security/authentication/windowsAuthentication' 2>&1 | Out-String)
    $anonCfg = (& $appcmd list config $SiteName '-section:system.webServer/security/authentication/anonymousAuthentication' 2>&1 | Out-String)
    $winOn  = ($winCfg  -match '(?i)windowsAuthentication\s+enabled="true"')
    $anonOff= ($anonCfg -match '(?i)anonymousAuthentication\s+enabled="false"')
    if($winOn -and $anonOff){ $authOk = $true }
    Write-YcLog ('IIS authentication readback: windowsAuthentication enabled=' + $winOn + ', anonymousAuthentication enabled=' + (-not $anonOff))
  }catch{
    Write-YcLog ('appcmd failed: ' + $_.Exception.Message) 'WARN'
  }
}else{
  Write-YcLog ('appcmd.exe not found at ' + $appcmd + ' - falling back to Set-WebConfigurationProperty') 'WARN'
}
if(-not $authOk){
  try{
    Set-WebConfigurationProperty -Filter '/system.webServer/security/authentication/windowsAuthentication' -Name 'enabled' -Value $true  -PSPath 'MACHINE/WEBROOT/APPHOST' -Location $SiteName -ErrorAction Stop
    Set-WebConfigurationProperty -Filter '/system.webServer/security/authentication/anonymousAuthentication' -Name 'enabled' -Value $false -PSPath 'MACHINE/WEBROOT/APPHOST' -Location $SiteName -ErrorAction Stop
    $w = Get-WebConfigurationProperty -Filter '/system.webServer/security/authentication/windowsAuthentication' -Name 'enabled' -PSPath 'MACHINE/WEBROOT/APPHOST' -Location $SiteName -ErrorAction Stop
    $a = Get-WebConfigurationProperty -Filter '/system.webServer/security/authentication/anonymousAuthentication' -Name 'enabled' -PSPath 'MACHINE/WEBROOT/APPHOST' -Location $SiteName -ErrorAction Stop
    if([bool]$w.Value -and -not [bool]$a.Value){ $authOk = $true }
    Write-YcLog ('IIS authentication readback (WebAdministration): windows=' + [bool]$w.Value + ' anonymous=' + [bool]$a.Value)
  }catch{
    Write-YcLog ('could not configure IIS authentication: ' + $_.Exception.Message) 'ERROR'
  }
}
if(-not $authOk){
  Exit-Yc 8 'Windows Authentication could not be proven ON and Anonymous Authentication proven OFF. This command will not publish an unauthenticated PowerShell console. Nothing was opened in the firewall.' 'ERROR'
}

try{ Start-Website -Name $SiteName -ErrorAction SilentlyContinue }catch{}
if($ScriptsDir -and -not (Test-Path -LiteralPath $ScriptsDir)){
  try{ New-Item -ItemType Directory -Path $ScriptsDir -Force -ErrorAction Stop | Out-Null }catch{}
}

# ------------------------------------------------------------------------------------
# 6. THE PROOF THAT MATTERS: an ANONYMOUS request must be REJECTED.
# ------------------------------------------------------------------------------------
$verifyHost = 'localhost'
if($certCn){
  try{
    $r = [Net.Dns]::GetHostAddresses($certCn)
    if($r){ $verifyHost = $certCn }
  }catch{}
}
$url = 'https://' + $verifyHost + ':' + $httpsPort + '/'
$prevCallback = [Net.ServicePointManager]::ServerCertificateValidationCallback
if($AllowSelfSignedCert -or $verifyHost -eq 'localhost'){
  Write-YcLog 'certificate validation is relaxed for the LOCAL verification GET only (the check being made is about authentication, not trust)' 'WARN'
  [Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
}
Set-YcTls

$anonStatus = 0
$anonErr    = ''
for($i=0; $i -lt 10; $i++){
  try{
    $resp = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 20 -ErrorAction Stop
    $anonStatus = [int]$resp.StatusCode
    break
  }catch{
    $anonErr = $_.Exception.Message
    try{
      $r2 = $_.Exception.Response
      if($r2){ $anonStatus = [int]$r2.StatusCode }
    }catch{}
    if($anonStatus -gt 0){ break }
  }
  Start-Sleep -Seconds 3
}

$authStatus = 0
try{
  $resp2 = Invoke-WebRequest -Uri $url -UseBasicParsing -UseDefaultCredentials -TimeoutSec 20 -ErrorAction Stop
  $authStatus = [int]$resp2.StatusCode
}catch{
  try{
    $r3 = $_.Exception.Response
    if($r3){ $authStatus = [int]$r3.StatusCode }
  }catch{}
}
[Net.ServicePointManager]::ServerCertificateValidationCallback = $prevCallback

Write-YcLog ('verification GET ' + $url + ' : anonymous -> ' + $(if($anonStatus){$anonStatus}else{'no response (' + $anonErr + ')'}) + ', authenticated (this process identity) -> ' + $(if($authStatus){$authStatus}else{'no response'}))

if($anonStatus -eq 200){
  Exit-Yc 8 ('ANONYMOUS ACCESS IS NOT REJECTED: ' + $url + ' answered 200 with no credentials. That is precisely the defect this rewrite exists to eliminate - a PowerShell execution UI open to anyone who can reach the port. NO firewall rule was created; fix the site authentication before exposing it.') 'ERROR'
}
if($anonStatus -eq 0){
  Exit-Yc 8 ('the site did not answer at ' + $url + ' (' + $anonErr + '). Upstream documents an ordering issue: REBOOT and run this command again. NO firewall rule was created.') 'ERROR'
}
if($anonStatus -ne 401 -and $anonStatus -ne 403){
  Write-YcLog ('the anonymous request returned ' + $anonStatus + ' rather than 401/403. It was not served content, but check the site configuration.') 'WARN'
}else{
  Write-YcLog ('anonymous access is REJECTED (' + $anonStatus + ') - Windows Authentication is enforced') 'OK'
}
if($authStatus -eq 200){ Write-YcLog 'an authenticated request is served (200)' 'OK' }
else{ Write-YcLog ('the authenticated request returned ' + $authStatus + '. This command runs as the machine/SYSTEM identity, which WebJEA is not expected to authorise; that is normal. Log in from a management workstation with an authorised account to confirm.') 'WARN' }

# ------------------------------------------------------------------------------------
# 7. Firewall LAST, scoped, Domain+Private only.
# ------------------------------------------------------------------------------------
if($NoFirewall){
  Write-YcLog '-NoFirewall: no firewall rule was created. The site is only reachable if an existing rule already allows it.'
}else{
  $rn = 'WebJEA https in ' + $httpsPort
  try{
    foreach($old in @('WebJEA in ' + $Port, 'WebJEA in ' + $httpsPort, $rn)){
      $ex = Get-NetFirewallRule -DisplayName $old -ErrorAction SilentlyContinue
      if($ex){
        Remove-NetFirewallRule -DisplayName $old -ErrorAction Stop
        Write-YcLog ('removed the previous rule "' + $old + '" (the old version created it on -Profile Any with no -RemoteAddress)') 'WARN'
      }
    }
    New-NetFirewallRule -DisplayName $rn -Direction Inbound -Action Allow -Protocol TCP `
                        -LocalPort $httpsPort -RemoteAddress $Cidrs -Profile Domain,Private -ErrorAction Stop | Out-Null
    Write-YcLog ('inbound allow TCP ' + $httpsPort + ' scoped to ' + ($Cidrs -join ',') + ' on the Domain and Private profiles ONLY (rule "' + $rn + '")') 'OK'
  }catch{
    Exit-Yc 1 ('WebJEA is deployed but the SCOPED firewall rule could not be created: ' + $_.Exception.Message + '. Do not replace it with an unscoped rule.') 'ERROR'
  }
}

Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
Exit-Yc 0 ('WebJEA is deployed on https://' + $verifyHost + ':' + $httpsPort + '/ - HTTPS only, Windows Authentication enforced, anonymous access proven rejected (' + $anonStatus + '), inbound scoped to ' + ($Cidrs -join ',') + '. Publish scripts into ' + $ScriptsDir + ' and remember that every one of them runs as the app pool identity.') 'OK'
