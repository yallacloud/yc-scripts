# _yc-lib.ps1 v2 - shared helper for YALLACLOUD C:\Scripts commands.
# PowerShell 5.1 compatible, ASCII only, dot-sourceable, emits NOTHING at dot-source time.
#
# ============================ WHAT CHANGED IN v2, AND WHY ============================
# v2 is a BACKWARD-COMPATIBLE SUPERSET of v1. Every function v1 exported still exists with
# a parameter set that accepts every call shape the 50 shipped callers use today. Nothing
# that worked before throws now. Where a caller does something wrong, v2 handles it
# gracefully and LOUDLY instead of silently doing the wrong thing.
#
# [P0] LOG DIRECTORY WAS A WORLD-READABLE CREDENTIAL STORE (audit L2)
#   v1: New-Item 'C:\Scripts' inherited the ACL of C:\, which includes BUILTIN\Users:(RX).
#       Start-Transcript then wrote a "Host Application:" header containing the FULL command
#       line of powershell.exe - so every -Token / -Password / -SaPassword / -OOAuth that a
#       .cmd wrapper forwarded with %* landed verbatim in C:\Scripts\<name>.log, readable by
#       every account on the box. Day2/README.txt additionally puts C:\Scripts on the system
#       PATH and gives it a Defender exclusion; a Users-readable/writable, PATH-listed,
#       AV-excluded directory on a host where these run as SYSTEM is a privilege-escalation
#       primitive, not just an information leak.
#   v2: Start-YcLog breaks inheritance and grants SYSTEM + Administrators only ON CREATE, and
#       idempotently REPAIRS an already-existing loose C:\Scripts (v263 images are sealed with
#       the loose ACL), logging exactly which identities it removed. It also scrubs the log of
#       secrets BEFORE starting the transcript (removing every header accumulated by -Append
#       from previous runs), attempts an immediate same-length in-place scrub of the header it
#       just wrote, and scrubs again - deterministically, because the file is then closed - in
#       Stop-YcLog and in the engine-exit hook. See the note on Write-YcRedacted for why the
#       immediate scrub is best-effort: PowerShell holds the transcript open with FileShare.Read,
#       so a write handle is usually refused until the transcript stops. The ACL is what makes
#       that window harmless; the scrub is what makes the file safe at rest.
#       Protect-YcSecret redacts any string a caller is about to log.
#
# [P1] Write-YcLog ACCEPTED A NUMERIC LEVEL AND FILED FAILURES AS INFO (audit L1)
#   v1: [string]$Level coerced an event ID to '1002', matched no switch branch, fell to
#       default, and wrote EventId 1001 / EntryType Information. Bitdefender-Register.ps1:42
#       does exactly this today, so the one advisory that script exists to raise is invisible
#       to any rule filtering on Warning.
#   v2: Write-YcLog NORMALISES the level. 1003/ERR/FATAL/CRITICAL -> ERROR, 1002/WARNING ->
#       WARN, 1000/1001/1099/DEBUG/VERBOSE -> INFO, SUCCESS -> OK. It emits ONE WARN per
#       distinct bad value naming the calling script and line so it gets fixed, then carries
#       on. It does NOT throw: a [ValidateSet] here would turn a cosmetic bug into a hard
#       binding error in 50 unattended scripts.
#
# [P0] Assert-YcPrereqs -SelfElevate RELAUNCHED WITH NO ARGUMENTS AND RETURNED 0 (audit L3)
#   v1: $script:YcArgs and $script:MyScriptPath were never assigned anywhere in the payload.
#       The elevated child started with every parameter unbound, printed usage into a UAC
#       console that closed instantly and exited 1, while the parent exited 0 without waiting
#       and without calling Stop-YcLog. Cloud-init recorded SUCCESS and nothing was installed.
#   v2: -SelfElevate REQUIRES -BoundParameters $PSBoundParameters. Without it the library
#       refuses to relaunch and exits 5 loudly - wrong usage is impossible, not silent. With
#       it, the argument list is rebuilt element-by-element (string[], never a concatenated
#       string), the child is run -Wait -PassThru, and the CHILD's exit code is propagated.
#       Self-elevation is also refused outright in a non-interactive session (cloud-init /
#       SYSTEM / RMM), where -Verb RunAs cannot work.
#
# [P1] NOTHING ENFORCED Stop-YcLog (audit L4)
#   v1: about 20 of 51 scripts never call it, leaving the transcript open with no [END] line
#       and no EventId 1099, so start/end pairing health checks are useless.
#   v2: Start-YcLog registers a PowerShell.Exiting engine handler that closes the transcript
#       and writes [END] with the last known exit code if Stop-YcLog was never reached.
#       Stop-YcLog is idempotent, so the 30 scripts that DO call it are unaffected. The engine
#       event is documented as best-effort across hosts, so Exit-Yc remains the sanctioned
#       exit path and the compliance gate enforces it.
#
# [P2] MISSING HELPERS 50 CALLERS REIMPLEMENTED BADLY OR NOT AT ALL (audit L5/L7)
#   Added: Assert-YcService, Invoke-YcInstaller, Get-YcFile, Assert-YcHttp, Assert-YcFile,
#   Exit-Yc, Protect-YcSecret, Write-YcRedacted, Write-YcInvocation, Set-YcTls, Test-YcService,
#   Test-YcWorldOpen.
#   Invoke-YcInstaller is the function whose absence caused the Acronis incident: it captures
#   the exit code, decodes 0/1641/3010 as success-ish, decodes known vendor failures including
#   Acronis 6452566 ("installer rejected the command line"), logs the argument list with
#   secrets redacted, enforces a timeout and a minimum plausible duration, and returns a result
#   OBJECT so a caller physically cannot print an exit code and ignore it.
#   Test-YcInternet no longer accepts HTTP 403/407 (captive portal / blocking proxy) as
#   "internet OK" and no longer CLOBBERS the process TLS policy - it ORs Tls12/Tls13 in.
#
# RETROFIT (unchanged from v1, still the documented usage):
#     . 'C:\Scripts\_yc-lib.ps1'
#     Start-YcLog 'command-name'
#     Assert-YcPrereqs -NeedAdmin
#     ... work ...
#     Exit-Yc 0 'done' 'OK'
# Self-elevating callers MUST pass their bound parameters:
#     Assert-YcPrereqs -NeedAdmin -SelfElevate -BoundParameters $PSBoundParameters
#
# Logging: timestamped transcript (all output + errors) at C:\Scripts\<command>.log, every
#          structured line tagged [YALLACLOUD][<command>], mirrored to the Windows Application
#          event log under source 'YallaCloud' (1000 start, 1001 info, 1002 warn, 1003 error,
#          1099 end).
# ====================================================================================

# --- PSModulePath sanity -------------------------------------------------------------
# MEASURED 2026-08-30 on a fresh clone. sshd's default shell on this image is pwsh 7, so
# every wrapper launched over SSH runs "powershell.exe" as a CHILD of pwsh and inherits
# pwsh's PSModulePath - which puts C:\Program Files\PowerShell\7\Modules AHEAD of the
# Windows PowerShell ones. Windows PowerShell 5.1 then finds PowerShell 7's copy of
# Microsoft.PowerShell.Security first and refuses to load it:
#
#   Error in TypeData "System.Security.AccessControl.ObjectSecurity":
#   The member AuditToString is already present.
#
# From that point every cmdlet in that module is dead - Get-Acl, and by extension
# Get-PackageProvider, Install-Module and anything that needs the gallery. That is what
# made install-sql fail with exit 9 ("dbatools is unusable") on BOTH 2019 and 2022 clones,
# and it would do the same to any L1 who SSHes in and runs a wrapper by hand.
#
# Drop the PowerShell 7 entries when we are running under Windows PowerShell. Nothing in
# this toolkit is PS7-only; everything here is 5.1 by contract.
if($PSVersionTable.PSEdition -ne 'Core'){
    try{
        $keep = @($env:PSModulePath -split ';' | Where-Object {
            $_ -and ($_ -notmatch '(?i)\\PowerShell\\7(\\|$)') -and ($_ -notmatch '(?i)\\Program Files\\PowerShell\\Modules$') -and ($_ -notmatch '(?i)\\Documents\\PowerShell\\Modules$')
        })
        $must = @("$env:ProgramFiles\WindowsPowerShell\Modules", "$env:WINDIR\System32\WindowsPowerShell\v1.0\Modules")
        foreach($m in $must){ if($keep -notcontains $m){ $keep += $m } }
        $env:PSModulePath = ($keep -join ';')
    }catch{}
}

$script:YcLibVersion   = '2.4.0'
$script:YcLogFile      = $null
$script:YcLogDir       = 'C:\Scripts'
$script:YcTag          = 'yallacloud'
$script:YcEvtSource    = 'YallaCloud'
$script:YcEvtLog       = 'Application'
$script:YcEvtOK        = $false
$script:YcStopped      = $true
$script:YcStarted      = $false
$script:YcExitHook     = $false
$script:YcTranscriptOK = $false
$script:YcHeaderDirty  = $false
$script:YcLastCode     = 0
$script:YcLevelWarned  = @{}
$script:YcScriptPath   = $null
$script:MyScriptPath   = $null      # v1 declared this and never assigned it; v2 assigns it.
$script:YcArgs         = @()        # v1 declared this and never assigned it; v2 assigns it.

# Parameter names whose VALUE must never reach a log, a console, or an event.
$script:YcSecretParams = @(
    'Token','Password','Pass','Secret','Key','ApiKey','EnrollSecret','PSK','Community',
    'SaPassword','MyPassword','PgPassword','SqlPassword','OOPass','OOAuth','SqlPass',
    'RegPassword','DeviceKey','ProductKey','AdminPassword','DSN','DataSourceName',
    'Credential','AuthToken','BearerToken','ClientSecret','AccessKey','SecretKey',
    'PrivateKey','LicenseKey','TrapCommunity','ConnectionString'
)

# Two patterns, built once. P1 catches installer-style 'name=value' and '--reg-token=value'.
# P2 catches PowerShell-style '-Name value'. P2 is anchored with a lookahead so that
# '-PassThru' does NOT match 'Pass' and swallow the next token.
$script:YcSecretRxAssign = '(?i)([\w./-]*(?:token|password|passwd|secret|apikey|api-key|psk|community|enrollsecret|devicekey|productkey|credential|privatekey|accesskey|secretkey|oopass|ooauth|sapassword|mypassword|pgpassword|sqlpassword|sqlpass|regpassword|connectionstring|datasourcename|dsn)[\w.-]*)(\s*[:=]\s*)("[^"]*"|''[^'']*''|[^\s;,&|]+)'
# A bare 5x5 product key. slmgr /ipk answers in PROSE - "Installed product key
# XXXXX-XXXXX-XXXXX-XXXXX-XXXXX successfully" - so it carries no name=value and no
# -Parameter for the two patterns above to catch, and the key went into the log, the
# transcript and the Application event log in full. Masking keeps the LAST FIVE, which
# is exactly what Windows itself publishes as PartialProductKey, and the replacement is
# the same length as the match so the in-place scrub can never change a file's size.
$script:YcSecretRxProductKey = '\b[A-Z0-9]{5}(?:-[A-Z0-9]{5}){4}\b'
$script:YcSecretRxParam  = $null
$script:YcSecretRxParam  = '(?i)(-(?:' + (($script:YcSecretParams | Sort-Object { $_.Length } -Descending) -join '|') + ')(?=[\s:=]))(\s*[:=]?\s+)("[^"]*"|''[^'']*''|[^\s;,&|]+)'

# Well-known SIDs that are ALLOWED to have access to the log directory.
$script:YcAclAllowedSids = @(
    'S-1-5-18',                                                                    # NT AUTHORITY\SYSTEM
    'S-1-5-32-544',                                                                # BUILTIN\Administrators
    'S-1-3-0',                                                                     # CREATOR OWNER
    'S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464'               # TrustedInstaller
)

# ------------------------------------------------------------------------------------
# Secret handling
# ------------------------------------------------------------------------------------

# Protect-YcSecret -Value <string> [-Keep <int>] [-Whole]
#   Default: scans $Value for secret-looking parameters and masks their VALUES, returning a
#            string that is safe to log. Use on any string before logging it.
#   -Whole : treats the WHOLE of $Value as one raw secret and returns '****' + last -Keep chars.
function Protect-YcSecret{
    param([string]$Value,[int]$Keep=0,[switch]$Whole)
    if($null -eq $Value){ return '' }
    if($Value.Length -eq 0){ return '' }
    if($Whole){
        if($Keep -gt 0 -and $Value.Length -gt $Keep){ return ('****' + $Value.Substring($Value.Length - $Keep)) }
        return '****'
    }
    $out = $Value
    try{
        $out = [regex]::Replace($out,$script:YcSecretRxAssign,{ param($m) $m.Groups[1].Value + $m.Groups[2].Value + '****' })
        $out = [regex]::Replace($out,$script:YcSecretRxParam ,{ param($m) $m.Groups[1].Value + ' ****' })
        $out = [regex]::Replace($out,$script:YcSecretRxProductKey,{ param($m)
                    '*****-*****-*****-*****-' + $m.Value.Substring($m.Value.Length - 5) })
    }catch{}
    return $out
}

# Write-YcRedacted -Path <file> [-Quiet]
#   Masks every secret value in a log file IN PLACE, replacing each value character with '*'
#   so the file's BYTE LENGTH NEVER CHANGES. That matters: PowerShell keeps its own write
#   position in an open transcript, so truncating or growing the file underneath it would
#   corrupt the log. Returns the number of characters masked, or -1 if the file could not be
#   opened for writing (which is the normal result while a transcript is active, because
#   PowerShell 5.1 opens the transcript with FileShare.Read - the deferred scrub in
#   Stop-YcLog then runs against a closed file and always succeeds).
function Write-YcRedacted{
    param([string]$Path,[switch]$Quiet)
    if(-not $Path){ return 0 }
    if(-not (Test-Path -LiteralPath $Path)){ return 0 }
    $fs = $null
    $changed = 0
    try{
        $fs = New-Object System.IO.FileStream($Path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::ReadWrite)
    }catch{
        if(-not $Quiet){ $script:YcHeaderDirty = $true }
        return -1
    }
    try{
        $len = [int]$fs.Length
        if($len -le 0){ return 0 }
        $buf = New-Object byte[] $len
        [void]$fs.Read($buf,0,$len)
        $enc = [System.Text.Encoding]::UTF8
        $isUtf16 = $false
        if($len -ge 2 -and $buf[0] -eq 0xFF -and $buf[1] -eq 0xFE){ $enc = [System.Text.Encoding]::Unicode; $isUtf16 = $true }
        $txt = $enc.GetString($buf)
        $new = $txt
        $new = [regex]::Replace($new,$script:YcSecretRxAssign,{ param($m)
                    $v = $m.Groups[3].Value
                    $q = ''
                    if($v.Length -ge 2 -and ($v[0] -eq '"' -or $v[0] -eq "'")){ $q = [string]$v[0] }
                    $inner = $v
                    if($q -ne ''){ $inner = $v.Substring(1,$v.Length-2) }
                    $m.Groups[1].Value + $m.Groups[2].Value + $q + ('*' * $inner.Length) + $q })
        $new = [regex]::Replace($new,$script:YcSecretRxParam,{ param($m)
                    $v = $m.Groups[3].Value
                    $q = ''
                    if($v.Length -ge 2 -and ($v[0] -eq '"' -or $v[0] -eq "'")){ $q = [string]$v[0] }
                    $inner = $v
                    if($q -ne ''){ $inner = $v.Substring(1,$v.Length-2) }
                    $m.Groups[1].Value + $m.Groups[2].Value + $q + ('*' * $inner.Length) + $q })
        $new = [regex]::Replace($new,$script:YcSecretRxProductKey,{ param($m)
                    '*****-*****-*****-*****-' + $m.Value.Substring($m.Value.Length - 5) })
        if($new -eq $txt){ return 0 }
        for($i=0;$i -lt $txt.Length -and $i -lt $new.Length;$i++){ if($txt[$i] -ne $new[$i]){ $changed++ } }
        $outBytes = $enc.GetBytes($new)
        if($isUtf16){
            # GetBytes() on the Unicode encoding drops the BOM; put it back so length matches.
            $tmp = New-Object byte[] ($outBytes.Length + 2)
            $tmp[0] = 0xFF; $tmp[1] = 0xFE
            [Array]::Copy($outBytes,0,$tmp,2,$outBytes.Length)
            $outBytes = $tmp
        }
        if($outBytes.Length -ne $len){ return 0 }   # refuse to change the file length, ever
        $fs.Position = 0
        $fs.Write($outBytes,0,$outBytes.Length)
        $fs.Flush()
        $script:YcHeaderDirty = $false
    }catch{
        return -1
    }finally{
        if($fs){ try{ $fs.Close() }catch{} }
    }
    return $changed
}

# ------------------------------------------------------------------------------------
# Event log (v1 behaviour preserved exactly)
# ------------------------------------------------------------------------------------

function Initialize-YcEvent{
    if($script:YcEvtOK){ return }
    try{
        if(-not [System.Diagnostics.EventLog]::SourceExists($script:YcEvtSource)){
            New-EventLog -LogName $script:YcEvtLog -Source $script:YcEvtSource -ErrorAction Stop
        }
        $script:YcEvtOK = $true
    }catch{ $script:YcEvtOK = $false }   # not admin / not permitted: file log still works
}

function Write-YcEvent([string]$Message,[string]$Level,[int]$EventId){
    if(-not $script:YcEvtOK){ return }
    $type = switch($Level){ 'ERROR'{'Error'} 'WARN'{'Warning'} default{'Information'} }
    $safe = Protect-YcSecret $Message
    try{ Write-EventLog -LogName $script:YcEvtLog -Source $script:YcEvtSource -EntryType $type -EventId $EventId -Message (("[{0}] " -f $script:YcTag) + $safe) -ErrorAction SilentlyContinue }catch{}
}

# ------------------------------------------------------------------------------------
# Level normalisation (audit L1)
# ------------------------------------------------------------------------------------

# Internal. Returns 'INFO' | 'OK' | 'WARN' | 'ERROR' for anything a caller might pass,
# and reports (once per distinct bad value) where the bad value came from.
function ConvertTo-YcLevel{
    param([string]$Level)
    if($null -eq $Level){ $Level = '' }
    $raw = $Level.Trim()
    if($raw.Length -eq 0){ return 'INFO' }
    $u = $raw.ToUpperInvariant()
    switch($u){
        'INFO'  { return 'INFO' }
        'OK'    { return 'OK' }
        'WARN'  { return 'WARN' }
        'ERROR' { return 'ERROR' }
    }
    $mapped = $null
    switch($u){
        'WARNING'  { $mapped = 'WARN' }
        'ERR'      { $mapped = 'ERROR' }
        'FATAL'    { $mapped = 'ERROR' }
        'CRITICAL' { $mapped = 'ERROR' }
        'CRIT'     { $mapped = 'ERROR' }
        'FAIL'     { $mapped = 'ERROR' }
        'SUCCESS'  { $mapped = 'OK' }
        'PASS'     { $mapped = 'OK' }
        'DONE'     { $mapped = 'OK' }
        'DEBUG'    { $mapped = 'INFO' }
        'VERBOSE'  { $mapped = 'INFO' }
        'TRACE'    { $mapped = 'INFO' }
        'NOTICE'   { $mapped = 'INFO' }
        '1000'     { $mapped = 'INFO' }
        '1001'     { $mapped = 'INFO' }
        '1002'     { $mapped = 'WARN' }
        '1003'     { $mapped = 'ERROR' }
        '1099'     { $mapped = 'INFO' }
    }
    if(-not $mapped){
        $n = 0
        if([int]::TryParse($raw,[ref]$n)){
            if($n -ge 1003){ $mapped = 'ERROR' }
            elseif($n -eq 1002){ $mapped = 'WARN' }
            else{ $mapped = 'INFO' }
        }else{
            $mapped = 'INFO'
        }
    }
    # One-time, non-fatal report naming the offending call site so it gets fixed.
    if(-not $script:YcLevelWarned.ContainsKey($u)){
        $script:YcLevelWarned[$u] = $true
        $where = 'unknown call site'
        try{
            $st = Get-PSCallStack
            foreach($f in $st){
                if($f.ScriptName -and ($f.ScriptName -notlike '*_yc-lib.ps1')){
                    $where = ('{0}:{1}' -f (Split-Path -Leaf $f.ScriptName),$f.ScriptLineNumber)
                    break
                }
            }
        }catch{}
        $nn = 0
        $hint = "'" + $raw + "' is not a recognised level"
        if([int]::TryParse($raw,[ref]$nn)){ $hint = "'" + $raw + "' is an EVENT ID, not a level - the level argument is the SECOND positional argument of Write-YcLog" }
        $msg = ("BAD LOG LEVEL passed to Write-YcLog at {0} - treated as {1}. Levels are INFO/OK/WARN/ERROR; {2}. Fix the call site." -f $where,$mapped,$hint)
        Write-Host ((Get-YcLogPrefix -Tag $script:YcTag -Level 'WARN') + (ConvertTo-YcOneLine $msg)) -ForegroundColor Yellow
        Write-YcEvent $msg 'WARN' 1002
    }
    return $mapped
}

# ------------------------------------------------------------------------------------
# Log directory hardening (audit L2)
# ------------------------------------------------------------------------------------

# Internal. Returns a short description of what it changed, or '' if nothing changed.
function Protect-YcLogDir{
    param([string]$Dir)
    $created = $false
    $note    = ''
    if(-not (Test-Path -LiteralPath $Dir)){
        New-Item -ItemType Directory -Path $Dir -Force | Out-Null
        $created = $true
    }
    $needFix = $created
    $loose   = @()
    if(-not $created){
        try{
            $acl = Get-Acl -Path $Dir
            if(-not $acl.AreAccessRulesProtected){ $needFix = $true }
            foreach($ace in $acl.Access){
                $sid = $null
                try{ $sid = $ace.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value }
                catch{ $sid = [string]$ace.IdentityReference }
                if($script:YcAclAllowedSids -notcontains $sid){
                    $needFix = $true
                    $nm = [string]$ace.IdentityReference
                    if($loose -notcontains $nm){ $loose += $nm }
                }
            }
        }catch{
            $needFix = $true
            $flat = ([string]$_.Exception.Message) -replace '[\r\n]+',' '
            $loose += ('ACL unreadable: ' + $flat)
        }
    }
    if(-not $needFix){ return '' }

    $ok = $false
    try{
        # Names first (matches the documented fix); SIDs as a locale-safe fallback.
        & icacls $Dir /inheritance:r /grant 'NT AUTHORITY\SYSTEM:(OI)(CI)F' 'BUILTIN\Administrators:(OI)(CI)F' 2>&1 | Out-Null
        if($LASTEXITCODE -eq 0){ $ok = $true }
        if(-not $ok){
            & icacls $Dir /inheritance:r /grant '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' 2>&1 | Out-Null
            if($LASTEXITCODE -eq 0){ $ok = $true }
        }
    }catch{ $ok = $false }

    # Hide the directory itself. The ACL is what PROTECTS it; this only stops a customer
    # browsing to C:\Scripts, finding a folder full of scripts named after things they
    # recognise, and running one. Hidden alone is defeated by "show hidden files", so the
    # System attribute goes on too - Explorer then also needs "hide protected operating
    # system files" turned off. Both are set on the FOLDER only, never on the files inside
    # it: a hidden folder still enumerates its children normally, and several commands here
    # count the files in C:\Scripts without -Force.
    try{
        $di = Get-Item -LiteralPath $Dir -Force -ErrorAction Stop
        $want = [IO.FileAttributes]::Hidden -bor [IO.FileAttributes]::System
        if(($di.Attributes -band $want) -ne $want){ $di.Attributes = $di.Attributes -bor $want }
    }catch{ }

    if($created){
        if($ok){ $note = ("created {0} with inheritance broken; SYSTEM + Administrators Full only" -f $Dir) }
        else   { $note = ("created {0} but FAILED to harden its ACL - it may be readable by BUILTIN\Users" -f $Dir) }
    }else{
        if($ok){
            $note = ("REPAIRED ACL on existing {0}: inheritance broken, SYSTEM + Administrators Full only" -f $Dir)
            if($loose.Count -gt 0){ $note += ("; removed access for: " + ($loose -join ', ')) }
            $note += ". Non-admin accounts can no longer read the transcripts in this directory (this directory is on the system PATH)."
        }else{
            $note = ("FAILED to repair the loose ACL on {0} (needs Administrator). Transcripts here may be readable by: {1}" -f $Dir,(($loose -join ', ')))
        }
    }
    return $note
}

# ------------------------------------------------------------------------------------
# Network scope
# ------------------------------------------------------------------------------------

# Test-YcWorldOpen [-Scope] <string[]>
#   THE single implementation of "is this firewall scope open to the whole internet?".
#   Promoted out of Set-Firewall.ps1 because three exporter registrars had each grown their
#   own version that only recognised the literal string 'Any', so -RemoteAddress 0.0.0.0/0
#   walked straight past the guard. True when the scope is null/empty, when ANY element is
#   empty, or when ANY element is a wildcard keyword. EVERY element is tested - a caller must
#   never assume a multi-element list is automatically safe.
function Test-YcWorldOpen{
    param([string[]]$Scope)
    if($null -eq $Scope -or $Scope.Count -eq 0){ return $true }
    foreach($s in $Scope){
        if([string]::IsNullOrEmpty($s)){ return $true }
        $t = $s.Trim()
        if($t -eq 'Any' -or $t -eq '*' -or $t -eq '0.0.0.0/0' -or $t -eq '::/0' -or $t -eq 'Internet'){ return $true }
    }
    return $false
}

# ------------------------------------------------------------------------------------
# TLS
# ------------------------------------------------------------------------------------

# Set-YcTls - ORs Tls12 (and Tls13 where the platform has it) into the CURRENT policy
# instead of replacing it. v1 assigned Tls12, which dropped Tls13 on Server 2022/2025.
function Set-YcTls{
    try{
        $cur = [Net.ServicePointManager]::SecurityProtocol
        $want = [Net.SecurityProtocolType]::Tls12
        if([int]$cur -ne 0){ $want = $cur -bor [Net.SecurityProtocolType]::Tls12 }
        if([enum]::GetNames([Net.SecurityProtocolType]) -contains 'Tls13'){
            try{ $want = $want -bor ([Net.SecurityProtocolType]'Tls13') }catch{}
        }
        try{ [Net.ServicePointManager]::SecurityProtocol = $want }
        catch{ [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
    }catch{}
}

# ------------------------------------------------------------------------------------
# Start / Write / Stop
# ------------------------------------------------------------------------------------

# Start-YcLog [-Name] <string> [[-Dir] <string> = 'C:\Scripts'] [[-MaxLogMB] <int> = 5] [-SkipAclHarden]
#   Hardens/creates the log directory, rotates an oversized log, starts the transcript (with a
#   LOUD banner if it fails - v1 swallowed that and ran completely unlogged), scrubs secrets out
#   of the transcript header, registers the exit hook that guarantees an [END] line, initialises
#   the event source and writes START / EventId 1000.
#   -Name is positional 1, exactly as v1: Start-YcLog 'acronis-register' still works.
function Start-YcLog{
    param([string]$Name,[string]$Dir='C:\Scripts',[int]$MaxLogMB=5,[switch]$SkipAclHarden)

    if(-not $Name){ $Name = 'yallacloud' }
    $script:YcTag     = $Name
    $script:YcLogDir  = $Dir
    $script:YcStopped = $false
    $script:YcStarted = $true
    $script:YcLastCode = 0
    $script:YcMsSent = $false
    $script:YcLastMessage = ''
    # The parameters the calling script was given, so the run-end webhook can tell a -Report or
    # -Help run (read-only, not reported) from one that changed something.
    $script:YcBoundNames = @()
    try{
        foreach($fr in @(Get-PSCallStack)){
            $ii = $fr.InvocationInfo
            if($ii -and $ii.MyCommand -and ([string]$ii.MyCommand.CommandType -eq 'ExternalScript') -and ([string]$fr.ScriptName -notlike '*_yc-lib.ps1')){
                $script:YcBoundNames = @($ii.BoundParameters.Keys); break
            }
        }
    }catch{}

    # Record where the caller lives so -SelfElevate and diagnostics have a real path.
    try{
        $p = $MyInvocation.PSCommandPath
        if(-not $p){
            $st = Get-PSCallStack
            foreach($f in $st){ if($f.ScriptName -and ($f.ScriptName -notlike '*_yc-lib.ps1')){ $p = $f.ScriptName; break } }
        }
        $script:YcScriptPath = $p
        $script:MyScriptPath = $p
    }catch{}

    $aclNote = ''
    if(-not $SkipAclHarden){
        try{ $aclNote = Protect-YcLogDir -Dir $Dir }catch{ $aclNote = 'ACL hardening threw: ' + $_.Exception.Message }
    }

    $script:YcLogFile = Join-Path $Dir ($Name + '.log')

    # Rotate before appending, so a single command cannot grow an unbounded secret archive.
    try{
        if(Test-Path -LiteralPath $script:YcLogFile){
            $sz = (Get-Item -LiteralPath $script:YcLogFile).Length
            if($MaxLogMB -gt 0 -and $sz -gt ($MaxLogMB * 1MB)){
                $bak = $script:YcLogFile + '.1'
                if(Test-Path -LiteralPath $bak){ Remove-Item -LiteralPath $bak -Force -ErrorAction SilentlyContinue }
                Move-Item -LiteralPath $script:YcLogFile -Destination $bak -Force -ErrorAction SilentlyContinue
            }
        }
    }catch{}

    # Scrub secrets left by PREVIOUS runs' transcript headers before we append another one.
    try{ [void](Write-YcRedacted -Path $script:YcLogFile -Quiet) }catch{}

    $script:YcTranscriptOK = $false
    try{
        Start-Transcript -Path $script:YcLogFile -Append -ErrorAction Stop | Out-Null
        $script:YcTranscriptOK = $true
    }catch{
        $script:YcTranscriptOK = $false
    }
    if(-not $script:YcTranscriptOK){
        # v1 swallowed this and left the command running with NO log and no warning.
        Write-Host ''
        Write-Host '*** TRANSCRIPT FAILED - THIS RUN IS NOT BEING LOGGED TO DISK ***' -ForegroundColor Red
        Write-Host ("*** target: {0}  (a transcript may already be running in this process, or the file is locked) ***" -f $script:YcLogFile) -ForegroundColor Red
        Write-Host ''
        $script:YcLogFile = $null
    }

    # The PS 5.1 transcript header always contains the host process command line, which is
    # where wrapper-forwarded secrets land. Best-effort immediate scrub; guaranteed at Stop.
    if($script:YcTranscriptOK){
        $r = -1
        try{ $r = Write-YcRedacted -Path $script:YcLogFile }catch{ $r = -1 }
        if($r -lt 0){ $script:YcHeaderDirty = $true }
    }

    Initialize-YcEvent

    $m  = ("START  host={0} user={1} ps={2} lib={3}" -f $env:COMPUTERNAME,$env:USERNAME,$PSVersionTable.PSVersion,$script:YcLibVersion)
    Write-Host ((Get-YcLogPrefix -Tag $Name -Level 'START') + (ConvertTo-YcOneLine $m))
    Write-YcEvent $m 'INFO' 1000

    if($aclNote){
        $lvl = 'INFO'
        if($aclNote -like 'FAILED*' -or $aclNote -like '*FAILED*'){ $lvl = 'WARN' }
        Write-YcLog ('log dir ACL: ' + $aclNote) $lvl
    }

    # A redacted, auditable record of how this command was actually invoked.
    try{
        $cl = [Environment]::CommandLine
        if($cl){ Write-YcLog ('invocation: ' + (Protect-YcSecret $cl)) 'INFO' }
        $script:YcArgs = @()
        if($cl -match '(?i)\s-File\s+"?[^"]*\.ps1"?\s*(.*)$'){ $script:YcArgs = @($Matches[1]) }
        if($cl -and ($cl -match $script:YcSecretRxParam -or $cl -match $script:YcSecretRxAssign)){
            Write-YcLog 'SECRET ON THE COMMAND LINE: this value is visible in the process table and in 4688 events, and was written into this transcript header by PowerShell (now masked). Prefer a secret file or an environment variable.' 'WARN'
        }
    }catch{}

    if($script:YcHeaderDirty){
        Write-YcLog 'Transcript header could not be scrubbed while the transcript is open (PowerShell holds it with FileShare.Read). It will be scrubbed when this command exits; until then the directory ACL is what protects it.' 'INFO'
    }

    # Guarantee an [END] line even for the ~20 scripts that never call Stop-YcLog.
    if(-not $script:YcExitHook){
        try{
            $null = Register-EngineEvent -SourceIdentifier PowerShell.Exiting -SupportEvent -Action {
                try{
                    if(-not $script:YcStopped){
                        $c = $script:YcLastCode
                        try{ if($null -ne $global:LASTEXITCODE){ $c = [int]$global:LASTEXITCODE } }catch{}
                        Stop-YcLog -Code $c -Unclean
                    }
                }catch{}
            }
            $script:YcExitHook = $true
        }catch{}
    }
}

# Write-YcLog [-Message] <string> [[-Level] <string> = 'INFO']
#   One tagged console line + one Application event. $Level is normalised, never rejected:
#   a numeric event id such as 1002 is MAPPED to WARN and reported once, not filed as INFO.
#   Secrets in $Message are masked before they reach the console or the event log.
# ------------------------------------------------------------------------------------
# THE LOG LINE GRAMMAR. Every line this library emits matches exactly this, and central
# logging can rely on it:
#
#   <ISO8601 with offset>  <HOSTNAME>  [YALLACLOUD][<command>] [<LEVEL>] <message>
#   2026-09-01T10:38:09+04:00  WIN-GQ69INT5EN6  [YALLACLOUD][install-sql] [INFO] ...
#
#   LEVEL is one of START INFO OK WARN ERROR END.
#   Regex:
#     ^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}\s+\S+\s+\[YALLACLOUD\]\[[^\]]+\] \[(START|INFO|OK|WARN|ERROR|END)\] 
#
# WHY THE HOSTNAME AND THE OFFSET. The old format was "yyyy-MM-dd HH:mm:ss [YALLACLOUD]..."
# with neither. Shipped to a central collector alongside every other machine, a line could
# not be attributed to a host at all, and a bare local time is ambiguous the moment two
# sites are in different zones - this estate runs at +04:00. Both are now in every line.
#
# ONE EVENT IS ONE LINE. A message containing a newline used to emit continuation lines
# with no timestamp and no tag, which arrive at a collector as orphans belonging to
# nothing. Newlines are folded to ' | ' so a line and an event are the same thing.
#
# NOT OURS, AND MUST NOT BE INGESTED AS OURS: C:\Scripts\*-*.msi.log are Windows
# Installer's own verbose logs, and the first few lines of every .log file are the
# PowerShell transcript header. Neither is YallaCloud output. Match on the regex above
# rather than on the file extension.
# ------------------------------------------------------------------------------------
function Get-YcLogPrefix{
    param([string]$Tag,[string]$Level)
    if(-not $script:YcHostName){ $script:YcHostName = $env:COMPUTERNAME }
    return ("{0}  {1}  [YALLACLOUD][{2}] [{3}] " -f (Get-Date).ToString('yyyy-MM-ddTHH:mm:sszzz'),$script:YcHostName,$Tag,$Level)
}
# Fold a multi-line message into one line so one event is one line.
function ConvertTo-YcOneLine{
    param([string]$Text)
    if($null -eq $Text){ return '' }
    return ((("$Text" -replace "`r`n"," | ") -replace "`r"," | ") -replace "`n"," | ")
}

function Write-YcLog{
    param([string]$Message,[string]$Level='INFO')
    $lvl  = ConvertTo-YcLevel $Level
    $safe = Protect-YcSecret $Message
    $line = (Get-YcLogPrefix -Tag $script:YcTag -Level $lvl) + (ConvertTo-YcOneLine $safe)
    # The last ERROR is the "why" the run-end webhook reports (Exit-Yc's message wins over it).
    if($lvl -eq 'ERROR' -and -not ([string]$safe).Contains('[YC-MILESTONE]')){ $script:YcLastMessage = $safe }
    switch($lvl){
        'ERROR' { Write-Host $line -ForegroundColor Red;    Write-YcEvent $safe 'ERROR' 1003 }
        'WARN'  { Write-Host $line -ForegroundColor Yellow; Write-YcEvent $safe 'WARN'  1002 }
        'OK'    { Write-Host $line -ForegroundColor Green;  Write-YcEvent $safe 'INFO'  1001 }
        default { Write-Host $line;                         Write-YcEvent $safe 'INFO'  1001 }
    }
}

# Write-YcInvocation [-BoundParameters] <hashtable> [[-SecretNames] <string[]>]
#   Logs a redacted one-line record of how the command was invoked.
function Write-YcInvocation{
    param([hashtable]$BoundParameters,[string[]]$SecretNames)
    if(-not $SecretNames){ $SecretNames = $script:YcSecretParams }
    $parts = @()
    if($BoundParameters){
        foreach($k in ($BoundParameters.Keys | Sort-Object)){
            $v = $BoundParameters[$k]
            $isSecret = $false
            foreach($s in $SecretNames){ if($k -eq $s){ $isSecret = $true; break } }
            if(-not $isSecret){
                foreach($s in @('Token','Password','Secret','ApiKey','Psk','Credential','ProductKey','DeviceKey','Dsn')){
                    if($k -like ('*' + $s + '*')){ $isSecret = $true; break }
                }
            }
            if($v -is [System.Management.Automation.SwitchParameter]){
                if($v.IsPresent){ $parts += ('-' + $k) }
            }elseif($isSecret){
                $parts += ('-' + $k + ' ' + (Protect-YcSecret ([string]$v) -Whole -Keep 0))
            }else{
                $parts += ('-' + $k + ' ' + (Protect-YcSecret ([string]$v)))
            }
        }
    }
    Write-YcLog ('invoked: ' + $script:YcTag + ' ' + ($parts -join ' ')) 'INFO'
}

# Stop-YcLog [[-Code] <int> = 0] [-Unclean]
#   Writes END exit=<n> + EventId 1099, stops the transcript, and scrubs any secret the
#   transcript header left behind (the file is closed at that point, so this always works).
#   IDEMPOTENT: a second call is a no-op, so the ~30 scripts that already call it are
#   unaffected and the PowerShell.Exiting hook cannot produce a duplicate [END].
#   -Unclean is set only by the exit hook, for a script that never reached Stop-YcLog or
#   Exit-Yc. In that path the [END] line is ALSO appended to the log file directly, because
#   output written from an engine-exiting handler is not reliably captured by the transcript -
#   and a missing [END] is precisely the signal (audit L4) this exists to guarantee.
function Stop-YcLog{
    param([int]$Code=0,[switch]$Unclean)
    if($script:YcStopped){ return }
    $script:YcStopped  = $true
    $script:YcLastCode = $Code
    # The run-end webhook, BEFORE the END line so its result is in this run's log. Never on the
    # unclean path: that runs inside the engine's exit handler, no place for a network call.
    if(-not $Unclean){ try{ [void](Send-YcRunMilestone -Code $Code) }catch{} }
    $note = ''
    if($Unclean){ $note = ' UNCLEAN - the script exited without calling Stop-YcLog or Exit-Yc; this exit code is the last one the library saw, not necessarily the process exit code' }
    $line = (Get-YcLogPrefix -Tag $script:YcTag -Level 'END') + (ConvertTo-YcOneLine ('exit=' + $Code + $note))
    Write-Host $line
    Write-YcEvent ("END exit=" + $Code + $note) 'INFO' 1099
    $f = $script:YcLogFile
    try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null } catch {}
    $script:YcTranscriptOK = $false
    if($f){
        if($Unclean){
            try{
                $seen = $false
                $tail = Get-Content -LiteralPath $f -Tail 25 -ErrorAction SilentlyContinue
                # NOT -like: '[END]' is a -like character class (one of E,N,D) and never matches
                # the literal text, so the duplicate-END guard silently never fired. .Contains() is literal.
                foreach($t in $tail){ if($t -and $t.Contains('[END] exit=')){ $seen = $true } }
                if(-not $seen){ Add-Content -LiteralPath $f -Value $line -Encoding ascii -ErrorAction SilentlyContinue }
            }catch{}
        }
        try{ [void](Write-YcRedacted -Path $f -Quiet) }catch{}
    }
}

# Exit-Yc [-Code] <int> [[-Message] <string>] [[-Level] <string>]
#   THE single sanctioned exit path: logs at the right level, Stop-YcLog, exit with the code.
#   Level defaults to OK for 0 and ERROR for anything else.
function Exit-Yc{
    param([int]$Code=0,[string]$Message,[string]$Level)
    if(-not $Level){ if($Code -eq 0){ $Level = 'OK' } else { $Level = 'ERROR' } }
    if($Message){ Write-YcLog $Message $Level }
    if($Code -ne 0 -and $Message){ $script:YcLastMessage = $Message }
    $script:YcLastCode = $Code
    Stop-YcLog $Code
    exit $Code
}

# ------------------------------------------------------------------------------------
# Preflight (v1 names and behaviour preserved)
# ------------------------------------------------------------------------------------

function Get-YcRegValueOrNull{
  param([string]$Path,[string]$Name)
  if(-not (Test-Path -LiteralPath $Path)){ return $null }
  try{
    $p = Get-ItemProperty -LiteralPath $Path
    if($p.PSObject.Properties.Name -contains $Name){ return $p.$Name }
    return $null
  }catch{ return $null }
}

# The documented pending-reboot indicators: Component Based Servicing RebootPending, Windows
# Update Auto Update RebootRequired, and Session Manager PendingFileRenameOperations. SQL Server
# setup's own RebootRequiredCheck rule fails EVERY action - install and editionupgrade alike -
# when any of these is present, so anything that shells out to setup.exe should look first rather
# than discover it eight minutes in. Lived here from 2026-09-01; it used to be private to
# Install-Sql.ps1, which meant activate-sql had no way to check.
function Get-YcPendingRebootReasons{
  $r = New-Object System.Collections.Generic.List[string]
  if(Test-Path -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'){
    [void]$r.Add('Component Based Servicing\RebootPending')
  }
  if(Test-Path -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'){
    [void]$r.Add('WindowsUpdate\Auto Update\RebootRequired')
  }
  # PendingFileRenameOperations is NOT evidence of a pending reboot on its own. Windows
  # re-queues the inbox PRINT-SPOOLER drivers into it at EVERY boot, so on a Server 2022
  # guest it is never empty and never clears. Measured on VC2022SQLTEST 2026-09-09: all 20
  # entries were \System32\spool\drivers\..., and they came straight back after a restart
  # that DID clear both Component Based Servicing and WindowsUpdate. Counting them made
  # install-sql refuse its preflight on every 2022 build, forever - not a machine that needs
  # a restart, a machine that can never be built. Only non-spooler entries count now.
  $pfro = Get-YcRegValueOrNull -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name 'PendingFileRenameOperations'
  if($pfro){
    $pfroReal = @($pfro | Where-Object { $_ -and ($_ -notmatch '\\spool\\drivers\\') })
    if($pfroReal.Count -gt 0){ [void]$r.Add('Session Manager\PendingFileRenameOperations') }
  }
  return $r
}

# Has the Windows computer been renamed since SQL Server was installed? Returns $null when
# there is nothing wrong (or when the question cannot be answered), otherwise a hashtable of
# @{ Was = <old>; Now = <expected> }.
#
# DETECTION lives here so every script that touches SQL can notice. The REPAIR deliberately
# does not: it needs sp_dropserver/sp_addserver, a SQL Server restart to take effect, and a
# refusal on clustered / AlwaysOn / replicated instances. None of that belongs inside a
# nightly backup or an installer, so it lives in exactly one place - fix-deploy -Only
# sqlrename - and everything else just says "run that".
function Get-YcSqlNameDrift{
  param([string]$Target = '.',[int]$TimeoutSec = 10)
  $cn = $null
  try{
    Add-Type -AssemblyName 'System.Data' -ErrorAction SilentlyContinue
    $cs = 'Server=' + $Target + ';Database=master;Integrated Security=SSPI;Connect Timeout=' +
          $TimeoutSec + ';Application Name=YallaCloud-namedrift'
    $cn = New-Object System.Data.SqlClient.SqlConnection $cs
    $cn.Open()
    $cmd = $cn.CreateCommand()
    $cmd.CommandText = "SET NOCOUNT ON; SELECT CONVERT(nvarchar(128),@@SERVERNAME) AS S," +
                       "CONVERT(nvarchar(128),SERVERPROPERTY('MachineName')) AS M," +
                       "CONVERT(nvarchar(128),ISNULL(SERVERPROPERTY('InstanceName'),'')) AS I"
    $cmd.CommandTimeout = $TimeoutSec
    $rd = $cmd.ExecuteReader()
    $was = ''; $mach = ''; $inst = ''
    if($rd.Read()){ $was = [string]$rd['S']; $mach = [string]$rd['M']; $inst = [string]$rd['I'] }
    $rd.Close()
    if(-not $was -or -not $mach){ return $null }
    $now = if([string]::IsNullOrEmpty($inst) -or $inst -eq 'MSSQLSERVER'){ $mach } else { $mach + '\' + $inst }
    if($was -eq $now){ return $null }
    return @{ Was = $was; Now = $now }
  }catch{
    return $null
  }finally{
    if($null -ne $cn){ try{ $cn.Close() }catch{}; try{ $cn.Dispose() }catch{} }
  }
}

# One line, said the same way by every caller, so the operator sees the same sentence wherever
# they happen to be looking.
function Write-YcSqlNameDriftWarning{
  param($Drift,[string]$InstanceName = 'MSSQLSERVER')
  if($null -eq $Drift){ return $false }
  Write-YcLog ('This machine was RENAMED after SQL Server was installed: @@SERVERNAME still ' +
    'reports "' + $Drift.Was + '" but the machine is "' + $Drift.Now + '". Logins are unaffected ' +
    '(Windows logins are stored by SID), but linked servers, replication and anything reading ' +
    '@@SERVERNAME see a machine that no longer exists, and Ola Hallengren backups fork into a ' +
    'new <hostname> folder that leaves the old one unpruned for ever. Repair it with:') 'WARN'
  Write-YcLog ('    C:\Scripts\fix-deploy.cmd -Only sqlrename -RestartSql -MergeOrphanBackups') 'WARN'
  return $true
}

function Test-YcAdmin{
    try{
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = New-Object Security.Principal.WindowsPrincipal($id)
        return $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }catch{ return $false }
}

# Test-YcInternet [[-Url] <string>] [[-TimeoutSec] <int> = 8]
#   True only on an HTTP status BELOW 400. v1 accepted anything under 500, so a captive portal
#   or a blocking proxy answering 403/407 counted as "internet OK".
function Test-YcInternet([string]$Url='https://www.microsoft.com',[int]$TimeoutSec=8){
    Set-YcTls
    try{
        $r = Invoke-WebRequest -Uri $Url -UseBasicParsing -Method Head -TimeoutSec $TimeoutSec -ErrorAction Stop
        if($r.StatusCode -ge 200 -and $r.StatusCode -lt 400){ return $true }
    }catch{}
    try{
        $r2 = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec $TimeoutSec -ErrorAction Stop
        if($r2.StatusCode -ge 200 -and $r2.StatusCode -lt 400){ return $true }
    }catch{}
    foreach($h in @('www.microsoft.com','packages.broadcom.com','8.8.8.8')){
        try{ if((Test-NetConnection -ComputerName $h -Port 443 -WarningAction SilentlyContinue -InformationLevel Quiet)){ return $true } }catch{}
    }
    return $false
}

# Assert-YcPrereqs [-NeedAdmin] [-SelfElevate] [-NeedInternet] [-InternetUrl <s>] [-BoundParameters <hashtable>]
#   -NeedAdmin     require elevation (exit 5)
#   -SelfElevate   relaunch elevated. REQUIRES -BoundParameters $PSBoundParameters; without it
#                  the library refuses to relaunch and exits 5 rather than starting an
#                  argument-less child and reporting SUCCESS (v1's P0 defect).
#   -NeedInternet  require outbound internet (exit 6)
function Assert-YcPrereqs{
    param([switch]$NeedAdmin,[switch]$SelfElevate,[switch]$NeedInternet,
          [string]$InternetUrl='https://www.microsoft.com',
          [hashtable]$BoundParameters)
    Set-YcTls
    if($NeedAdmin -and -not (Test-YcAdmin)){
        if($SelfElevate){
            $spath = $MyInvocation.PSCommandPath
            if(-not $spath){ $spath = $script:YcScriptPath }
            if(-not $spath){ $spath = $script:MyScriptPath }
            if(-not $spath){
                Exit-Yc 5 'SelfElevate requested but the calling script path could not be determined - refusing to relaunch. Re-run from an elevated PowerShell.' 'ERROR'
            }
            if(-not $BoundParameters){
                Exit-Yc 5 ('SelfElevate requested WITHOUT -BoundParameters. Relaunching without the original arguments would start an argument-less elevated copy that prints usage and exits 1 while this copy reported success - refusing. Call: Assert-YcPrereqs -NeedAdmin -SelfElevate -BoundParameters $PSBoundParameters') 'ERROR'
            }
            $interactive = $true
            try{ $interactive = [Environment]::UserInteractive }catch{}
            if(-not $interactive){
                Exit-Yc 5 'SelfElevate is impossible in a non-interactive session (cloud-init / SYSTEM / RMM): -Verb RunAs has no desktop to prompt on. Run this command as Administrator.' 'ERROR'
            }
            $a = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $spath + '"'))
            foreach($k in $BoundParameters.Keys){
                if($k -eq 'BoundParameters'){ continue }
                $v = $BoundParameters[$k]
                if($v -is [System.Management.Automation.SwitchParameter]){
                    if($v.IsPresent){ $a += ('-' + $k) }
                }elseif($v -is [array]){
                    $items = @()
                    foreach($x in $v){ $items += ('"' + ([string]$x -replace '"','""') + '"') }
                    if($items.Count -gt 0){ $a += ('-' + $k); $a += ($items -join ',') }
                }else{
                    $a += ('-' + $k)
                    $a += ('"' + ([string]$v -replace '"','""') + '"')
                }
            }
            Write-YcLog ('Not elevated - relaunching as Administrator (accept the UAC prompt): ' + (Protect-YcSecret ($a -join ' '))) 'WARN'
            $child = $null
            try{
                $child = Start-Process -FilePath 'powershell.exe' -ArgumentList $a -Verb RunAs -Wait -PassThru -ErrorAction Stop
            }catch{
                Exit-Yc 5 ('Self-elevate failed: ' + $_.Exception.Message + '. Run this command as Administrator.') 'ERROR'
            }
            $cc = 5
            try{ $cc = [int]$child.ExitCode }catch{}
            if($cc -eq 0){ Exit-Yc 0 ('Elevated run completed (child exit=' + $cc + ').') 'OK' }
            Exit-Yc $cc ('Elevated run FAILED (child exit=' + $cc + ').') 'ERROR'
        }
        Exit-Yc 5 'This command must run as Administrator. Open PowerShell as administrator and re-run.' 'ERROR'
    }
    if($NeedInternet -and -not (Test-YcInternet -Url $InternetUrl)){
        Exit-Yc 6 ('No outbound internet (tested ' + $InternetUrl + '). Check egress/proxy and retry.') 'ERROR'
    }
    Write-YcLog 'Preflight OK'
}

# ------------------------------------------------------------------------------------
# v2 additions - the helpers 50 callers reimplemented badly or not at all
# ------------------------------------------------------------------------------------

# Assert-YcService [-Name] <string> [[-TimeoutSec] <int> = 60] [[-State] <string> = 'Running']
#                  [-StartIfStopped] [[-Because] <string>] [-Fatal]
#   Proves a service EXISTS and reaches $State within $TimeoutSec. Returns $true/$false and
#   logs the truth (never "assumed OK"). -Fatal turns a failure into Exit-Yc 7.
#   This is the post-condition 34 scripts omit - the difference between "the installer ran"
#   and "the agent is installed and running".
function Assert-YcService{
    param([string]$Name,[int]$TimeoutSec=60,[string]$State='Running',[switch]$StartIfStopped,[string]$Because,[switch]$Fatal)
    $why = ''
    if($Because){ $why = ' (' + $Because + ')' }
    if(-not $Name){
        Write-YcLog ('Assert-YcService called with no service name' + $why) 'ERROR'
        if($Fatal){ Exit-Yc 7 'Assert-YcService: no service name' 'ERROR' }
        return $false
    }
    $svc = $null
    try{ $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue }catch{ $svc = $null }
    if(-not $svc){
        Write-YcLog ("service '" + $Name + "' DOES NOT EXIST - the installer did not create it" + $why) 'ERROR'
        if($Fatal){ Exit-Yc 7 ("required service missing: " + $Name) 'ERROR' }
        return $false
    }
    if($StartIfStopped -and $State -eq 'Running' -and $svc.Status -ne 'Running'){
        try{ Start-Service -Name $Name -ErrorAction Stop }catch{ Write-YcLog ("could not start service '" + $Name + "': " + $_.Exception.Message) 'WARN' }
    }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $last = ''
    while($sw.Elapsed.TotalSeconds -lt $TimeoutSec){
        try{ $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue }catch{ $svc = $null }
        if(-not $svc){ break }
        $last = [string]$svc.Status
        if($last -eq $State){
            $st = ''
            try{ $st = ' / StartType ' + $svc.StartType }catch{}
            Write-YcLog ("service '" + $Name + "' is " + $last + $st + " after " + [int]$sw.Elapsed.TotalSeconds + "s" + $why) 'OK'
            return $true
        }
        Start-Sleep -Seconds 2
    }
    Write-YcLog ("service '" + $Name + "' did NOT reach " + $State + " within " + $TimeoutSec + "s (last state: " + $last + ")" + $why) 'ERROR'
    if($Fatal){ Exit-Yc 7 ("service not " + $State + ": " + $Name) 'ERROR' }
    return $false
}

# Test-YcService - alias-shaped wrapper for Assert-YcService, for call sites that read better
# as a test than as an assertion. Same contract, always non-fatal.
function Test-YcService{
    param([string]$Name,[string]$State='Running',[int]$TimeoutSec=60,[switch]$StartIfStopped)
    return (Assert-YcService -Name $Name -State $State -TimeoutSec $TimeoutSec -StartIfStopped:$StartIfStopped)
}

# Assert-YcFile [-Path] <string> [[-MinBytes] <long> = 1] [-RequireSignature]
#               [[-Because] <string>] [-Fatal]
#   A required file exists, is at least -MinBytes, and (optionally) carries a VALID Authenticode
#   signature. Returns $true/$false; -Fatal turns a failure into Exit-Yc 4.
function Assert-YcFile{
    param([string]$Path,[long]$MinBytes=1,[switch]$RequireSignature,[string]$Because,[switch]$Fatal)
    $why = ''
    if($Because){ $why = ' (' + $Because + ')' }
    if(-not $Path -or -not (Test-Path -LiteralPath $Path)){
        Write-YcLog ('required file MISSING: ' + $Path + $why) 'ERROR'
        if($Fatal){ Exit-Yc 4 ('required file missing: ' + $Path) 'ERROR' }
        return $false
    }
    $len = 0
    try{ $len = (Get-Item -LiteralPath $Path).Length }catch{}
    if($len -lt $MinBytes){
        Write-YcLog ('required file TOO SMALL: ' + $Path + ' is ' + $len + ' bytes, expected at least ' + $MinBytes + $why) 'ERROR'
        if($Fatal){ Exit-Yc 4 ('required file too small: ' + $Path) 'ERROR' }
        return $false
    }
    if($RequireSignature){
        $status = 'Unavailable'
        try{ $status = [string](Get-AuthenticodeSignature -LiteralPath $Path -ErrorAction Stop).Status }
        catch{ $status = 'Unavailable: ' + $_.Exception.Message }
        if($status -ne 'Valid'){
            Write-YcLog ('Authenticode signature on ' + $Path + ' is ' + $status + ' (expected Valid)' + $why) 'ERROR'
            if($Fatal){ Exit-Yc 4 ('unsigned or untrusted file: ' + $Path) 'ERROR' }
            return $false
        }
        Write-YcLog ('file OK: ' + $Path + ' (' + $len + ' bytes, Authenticode Valid)' + $why) 'OK'
        return $true
    }
    Write-YcLog ('file OK: ' + $Path + ' (' + $len + ' bytes)' + $why) 'OK'
    return $true
}

# Assert-YcHttp [-Uri] <string> [[-TimeoutSec] <int> = 60] [[-ExpectStatus] <int> = 200]
#               [[-MatchContent] <string>] [[-IntervalSec] <int> = 3] [-Fatal]
#   GETs $Uri until it answers $ExpectStatus (optionally containing $MatchContent) or the
#   timeout expires. Liveness proof for the exporter scripts: an installed windows_exporter
#   that is not serving /metrics is not a working windows_exporter.
function Assert-YcHttp{
    param([string]$Uri,[int]$TimeoutSec=60,[int]$ExpectStatus=200,[string]$MatchContent,[int]$IntervalSec=3,[switch]$Fatal)
    Set-YcTls
    if(-not $Uri){
        Write-YcLog 'Assert-YcHttp called with no URI' 'ERROR'
        if($Fatal){ Exit-Yc 8 'Assert-YcHttp: no URI' 'ERROR' }
        return $false
    }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $last = 'no response'
    while($sw.Elapsed.TotalSeconds -lt $TimeoutSec){
        try{
            $r = Invoke-WebRequest -Uri $Uri -UseBasicParsing -TimeoutSec 15 -ErrorAction Stop
            $last = 'HTTP ' + $r.StatusCode
            if([int]$r.StatusCode -eq $ExpectStatus){
                if($MatchContent){
                    $body = ''
                    try{ $body = [string]$r.Content }catch{}
                    if($body -like ('*' + $MatchContent + '*')){
                        Write-YcLog ($Uri + ' answered ' + $ExpectStatus + ' and contains "' + $MatchContent + '" after ' + [int]$sw.Elapsed.TotalSeconds + 's') 'OK'
                        return $true
                    }
                    $last = 'HTTP ' + $r.StatusCode + ' but body does not contain "' + $MatchContent + '"'
                }else{
                    Write-YcLog ($Uri + ' answered ' + $ExpectStatus + ' after ' + [int]$sw.Elapsed.TotalSeconds + 's') 'OK'
                    return $true
                }
            }
        }catch{
            $last = $_.Exception.Message
            try{
                $resp = $_.Exception.Response
                if($resp){ $last = 'HTTP ' + [int]$resp.StatusCode }
            }catch{}
        }
        Start-Sleep -Seconds $IntervalSec
    }
    Write-YcLog ($Uri + ' did NOT answer ' + $ExpectStatus + ' within ' + $TimeoutSec + 's (last: ' + $last + ')') 'ERROR'
    if($Fatal){ Exit-Yc 8 ('endpoint not healthy: ' + $Uri) 'ERROR' }
    return $false
}

# Internal. Returns 'PE' | 'MSI' | 'ZIP' | 'GZ' | '7Z' | 'CAB' | 'HTML' | 'TEXT' | 'EMPTY' | 'OTHER'
function Get-YcFileKind{
    param([string]$Path)
    try{
        $fs = New-Object System.IO.FileStream($Path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
        try{
            $n = [int][Math]::Min(512,$fs.Length)
            if($n -le 0){ return 'EMPTY' }
            $b = New-Object byte[] $n
            [void]$fs.Read($b,0,$n)
        }finally{ $fs.Close() }
    }catch{ return 'OTHER' }
    if($n -ge 2 -and $b[0] -eq 0x4D -and $b[1] -eq 0x5A){ return 'PE' }
    if($n -ge 8 -and $b[0] -eq 0xD0 -and $b[1] -eq 0xCF -and $b[2] -eq 0x11 -and $b[3] -eq 0xE0){ return 'MSI' }
    if($n -ge 2 -and $b[0] -eq 0x50 -and $b[1] -eq 0x4B){ return 'ZIP' }
    if($n -ge 2 -and $b[0] -eq 0x1F -and $b[1] -eq 0x8B){ return 'GZ' }
    if($n -ge 2 -and $b[0] -eq 0x37 -and $b[1] -eq 0x7A){ return '7Z' }
    if($n -ge 4 -and $b[0] -eq 0x4D -and $b[1] -eq 0x53 -and $b[2] -eq 0x43 -and $b[3] -eq 0x46){ return 'CAB' }
    $head = ''
    try{ $head = ([System.Text.Encoding]::ASCII.GetString($b)).TrimStart() }catch{}
    if($head -match '(?i)^\s*(<!doctype\s+html|<html|<\?xml|<head|<body)'){ return 'HTML' }
    if($head -match '(?i)<html|</html>|<title>'){ return 'HTML' }
    return 'TEXT'
}

# Get-YcFile [-Uri] <string> [-OutFile] <string> [[-Sha256] <string>] [[-Retries] <int> = 4]
#            [[-TimeoutSec] <int> = 300] [[-MinBytes] <long> = 1024] [-AllowText] [-Fatal]
#   Downloads with TLS 1.2 (1.3 where available) forced, retries with exponential backoff,
#   verifies SHA256 when supplied, and REFUSES an HTML error page saved with a .exe/.msi/.zip
#   name - the classic "the proxy returned a login page and we installed it" failure.
#   Returns the output path on success, $null on failure. -Fatal turns failure into Exit-Yc 9.
function Get-YcFile{
    param([string]$Uri,[string]$OutFile,[string]$Sha256,[int]$Retries=4,[int]$TimeoutSec=300,[long]$MinBytes=1024,[switch]$AllowText,[switch]$Fatal)
    Set-YcTls
    if(-not $Uri -or -not $OutFile){
        Write-YcLog 'Get-YcFile requires -Uri and -OutFile' 'ERROR'
        if($Fatal){ Exit-Yc 9 'Get-YcFile: bad arguments' 'ERROR' }
        return $null
    }
    $dir = Split-Path -Parent $OutFile
    if($dir -and -not (Test-Path -LiteralPath $dir)){ New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $safeUri = Protect-YcSecret $Uri
    $attempt = 0
    $delay   = 3
    while($attempt -lt $Retries){
        $attempt++
        if(Test-Path -LiteralPath $OutFile){ Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue }
        Write-YcLog ('download attempt ' + $attempt + '/' + $Retries + ': ' + $safeUri)
        $failed = $null
        try{
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -TimeoutSec $TimeoutSec -ErrorAction Stop
        }catch{
            $failed = $_.Exception.Message
        }
        if(-not $failed){
            $len = 0
            try{ $len = (Get-Item -LiteralPath $OutFile).Length }catch{}
            if($len -lt $MinBytes){
                $failed = 'downloaded ' + $len + ' bytes, expected at least ' + $MinBytes
            }else{
                $kind = Get-YcFileKind -Path $OutFile
                $ext  = ''
                try{ $ext = ([IO.Path]::GetExtension($OutFile)).ToLowerInvariant() }catch{}
                $binaryExt = @('.exe','.msi','.msu','.zip','.7z','.cab','.gz','.tgz','.dll')
                if($kind -eq 'HTML'){
                    $failed = 'the server returned an HTML page, not a file (proxy/captive portal/404 page saved as ' + $ext + ')'
                }elseif(($binaryExt -contains $ext) -and $kind -eq 'TEXT' -and -not $AllowText){
                    $failed = 'the downloaded content is plain text but the target is ' + $ext + ' - refusing to treat it as a binary'
                }
                if(-not $failed -and $Sha256){
                    $actual = ''
                    try{ $actual = (Get-FileHash -LiteralPath $OutFile -Algorithm SHA256 -ErrorAction Stop).Hash }catch{ $actual = '' }
                    if($actual -and ($actual.ToUpperInvariant() -eq $Sha256.ToUpperInvariant())){
                        Write-YcLog ('SHA256 verified: ' + $actual) 'OK'
                    }else{
                        Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
                        Write-YcLog ('SHA256 MISMATCH for ' + $safeUri + ' - expected ' + $Sha256 + ', got ' + $actual + '. Partial file deleted.') 'ERROR'
                        if($Fatal){ Exit-Yc 9 'download hash mismatch' 'ERROR' }
                        throw ('SHA256 mismatch for ' + $safeUri)
                    }
                }
                if(-not $failed){
                    Write-YcLog ('downloaded ' + $len + ' bytes to ' + $OutFile + ' (content looks like ' + $kind + ')') 'OK'
                    return $OutFile
                }
            }
        }
        Write-YcLog ('download failed (attempt ' + $attempt + '/' + $Retries + '): ' + $failed) 'WARN'
        if(Test-Path -LiteralPath $OutFile){ Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue }
        if($attempt -lt $Retries){ Start-Sleep -Seconds $delay; $delay = $delay * 2 }
    }
    Write-YcLog ('download of ' + $safeUri + ' FAILED after ' + $Retries + ' attempts') 'ERROR'
    if($Fatal){ Exit-Yc 9 ('download failed: ' + $safeUri) 'ERROR' }
    return $null
}

# Internal. Human meaning for an installer exit code.
function Get-YcExitMeaning{
    param([int]$Code)
    switch($Code){
        0       { return 'success' }
        1641    { return 'success - the installer initiated a reboot' }
        3010    { return 'success - a reboot is required to complete' }
        1        { return 'generic failure (many bootstrappers use 1 for "bad command line")' }
        2        { return 'ERROR_FILE_NOT_FOUND / installer aborted' }
        5        { return 'ERROR_ACCESS_DENIED - not elevated, or the target is locked' }
        1602    { return 'ERROR_INSTALL_USEREXIT - the installation was cancelled' }
        1603    { return 'ERROR_INSTALL_FAILURE - fatal error during installation' }
        1605    { return 'ERROR_UNKNOWN_PRODUCT - that product is not installed' }
        1618    { return 'ERROR_INSTALL_ALREADY_RUNNING - another installation is in progress' }
        1619    { return 'ERROR_INSTALL_PACKAGE_OPEN_FAILED - the package could not be opened' }
        1620    { return 'ERROR_INSTALL_PACKAGE_INVALID - the package is corrupt' }
        1622    { return 'ERROR_INSTALL_LOG_FAILURE - the log location is not writable' }
        1623    { return 'ERROR_INSTALL_LANGUAGE_UNSUPPORTED' }
        1624    { return 'ERROR_INSTALL_TRANSFORM_FAILURE' }
        1625    { return 'ERROR_INSTALL_PACKAGE_REJECTED - system policy forbids this install' }
        1633    { return 'ERROR_INSTALL_PLATFORM_UNSUPPORTED - wrong architecture' }
        1638    { return 'ERROR_PRODUCT_VERSION - another version of this product is already installed' }
        1639    { return 'ERROR_INVALID_COMMAND_LINE - the installer rejected a switch' }
        1642    { return 'ERROR_PATCH_TARGET_NOT_FOUND' }
        6452566 { return 'ACRONIS: the installer REJECTED the command line (unknown or malformed switch). Nothing was installed. This is the failure the --log= switch produced.' }
        6452565 { return 'ACRONIS: installation failed - see the Acronis bootstrapper log' }
        29949963 { return 'ACRONIS 0x1C9000B: the command line was ACCEPTED and the agent installed, but REGISTRATION FAILED, so the MSI rolled back (result 1603). The token is wrong, expired, already consumed, or issued for a different data centre. Get a fresh token from the Acronis console and check -Url matches the tenant.' }
        7       { return 'NSIS/Salt: installation aborted' }
        -196608 { return 'powershell.exe -File pointed at a script that does not exist' }
    }
    if($Code -lt 0){ return ('negative/native exit code 0x' + ('{0:X8}' -f $Code)) }
    return 'unrecognised installer exit code'
}

# Invoke-YcInstaller [-FilePath] <string> [-ArgumentList] <string[]> [[-SuccessCodes] <int[]> = 0]
#                    [[-RebootCodes] <int[]> = 3010,1641] [[-TimeoutSec] <int> = 1800]
#                    [[-MinSeconds] <int> = 0] [[-WorkingDirectory] <string>] [-Fatal]
#   Runs an installer, waits with a TIMEOUT (killing it if it hangs), captures the exit code,
#   decodes it, logs the ARGUMENT LIST WITH SECRETS REDACTED, and returns a result OBJECT:
#     @{ FilePath; Arguments; ExitCode; Status; Success; RebootRequired; DurationSec; TimedOut; Meaning }
#   Status is Success | SuccessRebootRequired | Failed | TimedOut | Suspicious.
#   'Suspicious' is returned when the installer reports success but finished faster than
#   -MinSeconds: a web bootstrapper that exits in 4 seconds did not download and install
#   anything, which is exactly the Acronis signature nothing in v1 could see.
#   -Fatal calls Exit-Yc with the installer's own exit code on anything that is not success.
function Invoke-YcInstaller{
    param(
        [string]$FilePath,
        [string[]]$ArgumentList,
        [int[]]$SuccessCodes=@(0),
        [int[]]$RebootCodes=@(3010,1641),
        [int]$TimeoutSec=1800,
        [int]$MinSeconds=0,
        [string]$WorkingDirectory,
        [switch]$Fatal
    )
    $argStr  = ''
    if($ArgumentList){ $argStr = ($ArgumentList -join ' ') }
    $safeArg = Protect-YcSecret $argStr
    $res = [pscustomobject]@{
        FilePath       = $FilePath
        Arguments      = $safeArg
        ExitCode       = -1
        Status         = 'Failed'
        Success        = $false
        RebootRequired = $false
        DurationSec    = 0
        TimedOut       = $false
        Meaning        = ''
    }
    if(-not $FilePath -or -not (Test-Path -LiteralPath $FilePath)){
        $res.Meaning = 'installer not found: ' + $FilePath
        Write-YcLog $res.Meaning 'ERROR'
        if($Fatal){ Exit-Yc 4 $res.Meaning 'ERROR' }
        return $res
    }
    Write-YcLog ('running installer: ' + $FilePath + ' ' + $safeArg)
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $proc = $null
    try{
        $sp = @{ FilePath = $FilePath; PassThru = $true; ErrorAction = 'Stop' }
        if($ArgumentList -and $ArgumentList.Count -gt 0){ $sp['ArgumentList'] = $ArgumentList }
        if($WorkingDirectory){ $sp['WorkingDirectory'] = $WorkingDirectory }
        $proc = Start-Process @sp
    }catch{
        $sw.Stop()
        $res.Meaning = 'could not start the installer: ' + $_.Exception.Message
        $res.DurationSec = [int]$sw.Elapsed.TotalSeconds
        Write-YcLog $res.Meaning 'ERROR'
        if($Fatal){ Exit-Yc 4 $res.Meaning 'ERROR' }
        return $res
    }
    $exited = $false
    try{ $exited = $proc.WaitForExit($TimeoutSec * 1000) }catch{ $exited = $false }
    $sw.Stop()
    $res.DurationSec = [int]$sw.Elapsed.TotalSeconds
    if(-not $exited){
        $res.TimedOut = $true
        $res.Status   = 'TimedOut'
        $res.Meaning  = 'the installer did not exit within ' + $TimeoutSec + 's and was killed'
        try{ Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }catch{}
        Write-YcLog ('installer TIMEOUT after ' + $res.DurationSec + 's: ' + $FilePath) 'ERROR'
        if($Fatal){ Exit-Yc 10 $res.Meaning 'ERROR' }
        return $res
    }
    $code = -1
    try{ $code = [int]$proc.ExitCode }catch{ $code = -1 }
    $res.ExitCode = $code
    $res.Meaning  = Get-YcExitMeaning $code

    if($RebootCodes -contains $code){
        $res.Success = $true; $res.RebootRequired = $true; $res.Status = 'SuccessRebootRequired'
    }elseif($SuccessCodes -contains $code){
        $res.Success = $true; $res.Status = 'Success'
    }else{
        $res.Success = $false; $res.Status = 'Failed'
    }

    if($res.Success -and $MinSeconds -gt 0 -and $res.DurationSec -lt $MinSeconds){
        $res.Status  = 'Suspicious'
        $res.Success = $false
        $res.Meaning = ('exit code ' + $code + ' (' + $res.Meaning + ') but the installer finished in ' + $res.DurationSec + 's, under the ' + $MinSeconds + 's minimum for this package - it almost certainly rejected the command line and installed nothing')
    }

    $lvl = 'ERROR'
    if($res.Status -eq 'Success'){ $lvl = 'OK' }
    elseif($res.Status -eq 'SuccessRebootRequired'){ $lvl = 'WARN' }
    elseif($res.Status -eq 'Suspicious'){ $lvl = 'ERROR' }
    Write-YcLog ('installer ' + (Split-Path -Leaf $FilePath) + ' -> exit ' + $code + ' [' + $res.Status + '] in ' + $res.DurationSec + 's: ' + $res.Meaning) $lvl

    if($Fatal -and -not $res.Success){
        $ec = $code
        if($ec -eq 0){ $ec = 1 }
        Exit-Yc $ec ('installer FAILED: ' + (Split-Path -Leaf $FilePath) + ' -> ' + $res.Meaning) 'ERROR'
    }
    return $res
}

# ------------------------------------------------------------------------------------
# WEBHOOK MILESTONES (lib 2.1.0)
#   Every action script reports how its run ended - to the ERP webhook, to the optional second
#   webhook and to ntfy - so nobody has to open a log to find out. The hook is in Stop-YcLog, the
#   one exit path every script already takes, so no script had to be edited to get it.
#
#   Settings, first non-empty wins:
#     1. variables in the calling script: $ErpWebhookUrl  $ErpWebhookSecret  $ExtraWebhookUrl  $ExtraWebhookSecret
#     2. environment: ERP_WEBHOOK_URL  ERP_WEBHOOK_SECRET  EXTRA_WEBHOOK_URL  EXTRA_WEBHOOK_SECRET
#     3. C:\ProgramData\YallaCloud\yc-event.json (url, secret, token, extraUrl, extraSecret)
#   The ERP url defaults to the public ERP endpoint. A webhook is only posted to when its secret
#   is known; with no secrets anywhere no webhook is posted to.
#   ntfy: $NtfyServer / $NtfyTopic / $NtfyToken, env NTFY_SERVER / NTFY_TOPIC / NTFY_TOKEN, else
#   yc-event.json "ntfy" / "ntfyToken", else topic 9890122212 on OUR server https://n.oasisstack.io
#   when a token is known (it refuses anonymous posts - the token is a write token, sent as
#   Authorization: Bearer), and on public https://ntfy.sh when none is, so an alert is never lost
#   for want of a token. NTFY_TOPIC=off turns it off. A phone is not a log: ntfy gets the
#   states a human must act on (failed, waiting, waitforhuman) and the final word of a whole run
#   (-Ntfy always); a nightly "ok" is not pushed.
#
#   Transport: HTTPS POST, flat JSON, header X-Webhook-Secret. One try per webhook, 15 s, the
#   second webhook first and then the ERP. It never throws and never changes an exit code.
#   The body carries no secret: secret-shaped text in the error is replaced with REDACTED.
#   Body: type vm.<area>.<state>, vmId, hostname, ip, os, error, lastUpdated (Dubai, +04), extra.
#
#   ONE PLACE FOR EVERY OUTCOME ON THE VM. Whatever the network does, every milestone is also
#   written - always, settings or not - to:
#     C:\ProgramData\YallaCloud\logs\yc-milestones.log   one line per milestone, every command
#     the Application event log, source YallaCloud: 1700 ok, 1701 failed, 1702 needs a human
#     the command's own log (C:\Scripts\<command>.log), the same line
#   The line is built to be searched. Fixed keywords, then key=value:
#     2026-10-28 10:15:02 +04 [YALLACLOUD][YC-MILESTONE][YC-FAILED] type=vm.acronis.failed
#       area=acronis state=failed host=WEB01 vmId=<uuid> by="acronis-register payload 2.45.0"
#       error="exit 4: ..." sent=extra:202,erp:200,ntfy:200
#   Find every failure on a box:  Select-String C:\ProgramData\YallaCloud\logs\yc-milestones.log -Pattern YC-FAILED
#   The same keywords are used by the adopt script and the pre-migration check, and by the
#   Linux kits' own logs, so one search pattern works across the estate.
#   Not sent for read-only runs (-Help -Report -Status -Check -SelfCheck -DryRun -WhatIf ...),
#   for read-only commands (compliance, inventory, diagnostics) or for commands that report for
#   themselves (yc-event, the adopt script, salt-join whose join line reports vm.salt.*).
# ------------------------------------------------------------------------------------
$script:YcErpDefaultUrl = 'https://api.yallacloud.net/api/v1/webhooks/cloudstack'
$script:YcMsCfgFile   = 'C:\ProgramData\YallaCloud\yc-event.json'
$script:YcNtfyDefault   = 'https://ntfy.sh/9890122212'      # no token: public ntfy
$script:YcNtfyOwn       = 'https://n.oasisstack.io'         # token: our own server (2026-10-31)
$script:YcJournalFile   = 'C:\ProgramData\YallaCloud\logs\yc-milestones.log'
$script:YcMsSkipTags  = @('yc-event','yc-compliance','yc-integrity','report-inventory','diag','rootcause',
                            'collect-logs','vss-check','licence-report','yc-health','yallacloud','command-name',
                            'adopt-migrated-vm','salt-join','passgen','yc-keyguard')
$script:YcMsReadOnly  = @('Help','Report','Status','Check','SelfCheck','DryRun','WhatIf','List','Show',
                            'Test','Plan','Preview','Audit','Info','Version','Diagnose')

function Get-YcMsFirst{
    param([object[]]$Values)
    foreach($v in @($Values)){ if($null -ne $v -and ([string]$v).Trim()){ return ([string]$v).Trim() } }
    return ''
}

# Pure: settings from the three sources. -Vars and -Env are hashtables so a test can feed them.
function Resolve-YcMsConfig{
    param([hashtable]$Vars,[hashtable]$Env,$Json)
    $jv = @{}
    if($Json){ foreach($k in 'url','secret','token','extraUrl','extraSecret','ntfy','ntfyToken'){ if($Json.$k){ $jv[$k] = [string]$Json.$k } } }
    $c = @{
        erpUrl      = Get-YcMsFirst @($Vars.ErpWebhookUrl,      $Env.ERP_WEBHOOK_URL,      $jv.url, $script:YcErpDefaultUrl)
        erpSecret   = Get-YcMsFirst @($Vars.ErpWebhookSecret,   $Env.ERP_WEBHOOK_SECRET,   $jv.secret)
        erpToken    = Get-YcMsFirst @($jv.token)
        extraUrl    = Get-YcMsFirst @($Vars.ExtraWebhookUrl,    $Env.EXTRA_WEBHOOK_URL,    $jv.extraUrl)
        extraSecret = Get-YcMsFirst @($Vars.ExtraWebhookSecret, $Env.EXTRA_WEBHOOK_SECRET, $jv.extraSecret)
    }
    # ntfy: an explicit topic wins, then yc-event's configured url, then the estate default.
    $c.ntfyToken = Get-YcMsFirst @($Vars.NtfyToken, $Env.NTFY_TOKEN, $jv.ntfyToken)
    $topic  = Get-YcMsFirst @($Vars.NtfyTopic, $Env.NTFY_TOPIC)
    $server = Get-YcMsFirst @($Vars.NtfyServer, $Env.NTFY_SERVER)
    if(-not $server){ $server = $(if($c.ntfyToken){ $script:YcNtfyOwn } else { 'https://ntfy.sh' }) }
    $server = $server.TrimEnd('/')
    if($topic -eq 'off'){ $c.ntfyUrl = '' }
    elseif($topic){ $c.ntfyUrl = $(if($topic -match '^[A-Za-z0-9_-]{1,64}$'){ $server + '/' + $topic } else { '' }) }
    elseif($jv.ntfy){ $c.ntfyUrl = $jv.ntfy }
    else{ $c.ntfyUrl = $server + '/9890122212' }
    foreach($k in 'erpUrl','extraUrl','ntfyUrl'){ if($c[$k] -and $c[$k] -notmatch '^https://[^\s"'']+$'){ $c[$k] = '' } }
    return $c
}

function Get-YcMsConfig{
    $vars = @{}
    foreach($n in 'ErpWebhookUrl','ErpWebhookSecret','ExtraWebhookUrl','ExtraWebhookSecret','NtfyServer','NtfyTopic','NtfyToken'){
        $x = Get-Variable -Name $n -ValueOnly -ErrorAction SilentlyContinue
        if($x){ $vars[$n] = [string]$x }
    }
    $envs = @{ ERP_WEBHOOK_URL = $env:ERP_WEBHOOK_URL; ERP_WEBHOOK_SECRET = $env:ERP_WEBHOOK_SECRET
               EXTRA_WEBHOOK_URL = $env:EXTRA_WEBHOOK_URL; EXTRA_WEBHOOK_SECRET = $env:EXTRA_WEBHOOK_SECRET
               NTFY_SERVER = $env:NTFY_SERVER; NTFY_TOPIC = $env:NTFY_TOPIC; NTFY_TOKEN = $env:NTFY_TOKEN }
    $j = $null
    try{ if(Test-Path -LiteralPath $script:YcMsCfgFile){ $j = (Get-Content -LiteralPath $script:YcMsCfgFile -Raw) | ConvertFrom-Json } }catch{ $j = $null }
    return (Resolve-YcMsConfig -Vars $vars -Env $envs -Json $j)
}

# Pure: one line, at most 300 characters, every known secret and every secret-shaped value gone.
function ConvertTo-YcMsError{
    param([string]$Text,[string[]]$Secrets)
    if(-not $Text){ return '' }
    $t = ($Text -replace '\s+',' ').Trim()
    foreach($s in @($Secrets)){ if($s -and $s.Length -ge 4){ $t = $t.Replace($s,'REDACTED') } }
    $t = [regex]::Replace($t,'(?i)\b(password|passwd|pwd|secret|token|apikey|api[_-]?key|dsn|connectionstring|productkey|key)(\s*[=:]\s*)("[^"]*"|''[^'']*''|\S+)','${1}${2}REDACTED')
    if($t.Length -gt 300){ $t = $t.Substring(0,297) + '...' }
    return $t
}

# Pure: the flat body - the event head (2.47.7) first, then the agreed eight keys.
# Area and state are reduced to [a-z0-9-] and [a-z].
function New-YcMsBody{
    param([string]$Area,[string]$State,[string]$Err,[string]$Tag,[hashtable]$Id,[datetime]$UtcNow = [datetime]::UtcNow,
          [string]$DeployId = '-',[int]$Seq = 0,[string]$Detail = $null,[string]$KitVersion = '')
    $a = ([string]$Area).ToLower() -replace '[^a-z0-9-]',''
    $s = ([string]$State).ToLower() -replace '[^a-z]',''
    $nm = $(if($Id.vmName){ [string]$Id.vmName } else { ([string]$Id.hostname).ToLower() })
    $h = New-YcEventHead -DeployId $DeployId -Type ('vm.' + $a + '.' + $s) -Seq $Seq -VmName $nm -VmUuid ([string]$Id.vmId) -Ip ([string]$Id.ip) `
                         -Kit 'payload' -KitVersion $KitVersion -Detail $(if($null -ne $Detail){ $Detail } else { $Err }) -UtcNow $UtcNow
    return Join-YcEventHead -Head $h -Body ([ordered]@{
        type        = ('vm.' + $a + '.' + $s)
        vmId        = [string]$Id.vmId
        hostname    = [string]$Id.hostname
        ip          = [string]$Id.ip
        os          = [string]$Id.os
        error       = [string]$Err
        lastUpdated = ($UtcNow.AddHours(4).ToString('yyyy-MM-dd HH:mm:ss') + ' +04')
        extra       = [string]$Tag
    })
}

# Pure: which area a command reports as; '' = this command does not report.
function Get-YcMsArea{
    param([string]$Tag)
    $t = ([string]$Tag).ToLower()
    if(-not $t -or $script:YcMsSkipTags -contains $t){ return '' }
    switch($t){
        'acronis-register' { return 'acronis' }
        'set-local-wsus'   { return 'wsus' }
        'activate-windows' { return 'license' }
        'activate-sql'     { return 'sqllicense' }
        'install-sql'      { return 'sql' }
        'fix-deploy'       { return 'fixdeploy' }
        'glpi-join'        { return 'glpi' }
    }
    $a = ($t -replace '[^a-z0-9-]','')
    if($a -eq 'deploy'){ return '' }     # vm.deploy.* is the ERP's build lifecycle; only a build sends it
    return $a
}

# Pure: the state for an exit code. 3010 / 1641 are Windows' "done, reboot to finish".
function Get-YcMsState{
    param([string]$Area,[int]$Code)
    if($Area -eq 'acronis'){
        if($Code -eq 0){ return 'registered' }
        if($Code -eq 3){ return 'waitforhuman' }      # installed and running, the installer wants a reboot
        return 'failed'
    }
    if($Area -eq 'wsus'){
        if($Code -eq 0){ return 'ok' }
        if($Code -eq 6){ return 'waitforhuman' }      # already on ANOTHER update server - left as it is
        if($Code -eq 7){ return 'waiting' }           # local server did not answer - stays on Microsoft
        return 'failed'
    }
    if($Area -eq 'glpi'){
        if($Code -eq 0){ return 'registered' }
        if($Code -eq 8){ return 'waiting' }           # VM not known to CloudStack yet
        return 'failed'
    }
    if(@(0,3010,1641) -contains $Code){ return 'ok' }
    return 'failed'
}

function Test-YcMsReadOnly{
    param([string[]]$Names)
    foreach($n in @($Names)){ if($script:YcMsReadOnly -contains $n){ return $true } }
    return $false
}

function Get-YcMsIdentity{
    if($script:YcMsId){ return $script:YcMsId }
    $id = @{ vmId = ''; hostname = (Get-YcMsFirst @($env:COMPUTERNAME, [Environment]::MachineName)); ip = ''; os = '' }
    # yc-event's resolved identity first: it is what the ERP already knows this VM as.
    try{
        $f = 'C:\ProgramData\YallaCloud\vm-facts.json'
        if(Test-Path -LiteralPath $f){ $v = [string](((Get-Content -LiteralPath $f -Raw) | ConvertFrom-Json).vmId); if($v -match '^[0-9a-fA-F-]{36}$'){ $id.vmId = $v.ToLower() } }
    }catch{}
    if(-not $id.vmId){
        try{
            $u = [string](Get-CimInstance Win32_ComputerSystemProduct -ErrorAction Stop).UUID
            if($u -match '^[0-9a-fA-F-]{36}$' -and $u -notmatch '^[0-]+$' -and $u -notmatch '^[fF-]+$'){ $id.vmId = $u.ToLower() }
        }catch{}
    }
    if(-not $id.vmId){ $id.vmId = $id.hostname }
    try{
        $id.ip = [string](@(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' -ErrorAction Stop |
                  ForEach-Object { $_.IPAddress } | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' -and $_ -notlike '127.*' -and $_ -notlike '169.254.*' }) | Select-Object -First 1)
    }catch{}
    try{ $id.os = [string](Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).Caption }catch{}
    $script:YcMsId = $id
    return $id
}

function Get-YcMsTag{
    $v = ''
    try{
        $f = 'C:\Scripts\yc-payload-version.txt'
        if(Test-Path -LiteralPath $f){ $m = Select-String -LiteralPath $f -Pattern '^payload_version\s*=\s*(\S+)' | Select-Object -First 1; if($m){ $v = $m.Matches[0].Groups[1].Value } }
    }catch{}
    return ([string]$script:YcTag + $(if($v){ ' payload ' + $v } else { '' }))
}

function Send-YcMsPost{
    param([string]$Url,[hashtable]$Headers,[string]$Json)
    try{
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $r = Invoke-WebRequest -Uri $Url -Method Post -Body $Json -Headers $Headers -ContentType 'application/json' -UseBasicParsing -TimeoutSec 15 -ErrorAction Stop
        return [string][int]$r.StatusCode
    }catch{
        $c = ''
        try{ if($_.Exception.Response){ $c = [string][int]$_.Exception.Response.StatusCode } }catch{}
        if($c){ return $c }
        return 'no answer'
    }
}

# Pure: the keyword for a state. Three, so a search for one finds every command's result.
function Get-YcMsKeyword{
    param([string]$State)
    $s = ([string]$State).ToLower()
    if($s -eq 'failed'){ return 'YC-FAILED' }
    if(@('waiting','waitforhuman') -contains $s){ return 'YC-WAITING' }
    return 'YC-OK'
}

# Pure: the journal line. Values are quoted where they can contain spaces; quotes inside are dropped.
function Format-YcMsLine{
    param($Body,[string]$Sent)
    $st = ([string]$Body.type -split '\.')[-1]
    $area = (([string]$Body.type -split '\.') | Select-Object -Skip 1 -First 1)
    $q = { param($v) '"' + ([string]$v -replace '"','') + '"' }
    return ($Body.lastUpdated + ' [YALLACLOUD][YC-MILESTONE][' + (Get-YcMsKeyword $st) + '] type=' + $Body.type +
            ' area=' + $area + ' state=' + $st + ' host=' + $Body.hostname + ' vmId=' + $Body.vmId + ' ip=' + $Body.ip +
            $(if($Body.Contains('deploymentId')){ ' deployment=' + $Body.deploymentId + ' seq=' + $Body.seq } else { '' }) +
            ' by=' + (& $q $Body.extra) + ' error=' + (& $q $Body.error) + ' sent=' + $(if($Sent){ $Sent } else { 'none' }))
}

function Write-YcMsJournal{
    # $script:YcJournalFile '' = no file (the pre-migration check writes nothing outside its
    # report). $script:YcMsSink = a scriptblock { param($line,$keyword) } for a script that has
    # its own logger; otherwise the house Write-YcLog.
    param($Body,[string]$Sent)
    $line = Format-YcMsLine -Body $Body -Sent $Sent
    $kw = Get-YcMsKeyword (([string]$Body.type -split '\.')[-1])
    if($script:YcJournalFile){
        try{
            $d = Split-Path -Parent $script:YcJournalFile
            if(-not (Test-Path -LiteralPath $d)){ New-Item -ItemType Directory -Path $d -Force | Out-Null }
            if((Test-Path -LiteralPath $script:YcJournalFile) -and (Get-Item -LiteralPath $script:YcJournalFile).Length -gt 5MB){
                Move-Item -LiteralPath $script:YcJournalFile -Destination ($script:YcJournalFile + '.1') -Force -ErrorAction SilentlyContinue
            }
            Add-Content -LiteralPath $script:YcJournalFile -Value $line -Encoding ascii -ErrorAction Stop
        }catch{}
    }
    $lv = switch($kw){ 'YC-FAILED' {'ERROR'} 'YC-WAITING' {'WARN'} default {'OK'} }
    if($script:YcMsSink){ try{ & $script:YcMsSink $line $kw }catch{} }
    else{ try{ Write-YcLog $line $lv }catch{} }
    try{
        $id = switch($kw){ 'YC-FAILED' {1701} 'YC-WAITING' {1702} default {1700} }
        Write-YcEvent $line $(if($lv -eq 'OK'){ 'INFO' } else { $lv }) $id
    }catch{}
}

# Pure: should this state reach a phone? auto = only what a human must act on.
function Test-YcMsNtfy{
    param([string]$State,[string]$Mode = 'auto')
    if($Mode -eq 'always'){ return $true }
    if($Mode -eq 'never'){ return $false }
    return (@('failed','waiting','waitforhuman') -contains ([string]$State).ToLower())
}

# Pure: words a non-technical reader understands, for an area and for a state.
function Get-YcMsLabel{
    param([string]$Area)
    $a = ([string]$Area).ToLower()
    $known = @{
        'salt'='Salt management agent'; 'salt-register'='Salt agent install'; 'acronis'='Acronis backup agent'
        'wsus'='Windows Update (local WSUS)'; 'winupdate'='Windows Update'; 'license'='Windows licence'
        'sqllicense'='SQL Server licence'; 'sql'='SQL Server install'; 'fixdeploy'='Deployment fixes'
        'backup-sql'='SQL backup'; 'restore-sql'='SQL restore'; 'premig'='Pre-migration check'; 'adopt'='Adoption of a migrated VM'
        'deploy'='VM deployment'; 'glpi'='GLPI inventory agent'; 'grow-disk'='Disk extension'; 'set-firewall'='Firewall rules'; 'set-time'='Time sync'
        'rotate-password'='Password rotation'; 'vmware-tools'='VMware Tools'; 'install-dotnet'='.NET install'
    }
    if($known.ContainsKey($a)){ return $known[$a] }
    if($a -like 'adopt-*'){ return ('Adopt step: ' + $a.Substring(6)) }
    if($a -like 'premig-*'){ return ('Pre-migration: ' + $a.Substring(7)) }
    if($a -like 'fixdeploy-*'){ return ('Deployment fix: ' + $a.Substring(10)) }
    return $a
}
function Get-YcMsStateWords{
    param([string]$State)
    switch(([string]$State).ToLower()){
        'failed'       { return 'FAILED - action needed' }
        'waiting'      { return 'WAITING - will retry by itself' }
        'waitforhuman' { return 'NEEDS A HUMAN - read the reason' }
        'joined'       { return 'OK - joined' }
        'registered'   { return 'OK - registered' }
        'completed'    { return 'COMPLETED' }
        'backtogreen'  { return 'BACK TO GREEN' }
    }
    return 'OK'
}

# Pure: title / priority / tags / text for the ntfy push. Built for two readers: the first line
# and the title tell anyone what happened; the labelled block below tells an engineer where.
function New-YcMsNtfy{
    param($Body,[string]$Log = '')
    $st   = ([string]$Body.type -split '\.')[-1]
    $area = (([string]$Body.type -split '\.') | Select-Object -Skip 1 -First 1)
    $what = Get-YcMsLabel $area
    $p = '3'; $tg = 'white_check_mark'
    if($st -eq 'failed'){ $p = '5'; $tg = 'rotating_light' }
    elseif(@('waiting','waitforhuman') -contains $st){ $p = '4'; $tg = 'warning' }
    $did = $(if($Body.Contains('deploymentId')){ [string]$Body.deploymentId } else { '-' })
    $lines = @(
        ('deployment : ' + $did),
        ('RESULT   ' + (Get-YcMsStateWords $st)),
        ('WHAT     ' + $what),
        ('MACHINE  ' + $Body.hostname + '  ' + $Body.ip),
        ('OS       ' + $Body.os)
    )
    if($Body.error){ $lines += ('WHY      ' + $Body.error) }
    $lines += ('WHEN     ' + ($Body.lastUpdated -replace ' \+04$',' Dubai'))
    $lines += ('VM ID    ' + $Body.vmId)
    $lines += ('BY       ' + $Body.extra)
    $lines += ('EVENT    ' + $Body.type)
    if($Log){ $lines += ('LOG      ' + $Log) }
    if($st -eq 'failed'){ $lines += 'NEXT     read the LOG line above on the VM; every result is also in C:\ProgramData\YallaCloud\logs\yc-milestones.log' }
    return @{ title = ((Get-YcMsStateWords $st).Split(' ')[0] + ': ' + $what + ' - ' + $Body.hostname + ' | ' + $did); priority = $p; tags = $tg; text = ($lines -join "`n") }
}

function Send-YcMsNtfy{
    param([string]$Url,$Body,[string]$Log = '',[string]$Token = '',[hashtable]$Message = $null)
    try{
        $n = $(if($Message){ $Message } else { New-YcMsNtfy -Body $Body -Log $Log })
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $h = @{ Title = $n.title; Priority = $n.priority; Tags = $n.tags }
        if($Token){ $h['Authorization'] = 'Bearer ' + $Token }
        $r = Invoke-WebRequest -Uri $Url -Method Post -Body $n.text -ContentType 'text/plain' -UseBasicParsing -TimeoutSec 15 -ErrorAction Stop -Headers $h
        return [string][int]$r.StatusCode
    }catch{
        $c = ''
        try{ if($_.Exception.Response){ $c = [string][int]$_.Exception.Response.StatusCode } }catch{}
        if($c){ return $c }
        return 'no answer'
    }
}

# Send-YcMilestone -Area salt -State joined [-Err 'text'] [-Tag 'script version']
#   The one sender. Safe to call from anywhere: no settings = no-op, never throws.
#   2.47.7: every body starts with the event head (deploymentId, seq ...); an agent area (salt,
#   glpi, acronis, wsus) sends ONE final status on all channels, ntfy included, only when the result
#   changed; on a portal-built VM a copy goes to the portal's stage table.
function Send-YcMilestone{
    param([string]$Area,[string]$State,[string]$Err = '',[string]$Tag = '',[ValidateSet('auto','always','never')][string]$Ntfy = 'auto',[string]$LogPath = '')
    try{
        if(-not $Area -or -not $State){ return }
        $c = Get-YcMsConfig
        $agent = Test-YcAgentArea $Area
        $final = (@('ok','failed','waiting') -contains (Get-YcHeadStatus $State))
        if(-not $Tag){ $Tag = Get-YcMsTag }
        if(-not $LogPath -and $script:YcLogFile){ $LogPath = [string]$script:YcLogFile }
        $e = ConvertTo-YcMsError -Text $Err -Secrets @($c.erpSecret,$c.erpToken,$c.extraSecret,$c.ntfyToken,$env:GLPI_AGENT_PASSWORD)
        $d = $e
        if($agent -and $Area -eq 'acronis'){ $d = ConvertTo-YcMsError -Text ((@($e, (Get-YcAcronisDetail)) | Where-Object { $_ }) -join '; ') -Secrets @($c.erpSecret,$c.extraSecret,$c.ntfyToken) }
        $did = Get-YcDeployId
        $kv = ''; if($Tag -match 'payload (\S+)'){ $kv = $Matches[1] }
        $b = New-YcMsBody -Area $Area -State $State -Err $(if($agent){ $d } else { $e }) -Tag $Tag -Id (Get-YcMsIdentity) -DeployId $did -Seq (Get-YcNextSeq) -Detail $d -KitVersion $kv
        $toExtra = [bool]($c.extraUrl -and $c.extraSecret)
        $toErp   = [bool]($c.erpUrl -and ($c.erpSecret -or $c.erpToken))
        # an agent result counts as reported only when there is somewhere to report it to
        if($agent -and $final -and ($toExtra -or $toErp -or $c.ntfyUrl) -and -not (Test-YcAgentChanged -Area $Area -State $State)){
            Write-YcMsJournal -Body $b -Sent 'unchanged'
            return
        }
        $mode = $Ntfy; if($agent -and $Ntfy -eq 'auto'){ $mode = $(if($final){ 'always' } else { 'never' }) }
        $toNtfy  = [bool]($c.ntfyUrl -and (Test-YcMsNtfy -State $State -Mode $mode))
        $json = ([pscustomobject]$b) | ConvertTo-Json -Compress -Depth 4
        $res = @()
        if($toExtra){ $res += ('extra ' + (Send-YcMsPost -Url $c.extraUrl -Headers @{ 'X-Webhook-Secret' = $c.extraSecret } -Json $json)) }
        if($toErp){
            $h = @{}
            if($c.erpSecret){ $h['X-Webhook-Secret'] = $c.erpSecret }
            if($c.erpToken){ $h['Authorization'] = 'Bearer ' + $c.erpToken }
            $res += ('erp ' + (Send-YcMsPost -Url $c.erpUrl -Headers $h -Json $json))
        }
        $rp = Send-YcMsReport -Json $json; if($rp){ $res += ('portal ' + $rp) }
        if($toNtfy){
            $msg = $null
            if($agent){ $msg = New-YcAgentNtfy -Area $Area -State $State -Detail $d -DeployId $did -Host_ $b.hostname -VmId $b.vmId -Ip $b.ip -When (Get-YcAgentWhen) -Log $LogPath -By $Tag }
            $res += ('ntfy ' + (Send-YcMsNtfy -Url $c.ntfyUrl -Body $b -Log $LogPath -Token $c.ntfyToken -Message $msg))
        }
        Write-YcMsJournal -Body $b -Sent ((@($res) | ForEach-Object { ($_ -replace 'no answer','noanswer') -replace ' ',':' }) -join ',')
    }catch{}
}

# Called from Stop-YcLog: one event for the run, unless it was read-only or reports for itself.
function Send-YcRunMilestone{
    param([int]$Code)
    if($script:YcMsSent){ return }
    $script:YcMsSent = $true
    if(Test-YcMsReadOnly $script:YcBoundNames){ return }
    $a = Get-YcMsArea $script:YcTag
    if(-not $a){ return }
    $st = Get-YcMsState -Area $a -Code $Code
    $e = ''
    if(@('ok','registered','joined') -notcontains $st){ $e = ('exit ' + $Code + $(if($script:YcLastMessage){ ': ' + $script:YcLastMessage } else { '' })) }
    Send-YcMilestone -Area $a -State $st -Err $e
}

# Save-YcMsConfig: copies the webhook settings given to THIS run (variables / environment) into
# yc-event.json, so yc-event and every later day-2 run on this VM report too. Only the keys that
# were given are written; the rest of the file is kept. SYSTEM + Administrators only.
function Save-YcMsConfig{
    try{
        $given = @{}
        $map = @{ url = @('ErpWebhookUrl','ERP_WEBHOOK_URL'); secret = @('ErpWebhookSecret','ERP_WEBHOOK_SECRET')
                  extraUrl = @('ExtraWebhookUrl','EXTRA_WEBHOOK_URL'); extraSecret = @('ExtraWebhookSecret','EXTRA_WEBHOOK_SECRET') }
        foreach($k in $map.Keys){
            $x = Get-Variable -Name $map[$k][0] -ValueOnly -ErrorAction SilentlyContinue
            $v = Get-YcMsFirst @($x, [Environment]::GetEnvironmentVariable($map[$k][1]))
            if($v){ $given[$k] = $v }
        }
        if($given.secret -and -not $given.url){ $given.url = $script:YcErpDefaultUrl }
        $tk = Get-YcMsFirst @((Get-Variable -Name NtfyToken -ValueOnly -ErrorAction SilentlyContinue), $env:NTFY_TOKEN)
        if($tk){ $given.ntfyToken = $tk }
        $tp = Get-YcMsFirst @((Get-Variable -Name NtfyTopic -ValueOnly -ErrorAction SilentlyContinue), $env:NTFY_TOPIC)
        if($tp -and $tp -ne 'off' -and $tp -match '^[A-Za-z0-9_-]{1,64}$'){
            $sv = Get-YcMsFirst @((Get-Variable -Name NtfyServer -ValueOnly -ErrorAction SilentlyContinue), $env:NTFY_SERVER)
            if(-not $sv){ $sv = $(if($tk){ $script:YcNtfyOwn } else { 'https://ntfy.sh' }) }
            $given.ntfy = $sv.TrimEnd('/') + '/' + $tp
        }
        if(-not ($given.secret -or $given.extraSecret -or $given.ntfyToken)){ return 'no webhook secret or ntfy token given to this run - nothing saved' }
        $d = Split-Path -Parent $script:YcMsCfgFile
        if(-not (Test-Path -LiteralPath $d)){ New-Item -ItemType Directory -Path $d -Force | Out-Null }
        $o = [ordered]@{}
        if(Test-Path -LiteralPath $script:YcMsCfgFile){
            try{ $j = (Get-Content -LiteralPath $script:YcMsCfgFile -Raw) | ConvertFrom-Json; foreach($p in $j.PSObject.Properties){ $o[$p.Name] = $p.Value } }catch{}
        }
        foreach($k in $given.Keys){ $o[$k] = $given[$k] }
        ([pscustomobject]$o) | ConvertTo-Json | Set-Content -LiteralPath $script:YcMsCfgFile -Encoding ascii
        & icacls.exe $script:YcMsCfgFile '/inheritance:r' '/grant:r' '*S-1-5-18:F' '*S-1-5-32-544:F' *>$null
        return ('saved to ' + $script:YcMsCfgFile + ': ' + ((@($given.Keys) | Sort-Object) -join ', '))
    }catch{ return ('not saved: ' + $_.Exception.Message) }
}

# ------------------------------------------------------------------------------------
# DEPLOYMENT ID, EVENT HEAD AND AGENT STATUS (lib 2.4.0, payload 2.47.7)
#   One ID per VM deployment in EVERY message (owner, 2026-11-04): the cloud-init portal makes
#   YCD-YYYYMMDD-NNNNNN at render and the win-builder (v2.18.26) writes it to yc-build.json as
#   DeployId. Every event starts with the same head, the old keys follow unchanged:
#     deploymentId, event, stage, status (started|running|ok|failed|waiting), seq, time (UTC),
#     vm {name, uuid, ip}, kit, kitVersion, detail, progress {step, of, name} | null
#   seq = one counter per deployment, in the SAME file the builder's yc-notify.ps1 counts in.
#   ntfy: title ends with " | <id>", the first body line is "deployment : <id>".
#   Agents (salt, glpi, acronis, wsus): ONE final status on ERP + Tech + ntfy, with the reason,
#   and only when the result changed - a retry with the same result sends nothing anywhere.
#   Built without the portal: deploymentId is "-".
# ------------------------------------------------------------------------------------
$script:YcBuildFile   = 'C:\ProgramData\YallaCloud\sqltemplate\yc-build.json'
$script:YcSeqFile     = 'C:\ProgramData\YallaCloud\sqltemplate\yc-event-seq.txt'
$script:YcAgentDir    = 'C:\ProgramData\YallaCloud\agents'
$script:YcAgentAreas  = @('salt','glpi','acronis','wsus')

function Get-YcDeployId{
    param([string]$File = $script:YcBuildFile)
    try{
        if(Test-Path -LiteralPath $File){
            $d = [string](((Get-Content -LiteralPath $File -Raw) | ConvertFrom-Json).DeployId)
            if($d -match '^YCD-[A-Za-z0-9-]{1,40}$'){ return $d }
        }
    }catch{}
    return '-'
}

# The next number in the deployment's event sequence. A machine-wide mutex, because the builder
# tasks (Salt, Acronis, GLPI) and the build itself can report at the same moment.
function Get-YcNextSeq{
    param([string]$File = $script:YcSeqFile)
    if(-not (Test-Path -LiteralPath (Split-Path -Parent $File))){ $File = Join-Path (Split-Path -Parent (Split-Path -Parent $File)) 'yc-event-seq.txt' }
    $m = $null; $own = $false
    try{ $m = New-Object System.Threading.Mutex($false, 'Global\YcEventSeq'); $own = $m.WaitOne(5000) }catch [System.Threading.AbandonedMutexException]{ $own = $true }catch{}
    try{
        $n = 0
        try{ $n = [int]([string](Get-Content -LiteralPath $File -ErrorAction Stop | Select-Object -First 1)).Trim() }catch{}
        $n++
        Set-Content -LiteralPath $File -Value $n -Encoding ascii -ErrorAction Stop
        return $n
    }catch{ return 0 }
    finally{ if($m){ if($own){ try{ $m.ReleaseMutex() }catch{} }; $m.Dispose() } }
}

# Pure: the head status for the last word of an event type.
function Get-YcHeadStatus{
    param([string]$State)
    $s = ([string]$State).ToLower()
    if(@('ok','joined','registered','completed','done','backtogreen','configured') -contains $s){ return 'ok' }
    if(@('failed','error','cancelled') -contains $s){ return 'failed' }
    if(@('waiting','waitforhuman') -contains $s){ return 'waiting' }
    if(@('started','run','start') -contains $s){ return 'started' }
    return 'running'
}

# Pure: progress from a step string. "3 sql install" -> step 3; the builder's "NET+ SYNC+ SQL+"
# -> step 3, name SQL+ (the builder has no fixed step count, so "of" stays null).
function Get-YcProgress{
    param([string]$Step)
    $t = @(([string]$Step).Trim() -split '\s+' | Where-Object { $_ })
    if(-not $t.Count){ return $null }
    if($t[0] -match '^\d+$'){ return [ordered]@{ step = [int]$t[0]; of = $null; name = ((@($t) | Select-Object -Skip 1) -join ' ') } }
    return [ordered]@{ step = $t.Count; of = $null; name = [string]$t[-1] }
}

# Pure: the event head, first in every ERP and Tech event.
function New-YcEventHead{
    param([string]$DeployId,[string]$Type,[int]$Seq,[string]$VmName,[string]$VmUuid,[string]$Ip,
          [string]$Kit,[string]$KitVersion,[string]$Detail = '',[string]$Step = '',[datetime]$UtcNow = [datetime]::UtcNow)
    $p = ([string]$Type).Split('.')
    $d = (([string]$Detail) -replace '\s+',' ').Trim(); if($d.Length -gt 300){ $d = $d.Substring(0,297) + '...' }
    return [ordered]@{
        deploymentId = $(if($DeployId){ $DeployId } else { '-' })
        event        = [string]$Type
        stage        = $(if($p.Count -ge 3){ $p[1] } else { [string]$Type })
        status       = (Get-YcHeadStatus $p[-1])
        seq          = $Seq
        time         = $UtcNow.ToString('yyyy-MM-dd') + 'T' + $UtcNow.ToString('HH:mm:ss') + 'Z'
        vm           = [ordered]@{ name = [string]$VmName; uuid = [string]$VmUuid; ip = [string]$Ip }
        kit          = [string]$Kit
        kitVersion   = [string]$KitVersion
        detail       = $d
        progress     = (Get-YcProgress $Step)
    }
}

# Pure: head first, then every key of the body that the head does not already carry.
function Join-YcEventHead{
    param($Head,$Body)
    $o = [ordered]@{}
    foreach($k in @($Head.Keys)){ $o[$k] = $Head[$k] }
    foreach($k in @($Body.Keys)){ if(-not $o.Contains($k)){ $o[$k] = $Body[$k] } }
    return $o
}

function Test-YcAgentArea{
    param([string]$Area)
    return ($script:YcAgentAreas -contains ([string]$Area).ToLower())
}

# Was this agent result already reported? The result is the head status (ok / failed / waiting),
# not the wording, so a retry that fails again, or a second reporter (builder task + join.ps1)
# with the same answer, sends nothing. Records the new result unless -Peek.
function Test-YcAgentChanged{
    param([string]$Area,[string]$State,[string]$Dir = $script:YcAgentDir,[switch]$Peek)
    $r = Get-YcHeadStatus $State
    if(@('ok','failed','waiting') -notcontains $r){ return $true }
    $f = Join-Path $Dir (([string]$Area).ToLower() + '.sent')
    $prev = ''
    try{ if(Test-Path -LiteralPath $f){ $prev = ([string](Get-Content -LiteralPath $f -Raw)).Trim() } }catch{}
    if($prev -eq $r){ return $false }
    if(-not $Peek){
        try{
            if(-not (Test-Path -LiteralPath $Dir)){ New-Item -ItemType Directory -Path $Dir -Force | Out-Null }
            Set-Content -LiteralPath $f -Value $r -Encoding ascii
        }catch{}
    }
    return $true
}

# During or after the build: the builder writes yc-build.completed at its end.
function Get-YcAgentWhen{
    param([string]$BuildFile = $script:YcBuildFile)
    if(-not (Test-Path -LiteralPath $BuildFile)){ return 'outside a build (day-2 / adopt)' }
    if(Test-Path -LiteralPath (Join-Path (Split-Path -Parent $BuildFile) 'yc-build.completed')){ return 'after the build (separate message)' }
    return 'during the build (also in OK BUILD)'
}

# Acronis: the data-centre address the agent registered to (only <dc>-cloud.acronis.com counts).
function Get-YcAcronisRegistration{
    foreach($k in @('HKLM:\SOFTWARE\Acronis','HKLM:\SOFTWARE\WOW6432Node\Acronis')){
        if(-not (Test-Path $k)){ continue }
        foreach($key in @(Get-Item $k) + @(Get-ChildItem $k -Recurse -ErrorAction SilentlyContinue)){
            foreach($v in $key.GetValueNames()){
                $d = [string]$key.GetValue($v)
                if($d -match '(?<u>https?://[a-z]{2,4}[0-9]{0,3}-cloud\.acronis\.com)'){ return $Matches.u }
            }
        }
    }
    return ''
}

# Acronis reason: the last ERROR line of the LAST acronis-setup run (WARN if there is none), where
# it registered, and the Managed Machine Service state. Never a token: the kit masks it in its log.
function Get-YcAcronisDetail{
    # -RegisteredTo / -Service are for tests; NOT [string]$x = $null - a [string] parameter turns $null into ''
    param([string]$LogFile = 'C:\ProgramData\YallaCloud\acronis-setup.log',$RegisteredTo = $null,$Service = $null)
    $p = @()
    try{
        if(Test-Path -LiteralPath $LogFile){
            $l = @(Get-Content -LiteralPath $LogFile -Tail 500)
            $s = 0
            for($i = $l.Count - 1; $i -ge 0; $i--){ if($l[$i] -match '\] acronis-setup v\d'){ $s = $i; break } }
            $run = @($l[$s..($l.Count - 1)])
            $e = @($run | Where-Object { $_ -match '\[ERROR\]' }) | Select-Object -Last 1
            if(-not $e){ $e = @($run | Where-Object { $_ -match '\[(WARN|HUMAN)\]' }) | Select-Object -Last 1 }
            if($e){ $p += ('last error: ' + ((([string]$e) -replace '^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d \[\w+\] ','').Trim())) }
        }
    }catch{}
    if($null -eq $RegisteredTo){ $RegisteredTo = Get-YcAcronisRegistration }
    $p += $(if($RegisteredTo){ 'registered to ' + $RegisteredTo } else { 'not registered to a data centre' })
    if($null -eq $Service){ $sv = $null; try{ $sv = Get-Service -Name 'MMS' -ErrorAction SilentlyContinue }catch{}; $Service = $(if($sv){ [string]$sv.Status } else { 'not installed' }) }
    $p += ('service Acronis Managed Machine Service ' + $Service)
    return ($p -join '; ')
}

# Pure: words for an agent state on a phone.
function Get-YcAgentWord{
    param([string]$State)
    switch(([string]$State).ToLower()){
        'ok'           { return 'OK' }
        'joined'       { return 'JOINED' }
        'registered'   { return 'REGISTERED' }
        'completed'    { return 'OK' }
        'backtogreen'  { return 'BACK TO GREEN' }
        'failed'       { return 'FAILED' }
        'waiting'      { return 'WAITING' }
        'waitforhuman' { return 'WAIT FOR HUMAN' }
    }
    return ([string]$State).ToUpper()
}

# Pure: the ntfy message for an agent result - the same lines as linux-base 1.8.2 yc_agent.
function New-YcAgentNtfy{
    param([string]$Area,[string]$State,[string]$Detail,[string]$DeployId,[string]$Host_,[string]$VmId,[string]$Ip,[string]$When,[string]$Log = '',[string]$By = '')
    $hs = Get-YcHeadStatus $State
    $p = '3'; $tg = 'white_check_mark'
    if($hs -eq 'failed'){ $p = '4'; $tg = 'x' }
    elseif(([string]$State).ToLower() -eq 'waitforhuman'){ $p = '4'; $tg = 'raising_hand' }
    elseif($hs -eq 'waiting'){ $p = '3'; $tg = 'hourglass' }
    $a = ([string]$Area).ToLower()
    $lines = @(('deployment : ' + $DeployId), ($a.PadRight(9) + ': ' + ([string]$State).ToLower()))
    if($Detail){ $lines += ('detail   : ' + $Detail) }
    $lines += ('when     : ' + $When)
    $lines += ('vm       : ' + $VmId + '  ip ' + $Ip)
    if($Log){ $lines += ('log      : ' + $Log) }
    if($By){ $lines += ('by       : ' + $By) }
    return @{ title = ($a.ToUpper() + ' ' + (Get-YcAgentWord $State) + ' Windows - ' + $Host_ + ' | ' + $DeployId); priority = $p; tags = ($tg + ',' + $a); text = ($lines -join "`n") }
}

# Copy of a flat event to the cloud-init portal, for its stage table (GET /api/v1/deployments/<id>).
# Only on a portal-built VM: the builder writes yc-report.json {url,key}. One try, 10 s, never throws.
function Send-YcMsReport{
    param([string]$Json,[string]$File = 'C:\ProgramData\YallaCloud\sqltemplate\yc-report.json')
    try{
        if(-not (Test-Path -LiteralPath $File)){ return '' }
        $rj = (Get-Content -LiteralPath $File -Raw) | ConvertFrom-Json
        if(-not ([string]$rj.url -match '^https://\S+$') -or -not [string]$rj.key){ return '' }
        return (Send-YcMsPost -Url ([string]$rj.url) -Headers @{ 'X-YC-Report-Key' = [string]$rj.key; 'X-YC-Channel' = 'win' } -Json $Json)
    }catch{ return 'no answer' }
}
