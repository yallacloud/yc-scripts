@echo off
rem olivetin-install -IUnderstandTheRisk [-InstallDir <path>] [-Port 1337]
rem                  [-ConfigPath C:\ProgramData\OliveTin\config.yaml] [-ServiceAccount <acct>]
rem                  [-ZipPath <zip>] [-Url <url>] [-Sha256 <hash>]
rem                  [-AllowRemote -MgmtCidr <cidr[,cidr]>] [-NoFirewall] [-Force] [-Help]
rem
rem *** DO NOT RUN THIS FROM AN UNATTENDED IMAGE BUILD. ***
rem OliveTin is a web UI that RUNS COMMANDS on this host. It has NO TLS of its own and its
rem documented default ACL lets an unauthenticated guest execute every configured action.
rem The previous version ran it as LocalSystem and opened TCP 1337 on every firewall profile.
rem
rem This version binds 127.0.0.1 by default, creates NO firewall rule, runs the service as
rem NT AUTHORITY\LocalService, and refuses -AllowRemote unless config.yaml actually enables
rem authentication and closes the allow-all default. OliveTin now HAS a native Windows build
rem (OliveTin-windows-amd64.zip) - the Linux tarball path is refused, not "staged".
rem Logs to C:\Scripts\olivetin-install.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\OliveTin-Install.ps1" %*
exit /b %ERRORLEVEL%
