param(
  [switch]$Help,
  [string[]]$ExtraArgs,                 # EXTRA switches - now APPENDED to the documented base line (see header)
  # ---- ADDED in this revision ----
  [string]$Package,                     # explicit setupdownloader_*.exe (required if several are staged)
  [switch]$Force,                       # re-run the installer even if BEST is already present
  [int]$InstallTimeoutSec = 3600,       # the downloader fetches the whole kit; allow an hour
  [int]$VerifyTimeoutSec  = 900,        # how long to wait for the BEST services to appear
  [string]$InternetUrl                  # egress probe target (default: the library's)
)
# =====================================================================================
# Bitdefender-Register.ps1 - SILENT install of the Bitdefender GravityZone (BEST) agent.
# PowerShell 5.1, ASCII only. Runs unattended (cloud-init / SYSTEM / RMM).
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# 1. THE COMMAND LINE WAS INCOMPLETE AND COULD REBOOT THE VM MID-DEPLOYMENT.
#    v1: setupdownloader_*.exe /bdparams /silent
#    Now: setupdownloader_*.exe /bdparams /silent /v"REBOOT=ReallySuppress /qn /l*v <log>"
#    /bdparams propagates the parameters to the embedded MSI; without REBOOT=ReallySuppress
#    the BEST kit is free to restart the machine in the middle of cloud-init, killing every
#    later step of A-Z-Deploy. Note there is NO SPACE between /v and its quoted payload -
#    that is an InstallShield requirement and getting it wrong is exactly the class of bug
#    (an installer silently rejecting the command line) this rewrite exists to eliminate.
#    Start-Process is documented to join -ArgumentList elements with a single space and to
#    add NO quoting of its own, so the element below reaches the installer verbatim.
# 2. THE NUMERIC LOG LEVEL IS FIXED. v1 line 42 called
#        Write-YcLog 'ADVISORY: Acronis not detected ...' 1002
#    The 1002 bound to [string]$Level, matched no branch, and the one advisory this script
#    exists to raise was written as INFO with event id 1001 - invisible to any rule filtering
#    on Warning. It now passes 'WARN'. (v2 of the library also normalises this, but the call
#    site is fixed at the source.)
# 3. PROOF INSTEAD OF AN EXIT CODE. v1 printed the exit code in cyan and exited it.
#    setupdownloader is a DOWNLOADER: a 0 from it means "I handed off", not "BEST installed".
#    This version waits for and requires: EPSecurityService Running, AND at least one
#    GravityZone communication service (EPIntegrationService / epag) Running - without one of
#    those the endpoint never checks in to the console - plus the product's uninstall registry
#    entry, and it logs the Windows Security Center outcome (Defender flipping to Passive is
#    independent corroboration that a real AV registered itself).
# 4. -ExtraArgs NOW EXTENDS, IT DOES NOT REPLACE. v1 replaced the whole argument list, so
#    anyone following its own help text and passing one extra switch lost /silent and the
#    installer opened a GUI - under SYSTEM in session 0 that hangs until the deploy times out.
# 5. IDEMPOTENT. If BEST is already installed and running the installer is not re-run (use
#    -Force). v1 re-downloaded and re-installed the whole kit on every invocation.
# 6. AMBIGUOUS TENANT IS NOW AN ERROR. The company/tenant is encoded in the installer FILE
#    NAME. v1 did Get-ChildItem 'setupdownloader_*.exe' | Select -First 1 with no ordering, so
#    with two staged downloaders it silently registered the VM into an arbitrary tenant. Now
#    two or more matches is a hard error unless -Package names the one to use.
# 7. -NeedInternet is asserted (the downloader exists solely to pull the kit from Bitdefender),
#    and every exit goes through Exit-Yc so the transcript always ends with [END] exit=<n>.
#
# VENDOR VERIFICATION:
#   setupdownloader_<token>.exe /bdparams /silent /v"REBOOT=ReallySuppress /qn /l*v <path>"
#   is the documented unattended form (GravityZone Windows deployment):
#   https://osh.co.za/bitdefender-gravityzone-installing-on-windows-macos-and-linux/
#   REBOOT=ReallySuppress, /qn and /l*v are standard Windows Installer options:
#   https://learn.microsoft.com/en-us/windows/win32/msi/standard-installer-command-line-options
#   BEST service names (EPSecurityService, EPIntegrationService, EPUpdateService,
#   EPMaintenanceService, epag): https://gist.github.com/asheroto/1bd1abeed3820e10f36e7813eb758cef
#   Start-Process -ArgumentList joining/quoting behaviour (why the /v element is safe):
#   https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/start-process?view=powershell-5.1
# NO undocumented switch is emitted by this script unless YOU pass it with -ExtraArgs.
#
# SECRETS: the tenant token is part of the installer FILE NAME, so it is never passed as a
#   parameter and never reaches a command line built here. The file name is masked in the log.
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was installed. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'bitdefender-register'

$Usage = @'
bitdefender-register  -  SILENT install of the Bitdefender GravityZone (BEST / EDR) agent.
The tenant/company is embedded in the installer FILENAME, so NO token is needed.

USAGE:
  bitdefender-register
  bitdefender-register -Package C:\Scripts\setupdownloader_<tenant>.exe
  bitdefender-register -ExtraArgs '/v"INSTALL_PATH=D:\"'
  bitdefender-register -Force
  bitdefender-register -Help

PARAMETERS:
  -Package            Explicit installer path. REQUIRED when more than one
                      C:\Scripts\setupdownloader_*.exe is staged - each one encodes a
                      different GravityZone company, and guessing registers the VM into the
                      wrong tenant.
  -ExtraArgs          EXTRA installer switches. These are APPENDED to the documented base
                      line  /bdparams /silent /v"REBOOT=ReallySuppress /qn /l*v <log>"  -
                      they no longer replace it, so you cannot accidentally lose /silent.
  -Force              Run the installer even if BEST is already installed and running.
  -InstallTimeoutSec  Kill the installer after this many seconds. Default 3600.
  -VerifyTimeoutSec   How long to wait for the BEST services to appear after the downloader
                      exits. Default 900 (a full kit install takes several minutes).
  -InternetUrl        Egress probe URL for the pre-flight check.
  -Help               Show this help and exit.

NOTES:
  Run on the DEPLOYED VM (not the golden image).
  RECOMMENDED: install Acronis (acronis-register) BEFORE Bitdefender to avoid AV/backup agent
  conflicts. That check is advisory only and never blocks an unattended run - it is now logged
  at WARN (it used to be logged as INFO because of a numeric log-level bug).
  Success is NOT the installer's exit code. This command only reports success once
  EPSecurityService is Running and a GravityZone communication service (EPIntegrationService
  or epag) is Running - i.e. once the endpoint can actually check in to the console.

EXAMPLES:
  bitdefender-register -PackageUrl https://cloud.gravityzone.bitdefender.com/Packages/.../setup.exe
        normal install from the GravityZone package link for this tenant.
  bitdefender-register -PackageUrl <url> -Proxy http://proxy:3128
        same, through an outbound proxy.
EXIT CODES:
  0   BEST installed, services Running, endpoint able to check in
  1   generic failure
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4   installer not found, unusable, or ambiguous (several tenants staged)
  5   not running as Administrator
  6   no outbound internet - the downloader cannot fetch the kit
  7   the installer finished but the BEST services are missing or not Running
  10  the installer did not exit within -InstallTimeoutSec and was killed
  <n> any other value is the Bitdefender installer's own exit code

Log: C:\Scripts\bitdefender-register.log   MSI log: C:\Scripts\bitdefender-msi.log
     (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

if($InternetUrl){ Assert-YcPrereqs -NeedAdmin -NeedInternet -InternetUrl $InternetUrl }
else            { Assert-YcPrereqs -NeedAdmin -NeedInternet }
Write-YcInvocation $PSBoundParameters

$MsiLog   = 'C:\Scripts\bitdefender-msi.log'
$CoreSvc  = 'EPSecurityService'
$CommSvcs = @('EPIntegrationService','epag')
$AllSvcs  = @('EPSecurityService','EPIntegrationService','EPUpdateService','EPMaintenanceService','epag')

function Get-YcBestProduct{
  $roots = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
             'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')
  $hit = $null
  foreach($r in $roots){
    $keys = @(Get-ChildItem -LiteralPath $r -ErrorAction SilentlyContinue)
    foreach($k in $keys){
      $p = $null
      try{ $p = Get-ItemProperty -LiteralPath $k.PSPath -ErrorAction SilentlyContinue }catch{}
      if($p -and $p.DisplayName -and ([string]$p.DisplayName -like '*Bitdefender Endpoint Security*')){
        $hit = [pscustomobject]@{ Name = [string]$p.DisplayName; Version = [string]$p.DisplayVersion }
        break
      }
    }
    if($hit){ break }
  }
  return $hit
}

function Write-YcBestState{
  foreach($n in $AllSvcs){
    $s = Get-Service -Name $n -ErrorAction SilentlyContinue
    if($s){ Write-YcLog ('  service ' + $n + ': ' + $s.Status) }
    else  { Write-YcLog ('  service ' + $n + ': not present') }
  }
}

# ------------------------------------------------------------------------------------
# 1. Advisory: Acronis first. NON-BLOCKING, and now logged at the level it deserves.
# ------------------------------------------------------------------------------------
$acr = $false
if(Get-Service -Name '*Acronis*' -ErrorAction SilentlyContinue){ $acr = $true }
elseif(Test-Path 'C:\Program Files\Acronis'){ $acr = $true }
elseif(Test-Path 'C:\Program Files (x86)\Common Files\Acronis'){ $acr = $true }
if($acr){
  Write-YcLog 'Acronis detected - the recommended install order (Acronis before Bitdefender) is satisfied.'
}else{
  # v1 passed 1002 here - an EVENT ID where the LEVEL belongs - so this line was filed as INFO.
  Write-YcLog 'ADVISORY (not blocking): the Acronis Cyber Protect agent was NOT detected. Recommended order is acronis-register BEFORE bitdefender-register, to avoid AV/backup agent conflicts. The Bitdefender install WILL CONTINUE.' 'WARN'
}

# ------------------------------------------------------------------------------------
# 2. Already installed?
# ------------------------------------------------------------------------------------
$existing = Get-YcBestProduct
$coreNow  = Get-Service -Name $CoreSvc -ErrorAction SilentlyContinue
if($existing){ Write-YcLog ('already installed: ' + $existing.Name + ' ' + $existing.Version) }
if($coreNow -and $coreNow.Status -eq 'Running' -and -not $Force){
  Write-YcLog 'BEST is already installed and running - not re-running the downloader (use -Force to reinstall). Verifying the existing installation instead.'
}else{
  # ----------------------------------------------------------------------------------
  # 3. Pick the installer. Ambiguity is an ERROR, not a coin toss.
  # ----------------------------------------------------------------------------------
  $exe = ''
  if($Package){
    $exe = $Package
  }else{
    $cands = @(Get-ChildItem -Path 'C:\Scripts\setupdownloader_*.exe' -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer } | Sort-Object -Property Name)
    if($cands.Count -eq 0){
      Exit-Yc 4 'Bitdefender installer (C:\Scripts\setupdownloader_*.exe) not found. Download the kit for YOUR company from GravityZone and stage it, or pass -Package. Nothing was installed.' 'ERROR'
    }
    if($cands.Count -gt 1){
      Write-YcLog ('several staged Bitdefender downloaders found: ' + (($cands | ForEach-Object { Protect-YcSecret $_.Name }) -join ', ')) 'ERROR'
      Exit-Yc 4 'more than one setupdownloader_*.exe is staged and each one encodes a DIFFERENT GravityZone company - refusing to guess. Pass -Package <file>.' 'ERROR'
    }
    $exe = $cands[0].FullName
  }
  if(-not (Assert-YcFile -Path $exe -MinBytes 100KB -Because 'GravityZone downloader')){
    Exit-Yc 4 ('unusable Bitdefender installer: ' + $exe) 'ERROR'
  }
  $sig = 'Unavailable'
  try{ $sig = [string](Get-AuthenticodeSignature -LiteralPath $exe -ErrorAction Stop).Status }catch{ $sig = 'Unavailable' }
  if($sig -eq 'Valid'){ Write-YcLog 'installer Authenticode signature: Valid' 'OK' }
  else{ Write-YcLog ('installer Authenticode signature is ' + $sig + ' - continuing, but this package is not proven to be the vendor build') 'WARN' }

  # ----------------------------------------------------------------------------------
  # 4. The documented unattended command line. /v takes NO space before its payload.
  # ----------------------------------------------------------------------------------
  $al = @('/bdparams','/silent', ('/v"REBOOT=ReallySuppress /qn /l*v ' + $MsiLog + '"'))
  if($ExtraArgs){
    foreach($x in $ExtraArgs){ if($x){ $al += [string]$x } }
    Write-YcLog ('-ExtraArgs appended to the documented base line: ' + (($ExtraArgs) -join ' ')) 'WARN'
  }

  Write-YcLog 'installing the Bitdefender GravityZone agent (silent). The downloader fetches the full kit first, so this takes minutes, not seconds.'
  $inst = Invoke-YcInstaller -FilePath $exe -ArgumentList $al -SuccessCodes @(0) -RebootCodes @(3010,1641) -TimeoutSec $InstallTimeoutSec -MinSeconds 30
  if($inst.TimedOut){
    Write-YcBestState
    Exit-Yc 10 ('the Bitdefender installer had to be killed after ' + $InstallTimeoutSec + 's - the endpoint is in an unknown state. See ' + $MsiLog) 'ERROR'
  }
  if($inst.Status -eq 'Suspicious'){
    Write-YcBestState
    Exit-Yc 1 ('the installer returned ' + $inst.ExitCode + ' after only ' + $inst.DurationSec + 's. A downloader cannot fetch and install the kit that fast - it rejected the command line and installed nothing. Nothing was verified as installed.') 'ERROR'
  }
  if(-not $inst.Success){
    $code = $inst.ExitCode
    if($code -eq 0){ $code = 1 }
    Write-YcBestState
    Exit-Yc $code ('Bitdefender installer FAILED: ' + $inst.Meaning + '. See ' + $MsiLog) 'ERROR'
  }
  if($inst.RebootRequired){
    Write-YcLog 'the installer reports a reboot is required to complete. REBOOT=ReallySuppress stopped it rebooting on its own - schedule one after the deployment.' 'WARN'
  }
}

# ------------------------------------------------------------------------------------
# 5. PROOF. The installer exiting 0 is not evidence that anything is protecting this VM.
# ------------------------------------------------------------------------------------
Write-YcLog ('waiting up to ' + $VerifyTimeoutSec + 's for the BEST services to appear...')
$deadline = (Get-Date).AddSeconds($VerifyTimeoutSec)
$seen = $false
$tick = 0
while((Get-Date) -lt $deadline){
  if(Get-Service -Name $CoreSvc -ErrorAction SilentlyContinue){ $seen = $true; break }
  Start-Sleep -Seconds 10
  $tick++
  if(($tick % 6) -eq 0){ Write-YcLog ('  still waiting for ' + $CoreSvc + ' (' + ($tick * 10) + 's elapsed)') }
}
if(-not $seen){
  Write-YcBestState
  Exit-Yc 7 ($CoreSvc + ' never appeared - Bitdefender Endpoint Security Tools is NOT installed on this host, whatever the installer returned. See ' + $MsiLog) 'ERROR'
}
if(-not (Assert-YcService -Name $CoreSvc -TimeoutSec 300 -StartIfStopped -Because 'the BEST core service must run for this endpoint to be protected')){
  Write-YcBestState
  Exit-Yc 7 ($CoreSvc + ' exists but is not Running - this endpoint is NOT protected.') 'ERROR'
}

# GravityZone check-in: without a communication service the endpoint never appears in the
# console, no policy is ever applied, and nobody finds out.
$commOk = ''
foreach($c in $CommSvcs){
  $s = Get-Service -Name $c -ErrorAction SilentlyContinue
  if($s){
    if($s.Status -ne 'Running'){
      try{ Start-Service -Name $c -ErrorAction Stop }catch{ Write-YcLog ('could not start ' + $c + ': ' + $_.Exception.Message) 'WARN' }
      $s = Get-Service -Name $c -ErrorAction SilentlyContinue
    }
    if($s -and $s.Status -eq 'Running'){ $commOk = $c; break }
  }
}
Write-YcBestState
if(-not $commOk){
  Exit-Yc 7 ('no GravityZone communication service is running (looked for: ' + ($CommSvcs -join ', ') + '). The agent is installed but this endpoint will NEVER check in to the console.') 'ERROR'
}
Write-YcLog ('GravityZone communication service "' + $commOk + '" is Running - this endpoint can check in to the console') 'OK'

$prod = Get-YcBestProduct
if($prod){ Write-YcLog ('installed product: ' + $prod.Name + ' ' + $prod.Version) 'OK' }
else{ Write-YcLog 'the BEST services are running but no "Bitdefender Endpoint Security" uninstall entry was found - the installation may be partial' 'WARN' }

# Independent corroboration: when a real AV registers with the Windows Security Center,
# Microsoft Defender steps down to passive mode. This is informational, never fatal.
try{
  if(Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue){
    $mp = Get-MpComputerStatus -ErrorAction Stop
    Write-YcLog ('Windows Security Center: Defender AMRunningMode=' + $mp.AMRunningMode + ' RealTimeProtectionEnabled=' + $mp.RealTimeProtectionEnabled + ' (a third-party AV registering normally puts Defender into Passive mode)')
  }
}catch{
  Write-YcLog ('could not read the Defender status for corroboration: ' + $_.Exception.Message)
}

Write-YcLog ('the endpoint should now appear in GravityZone within a few minutes as ' + $env:COMPUTERNAME + '. If it does not, check egress to the GravityZone communication server from this VM.')
Exit-Yc 0 ('Bitdefender GravityZone agent installed and verified: ' + $CoreSvc + ' Running, ' + $commOk + ' Running.') 'OK'
