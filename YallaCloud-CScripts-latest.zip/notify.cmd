@echo off
rem notify <message>   publishes to the build ntfy topic
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $m='%*'; if(-not $m){$m='ping'}; try{ Invoke-RestMethod -Uri 'https://ntfy.sh/9890122212' -Method Post -Body $m -TimeoutSec 15 | Out-Null; Write-Host sent }catch{ Write-Host 'ntfy failed' }"
