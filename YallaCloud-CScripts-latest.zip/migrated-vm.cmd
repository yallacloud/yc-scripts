@echo off
REM ==================================================================================
REM  migrated-vm  -  bring a MIGRATED VM up to the same day-2 standard as a fresh one.
REM
REM  Run this ONCE on a VM migrated from vCenter or OpenStack. It surveys the machine,
REM  checks the prerequisites, pulls C:\Scripts from the public payload, puts it on the
REM  PATH so  yallacloud  works, reports what SQL is there, takes a first full backup
REM  and schedules the recurring ones, and registers the tasks that keep it current.
REM
REM    migrated-vm -Report      LOOK ONLY. Changes nothing. This is the default.
REM    migrated-vm -Run         do it
REM    migrated-vm -Status      what was done to this machine
REM    migrated-vm -Help        everything else
REM
REM  IT NEVER installs SQL Server, never activates Windows, and never removes anything
REM  it cannot positively identify. Those are decisions for a human, and it says so.
REM
REM  A PENDING REBOOT stops the run at exit 1 and registers YC-AdoptResume - reboot the
REM  machine and it carries on by itself. Pass -AllowReboot to let it restart on its own.
REM
REM  EXIT  0 done | 1 reboot required | 2 refused | 3 partial, items flagged
REM        4 payload hash mismatch (nothing installed) | 5 not admin | 6 no egress
REM  LOG   C:\Scripts\adopt-migrated-vm.log
REM ==================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Adopt-MigratedVm.ps1" %*
exit /b %ERRORLEVEL%
