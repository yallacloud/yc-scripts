# yc-deploy.ps1 - runs once per boot; records what this clone actually is.
$ErrorActionPreference='SilentlyContinue'
$log='C:\Scripts\yc-deploy.log'
$os=(Get-CimInstance Win32_OperatingSystem).Caption
$ip=(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' } | Select-Object -First 1).IPAddress
$xpr=(& cscript //nologo C:\Windows\System32\slmgr.vbs /xpr 2>&1) -join ' '
Add-Content $log ("[{0}] host={1} ip={2} os={3} lic={4}" -f (Get-Date -f 'yyyy-MM-dd HH:mm:ss'), $env:COMPUTERNAME, $ip, $os, $xpr) -Encoding ascii
