@echo off
setlocal
rem ================================================================================================
rem fix-deploy - apply the YallaCloud deployment-time fixes. Wrapper for C:\Scripts\Fix-Deploy.ps1.
rem
rem THE ONLY COMMAND MOST PEOPLE NEED:
rem
rem   fix-deploy
rem
rem Safe to run more than once. Each fix checks whether it applies before touching anything.
rem
rem USAGE:
rem   fix-deploy                        apply every fix that applies to this machine
rem   fix-deploy -Report                say what WOULD change, change nothing
rem   fix-deploy -Only lockout,gateway  apply just these
rem   fix-deploy -Help
rem
rem THE FIXES:
rem   lockout   net accounts /lockoutthreshold:0, and unlocks Administrator if it is already
rem             locked. A template-inherited lockout policy locks the account on a brand new VM
rem             and makes SSH report "Permission denied (publickey)" for what is really a lockout.
rem   gateway   CloudStack ISOLATED networks route through x.x.x.1 but the guest can come up with
rem             x.x.x.254 and no route off the subnet. Only changed when the address is private,
rem             the configured gateway does NOT answer and x.x.x.1 DOES. A working gateway and a
rem             public address are never touched.
rem   tls       SchUseStrongCrypto + SystemDefaultTlsVersions (32 and 64 bit) and the SCHANNEL
rem             TLS 1.2 keys. Windows Server 2016 and older only - .NET there defaults to TLS 1.0
rem             and every HTTPS call fails in a way that looks like "no internet".
rem   console   LogonUI LastLoggedOnUser / LastLoggedOnSAMUser = .\Administrator, so the console
rem             lands on the account whose password the deployment hands out. Mostly vCenter.
rem
rem CLOUD-INIT: call this FIRST, before anything that needs the network or SSH.
rem
rem EXIT CODES: 0 all applicable fixes in place | 1 bad arguments or help |
rem             2 a fix could not be applied | 5 not elevated
rem Logs to C:\Scripts\fix-deploy.log
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Fix-Deploy.ps1" %*
exit /b %ERRORLEVEL%
