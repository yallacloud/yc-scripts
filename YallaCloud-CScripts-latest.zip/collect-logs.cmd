@echo off
rem collect-logs - gather every log and system fact needed to diagnose this VM into ONE
rem                portable, redacted .zip for support.
rem
rem NEW COMMAND. Nothing in this toolkit produced a single artifact you could attach to a
rem ticket: an operator had to RDP in, run diag, run rootcause, run report-inventory, then
rem hunt through C:\Scripts\*.log, %ProgramData%\Acronis and Event Viewer by hand.
rem collect-logs COLLECTS the output of those commands rather than re-running them, so it
rem never runs chkdsk, sfc, DISM or cdb and therefore cannot hang while collecting.
rem
rem It NEVER modifies, moves or deletes a source log - everything is copied first and the
rem redaction pass only ever rewrites the staged COPY.
rem
rem USAGE:
rem   collect-logs
rem   collect-logs -Days 14
rem   collect-logs -Days 3 -IncludeSecurityLog -Perf
rem   collect-logs -OutDir D:\support -MaxSizeMB 256
rem   collect-logs -S3
rem   collect-logs -Help
rem
rem REDACTION is ON by default: secret-shaped values (token=, password=, --reg-token,
rem   -SaPassword, apikey:, connectionstring=, ...) are masked in every staged TEXT file.
rem   The .evtx event log BINARIES are NOT redacted - they ship as-is so Event Viewer can
rem   open them; the .csv twin of each channel IS redacted. -NoRedact turns the pass off
rem   and the archive is then NOT safe to send to a third party.
rem
rem Exit codes: 0 archive created and verified to open, 1 archive failed,
rem             2 usage error, 5 not elevated.
rem Log: C:\Scripts\collect-logs.log   Archive: C:\Scripts\logs\<hostname>-<timestamp>.zip
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Collect-Logs.ps1" %*
exit /b %ERRORLEVEL%
