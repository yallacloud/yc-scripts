param(
  [string[]]$Path,                 # folders to list as GravityZone exclusions (default C:\Scripts)
  [switch]$Help,
  # ---- ADDED in this revision ----
  [string]$OutFile = 'C:\Scripts\bitdefender-exclusions.txt',
  [switch]$Replace,                # overwrite the list instead of merging into it
  [switch]$Verify,                 # do not change anything: re-check the existing list and its ACLs
  [switch]$AcceptPrivEscRisk       # required to list a directory non-admins can write to
)
# =====================================================================================
# Bitdefender-Exclude.ps1 - prepare + verify Bitdefender GravityZone folder exclusions.
# PowerShell 5.1, ASCII only. Runs unattended (cloud-init / SYSTEM / RMM).
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# WHAT THIS COMMAND CAN AND CANNOT DO, STATED UP FRONT: GravityZone endpoint exclusions live
# in the CONSOLE POLICY. There is no supported local way to add one, so this command cannot
# apply anything to the agent, and it now says so at WARN on every run instead of implying
# the job is done. What it CAN verify - and now does - is (a) that the list it wrote is on
# disk and contains exactly what was requested, and (b) that every listed directory is safe
# to exclude in the first place.
#
# 1. IT NOW REFUSES TO RECOMMEND A PRIVILEGE-ESCALATION PRIMITIVE BY DEFAULT.
#    ***  EXCLUDING C:\Scripts IS A SECURITY DECISION, NOT HOUSEKEEPING.  ***
#    C:\Scripts is on the SYSTEM PATH and every command in this toolkit is executed from it
#    with -ExecutionPolicy Bypass, much of it as SYSTEM. A directory that is writable by
#    BUILTIN\Users, on the PATH, and excluded from the EDR is a local privilege-escalation
#    primitive: any user drops a payload, something runs it as SYSTEM, and the EDR has been
#    told not to look. v1 printed that exact recommendation for an operator to paste straight
#    into the console policy, with no warning at all.
#    This version inspects the ACL of every path and REFUSES unless the directory is already
#    locked to SYSTEM + Administrators, or -AcceptPrivEscRisk is passed. _yc-lib.ps1 v2
#    hardens C:\Scripts on every Start-YcLog, so on a current image the default passes.
# 2. THE LIST IS MERGED, NOT CLOBBERED. v1 did `$Path | Set-Content $out`, so
#    `bitdefender-exclude D:\Data` silently discarded the entry written by the previous run.
#    Now the file is merged and de-duplicated (-Replace restores the old behaviour) and is
#    READ BACK afterwards to prove every requested path is really in it (exit 13 if not).
# 3. 'C:\Scripts\*' IS GONE FROM THE DEFAULT. A GravityZone Folder-type exclusion is already
#    recursive, so the second entry was noise that reads as an error to whoever pastes it.
# 4. -Verify re-checks an existing list (paths, ACLs, whether the agent is even installed)
#    without changing anything - useful as a compliance probe.
# 5. Every exit goes through Exit-Yc, so the transcript always ends with [END] exit=<n>.
#    v1 had two bare exits and never called Stop-YcLog.
#
# NOTE ON -NeedAdmin: this command only writes a text file, but it also reads directory ACLs
# and reports on the installed agent, and Start-YcLog hardens C:\Scripts - all of which want
# elevation. It is kept, in line with the house prologue, and is the documented behaviour.
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was written. Re-deploy the C:\Scripts payload and re-run.      ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'bitdefender-exclude'

$Usage = @'
bitdefender-exclude  -  prepare + verify Bitdefender GravityZone folder exclusions.

Endpoint exclusions for GravityZone are set in the CONSOLE POLICY, not locally: this command
CANNOT apply them to the agent and never claims to. It maintains the authoritative list at
C:\Scripts\bitdefender-exclusions.txt, verifies the list was written, checks that every listed
directory is SAFE to exclude, and prints the exact console steps.

USAGE:
  bitdefender-exclude [<path> ...]
  bitdefender-exclude C:\Scripts D:\Data
  bitdefender-exclude -Verify
  bitdefender-exclude -Help

PARAMETERS:
  -Path                One or more folder paths to list as exclusions. Default: C:\Scripts.
                       ('C:\Scripts\*' is deliberately NOT included - a GravityZone Folder
                       exclusion is already recursive.)
  -OutFile             Where the list is kept. Default C:\Scripts\bitdefender-exclusions.txt.
  -Replace             Overwrite the list instead of merging into it.
  -Verify              Change nothing: re-read the existing list, re-check the ACLs and report.
  -AcceptPrivEscRisk   Required to list a directory that a non-administrative group can WRITE
                       to. See the security note below - this is not a formality.
  -Help                Show this help and exit.

  *** SECURITY: EXCLUDING C:\Scripts IS A PRIVILEGE-ESCALATION DECISION ***
  C:\Scripts is on the system PATH and everything in it runs with -ExecutionPolicy Bypass,
  much of it as SYSTEM. A directory that is (a) writable by ordinary users, (b) on the PATH
  and (c) excluded from the EDR is a local-privilege-escalation primitive: any user drops a
  file, something runs it as SYSTEM, and the EDR has been told not to look at it.
  This command INSPECTS THE ACL of each path and REFUSES if Users / Authenticated Users /
  Everyone / Guests can write there, unless -AcceptPrivEscRisk is passed. Harden the
  directory first - _yc-lib.ps1 v2 does exactly that to C:\Scripts on every run (inheritance
  broken, SYSTEM + Administrators Full only) - and the check passes with no flag.
  Prefer narrow, specific exclusions over a whole PATH directory, and record the risk
  acceptance if you must have one.

CONSOLE STEPS (the only place the exclusion actually takes effect):
  Policies > <your policy> > Antimalware > Settings > Exclusions > Custom > Add > Type=Folder

EXAMPLES:
  bitdefender-exclude
  bitdefender-exclude C:\Scripts D:\Data
  bitdefender-exclude -Path D:\SQLData -AcceptPrivEscRisk
  bitdefender-exclude -Verify
  bitdefender-exclude -Help

EXIT CODES:
  0   the list is written and verified (the console policy step is still YOURS to do)
  1   generic failure
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was written)
  5   not running as Administrator
  11  refused: a requested path is writable by non-administrators (pass -AcceptPrivEscRisk)
  12  -Verify was requested but no exclusion list exists yet
  13  the list was written but does not read back with the requested paths

Log: C:\Scripts\bitdefender-exclude.log   (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

if(-not $Path){ $Path = @('C:\Scripts') }

# ------------------------------------------------------------------------------------
# Risk inspection: is this path writable by a non-administrative principal, and is it on
# the system PATH? Both true = privilege-escalation primitive once the EDR stops looking.
# ------------------------------------------------------------------------------------
function Get-YcPathRisk{
  param([string]$InputPath)
  $r = [pscustomobject]@{ Path = $InputPath; Target = ''; Exists = $false; Writable = $false; OnSystemPath = $false; Who = @(); AclError = ''; JudgedPath = '' }
  $p = ([string]$InputPath).Trim()
  $p = $p -replace '\*+$',''
  $p = $p.TrimEnd('\')
  $r.Target = $p
  if(-not $p){ return $r }
  if(Test-Path -LiteralPath $p){ $r.Exists = $true }

  try{
    $envKey = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment'
    $raw = [string](Get-Item -LiteralPath $envKey -ErrorAction Stop).GetValue('Path',$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    foreach($seg in ($raw -split ';')){
      $s = ''
      try{ $s = [Environment]::ExpandEnvironmentVariables($seg) }catch{ $s = $seg }
      $s = $s.Trim().TrimEnd('\')
      if($s -and ($s -eq $p)){ $r.OnSystemPath = $true }
    }
  }catch{}

  # A path that does not exist YET is not safe: the exclusion covers whatever gets created
  # underneath it. Judge the nearest EXISTING ancestor instead - if a non-administrator can
  # create the directory there, they end up owning an AV-excluded directory with full control.
  # BEFORE: this returned Writable=$false without reading a single ACL, so naming a path one
  # day early walked straight past the guard.
  $judge = $p
  if(-not $r.Exists){
    $anc = $p
    while($anc -and -not (Test-Path -LiteralPath $anc)){
      $up = Split-Path -Parent $anc
      if(-not $up -or $up -eq $anc){ $anc = ''; break }
      $anc = $up
    }
    if(-not $anc){
      $r.AclError = 'no existing ancestor of ' + $p + ' could be found, so its ACL could not be judged'
      return $r
    }
    $r.JudgedPath = $anc
    $judge = $anc
  }
  $target = $judge
  try{ if(-not (Get-Item -LiteralPath $judge -ErrorAction Stop).PSIsContainer){ $target = Split-Path -Parent $judge } }catch{}
  $riskySids = @('S-1-5-32-545','S-1-5-11','S-1-1-0','S-1-5-32-546','S-1-5-7')
  try{
    $acl = Get-Acl -LiteralPath $target -ErrorAction Stop
    foreach($ace in $acl.Access){
      if([string]$ace.AccessControlType -ne 'Allow'){ continue }
      $sid = ''
      try{ $sid = $ace.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value }catch{ $sid = [string]$ace.IdentityReference }
      if($riskySids -notcontains $sid){ continue }
      $writes = $false
      $rightsText = [string]$ace.FileSystemRights
      if($rightsText -match '(?i)write|modify|fullcontrol|createfiles|appenddata|changepermissions|takeownership|delete'){ $writes = $true }
      $val = 0
      try{ $val = [int]$ace.FileSystemRights }catch{ $val = 0 }
      foreach($bit in @(0x2,0x4,0x10,0x100,0x10000,0x40000,0x80000)){
        if(($val -band $bit) -ne 0){ $writes = $true }
      }
      if($writes){
        $r.Writable = $true
        $r.Who += ([string]$ace.IdentityReference + ' -> ' + $rightsText)
      }
    }
  }catch{
    $r.AclError = $_.Exception.Message
  }
  return $r
}

function Show-YcRisk{
  param($Risk)
  if($Risk.AclError){ Write-YcLog ('could not read the ACL of ' + $Risk.Target + ': ' + $Risk.AclError) 'WARN'; return $false }
  $judged = ''
  if($Risk.JudgedPath){ $judged = ' (does not exist yet; judged its nearest existing ancestor ' + $Risk.JudgedPath + ', which is where a non-administrator would create it)' }
  # NO early return for a non-existent path: the exclusion still covers whatever is created there.
  if(-not $Risk.Exists){ Write-YcLog ('note: ' + $Risk.Target + ' does not exist on this host yet - the ACL of ' + $Risk.JudgedPath + ' is what decides who ends up owning the excluded directory') 'WARN' }
  if($Risk.Writable){
    $msg = 'PRIVILEGE-ESCALATION RISK: ' + $Risk.Target + ' is writable by non-administrators (' + ($Risk.Who -join '; ') + ')' + $judged
    if($Risk.OnSystemPath){ $msg += ' AND it is on the SYSTEM PATH, where this toolkit executes scripts as SYSTEM with -ExecutionPolicy Bypass' }
    Write-YcLog ($msg + '. Excluding it from the EDR removes the last control that would catch a planted payload.') 'ERROR'
    return $true
  }
  Write-YcLog ('ACL check OK: ' + $Risk.Target + ' is not writable by Users/Authenticated Users/Everyone/Guests' + $judged + $(if($Risk.OnSystemPath){' (it IS on the system PATH, but only administrators can write to it)'}else{''})) 'OK'
  return $false
}

# ------------------------------------------------------------------------------------
# -Verify: report on what is already there, change nothing.
# ------------------------------------------------------------------------------------
if($Verify){
  if(-not (Test-Path -LiteralPath $OutFile)){
    Exit-Yc 12 ('no exclusion list at ' + $OutFile + ' - run bitdefender-exclude first.') 'ERROR'
  }
  $cur = @()
  try{ $cur = @(Get-Content -LiteralPath $OutFile -ErrorAction Stop | Where-Object { $_ -and $_.Trim() }) }
  catch{ Exit-Yc 1 ('could not read ' + $OutFile + ': ' + $_.Exception.Message) 'ERROR' }
  Write-YcLog ('exclusion list (' + $cur.Count + ' entr(y/ies)) from ' + $OutFile + ':')
  $anyRisk = $false
  foreach($e in $cur){
    Write-YcLog ('  ' + $e)
    if(Show-YcRisk -Risk (Get-YcPathRisk -InputPath $e)){ $anyRisk = $true }
  }
  $bd = Get-Service -Name 'EPSecurityService' -ErrorAction SilentlyContinue
  if($bd){ Write-YcLog ('Bitdefender EPSecurityService is present (' + $bd.Status + ') - the exclusions above still have to exist in the CONSOLE policy for this endpoint.') }
  else   { Write-YcLog 'Bitdefender Endpoint Security Tools is not installed on this host (run bitdefender-register).' 'WARN' }
  if($anyRisk){
    Exit-Yc 11 'the existing exclusion list contains at least one directory that non-administrators can write to. Harden it or remove it from the list.' 'ERROR'
  }
  Exit-Yc 0 ('verified: ' + $cur.Count + ' exclusion(s) listed, all ACL-safe. Applying them in the GravityZone console policy remains a manual step.') 'OK'
}

# ------------------------------------------------------------------------------------
# ACL gate on the requested paths.
# ------------------------------------------------------------------------------------
$risky = @()
foreach($p in @($Path)){
  $risk = Get-YcPathRisk -InputPath $p
  if(Show-YcRisk -Risk $risk){ $risky += $risk }
}
if($risky.Count -gt 0){
  if($AcceptPrivEscRisk){
    Write-YcLog ('-AcceptPrivEscRisk was passed: listing ' + (($risky | ForEach-Object { $_.Target }) -join ', ') + ' despite the risk above. RECORD THIS AS AN ACCEPTED RISK.') 'WARN'
  }else{
    Exit-Yc 11 ('refusing to recommend excluding a user-writable directory from the EDR. Harden it first (icacls <dir> /inheritance:r /grant "NT AUTHORITY\SYSTEM:(OI)(CI)F" "BUILTIN\Administrators:(OI)(CI)F"), narrow the exclusion, or re-run with -AcceptPrivEscRisk. Nothing was written.') 'ERROR'
  }
}

# ------------------------------------------------------------------------------------
# Merge (not clobber), write, then READ BACK.
# ------------------------------------------------------------------------------------
$wanted = @()
foreach($p in @($Path)){
  $t = ([string]$p).Trim()
  if($t){ $wanted += $t }
}
$final = @()
if(-not $Replace -and (Test-Path -LiteralPath $OutFile)){
  try{
    foreach($l in @(Get-Content -LiteralPath $OutFile -ErrorAction Stop)){
      $t = ([string]$l).Trim()
      if($t -and ($t -ne 'C:\Scripts\*')){ $final += $t }
    }
  }catch{
    Write-YcLog ('could not read the existing list at ' + $OutFile + ' (' + $_.Exception.Message + ') - it will be replaced') 'WARN'
  }
}
foreach($w in $wanted){
  $dup = $false
  foreach($f in $final){ if($f.TrimEnd('\').ToLowerInvariant() -eq $w.TrimEnd('\').ToLowerInvariant()){ $dup = $true } }
  if(-not $dup){ $final += $w }
}
try{
  Set-Content -LiteralPath $OutFile -Value $final -Encoding ascii -ErrorAction Stop
}catch{
  Exit-Yc 1 ('could not write ' + $OutFile + ': ' + $_.Exception.Message) 'ERROR'
}

$readback = @()
try{ $readback = @(Get-Content -LiteralPath $OutFile -ErrorAction Stop | Where-Object { $_ -and $_.Trim() }) }
catch{ Exit-Yc 13 ('could not read back ' + $OutFile + ': ' + $_.Exception.Message) 'ERROR' }
$missing = @()
foreach($w in $wanted){
  $seen = $false
  foreach($r in $readback){ if(([string]$r).Trim().TrimEnd('\').ToLowerInvariant() -eq $w.TrimEnd('\').ToLowerInvariant()){ $seen = $true } }
  if(-not $seen){ $missing += $w }
}
if($missing.Count -gt 0){
  Exit-Yc 13 ('the exclusion list does not contain: ' + ($missing -join ', ') + ' after being written.') 'ERROR'
}
Write-YcLog ('exclusion list verified on disk (' + $readback.Count + ' entries): ' + $OutFile) 'OK'

Write-Host ''
Write-Host 'Add these as FOLDER exclusions in GravityZone:' -ForegroundColor Cyan
Write-Host '  Policies > <your policy> > Antimalware > Settings > Exclusions > Custom > Add > Type=Folder' -ForegroundColor Cyan
foreach($f in $readback){ Write-Host ('  ' + $f) -ForegroundColor Green }
Write-Host ''

$bd = Get-Service -Name 'EPSecurityService' -ErrorAction SilentlyContinue
if($bd){ Write-YcLog ('Bitdefender EPSecurityService is present (' + $bd.Status + ').') }
else   { Write-YcLog 'Bitdefender Endpoint Security Tools is not installed on this host yet (run bitdefender-register).' 'WARN' }

Write-YcLog 'NOT YET IN EFFECT: GravityZone exclusions are applied by the CONSOLE POLICY. This command has written and verified the list only - nothing on this endpoint has changed. Add them in the console, then re-run with -Verify as a record.' 'WARN'
Exit-Yc 0 ('exclusion list prepared and verified (' + $readback.Count + ' entries) at ' + $OutFile + '. Console policy step still required.') 'OK'
