@echo off
setlocal
rem ================================================================================================
rem sql-backup-path - move the SQL backup location, and change retention, on a live machine.
rem                   Wrapper for C:\Scripts\Yc-SqlBackupPath.ps1.
rem
rem WHY IT EXISTS: the backup root is chosen once by install-sql -BackupDir and then frozen into the
rem arguments of six scheduled tasks. The default is C:\dbbackupdaily - the system drive. Backups
rem grow, C: fills, and a full system drive does not slow a Windows VM down, it stops it. Until now
rem the only way to change that folder was to re-run install-sql on a live database server.
rem
rem   sql-backup-path -Report                        where the backups go now, and how long kept
rem   sql-backup-path -Path D:\dbbackupdaily         point new backups at D:
rem   sql-backup-path -Path D:\dbbackupdaily -Move   ...and robocopy the existing files across
rem   sql-backup-path -RetainFullDays 60             retention only, leave the location alone
rem   sql-backup-path -Path D:\dbbackupdaily -MonthlyPath D:\dbbackupmonthly -KeepMonths 24
rem   sql-backup-path -InstanceName YCWEB -Path E:\dbbackupdaily
rem   sql-backup-path -SelfCheck                     assertions only, no admin, changes nothing
rem   sql-backup-path -Help
rem
rem WHAT IT CHANGES, together, because they are one setting wearing two names:
rem   @Directory   in YC-SqlBackupFull / -Diff / -Log     where backups are written
rem   @CleanupTime in the same three tasks                how long they are kept THERE - Ola only
rem                                                       ever cleans the folder it is pointed at
rem   -MonthlyDir / -KeepMonths in YC-SqlBackupMonthly    the retained monthly archive
rem   the instance default backup directory               ad-hoc backups and SSMS follow too
rem YC-SqlRestoreVerify and restore-sql need nothing: they read the location back out of these
rem same task arguments, which are the single source of truth for where the backups live.
rem
rem IT PROVES THE PATH FIRST: creates the folder, grants the SQL service account, then makes SQL
rem Server itself write a real COPY_ONLY backup of master there and delete it. If SQL cannot write
rem there, NOTHING is changed and the old path stays in force - rather than discovering it at 01:15
rem as "operating system error 5" that nobody reads.
rem
rem ROLLBACK: every task is exported to C:\Scripts\yc-backuppath-rollback\<timestamp>\ before it is
rem touched, and any task whose change does not read back correctly is restored automatically.
rem
rem EXISTING FILES: left alone unless -Move. Either way msdb still records the OLD paths until the
rem next full backup runs - after a -Move, run backup-sql -Type Full once so msdb agrees with disk.
rem
rem EXIT CODES: 0 changed and verified | 1 one or more tasks unchanged | 2 usage |
rem             3 SQL unreachable | 4 SQL cannot write to the new path | 5 not elevated
rem
rem Logs to C:\Scripts\yc-sqlbackuppath.log and C:\Scripts\yc-sqlbackuppath.json.
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Yc-SqlBackupPath.ps1" %*
exit /b %ERRORLEVEL%
