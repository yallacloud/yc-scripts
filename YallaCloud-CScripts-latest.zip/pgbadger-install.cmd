@echo off
rem pgbadger-install [-InstallDir <path>] [-Help]
rem Stage pgBadger (PostgreSQL log analyzer, Perl - needs Strawberry Perl). Logs to C:\Scripts\pgbadger-install.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\PgBadger-Install.ps1" %*
