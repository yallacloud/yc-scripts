@echo off
REM ==================================================================================
REM  yc-integrity  -  is this machine's data still intact, and say so either way.
REM
REM    yc-integrity -Sql Fast        CHECKDB PHYSICAL_ONLY, every database (daily pass)
REM    yc-integrity -Sql Full        the whole logical CHECKDB          (weekly pass)
REM    yc-integrity -Disk            chkdsk /scan read-only, every fixed NTFS volume
REM    yc-integrity -RestoreVerify   RESTORE VERIFYONLY over the newest full backup
REM    yc-integrity -SuspectPages    read msdb.dbo.suspect_pages. Instant. Changes nothing.
REM    yc-integrity -Report          say what WOULD run. Changes nothing, sends nothing.
REM    yc-integrity -Help            everything else
REM
REM  It GATES on free space first (CHECKDB snapshots onto the data volume), RE-RUNS any
REM  failure before anyone is told, and reports the PASS as well as the FAIL - because
REM  silence and success look identical from the outside.
REM
REM  It DETECTS. It never repairs: REPAIR_ALLOW_DATA_LOSS does what its name says.
REM
REM  EXIT  0 all passed | 1 FAILED TWICE, escalate | 2 skipped | 3 transient
REM        5 not admin  | 6 SQL unreachable
REM  LOG   C:\Scripts\yc-integrity.log      JSON  C:\Scripts\yc-integrity.json
REM ==================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Yc-Integrity.ps1" %*
exit /b %ERRORLEVEL%
