param(
  [string]$InstallDir = 'C:\Tools\pgbadger',        # where pgBadger is staged
  [switch]$Help
)
# PgBadger-Install.ps1 - PowerShell 5.1, ASCII only.
# pgBadger = PostgreSQL log analyzer, written in PERL. NOT a compiled Windows binary - needs Strawberry Perl.
# This command stages the pgBadger source and, if perl.exe is present, creates a pgbadger.cmd wrapper.
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'pgbadger-install'
$installer = Get-ChildItem 'C:\Scripts\pgbadger-*.tar.gz' -EA SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1

if($Help){
@"
pgbadger-install - stage pgBadger (PostgreSQL log analyzer, Perl script).
                   Staged source: C:\Scripts\pgbadger-*.tar.gz   Log: C:\Scripts\pgbadger-install.log

USAGE:
  pgbadger-install [-InstallDir C:\Tools\pgbadger]

PARAMETERS (required: none):
  -InstallDir  Folder to stage pgBadger into (default C:\Tools\pgbadger).
  -Help        Show this help and exit.

NOTES:
  pgBadger is a Perl program - it needs a Perl runtime. Install Strawberry Perl (https://strawberryperl.com)
  so that perl.exe is on PATH. If perl.exe is found, this command writes a wrapper so you can run: pgbadger <args>.
  Otherwise it just stages the source and prints the manual run command.

EXAMPLES:
  pgbadger-install
  pgbadger-install -InstallDir D:\Tools\pgbadger

Log: C:\Scripts\pgbadger-install.log
"@ | Write-Host -ForegroundColor Cyan
  Stop-YcLog 0; exit 0
}

Assert-YcPrereqs -NeedAdmin
if(-not $installer){ Write-YcLog 'installer not found: C:\Scripts\pgbadger-*.tar.gz' 'ERROR'; Stop-YcLog 1; exit 1 }

if(-not (Test-Path $InstallDir)){ New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
$tar = Get-Command tar.exe -EA SilentlyContinue
if(-not $tar){ Write-YcLog 'tar.exe not found (needs Windows 10/Server 2019+). Extract the tar.gz manually.' 'ERROR'; Stop-YcLog 1; exit 1 }
& tar.exe -xf $installer.FullName -C $InstallDir 2>&1 | Out-Null
$pgb = Get-ChildItem $InstallDir -Recurse -Filter 'pgbadger' | Where-Object { -not $_.PSIsContainer } | Select-Object -First 1
if(-not $pgb){ Write-YcLog 'pgbadger script not found after extract' 'ERROR'; Stop-YcLog 1; exit 1 }
Write-YcLog ('Staged pgBadger to ' + $pgb.FullName)

$perl = Get-Command perl.exe -EA SilentlyContinue
if($perl){
  $wrap = 'C:\Scripts\pgbadger.cmd'
  ('@echo off' + "`r`n" + 'perl "' + $pgb.FullName + '" %*') | Out-File -FilePath $wrap -Encoding ascii -Force
  Write-YcLog ('Perl found (' + $perl.Source + ') - wrote wrapper ' + $wrap + '. Run: pgbadger <postgres-log> -o report.html') 'OK'
}else{
  Write-YcLog 'Strawberry Perl NOT found. Install it from https://strawberryperl.com then run:' 'WARN'
  Write-YcLog ('  perl "' + $pgb.FullName + '" <postgres-log> -o report.html') 'WARN'
}
Write-YcLog 'done'
Stop-YcLog 0
exit 0
