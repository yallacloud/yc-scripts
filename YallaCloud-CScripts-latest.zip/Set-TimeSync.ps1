<#
  Set-TimeSync.ps1 - make sure this machine knows what time it is. One script, four verbs,
  the same shape as set-local-wsus so there is nothing new to remember.

      set-time -Status        what am I synced to, and how far out am I?
      set-time -Test          can I reach the time servers? (changes nothing)
      set-time -Install       use the YallaCloud time sources
      set-time -Uninstall     back to the Windows default

  WHY IT MATTERS MORE THAN IT LOOKS. A clock more than 4 hours out does not just show the wrong
  time - it breaks things that give no hint that time is the cause:
    - KMS activation fails with 0xC004F06C / 0xC004F074 (the KMS host rejects the timestamp),
    - Kerberos refuses tickets past 5 minutes of skew, so domain logons fail,
    - TLS certificates read as not-yet-valid or expired,
    - every log line and every piece of migration evidence carries the wrong timestamp.
  A migrated VM is exactly where this bites: it arrives from another platform, often with the
  host's clock, sometimes with the wrong time zone, and nothing on it complains.

  DOMAIN MEMBERS ARE LEFT ALONE BY DEFAULT. A domain-joined machine must take its time from the
  domain hierarchy (NT5DS) - the PDC emulator is the authority. Pointing a member at an external
  NTP server is how a domain ends up with two disagreeing time sources and intermittent Kerberos
  failures that nobody connects back to this change. -Install REFUSES on a domain member unless
  -Force says you meant it, and -Status says which case this machine is.

  Windows Server 2012R2-2025, PowerShell 5.1, ASCII only.
#>
param(
  [switch]$Install,
  [switch]$Uninstall,
  [switch]$Status,
  [switch]$Test,
  [string]$Server,          # override the source list; space or comma separated
  [int]$MaxSkewSec = 300,   # report a skew above this as a finding (Kerberos breaks at 300)
  [switch]$Force,           # proceed on a domain member
  [switch]$Help
)

$YcLib = 'C:\Scripts\_yc-lib.ps1'
if (-not (Test-Path -LiteralPath $YcLib)) {
  Write-Host 'FATAL: C:\Scripts\_yc-lib.ps1 missing - payload incomplete' -ForegroundColor Red; exit 3
}
. $YcLib
Start-YcLog 'set-time'
$ErrorActionPreference = 'Continue'

# Three independent operators, each with its own anycast network. time.windows.com alone is a
# single point of failure and is widely reported as the least reliable of the three, so it is
# last rather than first. 0x8 = send as a CLIENT at the polling interval, which is what a
# non-domain machine wants; 0x1 would mean "special poll" and is for the domain hierarchy.
$DefaultSources = 'time.google.com,0x8 time.cloudflare.com,0x8 time.windows.com,0x8'

if ($Help -or -not ($Install -or $Uninstall -or $Status -or $Test)) {
@"
set-time  -  make sure this machine knows what time it is.

USAGE:
  set-time -Status                      what this machine is synced to, and how far out it is
  set-time -Test                        can it reach the time servers (changes nothing)
  set-time -Install                     use the YallaCloud time sources
  set-time -Install -Server '<a> <b>'   use these instead
  set-time -Install -Force              do it anyway on a DOMAIN MEMBER (read why below)
  set-time -Uninstall                   back to the Windows default

PARAMETERS:
  -Server       the source list. Space or comma separated. Each may carry a w32tm flag:
                ,0x8 = client mode (the normal one),  ,0x1 = special poll.
                Default: $DefaultSources
  -MaxSkewSec   report a skew larger than this. Default 300 - the point Kerberos refuses tickets.
  -Force        proceed on a domain member. See below before you use it.
  -Help         this text.

WHY IT MATTERS. A clock more than 4 hours out breaks KMS activation (0xC004F06C), Kerberos
refuses tickets past 5 MINUTES of skew so domain logons fail, TLS certificates read as
not-yet-valid, and every log line and every piece of migration evidence is stamped wrong.
Nothing reports "the clock is wrong" - you get the symptoms instead.

DOMAIN MEMBERS ARE LEFT ALONE. A domain-joined machine takes its time from the domain hierarchy
(NT5DS); the PDC emulator is the authority. Pointing a member at an external NTP server gives
the domain two disagreeing sources and intermittent Kerberos failures nobody traces back here.
-Install refuses on a member unless -Force. On the PDC emulator itself, an external source IS
correct - that is the one domain machine this is for.

EXAMPLES:
  set-time -Status                      start here: what is it synced to, how far out is it
  set-time -Test                        can it reach the time servers at all
  set-time -Install                     set the YallaCloud sources and resync
  set-time -Install -Server 'time.google.com,0x8'      one source instead of three
  set-time -Install -Force              on a DOMAIN MEMBER, when you know why
  set-time -Uninstall                   back to the Windows default

EXIT CODES:
  0  done, or healthy
  1  configured but NOT synced, or skew over -MaxSkewSec   (the state worth acting on)
  2  usage
  3  C:\Scripts\_yc-lib.ps1 missing
  5  not Administrator
  6  the change did not take

Log: C:\Scripts\set-time.log
"@ | Write-Host
  Exit-Yc 0
}

Assert-YcPrereqs -NeedAdmin

$W32 = Join-Path $env:windir 'System32\w32tm.exe'
$SvcName = 'W32Time'

function Get-DomainState {
  $o = [ordered]@{ joined=$false; isPdc=$false; domain='' }
  try {
    $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
    $o.joined = [bool]$cs.PartOfDomain
    $o.domain = [string]$cs.Domain
  } catch {}
  # The PDC emulator is the one domain machine that SHOULD take external time.
  if ($o.joined) {
    try {
      $r = (& $W32 /query /status 2>&1 | Out-String)
      if ($r -match '(?im)^\s*Source:\s*Local CMOS Clock') { $o.isPdc = $true }
      $role = (Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).DomainRole
      if ([int]$role -eq 5) { $o.isPdc = $true }   # 5 = primary domain controller
    } catch {}
  }
  return $o
}

function Get-TimeState {
  $s = [ordered]@{ serviceStatus='absent'; startType=''; running=$false
                   source=''; stratum=''; lastSync=''; configured=''; type=''
                   skewSec=$null; synced=$false }
  try {
    $svc = Get-Service -Name $SvcName -ErrorAction Stop
    $s.serviceStatus = [string]$svc.Status
    $s.running = ([string]$svc.Status -eq 'Running')
    try { $s.startType = [string](Get-CimInstance Win32_Service -Filter ("Name='" + $SvcName + "'") -ErrorAction Stop).StartMode } catch {}
  } catch {}
  try {
    $p = Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters' -ErrorAction Stop
    $s.configured = [string]$p.NtpServer
    $s.type       = [string]$p.Type
  } catch {}
  if ($s.running) {
    try { $s.source = ((& $W32 /query /source 2>&1 | Out-String)).Trim() } catch {}
    try {
      $st = (& $W32 /query /status 2>&1 | Out-String)
      if ($st -match '(?im)^\s*Stratum:\s*(.+)$')                 { $s.stratum  = $Matches[1].Trim() }
      if ($st -match '(?im)^\s*Last Successful Sync Time:\s*(.+)$'){ $s.lastSync = $Matches[1].Trim() }
    } catch {}
  }
  $s.synced = ($s.source -and ($s.source -notmatch 'Local CMOS Clock|Free-running'))
  return $s
}

# How far out are we, measured against a real server rather than trusted from the service.
function Get-SkewSeconds {
  param([string]$Host)
  try {
    $out = (& $W32 /stripchart /computer:$Host /samples:1 /dataonly 2>&1 | Out-String)
    # a data line looks like:  13:22:41, +00.0123456s
    if ($out -match '([+-]\d+\.\d+)s') { return [double]$Matches[1] }
  } catch {}
  return $null
}

function Split-Sources {
  param([string]$Raw)
  return @(($Raw -replace ',\s+',' ') -split '[\s,]+' | Where-Object { $_ } | ForEach-Object { ($_ -split ',')[0] })
}

$dom = Get-DomainState
$sources = $(if ($Server) { $Server } else { $DefaultSources })

# ---------------------------------------------------------------- -Status
if ($Status) {
  $t = Get-TimeState
  Write-YcLog ('service      : ' + $t.serviceStatus + $(if ($t.startType) { ' (' + $t.startType + ')' } else { '' }))
  Write-YcLog ('mode         : ' + $(if ($t.type) { $t.type } else { 'unreadable' }) +
               $(if ($t.type -eq 'NT5DS') { '  - domain hierarchy' } elseif ($t.type -eq 'NTP') { '  - explicit NTP servers' } else { '' }))
  Write-YcLog ('configured   : ' + $(if ($t.configured) { $t.configured } else { '(none)' }))
  Write-YcLog ('syncing from : ' + $(if ($t.source) { $t.source } else { '(not running)' }))
  if ($t.stratum)  { Write-YcLog ('stratum      : ' + $t.stratum) }
  if ($t.lastSync) { Write-YcLog ('last sync    : ' + $t.lastSync) }
  Write-YcLog ('domain       : ' + $(if ($dom.joined) { $dom.domain + $(if ($dom.isPdc) { ' (THIS IS THE PDC EMULATOR - external time is correct here)' } else { ' - member, time comes from the domain' }) } else { 'workgroup' }))

  $rc = 0
  if (-not $t.running) {
    Write-YcLog 'the Windows Time service is NOT running, so this machine is not syncing with anything.' 'WARN'
    $rc = 1
  } elseif (-not $t.synced) {
    Write-YcLog 'the clock is FREE-RUNNING (Local CMOS Clock) - it is drifting and nothing is correcting it.' 'WARN'
    $rc = 1
  }
  $probe = @(Split-Sources $(if ($t.configured) { $t.configured } else { $sources })) | Select-Object -First 1
  if ($probe) {
    $sk = Get-SkewSeconds -Host $probe
    if ($null -ne $sk) {
      $a = [math]::Abs($sk)
      Write-YcLog ('offset       : ' + [string][math]::Round($sk,3) + 's against ' + $probe)
      if ($a -gt 14400) {
        Write-YcLog ('the clock is ' + [string][math]::Round($a/3600,1) + ' HOURS out. KMS activation will fail with 0xC004F06C and Kerberos logons will not work. Run  set-time -Install  now.') 'ERROR'
        $rc = 1
      } elseif ($a -gt $MaxSkewSec) {
        Write-YcLog ('the clock is ' + [string][math]::Round($a,0) + 's out, past the ' + [string]$MaxSkewSec + 's Kerberos limit. Domain logons can fail intermittently.') 'WARN'
        $rc = 1
      }
    } else {
      Write-YcLog ('offset       : could not be measured against ' + $probe + ' (blocked or unreachable)') 'WARN'
    }
  }
  if ($rc -eq 0) { Exit-Yc 0 'time is healthy' }
  Exit-Yc 1 'time needs attention - see above'
}

# ---------------------------------------------------------------- -Test
if ($Test) {
  Write-YcLog ('testing: ' + $sources)
  $ok = 0; $bad = 0
  foreach ($h in (Split-Sources $sources)) {
    $sk = Get-SkewSeconds -Host $h
    if ($null -ne $sk) { $ok++;  Write-YcLog ('  ' + $h.PadRight(24) + ' reachable, offset ' + [string][math]::Round($sk,3) + 's') 'OK' }
    else               { $bad++; Write-YcLog ('  ' + $h.PadRight(24) + ' NO ANSWER on UDP 123') 'WARN' }
  }
  if ($ok -gt 0) { Exit-Yc 0 ([string]$ok + ' of ' + [string]($ok+$bad) + ' time source(s) answered - that is enough') }
  Exit-Yc 1 'NO time source answered. UDP 123 outbound is blocked, or none of these hosts is reachable. Nothing was changed.'
}

# ---------------------------------------------------------------- -Uninstall
if ($Uninstall) {
  if ($dom.joined) {
    & $W32 /config /syncfromflags:domhier /update | Out-Null
    Write-YcLog 'put back on the DOMAIN hierarchy (NT5DS), which is correct for a domain member' 'OK'
  } else {
    & $W32 /config /manualpeerlist:"time.windows.com,0x8" /syncfromflags:manual /update | Out-Null
    Write-YcLog 'put back on the Windows default (time.windows.com)' 'OK'
  }
  Restart-Service -Name $SvcName -Force -ErrorAction SilentlyContinue
  Start-Sleep -Seconds 2
  & $W32 /resync /force 2>&1 | Out-Null
  $t = Get-TimeState
  Write-YcLog ('syncing from : ' + $(if ($t.source) { $t.source } else { '(not yet)' }))
  Exit-Yc 0 'reverted'
}

# ---------------------------------------------------------------- -Install
if ($dom.joined -and -not $dom.isPdc -and -not $Force) {
  Write-YcLog ('this machine is a member of ' + $dom.domain + '. A domain member must take its time from the domain hierarchy - the PDC emulator is the authority.') 'WARN'
  Write-YcLog 'Pointing a member at external NTP gives the domain two disagreeing sources and intermittent Kerberos failures nobody traces back to this change.' 'WARN'
  Write-YcLog 'If the DOMAIN itself has the wrong time, fix it on the PDC emulator - run this there, where an external source IS correct.' 'WARN'
  Exit-Yc 2 'refused on a domain member. Use -Force only if you know why. Nothing was changed.'
}

Write-YcLog ('setting the time sources: ' + $sources)
if ($dom.isPdc) { Write-YcLog 'this is the PDC emulator - an external source is the correct configuration here' 'OK' }

try { Set-Service -Name $SvcName -StartupType Automatic -ErrorAction Stop } catch { Write-YcLog ('could not set W32Time to Automatic: ' + $_.Exception.Message) 'WARN' }
try { Start-Service -Name $SvcName -ErrorAction Stop } catch {}

& $W32 /config /manualpeerlist:"$sources" /syncfromflags:manual /reliable:$(if ($dom.isPdc) {'yes'} else {'no'}) /update 2>&1 | Out-Null
Restart-Service -Name $SvcName -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3
& $W32 /resync /force 2>&1 | Out-Null
Start-Sleep -Seconds 2

# PROVE IT. A w32tm command that returned quietly is not evidence that the clock is right.
$t = Get-TimeState
Write-YcLog ('configured   : ' + $(if ($t.configured) { $t.configured } else { '(unreadable)' }))
Write-YcLog ('syncing from : ' + $(if ($t.source) { $t.source } else { '(none yet)' }))
if (-not $t.running) { Exit-Yc 6 'the Windows Time service is not running after the change' }
if (-not $t.synced) {
  Write-YcLog 'the service is running but still shows Local CMOS Clock. It can take a few minutes on the first sync; run  set-time -Status  again shortly.' 'WARN'
  Exit-Yc 1 'configured, but not yet synced - check again in a few minutes'
}
$probe = @(Split-Sources $sources) | Select-Object -First 1
$sk = Get-SkewSeconds -Host $probe
if ($null -ne $sk -and [math]::Abs($sk) -gt $MaxSkewSec) {
  Exit-Yc 1 ('configured and syncing, but still ' + [string][math]::Round($sk,0) + 's out against ' + $probe + ' - give it another resync, then check -Status')
}
Exit-Yc 0 ('time is set and syncing from ' + $t.source + $(if ($null -ne $sk) { ', offset ' + [string][math]::Round($sk,3) + 's' } else { '' }))
