param(
  [string]$InstallDir = 'C:\Tools\percona-toolkit',  # where the source is staged
  [switch]$Help
)
# Percona-Toolkit-Install.ps1 - PowerShell 5.1, ASCII only.
# Percona Toolkit = MySQL/MariaDB CLI tools, written in PERL for Linux. NOT native Windows.
# This command stages the toolkit source and documents how to run it (Linux host / WSL2 / Strawberry Perl best-effort).
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'percona-toolkit-install'
$installer = Get-ChildItem 'C:\Scripts\percona-toolkit-*.tar.gz' -EA SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1

if($Help){
@"
percona-toolkit-install - stage Percona Toolkit (MySQL/MariaDB admin CLI tools, Perl/Linux).
                          Staged source: C:\Scripts\percona-toolkit-*.tar.gz   Log: C:\Scripts\percona-toolkit-install.log

USAGE:
  percona-toolkit-install [-InstallDir C:\Tools\percona-toolkit]

PARAMETERS (required: none):
  -InstallDir  Folder to stage Percona Toolkit into (default C:\Tools\percona-toolkit).
  -Help        Show this help and exit.

NOTES:
  Percona Toolkit is NOT a native Windows product. The tools (pt-query-digest, pt-online-schema-change, etc.)
  are Perl scripts targeting Linux/Unix. Run them from a Linux host, WSL2, or a container against your DB.
  Strawberry Perl can run some read-only tools (e.g. pt-query-digest) but full support is Linux only.

EXAMPLES:
  percona-toolkit-install
  percona-toolkit-install -InstallDir D:\Tools\percona-toolkit

Log: C:\Scripts\percona-toolkit-install.log
"@ | Write-Host -ForegroundColor Cyan
  Stop-YcLog 0; exit 0
}

Assert-YcPrereqs -NeedAdmin
if(-not $installer){ Write-YcLog 'installer not found: C:\Scripts\percona-toolkit-*.tar.gz' 'ERROR'; Stop-YcLog 1; exit 1 }

if(-not (Test-Path $InstallDir)){ New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
$tar = Get-Command tar.exe -EA SilentlyContinue
if(-not $tar){ Write-YcLog 'tar.exe not found (needs Windows 10/Server 2019+). Extract the tar.gz manually.' 'ERROR'; Stop-YcLog 1; exit 1 }
& tar.exe -xf $installer.FullName -C $InstallDir 2>&1 | Out-Null
$binDir = Get-ChildItem $InstallDir -Recurse -Directory -Filter 'bin' | Select-Object -First 1
if($binDir){ Write-YcLog ('Staged Percona Toolkit; tools in ' + $binDir.FullName) }
else{ Write-YcLog ('Staged Percona Toolkit source to ' + $InstallDir) }
Write-YcLog 'Percona Toolkit is Linux/Perl - not native Windows. Run from a Linux host / WSL2 / container:' 'WARN'
Write-YcLog '  pt-query-digest slow.log   |   pt-online-schema-change ...' 'WARN'
Write-YcLog 'done (staged only)' 'OK'
Stop-YcLog 0
exit 0
