param(
  [string]$ProductKey,
  [string]$InstanceName = 'MSSQLSERVER',
  [string]$SetupPath,
  [switch]$GlpiUpdate,
  [switch]$NoGlpi,
  [string]$TargetEdition,
  [int]$TimeoutMinutes = 30,
  [switch]$NoSkipRules,
  [switch]$Force,
  [switch]$Help
)
# =====================================================================================
# Activate-Sql.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only (0x00-0x7F).
#
# WHAT CHANGED AND WHY
# --------------------
# The previous version printed a setup exit code and some registry text two seconds
# later and called that "activation". It was the Acronis defect with better cosmetics.
# This version proves the edition changed or fails loudly.
#
#  1. EXIT CODE NO LONGER CLOBBERED BY GLPI (was P1-1, old lines 69-75).
#     setup.exe's $LASTEXITCODE is captured into $rc on the very next statement. The
#     optional GLPI inventory runs afterwards and can never influence the exit code.
#  2. REAL VERIFICATION, NOT "activation attempted" (was P1-2, old lines 71-72).
#     After setup returns we wait for the SQL Server service to come back (Microsoft:
#     "For the SQL Server edition change to be activated, Setup must restart SQL Server
#     services"), then poll SERVERPROPERTY('Edition') / ('EditionID') /
#     ('ProductVersion') / ('ProductLevel') over a real TDS connection until the edition
#     changes or the deadline expires. Still Evaluation, or unchanged => ERROR + non-zero.
#     Old 'Start-Sleep 2' removed - it read the registry mid-upgrade.
#  3. VENDOR COMMAND LINE MATCHED TO THE DOCS (was P1-3, old line 69).
#     /SkipRules=Engine_SqlEngineHealthCheck is now emitted by default - it is the
#     documented workaround for the health-check rule that fires on exactly the machine
#     people run this script on (an expired Evaluation instance whose service will not
#     start). /IACCEPTSQLSERVERLICENSETERMS is RETAINED: contrary to the audit note, the
#     "Upgrade parameters" table (which is the table that documents /ACTION=EditionUpgrade)
#     lists it as "Required, when the /Q or /QS parameter is specified for unattended
#     installations". We pass /q, so it is required, not decorative.
#  4. NO SHELL-STRING INTERPOLATION OF THE KEY (was P2-1/P2-3, old line 69).
#     Arguments are built as a string[] and splatted (& $setup @setupArgs), so PowerShell
#     hands argv straight to CreateProcess. The key is validated against the documented
#     5x5 format before use and is masked in every log line. The unavoidable residual
#     exposure (Win32_Process.CommandLine for the life of setup.exe) is stated in -Help.
#  5. setup.exe RESOLUTION MATCHED TO THE INSTANCE (was P2-2, old line 66).
#     The instance's own major version is read from the registry, then every candidate
#     setup.exe is filtered by its FileVersionInfo major version. No more "newest mtime
#     anywhere under Program Files", which picks a 2019 bootstrap for a 2022 instance.
#  6. IDEMPOTENT / UPGRADE-SAFE (was P2-4).
#     If the instance is already licensed (or already matches -TargetEdition) the script
#     logs OK and exits 0 without touching setup. -Force overrides.
#  7. EXIT 3010 IS SUCCESS-PENDING-REBOOT (was P2-5, old line 70), reported as such.
#  8. NO SILENT FAILURE PATHS. -ErrorAction SilentlyContinue removed from every
#     load-bearing call. Optional-feature probes (GLPI) use filtering, not error suppression.
#     One unhandled-exception guard means every path reaches Stop-YcLog with the real code.
#  9. sqlcmd IS RESOLVED, NOT ASSUMED. SQL Server 2022/2025 setup no longer installs
#     sqlcmd (Client Tools Connectivity was dropped from the feature list). Verification
#     therefore uses System.Data.SqlClient (part of .NET Framework, always present on
#     Server 2016+) as the primary path; sqlcmd is only a fallback, is located through
#     PATH + registry + every known install root, and when genuinely absent the script
#     says so and prints the download URL instead of shelling out to the bare string
#     'sqlcmd.exe'.
# 10. Dead code removed (P3-1, old line 32) and the registry property filter tightened
#     from '-notlike PS*' to an explicit exclusion list (P3-2).
#
# PARAMETERS ADDED (none renamed, none removed):
#     -TargetEdition, -TimeoutMinutes, -NoSkipRules, -Force
#
# Log: C:\Scripts\activate-sql.log
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'activate-sql'
$ErrorActionPreference = 'Stop'

$HelpText = @"
activate-sql - edition-upgrade a SQL Server instance (Evaluation -> licensed) and PROVE it changed.

USAGE:
  activate-sql -ProductKey <XXXXX-XXXXX-XXXXX-XXXXX-XXXXX> [-InstanceName MSSQLSERVER]
               [-SetupPath <setup.exe>] [-TargetEdition <name>] [-TimeoutMinutes 30]
               [-NoSkipRules] [-Force] [-GlpiUpdate | -NoGlpi]
  activate-sql -Help

PARAMETERS:
  -ProductKey     REQUIRED. SQL Server product key matching the installed version and the
                  target edition. Must be 5 groups of 5 alphanumeric characters separated
                  by hyphens. Validated before use; masked in all log output.
  -InstanceName   Database Engine instance name. Default MSSQLSERVER (the default instance).
  -SetupPath      Full path to the SQL media setup.exe. If omitted, the script resolves the
                  instance's own major version from the registry and selects a setup.exe
                  whose file version matches. Pass this explicitly on multi-version hosts.
  -TargetEdition  Expected edition after the upgrade, e.g. Standard, Enterprise, Developer,
                  Web. If supplied it is asserted after the upgrade, and if the instance is
                  ALREADY that edition the script exits 0 without running setup.
  -TimeoutMinutes How long to wait for SQL Server to restart and report the new edition.
                  Default 30. An edition upgrade takes minutes, not seconds.
  -Force          Continue even when a reboot is pending. By default activate-sql REFUSES in
                  that state with exit 2, because setup.exe fails its RebootRequiredCheck rule
                  for every action and would do so minutes later, as a setup error.
  -NoSkipRules    Do NOT pass /SkipRules=Engine_SqlEngineHealthCheck. By default the script
                  passes it, which is Microsoft's documented workaround for the health-check
                  rule that fails when the Evaluation period has already expired.
  -Force          Run setup even when the instance already looks licensed.
  -GlpiUpdate     Force a GLPI inventory push after a SUCCESSFUL verified upgrade.
  -NoGlpi         Never run a GLPI inventory. Unattended runs skip GLPI unless -GlpiUpdate.
  -Help           Show this help and exit 0.

EXAMPLES:
  activate-sql -ProductKey ABCDE-FGHIJ-KLMNO-PQRST-UVWXY
  activate-sql -ProductKey ABCDE-FGHIJ-KLMNO-PQRST-UVWXY -TargetEdition Standard
  activate-sql -ProductKey ABCDE-FGHIJ-KLMNO-PQRST-UVWXY -InstanceName SQL2022 -TimeoutMinutes 45
  activate-sql -ProductKey ABCDE-FGHIJ-KLMNO-PQRST-UVWXY -SetupPath D:\setup.exe -GlpiUpdate
  activate-sql -Help

EXIT CODES:
  0     Verified. The instance reports the new (non-Evaluation) edition.
  1     Failure: bad usage, no instance, no setup.exe, setup failed, or VERIFICATION FAILED.
  6     Refused as an impossible edition change, before the key was used: a downgrade
        (Enterprise to Standard, anything to Web) or Express, which no edition upgrade can
        reach. Nothing was changed.
  2     Refused by preflight, before the key was used and before anything changed:
        an invalid -ProductKey format (5 groups of 5 alphanumeric characters), or a
        pending reboot, which setup.exe's RebootRequiredCheck rule fails. Restart the
        machine, or pass -Force to try anyway.
  5     Not elevated (from _yc-lib Assert-YcPrereqs).
  3010  Setup succeeded but a reboot is required before the change can be verified.
  Any other value is setup.exe's own exit code, passed through unmodified.

SECURITY NOTE:
  /PID=<key> is unavoidably visible in Win32_Process.CommandLine and in Windows event 4688
  for the lifetime of setup.exe. There is no answer-file form of editionupgrade. Run this
  when no untrusted local users have a session on the host. The key is never written to the
  log, never written to disk, and never interpolated into a shell string.

Log: C:\Scripts\activate-sql.log   Setup logs: <bootstrap>\Log\Summary.txt
"@

if($Help){ Write-Host $HelpText -ForegroundColor Cyan; Stop-YcLog 0; exit 0 }
if(-not $ProductKey){
  Write-Host $HelpText -ForegroundColor Cyan
  Write-YcLog '-ProductKey is required.' 'ERROR'
  Stop-YcLog 1; exit 1
}

Assert-YcPrereqs -NeedAdmin

$script:YcExit = 1

# ------------------------------------------------------------------ helpers

function Get-YcMaskedKey([string]$Key){
  if([string]::IsNullOrEmpty($Key)){ return '(empty)' }
  if($Key.Length -le 5){ return '*****' }
  return ('*' * ($Key.Length - 5)) + $Key.Substring($Key.Length - 5)
}

# Registry inventory of every installed Database Engine instance.
# Returns objects: Name, RegId, Hive, Edition, Version, PatchLevel, IsEvaluation.
function Get-YcSqlInstances{
  $out = @()
  $skip = @('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider')
  foreach($root in @('HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server',
                     'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Microsoft SQL Server')){
    $namesKey = Join-Path $root 'Instance Names\SQL'
    if(-not (Test-Path $namesKey)){ continue }
    $inst = Get-ItemProperty -Path $namesKey
    foreach($p in ($inst.PSObject.Properties | Where-Object { $skip -notcontains $_.Name })){
      $setupKey = Join-Path $root ($p.Value + '\Setup')
      if(-not (Test-Path $setupKey)){ continue }
      $s = Get-ItemProperty -Path $setupKey
      $ed = [string]$s.Edition
      $out += (New-Object psobject -Property @{
        Name         = [string]$p.Name
        RegId        = [string]$p.Value
        SetupKey     = $setupKey
        Edition      = $ed
        Version      = [string]$s.Version
        PatchLevel   = [string]$s.PatchLevel
        IsEvaluation = ($ed -match 'Eval')
      })
    }
  }
  return $out
}

function Get-YcSqlInstance([string]$Name){
  $all = Get-YcSqlInstances
  foreach($i in $all){ if($i.Name -eq $Name){ return $i } }
  return $null
}

function Show-YcSqlState([string]$When){
  $all = Get-YcSqlInstances
  Write-Host ('==== SQL Server state (' + $When + ') ====') -ForegroundColor Cyan
  if($all.Count -eq 0){
    Write-Host '  (no SQL Server Database Engine instance found)' -ForegroundColor Yellow
    Write-YcLog ('state(' + $When + '): no SQL instance') 'WARN'
    return
  }
  foreach($i in $all){
    Write-Host ('  Instance ' + $i.Name + ' : ' + $i.Edition + '   v' + $i.Version +
                '   patch ' + $i.PatchLevel + '   Evaluation: ' + $i.IsEvaluation)
    Write-YcLog ('state(' + $When + '): ' + $i.Name + ' edition=' + $i.Edition +
                 ' v' + $i.Version + ' patch=' + $i.PatchLevel + ' eval=' + $i.IsEvaluation)
  }
}

# Windows service name for a Database Engine instance.
function Get-YcSqlServiceName([string]$Name){
  if($Name -eq 'MSSQLSERVER'){ return 'MSSQLSERVER' }
  return ('MSSQL$' + $Name)
}

# ".": default instance, ".\NAME": named instance. Used for the local TDS connection.
function Get-YcSqlConnectTarget([string]$Name){
  if($Name -eq 'MSSQLSERVER'){ return '.' }
  return ('.\' + $Name)
}

# --- SERVERPROPERTY over System.Data.SqlClient (primary verification path) ------------
# System.Data.SqlClient ships with the .NET Framework, so this works on a stock Server
# 2016 box and on SQL Server 2022/2025 hosts where sqlcmd.exe is not installed at all.
function Get-YcServerProperties{
  param([string]$Target,[int]$TimeoutSec = 15)
  $q = "SET NOCOUNT ON; SELECT CONVERT(nvarchar(128),SERVERPROPERTY('Edition')) AS Edition," +
       "CONVERT(nvarchar(128),SERVERPROPERTY('EditionID')) AS EditionID," +
       "CONVERT(nvarchar(128),SERVERPROPERTY('ProductVersion')) AS ProductVersion," +
       "CONVERT(nvarchar(128),SERVERPROPERTY('ProductLevel')) AS ProductLevel," +
       "CONVERT(nvarchar(128),SERVERPROPERTY('ProductUpdateLevel')) AS ProductUpdateLevel"
  $r = $null
  $cn = $null
  try{
    Add-Type -AssemblyName 'System.Data'
    $cs = 'Server=' + $Target + ';Database=master;Integrated Security=SSPI;Connect Timeout=' +
          $TimeoutSec + ';Application Name=YallaCloud-activate-sql'
    $cn = New-Object System.Data.SqlClient.SqlConnection $cs
    $cn.Open()
    $cmd = $cn.CreateCommand()
    $cmd.CommandText = $q
    $cmd.CommandTimeout = $TimeoutSec
    $rd = $cmd.ExecuteReader()
    if($rd.Read()){
      $r = @{
        Edition            = [string]$rd['Edition']
        EditionID          = [string]$rd['EditionID']
        ProductVersion     = [string]$rd['ProductVersion']
        ProductLevel       = [string]$rd['ProductLevel']
        ProductUpdateLevel = [string]$rd['ProductUpdateLevel']
        Source             = 'System.Data.SqlClient'
      }
    }
    $rd.Close()
  }catch{
    $script:YcSqlLastError = $_.Exception.Message
    $r = $null
  }finally{
    if($cn -ne $null){ try{ $cn.Close() }catch{} ; try{ $cn.Dispose() }catch{} }
  }
  if($r -ne $null){ return $r }

  # ---- fallback: sqlcmd, located robustly, never assumed -----------------------------
  $sqlcmd = Resolve-YcSqlCmd
  if(-not $sqlcmd){
    Write-YcLog ('SqlClient query failed (' + $script:YcSqlLastError + ') and sqlcmd.exe ' +
      'is not installed on this host. SQL Server 2022/2025 setup no longer installs it ' +
      '(Client Tools Connectivity was removed from the feature list). Install the ' +
      'Microsoft ODBC sqlcmd utility from ' +
      'https://learn.microsoft.com/en-us/sql/tools/sqlcmd/sqlcmd-download-install ' +
      'or fix the failing Windows-auth connection, then re-run.') 'WARN'
    return $null
  }
  try{
    # -s '|' is not cosmetic. Every SQL Server edition string contains spaces -
    # "Evaluation Edition (64-bit)", "Enterprise Edition: Core-based Licensing" - so the
    # old split on whitespace shattered column 1 across three fields and shifted every
    # value one or more places left. EditionID then held the word "Edition", and the
    # edition comparisons downstream were made against the FIRST WORD of the edition
    # rather than the edition. A single pipe separator keeps the columns intact.
    $raw = & $sqlcmd -S $Target -E -b -h -1 -W -s '|' -l $TimeoutSec -Q ($q + ";")
    $rc  = $LASTEXITCODE
    if($rc -ne 0){ throw ('sqlcmd exit ' + $rc + ': ' + ($raw -join ' ')) }
    $line = ($raw | Where-Object { $_ -and $_.Trim().Length -gt 0 -and $_ -notmatch '^[-|\s]+$' } |
             Select-Object -First 1)
    $cols = @($line -split '\|')
    if($cols.Count -lt 5){ throw ('unparseable sqlcmd output (expected 5 pipe-separated columns, got ' + $cols.Count + '): ' + $line) }
    $ed  = $cols[0].Trim()
    $eid = $cols[1].Trim()
    # EditionID is a signed integer. If it is not, the row did not parse the way we think
    # it did, and returning shifted values would let a still-Evaluation instance be
    # reported as verified. Fail loudly instead of guessing.
    if($eid -notmatch '^-?\d+$'){ throw ('sqlcmd output did not parse - EditionID is "' + $eid + '", not a number. Refusing to verify from it. Line: ' + $line) }
    if(-not $ed){ throw ('sqlcmd returned an empty Edition. Line: ' + $line) }
    return @{
      Edition            = $ed
      EditionID          = $eid
      ProductVersion     = $cols[2].Trim()
      ProductLevel       = $cols[3].Trim()
      ProductUpdateLevel = $cols[4].Trim()
      Source             = ('sqlcmd (' + $sqlcmd + ')')
    }
  }catch{
    Write-YcLog ('sqlcmd fallback failed: ' + $_.Exception.Message) 'WARN'
    return $null
  }
}

# Locate sqlcmd.exe without ever degrading to the bare string 'sqlcmd.exe'.
function Resolve-YcSqlCmd{
  if($script:YcSqlCmdPath -ne $null){ return $script:YcSqlCmdPath }
  $found = $null

  $cmd = Get-Command -Name 'sqlcmd.exe' -CommandType Application -ErrorAction Ignore |
         Select-Object -First 1
  if($cmd){ $found = $cmd.Source }

  if(-not $found){
    # ODBC sqlcmd registers its Binn directory here (e.g. ...\Client SDK\ODBC\170\Tools\Binn\).
    foreach($hive in @('HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Client SDK\ODBC',
                       'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Microsoft SQL Server\Client SDK\ODBC')){
      if(-not (Test-Path $hive)){ continue }
      $vers = Get-ChildItem -Path $hive | Sort-Object Name -Descending
      foreach($v in $vers){
        $cs = Join-Path $v.PSPath 'Tools\ClientSetup'
        if(-not (Test-Path $cs)){ continue }
        $p = $null
        try{ $p = (Get-ItemProperty -Path $cs).Path }catch{ $p = $null }
        if($p){
          $cand = Join-Path $p 'SQLCMD.EXE'
          if(Test-Path $cand){ $found = $cand; break }
        }
      }
      if($found){ break }
    }
  }

  if(-not $found){
    $globs = @(
      'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\*\Tools\Binn\SQLCMD.EXE',
      'C:\Program Files (x86)\Microsoft SQL Server\Client SDK\ODBC\*\Tools\Binn\SQLCMD.EXE',
      'C:\Program Files\Microsoft SQL Server\*\Tools\Binn\SQLCMD.EXE',
      'C:\Program Files (x86)\Microsoft SQL Server\*\Tools\Binn\SQLCMD.EXE',
      'C:\Program Files\sqlcmd\sqlcmd.exe',
      'C:\Program Files (x86)\sqlcmd\sqlcmd.exe'
    )
    if($env:ProgramData){ $globs += (Join-Path $env:ProgramData 'chocolatey\bin\sqlcmd.exe') }
    foreach($g in $globs){
      $hit = Get-ChildItem -Path $g -ErrorAction Ignore | Sort-Object FullName -Descending |
             Select-Object -First 1
      if($hit){ $found = $hit.FullName; break }
    }
  }

  if($found){ Write-YcLog ('Resolved sqlcmd: ' + $found) }
  $script:YcSqlCmdPath = $found
  return $found
}

# Select a setup.exe whose FILE VERSION matches the instance's major version.
function Resolve-YcSetupExe{
  param([string]$Explicit,[int]$MajorVersion)
  if($Explicit){
    if(-not (Test-Path -LiteralPath $Explicit)){
      Write-YcLog ('-SetupPath does not exist: ' + $Explicit) 'ERROR'
      return $null
    }
    return (Get-Item -LiteralPath $Explicit).FullName
  }
  $roots = @('C:\Program Files\Microsoft SQL Server','C:\Program Files (x86)\Microsoft SQL Server')
  $cands = @()
  foreach($r in $roots){
    if(-not (Test-Path $r)){ continue }
    $cands += Get-ChildItem -Path (Join-Path $r '*\Setup Bootstrap\*\setup.exe') -ErrorAction Ignore
    $cands += Get-ChildItem -Path (Join-Path $r '*\Setup Bootstrap\setup.exe')   -ErrorAction Ignore
  }
  # The bootstrap setup.exe reports its FileVersion as "<year>.0<major>.<build>.<rev>" -
  # SQL 2017 is 2017.0140.1000.169 - so FileMajorPart is 2017, NOT 14, and the old equality
  # test could never match. Measured on a Server 2016 lab VM on 2026-08-31: the file was sitting at
  # ...\Microsoft SQL Server\140\Setup Bootstrap\SQL2017\setup.exe and was still reported
  # missing, so SQL edition activation could not run at all without -SetupPath by hand.
  # Any one of three signals is enough: the version-numbered parent directory (130/140/150/
  # 160/170), the second component of the file version, or a genuinely-14-style major part.
  $matched = @()
  foreach($c in $cands){
    $ok = $false
    if($c.FullName -match ('\\' + ([string]($MajorVersion * 10)) + '\\Setup Bootstrap\\')){ $ok = $true }
    if(-not $ok){
      $fvs = ''
      try{ $fvs = [string]$c.VersionInfo.FileVersion }catch{ $fvs = '' }
      if($fvs -match ('^\d{4}\.0*' + [string]$MajorVersion + '\D')){ $ok = $true }
    }
    if(-not $ok){
      try{ if([int]$c.VersionInfo.FileMajorPart -eq $MajorVersion){ $ok = $true } }catch{}
    }
    if($ok){ $matched += $c }
  }
  if($matched.Count -eq 0){
    Write-YcLog ('No setup.exe with file version ' + $MajorVersion + '.x found under ' +
      '"Setup Bootstrap". Candidates inspected: ' + $cands.Count + '. Pass -SetupPath ' +
      'pointing at the SQL Server ' + $MajorVersion + '.x installation media setup.exe.') 'ERROR'
    return $null
  }
  $pick = $matched | Sort-Object { $_.VersionInfo.FileVersion } -Descending | Select-Object -First 1
  Write-YcLog ('Resolved setup.exe: ' + $pick.FullName + ' (file version ' +
               $pick.VersionInfo.FileVersion + ')')
  return $pick.FullName
}

function Get-YcSetupSummaryPath{
  <#
    .SYNOPSIS
      Resolve where setup.exe wrote Summary.txt for this run.
    .DESCRIPTION
      The bootstrap copy of setup.exe lives at
          <root>\Setup Bootstrap\<version>\setup.exe
      so its Summary.txt is two levels up in Log\Summary.txt. That layout does
      NOT hold for installation media. With -SetupPath E:\setup.exe the first
      Split-Path returns "E:\" and the second returns an EMPTY STRING, and
      Join-Path then throws

          Cannot bind argument to parameter 'Path' because it is an empty string

      which is an unhandled exception, not a clean error. That is exactly what
      killed a real run on X19B on 2026-08-29 at 19:45:13, immediately after
      setup.exe had already been launched - so the operator got a stack trace
      instead of the exit code.

      This resolves the two-levels-up form when it exists, otherwise falls back
      to the documented fixed location for the instance major version
      (13 -> 130, 14 -> 140, 15 -> 150, 16 -> 160, 17 -> 170), and never hands
      Join-Path an empty string.
  #>
  param(
    [string] $SetupExe,
    [int]    $MajorVersion = 0
  )
  # Plain string concatenation, not Join-Path. Join-Path VALIDATES the drive and
  # throws "Cannot find drive" for a path on a volume that is not mounted - and a
  # path we may only ever print must never be able to throw.
  $join = { param($a, $b) ([string]$a).TrimEnd('\') + '\' + ([string]$b).TrimStart('\') }

  $up1 = ''; $up2 = ''
  if($SetupExe){ try{ $up1 = [string](Split-Path -Parent $SetupExe) }catch{ $up1 = '' } }
  if($up1)     { try{ $up2 = [string](Split-Path -Parent $up1)      }catch{ $up2 = '' } }

  if($up2){
    $p = & $join $up2 'Log\Summary.txt'
    $exists = $false
    try{ $exists = Test-Path -LiteralPath $p }catch{ $exists = $false }
    if($exists){ return $p }
  }
  if($MajorVersion -gt 0){
    $pf = ${env:ProgramFiles}; if(-not $pf){ $pf = 'C:\Program Files' }
    return (& $join $pf ('Microsoft SQL Server\' + ($MajorVersion * 10) + '\Setup Bootstrap\Log\Summary.txt'))
  }
  if($up2){ return (& $join $up2 'Log\Summary.txt') }
  return '(setup summary path could not be derived from "' + $SetupExe + '")'
}

function Write-YcSetupSummary{
  <#
    .SYNOPSIS
      Echo the only part of a failed SQL setup run that actually explains it.
    .DESCRIPTION
      Microsoft publishes no table of SQL Server setup return codes - codes like
      -2061893586 (0x851A002E) have no documented meaning anywhere. What IS
      stable is the "Exit error code" / "Exit message" pair setup writes into
      Summary.txt, so print that instead of leaving the operator with a number.
  #>
  param([string] $SummaryPath)
  if(-not $SummaryPath){ return }
  if(-not (Test-Path -LiteralPath $SummaryPath)){
    Write-YcLog ('Setup summary not found at: ' + $SummaryPath) 'WARN'
    return
  }
  $lines = @()
  try{ $lines = Get-Content -LiteralPath $SummaryPath -ErrorAction Stop }catch{ return }
  foreach($l in $lines){
    if("$l" -match '(?i)^\s*(Final result|Exit code \(Decimal\)|Exit error code|Exit message|Exit facility code)\s*:'){
      Write-YcLog ('  summary: ' + ("$l").Trim()) 'ERROR'
    }
  }
}

function Wait-YcSqlServiceRunning{
  param([string]$ServiceName,[datetime]$Deadline)
  while((Get-Date) -lt $Deadline){
    $svc = Get-Service | Where-Object { $_.Name -eq $ServiceName } | Select-Object -First 1
    if($svc -and $svc.Status -eq 'Running'){ return $true }
    Start-Sleep -Seconds 5
  }
  return $false
}

function Invoke-YcGlpiInventory{
  $dir = 'C:\Program Files\GLPI-Agent'
  $svc = Get-Service | Where-Object { $_.Name -match '^(?i)glpi-agent$' } | Select-Object -First 1
  if(-not $svc -and -not (Test-Path $dir)){ Write-YcLog 'GLPI agent not installed - inventory skipped.'; return }
  $configured = $false
  if(Test-Path 'HKLM:\SOFTWARE\GLPI-Agent\Agent'){
    try{ if((Get-ItemProperty -Path 'HKLM:\SOFTWARE\GLPI-Agent\Agent').server){ $configured = $true } }catch{}
  }
  if(-not $configured -and (Test-Path (Join-Path $dir 'etc'))){
    $hits = Get-ChildItem -Path (Join-Path $dir 'etc') -Recurse -File -ErrorAction Ignore |
            Select-String -Pattern 'server' -ErrorAction Ignore
    if($hits){ $configured = $true }
  }
  if(-not $configured){ Write-YcLog 'GLPI agent installed but no server configured - inventory skipped.'; return }
  $exe = Get-ChildItem -Path $dir -Recurse -Filter 'glpi-agent.exe' -ErrorAction Ignore |
         Select-Object -First 1
  if($exe){
    Write-YcLog 'Triggering GLPI inventory (glpi-agent.exe --force)...'
    & $exe.FullName --force | Out-Host
    $grc = $LASTEXITCODE            # captured and DISCARDED - never leaks to our exit code
    if($grc -eq 0){ Write-YcLog 'GLPI inventory triggered.' 'OK' }
    else{ Write-YcLog ('GLPI inventory returned ' + $grc + ' (ignored; does not affect this script''s exit code).') 'WARN' }
  }elseif($svc){
    Write-YcLog 'glpi-agent.exe not found; restarting the GLPI agent service instead.'
    try{ Restart-Service -Name $svc.Name -ErrorAction Stop; Write-YcLog 'GLPI agent service restarted.' 'OK' }
    catch{ Write-YcLog ('GLPI agent restart failed: ' + $_.Exception.Message) 'WARN' }
  }
}

function Invoke-YcMaybeGlpi{
  if($NoGlpi){ Write-YcLog 'GLPI: -NoGlpi set, skipping.'; return }
  if($GlpiUpdate){ Invoke-YcGlpiInventory; return }
  if([Environment]::UserInteractive){
    $a = Read-Host 'Run a GLPI inventory update now? [y/N]'
    if($a -match '^(?i)(y|yes)$'){ Invoke-YcGlpiInventory } else { Write-YcLog 'GLPI: declined at prompt.' }
  }else{
    Write-YcLog 'GLPI: unattended run - inventory skipped (use -GlpiUpdate to force).'
  }
}

# ------------------------------------------------------------------ main

function Invoke-Main{

  # --- 1. validate the key BEFORE it is used anywhere -------------------------------
  $key = $ProductKey.Trim().ToUpperInvariant()
  if($key -notmatch '^[A-Z0-9]{5}(-[A-Z0-9]{5}){4}$'){
    Write-YcLog ('Invalid -ProductKey format. A SQL Server product key is 5 groups of 5 ' +
      'alphanumeric characters separated by hyphens (XXXXX-XXXXX-XXXXX-XXXXX-XXXXX). ' +
      'Got ' + $ProductKey.Length + ' characters. Nothing was run.') 'ERROR'
    $script:YcExit = 2; return
  }
  $mask = Get-YcMaskedKey $key
  Write-YcLog ('Product key format OK, using ' + $mask)

  if([string]::IsNullOrWhiteSpace($InstanceName)){
    Write-YcLog '-InstanceName must not be empty.' 'ERROR'; $script:YcExit = 1; return
  }

  # --- 1b. pending reboot ------------------------------------------------------------
  # setup.exe runs its RebootRequiredCheck rule for EVERY action, editionupgrade included.
  # With a reboot pending it fails that rule - but only after it has unpacked itself and
  # spent several minutes, and the failure reads as a setup error rather than as "restart
  # this machine". Refusing here costs a second and says the actual thing to do. -Force
  # proceeds anyway, for the case where you know the indicator is stale.
  $pending = Get-YcPendingRebootReasons
  if($pending.Count -gt 0){
    if($Force){
      Write-YcLog ('A reboot is pending (' + ($pending -join '; ') + ') and setup.exe fails its ' +
        'RebootRequiredCheck rule in this state. -Force was supplied, so this run continues ' +
        'anyway - expect setup to refuse unless the indicator is stale.') 'WARN'
    } else {
      Write-YcLog ('PREFLIGHT REFUSED: a reboot is pending (' + ($pending -join '; ') + '). ' +
        'SQL Server setup fails its RebootRequiredCheck rule in this state, so the edition ' +
        'upgrade would fail several minutes from now with a setup error instead of this one. ' +
        'Restart the machine and run activate-sql again, or pass -Force to try anyway. ' +
        'NOTHING was changed and the product key was not used.') 'ERROR'
      $script:YcExit = 2; return
    }
  } else {
    Write-YcLog 'No pending reboot - setup.exe RebootRequiredCheck will pass.' 'OK'
  }

  # --- 2. BEFORE state ---------------------------------------------------------------
  Show-YcSqlState 'BEFORE'
  $inst = Get-YcSqlInstance $InstanceName
  if(-not $inst){
    Write-YcLog ('Database Engine instance "' + $InstanceName + '" is not installed on this ' +
      'host. Installed instances: ' + (((Get-YcSqlInstances) | ForEach-Object { $_.Name }) -join ', ') +
      '. Nothing was run.') 'ERROR'
    $script:YcExit = 1; return
  }

  $svcName = Get-YcSqlServiceName $InstanceName
  $target  = Get-YcSqlConnectTarget $InstanceName
  $beforeReg = $inst.Edition
  $beforeSp  = Get-YcServerProperties -Target $target
  if($beforeSp){
    Write-YcLog ('BEFORE via ' + $beforeSp.Source + ': Edition="' + $beforeSp.Edition +
      '" EditionID=' + $beforeSp.EditionID + ' ProductVersion=' + $beforeSp.ProductVersion +
      ' ProductLevel=' + $beforeSp.ProductLevel)
  }else{
    Write-YcLog ('BEFORE: could not query SERVERPROPERTY (instance may be stopped or the ' +
      'Evaluation period may have expired). Falling back to the registry edition "' +
      $beforeReg + '" for the before/after comparison.') 'WARN'
  }
  $beforeEdition = if($beforeSp){ $beforeSp.Edition } else { $beforeReg }

  $majorVersion = 0
  try{ $majorVersion = [int](([version]$inst.Version).Major) }catch{ $majorVersion = 0 }
  if($majorVersion -le 0){
    Write-YcLog ('Could not parse the instance version "' + $inst.Version + '".') 'ERROR'
    $script:YcExit = 1; return
  }

  # --- 2b. COMPATIBILITY GUARD: editionupgrade only ever goes UP --------------------
  # setup.exe /ACTION=editionupgrade implements Microsoft's supported EDITION UPGRADE paths.
  # There is no downgrade path in it at all. Ask for one and setup unpacks itself, runs for
  # minutes and returns a raw negative code whose text does not say "you asked to go down".
  # Rank the ladder and refuse first, before the key is ever put on a command line.
  #
  # Evaluation is deliberately NOT on the ladder: an Evaluation instance is Enterprise
  # Evaluation, and it may legitimately be converted to Web, Standard, Enterprise or
  # Developer. That is the normal case for this whole toolkit.
  $edRank = @{ 'express' = 0; 'web' = 1; 'standard' = 2; 'enterprise' = 3 }
  function Get-YcEditionRank{
    param([string]$Name)
    $n = ("$Name").ToLowerInvariant()
    foreach($k in 'enterprise','standard','web','express'){ if($n -match $k){ return $edRank[$k] } }
    return -1
  }

  if($TargetEdition -match '(?i)express'){
    Write-YcLog ('REFUSED: Express is not reachable with an edition upgrade. setup.exe ' +
      '/ACTION=editionupgrade has no path to Express from any edition - Express is a separate, ' +
      'free product with its own installer, not a PID applied to this instance. To get Express, ' +
      'install it as its own instance from the Express media. Nothing was changed and the ' +
      'product key was not used.') 'ERROR'
    $script:YcExit = 6; return
  }

  $isEvalNow = ($beforeEdition -match '(?i)eval')
  if($TargetEdition -and -not $isEvalNow){
    $fromRank = Get-YcEditionRank $beforeEdition
    $toRank   = Get-YcEditionRank $TargetEdition
    if($fromRank -ge 0 -and $toRank -ge 0 -and $toRank -lt $fromRank){
      Write-YcLog ('REFUSED: this instance is "' + $beforeEdition + '" and -TargetEdition asks for "' +
        $TargetEdition + '", which is LOWER on the edition ladder (Express, Web, Standard, ' +
        'Enterprise). An edition upgrade only ever goes up; SQL Server has no supported downgrade. ' +
        'To move down, install a new instance of the edition you want and move the databases to it. ' +
        'Nothing was changed and the product key was not used.') 'ERROR'
      $script:YcExit = 6; return
    }
  }

  # --- 3. idempotency / upgrade safety ----------------------------------------------
  $alreadyLicensed = ($beforeEdition -notmatch 'Eval')
  # "Enterprise Evaluation Edition" CONTAINS "Enterprise", so a plain substring test made
  # -TargetEdition Enterprise match an Evaluation instance and the script reported
  # "already Enterprise, nothing to do" and exited 0 WITHOUT EVER APPLYING THE KEY.
  # Measured on a Server 2016 lab VM on 2026-08-31 with a real SQL 2016 Enterprise MAK. An
  # Evaluation instance is by definition not the target - getting off Evaluation is the
  # entire job - so it can never satisfy -TargetEdition.
  $matchesTarget   = ($TargetEdition -and $alreadyLicensed -and
                      ($beforeEdition -match [regex]::Escape($TargetEdition)))
  if(-not $Force){
    if($matchesTarget){
      Write-YcLog ('Instance ' + $InstanceName + ' already reports edition "' + $beforeEdition +
        '", which matches -TargetEdition "' + $TargetEdition + '". Nothing to do.') 'OK'
      Invoke-YcMaybeGlpi
      $script:YcExit = 0; return
    }
    if($alreadyLicensed -and -not $TargetEdition){
      Write-YcLog ('Instance ' + $InstanceName + ' already reports a licensed (non-Evaluation) ' +
        'edition "' + $beforeEdition + '". Re-running editionupgrade against an already-upgraded ' +
        'instance fails with "the current edition is not a valid upgrade path", so setup was NOT ' +
        'run. Pass -TargetEdition <name> to assert a specific edition, or -Force to run anyway.') 'OK'
      Invoke-YcMaybeGlpi
      $script:YcExit = 0; return
    }
  }

  # --- 4. resolve setup.exe matched to this instance's major version ------------------
  $setup = Resolve-YcSetupExe -Explicit $SetupPath -MajorVersion $majorVersion
  if(-not $setup){ $script:YcExit = 1; return }

  # --- 5. run the DOCUMENTED edition-upgrade command line ----------------------------
  # https://learn.microsoft.com/en-us/sql/database-engine/install-windows/upgrade-downgrade-sql-server-edition-setup
  #   setup.exe /q /ACTION=editionupgrade /InstanceName=MSSQLSERVER /PID=<pid> /SkipRules=Engine_SqlEngineHealthCheck
  # /IACCEPTSQLSERVERLICENSETERMS is required alongside /q per the Upgrade parameters table in
  # https://learn.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt
  $setupArgs = @(
    '/q',
    '/ACTION=editionupgrade',
    ('/INSTANCENAME=' + $InstanceName),
    ('/PID=' + $key),
    '/IACCEPTSQLSERVERLICENSETERMS'
  )
  if(-not $NoSkipRules){ $setupArgs += '/SkipRules=Engine_SqlEngineHealthCheck' }

  $logged = @()
  foreach($a in $setupArgs){ if($a -like '/PID=*'){ $logged += ('/PID=' + $mask) } else { $logged += $a } }
  Write-YcLog ('Running: "' + $setup + '" ' + ($logged -join ' '))
  Write-YcLog ('Setup restarts the SQL Server service to activate the edition change; ' +
               'expect downtime. Waiting up to ' + $TimeoutMinutes + ' minute(s).') 'WARN'

  $rc = 1
  try{
    & $setup @setupArgs | Out-Host
    $rc = $LASTEXITCODE                     # captured IMMEDIATELY - nothing may clobber it
  }catch{
    Write-YcLog ('Launching setup.exe failed: ' + $_.Exception.Message) 'ERROR'
    $script:YcExit = 1; return
  }

  $bootLog = Get-YcSetupSummaryPath -SetupExe $setup -MajorVersion $majorVersion
  if($rc -eq 0){
    Write-YcLog ('setup.exe /ACTION=editionupgrade exit 0.') 'OK'
  }elseif($rc -eq 3010){
    Write-YcLog ('setup.exe /ACTION=editionupgrade exit 3010 - success, REBOOT REQUIRED.') 'WARN'
  }else{
    Write-YcLog ('setup.exe /ACTION=editionupgrade exit ' + $rc + ' - the edition was NOT ' +
      'upgraded. Microsoft publishes no table of SQL setup return codes, so the Exit message ' +
      'below is the authoritative reason. Full log: ' + $bootLog) 'ERROR'
    Write-YcSetupSummary -SummaryPath $bootLog
    $script:YcExit = $rc; return
  }

  # --- 6. PROOF: wait for the service, then assert the edition actually changed -------
  $deadline = (Get-Date).AddMinutes($TimeoutMinutes)
  Write-YcLog ('Waiting for service ' + $svcName + ' to report Running...')
  if(-not (Wait-YcSqlServiceRunning -ServiceName $svcName -Deadline $deadline)){
    $cur = Get-Service | Where-Object { $_.Name -eq $svcName } | Select-Object -First 1
    $st  = if($cur){ [string]$cur.Status } else { 'absent' }
    Write-YcLog ('VERIFICATION FAILED: service ' + $svcName + ' is "' + $st + '" after ' +
      $TimeoutMinutes + ' minute(s). Setup log: ' + $bootLog) 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Service ' + $svcName + ' is Running.') 'OK'

  $after = $null
  while((Get-Date) -lt $deadline){
    $after = Get-YcServerProperties -Target $target
    if($after -and ($after.Edition -ne $beforeEdition)){ break }
    if($after -and $TargetEdition -and ($after.Edition -match [regex]::Escape($TargetEdition))){ break }
    Start-Sleep -Seconds 10
  }

  if(-not $after){
    $regNow = (Get-YcSqlInstance $InstanceName)
    $regEd  = if($regNow){ $regNow.Edition } else { '(instance key gone)' }
    if($rc -eq 3010){
      Write-YcLog ('Setup returned 3010 and SERVERPROPERTY could not be read yet. Registry ' +
        'edition is now "' + $regEd + '". REBOOT the host and re-run activate-sql to verify.') 'WARN'
      $script:YcExit = 3010; return
    }
    Write-YcLog ('VERIFICATION FAILED: cannot read SERVERPROPERTY from instance ' + $InstanceName +
      ' after the upgrade. Registry edition reads "' + $regEd + '". Setup log: ' + $bootLog) 'ERROR'
    $script:YcExit = 1; return
  }

  Write-YcLog ('AFTER via ' + $after.Source + ': Edition="' + $after.Edition + '" EditionID=' +
    $after.EditionID + ' ProductVersion=' + $after.ProductVersion + ' ProductLevel=' +
    $after.ProductLevel + ' ProductUpdateLevel=' + $after.ProductUpdateLevel)
  Show-YcSqlState 'AFTER'

  if($after.Edition -match 'Eval'){
    Write-YcLog ('VERIFICATION FAILED: edition is still "' + $after.Edition + '" (Evaluation) ' +
      'after editionupgrade. The product key did not apply. Setup log: ' + $bootLog) 'ERROR'
    $script:YcExit = 1; return
  }
  if($after.Edition -eq $beforeEdition -and -not $matchesTarget){
    Write-YcLog ('VERIFICATION FAILED: edition is unchanged ("' + $after.Edition + '") after ' +
      'editionupgrade. Setup log: ' + $bootLog) 'ERROR'
    $script:YcExit = 1; return
  }
  if($TargetEdition -and ($after.Edition -notmatch [regex]::Escape($TargetEdition))){
    Write-YcLog ('VERIFICATION FAILED: expected -TargetEdition "' + $TargetEdition + '" but the ' +
      'instance reports "' + $after.Edition + '". Setup log: ' + $bootLog) 'ERROR'
    $script:YcExit = 1; return
  }

  Write-YcLog ('VERIFIED: instance ' + $InstanceName + ' edition changed "' + $beforeEdition +
    '" -> "' + $after.Edition + '" (EditionID ' + $after.EditionID + '), ProductVersion ' +
    $after.ProductVersion + ' ' + $after.ProductLevel + '. Queried live via ' + $after.Source + '.') 'OK'

  # --- 7. side effects only AFTER the thing they support is proven --------------------
  Invoke-YcMaybeGlpi

  if($rc -eq 3010){
    Write-YcLog 'Edition verified, but setup requested a reboot (3010). Schedule one.' 'WARN'
    $script:YcExit = 3010; return
  }
  $script:YcExit = 0
}

try{
  Invoke-Main | Out-Null
}catch{
  Write-YcLog ('UNHANDLED EXCEPTION: ' + $_.Exception.Message) 'ERROR'
  if($_.ScriptStackTrace){ Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}

Stop-YcLog $script:YcExit
exit $script:YcExit
