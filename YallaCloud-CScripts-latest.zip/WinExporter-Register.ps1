param(
  [int]$ListenPort = 9182,
  [string]$ListenAddr = '0.0.0.0',
  [string]$Collectors = 'cpu,cpu_info,logical_disk,memory,net,os,physical_disk,process,service,system,tcp,time',
  [string]$TextfileDir,
  [string]$MsiPath,
  [string]$DownloadUrl,
  [string]$Sha256,
  [string]$ConfigFilePath,
  [string]$ServiceName = 'windows_exporter',
  [string[]]$RemoteAddress = @('LocalSubnet'),
  [string[]]$FirewallProfile = @('Domain','Private'),
  [switch]$AllowAnyRemote,
  [switch]$SkipFirewall,
  [switch]$Help
)
# =====================================================================================
# WinExporter-Register.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
# Installs windows_exporter and PROVES /metrics answers before opening anything.
#
# WHAT CHANGED AND WHY
# --------------------
#  1. [P0-26c] THE DEFAULT COLLECTOR LIST CONTAINED 'cs', WHICH NO LONGER EXISTS.
#     The 'cs' collector was REMOVED from windows_exporter (issue #2241, reported against
#     v0.31.3: an enabled removed collector makes the exporter "silently fail" to start).
#     msiexec still returns 0, so the old script exited 0 and added an inbound firewall rule
#     for a port nothing was listening on. Its very first help example - a bare
#     'winexporter-register' - was therefore broken on every current release.
#     FIXED two ways:
#       a. the default is now cpu,cpu_info,logical_disk,memory,net,os,physical_disk,process,
#          service,system,tcp,time  - every name checked against the collector table in the
#          current README. The 'cs' metrics are covered by cpu_info (logical processors),
#          memory (physical memory) and os (hostname / uptime).
#       b. -Collectors is VALIDATED before msiexec runs: 'cs' and 'logon' are refused with
#          this explanation, and an unknown name is a loud WARN naming it.
#     BEHAVIOUR CHANGE TO REPORT: the -Collectors default value changed (the parameter name
#     did not). The old value cannot work on any current release.
#  2. IT NO LONGER LIES. The old ending printed $svc.Status and then logged
#     'done - scrape at http://<host>:9182/metrics' at OK unconditionally; a Stopped service
#     still produced OK. Proof is now: msiexec's exit code DECODED (0/1641/3010 = success,
#     1638 = same version already installed and handled as such, everything else fatal);
#     service Running, polled, then re-checked after a settle window; and an actual
#     HTTP GET of /metrics that must return 200, be Prometheus exposition text, and contain
#     windows_exporter_build_info.
#  3. [cross-cutting] THE LISTENER IS NO LONGER WORLD-OPEN. The old rule was
#     -Profile Any with NO -RemoteAddress, on a 0.0.0.0 listener - windows_exporter /metrics
#     discloses hostname, domain, services, users, disk layout, uptime and process names to
#     anyone who can reach the port, on every network the VM is attached to including Public.
#     Now: -RemoteAddress defaults to LocalSubnet, -FirewallProfile defaults to
#     Domain,Private, and RemoteAddress 'Any' is REFUSED unless -AllowAnyRemote is passed
#     explicitly. Pin the listener with -ListenAddr <management ip> for defence in depth.
#  4. THE RULE IS CREATED ONLY AFTER THE EXPORTER IS PROVEN. ADDLOCAL=FirewallException is
#     deliberately NOT used: the MSI would create the rule during installation, i.e. before
#     anything is known to work, which is the ordering this toolkit forbids.
#  5. MSI PROPERTY QUOTING FIXED. Only the MSI path was quoted, so
#     -TextfileDir 'C:\Program Files\tf' silently truncated the property at the space. Every
#     property value is quoted now, and TEXTFILE_DIRS / CONFIG_FILE are handled.
#  6. Version-aware installer selection ([version] parse, not the old lexical sort where
#     0.9.0 beat 0.31.0), optional -Sha256 pin, optional -DownloadUrl with TLS 1.2+.
#  7. Unhandled-exception guard; every exit goes through Exit-Yc.
#
# PARAMETERS ADDED (none renamed, none removed): -MsiPath, -DownloadUrl, -Sha256,
#     -ConfigFilePath, -ServiceName, -RemoteAddress, -FirewallProfile, -AllowAnyRemote,
#     -SkipFirewall.
#
# VERIFIED AGAINST THE CURRENT RELEASE (docs, not memory):
#   MSI properties ENABLED_COLLECTORS / LISTEN_ADDR / LISTEN_PORT / METRICS_PATH /
#   TEXTFILE_DIRS / REMOTE_ADDR / CONFIG_FILE / EXTRA_FLAGS / ADDLOCAL=FirewallException,
#   and the collector table (no 'cs' anywhere in it)
#     https://github.com/prometheus-community/windows_exporter/blob/master/README.md
#   removed collectors make the exporter fail to start
#     https://github.com/prometheus-community/windows_exporter/issues/2241
#   'cs' and 'logon' are documented as removed / no effect
#     https://grafana.com/docs/alloy/latest/reference/components/prometheus/prometheus.exporter.windows/
#
# Log: C:\Scripts\winexporter-register.log
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'winexporter-register'
$ErrorActionPreference = 'Stop'

# Collector table of the current release. Kept here so a wrong name fails LOUDLY at parse
# time instead of producing an exporter that silently refuses to start.
$script:YcValidCollectors = @(
  'ad','adcs','adfs','cache','container','cpu','cpu_info','dfsr','dhcp','diskdrive','dns',
  'exchange','file','filetime','fsrmquota','gpu','hyperv','iis','license','logical_disk','memory',
  'mscluster','msmq','mssql','net','netframework','os','pagefile','performancecounter',
  'physical_disk','printer','process','remote_fx','scheduled_task','service','smb','smbclient',
  'smtp','system','tcp','terminal_services','textfile','thermalzone','time','udp','update','vmware'
)
$script:YcRemovedCollectors = @('cs','logon')

$HelpText = @"
winexporter-register - SILENT install of windows_exporter (Prometheus Windows metrics exporter),
                       with the collector list validated against the CURRENT release, an actual
                       /metrics probe as proof, and a firewall rule that is SCOPED and is created
                       only after the exporter is proven.

USAGE:
  winexporter-register [-ListenPort 9182] [-ListenAddr 0.0.0.0] [-Collectors <list>]
                       [-TextfileDir <path>] [-RemoteAddress 10.0.0.5,10.0.0.6]
  winexporter-register -Help

PARAMETERS:
  -ListenPort       TCP port for /metrics. Default 9182.
  -ListenAddr       Bind address. Default 0.0.0.0 (all interfaces). Set this to the MANAGEMENT IP
                    of the VM to keep the exporter off the tenant-facing NIC entirely.
  -Collectors       Comma-separated enabled collectors. Default
                    cpu,cpu_info,logical_disk,memory,net,os,physical_disk,process,service,system,tcp,time
                    'cs' and 'logon' were REMOVED from windows_exporter and are refused: enabling a
                    removed collector makes the exporter fail to start while msiexec still returns 0.
  -TextfileDir      Optional directory for the textfile collector (custom .prom metrics).
  -ConfigFilePath   Optional YAML config passed to the MSI as CONFIG_FILE (the version-stable way to
                    configure collectors, TLS and basic auth via web.config.file).
  -MsiPath          Explicit staged MSI. Default: newest C:\Scripts\windows_exporter-*-amd64.msi by
                    PARSED version.
  -DownloadUrl      Download the MSI instead of using a staged one (TLS 1.2+, retried).
  -Sha256           Expected SHA256 of the MSI. Strongly recommended.
  -ServiceName      Windows service name created by the MSI. Default windows_exporter.
  -RemoteAddress    Sources allowed through the inbound rule. Default LocalSubnet. Pass your
                    Prometheus servers or the management CIDR, e.g. -RemoteAddress 10.20.0.0/24
                    'Any' is REFUSED unless -AllowAnyRemote is also passed.
  -FirewallProfile  Profiles the rule applies to. Default Domain,Private (not Public).
  -AllowAnyRemote   Explicitly allow a world-open rule. Logs a loud WARN. Do not ship this.
  -SkipFirewall     Do not create an inbound rule at all (e.g. when a local agent scrapes 127.0.0.1).
  -Help             Show this help and exit 0.

EXAMPLES:
  winexporter-register -RemoteAddress 10.20.0.11
  winexporter-register -ListenAddr 10.20.0.50 -RemoteAddress 10.20.0.0/24
  winexporter-register -Collectors 'cpu,cpu_info,memory,logical_disk,net,os,service' -RemoteAddress 10.20.0.11
  winexporter-register -TextfileDir 'C:\Scripts\textfile' -RemoteAddress 10.20.0.11
  winexporter-register -Help

PROOF PERFORMED (in this order - any failure is a non-zero exit):
  1. every requested collector name is checked against the current collector table
  2. msiexec exit code decoded: 0/1641/3010 success, 1638 already-installed (handled), else fatal
  3. service Running, polled, then re-checked after a settle window
  4. GET http://<listen>:<port>/metrics -> 200, Prometheus text, contains windows_exporter_build_info
  5. only then is the SCOPED inbound firewall rule created and read back

EXIT CODES:
  0  Verified: service Running and /metrics served windows_exporter_build_info.
  1  Failure at any step.
  2  Usage error (invalid collector name, invalid port, RemoteAddress Any without -AllowAnyRemote).
  5  Not elevated.
  6  No outbound internet when -DownloadUrl was used.

Log: C:\Scripts\winexporter-register.log
"@

if($Help){ Write-Host $HelpText -ForegroundColor Cyan; Exit-Yc 0 'help shown' 'OK' }

Assert-YcPrereqs -NeedAdmin

# A .cmd wrapper or a parent script passing '-RemoteAddress 10.0.0.1,10.0.0.2' through
# powershell.exe -File delivers ONE string, not two elements, so New-NetFirewallRule would
# receive a single meaningless address. Split it back apart here.
function Split-YcList{
  param([string[]]$Value)
  $out = @()
  foreach($v in $Value){
    foreach($p in ([string]$v -split ',')){
      if($p.Trim().Length -gt 0){ $out += $p.Trim() }
    }
  }
  return $out
}
$RemoteAddress   = Split-YcList $RemoteAddress
$FirewallProfile = Split-YcList $FirewallProfile
$script:YcExit = 1
$script:YcTemp = $null

# ------------------------------------------------------------------ helpers

function Invoke-YcNative{
  param([string]$File,[string[]]$Arguments)
  $ErrorActionPreference = 'Continue'
  $out = & $File @Arguments 2>&1
  $rc  = $LASTEXITCODE
  $txt = @()
  foreach($o in $out){ if($null -ne $o){ $txt += ([string]$o) } }
  return (New-Object psobject -Property @{ Output = $txt; ExitCode = $rc })
}

function Get-YcServiceObject([string]$Name){
  return (Get-Service | Where-Object { $_.Name -eq $Name } | Select-Object -First 1)
}

function Get-YcExporterMsi{
  if($MsiPath){
    if(-not (Test-Path -LiteralPath $MsiPath)){ Write-YcLog ('-MsiPath not found: ' + $MsiPath) 'ERROR'; return $null }
    return (Get-Item -LiteralPath $MsiPath)
  }
  if($DownloadUrl){
    Assert-YcPrereqs -NeedInternet
    $script:YcTemp = Join-Path $env:TEMP ('winexp_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
    $dst = Join-Path $script:YcTemp 'windows_exporter-amd64.msi'
    $got = Get-YcFile -Uri $DownloadUrl -OutFile $dst -Sha256 $Sha256 -MinBytes 1048576
    if(-not $got){ return $null }
    return (Get-Item -LiteralPath $dst)
  }
  $all = Get-ChildItem -Path 'C:\Scripts\windows_exporter-*-amd64.msi' -File -ErrorAction Ignore
  if(-not $all){ return $null }
  # Parse the version so 0.31.0 beats 0.9.0 (the old lexical sort got this backwards).
  return ($all | Sort-Object {
      $m = [regex]::Match($_.Name,'(\d+\.\d+\.\d+)')
      if($m.Success){ [version]$m.Groups[1].Value } else { [version]'0.0.0' }
    } -Descending | Select-Object -First 1)
}

function Get-YcProbeHost{
  if(-not $ListenAddr){ return '127.0.0.1' }
  $a = $ListenAddr.Trim()
  if($a -eq '' -or $a -eq '0.0.0.0' -or $a -eq '::' -or $a -eq '[::]'){ return '127.0.0.1' }
  return $a
}

# ------------------------------------------------------------------ main

function Invoke-Main{

  # --- 0. validate what we were asked to do ------------------------------------------
  if($ListenPort -lt 1 -or $ListenPort -gt 65535){
    Write-YcLog ('-ListenPort ' + $ListenPort + ' is out of range.') 'ERROR'
    $script:YcExit = 2; return
  }
  $want = @()
  foreach($c in ($Collectors -split ',')){
    $n = $c.Trim()
    if($n.Length -gt 0){ $want += $n }
  }
  if($want.Count -eq 0){
    Write-YcLog '-Collectors is empty. The exporter would serve almost nothing.' 'ERROR'
    $script:YcExit = 2; return
  }
  $dead = @()
  $unknown = @()
  foreach($n in $want){
    if($script:YcRemovedCollectors -contains $n.ToLowerInvariant()){ $dead += $n }
    elseif($script:YcValidCollectors -notcontains $n.ToLowerInvariant()){ $unknown += $n }
  }
  if($dead.Count -gt 0){
    Write-YcLog ('-Collectors contains ' + ($dead -join ', ') + ', which was REMOVED from ' +
      'windows_exporter. Enabling a removed collector makes the exporter fail to start, while ' +
      'msiexec still returns 0 - this estate shipped exactly that and opened a firewall rule for a ' +
      'port nothing listened on. Replacements: cs -> cpu_info (logical processors) + memory ' +
      '(physical memory) + os (hostname, uptime); logon -> the terminal_services / os collectors. ' +
      'Refusing to install.') 'ERROR'
    $script:YcExit = 2; return
  }
  if($unknown.Count -gt 0){
    Write-YcLog ('-Collectors contains name(s) not in the collector table this script knows about: ' +
      ($unknown -join ', ') + '. If your windows_exporter is newer than this script, that is fine; ' +
      'if it is a typo the exporter will refuse to start and the /metrics proof below will catch ' +
      'it.') 'WARN'
  }
  $collectorList = ($want -join ',')
  # Test-YcWorldOpen (_yc-lib.ps1) tests EVERY element for Any / * / 0.0.0.0/0 / ::/0 / Internet.
  # The old test was ($RemoteAddress.Count -eq 1 -and $RemoteAddress[0] -eq 'Any'), which let
  # -RemoteAddress 0.0.0.0/0 through unexamined, and let ANY two-element list skip the gate.
  if((Test-YcWorldOpen -Scope $RemoteAddress) -and -not $SkipFirewall){
    if(-not $AllowAnyRemote){
      Write-YcLog ('-RemoteAddress Any would expose /metrics to every network this VM is attached ' +
        'to. windows_exporter discloses hostname, domain, installed services, users, disk layout, ' +
        'uptime and process names, with no TLS and no authentication. Pass your Prometheus servers ' +
        'or the management CIDR, or -SkipFirewall, or -AllowAnyRemote if you really mean it.') 'ERROR'
      $script:YcExit = 2; return
    }
    Write-YcLog ('-AllowAnyRemote: the inbound rule will be world-open. This is a recon feed for ' +
      'anything that can route to this host.') 'WARN'
  }

  # --- 1. the installer ---------------------------------------------------------------
  $msi = Get-YcExporterMsi
  if(-not $msi){
    Write-YcLog ('No windows_exporter installer. Stage C:\Scripts\windows_exporter-<ver>-amd64.msi, ' +
      'or pass -MsiPath / -DownloadUrl.') 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcFile -Path $msi.FullName -MinBytes 524288 -Because 'windows_exporter MSI')){ $script:YcExit = 1; return }
  $h = (Get-FileHash -LiteralPath $msi.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
  if($Sha256 -and -not $DownloadUrl){
    if($h -ne $Sha256.Trim().ToUpperInvariant()){
      Write-YcLog ('SHA256 MISMATCH on ' + $msi.Name + ': expected ' + $Sha256.Trim().ToUpperInvariant() +
        ', got ' + $h + '. Refusing to install.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('SHA256 verified: ' + $h) 'OK'
  }elseif(-not $DownloadUrl){
    Write-YcLog ('No -Sha256 pin supplied. MSI hash is ' + $h + ' - pin it on the next run.') 'WARN'
  }

  # --- 2. install ----------------------------------------------------------------------
  # https://github.com/prometheus-community/windows_exporter/blob/master/README.md
  # ADDLOCAL=FirewallException is deliberately NOT passed: it would create the inbound rule
  # during installation, before anything is proven.
  $msiArgs = @('/i',('"' + $msi.FullName + '"'),'/qn','/norestart',
               ('LISTEN_ADDR="' + $ListenAddr + '"'),
               ('LISTEN_PORT=' + $ListenPort),
               ('ENABLED_COLLECTORS="' + $collectorList + '"'))
  if($TextfileDir){
    if(-not (Test-Path -LiteralPath $TextfileDir)){ New-Item -ItemType Directory -Path $TextfileDir -Force | Out-Null }
    $msiArgs += ('TEXTFILE_DIRS="' + $TextfileDir + '"')
  }
  if($ConfigFilePath){
    if(-not (Test-Path -LiteralPath $ConfigFilePath)){
      Write-YcLog ('-ConfigFilePath not found: ' + $ConfigFilePath) 'ERROR'
      $script:YcExit = 1; return
    }
    $msiArgs += ('CONFIG_FILE="' + $ConfigFilePath + '"')
  }
  Write-YcLog ('Installing ' + $msi.Name + ' listen=' + $ListenAddr + ':' + $ListenPort +
               ' collectors=' + $collectorList)
  $res = Invoke-YcInstaller -FilePath 'msiexec.exe' -ArgumentList $msiArgs `
           -SuccessCodes @(0) -RebootCodes @(3010,1641) -TimeoutSec 1800
  if(-not $res.Success){
    if($res.ExitCode -eq 1638){
      Write-YcLog ('msiexec returned 1638 (another version of windows_exporter is already installed). ' +
        'Nothing was changed by this run. Continuing to the /metrics proof: if the installed exporter ' +
        'is healthy this run is still a success; if it is not, this run FAILS instead of pretending. ' +
        'To change version, uninstall the existing product first.') 'WARN'
    }else{
      Write-YcLog ('windows_exporter MSI FAILED: exit ' + $res.ExitCode + ' - ' + $res.Meaning) 'ERROR'
      $script:YcExit = 1; return
    }
  }
  if($res.RebootRequired){
    Write-YcLog 'The MSI reported that a reboot is required to complete. Proving the service anyway.' 'WARN'
  }

  # --- 3. PROOF: the service runs and STAYS running -----------------------------------
  if(-not (Assert-YcService -Name $ServiceName -TimeoutSec 90 -StartIfStopped -Because 'windows_exporter')){
    Write-YcLog ('The MSI returned success but the service is not Running. The classic cause is an ' +
      'enabled collector that no longer exists (see -Collectors above); check the Application event ' +
      'log, source windows_exporter.') 'ERROR'
    $script:YcExit = 1; return
  }
  Start-Sleep -Seconds 10
  $svc2 = Get-YcServiceObject $ServiceName
  if((-not $svc2) -or ($svc2.Status -ne 'Running')){
    $st = 'absent'; if($svc2){ $st = [string]$svc2.Status }
    Write-YcLog ('VERIFICATION FAILED: ' + $ServiceName + ' reached Running but is now "' + $st +
      '" 10s later.') 'ERROR'
    $script:YcExit = 1; return
  }
  $sc1 = Invoke-YcNative -File 'sc.exe' -Arguments @('config',$ServiceName,'start=','delayed-auto')
  if($sc1.ExitCode -ne 0){
    Write-YcLog ('sc.exe config start= delayed-auto returned ' + $sc1.ExitCode + ': ' + ($sc1.Output -join ' ')) 'WARN'
  }

  # --- 4. PROOF: /metrics actually answers ---------------------------------------------
  $probe = 'http://' + (Get-YcProbeHost) + ':' + $ListenPort + '/metrics'
  if(-not (Assert-YcHttp -Uri $probe -ExpectStatus 200 -TimeoutSec 90 -MatchContent 'windows_exporter_build_info')){
    Write-YcLog ('VERIFICATION FAILED: ' + $probe + ' did not return 200 with ' +
      'windows_exporter_build_info. The exporter is installed but is not serving metrics, so NO ' +
      'firewall rule was created. Check the collector list and the Application event log.') 'ERROR'
    $script:YcExit = 1; return
  }

  # --- 5. side effects ONLY after the thing they support is proven --------------------
  if($SkipFirewall){
    Write-YcLog '-SkipFirewall set: no inbound rule created.'
  }else{
    $rn = 'YallaCloud windows_exporter in ' + $ListenPort
    $existingRule = Get-NetFirewallRule -DisplayName $rn -ErrorAction Ignore
    if($existingRule){
      Write-YcLog ('Inbound firewall rule already present: ' + $rn + ' (left as-is; delete it to change ' +
        'its scope).')
    }else{
      try{
        New-NetFirewallRule -DisplayName $rn -Direction Inbound -Action Allow -Protocol TCP `
          -LocalPort $ListenPort -RemoteAddress $RemoteAddress -Profile $FirewallProfile `
          -Description 'Prometheus scrape of windows_exporter. Managed by YallaCloud.' `
          -ErrorAction Stop | Out-Null
      }catch{
        Write-YcLog ('Firewall rule creation FAILED: ' + $_.Exception.Message + '. The exporter is ' +
          'verified and running but is not reachable from off-box.') 'ERROR'
        $script:YcExit = 1; return
      }
      if(-not (Get-NetFirewallRule -DisplayName $rn -ErrorAction Ignore)){
        Write-YcLog ('VERIFICATION FAILED: firewall rule "' + $rn + '" does not exist after ' +
          'New-NetFirewallRule returned.') 'ERROR'
        $script:YcExit = 1; return
      }
      Write-YcLog ('Inbound allow verified: TCP ' + $ListenPort + ' from ' + ($RemoteAddress -join ',') +
        ' on profile(s) ' + ($FirewallProfile -join ',')) 'OK'
    }
  }

  Write-YcLog ('DONE. ' + $ServiceName + ' Running, ' + $probe + ' returned 200 with ' +
    'windows_exporter_build_info, collectors=' + $collectorList + '.') 'OK'
  $script:YcExit = 0
}

try{
  Invoke-Main | Out-Null
}catch{
  Write-YcLog ('UNHANDLED EXCEPTION: ' + (Protect-YcSecret $_.Exception.Message)) 'ERROR'
  if($_.ScriptStackTrace){ Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}finally{
  if($script:YcTemp -and (Test-Path -LiteralPath $script:YcTemp)){
    try{ Remove-Item -LiteralPath $script:YcTemp -Recurse -Force }catch{}
  }
}

if($script:YcExit -eq 0){ Exit-Yc 0 'winexporter-register verified' 'OK' }
Exit-Yc $script:YcExit 'winexporter-register FAILED - nothing was reported as working that is not proven' 'ERROR'
