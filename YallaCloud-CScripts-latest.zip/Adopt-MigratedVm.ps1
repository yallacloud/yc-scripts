param(
  # What to do. -Report changes NOTHING and is the default, because the first thing you do to
  # a machine holding production data is look at it.
  [switch]$Report,
  [switch]$Run,
  [switch]$Status,
  [switch]$Resume,          # internal: the reboot-resume task calls this
  # Phases. -Only takes the names in $AllPhases; -Skip removes them.
  [string[]]$Only,
  [string[]]$Skip,
  [string]$ChadminPassword, # only when S4U is refused on this host; never persisted by us
  [int]$MinFreeGB = 5,      # the disk floor for SQL volumes
  [switch]$SkipChoco,       # TOOLS: do not install Chocolatey (install-dotnet/install-ssms then refuse)
  [switch]$SkipDotNet,      # TOOLS: do not touch .NET
  [switch]$SkipPwsh,        # TOOLS: do not install PowerShell 7 (5.1 stays the host either way)
  [switch]$SkipSsms,        # TOOLS: do not install SSMS
  [switch]$SkipDiagTools,   # TOOLS: do not install the staged diagnostic tools
  [switch]$SkipExporter,    # SQLMAINT: do not register the local SQL metrics exporter
  [string]$QemuGaMsi,       # TOOLS: path or URL to the QEMU guest agent MSI. It is NOT in the
                            # payload zip (mirror-seed member, ~11.8 MB), so a migrated VM has no
                            # staged copy and needs this unless one was put in C:\Scripts.
  [switch]$SkipGuestAgent,  # TOOLS: report the guest agent, never install or start it
  [switch]$GrowDisk,        # DISKSCAN: actually extend partitions. Default is detect and report.
  [switch]$SkipOla,         # SQLMAINT: do not install Ola Hallengren
  [switch]$AllowReboot,     # reboot at the END if something installed needs one. Default: report
                            # it and leave the box up. A PENDING reboot never stops the run.
  [switch]$Force,           # proceed past a GATE finding. Says what it is overriding.
  [string]$Url    = 'https://raw.githubusercontent.com/yallacloud/yc-scripts/main/YallaCloud-CScripts-latest.zip',
  [string]$ShaUrl = 'https://raw.githubusercontent.com/yallacloud/yc-scripts/main/YallaCloud-CScripts-latest.sha256',
  [string]$ScriptsDir = 'C:\Scripts',
  [string]$BackupDir,       # SQL backup root. Omitted: let backup-sql decide (Ola's dir, or its default)
  # RETENTION FLOOR. Owner requirement: keep at least 15 days. THE PAYLOAD's own defaults are
  # FULL 35 / DIFF 14 / LOG 14 - DIFF and LOG are below the floor, so this script overrides them
  # to 16/16 below. Retention has to outlive detection latency because
  # retention has to outlive detection latency: corruption found on day 15 is unrecoverable if
  # the last clean backup aged out on day 14.
  [int]$RetainFullDays = 35,
  [int]$RetainDiffDays = 16,
  [int]$RetainLogDays  = 16,
  [switch]$Help
)
# ================================================================================================
# Adopt-MigratedVm.ps1 - YALLACLOUD: bring a MIGRATED VM up to the same day-2 standard as a VM we
# built ourselves. Windows PowerShell 5.1 only. ASCII only. Server 2016-2025.
#
# WHY THIS EXISTS
#   A fresh VM gets the whole toolkit because WE built it: cloudbase-init runs the userdata on
#   first boot, the userdata pulls C:\Scripts, and Yc-VmBuild.ps1 walks a state machine to a
#   reported, monitored, backed-up machine.
#   A migrated VM gets NONE of that, because the chain has no first link - no cloudbase-init (or
#   one still pointed at OpenStack), nothing baked in before sealing, no C:\Scripts, no
#   Chocolatey. This script is that first link, and nothing more: after it runs once, the machine
#   is on exactly the same payload channel as every fresh VM, forever.
#
# THE GOVERNING DIFFERENCE - construct vs adopt
#   A fresh deploy CONSTRUCTS: it owns the machine, nothing is lost on failure, and install-sql is
#   correct because there is no SQL yet.
#   A migration ADOPTS: somebody else built it, it holds production data, there is no redeploy, and
#   install-sql would be DESTRUCTIVE. Same outcome, opposite assumptions.
#
#   Every action here obeys four rules:
#     1. SURVEY BEFORE TOUCH      - no change without a recorded prior state.
#     2. ADDITIVE, NEVER DESTRUCTIVE - add a rule, never flush the set. Add a task only if absent.
#     3. REVERSIBLE, UNDO RECORDED FIRST - written before the change, not after.
#     4. PROVE IT CHANGED NOTHING ELSE - the post-survey diffs against the pre-survey.
#   Anything that cannot satisfy all four is FLAGGED FOR A HUMAN, not automated.
#
# THE BOOTSTRAP PROBLEM, AND WHY THIS FILE IS SELF-CONTAINED
#   Update-YcScripts.ps1 cannot bootstrap itself - it lives inside the payload it fetches. A fresh
#   VM has it baked in before sealing; a migrated VM has nothing. So this script carries its own
#   minimal logger and its own verified download, and only dot-sources C:\Scripts\_yc-lib.ps1
#   AFTER the payload is on disk. Calling the house library before SYNC would fail on exactly the
#   machines this script exists for.
#
# WHAT IT DELIBERATELY DOES NOT DO
#   * install-sql           - destructive on a migrated SQL box. Structurally unreachable here.
#   * activate-windows      - migration changes the MAC, so activation often drops. Re-licensing a
#                             customer VM onto our volume agreement is a COMMERCIAL decision, and
#                             an OEM or retail box must never be silently converted. REPORT ONLY.
#   * antivirus exclusions  - defender-exclude and bitdefender-exclude are DELIBERATELY manual
#                             (owner decision). Apply them by hand on a SQL box.
#   NOTE: Ola Hallengren USED to be on this list. SQLMAINT now installs it (-SkipOla opts out),
#   because the integrity and restore-verify schedule this programme exists for is built on it.
#   * remove anything it cannot positively identify - flagged, skipped.
#
# EXIT CODES
#   0  every requested phase completed
#   1  a reboot is required; the resume task is registered. Reboot, and it continues by itself.
#   2  REFUSED at the gate (use -Force only when you know what you are overriding)
#   3  PARTIAL - completed, but one or more phases were flagged for a human
#   4  payload sha256 mismatch (nothing was installed; Update-YcScripts rolls back)
#   5  not elevated
#   6  no HTTPS egress to the payload host, so the toolkit cannot be fetched
#
# LOG   C:\Scripts\adopt-migrated-vm.log        STATE  C:\Scripts\adopt-migrated-vm.state.json
# SURVEY C:\Scripts\survey\<host>-<stamp>.json  MARKER C:\ProgramData\YallaCloud\adopted.json
# ================================================================================================

$ErrorActionPreference = 'Continue'
$script:Tag      = 'adopt-migrated-vm'
$script:LogPath  = Join-Path $ScriptsDir 'adopt-migrated-vm.log'
$script:StatePath= Join-Path $ScriptsDir 'adopt-migrated-vm.state.json'
$script:MarkerDir= 'C:\ProgramData\YallaCloud'
$script:Marker   = Join-Path $script:MarkerDir 'adopted.json'
$script:ResumeTask = 'YC-AdoptResume'
$script:Flags    = New-Object System.Collections.Generic.List[string]
$script:Done     = New-Object System.Collections.Generic.List[string]
$script:LibOK    = $false
$script:UseS4U   = $false
$script:ChadminCreated = $false
$script:ChadminLogin   = ''
# Every scheduled task this payload can register, in ONE place. VERIFY used to test the added
# tasks against a regex written once and never updated, so on its first real run it flagged
# YC-DiskScan - a task this very script had created two phases earlier - as something a stranger
# had put there. A list that has to be kept in step with the code, kept beside the code.
# EVERY task this payload can register, in one place. VERIFY compares the tasks that appeared
# during the run against this list, so a name missing here is reported as somebody else's task -
# which is how YC-DiskScan came to be flagged by the same run that created it. The three
# YC-Adopt-SqlBackup* names were missing for the same reason and would have done the same thing
# the first time the SQLBACKUP write path actually ran; it has only ever refused so far.
$script:OurTaskNames = @('YC-AdoptResume','YC-AutoUpdate','YC-Inventory','YC-DiskScan',
                         'YC-IntegrityBaseline','YC-SqlIntegrity','YC-SqlIntegrityFast',
                         'YC-SqlRestoreVerify','YC-SqlIndexOpt','YC-S4U-Probe','YC-NetFix',
                         'YC-Adopt-SqlBackupFull','YC-Adopt-SqlBackupDiff','YC-Adopt-SqlBackupLog')
$script:SqlQueryFailed = $false
$script:RebootWasPending = $false
$script:SqlDamaged      = $false
$script:BackupOwned     = $false
$script:BaselineTaskOk  = $false
$script:BaselineTaskAt  = $null
# The evidence bundle. Collected before anything is changed, and emitted as adopt-report.json so
# the dates can be quoted without anybody having to re-read a log.
$script:Evidence = [ordered]@{ sql=@(); lastKnownGood=@(); events=$null; volumes=@(); databases=@()
                               platform=$null; guestAgent=$null; virtio=$null
                               vss=$null; chkdsk=$null; sqlIntegrity=$null; baselineSha256='' }
# Initialised here, not where it is computed: the verdict block reads it, and the verdict block
# also runs on the stop-mid-run path, which never reaches the place it is computed.
$script:RebootNeeded    = @()
$script:MissingPhases   = @()

$AllPhases = @('SURVEY','PREREQ','BOOTSTRAP','SYNC','PATH','TOOLS','NIC','SQLPREP','BASELINE','SQL','SQLHARDEN','SQLBACKUP','SQLMAINT','DISKSCAN','TASKS','NOTIFY','VERIFY')

# ------------------------------------------------------------------------------------------------
# Minimal logger. Deliberately NOT the house library: this runs before C:\Scripts exists. Once SYNC
# has landed the payload, Main dot-sources it and swaps in the real Write-YcLog so the log line format, the
# secret redaction and the Application event log entries match every other command on the fleet.
# ------------------------------------------------------------------------------------------------
function L {
  param([string]$Message,[string]$Level='INFO')
  if ($script:LibOK -and (Get-Command Write-YcLog -ErrorAction SilentlyContinue)) {
    # The house library accepts INFO/OK/WARN/ERROR only. FLAG is this script's own severity for
    # a finding a human must read, so map it to WARN. Passed through as 'FLAG' it was rejected and
    # treated as INFO, which made every flag invisible to any log filter looking for problems.
    Write-YcLog $Message $(if ($Level -eq 'FLAG') { 'WARN' } else { $Level })
    return
  }
  $line = ('{0}  {1}  [YALLACLOUD][{2}] [{3}] {4}' -f `
           (Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK'), $env:COMPUTERNAME, $script:Tag, $Level, $Message)
  switch ($Level) {
    'ERROR' { Write-Host $line -ForegroundColor Red }
    'WARN'  { Write-Host $line -ForegroundColor Yellow }
    'OK'    { Write-Host $line -ForegroundColor Green }
    'FLAG'  { Write-Host $line -ForegroundColor Magenta }
    default { Write-Host $line }
  }
  try {
    if (-not (Test-Path -LiteralPath $ScriptsDir)) { New-Item -ItemType Directory -Path $ScriptsDir -Force | Out-Null }
    Add-Content -LiteralPath $script:LogPath -Value $line -Encoding Ascii -ErrorAction SilentlyContinue
  } catch {}
}

# A FLAG is the whole point of the adopt posture: something a human must decide, recorded in the
# log, the state file and the final summary, without stopping the phases that are safe to run.
function Flag { param([string]$Phase,[string]$What)
  $script:Flags.Add(($Phase + ': ' + $What)) | Out-Null
  L ('FLAG [' + $Phase + '] ' + $What) 'FLAG'
}

# The library CANNOT be dot-sourced from inside a function: the definitions land in that
# function's scope and are gone the moment it returns. The first version of this did exactly
# that - the run logged "house library loaded" and then quietly used the built-in logger for
# every line after it. So this only REPORTS whether the file is there; the dot-source itself
# happens at script scope, in Main, where the definitions survive.
function Test-YcLibraryPresent {
  return (Test-Path -LiteralPath (Join-Path $ScriptsDir '_yc-lib.ps1'))
}

function Test-Elevated {
  try { return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch { return $false }
}

# $env:COMPUTERNAME comes back EMPTY in a detached SYSTEM child - measured on yc-survey, where it
# produced survey files named "-20260915.json". Three sources, first one that answers.
function Get-HostNameSafe {
  foreach ($try in @({ [Environment]::MachineName },
                     { (Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).Name },
                     { $env:COMPUTERNAME })) {
    try { $v = & $try; if ($v) { return [string]$v } } catch {}
  }
  return 'UNKNOWN-HOST'
}

function Save-State {
  param([string]$Phase,[string]$Result)
  $s = @{
    schema    = 'ycadopt.state/1'
    host      = (Get-HostNameSafe)
    updated   = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK')
    lastPhase = $Phase
    result    = $Result
    done      = @($script:Done)
    flags     = @($script:Flags)
  }
  try { $s | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $script:StatePath -Encoding Ascii } catch {}
}

# Run a payload command and report honestly. A command that is not there is NOT a success.
function Invoke-YcCommand {
  param([string]$Script,[string[]]$Arguments=@(),[string]$Phase,[int[]]$OkCodes=@(0))
  $p = Join-Path $ScriptsDir $Script
  if (-not (Test-Path -LiteralPath $p)) {
    Flag $Phase ($Script + ' is not in ' + $ScriptsDir + ' - the payload is incomplete, so this step did not run.')
    return $null
  }
  L ('run: ' + $Script + ' ' + ($Arguments -join ' '))
  $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$p) + $Arguments
  try {
    $proc = Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Wait -PassThru -NoNewWindow
    $code = $proc.ExitCode
  } catch { Flag $Phase ($Script + ' could not be started: ' + $_.Exception.Message); return $null }
  if ($OkCodes -contains $code) { L ($Script + ' exit=' + $code) 'OK' }
  else { Flag $Phase ($Script + ' exit=' + $code + ' - see C:\Scripts\' + [IO.Path]::GetFileNameWithoutExtension($Script).ToLower() + '.log') }
  return $code
}

# ================================================================================================
# PHASE 1 - SURVEY.  Read-only. Changes nothing. Nothing else may run until this has.
# It is also the ROLLBACK BASELINE for rule 4: VERIFY diffs against it.
# ================================================================================================
function Invoke-Survey {
  param([string]$Label='pre')
  $h = Get-HostNameSafe
  $s = [ordered]@{ schema='ycadopt.survey/1'; label=$Label; host=$h
                   collected=(Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK') }

  # Each collector is isolated: one that throws must not cost us the other seven. yc-survey lost a
  # whole run to Win32_PnPSignedDriver timing out, which is why none of these share a try block.
  $collect = [ordered]@{
    identity = {
      $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
      $cs = Get-CimInstance Win32_ComputerSystem  -ErrorAction Stop
      [ordered]@{ caption=$os.Caption; build=$os.BuildNumber; installed=$os.InstallDate
                  firmware=$(if ((Get-CimInstance Win32_ComputerSystem).BootupState -and (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State')) {'UEFI'} else {$(try{ if((bcdedit /enum '{current}' 2>$null) -match 'winload.efi'){'UEFI'}else{'BIOS'} }catch{'unknown'})})
                  domain=$cs.Domain; partOfDomain=$cs.PartOfDomain; manufacturer=$cs.Manufacturer
                  model=$cs.Model; memoryGB=[math]::Round($cs.TotalPhysicalMemory/1GB,1) }
    }
    bootRisk = {
      # The make-or-break item for a VMware -> KVM guest. No virtio = the VM does not boot.
      # MEASURED: Get-CimInstance Win32_SystemDriver took 14.5 SECONDS on a real host - it
      # enumerates and joins every driver on the box. The service registry holds the same
      # answer and returns in milliseconds, so the named drivers are looked up directly.
      $virtio = @()
      foreach ($drv in @('viostor','vioscsi','netkvm','balloon','vioser','viorng','vioinput','viofs','pvpanic')) {
        if (Test-Path -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\' + $drv)) { $virtio += $drv }
      }
      [ordered]@{ virtioDrivers=$virtio; virtioPresent=($virtio.Count -gt 0)
                  vmwareTools=[bool](Get-Service -Name 'VMTools' -ErrorAction SilentlyContinue)
                  # Kept as a bool for anything already reading it, but the real answer - status,
                  # start type, version - is captured at SURVEY time into $script:Evidence below,
                  # because Get-Service returns the service whether it is Running or Stopped.
                  qemuGuestAgent=[bool](Get-Service -Name 'QEMU-GA','qemu-ga' -ErrorAction SilentlyContinue)
                  pendingReboot=@(Get-PendingRebootReasonsLocal) }
    }
    network = {
      $cfgs = @(Get-CimInstance Win32_NetworkAdapterConfiguration -ErrorAction SilentlyContinue |
                Where-Object { $_.IPEnabled })
      # Ghost NICs: the classic migration failure. CloudStack hands the clone a new MAC, the old
      # adapter persists as a hidden device still holding the old static IP, and the new IP fails
      # with "already assigned to another adapter".
      $ghosts = 0
      try {
        $all = @(Get-CimInstance Win32_NetworkAdapter -ErrorAction Stop)
        $ghosts = @($all | Where-Object { $_.PNPDeviceID -and -not $_.NetEnabled -and $_.PhysicalAdapter }).Count
      } catch {}
      [ordered]@{ nics=@($cfgs | ForEach-Object {
                    [ordered]@{ desc=$_.Description; mac=$_.MACAddress; ip=@($_.IPAddress)
                                gateway=@($_.DefaultIPGateway); dns=@($_.DNSServerSearchOrder)
                                dhcp=$_.DHCPEnabled; dhcpServer=$_.DHCPServer } })
                  hiddenAdapterCount=$ghosts }
    }
    inherited = {
      # What someone else put here. We must not flatten any of it.
      $tasks = @()
      try { $tasks = @(Get-ScheduledTask -ErrorAction Stop |
              Where-Object { $_.TaskPath -notmatch '^\\Microsoft\\' } |
              ForEach-Object { $_.TaskName }) } catch {}
      $cbi = Get-Service -Name 'cloudbase-init' -ErrorAction SilentlyContinue
      $cbiCloud = ''
      foreach ($c in @('C:\Program Files\Cloudbase Solutions\Cloudbase-Init\conf\cloudbase-init.conf')) {
        if (Test-Path -LiteralPath $c) {
          $txt = Get-Content -LiteralPath $c -Raw -ErrorAction SilentlyContinue
          if ($txt -match '(?im)^\s*metadata_services\s*=\s*(.+)$') { $cbiCloud = $Matches[1].Trim() }
        }
      }
      [ordered]@{ nonMicrosoftTasks=$tasks
                  cloudbaseInit=$(if ($cbi) { $cbi.Status.ToString() } else { 'absent' })
                  cloudbaseInitMetadataServices=$cbiCloud
                  backupAgents=@(Get-BackupAgentServicesLocal)
                  antivirus=@(Get-AntivirusLocal) }
    }
    sql = { @(Get-SqlInstancesLocal) }
    capacity = {
      @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction SilentlyContinue |
        ForEach-Object { [ordered]@{ drive=$_.DeviceID; sizeGB=[math]::Round($_.Size/1GB,1)
                                     freeGB=[math]::Round($_.FreeSpace/1GB,1) } })
    }
    us = {
      $cnt = 0
      if (Test-Path -LiteralPath $ScriptsDir) { $cnt = @(Get-ChildItem -LiteralPath $ScriptsDir -File -ErrorAction SilentlyContinue).Count }
      $ver = ''
      $vf = Join-Path $ScriptsDir 'yc-payload-version.txt'
      if (Test-Path -LiteralPath $vf) { $ver = ((Get-Content -LiteralPath $vf -TotalCount 1) -replace '^[^=]*=\s*','').Trim() }
      $ycTasks = @()
      try { $ycTasks = @(Get-ScheduledTask -ErrorAction Stop | Where-Object { $_.TaskName -match '^(YC|GI)' } | ForEach-Object { $_.TaskName }) } catch {}
      [ordered]@{ scriptsDir=$ScriptsDir; fileCount=$cnt; payloadVersion=$ver; ycTasks=$ycTasks
                  onPath=(Test-ScriptsOnPathLocal) }
    }
  }

  foreach ($k in $collect.Keys) {
    $t0 = Get-Date
    try { $s[$k] = & $collect[$k] }
    catch { $s[$k] = @{ error = $_.Exception.Message }; L ('survey collector ' + $k + ' failed: ' + $_.Exception.Message) 'WARN' }
    $ms = [int]((Get-Date) - $t0).TotalMilliseconds
    L ('survey ' + $k + ' ' + $ms + 'ms')
  }

  # The guest platform is captured HERE, on the pre pass, because TOOLS may install or start the
  # guest agent later and the evidence file has to say what ARRIVED. Rule 1: survey before touch.
  if ($Label -eq 'pre') {
    try {
      $st = Get-PlatformToolingState
      $script:Evidence['platform']   = $st
      $script:Evidence['guestAgent'] = $st.agent
      $script:Evidence['virtio']     = $st.virtio
      $s['guestPlatform'] = $st
    } catch { L ('could not read the guest platform: ' + $_.Exception.Message) 'WARN' }
  }

  $dir = Join-Path $ScriptsDir 'survey'
  if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  $file = Join-Path $dir ($h + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $Label + '.json')
  try { $s | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $file -Encoding Ascii
        L ('survey written: ' + $file) 'OK' }
  catch { L ('could not write the survey: ' + $_.Exception.Message) 'ERROR' }
  return @{ data = $s; path = $file }
}

function Get-PendingRebootReasonsLocal {
  # The house library has Get-YcPendingRebootReasons, but SURVEY runs BEFORE the payload exists.
  # Same checks, so the two agree; once the library is loaded the library's copy is used.
  if ($script:LibOK -and (Get-Command Get-YcPendingRebootReasons -ErrorAction SilentlyContinue)) {
    return @(Get-YcPendingRebootReasons)
  }
  $r = New-Object System.Collections.Generic.List[string]
  if (Test-Path -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $r.Add('Component Based Servicing') | Out-Null }
  if (Test-Path -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $r.Add('Windows Update') | Out-Null }
  $pfro = $null
  try { $pfro = (Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction Stop).PendingFileRenameOperations } catch {}
  if ($pfro) { $r.Add('PendingFileRenameOperations') | Out-Null }
  try { if ((Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName' -Name ComputerName -ErrorAction Stop).ComputerName -ne
             (Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName' -Name ComputerName -ErrorAction Stop).ComputerName) {
          $r.Add('pending computer rename') | Out-Null } } catch {}
  return @($r)
}

function Test-ScriptsOnPathLocal {
  $p = [Environment]::GetEnvironmentVariable('Path','Machine')
  return ([string]$p -split ';' | Where-Object { $_.TrimEnd('\') -ieq $ScriptsDir.TrimEnd('\') }).Count -gt 0
}

function Get-BackupAgentServicesLocal {
  # Named, not guessed. A service we cannot identify is reported as-is, never acted on.
  $known = @{
    'AcronisAgent'='Acronis'; 'acrocmd'='Acronis'; 'VeeamEndpointBackupSvc'='Veeam Agent'
    'VeeamBackupSvc'='Veeam B&R'; 'VSSPROV'='Veeam'; 'BackupExecAgentAccelerator'='Veritas Backup Exec'
    'BackupExecRPCService'='Veritas Backup Exec'; 'NetBackup Client Service'='Veritas NetBackup'
    'CommvaultCommServe'='Commvault'; 'GxCVD(Instance001)'='Commvault'; 'cvd'='Commvault'
    'sdrsvc'='Windows Server Backup'; 'AcrSch2Svc'='Acronis Scheduler'
    'MSSQLSERVER_BACKUP'='unknown-sql-backup'; 'RvSrv'='Redstor'; 'bacula-fd'='Bacula'
    'SQLBackupAgent'='Redgate SQL Backup'; 'IDERAService'='Idera SQL Safe'
  }
  $out = @()
  foreach ($n in $known.Keys) {
    $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
    if ($svc) { $out += [ordered]@{ service=$svc.Name; product=$known[$n]; status=$svc.Status.ToString() } }
  }
  return $out
}

# root\SecurityCenter2 is a CLIENT-only namespace. On a Server SKU it does not exist, so the old
# version of this returned an empty list - and an empty list in an inventory reads as "this host
# has no antivirus", which is a false negative, not a blank. Confirmed on TS_BM_FD_DB01
# (Server 2022): "Invalid namespace", survey wrote "antivirus": []. The three-probe shape below is
# lifted from Report-Inventory.ps1's Get-AV, which already had this right.
function Get-AntivirusLocal {
  $out = @()
  # Ask ONLY on a workstation SKU. The catch below was already correct, but a thrown terminating
  # error still lands in the PowerShell transcript, so every single run on every server printed
  #   PS>TerminatingError(Get-CimInstance): ... Invalid namespace
  # into the log an operator reads. ProductType 1 is workstation; 2 and 3 are domain controller
  # and server. Win32_OperatingSystem.ProductType exists on every Windows from 2012R2 to 2025.
  $isWorkstation = $false
  try { $isWorkstation = ([int](Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).ProductType -eq 1) } catch {}
  if ($isWorkstation) {
    try {
      Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop |
        ForEach-Object { $out += [string]$_.displayName }
    } catch { }
  }
  if (Get-Command Get-MpComputerStatus -ErrorAction Ignore) {
    try {
      $d = Get-MpComputerStatus -ErrorAction Stop
      if ($d) { $out += ('Windows Defender (RTP=' + [string]$d.RealTimeProtectionEnabled + ';AV=' + [string]$d.AntivirusEnabled + ')') }
    } catch { }
  }
  try {
    # Get-Service, not Get-CimInstance Win32_Service: the CIM enumeration added 1.5-2.4s to every
    # survey on TS_BM_FD_DB01 (inherited went from ~1.4s to ~3.9s), and the survey runs once per
    # invocation. Get-Service returns the same DisplayName and state from the service controller.
    $pat = 'bitdefender|kaspersky|sophos|mcafee|trend micro|eset|symantec|crowdstrike|sentinelone|carbon black|cylance|webroot'
    foreach ($v in @(Get-Service -ErrorAction Stop | Where-Object { $_.DisplayName -match $pat })) {
      $out += ([string]$v.DisplayName + ' (service:' + [string]$v.Status + ')')
    }
  } catch { }
  return @($out | Select-Object -Unique)
}

# ================================================================================================
# SQL discovery.  Version, edition, licensed state, and the LAST FIVE characters of the key -
# which is all Windows itself publishes (PartialProductKey). A full product key is never read,
# never logged and never printed, here or anywhere else in this payload.
# ================================================================================================
function Get-SqlInstancesLocal {
  $out = @()
  $root = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL'
  if (-not (Test-Path -LiteralPath $root)) { return $out }
  $names = $null
  try { $names = Get-ItemProperty -LiteralPath $root -ErrorAction Stop } catch { return $out }
  foreach ($p in $names.PSObject.Properties) {
    if ($p.Name -match '^PS') { continue }
    $inst = $p.Name
    $key  = $p.Value          # e.g. MSSQL16.MSSQLSERVER
    $rec  = [ordered]@{ instance=$inst; regKey=$key; service=$(if ($inst -eq 'MSSQLSERVER') { 'MSSQLSERVER' } else { 'MSSQL$' + $inst }) }
    $setup = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\' + $key + '\Setup'
    foreach ($f in @('Edition','Version','PatchLevel','SQLPath')) {
      $v = $null
      try { $v = (Get-ItemProperty -LiteralPath $setup -Name $f -ErrorAction Stop).$f } catch {}
      $rec[$f.ToLower()] = [string]$v
    }
    $svc = Get-Service -Name $rec.service -ErrorAction SilentlyContinue
    $rec['status'] = $(if ($svc) { $svc.Status.ToString() } else { 'absent' })
    # Evaluation is NOT an edition on the upgrade ladder - it is a time bomb, so it is called out
    # separately rather than folded into "edition".
    $rec['isEvaluation'] = ([string]$rec.edition -match '(?i)evaluation')
    $rec['isExpress']    = ([string]$rec.edition -match '(?i)express')
    # Ask the engine itself when it is running - the registry records what was INSTALLED, which is
    # not the same as what the engine reports after an edition upgrade.
    if ($rec.status -eq 'Running') {
      $t = $(if ($inst -eq 'MSSQLSERVER') { '.' } else { '.\' + $inst })
      $q = "SET NOCOUNT ON; SELECT CONVERT(varchar(128),SERVERPROPERTY('Edition')) + '|' + " +
           "CONVERT(varchar(128),SERVERPROPERTY('ProductVersion')) + '|' + " +
           "CONVERT(varchar(128),SERVERPROPERTY('ProductLevel')) + '|' + " +
           "ISNULL(CONVERT(varchar(128),SERVERPROPERTY('ProductUpdateLevel')),'') + '|' + " +
           "CONVERT(varchar(32),SERVERPROPERTY('IsIntegratedSecurityOnly'));"
      $r = Invoke-SqlCmdLocal -Target $t -Query $q
      if ($r) {
        $f = $r -split '\|'
        if ($f.Count -ge 3) {
          $rec['liveEdition']=$f[0].Trim(); $rec['liveVersion']=$f[1].Trim(); $rec['liveLevel']=$f[2].Trim()
          if ($f.Count -ge 4) { $rec['liveUpdateLevel']=$f[3].Trim() }
          $rec['isEvaluation'] = ($f[0] -match '(?i)evaluation')
        }
      }
      $rec['databases'] = @(Get-SqlDatabasesLocal -Target $t)
      $rec['foreignBackupHistoryDays'] = (Get-ForeignBackupHistoryDaysLocal -Target $t)
    } else { $rec['databases'] = @(); $rec['foreignBackupHistoryDays'] = -1 }
    # Last five characters of the key, from Windows' own published value. Never more than that.
    $rec['partialProductKey'] = (Get-SqlPartialKeyLocal -RegKey $key)
    $out += $rec
  }
  return $out
}

function Get-SqlPartialKeyLocal {
  param([string]$RegKey)
  # SQL does not publish a PartialProductKey the way Windows does. The DigitalProductID under the
  # instance's Setup key is the only local source, and decoding it would mean reconstructing a full
  # product key - which this payload must never do. So: report whether one is present, nothing more,
  # and let licence-report (which reads Windows' own published partial) carry the five characters
  # for Windows. Saying "present" honestly beats printing five characters we had to derive.
  foreach ($p in @(('HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\' + $RegKey + '\Setup'))) {
    try {
      $v = (Get-ItemProperty -LiteralPath $p -Name DigitalProductID -ErrorAction Stop).DigitalProductID
      if ($v) { return 'present (not decoded - this payload never reconstructs a product key)' }
    } catch {}
  }
  return '(none recorded)'
}

function Get-SqlCmdPathLocal {
  if ($script:SqlCmdPath) { return $script:SqlCmdPath }
  $c = Get-Command sqlcmd.exe -ErrorAction SilentlyContinue
  if ($c) { $script:SqlCmdPath = $c.Source; return $script:SqlCmdPath }
  foreach ($g in @('C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\*\Tools\Binn\sqlcmd.exe',
                   'C:\Program Files\Microsoft SQL Server\*\Tools\Binn\sqlcmd.exe')) {
    $f = @(Get-ChildItem -Path $g -ErrorAction SilentlyContinue | Sort-Object FullName -Descending)
    if ($f.Count) { $script:SqlCmdPath = $f[0].FullName; return $script:SqlCmdPath }
  }
  return $null
}

function Invoke-SqlCmdLocal {
  param([string]$Target,[string]$Query,[int]$TimeoutSec = 30)
  $exe = Get-SqlCmdPathLocal
  if (-not $exe) { return $null }
  try {
    # -l login timeout, -t query timeout. On a host whose STORAGE is failing, a metadata query
    # that normally returns in milliseconds can block for as long as the IO layer retries, and a
    # call with no ceiling simply stops there. Measured on a real box with a full suspect_pages.
    $o = & $exe -S $Target -E -b -h -1 -W -l 15 -t $TimeoutSec -Q $Query 2>&1
    if ($LASTEXITCODE -ne 0) {
      # Do NOT return a bare $null and let the caller read it as "no rows". A FAILED query and an
      # EMPTY result are different facts, and conflating them is how a script reports a clean
      # machine having read nothing at all - which is exactly what the collation bug caused.
      $msg = (($o | Where-Object { $_ -and ($_ -notmatch '^\s*$') }) -join ' ')
      if ($msg.Length -gt 300) { $msg = $msg.Substring(0,300) }
      L ('sqlcmd FAILED on ' + $Target + ' (exit ' + [string]$LASTEXITCODE + '): ' + $msg) 'WARN'
      $script:SqlQueryFailed = $true
      return $null
    }
    return (($o | Where-Object { $_ -and ($_ -notmatch '^\s*$') }) -join "`n").Trim()
  } catch {
    L ('sqlcmd could not run against ' + $Target + ': ' + $_.Exception.Message) 'WARN'
    $script:SqlQueryFailed = $true
    return $null
  }
}

function Get-SqlDatabasesLocal {
  param([string]$Target)
  $q = "SET NOCOUNT ON; SELECT CONVERT(varchar(128),name) COLLATE DATABASE_DEFAULT + '|' + CONVERT(varchar(64),recovery_model_desc) COLLATE DATABASE_DEFAULT + '|' + CONVERT(varchar(64),state_desc) COLLATE DATABASE_DEFAULT + '|' + " +
       "ISNULL(CONVERT(varchar(20), CAST((SELECT SUM(size)*8.0/1024 FROM sys.master_files WHERE database_id = d.database_id) AS decimal(18,1))),'?') " +
       "FROM sys.databases d WHERE database_id > 4 AND state = 0;"
  $r = Invoke-SqlCmdLocal -Target $Target -Query $q
  if (-not $r) { return @() }
  @($r -split "`n" | ForEach-Object {
      $f = $_ -split '\|'
      if ($f.Count -ge 4) { [ordered]@{ name=$f[0].Trim(); recovery=$f[1].Trim(); state=$f[2].Trim(); sizeMB=$f[3].Trim() } }
    } | Where-Object { $_ })
}

# Is somebody else already backing this instance up? Two backup systems on one database is worse
# than one: each truncates the other's log chain and neither restore is then trustworthy.
# msdb.dbo.backupset is the only honest source - it records every backup whoever took it.
function Get-ForeignBackupHistoryDaysLocal {
  param([string]$Target)
  $q = "SET NOCOUNT ON; SELECT ISNULL(CONVERT(varchar(20), DATEDIFF(day, MAX(backup_finish_date), GETDATE())), '-1') " +
       "FROM msdb.dbo.backupset WHERE backup_finish_date IS NOT NULL;"
  $r = Invoke-SqlCmdLocal -Target $Target -Query $q
  if (-not $r) { return -1 }
  $n = -1; [void][int]::TryParse(($r -replace '[^0-9-]',''), [ref]$n)
  return $n
}

# ================================================================================================
# PHASE 2 - PREREQ.  Admin, PowerShell 5.1, TLS 1.2, egress, free space, and the one that decides
# whether this run can finish today: a PENDING REBOOT.
#
# A migrated guest very often arrives mid-reboot - Windows Update staged on the source, a rename
# half-applied by the migration, file renames queued.
#
# This USED to stop at exit 1 and hand the rest of the run to a resume task. It no longer does,
# and the reason is in Invoke-Prereq: no principal can both fire at startup and be chadmin
# without a stored password, so the resume task had to run as SYSTEM - which cannot register a
# task as chadmin, which is most of what the later phases do. Nothing here needs a clean boot,
# and TOOLS creates a pending reboot of its own anyway, so a pending reboot is now REPORTED, the
# run continues, and the reboot is reported again at the end.
# ================================================================================================
function Invoke-Prereq {
  $ok = $true

  if (-not (Test-Elevated)) { L 'not elevated - run this from an administrator session.' 'ERROR'; return 5 }
  L 'elevation: administrator' 'OK'

  $psv = $PSVersionTable.PSVersion
  L ('PowerShell ' + $psv.ToString())
  if ($psv.Major -lt 5) { Flag 'PREREQ' ('Windows PowerShell ' + $psv + ' - this payload needs 5.1. Nothing here will work until that is fixed.'); $ok = $false }
  if ($psv.Major -ge 6) { Flag 'PREREQ' ('running under PowerShell ' + $psv + '. The payload is written for Windows PowerShell 5.1; re-run with powershell.exe, not pwsh.exe.'); $ok = $false }

  # Server 2016 .NET defaults to TLS 1.0, so every HTTPS call fails while the network is fine.
  try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; L 'TLS 1.2 enabled for this session' 'OK' }
  catch { Flag 'PREREQ' 'could not select TLS 1.2 for this session.'; $ok = $false }

  $free = 0
  try { $free = [math]::Round((Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'").FreeSpace/1GB,1) } catch {}
  L ('free space on C: ' + $free + ' GB')
  if ($free -gt 0 -and $free -lt 2) { Flag 'PREREQ' ('only ' + $free + ' GB free on C: - the payload and its logs need room.') }

  $egress = Test-PayloadEgress
  if (-not $egress) {
    L 'no HTTPS egress to raw.githubusercontent.com:443 - the toolkit cannot be fetched.' 'ERROR'
    return 6
  }
  L 'HTTPS egress to the payload host: reachable' 'OK'

  # A PENDING REBOOT NO LONGER STOPS THIS RUN. Measured on TS_BM_FD_DB01 2026-10-22, same probe
  # body run as two principals:
  #   as SYSTEM   Register-ScheduledTask -LogonType S4U for chadmin -> Access is denied
  #   as chadmin  the same call                                     -> REGISTERED
  # So a run that stops here and hands the rest to YC-AdoptResume (SYSTEM) can NEVER register
  # YC-DiskScan or the SQLMAINT tasks, and reports it as "S4U is refused on this host", which is
  # false. chadmin via S4U can register them but an S4U task does not fire at startup until that
  # account logs on, so it cannot be the resume task either. No principal does both.
  #
  # The fix is to stop needing one: nothing in this adopt requires a clean boot before it runs,
  # and TOOLS creates a pending reboot of its own anyway, so stopping first only defers the work
  # while throwing away the one identity that can do the job. Run everything as the account we
  # already are, and reboot at the END.
  $reasons = @(Get-PendingRebootReasonsLocal)
  if ($reasons.Count -gt 0) {
    $script:RebootWasPending = $true
    L ('a reboot is PENDING: ' + ($reasons -join ', ')) 'WARN'
    L 'continuing anyway - this run does not need a clean boot, and stopping here is what used to hand the rest of the run to SYSTEM, which cannot register a task as chadmin. The reboot is reported again at the end.' 'WARN'
  } else {
    L 'no pending reboot' 'OK'
  }
  if (-not $ok) { return 2 }
  return 0
}

function Test-PayloadEgress {
  $hostName = ([Uri]$Url).Host
  try {
    $r = Test-NetConnection -ComputerName $hostName -Port 443 -WarningAction SilentlyContinue -ErrorAction Stop
    if ($r.TcpTestSucceeded) { return $true }
  } catch {}
  # Test-NetConnection is absent or slow on some builds; TcpClient with a real ceiling is the
  # fallback. 8 seconds, because a boot-time script must never hang.
  try {
    $c = New-Object Net.Sockets.TcpClient
    $ia = $c.BeginConnect($hostName, 443, $null, $null)
    $ok = $ia.AsyncWaitHandle.WaitOne(8000, $false)
    $c.Close()
    return $ok
  } catch { return $false }
}

# The resume task is how a reboot stops being a dead end. It is removed by the run that completes,
# so it can never become a task that fires forever doing nothing - the failure shape that bit
# report-inventory once already.
# Register-ResumeTask DELETED in 2.27.0, and this note is here so it is not reinvented.
#
# It registered a task to continue the run after a reboot. Nothing calls it any more, because a
# pending reboot no longer stops the run - see PREREQ. It is not kept "just in case", because
# the thing it would be kept for cannot work: measured on TS_BM_FD_DB01 2026-10-22, a resumed
# run as SYSTEM gets "Access is denied" registering an S4U task for chadmin, and a resume task
# registered AS chadmin via S4U does not fire at startup until chadmin logs on. Whichever
# principal it used, the resumed half was either unable to register the SQL and disk tasks or
# unable to start. A dead function that looks like a working fallback is worse than no fallback.
#
# Unregister-ResumeTask stays: hosts adopted by 2.21.0 through 2.26.0 may still carry a
# YC-AdoptResume task, and a completed run should clear it.

function Unregister-ResumeTask {
  try {
    if (Get-ScheduledTask -TaskName $script:ResumeTask -ErrorAction SilentlyContinue) {
      Unregister-ScheduledTask -TaskName $script:ResumeTask -Confirm:$false
      L ($script:ResumeTask + ' removed - the run completed, so there is nothing left to resume.') 'OK'
    }
  } catch { L ('could not remove ' + $script:ResumeTask + ': ' + $_.Exception.Message) 'WARN' }
}

# ================================================================================================
# PHASE 3 - BOOTSTRAP.  The ONE genuinely new download path in the whole estate.
# Update-YcScripts.ps1 cannot bootstrap itself - it lives inside the payload it fetches. This
# fetches the zip and its sidecar, VERIFIES THE HASH BEFORE EXTRACTING ANYTHING, and takes exactly
# one file out: Update-YcScripts.ps1. From the next phase on, this machine is on the same channel
# as every fresh VM and this code never runs again.
# ================================================================================================
function Invoke-Bootstrap {
  $upd = Join-Path $ScriptsDir 'Update-YcScripts.ps1'
  if (Test-Path -LiteralPath $upd) { L 'Update-YcScripts.ps1 is already present - bootstrap not needed.' 'OK'; return 0 }

  if (-not (Test-Path -LiteralPath $ScriptsDir)) { New-Item -ItemType Directory -Path $ScriptsDir -Force | Out-Null }
  $tmp = Join-Path $env:TEMP ('yc-bootstrap-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  $zip = Join-Path $tmp 'payload.zip'
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    L ('downloading ' + $Url)
    Invoke-WebRequest -Uri $Url -OutFile $zip -UseBasicParsing -ErrorAction Stop
    L ('downloading ' + $ShaUrl)
    $sidecar = (Invoke-WebRequest -Uri $ShaUrl -UseBasicParsing -ErrorAction Stop).Content
  } catch {
    L ('bootstrap download failed: ' + $_.Exception.Message) 'ERROR'
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    return 6
  }

  $want = ([string]$sidecar -split '\s+')[0].Trim().ToUpper()
  $got  = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToUpper()
  if (-not $want -or $want -ne $got) {
    L ('sha256 MISMATCH - expected ' + $want + ' got ' + $got + '. NOTHING was extracted.') 'ERROR'
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    return 4
  }
  L ('sha256 verified: ' + $got) 'OK'

  # Exactly one file. The rest of the payload arrives through Update-YcScripts, which is the only
  # thing allowed to write C:\Scripts wholesale.
  try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $z = [IO.Compression.ZipFile]::OpenRead($zip)
    try {
      $e = $z.Entries | Where-Object { $_.Name -eq 'Update-YcScripts.ps1' } | Select-Object -First 1
      if (-not $e) { L 'Update-YcScripts.ps1 is not inside the payload zip.' 'ERROR'; return 4 }
      [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $upd, $true)
    } finally { $z.Dispose() }
    L ('extracted Update-YcScripts.ps1 -> ' + $upd) 'OK'
  } catch {
    L ('extract failed: ' + $_.Exception.Message) 'ERROR'
    return 4
  } finally { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
  return 0
}

# ================================================================================================
# PHASE 4 - SYNC.  Hand over to the real payload channel. Exit 4 and 7 mean it ROLLED BACK, not
# that it half-updated - that distinction is why those two codes exist.
# ================================================================================================
function Invoke-Sync {
  $code = Invoke-YcCommand -Script 'Update-YcScripts.ps1' -Arguments @('-Url',$Url,'-ShaUrl',$ShaUrl) -Phase 'SYNC'
  if ($null -eq $code) { return 4 }
  if ($code -eq 4) { L 'payload sha256 mismatch - Update-YcScripts rolled back, so C:\Scripts is unchanged.' 'ERROR'; return 4 }
  if ($code -eq 7) { L 'Update-YcScripts refused at its own gate and rolled back - C:\Scripts is unchanged.' 'ERROR'; return 4 }
  if ($code -ne 0) { return 3 }
  # The library is dot-sourced by Main after this phase returns - see Test-YcLibraryPresent.
  $vf = Join-Path $ScriptsDir 'yc-payload-version.txt'
  if (Test-Path -LiteralPath $vf) { L ('payload now: ' + ((Get-Content -LiteralPath $vf -TotalCount 1) -replace '^[^=]*=\s*','').Trim()) 'OK' }
  $n = @(Get-ChildItem -LiteralPath $ScriptsDir -File -ErrorAction SilentlyContinue).Count
  # The version string alone has lied before - a 124-entry kit and the published 138-entry zip both
  # reported the same payload_version. Count the files too.
  L ([string]$n + ' files in ' + $ScriptsDir)
  if ($n -lt 100) { Flag 'SYNC' ([string]$n + ' files in ' + $ScriptsDir + ' - a full payload is ~148. This looks partial.') }
  return 0
}

# ================================================================================================
# PHASE 5 - PATH.  Make  yallacloud  work, which is the whole point for an L1 on the console.
# ================================================================================================
function Invoke-Path {
  $cur = [Environment]::GetEnvironmentVariable('Path','Machine')
  $parts = @([string]$cur -split ';' | Where-Object { $_ })
  if ($parts | Where-Object { $_.TrimEnd('\') -ieq $ScriptsDir.TrimEnd('\') }) {
    L ($ScriptsDir + ' is already on the machine PATH') 'OK'
  } else {
    try {
      [Environment]::SetEnvironmentVariable('Path', (($parts + $ScriptsDir) -join ';'), 'Machine')
      L ($ScriptsDir + ' added to the machine PATH') 'OK'
    } catch { Flag 'PATH' ('could not add ' + $ScriptsDir + ' to the machine PATH: ' + $_.Exception.Message); return 3 }
  }
  # Make it work in THIS session too, so the operator can type yallacloud without signing out.
  if (($env:Path -split ';' | Where-Object { $_.TrimEnd('\') -ieq $ScriptsDir.TrimEnd('\') }).Count -eq 0) {
    $env:Path = $env:Path + ';' + $ScriptsDir
  }
  $cmd = Join-Path $ScriptsDir 'yallacloud.cmd'
  if (Test-Path -LiteralPath $cmd) { L 'yallacloud is now a command on this host - type it to see the catalog.' 'OK' }
  else { Flag 'PATH' 'yallacloud.cmd is not in the payload, so the catalog command will not resolve.' ; return 3 }
  return 0
}

# ================================================================================================
# PHASE - TOOLS.  The things a migrated box is missing that a golden image already has.
#
# ORDER IS A DEPENDENCY CHAIN, NOT A PREFERENCE:
#   Chocolatey -> git -> .NET 4.8 -> PowerShell 7 -> dbatools -> SSMS -> winget
#
#   * Chocolatey is FIRST because install-dotnet and install-ssms both REFUSE without it - they
#     say "It ships on the YallaCloud golden image - this box is not one" and exit. A migrated VM
#     never passed through the golden build, so today neither command can run on one at all.
#   * git is SECOND because Update-YcScripts.ps1 says in its own comments "every YallaCloud server
#     has git installed" and falls back to a shallow clone when the HTTPS fetch fails. On a
#     migrated box that is simply untrue, so the payload update channel quietly has ONE path
#     instead of two - and git is the path that matters, because github.com and
#     raw.githubusercontent.com can be blocked independently AND git does its own TLS through
#     schannel rather than .NET, which is what survives the Server 2016 TLS 1.0 default.
#   * .NET 4.8 before SSMS and before Chocolatey 2.x, which both need it.
#   * PowerShell 7 is SIDE BY SIDE. Windows PowerShell 5.1 stays the host for everything in this
#     payload - yc-compliance FAILS any script using PS7-only syntax, and the scheduled tasks
#     keep calling powershell.exe. PS7 is here for humans and for dbatools.
#   * winget is BEST EFFORT and never a dependency: it ships inside App Installer, which is not
#     available on Server 2016 or 2019 at all and needs a manual msixbundle on 2022. That is
#     precisely why this payload standardised on Chocolatey, which works on 2016 through 2025.
#
# Every step is individually skippable and a failure FLAGS rather than aborting the adopt: a box
# that got the toolkit and the backups but not SSMS is still enormously better off than one that
# stopped at step three.
# ================================================================================================
function Invoke-Tools {
  $rc = 0

  # Read PATH back from the registry BEFORE the first check. A process inherits its parent's
  # environment block, and that parent may predate an earlier TOOLS run, so Get-Command would
  # report an installed tool as missing. Observed on TS_BM_FD_DB01: choco WAS installed, this
  # function did not see it, and re-ran the Chocolatey web installer - which printed a wall of
  # WARNING text about an existing installation that reads like a failure. git was detected
  # correctly in the same run only because the refresh used to happen after the choco branch.
  try {
    $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')
  } catch { }

  # --- 1. Chocolatey ---------------------------------------------------------------------------
  if (Get-Command choco.exe -ErrorAction SilentlyContinue) {
    L 'Chocolatey is already installed.' 'OK'
  } elseif ($SkipChoco) {
    L 'Chocolatey skipped by -SkipChoco. install-dotnet and install-ssms will refuse to run.' 'WARN'
  } else {
    L 'installing Chocolatey - install-dotnet and install-ssms both refuse without it.'
    try {
      [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
      Set-ExecutionPolicy Bypass -Scope Process -Force -ErrorAction SilentlyContinue
      $script = (New-Object Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1')
      Invoke-Expression $script | Out-Null
      # Read it back on a fresh PATH. "The installer did not throw" is not "choco is there".
      $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')
      if (Get-Command choco.exe -ErrorAction SilentlyContinue) {
        L ('Chocolatey installed: ' + ((& choco.exe --version 2>&1 | Select-Object -First 1))) 'OK'
      } else { Flag 'TOOLS' 'the Chocolatey installer ran without error but choco.exe is not on PATH.'; $rc = 3 }
    } catch { Flag 'TOOLS' ('Chocolatey install failed: ' + $_.Exception.Message); $rc = 3 }
  }

  # --- 2. git ----------------------------------------------------------------------------------
  if (Get-Command git.exe -ErrorAction SilentlyContinue) {
    L ('git is already installed: ' + ((& git.exe --version 2>&1 | Select-Object -First 1))) 'OK'
  } elseif (-not (Get-Command choco.exe -ErrorAction SilentlyContinue)) {
    Flag 'TOOLS' 'git is missing and Chocolatey is not available to install it. Update-YcScripts loses its clone fallback, so the payload update channel has only one path.'
    $rc = 3
  } else {
    L 'installing git - it is the fallback path Update-YcScripts already believes exists.'
    $c = Invoke-Choco -Package 'git' -Phase 'TOOLS'
    if ($c -ne 0) { $rc = 3 }
    else {
      $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')
      if (Get-Command git.exe -ErrorAction SilentlyContinue) { L 'git is on PATH - the payload update fallback is restored.' 'OK' }
      else { Flag 'TOOLS' 'choco reported success but git.exe is not on PATH yet. It usually needs a new shell; re-check after a reboot.' }
    }
  }

  # --- 3. .NET 4.8 -------------------------------------------------------------------------------
  if (-not $SkipDotNet) {
    # exit 8 means "installed, reboot required" - that is a success, not a failure.
    $c = Invoke-YcCommand -Script 'Install-DotNet.ps1' -Arguments @() -Phase 'TOOLS' -OkCodes @(0,8)
    if ($c -eq 8) { L '.NET installed and a REBOOT IS REQUIRED before SSMS will install cleanly.' 'WARN' }
  }

  # --- 4. PowerShell 7, side by side ---------------------------------------------------------------
  if ($SkipPwsh) { L 'PowerShell 7 skipped by -SkipPwsh.' }
  elseif (Test-Pwsh7Present) { L 'PowerShell 7 is already installed.' 'OK' }
  else { if (-not (Install-Pwsh7)) { $rc = 3 } }

  # --- 5. dbatools -------------------------------------------------------------------------------
  # -Online because a migrated box has no staged nupkg. Dbatools-Install.ps1 already proves the
  # install properly: it refuses a "dbatools 0.0.0" folder, checks dbatools.psd1 exists before
  # copying, verifies with real commands, and installs dbatools.library which 2.x needs to import.
  Invoke-YcCommand -Script 'Dbatools-Install.ps1' -Arguments @('-Online') -Phase 'TOOLS' | Out-Null

  # --- 6. SSMS -----------------------------------------------------------------------------------
  if (-not $SkipSsms) { Invoke-YcCommand -Script 'Install-Ssms.ps1' -Arguments @() -Phase 'TOOLS' | Out-Null }

  # --- 7. diagnostic tools -----------------------------------------------------------------------
  # DiagTools-Install installs from a STAGED folder that golden images carry and the payload zip
  # deliberately does not - it is about 1.7 GB. A migrated VM has never had it. So check first and
  # say so plainly, rather than running an installer that will find an empty directory and
  # reporting whatever it makes of that.
  if (-not $SkipDiagTools) {
    $dt = Join-Path $ScriptsDir 'DiagTools'
    if (Test-Path -LiteralPath $dt) {
      Invoke-YcCommand -Script 'DiagTools-Install.ps1' -Arguments @() -Phase 'TOOLS' | Out-Null
    } else {
      L ('no staged diagnostic tools at ' + $dt + ' - normal on a migrated VM, they ship with a golden image and not in the payload. Copy the DiagTools folder there and run  diagtools-install  if they are wanted on this host.') 'WARN'
    }
  }

  # --- 8. winget, best effort --------------------------------------------------------------------
  Install-WingetBestEffort

  # --- 9. the guest platform: the agent the backups depend on, and virtio against the pin -------
  # Last in the phase so the loud banner is the last thing on screen when TOOLS ends, rather than
  # scrolling away behind a Chocolatey wall of text.
  $g = Invoke-GuestPlatform
  if ($g -ne 0 -and $rc -eq 0) { $rc = 3 }

  return $rc
}

function Invoke-Choco {
  param([string]$Package,[string]$Phase)
  $choco = Get-Command choco.exe -ErrorAction SilentlyContinue
  if (-not $choco) { Flag $Phase ('Chocolatey is not available, so ' + $Package + ' was not installed.'); return 1 }
  try {
    $p = Start-Process -FilePath $choco.Source -Wait -PassThru -NoNewWindow `
           -ArgumentList @('install',$Package,'-y','--no-progress','--no-color')
    $code = $p.ExitCode
    # 3010 and 1641 are "installed, reboot needed" - success with a note, not a failure.
    if ($code -in @(0,3010,1641)) {
      L ('choco install ' + $Package + ' exit=' + [string]$code + $(if ($code -ne 0) { ' (installed, a reboot is required)' } else { '' })) 'OK'
      return 0
    }
    Flag $Phase ('choco install ' + $Package + ' failed with exit ' + [string]$code + '. See C:\ProgramData\chocolatey\logs\chocolatey.log')
    return $code
  } catch { Flag $Phase ('choco install ' + $Package + ' could not be started: ' + $_.Exception.Message); return 1 }
}

# Detect by install path, not by command name: a freshly installed PowerShell 7 is not on THIS
# process's PATH yet, so Get-Command would say "not installed" and we would install it twice.
function Test-Pwsh7Present {
  foreach ($g in @('C:\Program Files\PowerShell\7\*.exe','C:\Program Files\PowerShell\7-preview\*.exe')) {
    if (@(Get-ChildItem -Path $g -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^(pwsh|powershell)\.exe$' }).Count) { return $true }
  }
  return $false
}

function Install-Pwsh7 {
  # The MSI is staged on a golden image (MANIFEST install_to C:\Scripts\PowerShell-win-x64.msi).
  # A migrated box does not have it, so prefer the staged copy and fall back to Chocolatey, which
  # tracks the current release and saves us pinning a version in a frozen script.
  $staged = Join-Path $ScriptsDir 'PowerShell-win-x64.msi'
  if (Test-Path -LiteralPath $staged) {
    L ('installing PowerShell 7 from the staged MSI: ' + $staged)
    try {
      $p = Start-Process -FilePath 'msiexec.exe' -Wait -PassThru -NoNewWindow `
             -ArgumentList @('/i',('"' + $staged + '"'),'/quiet','/norestart','ADD_EXPLORER_CONTEXT_MENU_OPENPOWERSHELL=0','ENABLE_PSREMOTING=0','REGISTER_MANIFEST=1')
      if ($p.ExitCode -in @(0,3010,1641)) { L ('PowerShell 7 installed (msiexec exit ' + [string]$p.ExitCode + ').') 'OK'; return $true }
      Flag 'TOOLS' ('msiexec returned ' + [string]$p.ExitCode + ' installing the staged PowerShell 7 MSI.')
      return $false
    } catch { Flag 'TOOLS' ('could not run msiexec for PowerShell 7: ' + $_.Exception.Message); return $false }
  }
  # PROVEN FAILURE, TS_BM_FD_DB01 2026-10-22: choco's powershell-core package reported
  # "exited 404" while its real error was
  #   Exception calling "GetResponse" ... "The underlying connection was closed:
  #   An unexpected error occurred on a send."
  # A HEAD on the exact same asset URL returned 200 from the same host minutes later. The
  # package's downloader runs in its own process without our TLS setting, and choco maps the
  # failure onto 404, so the log blames a missing file for what is a transport problem. Doing
  # the download in a session we control removes the whole class. Choco stays as the last
  # resort, not the first.
  if (Install-Pwsh7FromGitHub) { return $true }
  if (Get-Command choco.exe -ErrorAction SilentlyContinue) {
    L 'direct download did not work - falling back to Chocolatey for PowerShell 7.' 'WARN'
    return ((Invoke-Choco -Package 'powershell-core' -Phase 'TOOLS') -eq 0)
  }
  Flag 'TOOLS' 'PowerShell 7 was not installed: no staged MSI, no direct download and no Chocolatey.'
  return $false
}

# Resolve the CURRENT release rather than pinning a version into a frozen script, then install
# it with msiexec. The asset name is read from the release, never built by hand: PowerShell has
# changed its asset naming before and a guessed URL is the 404 this function exists to avoid.
function Install-Pwsh7FromGitHub {
  $api = 'https://api.github.com/repos/PowerShell/PowerShell/releases/latest'
  $url = ''
  $ver = ''
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $ProgressPreference = 'SilentlyContinue'
    # GitHub rejects a request with no User-Agent.
    $rel = Invoke-RestMethod -Uri $api -UseBasicParsing -TimeoutSec 30 `
             -Headers @{ 'User-Agent' = 'yallacloud-adopt'; 'Accept' = 'application/vnd.github+json' }
    $ver = [string]$rel.tag_name
    $a = @($rel.assets | Where-Object { $_.name -like '*win-x64.msi' } | Select-Object -First 1)
    if ($a.Count) { $url = [string]$a[0].browser_download_url }
  } catch {
    # Unauthenticated api.github.com allows 60 requests an hour PER SOURCE IP. A fleet behind one
    # NAT can exhaust that, and the symptom is a 403 here - which is a rate limit, not an outage.
    Flag 'TOOLS' ('could not ask GitHub which PowerShell release is current (' + $_.Exception.Message + '). If this is a 403 it is the unauthenticated rate limit on this egress IP, not a broken release feed.')
    return $false
  }
  if (-not $url) { Flag 'TOOLS' 'the current PowerShell release lists no win-x64.msi asset. Not guessing a URL.'; return $false }

  $msi = Join-Path $env:TEMP ('pwsh7-' + [guid]::NewGuid().ToString('N') + '.msi')
  try {
    L ('downloading PowerShell ' + $ver + ' from the release feed: ' + $url)
    Invoke-WebRequest -Uri $url -OutFile $msi -UseBasicParsing -TimeoutSec 600 -ErrorAction Stop
  } catch {
    Flag 'TOOLS' ('could not download the PowerShell MSI: ' + $_.Exception.Message)
    Remove-Item -LiteralPath $msi -Force -ErrorAction SilentlyContinue
    return $false
  }
  # A truncated download installs as a corrupt MSI, so refuse anything implausibly small rather
  # than handing msiexec a broken file. The real MSI is ~100 MB.
  $kb = 0
  try { $kb = [int]((Get-Item -LiteralPath $msi).Length / 1KB) } catch {}
  if ($kb -lt 20000) {
    Flag 'TOOLS' ('the downloaded PowerShell MSI is only ' + [string]$kb + ' KB, which is too small to be real. Not installing it.')
    Remove-Item -LiteralPath $msi -Force -ErrorAction SilentlyContinue
    return $false
  }
  try {
    $p = Start-Process -FilePath 'msiexec.exe' -Wait -PassThru -NoNewWindow `
           -ArgumentList @('/i',('"' + $msi + '"'),'/quiet','/norestart','ADD_EXPLORER_CONTEXT_MENU_OPENPOWERSHELL=0','ENABLE_PSREMOTING=0','REGISTER_MANIFEST=1')
    if ($p.ExitCode -notin @(0,3010,1641)) {
      Flag 'TOOLS' ('msiexec returned ' + [string]$p.ExitCode + ' installing PowerShell ' + $ver + '.')
      return $false
    }
  } catch { Flag 'TOOLS' ('could not run msiexec for the PowerShell MSI: ' + $_.Exception.Message); return $false }
  finally { Remove-Item -LiteralPath $msi -Force -ErrorAction SilentlyContinue }

  # Read it back by install path. msiexec exiting 0 is not pwsh.exe existing.
  if (Test-Pwsh7Present) { L ('PowerShell ' + $ver + ' installed and confirmed on disk.') 'OK'; return $true }
  Flag 'TOOLS' ('msiexec reported success but no pwsh.exe is under C:\Program Files\PowerShell\7.')
  return $false
}

function Install-WingetBestEffort {
  if (Get-Command winget.exe -ErrorAction SilentlyContinue) { L 'winget is already present.' 'OK'; return }
  $build = 0
  try { $build = [int](Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).BuildNumber } catch {}
  # Server 2016 = 14393, 2019 = 17763. App Installer, which carries winget, is not available on
  # either, and that is not a fault to fix - it is why this payload uses Chocolatey everywhere.
  if ($build -gt 0 -and $build -le 17763) {
    L ('winget is NOT AVAILABLE on this OS (build ' + [string]$build + ' - Server 2016/2019). Chocolatey covers it; nothing in this payload depends on winget.') 'WARN'
    return
  }
  if (Get-Command choco.exe -ErrorAction SilentlyContinue) {
    L 'attempting winget through Chocolatey (best effort - nothing depends on it).'
    $c = Invoke-Choco -Package 'winget-cli' -Phase 'TOOLS'
    if ($c -ne 0) { L 'winget could not be installed. Not a failure: nothing in this payload uses it.' 'WARN' }
    return
  }
  L 'winget not installed - no Chocolatey to try it with. Nothing depends on it.' 'WARN'
}

function Invoke-GuestPlatform {
  # Reports what this machine IS and whether it has the right agent for that platform, then fixes
  # only the thing that is safe to fix. Neither virtio nor VMware Tools is ever installed or
  # swapped here: both lay down storage and network filter drivers and want a reboot, and that is
  # a change window on a live customer VM. Starting a service that is already there is different.
  $st = $script:Evidence['platform']
  if (-not $st) { $st = Get-PlatformToolingState; $script:Evidence['platform'] = $st }
  $script:Evidence['guestAgent'] = $st.agent
  $script:Evidence['virtio']     = $st.virtio
  Write-GuestPlatformLoud -State $st
  if ($SkipGuestAgent) {
    if ($st.agent.verdict -notin @('OK','NOT-APPLICABLE')) { L 'the guest agent was NOT installed or started: -SkipGuestAgent was passed.' 'WARN' }
    return 0
  }
  $rc = 0
  switch ($st.platform) {
    'KVM'    { $rc = Install-QemuGuestAgent  -Guest $st.agent }
    'VMWARE' { $rc = Start-VMwareToolsService -Agent $st.agent }
    default  { L ('no guest tooling is installed on a ' + $st.platform + ' guest - YallaCloud has none for it. Reported only.') 'WARN' }
  }
  # Re-read, so the report says what is true NOW while Evidence keeps what ARRIVED.
  $script:GuestAgentAfter = $(if ($st.platform -eq 'VMWARE') { Get-VMwareToolsState } elseif ($st.platform -eq 'KVM') { Get-GuestAgentState } else { $st.agent })
  return $rc
}

# ================================================================================================
# WHAT HYPERVISOR IS THIS, AND IS THE RIGHT GUEST TOOLING ON IT?
#
# This estate started KVM/CloudStack, so the first version of this file only knew about virtio and
# the QEMU guest agent. We also adopt VMs off vCenter, and on one of those the virtio check is
# meaningless while a stopped VMware Tools is the whole problem. So the platform is DETECTED and
# the checks branch on it.
#
# WHY IT MATTERS AT ALL: snapshot backups on this estate are AGENTLESS. PBS asks qemu-guest-agent
# (KVM) or VMware Tools (vCenter) to freeze the machine so a database is consistent inside the
# snapshot. Whichever platform it is, if that agent is absent or STOPPED, every snapshot of that
# VM is crash-consistent and nobody is told at the time. Vss-Check.ps1 says the same thing.
#
# DETECTION: Win32_ComputerSystem Manufacturer/Model, with Win32_BIOS as the second opinion. Both
# classes exist on every Windows from 2012R2 to 2025 - no CIM namespace that only ships on newer
# builds, no Get-ComputerInfo (2016+ only), no WMI query that a 2012R2 box answers differently.
$script:VirtioPinFileVersion = '100.100.104.27100'   # virtio-win 0.1.271, as yc-firstboot pins it
$script:VirtioDrivers = @('viostor','vioscsi','netkvm','balloon','vioser')
$script:VMwareDrivers = @('pvscsi','vmxnet3','vmci','vmmemctl','vmmouse','vsock')

function Get-GuestPlatformKind {
  $o = [ordered]@{ kind='UNKNOWN'; manufacturer=''; model=''; bios=''; why='' }
  try {
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
    $o.manufacturer = [string]$cs.Manufacturer
    $o.model        = [string]$cs.Model
  } catch { }
  try { $o.bios = [string](Get-CimInstance -ClassName Win32_BIOS -ErrorAction Stop).Manufacturer } catch { }
  $all = ($o.manufacturer + ' ' + $o.model + ' ' + $o.bios)

  # Order matters. A VMware guest reports "VMware, Inc." in Manufacturer AND in the BIOS, while a
  # CloudStack/KVM guest reports QEMU in one and often "Standard PC" or a seabios string in the
  # other, so the distinctive vendor string is tested before the generic machine model.
  if     ($all -match 'VMware')                       { $o.kind='VMWARE';  $o.why='Manufacturer/BIOS reports VMware' }
  elseif ($all -match 'QEMU|KVM|Bochs|SeaBIOS')       { $o.kind='KVM';     $o.why='Manufacturer/BIOS reports QEMU/KVM' }
  elseif ($all -match 'Microsoft.*Virtual|Hyper-V')   { $o.kind='HYPERV';  $o.why='Manufacturer/Model reports a Microsoft virtual machine' }
  elseif ($all -match 'Xen')                          { $o.kind='XEN';     $o.why='Manufacturer/BIOS reports Xen' }
  elseif ($all -match 'VirtualBox')                   { $o.kind='VBOX';    $o.why='Manufacturer/BIOS reports VirtualBox' }
  elseif ($all -match 'Amazon|Google|Nutanix|Parallels|oVirt|Red Hat') {
                                                        $o.kind='OTHER-HV'; $o.why='reports a hypervisor vendor we do not have tooling for' }
  else {
    # Last resort: a machine with no hypervisor string but a virtual-looking model. Physical
    # hardware answers with a real vendor and a real model, so this is only reached when neither
    # matched - and saying UNKNOWN is better than guessing PHYSICAL and skipping every check.
    if ($o.manufacturer -and $o.model) { $o.kind='PHYSICAL-OR-UNKNOWN'; $o.why='no hypervisor signature in Manufacturer, Model or BIOS' }
    else { $o.why='could not read Win32_ComputerSystem' }
  }
  return $o
}

function Get-VirtioPin {
  # Read the pinned package version out of the payload's own manifest. Falls back to the constant
  # above, and SAYS SO, rather than silently comparing against nothing.
  $pin = [ordered]@{ package=''; fileVersion=$script:VirtioPinFileVersion; source='built-in constant' }
  try {
    $mf = Join-Path $ScriptsDir 'MANIFEST.json'
    if (Test-Path -LiteralPath $mf) {
      $m = Get-Content -LiteralPath $mf -Raw | ConvertFrom-Json
      $iso = @($m.members | Where-Object { $_.name -eq 'virtio-win-iso' }) | Select-Object -First 1
      if ($iso -and $iso.version) { $pin.package = [string]$iso.version; $pin.source = 'MANIFEST.json' }
    }
  } catch {}
  if (-not $pin.package) { $pin.package = '0.1.271-1 (manifest unreadable)' }
  return $pin
}

function Get-VMwareToolsPin {
  # VMware Tools 13.x DROPPED Windows Server 2012R2. A 2012R2 guest pinned to 13.x would be
  # reported as out of date forever and could never satisfy it, so the pin is chosen by OS build:
  # 14393 is Server 2016. The manifest carries both builds for exactly this reason
  # (vmware-tools 13.1.0 and vmware-tools-legacy 12.5.4).
  $pin = [ordered]@{ package=''; source='built-in constant'; track='current'; reason='' }
  $build = 0
  try { $build = [int]((Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).BuildNumber) } catch {}
  $wantLegacy = ($build -gt 0 -and $build -lt 14393)
  $pin.track  = if ($wantLegacy) { 'legacy' } else { 'current' }
  $pin.reason = if ($wantLegacy) { 'OS build ' + [string]$build + ' is older than Server 2016, which VMware Tools 13.x does not support' }
                else { 'OS build ' + [string]$build + ' is Server 2016 or newer' }
  $name = if ($wantLegacy) { 'vmware-tools-legacy' } else { 'vmware-tools' }
  try {
    $mf = Join-Path $ScriptsDir 'MANIFEST.json'
    if (Test-Path -LiteralPath $mf) {
      $m = Get-Content -LiteralPath $mf -Raw | ConvertFrom-Json
      $e = @($m.members | Where-Object { $_.name -eq $name }) | Select-Object -First 1
      if ($e -and $e.version) { $pin.package = [string]$e.version; $pin.source = 'MANIFEST.json' }
    }
  } catch {}
  if (-not $pin.package) { $pin.package = if ($wantLegacy) { '12.5.4' } else { '13.1.0' } }
  return $pin
}

function Compare-VersionLoose {
  # Returns -1 older, 0 same, 1 newer, 99 not comparable. VMware Tools reports 4 parts
  # (13.1.0.12345) while the manifest pins 3 (13.1.0), so only the parts both sides have are
  # compared - otherwise every host reads as "older than the pin" forever.
  param([string]$Have,[string]$Want)
  $h = @(($Have -replace '[^0-9.]','') -split '\.' | Where-Object { $_ -ne '' })
  $w = @(($Want -replace '[^0-9.]','') -split '\.' | Where-Object { $_ -ne '' })
  if (-not $h.Count -or -not $w.Count) { return 99 }
  $n = [Math]::Min($h.Count, $w.Count)
  for ($i=0; $i -lt $n; $i++) {
    $a = 0; $b = 0
    [void][int]::TryParse($h[$i], [ref]$a); [void][int]::TryParse($w[$i], [ref]$b)
    if ($a -lt $b) { return -1 }
    if ($a -gt $b) { return 1 }
  }
  return 0
}

function Get-ServiceStateSafe {
  # One shape for "is this agent service there, and is it actually running", used by both
  # platforms. Get-Service returns the service whether it is Running or Stopped, which is exactly
  # the trap this whole section exists to close.
  param([string[]]$Names,[string]$DisplayLike)
  $s = [ordered]@{ installed=$false; service=''; status='absent'; startType=''; running=$false }
  $svc = $null
  try { $svc = @(Get-Service -Name $Names -ErrorAction SilentlyContinue) | Select-Object -First 1 } catch {}
  if (-not $svc -and $DisplayLike) {
    try { $svc = @(Get-Service -DisplayName $DisplayLike -ErrorAction SilentlyContinue) | Select-Object -First 1 } catch {}
  }
  if (-not $svc) { return $s }
  $s.installed = $true
  $s.service   = [string]$svc.Name
  $s.status    = [string]$svc.Status
  $s.running   = ([string]$svc.Status -eq 'Running')
  # StartType on the Get-Service object is PowerShell 5.1+ only on some builds; Win32_Service is
  # on every Windows back to 2012R2, so read it there and never fail the whole probe for it.
  try { $s.startType = [string](Get-CimInstance Win32_Service -Filter ("Name='" + $svc.Name + "'") -ErrorAction Stop).StartMode } catch {}
  return $s
}

function Get-GuestAgentState {
  # The KVM agent.
  $g = [ordered]@{ platform='KVM'; agent='qemu-guest-agent'; installed=$false; service=''; status='absent'
                   startType=''; version=''; running=$false; verdict='MISSING'
                   why='no QEMU guest agent service on this machine' }
  $s = Get-ServiceStateSafe -Names @('QEMU-GA','qemu-ga') -DisplayLike 'QEMU Guest Agent*'
  foreach ($k in @('installed','service','status','startType','running')) { $g[$k] = $s[$k] }
  if (-not $g.installed) { return $g }
  try {
    $exe = (Get-CimInstance Win32_Service -Filter ("Name='" + $g.service + "'") -ErrorAction Stop).PathName
    if ($exe) {
      $p = ($exe -replace '^"([^"]+)".*$','$1') -replace '\s+-.*$',''
      if (Test-Path -LiteralPath $p) { $g.version = [string](Get-Item -LiteralPath $p).VersionInfo.FileVersion }
    }
  } catch { }
  if ($g.running) {
    $g.verdict = 'OK'
    $g.why = 'installed and running (' + $g.service + ', start type ' + $(if ($g.startType) { $g.startType } else { 'unknown' }) + ')'
  } else {
    $g.verdict = 'STOPPED'
    $g.why = 'installed but NOT RUNNING (' + $g.service + ' is ' + $g.status + '). Snapshot backups cannot freeze this machine while the agent is down, so they are crash-consistent and nothing says so.'
  }
  return $g
}

function Get-VMwareToolsState {
  # The vCenter agent. Same shape as the KVM one so the report and the fleet event do not need to
  # know which platform they are describing.
  $pin = Get-VMwareToolsPin
  $g = [ordered]@{ platform='VMWARE'; agent='VMware Tools'; installed=$false; service=''; status='absent'
                   startType=''; version=''; running=$false
                   pinPackage=$pin.package; pinTrack=$pin.track; pinSource=$pin.source; pinReason=$pin.reason
                   versusPin='unknown'; drivers=@(); verdict='MISSING'
                   why='no VMware Tools service on this machine' }
  $s = Get-ServiceStateSafe -Names @('VMTools','VMwareTools') -DisplayLike 'VMware Tools*'
  foreach ($k in @('installed','service','status','startType','running')) { $g[$k] = $s[$k] }
  foreach ($k in @('HKLM:\SOFTWARE\VMware, Inc.\VMware Tools','HKLM:\SOFTWARE\WOW6432Node\VMware, Inc.\VMware Tools')) {
    if ($g.version) { break }
    try { $p = Get-ItemProperty -Path $k -ErrorAction SilentlyContinue
          if ($p -and $p.Version) { $g.version = [string]$p.Version } } catch {}
  }
  $drv = @()
  foreach ($d in $script:VMwareDrivers) { if (Get-Service -Name $d -ErrorAction SilentlyContinue) { $drv += $d } }
  $g.drivers = @($drv)
  if (-not $g.installed -and -not $g.version) { return $g }
  $g.installed = $true

  if ($g.version) {
    switch (Compare-VersionLoose -Have $g.version -Want $pin.package) {
      -1 { $g.versusPin = 'OLDER-THAN-PIN' }
       0 { $g.versusPin = 'MATCHES-PIN' }
       1 { $g.versusPin = 'NEWER-THAN-PIN' }
      default { $g.versusPin = 'NOT-COMPARABLE' }
    }
  }

  if (-not $g.running) {
    $g.verdict = 'STOPPED'
    $g.why = 'installed (' + $(if ($g.version) { $g.version } else { 'version unreadable' }) + ') but NOT RUNNING (' + $(if ($g.service) { $g.service } else { 'VMTools' }) + ' is ' + $g.status + '). Snapshot backups cannot freeze this machine while VMware Tools is down, so they are crash-consistent and nothing says so.'
  } elseif ($g.versusPin -eq 'OLDER-THAN-PIN') {
    $g.verdict = 'OLD'
    $g.why = 'running, but version ' + $g.version + ' is OLDER than the pinned ' + $pin.package + ' (' + $pin.track + ' track: ' + $pin.reason + ')'
  } else {
    $g.verdict = 'OK'
    $g.why = 'installed and running (' + $g.service + ', version ' + $(if ($g.version) { $g.version } else { 'unreadable' }) + ', ' + $g.versusPin + ' ' + $pin.package + ')'
  }
  return $g
}

function Get-VirtioState {
  # Every virtio driver present, its file version, and how it compares with the pin.
  $pin = Get-VirtioPin
  $out = [ordered]@{ pinPackage=$pin.package; pinFileVersion=$pin.fileVersion; pinSource=$pin.source
                     present=$false; drivers=@(); verdict='NOT-VIRTIO'
                     why='no virtio drivers on this machine' }
  $rows = @(); $mismatch = 0; $unknown = 0
  foreach ($d in $script:VirtioDrivers) {
    $f = Join-Path $env:windir ('System32\drivers\' + $d + '.sys')
    if (-not (Test-Path -LiteralPath $f)) { continue }
    $v = ''
    try { $v = [string](Get-Item -LiteralPath $f).VersionInfo.FileVersion } catch {}
    $state = 'UNKNOWN'
    if (-not $v) { $unknown++ }
    elseif ($v -eq $pin.fileVersion) { $state = 'MATCHES-PIN' }
    else { $state = 'DIFFERS-FROM-PIN'; $mismatch++ }
    $rows += [ordered]@{ driver=$d; fileVersion=$(if ($v) { $v } else { '(unreadable)' }); state=$state }
  }
  $out.drivers = @($rows)
  if ($rows.Count -eq 0) { return $out }
  $out.present = $true
  if ($mismatch -gt 0) {
    $out.verdict = 'DIFFERS'
    $out.why = [string]$mismatch + ' of ' + [string]$rows.Count + ' virtio driver(s) are NOT at the pinned version ' + $pin.package + '. An old virtio STORAGE driver is exposed to known IO races, and it was already old when this VM arrived.'
  } elseif ($unknown -gt 0) {
    $out.verdict = 'UNPROVEN'
    $out.why = 'virtio is present but ' + [string]$unknown + ' driver version(s) could not be read, so the pin could not be checked'
  } else {
    $out.verdict = 'OK'
    $out.why = 'all ' + [string]$rows.Count + ' virtio driver(s) are at the pinned version ' + $pin.package
  }
  return $out
}

function Get-PlatformToolingState {
  # The whole picture: what this machine IS, what agent it should have, what it actually has, and
  # anything left over from the platform it came FROM.
  $p  = Get-GuestPlatformKind
  $o  = [ordered]@{ platform=$p.kind; platformWhy=$p.why; manufacturer=$p.manufacturer
                    model=$p.model; bios=$p.bios
                    expectedAgent=''; agent=$null; virtio=$null; leftovers=@(); verdict='OK'; why='' }
  $qemu   = Get-GuestAgentState
  $vmware = Get-VMwareToolsState
  $virtio = Get-VirtioState
  $o.virtio = $virtio

  switch ($p.kind) {
    'KVM' {
      $o.expectedAgent = 'qemu-guest-agent'
      $o.agent = $qemu
      # VMware Tools on a KVM guest is a leftover from the source platform. It cannot talk to any
      # host here, and a running one wastes a service; a stopped one is what vss-check reports as
      # a dead agent, which sends people looking in the wrong place.
      if ($vmware.installed) {
        $o.leftovers += ('VMware Tools is installed on a KVM guest (' + $vmware.status + ', version ' + $(if ($vmware.version) { $vmware.version } else { 'unreadable' }) + '). It came with the VM from vCenter and has no host to talk to here. It is REPORTED, not removed - uninstalling guest tooling is a reboot and a change window.')
      }
    }
    'VMWARE' {
      $o.expectedAgent = 'VMware Tools'
      $o.agent = $vmware
      if ($qemu.installed) {
        $o.leftovers += ('the QEMU guest agent is installed on a VMware guest (' + $qemu.status + '). It came from a KVM platform and has no host to talk to here.')
      }
      if ($virtio.present) {
        $o.leftovers += ([string]@($virtio.drivers).Count + ' virtio driver(s) are present on a VMware guest. They are inert here - the disks and NICs are on pvscsi/vmxnet3 - but they are evidence this VM was on KVM before.')
      }
    }
    default {
      # Hyper-V, Xen, physical, unknown. We have no tooling of our own for these, so the honest
      # answer is to report what is there and claim nothing about whether it is right.
      $o.expectedAgent = '(none - YallaCloud has no guest tooling for ' + $p.kind + ')'
      if     ($vmware.installed) { $o.agent = $vmware }
      elseif ($qemu.installed)   { $o.agent = $qemu }
      else {
        $o.agent = [ordered]@{ platform=$p.kind; agent='(none expected)'; installed=$false; service=''
                               status='absent'; startType=''; version=''; running=$false
                               verdict='NOT-APPLICABLE'
                               why='this is not a KVM or VMware guest, so neither guest agent is expected here' }
      }
    }
  }

  # virtio only earns a verdict on KVM. On anything else its presence is a leftover, not a fault.
  if ($p.kind -ne 'KVM' -and $virtio.present) { $o.virtio.verdict = 'NOT-APPLICABLE'
    $o.virtio.why = 'virtio drivers are present but this is a ' + $p.kind + ' guest, so they are inert here and the pin does not apply' }
  elseif ($p.kind -ne 'KVM') { $o.virtio.verdict = 'NOT-APPLICABLE'; $o.virtio.why = 'not a KVM guest - virtio does not apply' }

  $bad = @()
  if ($o.agent.verdict -notin @('OK','NOT-APPLICABLE')) { $bad += $o.agent.verdict }
  if ($p.kind -eq 'KVM' -and $o.virtio.verdict -in @('DIFFERS','UNPROVEN')) { $bad += 'VIRTIO ' + $o.virtio.verdict }
  if ($bad.Count) { $o.verdict = 'NEEDS-ATTENTION'; $o.why = ($bad -join ', ') }
  else { $o.verdict = 'OK'; $o.why = 'the right agent for a ' + $p.kind + ' guest is present and running' }
  return $o
}

function Write-GuestPlatformLoud {
  # Loud ONLY when there is something to be loud about. A banner that fires on a healthy machine
  # trains people to skip banners, which costs more than it buys.
  param($State)
  $a = $State.agent; $v = $State.virtio
  $bad = @()
  if ($a.verdict -notin @('OK','NOT-APPLICABLE')) { $bad += ($State.expectedAgent.ToUpper() + ': ' + $a.why) }
  if ($State.platform -eq 'KVM' -and $v.verdict -in @('DIFFERS','UNPROVEN')) { $bad += 'VIRTIO: ' + $v.why }
  L ('platform: ' + $State.platform + ' - ' + $State.platformWhy + '  (Manufacturer "' + $State.manufacturer + '", Model "' + $State.model + '")') $(if ($State.platform -eq 'UNKNOWN') { 'WARN' } else { 'OK' })
  foreach ($x in $State.leftovers) { L ('LEFTOVER FROM THE SOURCE PLATFORM: ' + $x) 'WARN'; Flag 'GUEST' ('leftover: ' + $x) }
  if (-not $bad.Count) {
    L ($State.expectedAgent + ': ' + $a.why) 'OK'
    if ($State.platform -eq 'KVM') { L ('virtio: ' + $v.why) 'OK' }
    return
  }
  # The log file has no colour, so the TEXT has to carry the severity - an L1 reading the log
  # tomorrow sees the same warning the console showed today.
  foreach ($x in $bad) { Flag 'GUEST' $x }
  Write-LoudBanner -Title ('ATTENTION - GUEST PLATFORM (' + $State.platform + ')') -Lines $bad
  if ($State.platform -eq 'KVM' -and $v.verdict -eq 'DIFFERS') {
    foreach ($r in @($v.drivers | Where-Object { $_.state -eq 'DIFFERS-FROM-PIN' })) {
      $m = '   ' + $r.driver + ' is ' + $r.fileVersion + ', pinned is ' + $v.pinFileVersion
      Write-Host $m -ForegroundColor Red; L $m 'WARN'
    }
    L 'virtio drivers are REPORTED, never swapped by this script: replacing a storage driver is a reboot and a risk of its own, and it belongs in a change window.' 'WARN'
  }
  if ($State.platform -eq 'VMWARE' -and $a.verdict -eq 'OLD') {
    L ('VMware Tools is REPORTED, never upgraded by this script: it installs storage and network filter drivers and needs a reboot. Upgrade it with  vmware-tools  in a change window. Pin track is ' + $a.pinTrack + ' because ' + $a.pinReason + '.') 'WARN'
  }
}

function Install-QemuGuestAgent {
  # The agent is a userspace service, not a storage driver, so installing it is low risk - unlike
  # virtio and VMware Tools, which this script only ever reports on.
  #
  # The MSI is NOT in the payload zip: the manifest lists it as a mirror-seed member
  # (qemu-ga-win-<version>-x86_64.msi, ~11.8 MB) and the zip is under 1 MB. A freshly built VM
  # gets it from the golden image; a MIGRATED VM has never had it. So this installs from a staged
  # copy if one is there, or from -QemuGaMsi (a local path or a URL the operator supplies), and
  # otherwise FLAGS with the exact reason instead of pretending.
  #
  # Wildcarded on purpose: yc-firstboot.ps1 used to test for C:\Scripts\qemu-ga.msi while the
  # manifest installs it as C:\Scripts\qemu-ga-win-110.0.2-x86_64.msi, so that check never fired
  # and fresh VMs could end up with no agent either.
  param($Guest)
  if ($Guest.verdict -in @('OK','NOT-APPLICABLE')) { return 0 }

  if ($Guest.installed -and -not $Guest.running) {
    L ('the guest agent is installed but ' + $Guest.status + '. Starting it and setting it to start automatically.') 'WARN'
    try {
      Set-Service -Name $Guest.service -StartupType Automatic -ErrorAction Stop
      Start-Service -Name $Guest.service -ErrorAction Stop
    } catch { Flag 'TOOLS' ('could not start the guest agent service ' + $Guest.service + ': ' + $_.Exception.Message); return 3 }
    Start-Sleep -Seconds 3
    $after = Get-GuestAgentState
    if ($after.running) { L ('guest agent is now Running (' + $after.service + ').') 'OK'; return 0 }
    Flag 'TOOLS' ('the guest agent service ' + $Guest.service + ' was told to start and is still ' + $after.status + '.')
    return 3
  }

  $msi = ''
  if ($QemuGaMsi) {
    if ($QemuGaMsi -match '^https?://') {
      $dst = Join-Path $env:TEMP 'qemu-ga.msi'
      try {
        L ('downloading the guest agent from ' + $QemuGaMsi)
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $QemuGaMsi -OutFile $dst -UseBasicParsing -TimeoutSec 180 -ErrorAction Stop
        if ((Get-Item -LiteralPath $dst).Length -lt 1000000) { throw 'the download is under 1 MB, which is not the guest agent MSI' }
        $msi = $dst
      } catch { Flag 'TOOLS' ('could not download the guest agent from ' + $QemuGaMsi + ': ' + $_.Exception.Message); return 3 }
    } elseif (Test-Path -LiteralPath $QemuGaMsi) { $msi = $QemuGaMsi }
    else { Flag 'TOOLS' ('-QemuGaMsi was given as ' + $QemuGaMsi + ' but there is no such file.'); return 3 }
  } else {
    foreach ($pat in @('qemu-ga-win-*-x86_64.msi','qemu-ga*.msi','virtio-win-guest-tools.exe')) {
      $hit = @(Get-ChildItem -LiteralPath $ScriptsDir -Filter $pat -File -ErrorAction SilentlyContinue) | Select-Object -First 1
      if ($hit) { $msi = $hit.FullName; break }
    }
  }
  if (-not $msi) {
    Flag 'GUEST' ('the QEMU guest agent is NOT INSTALLED and no installer was found. Snapshot backups cannot freeze this machine without it. Stage the MSI in ' + $ScriptsDir + ' or re-run with -QemuGaMsi <path-or-url>.')
    return 3
  }

  L ('installing the guest agent from ' + $msi)
  try {
    if ($msi -like '*.exe') {
      $p = Start-Process -FilePath $msi -ArgumentList @('/install','/quiet','/norestart') -Wait -PassThru -ErrorAction Stop
    } else {
      $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList @('/i',('"' + $msi + '"'),'/qn','/norestart') -Wait -PassThru -ErrorAction Stop
    }
    $code = $p.ExitCode
    if ($code -in @(3010,1641)) { $script:RebootNeeded += 'QEMU guest agent'; $code = 0 }
    if ($code -ne 0) { Flag 'TOOLS' ('the guest agent installer exited ' + [string]$code + '.'); return 3 }
  } catch { Flag 'TOOLS' ('could not run the guest agent installer: ' + $_.Exception.Message); return 3 }

  Start-Sleep -Seconds 3
  $after = Get-GuestAgentState
  if (-not $after.installed) { Flag 'TOOLS' 'the guest agent installer reported success but no service appeared.'; return 3 }
  if (-not $after.running) {
    try { Set-Service -Name $after.service -StartupType Automatic -ErrorAction SilentlyContinue
          Start-Service -Name $after.service -ErrorAction SilentlyContinue } catch {}
    Start-Sleep -Seconds 3
    $after = Get-GuestAgentState
  }
  if ($after.running) { L ('guest agent installed and Running (' + $after.service + ').') 'OK'; return 0 }
  Flag 'TOOLS' ('the guest agent installed but the service is ' + $after.status + '.')
  return 3
}

function Start-VMwareToolsService {
  # VMware Tools is NEVER installed or upgraded by the adopt: the installer lays down storage and
  # network filter drivers and wants a reboot, which is a change window on a live customer VM.
  # Starting a service that is already installed is a different thing, and it is the difference
  # between snapshots that freeze the machine and snapshots that do not.
  param($Agent)
  if ($Agent.verdict -in @('OK','NOT-APPLICABLE')) { return 0 }
  if (-not $Agent.installed) {
    Flag 'GUEST' ('VMware Tools is NOT INSTALLED on this VMware guest. Snapshot backups cannot freeze this machine without it, and this script does not install it: it lays down storage and network filter drivers and needs a reboot. Install it in a change window with  vmware-tools  (pin ' + $Agent.pinPackage + ', ' + $Agent.pinTrack + ' track).')
    return 3
  }
  if ($Agent.verdict -eq 'OLD') {
    Flag 'GUEST' ('VMware Tools is running but version ' + $Agent.version + ' is older than the pinned ' + $Agent.pinPackage + ' (' + $Agent.pinTrack + ' track: ' + $Agent.pinReason + '). Upgrade it in a change window with  vmware-tools  - it is not upgraded here because it needs a reboot.')
    return 3
  }
  L ('VMware Tools is installed but ' + $Agent.status + '. Starting it and setting it to start automatically.') 'WARN'
  try {
    Set-Service -Name $Agent.service -StartupType Automatic -ErrorAction Stop
    Start-Service -Name $Agent.service -ErrorAction Stop
  } catch { Flag 'TOOLS' ('could not start VMware Tools (' + $Agent.service + '): ' + $_.Exception.Message); return 3 }
  Start-Sleep -Seconds 3
  $after = Get-VMwareToolsState
  if ($after.running) { L ('VMware Tools is now Running (' + $after.service + ', version ' + $after.version + ').') 'OK'; return 0 }
  Flag 'TOOLS' ('VMware Tools was told to start and is still ' + $after.status + '.')
  return 3
}

# ================================================================================================
# THE THREE THINGS THAT DECIDE WHETHER THE DATA SURVIVES
#
# VSS, chkdsk and SQL integrity are not status lines - they are the backup path and the data
# itself, which is the entire point of this programme. On the first real end-to-end run the guest
# platform got a red banner while "33 damaged pages", "8 databases never CHECKDB'd" and "VSS has
# 4 CRITICAL findings" went past as three WARN lines among seventeen. That is backwards.
#
# One banner, fired once, carrying all three, because they fail together and they are read
# together: a damaged database, a filesystem nobody has checked, and a snapshot that cannot
# freeze the machine is not three problems - it is one unrecoverable situation.
#
# The console has colour and the log does not, so the TEXT carries the severity either way.

function Write-LoudBanner {
  param([string]$Title,[string[]]$Lines,[string[]]$Detail = @())
  if (-not $Lines.Count) { return }
  Write-Host ''
  Write-Host '  ############################################################################' -ForegroundColor Red
  Write-Host ('  #  ' + $Title) -ForegroundColor Red
  Write-Host '  ############################################################################' -ForegroundColor Red
  foreach ($x in $Lines)  { Write-Host ('  !! ' + $x) -ForegroundColor Red }
  foreach ($x in $Detail) { Write-Host ('     ' + $x) -ForegroundColor Red }
  Write-Host '  ############################################################################' -ForegroundColor Red
  Write-Host ''
  foreach ($x in $Lines)  { L ('ATTENTION - ' + $x) 'WARN' }
  foreach ($x in $Detail) { L ('   ' + $x) 'WARN' }
}

function Get-VssState {
  # Runs vss-check for its STRUCTURED output rather than reading an exit code. -Json emits one
  # finding per line (Severity/Area/Subject/Detail/Remedy), so the report can name the actual
  # failure instead of saying "exit 2, go and read a log".
  #
  # READ-ONLY. vss-check changes nothing, so this runs on every path - not only when SQLBACKUP
  # refuses. Whether YallaCloud owns backup or the incumbent does, a VSS that cannot snapshot
  # means neither of them is taking an application-consistent backup of this machine.
  # Already run this session? Reuse it. vss-check reads the event log and every writer on the
  # box; running it twice for the same answer is a minute of a production machine's time.
  if ($script:Evidence['vss']) { return $script:Evidence['vss'] }
  $o = [ordered]@{ ran=$false; exit=$null; critical=0; warn=0; findings=@()
                   verdict='UNKNOWN'; why='vss-check did not run' }
  $vs = Join-Path $ScriptsDir 'Vss-Check.ps1'
  if (-not (Test-Path -LiteralPath $vs)) { $o.why = 'Vss-Check.ps1 is not in the payload'; return $o }
  $out = Join-Path $env:TEMP ('yc-vss-' + [string](Get-Random) + '.json')
  try {
    $p = Start-Process -FilePath 'powershell.exe' `
           -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$vs,'-Json') `
           -Wait -PassThru -NoNewWindow -RedirectStandardOutput $out -ErrorAction Stop
    $o.ran  = $true
    $o.exit = $p.ExitCode
  } catch {
    $o.why = 'could not run vss-check: ' + $_.Exception.Message
    Remove-Item $out -Force -ErrorAction SilentlyContinue
    return $o
  }
  $rows = @()
  try {
    foreach ($line in @(Get-Content -LiteralPath $out -ErrorAction Stop)) {
      $t = [string]$line
      if (-not $t.Trim().StartsWith('{')) { continue }     # the log lines it also prints
      try { $rows += ($t | ConvertFrom-Json) } catch { }
    }
  } catch { }
  Remove-Item $out -Force -ErrorAction SilentlyContinue
  $o.findings = @($rows | ForEach-Object {
    [ordered]@{ severity=[string]$_.Severity; area=[string]$_.Area
                subject=[string]$_.Subject; detail=[string]$_.Detail; remedy=[string]$_.Remedy } })
  $o.critical = @($o.findings | Where-Object { $_.severity -eq 'CRITICAL' }).Count
  $o.warn     = @($o.findings | Where-Object { $_.severity -eq 'WARN' }).Count

  if ($o.critical -gt 0) {
    $o.verdict = 'BROKEN'
    $o.why = [string]$o.critical + ' CRITICAL VSS finding(s). Snapshot backups of this machine are NOT application-consistent - they succeed and report success while the database inside them is not quiesced.'
  } elseif ($o.warn -gt 0) {
    $o.verdict = 'SUSPECT'
    $o.why = [string]$o.warn + ' VSS warning(s) - correlate them with the backup window before trusting the next backup.'
  } elseif ($o.ran -and $o.exit -eq 0) {
    $o.verdict = 'OK'; $o.why = 'VSS answered and reported no critical finding'
  } elseif ($o.exit -eq 5) {
    # 5 is the payload's "not elevated". The adopt always runs elevated, so this is only reachable
    # when somebody runs the check by hand - but reporting "VSS is unproven" would imply it looked.
    $o.verdict = 'NOT-CHECKED'
    $o.why = 'vss-check could not run: it needs an elevated session (exit 5). VSS health was not checked, not found healthy.'
  } else {
    # Exit code said something but no findings parsed. Say that, rather than inventing a verdict.
    $o.verdict = 'UNPROVEN'
    $o.why = 'vss-check exited ' + [string]$o.exit + ' but no findings could be read back, so VSS health is unproven'
  }
  return $o
}

function Get-ChkdskState {
  # Has this filesystem ever actually been checked, and what did it say?
  #
  # The adopt does NOT run chkdsk: /scan is online and read-only but it reads the whole volume,
  # so it is deferred to YC-IntegrityBaseline outside the window. That makes two things worth
  # reporting HERE and loudly:
  #   1. the DIRTY BIT - Windows has already decided the volume needs repair, and no scan is
  #      needed to know that.
  #   2. what the LAST chkdsk found, from the event log. Windows writes chkdsk output under
  #      Microsoft-Windows-Wininit (event 1001, boot-time autochk) and Chkdsk (26212/26214,
  #      an online scan). Both have existed since 2012R2.
  # And if the baseline task was never registered, nothing will ever run one - which is worth
  # saying out loud rather than leaving as an absence.
  $o = [ordered]@{ dirtyVolumes=@(); unreadable=@(); lastRun=''; lastResult=''; found=@()
                   clean=$false; scanScheduled=$false; verdict='UNPROVEN'; why='' }
  foreach ($v in @($script:Evidence['volumes'])) {
    if ([string]$v.dirty -like 'YES*')          { $o.dirtyVolumes += [string]$v.drive }
    elseif ([string]$v.dirty -eq '(unreadable)'){ $o.unreadable   += [string]$v.drive }
  }
  try {
    $ev = @(Get-WinEvent -FilterHashtable @{ LogName='Application'
                                             ProviderName=@('Microsoft-Windows-Wininit','Chkdsk')
                                             StartTime=(Get-Date).AddDays(-365) } `
              -MaxEvents 20 -ErrorAction Stop | Sort-Object TimeCreated -Descending)
    if ($ev.Count) {
      $o.lastRun = $ev[0].TimeCreated.ToString('yyyy-MM-dd HH:mm:ss')
      $m = [string]$ev[0].Message
      # MATCH THE CLEAN PHRASE FIRST, AND STOP. "Windows has scanned the file system and found no
      # problems" CONTAINS the word "problems", so a loose -match 'problems' reads a perfectly
      # clean chkdsk as a failure. Measured: this reported BAD on a healthy laptop whose last scan
      # was clean. A filesystem check that cries wolf is worth nothing, same as the storage-event
      # collector before it was scoped by provider.
      if ($m -match '(?i)found no problems|no further action is required') {
        $o.clean = $true
        $o.found = @('Windows reported no problems')
      } else {
        foreach ($pat in @('(?i)Windows has made corrections to the file system',
                           '(?i)found problems',
                           '(?i)Errors found',
                           '(?i)corruption was found',
                           '(?i)failed to (scan|check)')) {
          if ($m -match $pat) { $o.found += $Matches[0] }
        }
      }
      $o.lastResult = (($m -split "`r?`n" | Where-Object { $_.Trim() } | Select-Object -First 3) -join ' ')
      if ($o.lastResult.Length -gt 300) { $o.lastResult = $o.lastResult.Substring(0,300) + '...' }
    }
  } catch { }
  try { $o.scanScheduled = [bool](Get-ScheduledTask -TaskName 'YC-DiskScan' -ErrorAction SilentlyContinue) } catch {}

  if ($o.dirtyVolumes.Count) {
    $o.verdict = 'BAD'
    $o.why = 'the NTFS dirty bit is SET on ' + ($o.dirtyVolumes -join ', ') + '. Windows itself has already decided this filesystem needs repair, and it has not been repaired. A backup of a volume in this state copies the damage.'
  } elseif ($o.found.Count -and -not $o.clean) {
    $o.verdict = 'BAD'
    $o.why = 'the last chkdsk on this machine reported a problem on ' + $o.lastRun + ': ' + (($o.found | Select-Object -Unique) -join '; ')
  } elseif ($o.unreadable.Count) {
    $o.verdict = 'UNPROVEN'
    $o.why = 'the dirty bit could not be read on ' + ($o.unreadable -join ', ') + ', so a clean filesystem has not been established'
  } elseif ($o.lastRun -and $o.clean) {
    $o.verdict = 'OK'
    $o.why = 'no dirty bit, and the last chkdsk (' + $o.lastRun + ') reported no problems'
  } elseif ($o.lastRun) {
    # An event exists but says neither "clean" nor anything we recognise as a failure. Saying OK
    # on an unread message would be a claim we cannot support.
    $o.verdict = 'UNPROVEN'
    $o.why = 'no dirty bit, and a chkdsk ran on ' + $o.lastRun + ', but its result could not be read as either clean or failed'
  } else {
    $o.verdict = 'UNPROVEN'
    $o.why = 'no dirty bit, but there is NO RECORD of chkdsk ever running on this machine, so nobody has confirmed the filesystem is sound'
  }
  if (-not $o.scanScheduled -and $o.verdict -ne 'OK') {
    $o.why += ' YC-DiskScan is NOT registered, so no scan will run by itself either.'
  }
  return $o
}

function Get-SqlIntegrityState {
  # The same evidence the report already carries, reduced to one verdict loud enough to see.
  # Reads $script:Evidence rather than re-querying: two code paths asking SQL the same question
  # is how an event and a report come to disagree.
  $o = [ordered]@{ damagedPages=0; firstSeen=''; lastSeen=''; neverChecked=@()
                   weeklyCheckdbWired=$false; verdict='UNPROVEN'; why='' }
  foreach ($e in @($script:Evidence['sql'])) {
    try {
      $o.damagedPages += [int]$e.suspectPages.totalPages
      if ($e.suspectPages.earliest -and (-not $o.firstSeen -or $e.suspectPages.earliest -lt $o.firstSeen)) { $o.firstSeen = [string]$e.suspectPages.earliest }
      if ($e.suspectPages.latest   -and ($e.suspectPages.latest -gt $o.lastSeen)) { $o.lastSeen = [string]$e.suspectPages.latest }
    } catch { }
  }
  $o.neverChecked = @($script:Evidence['lastKnownGood'] | Where-Object { $_.neverChecked } | ForEach-Object { [string]$_.database })
  try { $o.weeklyCheckdbWired = [bool](Get-ScheduledTask -TaskName 'YC-SqlIntegrity' -ErrorAction SilentlyContinue) } catch {}

  if ($o.damagedPages -gt 0) {
    $o.verdict = 'BAD'
    $o.why = [string]$o.damagedPages + ' damaged page(s) on record, first seen ' + $o.firstSeen + ', most recent ' + $o.lastSeen + '. SQL Server wrote those dates itself.'
    # The dates are the point. If the most recent is close to now, this is not a historical scar.
    if ($o.lastSeen -and $o.firstSeen -and $o.lastSeen -ne $o.firstSeen) {
      $o.why += ' The damage is STILL BEING FOUND - the newest entry is not the oldest, so this is ongoing, not a one-off that has already settled.'
    }
  } elseif ($o.neverChecked.Count) {
    $o.verdict = 'UNPROVEN'
    $o.why = [string]$o.neverChecked.Count + ' database(s) have NEVER had a CHECKDB complete cleanly, on this platform or the one before it, so nobody has ever confirmed they are undamaged: ' + (($o.neverChecked | Select-Object -First 6) -join ', ') + $(if ($o.neverChecked.Count -gt 6) { ', ...' } else { '' })
  } else {
    $o.verdict = 'OK'
    $o.why = 'no damaged pages on record and every database has passed a consistency check'
  }
  return $o
}

function Invoke-DataAndBackupCheck {
  # One pass, one banner, three answers. Runs late enough that the tasks it reports on have
  # already been registered (or refused), so what it says is what the machine will actually do.
  $vss  = Get-VssState
  $disk = Get-ChkdskState
  $sql  = Get-SqlIntegrityState
  $script:Evidence['vss']          = $vss
  $script:Evidence['chkdsk']       = $disk
  $script:Evidence['sqlIntegrity'] = $sql

  $loud = @(); $detail = @()

  if ($sql.verdict -eq 'BAD') {
    $loud += ('SQL DATA IS DAMAGED: ' + $sql.why)
    Flag 'DATA' ('SQL integrity: ' + $sql.why)
    if (-not $sql.weeklyCheckdbWired) {
      $detail += 'The weekly FULL CHECKDB is deliberately NOT scheduled on a damaged instance. Run it by hand in a change window:  yc-integrity -Sql Full'
    }
  } elseif ($sql.verdict -eq 'UNPROVEN') {
    $loud += ('SQL DATA IS UNPROVEN: ' + $sql.why)
    Flag 'DATA' ('SQL integrity: ' + $sql.why)
  }

  if ($disk.verdict -eq 'BAD') {
    $loud += ('FILESYSTEM: ' + $disk.why)
    Flag 'DATA' ('chkdsk/filesystem: ' + $disk.why)
    $detail += 'Repair is NOT done here - chkdsk /f dismounts the volume. Schedule it in a change window:  boot-repair -ScheduleChkdsk'
  } elseif ($disk.verdict -eq 'UNPROVEN') {
    $loud += ('FILESYSTEM UNPROVEN: ' + $disk.why)
    Flag 'DATA' ('chkdsk/filesystem: ' + $disk.why)
  }

  if ($vss.verdict -eq 'BROKEN') {
    $loud += ('BACKUPS ARE NOT APPLICATION-CONSISTENT: ' + $vss.why)
    Flag 'DATA' ('VSS: ' + $vss.why)
    foreach ($f in @($vss.findings | Where-Object { $_.severity -eq 'CRITICAL' })) {
      $detail += ('VSS ' + $f.area + ' - ' + $f.subject + ': ' + $f.detail)
    }
  } elseif ($vss.verdict -in @('SUSPECT','UNPROVEN','NOT-CHECKED')) {
    $loud += ('BACKUP PATH: ' + $vss.why)
    Flag 'DATA' ('VSS: ' + $vss.why)
  }

  if ($loud.Count) {
    # The sentence that ties them together. Any one of these alone is a problem; together they
    # are the situation where the data is damaged AND there is no good copy of it.
    if ($sql.verdict -eq 'BAD' -and $vss.verdict -eq 'BROKEN') {
      $detail += 'READ THIS TOGETHER: the data is damaged AND the backups of it are not application-consistent. There may be no clean copy of this database anywhere.'
    }
    Write-LoudBanner -Title 'ATTENTION - DATA AND BACKUP' -Lines $loud -Detail $detail
    return 3
  }
  L ('data and backup: SQL ' + $sql.verdict + ', filesystem ' + $disk.verdict + ', VSS ' + $vss.verdict) 'OK'
  return 0
}

# ================================================================================================
# PHASE 6 - NIC.  Ghost NICs only, and only through set-nic, which carries the deadman rollback.
# No addressing change is made here: a network change on a production VM you cannot redeploy is
# exactly the thing a human should be holding the console for.
# ================================================================================================
function Invoke-Nic {
  param($Survey)
  $ghosts = 0
  try { $ghosts = [int]$Survey.data.network.hiddenAdapterCount } catch {}
  if ($ghosts -le 0) { L 'no hidden network adapters found - nothing to clean.' 'OK'; return 0 }
  L ([string]$ghosts + ' hidden network adapter(s) present - these hold the old static IP after a MAC change.') 'WARN'
  $code = Invoke-YcCommand -Script 'Set-Nic.ps1' -Arguments @('-CleanGhosts') -Phase 'NIC'
  if ($null -eq $code -or $code -ne 0) { return 3 }
  return 0
}

# ================================================================================================
# PHASE - SQLPREP.  The refusing gate. Nothing SQL happens until all of this is true.
#
# WHY A GATE AND NOT A WARNING
#   Every scheduled task this script registers runs as a Windows identity. On a FRESH build
#   Install-Sql grants that identity sysadmin as part of the build. A migrated instance was built
#   by somebody else, so the grant does not exist - and a backup task without sysadmin does not
#   error loudly, it just fails at 02:15 every night forever. The only symptom is an ABSENCE, and
#   nobody notices an absence. That is why this refuses instead of warning.
#
# WHY chadmin AND NOT SYSTEM
#   NT AUTHORITY\SYSTEM maps to EVERY service running as LocalSystem on the host, so making it
#   sysadmin hands that role to everything on the box. chadmin is one named account we control,
#   and it keeps every log line and every event attributable to a real account.
#
# The T-SQL below is lifted verbatim in shape from Install-Sql.ps1 (the sysadmin test and the
# CREATE LOGIN / ALTER SERVER ROLE fix), so a migrated instance ends up configured exactly the
# same way a fresh one is.
# ================================================================================================
function Invoke-SqlPrep {
  param($Survey)
  $inst = @()
  try { $inst = @($Survey.data.sql | Where-Object { $_.status -eq 'Running' }) } catch {}
  if ($inst.Count -eq 0) { L 'no running SQL Server instance - SQLPREP has nothing to gate.' 'OK'; return 0 }

  $chadmin = (Get-HostNameSafe) + '\chadmin'
  $script:ChadminLogin = $chadmin

  # --- the Windows account ---------------------------------------------------------------------
  $acct = Get-LocalUserSafe -Name 'chadmin'
  if (-not $acct) {
    L 'chadmin does not exist on this guest - creating it (owner decision D8).' 'WARN'
    if (-not (New-ChadminAccount)) { L 'chadmin could not be created, so no SQL task can be registered.' 'ERROR'; return 2 }
  } else {
    L 'chadmin already exists on this guest.' 'OK'
    if ($acct.Enabled -eq $false) {
      Flag 'SQLPREP' 'chadmin exists but is DISABLED. A disabled account cannot run a scheduled task.'
      return 2
    }
  }
  if (-not (Test-LocalAdminMember -Name 'chadmin')) {
    try { Add-LocalGroupMember -Group 'Administrators' -Member 'chadmin' -ErrorAction Stop
          L 'chadmin added to the local Administrators group.' 'OK' }
    catch { Flag 'SQLPREP' ('chadmin is not a local administrator and could not be added: ' + $_.Exception.Message); return 2 }
  }

  # --- per instance: reachable, chadmin sysadmin, disk ------------------------------------------
  foreach ($i in $inst) {
    $t = $(if ($i.instance -eq 'MSSQLSERVER') { '.' } else { '.\' + $i.instance })

    $probe = Invoke-SqlCmdLocal -Target $t -Query 'SELECT 1'
    if (-not $probe) {
      Flag 'SQLPREP' ($i.instance + ': cannot be reached with Windows authentication as the account running this script. Nothing SQL can be done here.')
      return 2
    }
    L ($i.instance + ': reachable') 'OK'

    $q = "SET NOCOUNT ON; SELECT ISNULL(CONVERT(varchar(3),IS_SRVROLEMEMBER('sysadmin', N'" + ($chadmin -replace "'","''") + "')),'NULL')"
    $r = Invoke-SqlCmdLocal -Target $t -Query $q
    if ($r -and $r.Trim() -eq '1') {
      L ($i.instance + ': ' + $chadmin + ' is already sysadmin') 'OK'
    } else {
      L ($i.instance + ': granting sysadmin to ' + $chadmin) 'WARN'
      $fix = "IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'" + ($chadmin -replace "'","''") + "') CREATE LOGIN [" + $chadmin + "] FROM WINDOWS; " +
             "IF NOT EXISTS (SELECT 1 FROM sys.server_role_members rm JOIN sys.server_principals r ON rm.role_principal_id = r.principal_id " +
             "JOIN sys.server_principals m ON rm.member_principal_id = m.principal_id WHERE r.name = 'sysadmin' AND m.name = N'" + ($chadmin -replace "'","''") + "') " +
             "ALTER SERVER ROLE sysadmin ADD MEMBER [" + $chadmin + "];"
      Invoke-SqlCmdLocal -Target $t -Query $fix | Out-Null
      # Read it back. A grant that did not take is worse than no grant, because we would proceed.
      $r2 = Invoke-SqlCmdLocal -Target $t -Query $q
      if ($r2 -and $r2.Trim() -eq '1') { L ($i.instance + ': sysadmin granted and confirmed') 'OK' }
      else { Flag 'SQLPREP' ($i.instance + ': could not make ' + $chadmin + ' sysadmin. Every SQL task would fail silently, so none is registered.'); return 2 }
    }

    # Disk. CHECKDB builds an internal snapshot on the SAME volume as the data file, and a backup
    # needs somewhere to land. A check that fills a production volume causes the outage it exists
    # to prevent.
    $vols = Invoke-SqlCmdLocal -Target $t -Query "SET NOCOUNT ON; SELECT DISTINCT LEFT(physical_name,1) FROM sys.master_files;"
    foreach ($letter in @(([string]$vols) -split "`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ })) {
      $free = $null
      try { $free = [math]::Round((Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $letter + ":'") -ErrorAction Stop).FreeSpace/1GB,1) } catch {}
      if ($null -eq $free) { continue }
      if ($free -lt $MinFreeGB) {
        Flag 'SQLPREP' ($letter + ': holds SQL files and has only ' + [string]$free + ' GB free, below the ' + [string]$MinFreeGB + ' GB floor. CHECKDB snapshots here and a backup lands here.')
      } else { L ($letter + ': ' + [string]$free + ' GB free') 'OK' }
    }
  }

  # --- S4U, proven with a throwaway task --------------------------------------------------------
  # "Registered without error" is not "it can log on". A task that cannot log on never runs, and
  # finding that out in two seconds here beats finding it out as six weeks of missing backups.
  $script:UseS4U = Test-S4ULogon -User $chadmin
  if ($script:UseS4U) { L ('S4U logon works for ' + $chadmin + ' - tasks will run passwordless as chadmin.') 'OK' }
  elseif ($ChadminPassword) { L 'S4U was refused; the stored credential from -ChadminPassword will be used instead.' 'WARN' }
  else {
    # Blaming the host sends somebody hunting a policy problem that does not exist. If this
    # process is SYSTEM, that is the cause, and it is ours - not the host's.
    $amSystem = $false
    try { $amSystem = ([Security.Principal.WindowsIdentity]::GetCurrent()).IsSystem } catch {}
    if ($amSystem) {
      Flag 'SQLPREP' ('S4U could not be used for ' + $chadmin + ' because THIS PROCESS IS RUNNING AS SYSTEM, and SYSTEM is not allowed to register an S4U task for another account. This is not a problem with the host. Re-run  migrated-vm -Run  from an elevated session as chadmin and the tasks will register.')
      return 2
    }
    Flag 'SQLPREP' ('S4U logon is REFUSED for ' + $chadmin + ' on this host, and no -ChadminPassword was given. ' +
                    $(if ($script:ChadminCreated) { 'chadmin was created by this run with a password nobody knows, so re-run with -ChadminPassword <pw> - that resets the account to that value. ' } else { '' }) +
                    'No SQL task is registered: a task that cannot log on would fail silently forever.')
    return 2
  }
  return 0
}

# SQLPREP proves the task identity into SCRIPT scope, and script scope does not survive a new
# process. Any run that does phases in separate invocations - the staged harness, a resume after a
# reboot, an operator typing -Only SQLMAINT - would refuse with "SQLPREP did not run" and never
# reach the gate that was supposed to decide. SQLPREP is idempotent: every step is check, then fix,
# then read back. So the honest fix is to RUN it, not to trust a stale note that it once passed.
function Assert-TaskIdentity {
  param($Survey,[string]$Phase)
  if ($script:ChadminLogin) { return 0 }
  L ('no proven task identity in this process - running SQLPREP first so ' + $Phase + ' can decide on evidence.') 'WARN'
  return (Invoke-SqlPrep -Survey $Survey)
}

function Get-LocalUserSafe {
  param([string]$Name)
  # Get-LocalUser does not exist on Server 2016 without the LocalAccounts module, so fall back to
  # WMI rather than assuming a cmdlet that is missing on a third of the estate.
  try { return (Get-LocalUser -Name $Name -ErrorAction Stop) } catch {}
  try {
    $u = Get-CimInstance Win32_UserAccount -Filter ("LocalAccount=TRUE AND Name='" + $Name + "'") -ErrorAction Stop
    if ($u) { return [pscustomobject]@{ Name=$u.Name; Enabled=(-not $u.Disabled) } }
  } catch {}
  return $null
}

function Test-LocalAdminMember {
  param([string]$Name)
  try {
    $members = @(Get-LocalGroupMember -Group 'Administrators' -ErrorAction Stop | ForEach-Object { $_.Name })
    return [bool](@($members | Where-Object { $_ -match ('\\' + [regex]::Escape($Name) + '$') }).Count)
  } catch {}
  try { return (((net localgroup Administrators) -join "`n") -match ('(?im)^\s*' + [regex]::Escape($Name) + '\s*$')) } catch { return $false }
}

function New-ChadminAccount {
  # The password is generated, used once by Windows to create the account, and never written to
  # the log, the state file, the repo or any document. S4U is passwordless, so nothing needs it
  # again. If S4U is refused the operator supplies -ChadminPassword, which RESETS the account.
  $pw = New-HousePassword
  if (-not $pw) { Flag 'SQLPREP' 'could not generate a password for chadmin.'; return $false }
  try {
    $sec = ConvertTo-SecureString $pw -AsPlainText -Force
    try { New-LocalUser -Name 'chadmin' -Password $sec -FullName 'YallaCloud maintenance' `
            -Description 'YallaCloud day-2 maintenance account. Scheduled tasks run as this account.' `
            -PasswordNeverExpires -ErrorAction Stop | Out-Null }
    catch { & net.exe user chadmin $pw /add /comment:"YallaCloud day-2 maintenance account" /expires:never | Out-Null
            # NOT wmic: it is deprecated and disabled by default on Server 2025, so the fallback
            # would itself fail on the newest OS. Win32_UserAccount.PasswordExpires is write=True
            # and its MappingStrings name UF_DONT_EXPIRE_PASSWD - the same USER_INFO_2 flag wmic set.
            try { $ua = Get-CimInstance Win32_UserAccount -Filter "Name='chadmin' AND LocalAccount=TRUE" -ErrorAction Stop
                  if ($ua) { Set-CimInstance -InputObject $ua -Property @{ PasswordExpires = $false } -ErrorAction Stop } }
            catch { L ('created chadmin via net.exe, but could not clear password expiry: ' + $_.Exception.Message) 'WARN' } }
    Remove-Variable pw -ErrorAction SilentlyContinue
    if (Get-LocalUserSafe -Name 'chadmin') {
      $script:ChadminCreated = $true
      L 'chadmin created. The password was generated, used once and never recorded - S4U needs none.' 'OK'
      return $true
    }
    Flag 'SQLPREP' 'chadmin creation reported success but the account is not there.'
    return $false
  } catch { Flag 'SQLPREP' ('could not create chadmin: ' + $_.Exception.Message); return $false }
  finally { Remove-Variable pw -ErrorAction SilentlyContinue }
}

function New-HousePassword {
  # passgen is the single source of the house password rule. Use it when it is there rather than
  # inventing a second generator that drifts from the first.
  $pg = Join-Path $ScriptsDir 'PassGen.ps1'
  if (Test-Path -LiteralPath $pg) {
    try {
      $out = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $pg 2>&1
      $cand = @($out | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ -match '^[A-Za-z0-9#]{8,16}$' })
      if ($cand.Count) { return $cand[0] }
    } catch {}
  }
  # Fallback to the same rule passgen enforces: first A-Z, last a-z, at least two #, a digit,
  # # the only symbol, and no O/0/I/l so nobody mistypes it over the phone.
  #
  # CRYPTO RNG, NOT System.Random. MEASURED: New-Object Random is seeded from the system clock,
  # so a fresh instance created inside this function on successive calls gets the SAME SEED and
  # returns the SAME PASSWORD - 200 generations produced long runs of one identical value. For a
  # local administrator account that is a security defect, not a cosmetic one.
  $U='ABCDEFGHJKLMNPQRSTUVWXYZ'; $Lw='abcdefghijkmnpqrstuvwxyz'; $D='23456789'
  $rng = $null
  try {
    $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
    function Next-Int { param([int]$Max)
      $b = New-Object byte[] 4
      do { $rng.GetBytes($b); $v = [BitConverter]::ToUInt32($b,0) } while ($v -ge ([uint32]::MaxValue - ([uint32]::MaxValue % $Max)))
      return [int]($v % $Max)
    }
    # REJECTION SAMPLING. The two '#' are placed at random positions and can land on the digit,
    # leaving a candidate with no digit at all - MEASURED at roughly 1 in 300. Returning $null
    # there would fail the whole chadmin creation for no reason, so generate again instead.
    foreach ($attempt in 1..40) {
      $pool = $U + $Lw + $D
      $mid = @(); foreach ($n in 1..11) { $mid += $pool[(Next-Int $pool.Length)] }
      $mid[(Next-Int $mid.Count)] = '#'
      $mid[(Next-Int $mid.Count)] = '#'
      $mid[(Next-Int $mid.Count)] = $D[(Next-Int $D.Length)]
      # Fisher-Yates, so the two # and the digit do not sit in predictable places.
      for ($k = $mid.Count - 1; $k -gt 0; $k--) { $j = Next-Int ($k+1); $tmp=$mid[$k]; $mid[$k]=$mid[$j]; $mid[$j]=$tmp }
      $out = $U[(Next-Int $U.Length)] + ($mid -join '') + '#' + $Lw[(Next-Int $Lw.Length)]
      # Prove it against the rule before returning it. A generator nobody checks is a generator
      # that quietly stops meeting the rule.
      if ($out.Length -lt 8 -or $out.Length -gt 16) { continue }
      if ($out[0] -cnotmatch '[A-Z]' -or $out[-1] -cnotmatch '[a-z]') { continue }
      if (([regex]::Matches($out,'#')).Count -lt 2) { continue }
      if ($out -cnotmatch '[2-9]') { continue }
      if ($out -cmatch '[O0Il]') { continue }
      if ($out -cmatch '[^A-Za-z0-9#]') { continue }
      return $out
    }
    return $null
  } finally { if ($rng) { try { $rng.Dispose() } catch {} } }
}

function Test-S4ULogon {
  param([string]$User)
  $name = 'YC-S4U-Probe'
  try {
    $act = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument '/c exit 0'
    $trg = New-ScheduledTaskTrigger -Once -At ((Get-Date).AddYears(10))
    $pri = New-ScheduledTaskPrincipal -UserId $User -LogonType S4U -RunLevel Highest -ErrorAction Stop
    Register-ScheduledTask -TaskName $name -Action $act -Trigger $trg -Principal $pri -Force -ErrorAction Stop | Out-Null
    $ok = [bool](Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue)
    return $ok
  } catch {
    L ('S4U probe refused: ' + $_.Exception.Message) 'WARN'
    return $false
  } finally {
    try { Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue } catch {}
  }
}

# One place that builds the task principal, so every task this script registers gets the same
# identity and nothing silently falls back to SYSTEM.
function New-YcTaskPrincipal {
  if ($script:UseS4U) {
    return (New-ScheduledTaskPrincipal -UserId $script:ChadminLogin -LogonType S4U -RunLevel Highest)
  }
  return $null   # caller uses -User/-Password with $ChadminPassword
}

# ================================================================================================
# PHASE 7 - SQL.  Discover and REPORT. Nothing is installed, nothing is licensed, nothing is
# changed. install-sql is structurally unreachable from this file for a reason.
# ================================================================================================
function Invoke-Sql {
  param($Survey)
  $inst = @()
  try { $inst = @($Survey.data.sql) } catch {}
  if ($inst.Count -eq 0) { L 'no SQL Server instance found on this host.' 'OK'; return 0 }

  foreach ($i in $inst) {
    $ed  = $(if ($i.liveEdition) { $i.liveEdition } else { $i.edition })
    $ver = $(if ($i.liveVersion) { $i.liveVersion } else { $i.version })
    L ('SQL instance ' + $i.instance + '  edition=' + $ed + '  version=' + $ver +
       '  patch=' + $i.patchlevel + '  service=' + $i.status)
    L ('   product key: ' + $i.partialProductKey)
    if ($i.isEvaluation) {
      Flag 'SQL' ($i.instance + ' is running an EVALUATION edition. It will stop accepting connections when the period ends. Licensing a migrated customer instance is a commercial decision - raise it, do not automate it.')
    }
    if ($i.isExpress) {
      L ('   ' + $i.instance + ' is Express: 10 GB per database, 1410 MB buffer pool, no backup compression, no SQL Agent.') 'WARN'
    }
    $dbs = @($i.databases)
    L ('   ' + [string]$dbs.Count + ' user database(s)')
    foreach ($d in $dbs) { L ('     ' + $d.name + '  recovery=' + $d.recovery + '  size=' + $d.sizeMB + ' MB') }
  }
  # licence-report is the house authority on licensing and prints no key. Run it so the JSON lands
  # beside everything else rather than re-deriving any of it here.
  $out = Join-Path $ScriptsDir 'survey\licence-report.json'
  Invoke-YcCommand -Script 'Licence-Report.ps1' -Arguments @('-Format','Json','-Path',$out) -Phase 'SQL' | Out-Null
  return 0
}

# ================================================================================================
# PHASE - BASELINE.  The provenance record: baseline_beforemigration.log
#
# This is the file that answers "did the rot come WITH this VM, or did it appear on our
# infrastructure afterwards?" - which is a commercial question as much as a technical one. It is
# captured BEFORE anything is changed and its header says so.
#
# IT ONLY DOES THE INSTANT CHECKS. Owner constraint: nobody babysits a migration for more than
# about thirty minutes, and downtime windows are limited. chkdsk /scan on a large volume and a
# full DBCC CHECKDB on a large database both take as long as they take, so they are handed to a
# ONE-OFF task that runs right after the adopt and APPENDS its findings to this same file.
# ================================================================================================
# ================================================================================================
# THE EVIDENCE COLLECTOR.
#
# This exists for ONE argument, and it is a commercial argument, not a technical one:
#
#   The customer's database was already damaged on the source platform. The damage travelled with
#   the VM, because a migration copies blocks faithfully - including the broken ones. After the
#   move the customer sees errors and says the migration caused them. We have to be able to show
#   that it did not.
#
# A COUNT CANNOT WIN THAT ARGUMENT. "33 damaged pages" says nothing about when they appeared.
# DATES win it, and the dates we want were not written by us:
#
#   msdb.dbo.suspect_pages.last_update_date   written by SQL Server, on the SOURCE platform
#   Application log events 823 / 824 / 825    written by Windows, on the SOURCE platform
#   dbi_dbccLastKnownGood                     the last time CHECKDB passed - often years ago
#   page_verify as received                   NONE or TORN_PAGE means damage was UNDETECTABLE,
#                                             so it could have been accumulating unseen for years
#
# Every one of those is Microsoft's own record, timestamped before this script ever ran. Our job
# is to capture them before we change anything, and to say plainly what they mean.
#
# The comparison needs an anchor, so the baseline also records when this machine arrived and when
# we first touched it. Evidence dated BEFORE that anchor is evidence we did not cause.
# ================================================================================================
function Get-SqlDamageEvidence {
  param([string]$Target)
  $ev = [ordered]@{ rows=@(); totalPages=0; earliest=''; latest=''; capped=$false }

  # Per database, with dates. GROUP BY database_id because a dropped database still has rows and
  # DB_NAME then returns NULL - which is itself evidence, so it is kept rather than filtered out.
  $q = "SET NOCOUNT ON; SELECT CONVERT(varchar(10),database_id) + '|' + " +
       "ISNULL(CONVERT(varchar(128),DB_NAME(database_id)) COLLATE DATABASE_DEFAULT,'(dropped)') + '|' + " +
       "CONVERT(varchar(10),COUNT(*)) + '|' + " +
       "ISNULL(CONVERT(varchar(30),MIN(last_update_date),120),'?') + '|' + " +
       "ISNULL(CONVERT(varchar(30),MAX(last_update_date),120),'?') + '|' + " +
       "CONVERT(varchar(10),MAX(error_count)) " +
       "FROM msdb.dbo.suspect_pages WHERE event_type IN (1,2,3) GROUP BY database_id;"
  $r = Invoke-SqlCmdLocal -Target $Target -Query $q
  foreach ($line in @(([string]$r) -split "`n" | Where-Object { $_ -match '\|' })) {
    $f = $line -split '\|'
    if ($f.Count -lt 6) { continue }
    $n = 0; [void][int]::TryParse(($f[2] -replace '[^0-9]',''), [ref]$n)
    $ev.rows += [ordered]@{ databaseId=$f[0].Trim(); database=$f[1].Trim(); pages=$n
                            firstSeen=$f[3].Trim(); lastSeen=$f[4].Trim(); maxErrors=$f[5].Trim() }
    $ev.totalPages += $n
    foreach ($d in @($f[3].Trim(), $f[4].Trim())) {
      if ($d -and $d -ne '?') {
        if ((-not $ev.earliest) -or ($d -lt $ev.earliest)) { $ev.earliest = $d }
        if ((-not $ev.latest)   -or ($d -gt $ev.latest))   { $ev.latest   = $d }
      }
    }
  }
  # 1000 is the table's hard cap. A full table means the real number is unknown and larger, and
  # the EARLIEST date is then also unreliable - SQL stopped recording, it did not stop happening.
  if ($ev.totalPages -ge 1000) { $ev.capped = $true }
  return $ev
}

function Get-SqlLastKnownGood {
  # When did CHECKDB last pass on this database? Read from the boot page, instant. A date years
  # old, or none at all, says nobody was checking - so damage could have sat unseen for that long.
  param([string]$Target,[string[]]$Databases)
  $out = @()
  foreach ($db in $Databases) {
    if (-not $db) { continue }
    $esc = $db -replace ']', ']]'
    $q = "SET NOCOUNT ON; CREATE TABLE #d(ParentObject varchar(255),Object varchar(255),Field varchar(255),Value varchar(255)); " +
         "INSERT #d EXEC('DBCC DBINFO([" + $esc + "]) WITH TABLERESULTS, NO_INFOMSGS'); " +
         "SELECT TOP 1 LTRIM(RTRIM(Value)) FROM #d WHERE Field = 'dbi_dbccLastKnownGood'; DROP TABLE #d;"
    $v = Invoke-SqlCmdLocal -Target $Target -Query $q -TimeoutSec 20
    $t = ([string]$v).Trim()
    if (-not $t) { $t = '(unreadable)' }
    # SQL writes 1900-01-01 when CHECKDB has never completed cleanly on this database.
    $never = ($t -like '1900-01-01*')
    $out += [ordered]@{ database=$db; lastKnownGood=$t; neverChecked=$never }
  }
  return $out
}

function Group-StorageEvidence {
  param($Events, [switch]$ByProvider)
  $rows = @()
  $g = if ($ByProvider) { $Events | Group-Object ProviderName,Id,LevelDisplayName } else { $Events | Group-Object Id }
  foreach ($grp in @($g)) {
    $times = @($grp.Group | ForEach-Object { $_.TimeCreated } | Sort-Object)
    $one   = @($grp.Group)[0]
    $rows += [ordered]@{
      provider = [string]$one.ProviderName
      id       = [int]$one.Id
      level    = [string]$one.LevelDisplayName
      count    = $grp.Count
      first    = $times[0].ToString('yyyy-MM-dd HH:mm:ss')
      last     = $times[-1].ToString('yyyy-MM-dd HH:mm:ss')
    }
  }
  return @($rows | Sort-Object { $_.provider }, { $_.id })
}

function Get-StorageErrorEvidence {
  # Windows' own record of IO trouble, with dates. NOT a SMART read: this is a virtual volume on a
  # hypervisor, so physical-disk health has no meaning here and asking for it would produce a
  # confident answer about hardware that does not exist.
  #
  # Scoped BY PROVIDER, never by event id alone. Ids 7, 9, 11, 15, 55, 98 and friends are reused by
  # unrelated components: measured on a healthy machine, a bare id filter returned 1688 "disk
  # errors", of which 248 were Kerberos id 11 and most of the rest were not storage at all. A
  # liability document that cries wolf on a healthy machine is worth nothing in a dispute, so every
  # row below is attributed to the component that logged it.
  #
  # ProviderName in a FilterHashtable is VALIDATED against the providers registered on the machine
  # and THROWS on the first name it does not know (measured: 'vioscsi' on a non-virtio guest). A
  # throw inside the catch would return silent zero evidence - the worst outcome this function has -
  # so the list is resolved against the machine first and only names that exist are queried.
  $out = [ordered]@{ sql=@(); storage=@(); corruption=@(); windowDays=365; capped=$false
                     providersQueried=@(); providersAbsent=@() }
  $since = (Get-Date).AddDays(-365)

  # Ids that mean "the data on this volume is damaged", per provider. Everything a storage provider
  # logs is still recorded in .storage below, but only these drive the verdict: Volsnap 36 ("shadow
  # copies aborted, low disk space") appeared 89 times on a machine with no corruption at all.
  $corruptIds = @{
    # keys are matched case-insensitively, like every PowerShell hash literal - which is also why
    # 'disk' and 'Disk' cannot both appear here: the parser rejects the duplicate outright.
    'disk'=@(7,11,52,153)
    'Ntfs'=@(55,98,130,131,137,140); 'Microsoft-Windows-Ntfs'=@(55,98,130,131,137,140)
    'volmgr'=@(46,49,161,162); 'partmgr'=@(58)
    'storahci'=@(129,153); 'stornvme'=@(129,153); 'vioscsi'=@(129,153); 'viostor'=@(129,153)
    'pvscsi'=@(129,153);   'vmscsi'=@(129,153);   'LSI_SAS'=@(129,153); 'LSI_SAS3'=@(129,153)
    'iaStorA'=@(129,153);  'amdsata'=@(129,153);  'msdsm'=@(129,153);   'mpio'=@(16,17,32)
  }

  # --- SQL side: the Application log, where SQL Server records its own IO failures --------------
  try {
    $e = @(Get-WinEvent -FilterHashtable @{ LogName='Application'
                                            Id=@(823,824,825,3313,3314,3414,17053)
                                            StartTime=$since } -MaxEvents 2000 -ErrorAction Stop)
    if ($e.Count -ge 2000) { $out.capped = $true }
    $out.sql = @(Group-StorageEvidence -Events $e)
  } catch { }   # no matching events is the normal case, and is not an error

  # --- storage side: the System log, provider-scoped --------------------------------------------
  # Provider names resolve case-insensitively, so each component is named once.
  $want = @('disk','Ntfs','Microsoft-Windows-Ntfs','volmgr','partmgr','volsnap',
            'storahci','stornvme','vioscsi','viostor','pvscsi','vmscsi','LSI_SAS','LSI_SAS3',
            'iaStorA','amdsata','msdsm','mpio','Microsoft-Windows-StorPort','EhStorClass',
            'UASPStor','ScsiPort')
  $have = @()
  foreach ($p in $want) {
    if (Get-WinEvent -ListProvider $p -ErrorAction SilentlyContinue) { $have += $p }
    else { $out.providersAbsent += $p }
  }
  $out.providersQueried = $have
  if ($have.Count) {
    try {
      $e = @(Get-WinEvent -FilterHashtable @{ LogName='System'; ProviderName=$have; Level=1,2,3
                                              StartTime=$since } -MaxEvents 2000 -ErrorAction Stop)
      if ($e.Count -ge 2000) { $out.capped = $true }
      $out.storage    = @(Group-StorageEvidence -Events $e -ByProvider)
      $bad            = @($e | Where-Object { $i = $corruptIds[[string]$_.ProviderName]; $i -and ($i -contains [int]$_.Id) })
      $out.corruption = @(Group-StorageEvidence -Events $bad -ByProvider)
    } catch { }
  }
  return $out
}
function Invoke-Baseline {
  param($Survey)
  $path = Join-Path $ScriptsDir 'baseline_beforemigration.log'
  $json = Join-Path $ScriptsDir 'baseline_beforemigration.json'
  $h    = Get-HostNameSafe
  $now  = (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss') + ' UTC'

  $b = New-Object System.Collections.Generic.List[string]
  $null = $b.Add('================================================================================')
  $null = $b.Add('  YALLACLOUD - BASELINE, STATE AS RECEIVED')
  $null = $b.Add('================================================================================')
  $null = $b.Add('  host            : ' + $h)
  $null = $b.Add('  captured        : ' + $now)
  $null = $b.Add('  payload         : ' + (Get-PayloadVersion))
  $null = $b.Add('')
  $null = $b.Add('  This is the state of this machine AS RECEIVED from the source platform.')
  $null = $b.Add('  Nothing had been changed by YallaCloud when these values were read.')
  $null = $b.Add('  Anything reported as a problem here ARRIVED WITH THE VM - it was not')
  $null = $b.Add('  caused by the migration target or by this toolkit.')
  $null = $b.Add('')

  # --- identity -------------------------------------------------------------------------------
  $null = $b.Add('--- IDENTITY -------------------------------------------------------------------')
  try {
    $null = $b.Add('  os              : ' + $Survey.data.identity.caption + '  build ' + $Survey.data.identity.build)
    $null = $b.Add('  firmware        : ' + $Survey.data.identity.firmware)
    $null = $b.Add('  domain          : ' + $Survey.data.identity.domain + '  (joined: ' + $Survey.data.identity.partOfDomain + ')')
    $null = $b.Add('  memory          : ' + [string]$Survey.data.identity.memoryGB + ' GB')
  } catch {}
  $null = $b.Add('')

  # --- virtio ----------------------------------------------------------------------------------
  # A migrated guest on an old virtio storage driver is exposed to known IO race conditions. We
  # REPORT the version; we never swap a storage driver, because that is a reboot and a risk of
  # its own and it belongs in a change window.
  $null = $b.Add('--- PLATFORM AND GUEST TOOLING, AS RECEIVED ------------------------------------')
  $pl = $script:Evidence['platform']
  if (-not $pl) { $pl = Get-PlatformToolingState; $script:Evidence['platform'] = $pl }
  $null = $b.Add('  hypervisor      : ' + $pl.platform + '  (' + $pl.platformWhy + ')')
  $null = $b.Add('  manufacturer    : ' + $pl.manufacturer)
  $null = $b.Add('  model           : ' + $pl.model)
  $null = $b.Add('  bios            : ' + $pl.bios)
  $null = $b.Add('  expected agent  : ' + $pl.expectedAgent)
  $null = $b.Add('')
  $ag = $pl.agent
  $null = $b.Add('  GUEST AGENT (' + $ag.agent + ')')
  $null = $b.Add('    installed     : ' + [string]$ag.installed)
  $null = $b.Add('    service       : ' + $(if ($ag.service) { $ag.service } else { '(none)' }))
  $null = $b.Add('    status        : ' + $ag.status + $(if ($ag.startType) { '  (start type ' + $ag.startType + ')' } else { '' }))
  if ($ag.version)    { $null = $b.Add('    version       : ' + $ag.version) }
  if ($ag.pinPackage) { $null = $b.Add('    pinned        : ' + $ag.pinPackage + '  (' + $ag.pinTrack + ' track, from ' + $ag.pinSource + ' - ' + $ag.pinReason + ')')
                        $null = $b.Add('    vs the pin    : ' + $ag.versusPin) }
  if (@($ag.drivers).Count) { $null = $b.Add('    drivers       : ' + (@($ag.drivers) -join ', ')) }
  $null = $b.Add('    verdict       : ' + $ag.verdict + ' - ' + $ag.why)
  $null = $b.Add('')
  $vs = $pl.virtio
  $null = $b.Add('  VIRTIO DRIVERS')
  if ($pl.platform -ne 'KVM') {
    $null = $b.Add('    ' + $vs.why)
    foreach ($r in @($vs.drivers)) { $null = $b.Add(('    {0,-10} {1,-22} (inert on this platform)' -f $r.driver, $r.fileVersion)) }
  } else {
    $null = $b.Add('    pinned        : virtio-win ' + $vs.pinPackage + '  (driver file version ' + $vs.pinFileVersion + ', from ' + $vs.pinSource + ')')
    if (-not $vs.present) { $null = $b.Add('    none present - this KVM guest is NOT running virtio drivers.') }
    else { foreach ($r in @($vs.drivers)) { $null = $b.Add(('    {0,-10} {1,-22} {2}' -f $r.driver, $r.fileVersion, $r.state)) } }
    $null = $b.Add('    verdict       : ' + $vs.verdict + ' - ' + $vs.why)
  }
  if (@($pl.leftovers).Count) {
    $null = $b.Add('')
    $null = $b.Add('  LEFT OVER FROM THE PLATFORM THIS VM CAME FROM:')
    foreach ($x in @($pl.leftovers)) { $null = $b.Add('    - ' + $x) }
  }
  $null = $b.Add('')
  $null = $b.Add('  NOTE: snapshot backups on this estate are AGENTLESS - they ask this agent to')
  $null = $b.Add('        freeze the machine. Without it running, a snapshot of a database is')
  $null = $b.Add('        crash-consistent, and nothing says so at the time.')
  $null = $b.Add('')
  $null = $b.Add('--- VOLUMES (NTFS, fixed) ------------------------------------------------------')
  $volRows = @()
  try {
    foreach ($v in @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction Stop)) {
      $dirty = 'no'
      try { if (((cmd /c ('fsutil dirty query ' + $v.DeviceID) 2>&1) -join ' ') -match 'is Dirty') { $dirty = 'YES - Windows has already decided this volume needs repair' } } catch { $dirty = '(unreadable)' }
      $freeGB = [math]::Round($v.FreeSpace/1GB,1); $sizeGB = [math]::Round($v.Size/1GB,1)
      $pct = if ($v.Size -gt 0) { [math]::Round(($v.FreeSpace/$v.Size)*100,1) } else { 0 }
      $null = $b.Add(('  {0,-4} {1,8} GB total  {2,8} GB free ({3}%)  fs={4}  dirty bit: {5}' -f $v.DeviceID, $sizeGB, $freeGB, $pct, $v.FileSystem, $dirty))
      $volRows += [ordered]@{ drive=$v.DeviceID; sizeGB=$sizeGB; freeGB=$freeGB; freePct=$pct; fs=$v.FileSystem; dirty=$dirty }
      # The report's disk verdict reads the dirty bit from HERE, because this is the only place it
      # is actually measured. It previously read $Survey.data.capacity, which (a) is not in scope
      # in Write-AdoptReport and (b) has no dirty property at all - so the verdict could never say
      # BAD, even on a volume Windows had already flagged for repair. A report that under-states
      # damage is the exact failure this script exists to prevent.
      $script:Evidence['volumes'] += [ordered]@{ drive=$v.DeviceID; fs=$v.FileSystem; dirty=$dirty; sizeGB=$sizeGB; freeGB=$freeGB }
    }
  } catch { $null = $b.Add('  could not enumerate volumes: ' + $_.Exception.Message) }
  $null = $b.Add('  chkdsk /scan is NOT run here. It is read-only and online, but it reads the whole')
  $null = $b.Add('  volume, so it is deferred to YC-IntegrityBaseline outside the window - IF that')
  $null = $b.Add('  task was scheduled. adopt-report.txt beside this file says whether it was.')
  $null = $b.Add('')

  # --- SQL ---------------------------------------------------------------------------------------
  $null = $b.Add('--- SQL SERVER -----------------------------------------------------------------')
  $sqlRows = @()
  $inst = @()
  try { $inst = @($Survey.data.sql) } catch {}
  if ($inst.Count -eq 0) { $null = $b.Add('  no SQL Server instance on this host.') }
  foreach ($i in $inst) {
    $ed = $(if ($i.liveEdition) { $i.liveEdition } else { $i.edition })
    $null = $b.Add('  instance        : ' + $i.instance + '   (' + $i.status + ')')
    $null = $b.Add('    edition       : ' + $ed)
    $null = $b.Add('    version       : ' + $(if ($i.liveVersion) { $i.liveVersion } else { $i.version }) + '   patch ' + $i.patchlevel)
    $null = $b.Add('    evaluation    : ' + $(if ($i.isEvaluation) { 'YES - this edition STOPS working when the period ends' } else { 'no' }))
    $null = $b.Add('    product key   : ' + $i.partialProductKey)
    if ($i.status -ne 'Running') { $null = $b.Add('    (not running - nothing further could be read)'); continue }
    $t = $(if ($i.instance -eq 'MSSQLSERVER') { '.' } else { '.\' + $i.instance })

    # PAGE_VERIFY AS RECEIVED. This is the single most important line in the file: a database on
    # TORN_PAGE_DETECTION or NONE has had NO bit-rot detection for its whole life, and every
    # backup taken of it carries whatever rot it has.
    $pv = Invoke-SqlCmdLocal -Target $t -Query "SET NOCOUNT ON; SELECT CONVERT(varchar(128),name) COLLATE DATABASE_DEFAULT + '|' + CONVERT(varchar(64),page_verify_option_desc) COLLATE DATABASE_DEFAULT + '|' + CONVERT(varchar(64),recovery_model_desc) COLLATE DATABASE_DEFAULT + '|' + ISNULL(CONVERT(varchar(20),CAST((SELECT SUM(size)*8.0/1024 FROM sys.master_files WHERE database_id = d.database_id) AS decimal(18,1))),'?') FROM sys.databases d WHERE database_id > 4 AND state = 0;"
    $null = $b.Add('    databases     :')
    foreach ($line in @(([string]$pv) -split "`n" | Where-Object { $_ -match '\|' })) {
      $f = $line -split '\|'
      $warn = ''
      if ($f[1].Trim() -ne 'CHECKSUM') { $warn = '   <-- NO BIT-ROT DETECTION as received' }
      if ($f[2].Trim() -eq 'SIMPLE')   { $warn += '   <-- SIMPLE: point-in-time recovery is IMPOSSIBLE' }
      $null = $b.Add(('      {0,-32} page_verify={1,-22} recovery={2,-8} {3} MB{4}' -f $f[0].Trim(), $f[1].Trim(), $f[2].Trim(), $f[3].Trim(), $warn))
      $sqlRows += [ordered]@{ instance=$i.instance; database=$f[0].Trim(); pageVerifyAsReceived=$f[1].Trim(); recovery=$f[2].Trim(); sizeMB=$f[3].Trim() }
      # The report reads sizes from here. Size is not cosmetic on this job: it is what decides
      # whether a CHECKDB or a restore test fits the window and the free space, and it is the
      # first thing asked when somebody has to plan a repair.
      $script:Evidence['databases'] += [ordered]@{ instance=$i.instance; database=$f[0].Trim(); recovery=$f[2].Trim(); pageVerify=$f[1].Trim(); sizeMB=$f[3].Trim() }
    }

    # suspect_pages WITH DATES. The dates are the evidence; the count never was.
    $ev = Get-SqlDamageEvidence -Target $t
    $script:Evidence['sql'] += [ordered]@{ instance=$i.instance; suspectPages=$ev }
    if ($ev.totalPages -gt 0) {
      $null = $b.Add('    suspect_pages : ' + [string]$ev.totalPages + ' DAMAGED PAGE(S) ON RECORD - THIS INSTANCE ARRIVED DAMAGED')
      $null = $b.Add('      SQL Server recorded these itself. The dates below were written on the')
      $null = $b.Add('      SOURCE platform, before this machine was migrated and before this')
      $null = $b.Add('      toolkit ever ran on it.')
      $null = $b.Add('      database                        pages  first seen           last seen')
      foreach ($r in $ev.rows) {
        $null = $b.Add(('      {0,-30} {1,6}  {2,-19}  {3}' -f $r.database, $r.pages, $r.firstSeen, $r.lastSeen))
      }
      if ($ev.capped) {
        $null = $b.Add('      *** 1000 is the TABLE CAP, not a count. SQL stopped recording; it did')
        $null = $b.Add('      *** not stop happening. The real number is unknown and larger, and the')
        $null = $b.Add('      *** earliest date above is therefore a LOWER bound - damage may be older.')
      }
      Flag 'BASELINE' ($i.instance + ': ' + [string]$ev.totalPages + ' damaged page(s) on record, first seen ' + $(if ($ev.earliest) { $ev.earliest } else { 'unknown' }) + '. SQL Server wrote that date itself. This instance ARRIVED damaged.')
    } else { $null = $b.Add('    suspect_pages : 0 - no damage on record') }

    # When was each database last PROVEN clean? Often the answer is never.
    $dbNames = @($sqlRows | Where-Object { $_.instance -eq $i.instance } | ForEach-Object { $_.database })
    if ($dbNames.Count) {
      $lkg = Get-SqlLastKnownGood -Target $t -Databases $dbNames
      $script:Evidence['lastKnownGood'] += $lkg
      $null = $b.Add('    last CHECKDB that PASSED (dbi_dbccLastKnownGood):')
      foreach ($g in $lkg) {
        $null = $b.Add(('      {0,-30} {1}' -f $g.database, $(if ($g.neverChecked) { 'NEVER - no CHECKDB has ever completed cleanly' } else { $g.lastKnownGood })))
      }
      $never = @($lkg | Where-Object { $_.neverChecked })
      if ($never.Count) {
        Flag 'BASELINE' ([string]$never.Count + ' database(s) have NEVER had a CHECKDB complete cleanly (' + (($never | ForEach-Object { $_.database }) -join ', ') + '). Corruption there could have been accumulating undetected for the life of the database, on the source platform.')
      }
    }

    $bh = Invoke-SqlCmdLocal -Target $t -Query "SET NOCOUNT ON; SELECT TOP 5 database_name + '  ' + CONVERT(varchar(30),backup_finish_date,120) + '  type=' + type + '  by ' + ISNULL(user_name,'?') FROM msdb.dbo.backupset ORDER BY backup_finish_date DESC;"
    $null = $b.Add('    last backups  :')
    if ($bh) { foreach ($line in @(([string]$bh) -split "`n" | Where-Object { $_.Trim() })) { $null = $b.Add('      ' + $line.Trim()) } }
    else     { $null = $b.Add('      none recorded in msdb') }
  }
  $null = $b.Add('')
  # A baseline is handed to a customer as the record of what arrived. If it names NO database on
  # an instance that is RUNNING, it is not a clean baseline - it is a failed read that looks like
  # a clean one, and the 562 GB it omitted includes the damaged database. Refuse to be quiet.
  if ($sqlRows.Count -eq 0) {
    $running = 0
    try { $running = @($Survey.data.sql | Where-Object { $_.status -eq 'Running' }).Count } catch {}
    if ($running -gt 0) {
      Flag 'BASELINE' ('this baseline lists NO databases although ' + [string]$running + ' SQL instance(s) are RUNNING. The read failed; the file is NOT a usable record of what arrived. Most likely cause: the account running this is not a sysadmin on the instance, so sys.master_files returned nothing. Re-run BASELINE as an account that IS sysadmin.')
      $null = $b.Add('  *** WARNING: the database list above is EMPTY because the read FAILED, not')
      $null = $b.Add('  *** because this instance has no databases. Do not treat this file as a')
      $null = $b.Add('  *** complete baseline. Re-run as a sysadmin account.')
      $null = $b.Add('')
    }
  }
  # --- Windows' own dated record of IO trouble -------------------------------------------------
  $se = Get-StorageErrorEvidence
  $script:Evidence['events'] = $se
  $null = $b.Add('--- IO AND SQL ERRORS ALREADY IN THE EVENT LOG (last 365 days) -----------------')
  $null = $b.Add('  Written by Windows and by SQL Server, not by this toolkit. These are dated.')
  $null = $b.Add('  This is a VIRTUAL volume on a hypervisor, so no physical-disk or SMART health')
  $null = $b.Add('  is reported here - there is no physical disk in this guest to report on.')
  foreach ($pair in @(@{k='sql';t='SQL Server (Application log)'}, @{k='storage';t='disk / NTFS / storage driver (System log)'})) {
    $rows = @($se[$pair.k])
    $null = $b.Add('  ' + $pair.t + ':')
    if (-not $rows.Count) { $null = $b.Add('    none in the window'); continue }
    foreach ($r in $rows) {
      $null = $b.Add(('    event {0,-6} x{1,-6} first {2}   last {3}' -f $r.id, $r.count, $r.first, $r.last))
    }
  }
  if ($se.capped) { $null = $b.Add('  *** the 2000-event read cap was hit, so the FIRST date above is a lower bound.') }
  $null = $b.Add('')

  # --- the anchor the dates above are compared against -----------------------------------------
  $null = $b.Add('--- WHEN THIS MACHINE ARRIVED --------------------------------------------------')
  $null = $b.Add('  Any evidence dated BEFORE the adopt time below existed before YallaCloud ran')
  $null = $b.Add('  anything on this machine. Compare the migration date from the migration record')
  $null = $b.Add('  against the dates above to place the damage either side of the move.')
  try { $null = $b.Add('  Windows installed : ' + $Survey.data.identity.installDate) } catch {}
  try { $null = $b.Add('  last boot         : ' + $Survey.data.identity.lastBoot) } catch {}
  $null = $b.Add('  first YallaCloud   : ' + $now + '   (this baseline - nothing had been changed)')
  $null = $b.Add('')

  $null = $b.Add('--- END OF AS-RECEIVED BASELINE ------------------------------------------------')
  $null = $b.Add('  A deferred check appends its findings below IF it was scheduled. SQLMAINT decides')
  $null = $b.Add('  that, and it is not always able to: whether it was is recorded in adopt-report.txt')
  $null = $b.Add('  beside this file. If nothing is appended below, read that report before assuming')
  $null = $b.Add('  the check passed - it may never have been scheduled at all.')
  $null = $b.Add('')

  try {
    $b -join "`r`n" | Set-Content -LiteralPath $path -Encoding Ascii
    L ('baseline written: ' + $path) 'OK'
  } catch { Flag 'BASELINE' ('could not write ' + $path + ': ' + $_.Exception.Message); return 3 }

  # CHAIN OF CUSTODY. A file anybody could have edited afterwards is weak evidence. Hash it the
  # moment it is written, log the hash, and put the same hash in the fleet event and the adopt
  # report - three places, two of them off this machine. If the file is ever disputed, the hash
  # recorded elsewhere at a known time says whether the copy being argued over is the original.
  try {
    $script:Evidence['baselineSha256'] = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    L ('baseline SHA256: ' + $script:Evidence['baselineSha256'] + '  - recorded here, in adopt-report.json and in the fleet event, so this file cannot be quietly edited later.') 'OK'
  } catch { Flag 'BASELINE' ('could not hash the baseline: ' + $_.Exception.Message) }

  try {
    ([ordered]@{ schema='ycadopt.baseline/1'; host=$h; capturedUtc=$now
                 note='state as RECEIVED from the source platform; nothing had been changed'
                 payload=(Get-PayloadVersion); platform=$script:Evidence['platform']
                 volumes=$volRows; databases=$sqlRows
                 # (the guard above refuses to let this be silently empty)
                 sql=@($inst | ForEach-Object { [ordered]@{ instance=$_.instance; edition=$(if($_.liveEdition){$_.liveEdition}else{$_.edition}); evaluation=$_.isEvaluation; status=$_.status } })
               } | ConvertTo-Json -Depth 7) | Set-Content -LiteralPath $json -Encoding Ascii
  } catch {}
  return 0
}

function Get-PayloadVersion {
  $vf = Join-Path $ScriptsDir 'yc-payload-version.txt'
  if (Test-Path -LiteralPath $vf) { return ((Get-Content -LiteralPath $vf -TotalCount 1) -replace '^[^=]*=\s*','').Trim() }
  return '(unknown)'
}

# ================================================================================================
# PHASE - SQLHARDEN.  The vaccine. One ALTER per database, and it costs nothing.
#
# PAGE_VERIFY CHECKSUM makes SQL Server write a checksum on every page write and verify it on
# every page read. Without it - and a database carried up from SQL 2000/2005 keeps
# TORN_PAGE_DETECTION or NONE forever - SQL NEVER NOTICES BIT ROT. Not on read, not on backup,
# not on RESTORE VERIFYONLY. The damage is copied into every backup silently and is found months
# later, when the clean backup has long aged out. That is the shape of a 10% recovery rate.
#
# WHAT IT DOES NOT DO: it does not retrofit. A checksum is written when a page is WRITTEN, so
# pages already on disk stay unprotected until something rewrites them. Retrofitting means an
# index rebuild - hours of IO and large log growth - and the owner's constraint is no IO, CPU or
# memory increase. So the date CHECKSUM was turned on is RECORDED, and the gap is covered by
# BACKUP WITH CHECKSUM, which reads every page as part of a backup we are taking anyway.
# ================================================================================================
function Invoke-SqlHarden {
  param($Survey)
  $inst = @()
  try { $inst = @($Survey.data.sql | Where-Object { $_.status -eq 'Running' }) } catch {}
  if ($inst.Count -eq 0) { L 'no running SQL instance to harden.' 'OK'; return 0 }
  $changed = 0; $simple = 0
  $undo = New-Object System.Collections.Generic.List[object]

  foreach ($i in $inst) {
    $t = $(if ($i.instance -eq 'MSSQLSERVER') { '.' } else { '.\' + $i.instance })
    $rows = Invoke-SqlCmdLocal -Target $t -Query "SET NOCOUNT ON; SELECT CONVERT(varchar(128),name) COLLATE DATABASE_DEFAULT + '|' + CONVERT(varchar(64),page_verify_option_desc) COLLATE DATABASE_DEFAULT + '|' + CONVERT(varchar(64),recovery_model_desc) COLLATE DATABASE_DEFAULT FROM sys.databases WHERE database_id > 4 AND state = 0 AND is_read_only = 0;"
    foreach ($line in @(([string]$rows) -split "`n" | Where-Object { $_ -match '\|' })) {
      $f = $line -split '\|'; $db = $f[0].Trim(); $pv = $f[1].Trim(); $rm = $f[2].Trim()

      if ($rm -eq 'SIMPLE') {
        $simple++
        # D2: report loudly, change NOTHING. Switching to FULL starts a transaction log that
        # grows until it is backed up, and on a disk we did not size that fills the volume and
        # stops SQL. The honest sentence matters more than the fix here.
        Flag 'SQLHARDEN' ($i.instance + '/' + $db + ' is in SIMPLE recovery: POINT-IN-TIME RECOVERY IS IMPOSSIBLE for it. The best that can ever be offered is the last FULL or DIFF. Changing this is a sizing decision, not an automatic one.')
      }

      if ($pv -eq 'CHECKSUM') { L ($i.instance + '/' + $db + ': page_verify already CHECKSUM') 'OK'; continue }
      L ($i.instance + '/' + $db + ': page_verify is ' + $pv + ' - SQL has never been able to see bit rot here. Setting CHECKSUM.') 'WARN'
      $undo.Add([ordered]@{ instance=$i.instance; database=$db; previousPageVerify=$pv }) | Out-Null
      $q = 'ALTER DATABASE [' + $db.Replace(']',']]') + '] SET PAGE_VERIFY CHECKSUM WITH NO_WAIT;'
      Invoke-SqlCmdLocal -Target $t -Query $q | Out-Null
      $chk = Invoke-SqlCmdLocal -Target $t -Query ("SET NOCOUNT ON; SELECT page_verify_option_desc FROM sys.databases WHERE name = N'" + ($db -replace "'","''") + "';")
      if (([string]$chk).Trim() -eq 'CHECKSUM') { L ($i.instance + '/' + $db + ': page_verify is now CHECKSUM') 'OK'; $changed++ }
      else { Flag 'SQLHARDEN' ($i.instance + '/' + $db + ': the ALTER ran but page_verify still reads ' + ([string]$chk).Trim()) }
    }
  }

  if ($undo.Count) {
    try { ([ordered]@{ schema='ycadopt.pageverify.undo/1'; host=(Get-HostNameSafe)
                       changedUtc=(Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
                       note='PAGE_VERIFY values as they were BEFORE this run. Pages written before changedUtc carry no checksum.'
                       databases=@($undo) } | ConvertTo-Json -Depth 5) |
          Set-Content -LiteralPath (Join-Path $ScriptsDir 'pageverify.undo.json') -Encoding Ascii } catch {}
  }
  L ([string]$changed + ' database(s) moved to PAGE_VERIFY CHECKSUM, ' + [string]$simple + ' in SIMPLE recovery.') $(if ($simple -gt 0) {'WARN'} else {'OK'})
  if ($changed -gt 0) {
    L 'NOTE: a checksum is written when a page is WRITTEN. Pages already on disk stay unprotected' 'WARN'
    L 'until something rewrites them. The full CHECKDB baseline is what covers those.' 'WARN'
  }
  return 0
}

# ================================================================================================
# PHASE 8 - SQLBACKUP.  The one phase that touches production data, so it is the most careful.
#
#   REFUSES when another backup scheme is already live. Two backup systems on one database is
#   worse than one: each truncates the other's log chain and then NEITHER restore is trustworthy.
#   Detection is msdb.dbo.backupset (which records every backup, whoever took it) plus the named
#   third-party agent services from the survey.
#
#   THIS phase does not install Ola - backup-sql uses dbo.DatabaseBackup when it exists and falls
#   back to native verified T-SQL BACKUP when it does not: same files, same naming, same msdb
#   rows. SQLMAINT, two phases later, DOES install it for the integrity schedule. So on a normal
#   run Ola ends up present; it is just not this phase that puts it there.
#
#   Order: ONE FULL of every database first, proved, and only then the recurring tasks. A DIFF
#   with no FULL behind it restores nothing, so the tasks are not registered until the full is on
#   disk and in msdb.
# ================================================================================================
# Set only where this script actually takes over backup. The report reads it, and reporting that
# we own backups when we refused to is the kind of false comfort this whole programme exists to
# avoid.
function Invoke-SqlBackup {
  param($Survey)
  $inst = @()
  try { $inst = @($Survey.data.sql | Where-Object { $_.status -eq 'Running' }) } catch {}
  if ($inst.Count -eq 0) { L 'no running SQL instance - nothing to back up.' 'OK'; return 0 }

  # --- the refusal gate ---------------------------------------------------------------------
  $agents = @()
  try { $agents = @($Survey.data.inherited.backupAgents | Where-Object { $_.status -eq 'Running' }) } catch {}
  $foreign = @($inst | Where-Object { $_.foreignBackupHistoryDays -ge 0 -and $_.foreignBackupHistoryDays -le 7 })
  $ycTasks = @()
  try { $ycTasks = @($Survey.data.us.ycTasks | Where-Object { $_ -match 'SqlBackup' }) } catch {}

  if (($agents.Count -gt 0 -or $foreign.Count -gt 0) -and $ycTasks.Count -eq 0) {
    if ($agents.Count -gt 0) {
      Flag 'SQLBACKUP' ('a third-party backup agent is RUNNING on this host: ' +
        (($agents | ForEach-Object { $_.product + ' (' + $_.service + ')' }) -join ', ') + '.')
    }
    foreach ($i in $foreign) {
      Flag 'SQLBACKUP' ($i.instance + ' has backup history in msdb from the last ' + $i.foreignBackupHistoryDays +
        ' day(s), taken by something that is not us.')
    }
    if (-not $Force) {
      L 'REFUSING the SQL backup phase. Two backup systems on one database break each other log chains and neither restore is then trustworthy.' 'ERROR'
      L 'Decide which scheme owns this instance. To proceed anyway once that decision is made, re-run with -Force.' 'WARN'
    # We just handed backup responsibility to somebody else's agent. Check that the plumbing it
    # depends on actually works, rather than assuming it. VSS is read-only to inspect and it is
    # what every Windows backup agent uses; a broken writer is a silent backup failure, and a
    # silent backup failure on an already-damaged instance is how the last clean copy disappears.
    # Structured, and CACHED: the data-and-backup banner later in the run reads this rather than
    # running vss-check a second time on the same machine for the same answer.
    $vss = Get-VssState
    $script:Evidence['vss'] = $vss
    if ($vss.verdict -eq 'BROKEN') {
      Flag 'SQLBACKUP' ('we are leaving backup to the incumbent agent, and VSS has ' + [string]$vss.critical + ' CRITICAL finding(s) - so the mechanism that agent relies on is NOT healthy. A backup that cannot snapshot is a backup that is not happening. ' + $vss.why)
      foreach ($f in @($vss.findings | Where-Object { $_.severity -eq 'CRITICAL' })) {
        L ('   VSS CRITICAL ' + $f.area + ' - ' + $f.subject + ': ' + $f.detail) 'ERROR'
      }
    } elseif ($vss.verdict -eq 'SUSPECT') {
      Flag 'SQLBACKUP' ('we are leaving backup to the incumbent agent, and VSS has ' + [string]$vss.warn + ' warning(s). ' + $vss.why)
    } elseif ($vss.verdict -eq 'OK') {
      L 'vss-check: the shadow-copy mechanism the incumbent backup relies on looks healthy.' 'OK'
    } else {
      Flag 'SQLBACKUP' ('we are leaving backup to the incumbent agent and could not establish whether VSS works: ' + $vss.why)
    }
      return 2
    }
    L 'proceeding past the existing-backup gate because -Force was given. You are now running two backup schemes on this instance.' 'WARN'
  }

  # --- the first full -------------------------------------------------------------------------
  foreach ($pair in @(@{n='RetainFullDays';v=$RetainFullDays},@{n='RetainDiffDays';v=$RetainDiffDays},@{n='RetainLogDays';v=$RetainLogDays})) {
    if ($pair.v -lt 15) { Flag 'SQLBACKUP' ($pair.n + ' is ' + [string]$pair.v + ' days, below the 15-day floor. Retention must outlive detection latency or a corruption found on day 15 has no clean backup left.') }
  }
  # MEASURED on a real customer box: a 539 GB database, its log AND its backups all on one C:
  # with 134 GB free. A full backup of that does not fail politely - it fills the system volume
  # and stops SQL Server. Check that the target can actually hold the data before starting.
  foreach ($i in $inst) {
    $t = $(if ($i.instance -eq 'MSSQLSERVER') { '.' } else { '.\' + $i.instance })
    $sizeMB = 0
    $r = Invoke-SqlCmdLocal -Target $t -Query "SET NOCOUNT ON; SELECT CONVERT(varchar(20),CAST(SUM(size)*8.0/1024 AS decimal(18,0))) FROM sys.master_files WHERE database_id > 4 AND type = 0;"
    [void][int]::TryParse(([string]$r -replace '[^0-9]',''), [ref]$sizeMB)
    if ($sizeMB -le 0) { continue }
    $needGB = [math]::Round($sizeMB/1024,1)
    $tgt = $(if ($BackupDir) { $BackupDir } else { 'C:\' })
    $letter = ([string]$tgt).Substring(0,1)
    $freeGB = $null
    try { $freeGB = [math]::Round((Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $letter + ":'") -ErrorAction Stop).FreeSpace/1GB,1) } catch {}
    if ($null -ne $freeGB) {
      L ($i.instance + ': user data is ' + [string]$needGB + ' GB, backup target ' + $letter + ': has ' + [string]$freeGB + ' GB free.')
      # Uncompressed is the honest assumption. Compression is an Enterprise/Standard feature that
      # is not on by default and is unavailable on Express, so assuming it is how you fill a disk.
      if ($freeGB -lt $needGB) {
        Flag 'SQLBACKUP' ($i.instance + ': a full backup needs about ' + [string]$needGB + ' GB but ' + $letter + ': has only ' + [string]$freeGB + ' GB free. REFUSING - a backup that fills the system volume stops SQL Server, which is a worse outage than having no backup tonight. Point -BackupDir at a volume with room.')
        if (-not $Force) { return 2 }
        L 'proceeding past the backup-space gate because -Force was given.' 'WARN'
      }
    }
  }
  $fullArgs = @('-AllInstances','-Type','Full','-Checksum','-Verify')
  if ($BackupDir) { $fullArgs += @('-Directory',$BackupDir) }
  L 'taking the FIRST FULL backup of every user database. Nothing is scheduled until this is on disk and in msdb.'
  $code = Invoke-YcCommand -Script 'Backup-Sql.ps1' -Arguments $fullArgs -Phase 'SQLBACKUP'
  if ($null -eq $code -or $code -ne 0) {
    Flag 'SQLBACKUP' 'the first FULL backup did not complete, so NO recurring task was registered. A DIFF with no FULL behind it restores nothing.'
    return 3
  }
  L 'first FULL backup completed and verified.' 'OK'

  # --- the recurring tasks ----------------------------------------------------------------------
  # FULL weekly, DIFF on the other six days, LOG every 15 minutes for FULL-recovery databases.
  # Same shape install-sql uses on a fresh VM, so a migrated box and a built box look identical in
  # the task list - except for the name, which says where it came from.
  $rc = 0
  $rc += Register-AdoptTask -Name 'YC-Adopt-SqlBackupFull' -BackupType 'Full' -Weekly   -At '01:15'
  $rc += Register-AdoptTask -Name 'YC-Adopt-SqlBackupDiff' -BackupType 'Diff' -Daily    -At '01:15'
  $anyFull = @()
  foreach ($i in $inst) { $anyFull += @($i.databases | Where-Object { $_.recovery -eq 'FULL' }) }
  if ($anyFull.Count -gt 0) {
    L ([string]$anyFull.Count + ' database(s) are in FULL recovery, so the log must be backed up or it grows until the disk fills.')
    $rc += Register-AdoptTask -Name 'YC-Adopt-SqlBackupLog' -BackupType 'Log' -Daily -At '00:05' -RepeatMinutes 15
  } else {
    L 'no database is in FULL recovery - no log backup task is needed.' 'OK'
  }
  if ($rc -ne 0) { return 3 }
  # Say so. This flag is what adopt-report.txt prints as "YallaCloud owns SQL backups", and it was
  # declared at the top of the file and then never assigned anywhere - so the report answered "no"
  # even on a machine where all three tasks had just registered cleanly.
  $script:BackupOwned = $true
  L 'YallaCloud now owns SQL backup on this instance - the recurring tasks are registered and read back.' 'OK'
  return 0
}

# Additive, never destructive: a task that already exists is LEFT ALONE and flagged. Overwriting
# somebody else's backup schedule because our name happened to match is the destructive edit this
# whole posture exists to prevent.
function Register-AdoptTask {
  param([string]$Name,[string]$BackupType,[switch]$Daily,[switch]$Weekly,[string]$At,[int]$RepeatMinutes=0)
  $existing = $null
  try { $existing = Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue } catch {}
  if ($existing) {
    Flag 'SQLBACKUP' ('scheduled task ' + $Name + ' already exists - left exactly as it is. Check it is what you want.')
    return 0
  }
  $bs = Join-Path $ScriptsDir 'Backup-Sql.ps1'
  if (-not (Test-Path -LiteralPath $bs)) { Flag 'SQLBACKUP' 'Backup-Sql.ps1 is not in the payload, so no backup task was registered.'; return 3 }
  $a = '-NoProfile -ExecutionPolicy Bypass -File "' + $bs + '" -AllInstances -Type ' + $BackupType + ' -Checksum -Verify'
  if ($BackupDir) { $a += ' -Directory "' + $BackupDir + '"' }
  try {
    $atTime = [datetime]::ParseExact($At,'HH:mm',[Globalization.CultureInfo]::InvariantCulture)
    $act = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $a
    if ($Weekly) { $trg = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At $atTime }
    else         { $trg = New-ScheduledTaskTrigger -Daily -At $atTime }
    if ($RepeatMinutes -gt 0) {
      # RepetitionInterval is set on the TRIGGER. Setting it on the settings set silently does
      # nothing on Server 2019 - the exception is swallowed and the log claims a repeat that never
      # happened. Same trap Yc-AutoUpdate hit with RandomDelay.
      try {
        $trg.Repetition = (New-ScheduledTaskTrigger -Once -At $atTime `
                            -RepetitionInterval (New-TimeSpan -Minutes $RepeatMinutes) `
                            -RepetitionDuration (New-TimeSpan -Days 1)).Repetition
      } catch { Flag 'SQLBACKUP' ($Name + ': this build would not accept a ' + $RepeatMinutes + '-minute repeat, so the log backup runs ONCE a day, not every ' + $RepeatMinutes + ' minutes.') }
    }
    $pri = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
             -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 4)
    Register-ScheduledTask -TaskName $Name -Action $act -Trigger $trg -Principal $pri -Settings $set -Force | Out-Null
    # Read it back, every time. "Registered without error" is not "the task is there".
    if (Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue) {
      L ($Name + ' registered (' + $(if ($Weekly) {'weekly Sunday'} else {'daily'}) + ' ' + $At +
         $(if ($RepeatMinutes -gt 0) { ', repeating every ' + $RepeatMinutes + ' min' } else { '' }) +
         ', SYSTEM) - existence confirmed.') 'OK'
      return 0
    }
    Flag 'SQLBACKUP' ('Register-ScheduledTask returned without error but ' + $Name + ' is not there.')
    return 3
  } catch { Flag 'SQLBACKUP' ('could not register ' + $Name + ': ' + $_.Exception.Message); return 3 }
}

# ================================================================================================
# PHASE - SQLMAINT.  Ola, then the recurring checks, then the deferred baseline.
#
# This is the phase that brings a migrated box to FRESH-DEPLOY PARITY. Install-Sql PHASE 12 gives
# every freshly built VM YC-SqlIntegrity, YC-SqlIndexOpt and YC-SqlRestoreVerify. Before this,
# migrated-vm registered none of them - so the machine most likely to be carrying old, undetected
# corruption was the one getting the least protection.
#
# Everything here is registered as chadmin via S4U, never SYSTEM, so every run is attributable.
# ================================================================================================
function Invoke-SqlMaint {
  param($Survey)
  $inst = @()
  try { $inst = @($Survey.data.sql | Where-Object { $_.status -eq 'Running' }) } catch {}
  if ($inst.Count -eq 0) { L 'no running SQL instance - no maintenance to register.' 'OK'; return 0 }
  if (-not $script:ChadminLogin) { Flag 'SQLMAINT' 'INTERNAL: SQLPREP returned success but set no task identity. No task registered.'; return 2 }
  $rc = 0

  # MEASURED on a real customer box: msdb.dbo.suspect_pages held 1000 rows - which is the CAP,
  # not a count. SQL stops writing at 1000, so a full table means damage is ONGOING AND UNCOUNTED.
  # Scheduling a full CHECKDB and nightly backups over that is actively harmful: the CHECKDB
  # hammers storage that is already failing reads, and backup retention can age out the last
  # clean copy while nobody is looking. An already-damaged instance needs a human, not a schedule.
  # THE REFUSAL IS SPLIT, and this is the correction that matters most in the whole adopt path.
  #
  # It used to return here and register NOTHING. So an instance with damaged pages - the exact case
  # this programme exists for - got no Ola, no daily watch, no restore verification and no baseline.
  # Observed twice on a real host. That is backwards: the cheap read-only watch is MORE valuable on
  # a damaged instance, not less, because it is the only thing that says the damage is GROWING. On
  # that same host suspect_pages went from 33 rows to 1000 between two copies and nobody was looking.
  #
  # What is actually expensive is the FULL logical CHECKDB: it reads everything and builds a
  # snapshot on a volume whose reads are already failing. That one is withheld. Everything else is
  # registered, and the flag says which is which rather than implying nothing was done.
  $script:SqlDamaged = $false
  foreach ($i in $inst) {
    $t = $(if ($i.instance -eq 'MSSQLSERVER') { '.' } else { '.\' + $i.instance })
    $sp = Invoke-SqlCmdLocal -Target $t -Query "SET NOCOUNT ON; SELECT CONVERT(varchar(10),COUNT(*)) FROM msdb.dbo.suspect_pages WHERE event_type IN (1,2,3);"
    $spn = 0; [void][int]::TryParse(([string]$sp -replace '[^0-9]',''), [ref]$spn)
    if ($spn -gt 0) {
      $script:SqlDamaged = $true
      Flag 'SQLMAINT' ($i.instance + ': msdb.dbo.suspect_pages already holds ' + [string]$spn + ' damaged page(s)' +
        $(if ($spn -ge 1000) { ' - and 1000 is the CAP, so the real number is unknown and larger' } else { '' }) +
        '. The WEEKLY FULL CHECKDB is NOT registered: it would read everything and snapshot onto a volume whose reads are already failing. The daily fast check, the restore verification and the one-off baseline ARE registered, because on a damaged instance those matter more, not less. This instance needs a human.')
    }
    if (-not $SkipOla) { if (-not (Install-Ola -Target $t -Instance $i.instance)) { $rc = 3 } }
  }

  # The recurring checks. All call yc-integrity, which carries the disk gate, the re-run before
  # anyone is told, and the PASS report as well as the FAIL - written once, not five times.
  $yi = Join-Path $ScriptsDir 'Yc-Integrity.ps1'
  if (-not (Test-Path -LiteralPath $yi)) { Flag 'SQLMAINT' 'Yc-Integrity.ps1 is not in the payload, so no integrity task was registered.'; return 3 }

  # Daily, cheap, read-only. PHYSICAL_ONLY plus a read of msdb.dbo.suspect_pages. This is the one
  # that answers "is it getting worse", so it is registered whatever state the instance is in.
  $rc += Register-YcTask -Name 'YC-SqlIntegrityFast' -Daily  -At '02:15' -Script $yi -Arguments '-Sql Fast -SuspectPages'
  # Weekly, and the only thing the damage gate withholds.
  if ($script:SqlDamaged -and -not $Force) {
    L 'YC-SqlIntegrity (weekly FULL CHECKDB) NOT registered - this instance already has damaged pages. Run it by hand in a change window:  yc-integrity -Sql Full' 'WARN'
  } else {
    $rc += Register-YcTask -Name 'YC-SqlIntegrity'   -Weekly -At '02:45' -Script $yi -Arguments '-Sql Full'
  }
  $rc += Register-YcTask -Name 'YC-SqlRestoreVerify' -Weekly -At '04:15' -Script $yi -Arguments '-RestoreVerify'

  # The deferred baseline (D6). A full CHECKDB on a large database runs for as long as it runs,
  # and the owner's constraint is that nobody babysits a migration. So it is a ONE-OFF at the
  # maintenance hour, MAXDOP 1 so it does not take every core, and it appends to the baseline file.
  # Local metrics. Bound to 127.0.0.1 on purpose: the owner asked for this "at least for logging
  # locally", and the default -RemoteAddress Any would open a listener to the network on a
  # customer database server, which is a decision nobody made.
  if (-not $SkipExporter) {
    $ex = Invoke-YcCommand -Script 'SqlExporter-Register.ps1' `
            -Arguments @('-TrustedAuth','-SqlServer','localhost','-BindAddress','127.0.0.1','-RemoteAddress','127.0.0.1') `
            -Phase 'SQLMAINT' -OkCodes @(0)
    if ($null -eq $ex -or $ex -ne 0) {
      L 'the local SQL metrics exporter did not register. Not fatal - nothing else depends on it. See C:\Scripts\sqlexporter-register.log.' 'WARN'
    } else { L 'local SQL metrics exporter registered, listening on 127.0.0.1 only.' 'OK' }
  }

  # Owner constraint: "we can't take more downtime so can't do a full DBCC but atleast we get to
  # know if there is a problem or not". So the one-off baseline uses the FAST check - CHECKDB
  # PHYSICAL_ONLY - which verifies page checksums without the logical pass, plus chkdsk /scan,
  # which is ONLINE and READ-ONLY on a virtual volume. MAXDOP 1 so it does not take every core.
  $when = (Get-Date).Date.AddDays($(if ((Get-Date).Hour -ge 2) { 1 } else { 0 })).AddHours(2).AddMinutes(15)
  $script:BaselineTaskAt = $when
  $rc += Register-YcTask -Name 'YC-IntegrityBaseline' -Once -At $when -Script $yi `
           -Arguments ('-Sql Fast -Disk -RestoreVerify -SuspectPages -MaxDop 1 -MinFreeGB ' + [string]$MinFreeGB)
  if (Get-ScheduledTask -TaskName 'YC-IntegrityBaseline' -ErrorAction SilentlyContinue) { $script:BaselineTaskOk = $true }
  L ('YC-IntegrityBaseline will run once at ' + $when.ToString('yyyy-MM-dd HH:mm') + ' - CHECKDB PHYSICAL_ONLY, chkdsk /scan and a restore verify, out of the window.') 'OK'
  # PHYSICAL_ONLY only means something where the pages already HAVE checksums. SQLHARDEN sets
  # PAGE_VERIFY CHECKSUM, but that protects pages written AFTERWARDS - so on a database that
  # arrived as NONE or TORN_PAGE_DETECTION the fast check can report clean on damaged data. The
  # baseline records what each database arrived as, and the report says where Fast is trustworthy.
  L 'note: CHECKDB PHYSICAL_ONLY is only conclusive for databases that ARRIVED with PAGE_VERIFY CHECKSUM. The adopt report names the ones where it is not.' 'WARN'
  return $(if ($rc -gt 0) { 3 } else { 0 })
}

# ================================================================================================
# PHASE - DISKSCAN.  The NTFS side of the same question.
# chkdsk /scan is ONLINE and READ-ONLY: no dismount, no reboot, no repair. Repair is a decision
# for a human in a change window (boot-repair -ScheduleChkdsk), never something a nightly task does.
# ================================================================================================
# A migration very often lands a virtual disk larger than the partition on it, because the disk
# was grown as part of the move and nobody extended the filesystem. The guest then runs short of
# space on a volume that has plenty of unallocated room sitting behind it.
#
# DETECT AND REPORT by default. Extending a partition on a live customer database server is a
# change, and it is not one to make silently in the middle of an adopt - -GrowDisk opts in.
function Invoke-GrowDiskCheck {
  $gd = Join-Path $ScriptsDir 'Grow-Disk.ps1'
  if (-not (Test-Path -LiteralPath $gd)) { return 0 }
  if ($GrowDisk) {
    L 'extending partitions into adjacent free space (-GrowDisk was given).' 'WARN'
    $c = Invoke-YcCommand -Script 'Grow-Disk.ps1' -Arguments @() -Phase 'DISKSCAN'
    return $(if ($null -eq $c -or $c -ne 0) { 3 } else { 0 })
  }
  $c = Invoke-YcCommand -Script 'Grow-Disk.ps1' -Arguments @('-WhatIf') -Phase 'DISKSCAN' -OkCodes @(0,1,2,3)
  L 'grow-disk ran in report mode - nothing was changed. If it listed a volume that can grow, extend it with  grow-disk  in a change window, or re-run the adopt with -GrowDisk.' 'OK'
  return 0
}

function Invoke-DiskScanTask {
  $yi = Join-Path $ScriptsDir 'Yc-Integrity.ps1'
  if (-not (Test-Path -LiteralPath $yi)) { Flag 'DISKSCAN' 'Yc-Integrity.ps1 is not in the payload, so YC-DiskScan was not registered.'; return 3 }
  if (-not $script:ChadminLogin) { Flag 'DISKSCAN' 'INTERNAL: SQLPREP returned success but set no task identity. YC-DiskScan not registered.'; return 3 }
  # Normalise, do not pass the registrar's code straight out. Every other phase maps its inner
  # codes to 0 or 3; this one returned them raw, so a single registration failure arrived at the
  # dispatch as rc 1 - "fatal, stop the run" - and NOTIFY, VERIFY and the adopt report never ran.
  # On a liability job, losing the report because a scheduled task did not appear is the worst
  # possible trade.
  $rc = Register-YcTask -Name 'YC-DiskScan' -Daily -At '05:15' -Script $yi -Arguments ('-Disk -MinFreeGB ' + [string]$MinFreeGB) -Phase 'DISKSCAN'
  if ($rc -ne 0) { $rc = 3 } else { $rc = 0 }

  # LAST thing in the phase, and deliberately after SQLBACKUP, SQLMAINT and the task registration
  # above have all decided - so what this reports is what the machine will actually do, not what
  # the script intended. These three are the backup path and the data itself; they get the banner.
  $dc = Invoke-DataAndBackupCheck
  if ($dc -ne 0 -and $rc -eq 0) { $rc = 3 }
  return $rc
}

# One registrar for every task this script creates, so none of them can quietly end up running as
# something other than chadmin, and every one is read back before it is reported as registered.
function Register-YcTask {
  param([string]$Name,[switch]$Daily,[switch]$Weekly,[switch]$Once,$At,
        [string]$Script,[string]$Arguments,[string]$Phase = 'SQLMAINT')
  try {
    if (Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue) {
      Flag $Phase ('scheduled task ' + $Name + ' already exists - left exactly as it is. Check it is what you want.')
      return 0
    }
  } catch {}
  try {
    $act = New-ScheduledTaskAction -Execute 'powershell.exe' `
             -Argument ('-NoProfile -ExecutionPolicy Bypass -File "' + $Script + '" ' + $Arguments)
    if     ($Once)   { $trg = New-ScheduledTaskTrigger -Once   -At $At }
    elseif ($Weekly) { $trg = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At ([datetime]::ParseExact($At,'HH:mm',[Globalization.CultureInfo]::InvariantCulture)) }
    else             { $trg = New-ScheduledTaskTrigger -Daily  -At ([datetime]::ParseExact($At,'HH:mm',[Globalization.CultureInfo]::InvariantCulture)) }
    $set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
             -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 8)

    if ($script:UseS4U) {
      $pri = New-ScheduledTaskPrincipal -UserId $script:ChadminLogin -LogonType S4U -RunLevel Highest
      Register-ScheduledTask -TaskName $Name -Action $act -Trigger $trg -Principal $pri -Settings $set -Force -ErrorAction Stop | Out-Null
      $how = 'chadmin via S4U, no stored password'
    } elseif ($ChadminPassword) {
      Register-ScheduledTask -TaskName $Name -Action $act -Trigger $trg -Settings $set `
        -User $script:ChadminLogin -Password $ChadminPassword -RunLevel Highest -Force -ErrorAction Stop | Out-Null
      $how = 'chadmin using the stored credential from -ChadminPassword'
    } else {
      # Never silently fall back to SYSTEM. SQLPREP already refused in this case; this is the
      # belt to that braces, so a future caller cannot reach here and get a SYSTEM task by accident.
      # NOT 1. The dispatch treats rc 1 as "a reboot is pending, stop the run", so returning 1
      # here made a task-registration refusal masquerade as a reboot request: the run stopped at
      # DISKSCAN and NOTIFY and VERIFY never ran, which cost the marker file, the registry stamp,
      # the fleet event and the did-not-change-anything-else diff. 3 is "done, with flags".
      Flag $Phase ($Name + ' NOT registered: S4U is unavailable and no -ChadminPassword was given. Falling back to SYSTEM would widen who is sysadmin, so it is not done.')
      return 3
    }
    if (Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue) {
      L ($Name + ' registered (' + $(if ($Once) {'once at ' + ([datetime]$At).ToString('yyyy-MM-dd HH:mm')} elseif ($Weekly) {'weekly Sunday ' + $At} else {'daily ' + $At}) + ', ' + $how + ') - existence confirmed.') 'OK'
      return 0
    }
    # NOT 1, for the same reason as the SYSTEM branch above: the dispatch treats rc 1 as fatal.
    Flag $Phase ('Register-ScheduledTask returned without error but ' + $Name + ' is not there.')
    return 3
  } catch { Flag $Phase ('could not register ' + $Name + ': ' + $_.Exception.Message); return 3 }
}

# Ola Hallengren, installed the way Install-Sql.ps1 does it - with sqlcmd directly, NOT through
# dbatools' Install-DbaMaintenanceSolution, which has its own version check that refuses engines
# this estate still runs. Two traps are carried over from that code because both have bitten:
#   1. Ola publishes TWO builds. The current one needs STRING_AGG, which is a 2017 built-in, so on
#      an engine older than 2017 it leaves 2 of the 4 procedures behind and NO backups happen.
#   2. The header must be retargeted (@CreateJobs = N) or it creates SQL Agent jobs, which Express
#      does not even have and which would compete with our scheduled tasks.
function Install-Ola {
  param([string]$Target,[string]$Instance)
  $have = Invoke-SqlCmdLocal -Target $Target -Query "SET NOCOUNT ON; SELECT CONVERT(varchar(10),COUNT(*)) FROM DBA.sys.procedures WHERE name IN ('DatabaseBackup','DatabaseIntegrityCheck','IndexOptimize','CommandExecute');"
  $n = 0; [void][int]::TryParse(([string]$have -replace '[^0-9]',''), [ref]$n)
  if ($n -ge 4) { L ($Instance + ': Ola Hallengren is already installed (4 procedures present).') 'OK'; return $true }

  $major = 0
  $v = Invoke-SqlCmdLocal -Target $Target -Query "SET NOCOUNT ON; SELECT CONVERT(varchar(10),SERVERPROPERTY('ProductMajorVersion'));"
  [void][int]::TryParse(([string]$v -replace '[^0-9]',''), [ref]$major)
  $url = $(if ($major -gt 0 -and $major -lt 14) {
            'https://ola.hallengren.com/scripts/sql-server-2008-2016/MaintenanceSolution.sql'
          } else {
            'https://raw.githubusercontent.com/olahallengren/sql-server-maintenance-solution/master/MaintenanceSolution.sql'
          })
  if ($major -gt 0 -and $major -lt 14) { L ($Instance + ': engine major ' + [string]$major + ' is pre-2017, so the 2008-2016 build of MaintenanceSolution.sql is used - the current build needs STRING_AGG and would leave half the procedures behind.') 'WARN' }

  $tmp = Join-Path $env:TEMP ('ola-' + [guid]::NewGuid().ToString('N') + '.sql')
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing -ErrorAction Stop
  } catch { Flag 'SQLMAINT' ($Instance + ': could not download MaintenanceSolution.sql: ' + $_.Exception.Message); return $false }

  $txt = Get-Content -LiteralPath $tmp -Raw
  $bak = Get-OlaBackupDir -Target $Target
  foreach ($pair in @(
      @{ rx='(?m)^SET @CreateJobs\s*=\s*''[YN]''';          to="SET @CreateJobs          = 'N'" },
      @{ rx='(?m)^SET @BackupDirectory\s*=\s*N?''[^'']*''';  to=("SET @BackupDirectory     = N'" + $bak + "'") },
      @{ rx='(?m)^USE \[master\]';                           to='USE [DBA]' })) {
    if ($txt -notmatch $pair.rx) {
      Flag 'SQLMAINT' ($Instance + ': MaintenanceSolution.sql does not contain the expected line to retarget (' + $pair.rx + '). Refusing to run a script this code cannot retarget - it would install into the wrong database or create SQL Agent jobs.')
      Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
      return $false
    }
    $txt = [regex]::Replace($txt, $pair.rx, $pair.to)
  }
  Set-Content -LiteralPath $tmp -Value $txt -Encoding Ascii

  Invoke-SqlCmdLocal -Target $Target -Query "IF DB_ID('DBA') IS NULL CREATE DATABASE [DBA];" | Out-Null
  $exe = Get-SqlCmdPathLocal
  if (-not $exe) { Flag 'SQLMAINT' 'sqlcmd is not on this host, so Ola could not be installed.'; return $false }
  try {
    & $exe -S $Target -E -b -i $tmp 2>&1 | Out-Null
    $code = $LASTEXITCODE
  } catch { Flag 'SQLMAINT' ($Instance + ': sqlcmd -i MaintenanceSolution.sql could not run: ' + $_.Exception.Message); return $false }
  finally { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }

  # PROVE it. install-sql learned this the hard way: it used to log "complete" while the Ola
  # procedures did not exist, leaving scheduled tasks calling procedures that were never created.
  $have2 = Invoke-SqlCmdLocal -Target $Target -Query "SET NOCOUNT ON; SELECT CONVERT(varchar(10),COUNT(*)) FROM DBA.sys.procedures WHERE name IN ('DatabaseBackup','DatabaseIntegrityCheck','IndexOptimize','CommandExecute');"
  $n2 = 0; [void][int]::TryParse(([string]$have2 -replace '[^0-9]',''), [ref]$n2)
  if ($n2 -ge 4) { L ($Instance + ': Ola installed - all 4 procedures confirmed in DBA.') 'OK'; return $true }
  Flag 'SQLMAINT' ($Instance + ': sqlcmd exited ' + [string]$code + ' but only ' + [string]$n2 + ' of the 4 Ola procedures exist in DBA. No maintenance task will work against this instance.')
  return $false
}

function Get-OlaBackupDir {
  param([string]$Target)
  if ($BackupDir) { return $BackupDir }
  $r = Invoke-SqlCmdLocal -Target $Target -Query "SET NOCOUNT ON; SELECT CONVERT(nvarchar(4000),SERVERPROPERTY('InstanceDefaultBackupPath'));"
  if ($r -and ([string]$r).Trim()) { return ([string]$r).Trim() }
  return 'C:\dbbackupdaily'
}

# ================================================================================================
# PHASE 9 - TASKS.  The two recurring jobs that keep this machine current and visible. Installed
# through their OWN commands, because those already read their registration back and already know
# what a correct trigger set looks like on this build. ONLY IF ABSENT.
# ================================================================================================
function Invoke-Tasks {
  param($Survey)
  $have = @()
  try { $have = @($Survey.data.us.ycTasks) } catch {}
  $rc = 0

  if ($have -contains 'YC-AutoUpdate') { L 'YC-AutoUpdate already exists - left alone.' 'OK' }
  else {
    # Keeps C:\Scripts current from the public repo: startup, on network, daily 00:01 with a 30 min
    # random delay so the fleet does not hit raw.githubusercontent.com at the same second.
    $c = Invoke-YcCommand -Script 'Yc-AutoUpdate.ps1' -Arguments @('-Install') -Phase 'TASKS'
    if ($null -eq $c -or $c -ne 0) { $rc = 3 }
  }

  if ($have -contains 'YC-Inventory') { L 'YC-Inventory already exists - left alone.' 'OK' }
  else {
    # -Install collects, writes, PROVES the file and only THEN registers the task - deliberately,
    # after a version that registered first and left hosts with a task that did nothing.
    $c = Invoke-YcCommand -Script 'Report-Inventory.ps1' -Arguments @('-Install','-Tag','migrated') -Phase 'TASKS'
    if ($null -eq $c -or $c -ne 0) { $rc = 3 }
  }
  return $rc
}

# ================================================================================================
# PHASE 10 - NOTIFY.  Say, in three places that outlast this session, that this machine is now
# managed by the YallaCloud scripts: a marker file, a registry stamp an inventory sweep can read,
# and a fleet event.
# ================================================================================================
function Invoke-Notify {
  param($Survey)
  $h = Get-HostNameSafe
  $payload = ''
  $vf = Join-Path $ScriptsDir 'yc-payload-version.txt'
  if (Test-Path -LiteralPath $vf) { $payload = ((Get-Content -LiteralPath $vf -TotalCount 1) -replace '^[^=]*=\s*','').Trim() }

  $marker = [ordered]@{
    schema        = 'ycadopt.marker/1'
    host          = $h
    source        = 'migrated'
    adoptedUtc    = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
    payloadVersion= $payload
    scriptsDir    = $ScriptsDir
    phasesRun     = @($script:Done)
    flags         = @($script:Flags)
    note          = 'This VM was MIGRATED and has been configured with the YallaCloud C-Scripts toolkit. It is on the same payload channel as a freshly deployed VM. Type  yallacloud  for the command catalog.'
  }
  try {
    if (-not (Test-Path -LiteralPath $script:MarkerDir)) { New-Item -ItemType Directory -Path $script:MarkerDir -Force | Out-Null }
    $marker | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $script:Marker -Encoding Ascii
    L ('marker written: ' + $script:Marker) 'OK'
  } catch { Flag 'NOTIFY' ('could not write ' + $script:Marker + ': ' + $_.Exception.Message) }

  # A registry stamp, because that is what an inventory sweep reads without parsing a file.
  try {
    $k = 'HKLM:\SOFTWARE\YallaCloud'
    if (-not (Test-Path -LiteralPath $k)) { New-Item -Path $k -Force | Out-Null }
    New-ItemProperty -Path $k -Name 'Source'         -Value 'migrated'      -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $k -Name 'AdoptedUtc'     -Value $marker.adoptedUtc -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $k -Name 'PayloadVersion' -Value $payload        -PropertyType String -Force | Out-Null
    L 'registry stamp written: HKLM:\SOFTWARE\YallaCloud (Source=migrated)' 'OK'
  } catch { Flag 'NOTIFY' ('could not write the registry stamp: ' + $_.Exception.Message) }

  # The fleet event. yc-event knows how to find out who this VM is and queues to disk when the
  # receiver is unreachable, so a missing event is never silently lost.
  # THE EVENT IS NOT SENT HERE ANY MORE. NOTIFY is phase 16 of 17, so an event sent from here
  # went out before VERIFY had run and before anything knew whether the adoption had worked -
  # it could only ever say "completed", never "completed, and here is what needs a human". It is
  # sent from the verdict instead, where the outcome is known. NOTIFY keeps what is genuinely
  # its job: the marker file and the registry stamp, both of which outlive the session.
  L 'fleet event deferred to the end of the run, where the outcome is known.' 'OK'
  return 0
}

# ================================================================================================
# PHASE 11 - VERIFY.  Rule 4: prove it changed nothing else. The post-survey is diffed against the
# pre-survey and ANY delta outside the set this script is allowed to cause is reported loudly.
# ================================================================================================
function Invoke-Verify {
  param($Pre)
  $post = Invoke-Survey -Label 'post'
  $deltas = New-Object System.Collections.Generic.List[string]

  # Things this script is ALLOWED to change. Anything else that moved is worth a human reading.
  $expected = @('us.fileCount','us.payloadVersion','us.ycTasks','us.onPath','network.hiddenAdapterCount')

  foreach ($pair in @(
      @{ n='identity.caption';  a=$Pre.data.identity.caption;  b=$post.data.identity.caption },
      @{ n='identity.domain';   a=$Pre.data.identity.domain;   b=$post.data.identity.domain },
      @{ n='nic count';         a=@($Pre.data.network.nics).Count;  b=@($post.data.network.nics).Count },
      @{ n='sql instance count';a=@($Pre.data.sql).Count;      b=@($post.data.sql).Count },
      @{ n='antivirus';         a=(@($Pre.data.inherited.antivirus) -join ','); b=(@($post.data.inherited.antivirus) -join ',') },
      @{ n='backup agents';     a=@($Pre.data.inherited.backupAgents).Count;    b=@($post.data.inherited.backupAgents).Count },
      @{ n='non-Microsoft task count'; a=@($Pre.data.inherited.nonMicrosoftTasks).Count; b=@($post.data.inherited.nonMicrosoftTasks).Count }
    )) {
    if ([string]$pair.a -ne [string]$pair.b) { $deltas.Add(($pair.n + ': ' + $pair.a + ' -> ' + $pair.b)) | Out-Null }
  }

  # The task count is expected to rise by exactly the tasks we registered. Anything else is not.
  $added = @(@($post.data.inherited.nonMicrosoftTasks) | Where-Object { @($Pre.data.inherited.nonMicrosoftTasks) -notcontains $_ })
  # Compare on the LEAF name: the task collectors return '\YC-DiskScan' in some places and
  # 'YC-DiskScan' in others, and an anchored '^YC-' never matches the one with the path on it.
  $ours  = @($added | Where-Object { $script:OurTaskNames -contains (($_ -split '\\')[-1]) })
  $theirs= @($added | Where-Object { $script:OurTaskNames -notcontains (($_ -split '\\')[-1]) })
  if ($ours.Count)  { L ('tasks added by this run: ' + ($ours -join ', ')) 'OK' }
  if ($theirs.Count){ Flag 'VERIFY' ('scheduled tasks appeared that this script did not create: ' + ($theirs -join ', ')) }

  $realDeltas = @($deltas | Where-Object { $_ -notmatch '^non-Microsoft task count' })
  if ($realDeltas.Count -eq 0) {
    L 'VERIFY: nothing changed outside the set this script is allowed to change.' 'OK'
    L ('post-survey: ' + $post.path)
    return 0
  }
  foreach ($d in $realDeltas) { Flag 'VERIFY' ('UNEXPECTED CHANGE - ' + $d) }
  L ('post-survey: ' + $post.path)
  return 3
}

# ================================================================================================
# THE VERDICT.  The last thing an operator sees, and for a long time the thing this script did
# not say. A real migrated VM always raises flags - flags are FINDINGS, not failures - so the
# "ADOPTED" line, which only printed when the flag count was zero, was unreachable in practice.
# What an L1 actually saw was eleven WARN lines and "END exit=2", and no way to tell whether the
# machine was adopted or broken. Every exit path now ends here, and it says so in one word.
# ================================================================================================
function Show-AdoptVerdict {
  param([int]$Code,[string]$StoppedAt = '',[string[]]$Missing = @())

  $h     = Get-HostNameSafe
  $ran   = @($script:Done).Count
  $total = @($AllPhases).Count
  $fl    = $script:Flags.Count

  if ($Report)                  { $verdict = 'REPORT ONLY - NOTHING WAS CHANGED'; $col = 'Cyan' }
  elseif ($StoppedAt)           { $verdict = 'DID NOT COMPLETE - STOPPED AT ' + $StoppedAt; $col = 'Red' }
  elseif ($Missing.Count -gt 0) { $verdict = 'PARTIAL RUN - THIS IS NOT AN ADOPTION'; $col = 'Yellow' }
  elseif ($fl -eq 0)            { $verdict = 'ADOPTION COMPLETE - NOTHING NEEDS A HUMAN'; $col = 'Green' }
  else                          { $verdict = 'ADOPTION COMPLETE - ' + [string]$fl + ' ITEM(S) NEED A HUMAN'; $col = 'Yellow' }

  $meaning = switch ($Code) {
    0 { 'everything this run did, worked' }
    1 { 'stopped early - something must happen before it can continue' }
    2 { 'a safety gate REFUSED to do something. That is the gate working, not a crash' }
    3 { 'it finished, and findings above need a person to read them' }
    4 { 'the downloaded payload failed its checksum - nothing was installed' }
    5 { 'not running as administrator' }
    6 { 'no HTTPS route to the payload host' }
    default { 'see the log' }
  }

  Write-Host ''
  Write-Host '================================================================================' -ForegroundColor $col
  Write-Host ('  ' + $verdict) -ForegroundColor $col
  Write-Host '================================================================================' -ForegroundColor $col
  Write-Host ('  host          : ' + $h)
  Write-Host ('  phases run    : ' + [string]$ran + ' of ' + [string]$total + $(if ($Missing.Count) { '   still to do: ' + ($Missing -join ', ') } else { '' }))
  Write-Host ('  findings      : ' + [string]$fl + $(if ($fl) { ' - listed above, nothing in them was guessed at' } else { '' }))
  Write-Host ('  payload       : ' + (Get-PayloadVersion))
  Write-Host ('  exit code     : ' + [string]$Code + '  (' + $meaning + ')')
  Write-Host ''
  Write-Host '  WHAT TO DO NEXT'
  $n = 1
  if ($Report) {
    Write-Host ('   ' + [string]$n + '. Read the survey, then run:  migrated-vm -Run'); $n++
  } else {
    if ($fl)                      { Write-Host ('   ' + [string]$n + '. Read the ' + [string]$fl + ' finding(s) above and decide on each one.'); $n++ }
    if ($Missing.Count -gt 0)     { Write-Host ('   ' + [string]$n + '. Finish the run:  migrated-vm -Run'); $n++ }
    if ($StoppedAt)               { Write-Host ('   ' + [string]$n + '. Fix what the message above describes, then run:  migrated-vm -Run'); $n++ }
    if ($script:RebootNeeded.Count -gt 0) { Write-Host ('   ' + [string]$n + '. REBOOT this machine when the change window allows.'); $n++ }
  }
  Write-Host ('   ' + [string]$n + '. Full log      : ' + (Join-Path $ScriptsDir 'adopt-migrated-vm.log')); $n++
  Write-Host ('   ' + [string]$n + '. As-received   : ' + (Join-Path $ScriptsDir 'baseline_beforemigration.log')); $n++
  Write-Host ('   ' + [string]$n + '. Read it again : migrated-vm -Status')
  if ((-not $Report) -and (-not $StoppedAt) -and $Missing.Count -eq 0) {
    Write-Host ''
    Write-Host '  This VM is on the same payload channel as a freshly deployed one.'
    Write-Host '  Type  yallacloud  for the command catalog.'
  }
  Write-Host '================================================================================' -ForegroundColor $col
  Write-Host ''
  # Also into the log, so the verdict survives the console being closed.
  L ('VERDICT: ' + $verdict + '  |  phases ' + [string]$ran + '/' + [string]$total + '  |  findings ' + [string]$fl + '  |  exit ' + [string]$Code) $(if ($col -eq 'Red') { 'ERROR' } elseif ($col -eq 'Green') { 'OK' } else { 'WARN' })

  # --- and tell somebody who is not standing at this console -----------------------------------
  # -Report changed nothing, so it is not news. Everything else is.
  if ($Report) { return }
  Send-AdoptNotification -Code $Code -Verdict $verdict -StoppedAt $StoppedAt -Missing $Missing
}

# ================================================================================================
# THE ADOPT REPORT.  Two files, same facts:
#
#   adopt-report.json   for anything that reads machines
#   adopt-report.txt    for a person, in plain language, with no jargon it can avoid
#
# It answers three questions and nothing else:
#   1. Which protections are actually WIRED on this machine, and which are not?
#   2. Are the databases good or bad - and if bad, WHEN did that start?
#   3. Are the volumes good or bad?
#
# Question 2 is the one that matters commercially. A migration copies blocks faithfully, broken
# ones included, so a database that was damaged before the move is damaged after it. When the
# customer asks whether the migration caused it, this file is the answer, and the dates in it
# were written by SQL Server and by Windows - not by us.
# ================================================================================================
function Write-AdoptReport {
  $h    = Get-HostNameSafe
  $json = Join-Path $ScriptsDir 'adopt-report.json'
  $txt  = Join-Path $ScriptsDir 'adopt-report.txt'
  $now  = (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss') + ' UTC'

  # --- what is wired ---------------------------------------------------------------------------
  # Read back from the machine, never assumed from "the phase returned 0".
  $tasks = @{}
  foreach ($t in $script:OurTaskNames) {
    $st = $null
    try { $st = Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue } catch {}
    if ($st) {
      $who = ''
      try { $who = [string]$st.Principal.UserId + ' / ' + [string]$st.Principal.LogonType } catch {}
      $tasks[$t] = [ordered]@{ wired=$true; runsAs=$who }
    } else { $tasks[$t] = [ordered]@{ wired=$false; runsAs='' } }
  }

  $features = [ordered]@{
    'daily disk check (chkdsk /scan, read-only)'      = $tasks['YC-DiskScan'].wired
    'daily SQL page check + damaged-page watch'       = $tasks['YC-SqlIntegrityFast'].wired
    'weekly full SQL consistency check'               = $tasks['YC-SqlIntegrity'].wired
    'weekly restore verification'                     = $tasks['YC-SqlRestoreVerify'].wired
    'one-off baseline check after adopt'              = $tasks['YC-IntegrityBaseline'].wired
    'payload stays current (auto-update)'             = $tasks['YC-AutoUpdate'].wired
    'inventory reporting'                             = $tasks['YC-Inventory'].wired
    'YallaCloud owns SQL backups'                     = $script:BackupOwned
  }

  # --- are the databases good or bad -----------------------------------------------------------
  $dbVerdict = 'GOOD'; $dbWhy = 'no damaged pages on record'
  $tot = 0; $first = ''; $capped = $false
  foreach ($e in $script:Evidence['sql']) {
    $tot += [int]$e.suspectPages.totalPages
    if ($e.suspectPages.capped) { $capped = $true }
    $d = [string]$e.suspectPages.earliest
    if ($d -and ((-not $first) -or ($d -lt $first))) { $first = $d }
  }
  if ($tot -gt 0) {
    $dbVerdict = 'BAD'
    $dbWhy = [string]$tot + ' damaged page(s) on record, first seen ' + $(if ($first) { $first } else { 'date unknown' })
  }
  $never = @($script:Evidence['lastKnownGood'] | Where-Object { $_.neverChecked })
  if ($dbVerdict -eq 'GOOD' -and $never.Count) {
    $dbVerdict = 'UNPROVEN'
    $dbWhy = 'no damaged pages on record, but ' + [string]$never.Count + ' database(s) have never had a consistency check complete cleanly, so "good" is unproven'
  }

  # --- are the volumes good or bad -------------------------------------------------------------
  # Only the NTFS dirty bit and PROVIDER-ATTRIBUTED corruption events decide this. A raw count of
  # everything a storage driver has ever logged says SUSPECT on a perfectly healthy machine
  # (measured: 133 events, 89 of them VSS running out of disk space), and a verdict that is always
  # SUSPECT proves nothing to anybody. Everything else stays in the JSON under volumes.otherEvents.
  $volVerdict = 'GOOD'; $volWhy = 'no dirty bit, and no filesystem or disk corruption events on record'
  # 'YES - Windows has already decided this volume needs repair' is what the fsutil probe writes;
  # '(unreadable)' means the probe itself failed and is NOT evidence of a clean volume.
  $dirty = @(); $undetermined = @()
  try {
    $dirty        = @($script:Evidence['volumes'] | Where-Object { [string]$_.dirty -like 'YES*' })
    $undetermined = @($script:Evidence['volumes'] | Where-Object { [string]$_.dirty -eq '(unreadable)' })
  } catch {}
  $corrupt = @(); $corruptCount = 0; $corruptFirst = ''
  try {
    $corrupt = @($script:Evidence['events'].corruption)
    foreach ($r in $corrupt) { $corruptCount += [int]$r.count }
    $cf = @($corrupt | ForEach-Object { $_.first } | Sort-Object)
    if ($cf.Count) { $corruptFirst = $cf[0] }
  } catch {}
  $otherCount = 0
  try { foreach ($r in @($script:Evidence['events'].storage)) { $otherCount += [int]$r.count } } catch {}
  $otherCount = $otherCount - $corruptCount
  if ($otherCount -lt 0) { $otherCount = 0 }
  if ($dirty.Count) {
    $volVerdict = 'BAD'
    $volWhy = 'NTFS dirty bit set on ' + [string]$dirty.Count + ' volume(s) - Windows itself says this filesystem was not shut down cleanly and has not been checked since'
    if ($corruptCount) { $volWhy += ', and ' + [string]$corruptCount + ' corruption event(s) on record, first seen ' + $corruptFirst }
  } elseif ($corruptCount) {
    $volVerdict = 'SUSPECT'
    $volWhy = [string]$corruptCount + ' filesystem/disk corruption event(s) on record, first seen ' + $corruptFirst + ', but no dirty bit set'
  } elseif ($undetermined.Count) {
    $volVerdict = 'UNPROVEN'
    $volWhy = 'no corruption events on record, but the dirty bit could not be read on ' + [string]$undetermined.Count + ' volume(s), so a clean filesystem has not actually been established'
  }
  if ($volVerdict -ne 'UNPROVEN' -and $undetermined.Count) {
    $volWhy += '. The dirty bit was unreadable on ' + [string]$undetermined.Count + ' volume(s).'
  }

  $obj = [ordered]@{
    schema         = 'ycadopt.report/1'
    host           = $h
    generatedUtc   = $now
    payload        = (Get-PayloadVersion)
    phasesRun      = @($script:Done)
    findings       = @($script:Flags)
    featuresWired  = $features
    tasks          = $tasks
    databases      = [ordered]@{ verdict=$dbVerdict; reason=$dbWhy; damagedPages=$tot; firstSeen=$first; countIsCapped=$capped }
    dataAndBackup  = [ordered]@{
                       # The three that decide whether the data survives. Verdicts, not prose.
                       sqlIntegrity = $script:Evidence['sqlIntegrity']
                       chkdsk       = $script:Evidence['chkdsk']
                       vss          = $script:Evidence['vss']
                     }
    databaseInventory = @($script:Evidence['databases'])
    guestPlatform  = [ordered]@{
                       # WHAT THIS MACHINE IS, and what agent that platform calls for.
                       platform            = $(if ($script:Evidence['platform']) { $script:Evidence['platform'].platform } else { '' })
                       expectedAgent       = $(if ($script:Evidence['platform']) { $script:Evidence['platform'].expectedAgent } else { '' })
                       detection           = $script:Evidence['platform']
                       # AS RECEIVED, captured at SURVEY before TOOLS could change anything.
                       guestAgentOnArrival = $script:Evidence['guestAgent']
                       # AS IT IS NOW, after TOOLS. Absent on a -Report pass, which changes nothing.
                       guestAgentNow       = $script:GuestAgentAfter
                       virtio              = $script:Evidence['virtio']
                       leftovers           = $(if ($script:Evidence['platform']) { @($script:Evidence['platform'].leftovers) } else { @() })
                     }
    volumes        = [ordered]@{ verdict=$volVerdict; reason=$volWhy
                                 dirtyVolumes=@($dirty | ForEach-Object { $_.drive })
                                 dirtyBitUnreadableOn=@($undetermined | ForEach-Object { $_.drive })
                                 volumes=@($script:Evidence['volumes'])
                                 corruptionEvents=@($corrupt); corruptionCount=$corruptCount
                                 corruptionFirstSeen=$corruptFirst; otherStorageEventCount=$otherCount }
    evidence       = $script:Evidence
    note           = 'Dates under evidence were written by SQL Server and by Windows on the source platform. Anything dated before generatedUtc existed before YallaCloud ran on this machine.'
  }
  try { ($obj | ConvertTo-Json -Depth 8) | Set-Content -LiteralPath $json -Encoding Ascii; L ('report written: ' + $json) 'OK' }
  catch { Flag 'VERIFY' ('could not write ' + $json + ': ' + $_.Exception.Message) }

  # --- the same thing, for a person -------------------------------------------------------------
  $p = New-Object System.Collections.Generic.List[string]
  $null = $p.Add('================================================================================')
  $null = $p.Add('  WHAT THIS MACHINE HAS, AND WHETHER ITS DATA IS HEALTHY')
  $null = $p.Add('================================================================================')
  $null = $p.Add('  machine   : ' + $h)
  $null = $p.Add('  written   : ' + $now)
  $null = $p.Add('  toolkit   : ' + (Get-PayloadVersion))
  $null = $p.Add('')
  $vss = $script:Evidence['vss']; $ckd = $script:Evidence['chkdsk']; $sqi = $script:Evidence['sqlIntegrity']
  if ($vss -or $ckd -or $sqi) {
    $null = $p.Add('--- THE THREE THINGS THAT DECIDE WHETHER THE DATA SURVIVES ---------------------')
    $null = $p.Add('  Read these together. Any one of them alone is a problem; all three at once is the')
    $null = $p.Add('  situation where the data is damaged and there is no good copy of it.')
    $null = $p.Add('')
    foreach ($row in @(
        @{ n='IS THE DATA ITSELF SOUND?   (SQL integrity)'; s=$sqi },
        @{ n='HAS THE FILESYSTEM BEEN CHECKED?  (chkdsk)';  s=$ckd },
        @{ n='CAN A BACKUP ACTUALLY FREEZE IT?  (VSS)';     s=$vss })) {
      if (-not $row.s) { continue }
      $mark = $(if ($row.s.verdict -eq 'OK') { '  ' } else { '!!' })
      $null = $p.Add($mark + ' ' + $row.n)
      $null = $p.Add('     answer : ' + $row.s.verdict)
      foreach ($w in @(($row.s.why -split '(?<=\.) ') | Where-Object { $_.Trim() })) {
        $null = $p.Add('     ' + $w.Trim())
      }
      $null = $p.Add('')
    }
    if ($vss -and @($vss.findings).Count) {
      $null = $p.Add('  WHAT VSS ITSELF REPORTED:')
      foreach ($f in @($vss.findings)) {
        $null = $p.Add(('    [{0}] {1} - {2}' -f $f.severity, $f.area, $f.subject))
        $null = $p.Add('       ' + $f.detail)
        if ($f.remedy) { $null = $p.Add('       FIX: ' + $f.remedy) }
      }
      $null = $p.Add('')
    }
    if ($ckd) {
      if ($ckd.lastRun) { $null = $p.Add('  last chkdsk on this machine : ' + $ckd.lastRun) }
      else              { $null = $p.Add('  last chkdsk on this machine : NO RECORD - there is no evidence one has ever run') }
      $null = $p.Add('  daily read-only scan wired  : ' + $(if ($ckd.scanScheduled) { 'YES (YC-DiskScan)' } else { 'no' }))
      $null = $p.Add('')
    }
  }
  $null = $p.Add('--- IS THE DATABASE HEALTHY? ---------------------------------------------------')
  $null = $p.Add('  answer    : ' + $dbVerdict)
  $null = $p.Add('  because   : ' + $dbWhy)
  if ($tot -gt 0) {
    $null = $p.Add('')
    $null = $p.Add('  WHAT THIS MEANS, PLAINLY:')
    $null = $p.Add('  SQL Server keeps its own list of pages it could not read properly. That list')
    $null = $p.Add('  is not empty on this machine, and the dates on it come from SQL Server, not')
    $null = $p.Add('  from us.')
    $null = $p.Add('')
    if ($first) {
      $null = $p.Add('  The FIRST bad page was recorded on ' + $first + '.')
      $null = $p.Add('  This report was written on ' + $now + '.')
      $null = $p.Add('  If the migration happened after ' + $first + ', then the damage already')
      $null = $p.Add('  existed before the move. A migration copies the data exactly as it finds it,')
      $null = $p.Add('  including the parts that are already broken, so damage that was there before')
      $null = $p.Add('  is still there after. It did not start here.')
    }
    if ($capped) {
      $null = $p.Add('')
      $null = $p.Add('  NOTE: SQL Server stops adding to that list at 1000 entries. The list is full,')
      $null = $p.Add('  so the real number of bad pages is higher than 1000 and is not known, and the')
      $null = $p.Add('  first date above is the earliest one STILL ON THE LIST - the real first')
      $null = $p.Add('  occurrence may be older.')
    }
    foreach ($e in $script:Evidence['sql']) {
      foreach ($r in $e.suspectPages.rows) {
        $null = $p.Add('')
        $null = $p.Add(('  database "{0}": {1} bad page(s), first {2}, last {3}' -f $r.database, $r.pages, $r.firstSeen, $r.lastSeen))
      }
    }
  }
  if ($never.Count) {
    $null = $p.Add('')
    $null = $p.Add('  These databases have NEVER passed a full consistency check, on this platform')
    $null = $p.Add('  or the one before it, so nobody has ever confirmed they are undamaged:')
    foreach ($n in $never) { $null = $p.Add('    - ' + $n.database) }
  }
  $null = $p.Add('')
  $null = $p.Add('--- IS THE DISK HEALTHY? -------------------------------------------------------')
  $null = $p.Add('  answer    : ' + $volVerdict)
  $null = $p.Add('  because   : ' + $volWhy)
  $null = $p.Add('  note      : this machine uses a virtual disk, so there is no physical drive to')
  $null = $p.Add('              test. What can be checked is the filesystem and what Windows has')
  $null = $p.Add('              already logged about it, and that is what is above.')
  if ($corrupt.Count) {
    $null = $p.Add('')
    $null = $p.Add('  WHAT WINDOWS ITSELF LOGGED, with the dates it logged them:')
    foreach ($r in $corrupt) {
      $null = $p.Add(('    {0} event {1} ({2}) x{3}   first {4}   last {5}' -f `
                      $r.provider, $r.id, $r.level, $r.count, $r.first, $r.last))
    }
    $null = $p.Add('')
    $null = $p.Add('  The FIRST of these was logged on ' + $corruptFirst + '. If the migration')
    $null = $p.Add('  happened after that date, the filesystem was already damaged before the move.')
  }
  if ($otherCount) {
    $null = $p.Add('')
    $null = $p.Add('  There are also ' + [string]$otherCount + ' other storage-related event(s) in the log that are')
    $null = $p.Add('  NOT corruption - things like backup snapshots running out of space. They are')
    $null = $p.Add('  listed in adopt-report.json so nothing is hidden, but they do not mean the')
    $null = $p.Add('  data is damaged and they are not counted in the answer above.')
  }
  $null = $p.Add('')
  $null = $p.Add('--- WHAT IS ON THIS INSTANCE, AND HOW BIG ---------------------------------------')
  $dbRows = @($script:Evidence['databases'])
  if (-not $dbRows.Count) { $null = $p.Add('  not measured on this run') }
  else {
    $tot = 0.0
    $null = $p.Add('  database                          size MB   recovery  page_verify  ever CHECKDB''d')
    foreach ($d in @($dbRows | Sort-Object { -[double]($_.sizeMB -replace '[^0-9.]','') })) {
      $sz = 0.0; [void][double]::TryParse(($d.sizeMB -replace '[^0-9.]',''), [ref]$sz); $tot += $sz
      $lkg = @($script:Evidence['lastKnownGood'] | Where-Object { $_.database -eq $d.database }) | Select-Object -First 1
      $ck  = if (-not $lkg) { '?' } elseif ($lkg.neverChecked) { 'NEVER' } else { 'yes' }
      $null = $p.Add(('  {0,-30} {1,10}   {2,-8}  {3,-11}  {4}' -f $d.database, $d.sizeMB, $d.recovery, $d.pageVerify, $ck))
    }
    $null = $p.Add(('  {0,-30} {1,10}' -f 'TOTAL', [math]::Round($tot,1)))
    $null = $p.Add('')
    # Size is not trivia: a restore test and a full CHECKDB both need room for a second copy.
    # YC-SqlRestoreVerify is registered on this box, so if the biggest database does not fit in
    # the free space it will fail every week and somebody will eventually stop reading it.
    $big = @($dbRows | Sort-Object { -[double]($_.sizeMB -replace '[^0-9.]','') }) | Select-Object -First 1
    $bigGB = 0.0; if ($big) { $x=0.0; [void][double]::TryParse(($big.sizeMB -replace '[^0-9.]',''), [ref]$x); $bigGB=[math]::Round($x/1024,1) }
    $freeGB = 0.0
    try { $freeGB = [double](@($script:Evidence['volumes'] | Where-Object { $_.drive -eq 'C:' } | ForEach-Object { $_.freeGB }) | Select-Object -First 1) } catch {}
    if ($big -and $freeGB -gt 0) {
      $null = $p.Add('  CAN A RESTORE TEST OR A FULL CHECKDB ACTUALLY RUN HERE?')
      $null = $p.Add('    biggest database : ' + $big.database + '  ' + [string]$bigGB + ' GB')
      $null = $p.Add('    free space on C: : ' + [string]$freeGB + ' GB')
      if ($bigGB -gt $freeGB) {
        $null = $p.Add('    answer           : NO. Restoring it needs a second copy and there is not room')
        $null = $p.Add('                       for one. The weekly restore verification will fail on this')
        $null = $p.Add('                       database every time until it has somewhere else to restore to.')
        Flag 'SQLMAINT' ('the largest database (' + $big.database + ', ' + [string]$bigGB + ' GB) does not fit in the free space on C: (' + [string]$freeGB + ' GB), so a restore test of it cannot run on this volume. Give it another target or more space, or the weekly restore verification will keep failing on it.')
      } else {
        $null = $p.Add('    answer           : yes, it fits on this volume')
      }
    }
  }
  $null = $p.Add('')
  $null = $p.Add('--- IS THE GUEST PLATFORM RIGHT? -----------------------------------------------')
  $pl = $script:Evidence['platform']
  $ga = $script:GuestAgentAfter; if (-not $ga -and $pl) { $ga = $pl.agent }
  $vi = $script:Evidence['virtio']
  if (-not $pl) { $null = $p.Add('  not measured on this run') }
  else {
    $null = $p.Add('  this machine is : ' + $pl.platform + '  (' + $pl.platformWhy + ')')
    $null = $p.Add('                    Manufacturer "' + $pl.manufacturer + '"  Model "' + $pl.model + '"')
    $null = $p.Add('  it should have  : ' + $pl.expectedAgent)
    if ($ga) {
      $mark = $(if ($ga.verdict -in @('OK','NOT-APPLICABLE')) { '  ' } else { '!!' })
      $null = $p.Add($mark + ' agent         : ' + $ga.verdict + ' - ' + $ga.why)
      if ($ga.version)    { $null = $p.Add('     version    : ' + $ga.version) }
      if ($ga.pinPackage) { $null = $p.Add('     pinned     : ' + $ga.pinPackage + '  (' + $ga.pinTrack + ' track - ' + $ga.pinReason + ')') }
      if ($ga.versusPin -and $ga.versusPin -ne 'unknown') { $null = $p.Add('     vs the pin : ' + $ga.versusPin) }
      $arr = $(if ($pl) { $pl.agent } else { $null })
      if ($arr -and $arr.verdict -ne $ga.verdict) { $null = $p.Add('     on arrival it was ' + $arr.verdict + ' - ' + $arr.why) }
    }
    if ($pl.platform -eq 'KVM' -and $vi) {
      $mark = $(if ($vi.verdict -eq 'OK') { '  ' } else { '!!' })
      $null = $p.Add($mark + ' virtio        : ' + $vi.verdict + ' - ' + $vi.why)
      foreach ($r in @($vi.drivers)) { $null = $p.Add(('     {0,-10} {1,-22} {2}' -f $r.driver, $r.fileVersion, $r.state)) }
      if ($vi.verdict -eq 'DIFFERS') {
        $null = $p.Add('     This is NOT changed by the adopt. Replacing a storage driver is a reboot')
        $null = $p.Add('     and a risk of its own, so it belongs in a change window. It also means')
        $null = $p.Add('     the driver was already this old when the VM arrived.')
      }
    } elseif ($pl.platform -eq 'VMWARE' -and $ga -and @($ga.drivers).Count) {
      $null = $p.Add('     VMware drivers present: ' + (@($ga.drivers) -join ', '))
    }
    if (@($pl.leftovers).Count) {
      $null = $p.Add('')
      $null = $p.Add('  LEFT OVER FROM THE PLATFORM THIS VM CAME FROM:')
      foreach ($x in @($pl.leftovers)) { $null = $p.Add('    - ' + $x) }
    }
    $null = $p.Add('')
    $null = $p.Add('  Why this matters: snapshot backups on this estate are AGENTLESS - they ask the')
    $null = $p.Add('  guest agent to freeze the machine. If the right agent is missing or stopped, a')
    $null = $p.Add('  snapshot of a database is crash-consistent, and nothing says so at the time.')
  }
  $null = $p.Add('')
  $null = $p.Add('--- WHAT IS SWITCHED ON --------------------------------------------------------')
  foreach ($k in $features.Keys) {
    $null = $p.Add(('  {0,-48} {1}' -f $k, $(if ($features[$k]) { 'YES' } else { 'no' })))
  }
  $off = @($features.Keys | Where-Object { -not $features[$_] })
  if ($off.Count) {
    $null = $p.Add('')
    $null = $p.Add('  The "no" lines above are NOT failures by themselves - several are switched off')
    $null = $p.Add('  deliberately, for reasons listed under WHAT NEEDS A PERSON below.')
  }
  $null = $p.Add('')
  $null = $p.Add('--- WHAT NEEDS A PERSON --------------------------------------------------------')
  if (-not $script:Flags.Count) { $null = $p.Add('  nothing') }
  else { foreach ($f in $script:Flags) { $null = $p.Add('  - ' + $f) } }
  $null = $p.Add('')
  $null = $p.Add('--- PROOF THIS FILE HAS NOT BEEN CHANGED ---------------------------------------')
  $null = $p.Add('  The as-received record is  baseline_beforemigration.log  beside this file.')
  $null = $p.Add('  Its SHA256 when it was written:')
  $null = $p.Add('    ' + $(if ($script:Evidence['baselineSha256']) { $script:Evidence['baselineSha256'] } else { '(not captured)' }))
  $null = $p.Add('  The same hash is in adopt-report.json and in the notification sent off this')
  $null = $p.Add('  machine at the time. If the baseline is ever disputed, compare the hash.')
  $null = $p.Add('================================================================================')
  try { ($p -join "`r`n") | Set-Content -LiteralPath $txt -Encoding Ascii; L ('report written: ' + $txt) 'OK' }
  catch { Flag 'VERIFY' ('could not write ' + $txt + ': ' + $_.Exception.Message) }
}

# ================================================================================================
# THE NOTIFICATION.  yc-event owns the ntfy channel, its config and its retry queue, so this
# composes the message and hands it over rather than posting anywhere itself.
#
# WHAT A PHONE ACTUALLY SHOWS is the title, the priority and the first line or two. So the title
# carries the verdict and the hostname, the priority says whether it is worth waking up for, and
# the body is a short aligned block rather than one run-on line.
#   5  did not complete            - gets past Do Not Disturb
#   4  completed, findings to read - high, no alarm
#   3  completed clean             - default
# ================================================================================================
function Send-AdoptNotification {
  param([int]$Code,[string]$Verdict,[string]$StoppedAt = '',[string[]]$Missing = @())

  $h  = Get-HostNameSafe
  $fl = $script:Flags.Count

  if ($StoppedAt)               { $type='vm.adopt.failed';   $pri='5'; $tag='rotating_light';   $short='FAILED at ' + $StoppedAt }
  elseif ($Missing.Count -gt 0) { $type='vm.adopt.partial';  $pri='4'; $tag='warning';          $short='PARTIAL ' + [string]@($script:Done).Count + '/' + [string]@($AllPhases).Count }
  elseif ($fl -gt 0)            { $type='vm.adopt.findings'; $pri='4'; $tag='warning';          $short=[string]$fl + ' to read' }
  else                          { $type='vm.adopt.ok';       $pri='3'; $tag='white_check_mark'; $short='clean' }

  $lines = @()
  $lines += ($h + ' - ' + $Verdict)
  $lines += ('phases   : ' + [string]@($script:Done).Count + ' of ' + [string]@($AllPhases).Count)
  $lines += ('findings : ' + [string]$fl + $(if ($fl) { ' need a human' } else { ' - nothing to read' }))
  $lines += ('payload  : ' + (Get-PayloadVersion))
  $lines += ('exit     : ' + [string]$Code)
  if ($script:RebootNeeded.Count -gt 0) { $lines += 'reboot   : REQUIRED' }
  if ($Missing.Count -gt 0)             { $lines += ('still    : ' + ($Missing -join ' ')) }
  # The guest platform goes on the phone, not just in the log: a guest agent that is not running
  # means the snapshot backups are not freezing this machine, and that is worth waking somebody.
  $ga = $script:GuestAgentAfter; if (-not $ga) { $ga = $script:Evidence['guestAgent'] }
  $vi = $script:Evidence['virtio']
  # These three go NEAR THE TOP of the notification, before the platform line: a damaged
  # database whose backups cannot snapshot is the message, and a phone shows about eight lines.
  $sqi = $script:Evidence['sqlIntegrity']; $ckd = $script:Evidence['chkdsk']; $vss = $script:Evidence['vss']
  if ($sqi -and $sqi.verdict -ne 'OK') { $lines += ('SQL DATA : ' + $sqi.verdict + $(if ($sqi.damagedPages) { ' - ' + [string]$sqi.damagedPages + ' damaged page(s)' } else { '' })) }
  if ($ckd -and $ckd.verdict -ne 'OK') { $lines += ('FILESYS  : ' + $ckd.verdict + $(if (@($ckd.dirtyVolumes).Count) { ' - dirty bit on ' + (@($ckd.dirtyVolumes) -join ',') } else { '' })) }
  if ($vss -and $vss.verdict -ne 'OK') { $lines += ('BACKUP   : ' + $vss.verdict + $(if ($vss.critical) { ' - ' + [string]$vss.critical + ' CRITICAL VSS finding(s), snapshots are NOT consistent' } else { '' })) }
  $pl = $script:Evidence['platform']
  if ($pl) { $lines += ('platform : ' + $pl.platform) }
  if ($ga -and $ga.verdict -notin @('OK','NOT-APPLICABLE')) { $lines += ('AGENT    : ' + $ga.verdict + ' - snapshot backups cannot freeze this VM') }
  elseif ($ga)                                              { $lines += 'agent    : running' }
  if ($pl -and @($pl.leftovers).Count)                      { $lines += ('LEFTOVER : ' + [string]@($pl.leftovers).Count + ' from the source platform') }
  if ($vi -and $vi.verdict -eq 'DIFFERS')              { $lines += ('VIRTIO   : NOT at pin ' + $vi.pinPackage) }
  elseif ($vi -and $vi.verdict -eq 'UNPROVEN')         { $lines += 'VIRTIO   : version unreadable' }
  elseif ($vi -and $vi.verdict -eq 'OK')               { $lines += ('virtio   : at pin ' + $vi.pinPackage) }
  # Raise the priority on a clean-looking run that nevertheless has one of these wrong, so it is
  # not delivered as a quiet "all good".
  # Any of the three data answers being bad outranks a clean phase count. A run where every
  # phase succeeded on a machine whose data is damaged and whose backups cannot snapshot is not
  # a success notification, and must never arrive looking like one.
  if (($sqi -and $sqi.verdict -eq 'BAD') -or ($ckd -and $ckd.verdict -eq 'BAD') -or ($vss -and $vss.verdict -eq 'BROKEN')) {
    $pri = '5'; $tag = 'rotating_light'
    $short = 'DATA OR BACKUP IS BROKEN'
  } elseif ($pri -eq '3' -and (($ga -and $ga.verdict -notin @('OK','NOT-APPLICABLE')) -or ($vi -and $vi.verdict -in @('DIFFERS','UNPROVEN')) -or ($sqi -and $sqi.verdict -ne 'OK') -or ($ckd -and $ckd.verdict -ne 'OK') -or ($vss -and $vss.verdict -ne 'OK'))) {
    $pri = '4'; $tag = 'warning'; $short = 'needs a look'
  }
  # The first two findings, trimmed. A phone cannot show eleven, and a notification that has to
  # be opened to learn anything is a notification nobody opens.
  $n = 0
  foreach ($f in $script:Flags) {
    if ($n -ge 2) { break }
    $t = [string]$f
    if ($t.Length -gt 90) { $t = $t.Substring(0,90) + '...' }
    $lines += ('  - ' + $t)
    $n++
  }
  if ($fl -gt 2) { $lines += ('  ... and ' + [string]($fl - 2) + ' more, in the log') }
  $lines += ('log      : ' + (Join-Path $ScriptsDir 'adopt-migrated-vm.log'))

  $title = 'ADOPT ' + $(if ($StoppedAt -or $Missing.Count) { $short } elseif ($fl) { 'OK - ' + $short } else { 'OK' }) + ' - ' + $h

  $args = @('-Type',$type,'-Step',('ADOPT ' + ($script:Done -join '+')),
            '-NtfyTitle',$title,'-NtfyPriority',$pri,'-NtfyTags',$tag)
  foreach ($l in $lines) { $args += '-NtfyLine'; $args += $l }
  if ($StoppedAt) { $args += '-FailedStep'; $args += $StoppedAt }

  # --- the same facts, STRUCTURED, so they leave the VM ----------------------------------------
  # The ntfy lines above are for a human on a phone. These are for whatever collects the fleet
  # events - ychook next. -Field is Yc-Event's own extension point for exactly this: its comment
  # says "anything new to report goes HERE first; a field only earns a top-level place once it is
  # proven and permanent. The receiver never waits on a payload release to start collecting
  # something." So no new emitter and no schema change on either side.
  #
  # WHY IT MATTERS THAT THESE LEAVE THE MACHINE: adopt-report.json lives on the VM whose data is
  # being disputed. A copy that left the machine on the day of the adopt, with the dates on it,
  # is worth considerably more than one that has sat on the box ever since.
  $f = @()
  $f += ('adoptReport=' + (Join-Path $ScriptsDir 'adopt-report.json'))
  $f += ('phasesDone=' + [string]@($script:Done).Count + '/' + [string]@($AllPhases).Count)
  $f += ('findings=' + [string]$fl)
  if ($script:Evidence['baselineSha256']) { $f += ('baselineSha256=' + $script:Evidence['baselineSha256']) }
  if ($sqi) { $f += ('sqlIntegrity=' + $sqi.verdict)
              if ($sqi.damagedPages) { $f += ('sqlDamagedPages=' + [string]$sqi.damagedPages) }
              if ($sqi.lastSeen)     { $f += ('sqlDamageLastSeen=' + $sqi.lastSeen) }
              if (@($sqi.neverChecked).Count) { $f += ('sqlNeverCheckdb=' + [string]@($sqi.neverChecked).Count) } }
  if ($ckd) { $f += ('chkdsk=' + $ckd.verdict)
              if (@($ckd.dirtyVolumes).Count) { $f += ('dirtyBitOn=' + (@($ckd.dirtyVolumes) -join ',')) }
              if ($ckd.lastRun) { $f += ('chkdskLastRun=' + $ckd.lastRun) } }
  if ($vss) { $f += ('vss=' + $vss.verdict); $f += ('vssCritical=' + [string]$vss.critical); $f += ('vssWarn=' + [string]$vss.warn) }
  if ($pl) {
    $f += ('platform=' + $pl.platform)
    $f += ('expectedAgent=' + $pl.expectedAgent)
    foreach ($x in @($pl.leftovers)) { $f += ('leftover=' + $x) }
  }
  if ($ga) {
    $f += ('guestAgent=' + $ga.verdict)
    if ($ga.pinPackage) { $f += ('guestAgentPin=' + $ga.pinPackage); $f += ('guestAgentVsPin=' + $ga.versusPin) }
    if ($ga.service) { $f += ('guestAgentService=' + $ga.service + ':' + $ga.status) }
    if ($ga.version) { $f += ('guestAgentVersion=' + $ga.version) }
    $arr = $script:Evidence['guestAgent']
    if ($arr) { $f += ('guestAgentOnArrival=' + $arr.verdict) }
  }
  if ($vi) {
    $f += ('virtio=' + $vi.verdict)
    $f += ('virtioPin=' + $vi.pinPackage)
    foreach ($r in @($vi.drivers | Where-Object { $_.state -eq 'DIFFERS-FROM-PIN' })) {
      $f += ('virtioOld=' + $r.driver + ':' + $r.fileVersion)
    }
  }
  # The two verdicts the dispute turns on. Read back from the report we just wrote, so the event
  # and the file cannot disagree - computing them twice is how they drift.
  try {
    $rp = Join-Path $ScriptsDir 'adopt-report.json'
    if (Test-Path -LiteralPath $rp) {
      $rj = Get-Content -LiteralPath $rp -Raw | ConvertFrom-Json
      if ($rj.databases) {
        $f += ('dbVerdict=' + [string]$rj.databases.verdict)
        if ($rj.databases.damagedPages) { $f += ('dbDamagedPages=' + [string]$rj.databases.damagedPages) }
        if ($rj.databases.firstSeen)    { $f += ('dbDamageFirstSeen=' + [string]$rj.databases.firstSeen) }
      }
      if ($rj.volumes) {
        $f += ('diskVerdict=' + [string]$rj.volumes.verdict)
        if ($rj.volumes.corruptionCount)     { $f += ('diskCorruptionEvents=' + [string]$rj.volumes.corruptionCount) }
        if ($rj.volumes.corruptionFirstSeen) { $f += ('diskCorruptionFirstSeen=' + [string]$rj.volumes.corruptionFirstSeen) }
      }
    }
  } catch { L ('could not read the report back for the fleet event: ' + $_.Exception.Message) 'WARN' }
  foreach ($kv in $f) { $args += '-Field'; $args += $kv }

  # exit 1 from yc-event means "could not deliver, QUEUED to disk and will retry". On a host with
  # no webhook and no ntfy configured that is simply the normal answer, so it is reported, not
  # flagged - a flag that says nothing is wrong teaches people to stop reading flags.
  $ev = Invoke-YcCommand -Script 'Yc-Event.ps1' -Arguments $args -Phase 'NOTIFY' -OkCodes @(0,1)
  if ($ev -eq 1) {
    L 'the notification was QUEUED, not delivered - usually no ntfy url and no webhook configured on this host. Set one with:  yc-event -SetNtfy https://<server>/<topic> -SetNtfyEnabled on   Nothing is lost; the next yc-event run retries it.' 'WARN'
  } elseif ($ev -eq 0) {
    L ('notification sent: ' + $title) 'OK'
  }
}

# ================================================================================================
# -Status.  What happened to this machine, read back from disk. Changes nothing.
# ================================================================================================
function Show-Status {
  $h = Get-HostNameSafe
  Write-Host ''
  Write-Host ('  ADOPT STATUS  -  ' + $h) -ForegroundColor Green
  Write-Host ''
  if (Test-Path -LiteralPath $script:Marker) {
    try {
      $m = Get-Content -LiteralPath $script:Marker -Raw | ConvertFrom-Json
      Write-Host ('    adopted         : YES, ' + $m.adoptedUtc + ' UTC')
      Write-Host ('    source          : ' + $m.source)
      Write-Host ('    payload version : ' + $m.payloadVersion)
      Write-Host ('    phases run      : ' + (@($m.phasesRun) -join ', '))
      if (@($m.flags).Count) {
        Write-Host ('    flags           : ' + @($m.flags).Count + ' - a human still has to read these:') -ForegroundColor Magenta
        foreach ($f in @($m.flags)) { Write-Host ('                      - ' + $f) -ForegroundColor Magenta }
      } else { Write-Host '    flags           : none' }
    } catch { Write-Host '    adopted         : marker present but unreadable' -ForegroundColor Yellow }
  } else {
    Write-Host '    adopted         : NO - this machine has not been through migrated-vm.' -ForegroundColor Yellow
  }
  $n = 0
  if (Test-Path -LiteralPath $ScriptsDir) { $n = @(Get-ChildItem -LiteralPath $ScriptsDir -File -ErrorAction SilentlyContinue).Count }
  Write-Host ('    C:\Scripts      : ' + $n + ' files' + $(if (Test-ScriptsOnPathLocal) { ', on PATH' } else { ', NOT on PATH' }))
  Write-Host ('    resume task     : ' + $(if (Get-ScheduledTask -TaskName $script:ResumeTask -ErrorAction SilentlyContinue) { 'PRESENT - a run is waiting for a reboot' } else { 'none' }))
  $tasks = @()
  try { $tasks = @(Get-ScheduledTask -ErrorAction Stop | Where-Object { $_.TaskName -match '^YC-' } | ForEach-Object { $_.TaskName }) } catch {}
  Write-Host ('    YC tasks        : ' + $(if ($tasks.Count) { ($tasks -join ', ') } else { 'none' }))
  Write-Host ('    log             : ' + $script:LogPath)
  Write-Host ''
}

# Every exit path closes the transcript. Two of them did not: the terminal-phase stop (including
# the reboot path, which is exactly the run somebody comes back to read) and the normal end left
# the log open with no [END] line and no recorded exit code. yc-compliance EXITDISC blocks on it.
function Exit-Adopt {
  param([int]$Code)
  L ('END exit=' + $Code)
  if ($script:LibOK -and (Get-Command Stop-YcLog -ErrorAction SilentlyContinue)) { Stop-YcLog $Code }
  exit $Code
}

# ================================================================================================
# Help
# ================================================================================================
$Usage = @'
migrated-vm  -  bring a MIGRATED VM up to the same day-2 standard as one we built ourselves,
                and write down what was already wrong with it before we touched it.

WHAT IT IS FOR
  A fresh VM gets C:\Scripts, the scheduled tasks, the reports and the backups because the
  userdata runs on first boot. A VM migrated from vCenter or OpenStack gets none of that - there
  is no first link in the chain. This is that first link, run ONCE on the migrated guest.

  After it runs, the machine pulls the same payload from the same URL as every fresh VM, keeps
  itself current, and appears in the fleet view. Nothing special about it afterwards.

  IT ALSO BUILDS THE EVIDENCE FILE. A VM can arrive already damaged - a damaged disk, damaged
  files, a damaged database - and a migration copies data exactly as it finds it, including the
  broken parts. So this records, on arrival and before changing anything, what was already wrong
  AND THE DATES WINDOWS AND SQL SERVER THEMSELVES RECORDED IT. If somebody later says the
  migration caused it, that file is the answer.

MODES
  migrated-vm -Report            look only. Surveys the machine, writes the JSON, changes NOTHING.
                                 THIS IS THE DEFAULT. Run it first, read it, then run -Run.
  migrated-vm -Run               do the work.
  migrated-vm -Status            what was done to this machine, read back from disk.
  migrated-vm -Help              this text.

  Every run ends in a worded verdict - REPORT ONLY, ADOPTION COMPLETE, PARTIAL RUN or DID NOT
  COMPLETE - with the exit code spelled out and numbered next steps. It does not just stop.

OPTIONS
  -Only <phases>     run just these        } any of the 17 phase names listed below.
  -Skip <phases>     run all but these     } BOTH NEED -Run. In the default -Report mode the
                     phase list is fixed at SURVEY,SQL and -Only/-Skip are ignored, so
                     "-Only SQLMAINT" with no -Run surveys the box and reports success.
  -Force             proceed past a refusal. It reaches the SQLBACKUP gates (an incumbent
                     backup scheme, and too little backup space) and the SQLMAINT damaged-pages
                     gate ONLY. It does NOT override SQLPREP or PREREQ: if we cannot prove a task
                     identity or you are not an administrator, there is nothing to force.
  -AllowReboot       reboot at the END if something installed needs one. DEFAULT IS NOT TO
                     REBOOT: it reports what needs one and leaves the box up for your change
                     window. Nothing is waiting on the reboot - the adopt is already complete.
  -ChadminPassword   only when S4U is refused on this host. Never written down by us.
  -MinFreeGB <n>     the free-space floor for SQL volumes (default 5)
  -BackupDir <path>  SQL backup root. Omitted: backup-sql decides (Ola directory, or its default)
  -GrowDisk          DISKSCAN: actually extend a partition. DEFAULT IS DETECT AND REPORT ONLY.
  -SkipChoco         TOOLS: no Chocolatey      -SkipDotNet   TOOLS: do not touch .NET
  -SkipPwsh          TOOLS: no PowerShell 7    -SkipSsms     TOOLS: no SSMS
  -SkipDiagTools     TOOLS: no staged diagnostic tools
  -SkipOla           SQLMAINT: do not install Ola Hallengren
  -SkipExporter      SQLMAINT: do not register the local SQL metrics exporter
  -QemuGaMsi <p>     path OR url to the QEMU guest agent MSI. It is NOT in the payload zip
                     (~11.8 MB mirror member), so a migrated VM has no staged copy. Without
                     this, and with nothing in C:\Scripts, a missing agent is FLAGGED not fixed.
  -SkipGuestAgent    report the guest agent, never install or start it (either platform)
  -ScriptsDir <path> where the toolkit lives. Default C:\Scripts - it is the root of every
                     path in WHAT IT LEAVES BEHIND below.
  -RetainFullDays / -RetainDiffDays / -RetainLogDays   backup retention, default 35 / 16 / 16
                     days. Floor is 15 days:
                     retention has to outlive detection latency, because corruption found on
                     day 15 is unrecoverable if the last clean backup aged out on day 14.
  -Url / -ShaUrl     payload and sidecar. Defaults are the frozen public URLs.

THE 17 PHASES, in order
  SURVEY     read-only inventory -> C:\Scripts\survey\<host>-<stamp>-pre.json. The baseline
             VERIFY later diffs against. Nothing else runs until this has.
  PREREQ     admin, PowerShell 5.1, TLS 1.2, free space, egress, pending reboot.
             A PENDING REBOOT NO LONGER STOPS THE RUN. It is reported, the run continues, and
             the reboot is reported again at the end. Stopping first used to hand the rest of
             the run to SYSTEM, which cannot register a task as chadmin.
  BOOTSTRAP  fetch the payload zip + .sha256, VERIFY THE HASH, extract Update-YcScripts.ps1 only.
             The one new download path in the estate. Runs once, never again.
  SYNC       update-yc-scripts - the full payload, same channel as every fresh VM.
  PATH       put C:\Scripts on the machine PATH so  yallacloud  works. (The Hidden+System
             attribute on C:\Scripts is set by the payload's own ACL repair, not by this phase,
             and it is cosmetic - it is not a permission and it does not stop anybody.)
  TOOLS      Chocolatey, git, .NET, PowerShell 7, dbatools, SSMS, winget. SSMS is installed by
             DEFAULT - pass -SkipSsms to leave it out, which is usually right on a customer box.
             PowerShell 7 is taken from the staged MSI in C:\Scripts if it is there, else from
             the GitHub release (asset name read FROM the release, never constructed), and only
             then from Chocolatey.
             THEN THE GUEST PLATFORM. The hypervisor is DETECTED first, from
             Win32_ComputerSystem and Win32_BIOS (both on every Windows 2012R2 to 2025), and the
             checks branch on what it finds. Reported LOUDLY and in red when something is wrong:
               KVM     expects qemu-guest-agent, and checks VIRTIO against the pinned version.
               VMWARE  expects VMware Tools, and checks its VERSION against the pin. The pin
                       follows the OS: Tools 13.x dropped Server 2012R2, so a pre-2016 build is
                       compared against the LEGACY track (12.5.4) instead, and says which track
                       it used. Both come from the payload's own MANIFEST.json.
               other   Hyper-V, Xen, physical, unknown: reported, nothing claimed. We have no
                       guest tooling of our own for these.
             AGENT, EITHER PLATFORM: installed? and actually RUNNING? Presence is not running -
               Get-Service answers true for a stopped service. Snapshot backups on this estate
               are AGENTLESS, they ask this agent to freeze the machine, so an agent that is down
               means a database snapshot is crash-consistent and nobody was told. A STOPPED agent
               is started and set to Automatic on both platforms. A MISSING one is installed on
               KVM only (see -QemuGaMsi); VMware Tools is never installed or upgraded here,
               because it lays down storage and network filter drivers and wants a reboot.
             LEFTOVERS: VMware Tools on a KVM guest, or qemu-ga/virtio on a VMware guest, came
               with the VM from the platform it left. They have no host to talk to here, and a
               stopped one is what sends people looking in the wrong place when a backup fails.
               They are REPORTED, never removed - uninstalling guest tooling is a change window.
             VIRTIO and VMware Tools are REPORTED, NEVER SWAPPED OR UPGRADED. An old virtio
               storage driver is exposed to known IO races - and it was already that old when the
               VM arrived, which is why it belongs in the evidence file either way.
  NIC        set-nic -CleanGhosts, only if hidden adapters are present. No addressing change.
  SQLPREP    THE REFUSING GATE. chadmin exists, chadmin is sysadmin, the disk floor is met, and
             S4U is PROVEN on this host - not assumed. Everything after this needs a task
             identity, so if this cannot prove one, the phases that need it say so and stop.
  BASELINE   writes baseline_beforemigration.log/.json - THE STATE AS RECEIVED, before anything
             is changed. It is hashed the moment it is written and that SHA256 goes into the log
             and into adopt-report.json. If the baseline is ever disputed, compare the hash.
  SQL        discover instances: edition, version, patch level, evaluation, databases. REPORTS.
             Never installs, never licenses - activation is a commercial decision.
  SQLHARDEN  sets PAGE_VERIFY to CHECKSUM. Reports SIMPLE recovery, never changes it.
             NOTE: CHECKSUM only protects pages written AFTER it is set, so a PHYSICAL_ONLY
             check is only conclusive for databases that ARRIVED set to CHECKSUM.
  SQLBACKUP  ONE FULL of every database first, proved, THEN the recurring tasks:
               YC-Adopt-SqlBackupFull   weekly  01:15
               YC-Adopt-SqlBackupDiff   daily   01:15
               YC-Adopt-SqlBackupLog    every 15 min, only if a database is in FULL recovery
             REFUSES if another backup scheme is already live - and when it refuses it runs
             vss-check, so the refusal rests on evidence instead of an assumption that the
             incumbent works.
  SQLMAINT   installs Ola Hallengren, then:
               YC-SqlIntegrityFast    daily  02:15   yc-integrity -Sql Fast -SuspectPages
               YC-SqlIntegrity        weekly 02:45   yc-integrity -Sql Full
               YC-SqlRestoreVerify    weekly 04:15   yc-integrity -RestoreVerify
               YC-IntegrityBaseline   once           the one-off baseline check after adopt
             ON AN INSTANCE THAT ALREADY HAS DAMAGED PAGES, only the WEEKLY FULL CHECKDB is
             withheld - it is heavy, and hammering storage that is already failing reads can
             make things worse. Everything else still registers, because the daily fast watch is
             the only thing that would tell you the damage is GROWING. The log names the
             withheld task and the command to run it by hand in a change window.
             Also registers the local SQL metrics exporter, bound to 127.0.0.1 only.
  DISKSCAN   YC-DiskScan, daily 05:15, chkdsk /scan - ONLINE AND READ-ONLY, so no downtime.
             THEN THE THREE THINGS THAT DECIDE WHETHER THE DATA SURVIVES, in one red banner:
               SQL INTEGRITY - damaged pages with the dates SQL Server wrote, and every database
                 that has NEVER had a CHECKDB complete cleanly. If the newest damaged page is not
                 the oldest, it says so: that means the damage is STILL being found, not a scar.
               CHKDSK / FILESYSTEM - the NTFS dirty bit (Windows has already decided the volume
                 needs repair), and what the LAST chkdsk found, read from the event log
                 (Wininit 1001 and Chkdsk 26212/26214). No record of one ever running is itself
                 an answer, and it is UNPROVEN, not OK.
               VSS - vss-check -Json, so the report names the actual failing writer or provider
                 instead of an exit code. A VSS that cannot snapshot means NEITHER our backup nor
                 the incumbent's is application-consistent, so this runs on every path.
             All three are REPORTED, never repaired: chkdsk /f dismounts the volume and a full
             CHECKDB on a damaged instance hammers storage that is already failing reads. Both
             belong in a change window. When SQL is damaged AND VSS is broken the banner says the
             thing worth saying out loud: there may be no clean copy of that database anywhere.
             Also detects a partition smaller than its disk. THIS IS A VIRTUAL VOLUME: there is
             no physical drive, so there is no SMART read and no hardware health claim anywhere.
  TASKS      YC-AutoUpdate and YC-Inventory, through their own commands, ONLY IF ABSENT.
  NOTIFY     marker file and registry stamp (HKLM:\SOFTWARE\YallaCloud Source=migrated) only.
             The fleet event and the ntfy message are sent LAST, with the verdict, because phase
             16 of 17 cannot yet know how the run ended. Priority 5 stopped early, 4 findings or
             partial, 3 clean.
  VERIFY     post-survey diffed against the pre-survey. Any task that appeared and is not one of
             ours, or any delta outside the allowed set, is reported loudly.

THE FOUR RULES IT OBEYS
  1. Survey before touch.                  3. Reversible, undo recorded BEFORE the change.
  2. Additive, never destructive.          4. Prove it changed nothing else.
  Anything that cannot satisfy all four is FLAGGED FOR A HUMAN, not automated.

WHAT IT WILL NOT DO
  install-sql        destructive on a migrated SQL box. Unreachable from here.
  activate-windows   the MAC changes on migration so activation often drops. Re-licensing a
                     customer VM onto our agreement is commercial. REPORT ONLY.
  antivirus exclusions   defender-exclude and bitdefender-exclude are DELIBERATELY manual.
                     Apply them by hand on a SQL box: real-time scanning of .mdf/.ndf/.ldf and
                     the backup folder is a known cause of IO stalls and 823/825 errors.
  take over backup   when another scheme owns the instance, it refuses and reports.
  change recovery model, flatten a rule set or a task, or remove anything it cannot positively
                     identify from inside the guest.

EXIT CODES
   0  every requested phase completed
   1  STOPPED EARLY - a phase could not finish and the run did not continue. NOTIFY, VERIFY
      and the adopt report did NOT run, so this machine has no report. Read the last phase in
      the log. A reboot requirement does NOT produce this - that is reported and exits 0.
   2  REFUSED at a gate. -Force reaches the SQLBACKUP and SQLMAINT gates only, never SQLPREP
   3  PARTIAL - finished, but one or more items were flagged for a human
   4  payload sha256 mismatch - nothing was installed, the update rolled back
   5  not elevated
   6  no HTTPS egress to the payload host

Log:
  C:\Scripts\adopt-migrated-vm.log  - every line of every run, newest at the bottom. Also goes to
  the Application event log (source YALLACLOUD) once the house library is loaded, which is from
  SQLPREP onwards; the earliest phases are in the file only.

WHAT IT LEAVES BEHIND, and which file to read first
  C:\Scripts\adopt-report.txt               READ THIS ONE. Plain language: is the database
                                            healthy, is the disk healthy, what is switched on.
                                            WRITTEN BY -Run ONLY - a -Report pass does not
                                            produce it, because it has nothing to report on yet.
  C:\Scripts\adopt-report.json              the same thing for a machine to read, with the
                                            evidence and the dates behind every verdict
  C:\Scripts\baseline_beforemigration.log   the state AS RECEIVED, plus its SHA256
  C:\Scripts\baseline_beforemigration.json  the same, for a machine to read
  C:\Scripts\pageverify.undo.json          what PAGE_VERIFY was before SQLHARDEN changed it,
                                            written BEFORE the change - this is rule 3
  C:\Scripts\survey\licence-report.json     Windows and SQL licensing. No key is ever printed.
  C:\Scripts\adopt-migrated-vm.log          every line, also in the Application event log,
                                            source YALLACLOUD
  C:\Scripts\adopt-migrated-vm.state.json   phase state
  C:\Scripts\survey\<host>-<stamp>-pre.json    the baseline survey
  C:\Scripts\survey\<host>-<stamp>-post.json   what VERIFY diffed against it
  C:\ProgramData\YallaCloud\adopted.json    the marker that says this VM is managed by us

  HOW TO READ THE GUEST PLATFORM ANSWER
    platform      KVM | VMWARE | HYPERV | XEN | VBOX | OTHER-HV | PHYSICAL-OR-UNKNOWN | UNKNOWN
    guest agent   OK              the right agent for this platform, installed and running
                  STOPPED         installed but not running - backups are NOT freezing this VM
                  OLD             running, but older than the pin (VMware Tools)
                  MISSING         no agent at all
                  NOT-APPLICABLE  not a KVM or VMware guest, so neither agent is expected
    virtio        OK              every driver at the pinned version   (KVM only)
                  DIFFERS         at least one driver is NOT at the pin
                  UNPROVEN        present, but a version could not be read
                  NOT-VIRTIO      no virtio drivers on a KVM guest
                  NOT-APPLICABLE  not a KVM guest - the pin does not apply

  HOW TO READ THE DATABASE ANSWER
    GOOD      no damaged pages on record, and a consistency check has completed cleanly
    UNPROVEN  no damaged pages on record, but no consistency check has ever completed cleanly,
              on this platform or the one before it - so "good" was never established by anybody
    BAD       SQL Server's own damaged-page list is not empty. The dates come from SQL Server.

  HOW TO READ THE DISK ANSWER
    GOOD      no dirty bit, and no filesystem or disk corruption events on record
    UNPROVEN  nothing on record, but the dirty bit could not be read, so a clean filesystem
              was not actually established either
    SUSPECT   corruption events ARE on record, with dates, but no dirty bit is set
    BAD       the NTFS dirty bit is set: Windows itself has decided this volume needs repair

EXAMPLES
  migrated-vm -Report                       look first. Always.
  migrated-vm -Run                          the whole thing
  migrated-vm -Run -Skip SQLBACKUP          adopt the box, leave the database alone for now
  migrated-vm -Only SURVEY,SQL              just tell me what SQL is on here
  migrated-vm -Run -GrowDisk                also extend a partition short of its disk
  migrated-vm -Status                       what was done to this machine
  yc-integrity -Sql Full                    the weekly CHECKDB by hand, in a change window
'@

if ($Help -or ($PSBoundParameters.Count -eq 0 -and -not $Run -and -not $Status -and -not $Resume -and -not $Report)) {
  if ($Help) { Write-Host $Usage; exit 0 }
}

# ================================================================================================
# Main
# ================================================================================================
if ($Help)   { Write-Host $Usage; exit 0 }
if ($Status) { Show-Status; exit 0 }

# -Report is the default on purpose. The first thing you do to a machine holding production data
# is look at it, and a bare "migrated-vm" must never start changing one.
if (-not $Run -and -not $Resume) { $Report = $true }

# powershell.exe -File passes EVERY argument as a plain string and does not do PowerShell's usual
# array parsing, so "-Only SURVEY,SQL" arrives as ONE element containing commas rather than two.
# That is how every .cmd wrapper in this payload invokes its script, and it is how the -Help
# examples tell people to type it - so the documented usage was broken. Normalise both shapes.
if ($Only) { $Only = @($Only | ForEach-Object { ([string]$_) -split ',' } | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }
if ($Skip) { $Skip = @($Skip | ForEach-Object { ([string]$_) -split ',' } | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }

$phases = $AllPhases
if ($Only) {
  $bad = @($Only | Where-Object { $AllPhases -notcontains $_.ToUpper() })
  if ($bad.Count) { L ('unknown phase(s): ' + ($bad -join ', ') + '. Valid: ' + ($AllPhases -join ' ')) 'ERROR'; exit 2 }
  $phases = @($AllPhases | Where-Object { $Only.ToUpper() -contains $_ })
}
if ($Skip) {
  $bad = @($Skip | Where-Object { $AllPhases -notcontains $_.ToUpper() })
  if ($bad.Count) { L ('unknown phase(s): ' + ($bad -join ', ') + '. Valid: ' + ($AllPhases -join ' ')) 'ERROR'; exit 2 }
  $phases = @($phases | Where-Object { $Skip.ToUpper() -notcontains $_ })
}
if ($Report) { $phases = @('SURVEY','SQL') }

# Every phase MUST have a case in the dispatch below. A phase in the list with no case falls
# through, leaves $rc at 0, and is recorded as DONE having done nothing - a silent success, which
# is the failure shape this whole script exists to avoid. So check it before doing any work.
$dispatched = @('SURVEY','PREREQ','BOOTSTRAP','SYNC','PATH','TOOLS','NIC','SQLPREP','BASELINE','SQL',
                'SQLHARDEN','SQLBACKUP','SQLMAINT','DISKSCAN','TASKS','NOTIFY','VERIFY')
$undispatched = @($AllPhases | Where-Object { $dispatched -notcontains $_ })
if ($undispatched.Count) {
  L ('INTERNAL: these phases are listed but have no handler: ' + ($undispatched -join ', ') + '. Refusing to run.') 'ERROR'
  exit 2
}

L ('START  mode=' + $(if ($Report) {'REPORT (nothing will be changed)'} elseif ($Resume) {'RESUME after reboot'} else {'RUN'}) +
   '  host=' + (Get-HostNameSafe) + '  phases=' + ($phases -join ','))
if ($Resume) { L 'resumed by YC-AdoptResume after a reboot.' }

# Dot-source the house library AT SCRIPT SCOPE so the definitions outlive this statement. If the
# payload is not here yet, L stays on its built-in logger until SYNC lands it and the loop below
# tries again. Nothing depends on which logger is active - only the line format differs.
if ((-not $script:LibOK) -and (Test-YcLibraryPresent)) {
  try {
    . (Join-Path $ScriptsDir '_yc-lib.ps1')
    if (Get-Command Start-YcLog -ErrorAction SilentlyContinue) { Start-YcLog -Name $script:Tag -Dir $ScriptsDir | Out-Null }
    $script:LibOK = $true
    L 'house library loaded - log format, secret redaction and the Application event log are now the fleet standard.'
  } catch { L ('could not load the house library: ' + $_.Exception.Message) 'WARN' }
}

$pre  = $null
$exit = 0

foreach ($p in $phases) {
  L ('--- phase ' + $p + ' ---')
  $rc = 0
  switch ($p) {
    'SURVEY'    { $pre = Invoke-Survey -Label 'pre'; $rc = 0 }
    'PREREQ'    { $rc = Invoke-Prereq }
    'BOOTSTRAP' { $rc = Invoke-Bootstrap }
    'SYNC'      { $rc = Invoke-Sync }
    'PATH'      { $rc = Invoke-Path }
    'TOOLS'     { $rc = Invoke-Tools }
    'NIC'       { if ($pre) { $rc = Invoke-Nic -Survey $pre } else { Flag 'NIC' 'no survey, so the ghost-NIC count is unknown. Skipped.'; $rc = 3 } }
    'SQLPREP'   { if (-not $pre) { $pre = Invoke-Survey -Label 'pre' }; $rc = Invoke-SqlPrep -Survey $pre }
    'SQL'       { if (-not $pre) { $pre = Invoke-Survey -Label 'pre' }; $rc = Invoke-Sql -Survey $pre }
    'BASELINE'  { if (-not $pre) { $pre = Invoke-Survey -Label 'pre' }; $rc = Invoke-Baseline  -Survey $pre }
    'SQLHARDEN' { if (-not $pre) { $pre = Invoke-Survey -Label 'pre' }; $rc = Invoke-SqlHarden -Survey $pre }
    'SQLBACKUP' { if (-not $pre) { $pre = Invoke-Survey -Label 'pre' }; $rc = Invoke-SqlBackup -Survey $pre }
    'SQLMAINT'  { if (-not $pre) { $pre = Invoke-Survey -Label 'pre' }
                  $rc = Assert-TaskIdentity -Survey $pre -Phase 'SQLMAINT'
                  if ($rc -eq 0) { $rc = Invoke-SqlMaint -Survey $pre } }
    'DISKSCAN'  { if (-not $pre) { $pre = Invoke-Survey -Label 'pre' }
                  [void](Invoke-GrowDiskCheck)
                  $rc = Assert-TaskIdentity -Survey $pre -Phase 'DISKSCAN'
                  if ($rc -eq 0) { $rc = Invoke-DiskScanTask } }
    'TASKS'     { if (-not $pre) { $pre = Invoke-Survey -Label 'pre' }; $rc = Invoke-Tasks -Survey $pre }
    'NOTIFY'    { $rc = Invoke-Notify -Survey $pre }
    'VERIFY'    { if ($pre) { $rc = Invoke-Verify -Pre $pre } else { L 'VERIFY skipped - there is no pre-survey to diff against.' 'WARN'; $rc = 3 } }
  }
  # 5, 6, 4 and 1 are terminal: there is no point running the next phase on a box that is not
  # elevated, has no egress, could not verify the payload, or is waiting for a reboot.
  if ($rc -in @(1,4,5,6)) {
    Save-State $p 'stopped'
    L ('STOPPING at ' + $p + ' with exit ' + $rc) $(if ($rc -eq 1) {'WARN'} else {'ERROR'})
    if ($script:Flags.Count) {
      L ([string]$script:Flags.Count + ' item(s) need a human. Nothing below was guessed at:') 'WARN'
      foreach ($f in $script:Flags) { L ('   - ' + $f) 'FLAG' }
    }
    # Write the report even on a stop. If BASELINE has already run, this machine's evidence is
    # collected and throwing it away because a LATER phase failed is the one thing we cannot
    # afford: the dates in it are the whole point, and a stopped run is exactly the run somebody
    # comes back to argue about.
    if ((-not $Report) -and ($script:Done -contains 'BASELINE')) {
      L 'writing the adopt report before stopping - the evidence collected so far is kept.' 'WARN'
      try { Write-AdoptReport } catch { L ('could not write the report: ' + $_.Exception.Message) 'ERROR' }
    }
    Show-AdoptVerdict -Code $rc -StoppedAt $p
    Exit-Adopt $rc
  }
  # SYNC is what puts _yc-lib.ps1 on disk, so this is the first moment the real logger can exist.
  if ($p -eq 'SYNC' -and $rc -eq 0 -and -not $script:LibOK -and (Test-YcLibraryPresent)) {
    try {
      . (Join-Path $ScriptsDir '_yc-lib.ps1')
      if (Get-Command Start-YcLog -ErrorAction SilentlyContinue) { Start-YcLog -Name $script:Tag -Dir $ScriptsDir | Out-Null }
      $script:LibOK = $true
      L 'house library loaded - log format, secret redaction and the Application event log are now the fleet standard.'
    } catch { L ('could not load the house library: ' + $_.Exception.Message) 'WARN' }
  }
  if ($rc -eq 2) { $exit = 2 }
  elseif ($rc -ne 0 -and $exit -eq 0) { $exit = 3 }
  $script:Done.Add($p) | Out-Null
  Save-State $p $(if ($rc -eq 0) { 'ok' } else { 'flagged' })
}

# A completed run owns the cleanup of its own resume task.
if (-not $Report) { Unregister-ResumeTask }

# THE REBOOT, AT THE END, WHERE IT COSTS NOTHING. By here every phase has run as the account
# that invoked this, so every task that was going to be registered already is. Re-read the
# pending state rather than trusting what PREREQ saw: TOOLS installs Chocolatey, git and the
# PowerShell 7 MSI, and each of those sets PendingFileRenameOperations on its own.
$script:RebootNeeded = @()
if (-not $Report) {
  try { $script:RebootNeeded = @(Get-PendingRebootReasonsLocal) } catch {}
}

$script:MissingPhases = @()
Write-Host ''
if ($Report) {
  L 'REPORT ONLY - nothing on this machine was changed.' 'OK'
} else {
  if ($script:Flags.Count -eq 0) {
    # "ADOPTED" is a claim about the WHOLE machine, so it may only be made by a run that did the
    # whole thing. Stage E of the staged test ran SURVEY,SQLPREP,DISKSCAN and was told
    # "This VM is now on the same payload channel as a freshly deployed one" - which was false,
    # and the harness then removed the one task it had registered. A partial run reports what it
    # did and nothing more.
    $script:MissingPhases = @($AllPhases | Where-Object { $script:Done -notcontains $_ })
    L ('phases run: ' + ($script:Done -join ', ') + '. No findings.') 'OK'
  } else {
    $script:MissingPhases = @($AllPhases | Where-Object { $script:Done -notcontains $_ })
    L ([string]$script:Flags.Count + ' item(s) need a human. Nothing below was guessed at:') 'WARN'
    foreach ($f in $script:Flags) { L ('   - ' + $f) 'FLAG' }
    if ($exit -eq 0) { $exit = 3 }
  }
}
if ((-not $Report) -and $script:RebootNeeded.Count -gt 0) {
  Write-Host ''
  L ('THIS MACHINE NEEDS A REBOOT to finish applying what was installed: ' + ($script:RebootNeeded -join ', ')) 'WARN'
  if ($script:RebootWasPending) { L 'one was already pending before this run started, so it is not all ours.' }
  if ($AllowReboot) {
    L 'rebooting now (-AllowReboot). Everything this run was going to do is already done; nothing resumes afterwards.' 'WARN'
    Save-State 'REBOOT' 'rebooting'
    try { Restart-Computer -Force } catch { L ('reboot failed: ' + $_.Exception.Message) 'ERROR' }
  } else {
    L 'Reboot it when the change window allows. Nothing is waiting on it - the adopt is complete.' 'WARN'
    L 'To let a future run reboot on its own, pass -AllowReboot.'
  }
}
if (-not $Report) { Write-AdoptReport }
Show-AdoptVerdict -Code $exit -Missing $script:MissingPhases
Exit-Adopt $exit
