@echo off
setlocal
rem ================================================================================================
rem postgresexporter-register - install postgres_exporter UNDER THE WinSW SERVICE WRAPPER and prove
rem                             pg_up 1.  Wrapper for C:\Scripts\PostgresExporter-Register.ps1.
rem
rem WHAT CHANGED, AND WHY:
rem   - Added "exit /b %ERRORLEVEL%".
rem   - postgres_exporter is a plain Go binary with NO Windows service dispatcher: registered
rem     directly with New-Service the SCM kills it after 30 seconds with error 1053. The old script
rem     did exactly that with -EA SilentlyContinue and then logged success, so this exporter never
rem     ran on any VM. It now runs under WinSW - stage C:\Scripts\WinSW-x64.exe.
rem   - The old script also wrote the whole DSN, password included, to the MACHINE environment
rem     variable DATA_SOURCE_NAME, which every authenticated user can read and which is injected
rem     into every new process. The password now lives in an ACL-verified file referenced by
rem     DATA_SOURCE_PASS_FILE in the service's own environment, and the script REMOVES the stale
rem     machine variable if it finds one (rotate that password: assume it is compromised).
rem   - -PgSslMode now defaults to 'require' instead of 'disable'.
rem
rem PREFERRED:
rem   set YC_POSTGRES_EXPORTER_PASSWORD=...
rem   postgresexporter-register -PgHost 10.0.0.5 -PgUser exporter -RemoteAddress 10.20.0.11
rem   postgresexporter-register -PgHost localhost -PgUser exporter -PgPasswordFile C:\Scripts\.pg.pw
rem   postgresexporter-register -Help
rem
rem EXIT CODES: 0 verified | 1 failed | 2 usage | 5 not elevated | 6 no internet
rem Log: C:\Scripts\postgresexporter-register.log
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\PostgresExporter-Register.ps1" %*
exit /b %ERRORLEVEL%
