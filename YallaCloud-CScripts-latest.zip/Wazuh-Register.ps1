param(
  # ---- names preserved from wazuh-register.cmd and the catalog ----
  [string]$Manager,
  [string]$RegPassword,
  [string]$Group,
  [string]$Name,
  [switch]$Help,
  # ---- ADDED in this revision ----
  [string]$RegPasswordFile,            # read the enrollment password from a FILE, not argv
  [string]$MsiPath,                    # explicit wazuh-agent MSI
  [int]$ManagerPort = 1514,            # WAZUH_MANAGER_PORT
  [int]$RegistrationPort = 1515,       # WAZUH_REGISTRATION_PORT
  [string]$Protocol = 'tcp',           # WAZUH_PROTOCOL (tcp or udp)
  [int]$VerifySec = 180,               # how long to wait for enrolment evidence
  [switch]$Force,                      # re-run the MSI even if WazuhSvc already exists
  [switch]$SkipFirewall,               # do not create the outbound allow rules
  [switch]$AllowAnyRemote              # explicit opt-in to an unscoped outbound rule
)
# =====================================================================================
# Wazuh-Register.ps1 - SILENT install + enrolment of the Wazuh agent. OUTBOUND ONLY.
# PowerShell 5.1, ASCII only, unattended (cloud-init / SYSTEM / RMM).
#
# 2026-08-19: repaired. Added the library guard + Exit-Yc on every path (four bare exits, no
#             Stop-YcLog); msiexec now runs through Invoke-YcInstaller so its exit code is
#             captured, decoded and timed; the enrolment password is written to the vendor's
#             authd.pass file with a proven ACL INSTEAD of being put on the msiexec command
#             line; WazuhSvc must exist and reach Running and client.keys must appear before
#             success is reported; and the outbound firewall rules are created ONLY after
#             enrolment is proven, scoped to the manager's addresses rather than -Profile Any.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P0] IT REPORTED THE INSTALLER'S EXIT CODE AS THE RESULT AND CHECKED NOTHING.
#   Old lines 35-39:
#     $p = Start-Process msiexec.exe -ArgumentList $a -Wait -PassThru
#     Start-Sleep 3; & net start WazuhSvc 2>$null | Out-Null
#     foreach($pt in 1514,1515){ ... New-NetFirewallRule ... -Profile Any ... }
#     Write-Host ("Wazuh msiexec exit: " + $p.ExitCode + " (outbound 1514/1515 allowed)")
#     exit $p.ExitCode
#   $p.ExitCode was captured and never COMPARED to anything. 'net start WazuhSvc' had its
#   errors sent to $null, so a service that does not exist looked identical to one that
#   started. The two firewall rules were then created unconditionally, so a host where
#   nothing installed ended up carrying the artefacts of a working agent - the exact shape
#   of the Acronis incident. The message printed "outbound 1514/1515 allowed" as though
#   that were the outcome that mattered.
#   NOW: Invoke-YcInstaller decodes the exit code (including 1638 "already installed" and
#   1639 "the installer rejected a switch") with a timeout and a minimum plausible duration;
#   then ossec.conf must exist, WazuhSvc must reach Running, client.keys must be present and
#   non-empty, and ossec.log must be free of the documented enrolment errors. Only then are
#   the firewall rules created, and each one is read back after creation.
#
# [P0] THE ENROLMENT PASSWORD WAS ON A CHILD PROCESS COMMAND LINE.
#   Old line 32 appended WAZUH_REGISTRATION_PASSWORD=<password> to the msiexec argument list.
#   That value is visible in the process table for the life of msiexec, in 4688 command-line
#   audit events for ever, and PowerShell wrote the parent command line into the transcript
#   header. Wazuh's own Windows instructions do not require this: the password belongs in
#   authd.pass in the agent directory.
#   NOW: -RegPasswordFile / the YC_WAZUH_REGISTRATION_PASSWORD environment variable / -Password
#   are read into memory, written to <agent dir>\authd.pass, and that file is locked to SYSTEM
#   and Administrators with the ACL READ BACK to prove it. If the lock cannot be proven the
#   file is DELETED and the command fails (exit 13) rather than leaving a manager-wide
#   enrolment credential readable by every local account. The password is never passed to
#   Write-YcLog and never reaches the transcript.
#
# [P1] -Profile Any ON THE OUTBOUND RULES.
#   The rules allowed outbound 1514/1515 to EVERY remote address. They are now scoped with
#   -RemoteAddress to the resolved addresses of -Manager. Test-YcWorldOpen refuses an
#   unscoped scope unless -AllowAnyRemote is given explicitly. The rules stay on all profiles
#   because they are OUTBOUND to one known host, and a cloud VM's NIC is frequently
#   classified Public; no INBOUND rule is created at all, because the agent never listens.
#
# VENDOR VERIFICATION - every property and path below is documented:
#   Windows deployment variables (WAZUH_MANAGER, WAZUH_MANAGER_PORT, WAZUH_PROTOCOL,
#   WAZUH_REGISTRATION_SERVER, WAZUH_REGISTRATION_PORT, WAZUH_REGISTRATION_PASSWORD,
#   WAZUH_AGENT_NAME, WAZUH_AGENT_GROUP) and the msiexec examples:
#     https://documentation.wazuh.com/current/user-manual/agent/agent-enrollment/deployment-variables/deployment-variables-windows.html
#   Silent install command, service name WazuhSvc, install path C:\Program Files (x86)\ossec-agent:
#     https://documentation.wazuh.com/current/installation-guide/wazuh-agent/wazuh-agent-package-windows.html
#   authd.pass on Windows (create the file in the agent directory and save the password):
#     https://documentation.wazuh.com/current/user-manual/agent/agent-enrollment/security-options/using-password-authentication.html
#   client.keys, ossec.log and ossec.conf locations, ports 1514/1515, and the enrolment error
#   lines this script greps for ("Invalid password (from manager)", "Unable to add agent
#   (from manager)"):
#     https://documentation.wazuh.com/current/user-manual/agent/agent-enrollment/troubleshooting.html
#   Windows Installer standard options (/i, /q, /l*v):
#     https://learn.microsoft.com/en-us/windows/win32/msi/standard-installer-command-line-options
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was installed. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'wazuh-register'

$SvcName = 'WazuhSvc'
$MsiLog  = 'C:\Scripts\wazuh-agent-msi.log'

$Usage = @'
wazuh-register  -  SILENT install + enrolment of the Wazuh agent. OUTBOUND ONLY: the agent
                   opens TCP 1514 (events) and 1515 (enrolment) TO the manager. Nothing listens.
                   Staged installer: C:\Scripts\wazuh-agent-*.msi

USAGE:
  wazuh-register -Manager <manager-ip-or-fqdn>
  wazuh-register -Manager <m> -RegPasswordFile C:\Scripts\wazuh.pass [-Group <g>] [-Name <n>]
  wazuh-register -Manager <m> [-ManagerPort 1514] [-RegistrationPort 1515] [-Protocol tcp]
                 [-MsiPath <msi>] [-VerifySec 180] [-Force] [-SkipFirewall] [-AllowAnyRemote]
  wazuh-register -Help

PARAMETERS:
  -Manager          Wazuh manager IP or FQDN (required). Used for both WAZUH_MANAGER and
                    WAZUH_REGISTRATION_SERVER.
  -RegPassword      Enrollment password. PREFER -RegPasswordFile or the
                    YC_WAZUH_REGISTRATION_PASSWORD environment variable: a password on the
                    command line is visible in the process table and in 4688 audit events.
                    However supplied, it is written to <agent dir>\authd.pass and NEVER put
                    on the msiexec command line.
  -RegPasswordFile  File containing the enrollment password. Read, then the resulting
                    authd.pass is locked to SYSTEM + Administrators and the ACL is verified.
  -Group            WAZUH_AGENT_GROUP. The group must ALREADY EXIST on the manager; a
                    non-existent group makes the manager refuse the enrolment.
  -Name             WAZUH_AGENT_NAME. Defaults to the computer name. It must be unique across
                    the manager or enrolment is refused.
  -ManagerPort      WAZUH_MANAGER_PORT (default 1514).
  -RegistrationPort WAZUH_REGISTRATION_PORT (default 1515).
  -Protocol         WAZUH_PROTOCOL, tcp or udp (default tcp).
  -MsiPath          Explicit MSI. Default: the highest-version C:\Scripts\wazuh-agent-*.msi.
  -VerifySec        How long to wait for client.keys to appear (default 180).
  -Force            Re-run the MSI even if WazuhSvc already exists. Required to CHANGE the
                    manager or the group of an already-installed agent.
  -SkipFirewall     Do not create the outbound allow rules (the host already permits egress).
  -AllowAnyRemote   Create the outbound rules even when -Manager cannot be resolved to an
                    address, scoping them to Any. Refused without this switch.
  -Help             Show this help and exit.

PROOF OF SUCCESS (nothing below is assumed):
  msiexec exit code captured and decoded (the old script captured it and never compared it)
  + <agent dir>\ossec.conf present
  + the WazuhSvc service EXISTS and reaches Running
  + <agent dir>\client.keys present and non-empty - that file only exists once the manager
    has accepted this agent, so it is the enrolment receipt
  + ossec.log free of the documented enrolment errors
  + TCP reachability to the manager on the event and enrolment ports
  + every firewall rule read back after creation.
  If enrolment cannot be proven the command FAILS and no firewall rule is created.

SECURITY:
  Outbound only; no inbound rule is created. The enrolment password is a MANAGER-WIDE
  credential: anyone who can read it can enroll a rogue agent. It is stored only in
  <agent dir>\authd.pass, locked to SYSTEM and Administrators, and the lock is verified.

EXAMPLES:
  wazuh-register -Manager wazuh.example.com
  wazuh-register -Manager 10.0.0.5 -Group ACME -Name web01 -RegPasswordFile C:\Scripts\wazuh.pass
  $env:YC_WAZUH_REGISTRATION_PASSWORD='...'; wazuh-register -Manager 10.0.0.5
  wazuh-register -Manager 10.0.0.5 -Force
  wazuh-register -Help

EXIT CODES:
  0   the agent is installed, WazuhSvc is Running and enrolment is proven
  1   generic failure (authd.pass could not be written, or a firewall rule failed)
  2   usage error (no -Manager, bad port, bad -Protocol, unreadable -RegPasswordFile)
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4   the Wazuh MSI is missing or too small, or ossec.conf is absent after the install
  5   not running as Administrator
  7   the WazuhSvc service does not exist or did not reach Running
  8   enrolment could not be proven (no client.keys, or the manager refused this agent)
  10  msiexec did not exit within its timeout and was killed
  13  the authd.pass ACL could not be proven - the password file was DELETED
  <n> any other value is msiexec's own exit code

Log: C:\Scripts\wazuh-register.log   MSI log: C:\Scripts\wazuh-agent-msi.log
     (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

# ------------------------------------------------------------------------------------
# Resolve the enrolment password without ever printing it.
# ------------------------------------------------------------------------------------
$pw = ''
if($RegPasswordFile){
  if(-not (Test-Path -LiteralPath $RegPasswordFile)){
    Write-Host $Usage -ForegroundColor Cyan
    Exit-Yc 2 ('-RegPasswordFile not found: ' + $RegPasswordFile + '. Nothing was installed.') 'ERROR'
  }
  $pwRaw = $null
  # Get-Content -Raw returns $null for an EMPTY file, and [string]$null is $null, not '' - so
  # calling .Trim() straight off the pipeline throws instead of reporting "the file is empty".
  try{ $pwRaw = Get-Content -LiteralPath $RegPasswordFile -Raw -ErrorAction Stop }
  catch{ Exit-Yc 2 ('-RegPasswordFile could not be read: ' + $_.Exception.Message) 'ERROR' }
  if($null -eq $pwRaw){ $pwRaw = '' }
  $pw = ([string]$pwRaw).Trim()
  if(-not $pw){ Exit-Yc 2 ('-RegPasswordFile is empty: ' + $RegPasswordFile) 'ERROR' }
  Write-YcLog ('enrolment password read from ' + $RegPasswordFile + ' (the value is not logged)')
}elseif($RegPassword){
  $pw = $RegPassword.Trim()
  Write-YcLog 'the enrolment password was passed on the command line, so it is in this host''s process table and 4688 audit trail. Prefer -RegPasswordFile or YC_WAZUH_REGISTRATION_PASSWORD.' 'WARN'
}elseif($env:YC_WAZUH_REGISTRATION_PASSWORD){
  $pw = ([string]$env:YC_WAZUH_REGISTRATION_PASSWORD).Trim()
  Write-YcLog 'enrolment password taken from the YC_WAZUH_REGISTRATION_PASSWORD environment variable (it is not on the command line - good)'
}

if(-not $Manager){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 '-Manager is required (the Wazuh manager IP or FQDN). Nothing was installed.' 'ERROR'
}
$Manager = $Manager.Trim()
if($Manager -match '(?i)^https?://'){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 ('-Manager must be a host or IP, not a URL: ' + $Manager) 'ERROR'
}
foreach($pp in @(@('ManagerPort',$ManagerPort),@('RegistrationPort',$RegistrationPort))){
  if([int]$pp[1] -lt 1 -or [int]$pp[1] -gt 65535){
    Exit-Yc 2 ('-' + $pp[0] + ' ' + $pp[1] + ' is out of range 1-65535') 'ERROR'
  }
}
$proto = $Protocol.Trim().ToLowerInvariant()
if($proto -ne 'tcp' -and $proto -ne 'udp'){
  Exit-Yc 2 ('-Protocol must be tcp or udp, got "' + $Protocol + '" (WAZUH_PROTOCOL accepts nothing else)') 'ERROR'
}
if($VerifySec -lt 1){ Exit-Yc 2 ('-VerifySec must be at least 1, got ' + $VerifySec) 'ERROR' }

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
Write-YcLog ('manager ' + $Manager + ' events ' + $proto + '/' + $ManagerPort + ' enrolment tcp/' + $RegistrationPort +
  ' group "' + $Group + '" agent name "' + $(if($Name){$Name}else{$env:COMPUTERNAME + ' (default)'}) + '"')

function Test-YcTcpPort{
  param([string]$ComputerName,[int]$Port,[int]$TimeoutMs = 5000)
  $c = $null
  try{
    $c = New-Object System.Net.Sockets.TcpClient
    $iar = $c.BeginConnect($ComputerName,$Port,$null,$null)
    if(-not $iar.AsyncWaitHandle.WaitOne($TimeoutMs,$false)){ return $false }
    $c.EndConnect($iar)
    return $true
  }catch{
    return $false
  }finally{
    if($c){ try{ $c.Close() }catch{} }
  }
}

# The agent directory depends on the host architecture, and the vendor documents both.
$agentDirs = @('C:\Program Files (x86)\ossec-agent','C:\Program Files\ossec-agent')
function Get-YcAgentDir{
  foreach($d in $agentDirs){ if(Test-Path -LiteralPath (Join-Path $d 'ossec.conf')){ return $d } }
  foreach($d in $agentDirs){ if(Test-Path -LiteralPath $d){ return $d } }
  return ''
}

# ------------------------------------------------------------------------------------
# 1. Install (or deliberately skip) the MSI - with an exit code this time.
# ------------------------------------------------------------------------------------
$already = $false
try{ if(Get-Service -Name $SvcName -ErrorAction Ignore){ $already = $true } }catch{ $already = $false }

if($already -and -not $Force){
  Write-YcLog ('the ' + $SvcName + ' service already exists - NOT re-running the MSI. Pass -Force to reinstall or to change the manager/group of this agent. Enrolment is still verified below.') 'WARN'
}else{
  $msi = ''
  if($MsiPath){
    $msi = $MsiPath
  }else{
    $cands = @(Get-ChildItem -Path 'C:\Scripts\wazuh-agent-*.msi' -File -ErrorAction Ignore)
    if($cands.Count -gt 0){
      $ranked = @()
      foreach($f in $cands){
        $v = [version]'0.0'
        if($f.Name -match 'wazuh-agent-(\d+(?:\.\d+){1,3})'){ try{ $v = [version]$Matches[1] }catch{ $v = [version]'0.0' } }
        $ranked += (New-Object psobject -Property @{ File = $f; Ver = $v })
      }
      $ranked = @($ranked | Sort-Object -Property Ver -Descending)
      if($ranked.Count -gt 1){ Write-YcLog ('several staged Wazuh MSIs found - using the highest version: ' + $ranked[0].File.Name) 'WARN' }
      $msi = $ranked[0].File.FullName
    }
  }
  if(-not $msi){
    Exit-Yc 4 'the Wazuh agent MSI was not found (C:\Scripts\wazuh-agent-*.msi). Stage it or pass -MsiPath. Nothing was installed.' 'ERROR'
  }
  if(-not (Assert-YcFile -Path $msi -MinBytes 1MB -Because 'Wazuh agent MSI')){
    Exit-Yc 4 ('unusable Wazuh agent MSI: ' + $msi) 'ERROR'
  }
  $sig = 'Unavailable'
  try{ $sig = [string](Get-AuthenticodeSignature -LiteralPath $msi -ErrorAction Stop).Status }catch{ $sig = 'Unavailable' }
  if($sig -eq 'Valid'){ Write-YcLog ('MSI Authenticode signature: Valid (' + (Split-Path -Leaf $msi) + ')') 'OK' }
  else{ Write-YcLog ('MSI Authenticode signature is ' + $sig + ' for ' + $msi + ' - continuing, but this package is not proven to be the Wazuh build') 'WARN' }

  # Every property below is a documented Windows deployment variable. The enrolment password
  # is NOT here: it goes to authd.pass in step 2, so it never reaches a process command line.
  $a = @('/i', ('"' + $msi + '"'), '/q', '/l*v', ('"' + $MsiLog + '"'),
         ('WAZUH_MANAGER="' + $Manager + '"'),
         ('WAZUH_REGISTRATION_SERVER="' + $Manager + '"'),
         ('WAZUH_MANAGER_PORT=' + $ManagerPort),
         ('WAZUH_REGISTRATION_PORT=' + $RegistrationPort),
         ('WAZUH_PROTOCOL=' + $proto))
  if($Name){  $a += ('WAZUH_AGENT_NAME="'  + $Name  + '"') }
  if($Group){ $a += ('WAZUH_AGENT_GROUP="' + $Group + '"') }

  $inst = Invoke-YcInstaller -FilePath 'msiexec.exe' -ArgumentList $a -SuccessCodes @(0) -RebootCodes @(3010,1641) -TimeoutSec 1800 -MinSeconds 4
  if($inst.TimedOut){
    Exit-Yc 10 ('msiexec did not finish within its timeout and was killed - see ' + $MsiLog + '. The agent may be half-installed.') 'ERROR'
  }
  if($inst.ExitCode -eq 1638){
    Write-YcLog 'msiexec returned 1638 (another version of this product is already installed) - continuing to verify and configure the EXISTING agent' 'WARN'
  }elseif(-not $inst.Success){
    $code = $inst.ExitCode
    if($code -eq 0){ $code = 1 }
    Exit-Yc $code ('the Wazuh agent MSI FAILED: ' + $inst.Meaning + '. See ' + $MsiLog +
      '. Nothing is enrolled and NO firewall rule was created.') 'ERROR'
  }
}

$dir = Get-YcAgentDir
if(-not $dir){
  Exit-Yc 4 ('the installer reported success but neither ' + ($agentDirs -join ' nor ') +
    ' exists. The Wazuh agent is NOT installed. See ' + $MsiLog + '.') 'ERROR'
}
Write-YcLog ('agent directory: ' + $dir)
if(-not (Assert-YcFile -Path (Join-Path $dir 'ossec.conf') -MinBytes 100 -Because 'agent configuration')){
  Exit-Yc 4 ('ossec.conf is missing from ' + $dir + ' - the package did not install. See ' + $MsiLog + '.') 'ERROR'
}

# ------------------------------------------------------------------------------------
# 2. The enrolment password: authd.pass, LOCKED, and the lock PROVEN.
# ------------------------------------------------------------------------------------
$passFile = Join-Path $dir 'authd.pass'
if($pw){
  try{
    [IO.File]::WriteAllText($passFile,$pw,(New-Object System.Text.ASCIIEncoding))
  }catch{
    Exit-Yc 1 ('could not write ' + $passFile + ': ' + $_.Exception.Message + '. The agent cannot enroll with a password.') 'ERROR'
  }
  $aclOk = $false
  try{
    & icacls $passFile /inheritance:r /grant '*S-1-5-18:F' '*S-1-5-32-544:F' 2>&1 | Out-Null
    if($LASTEXITCODE -eq 0){ $aclOk = $true }
    if(-not $aclOk){
      & icacls $passFile /inheritance:r /grant 'NT AUTHORITY\SYSTEM:(F)' 'BUILTIN\Administrators:(F)' 2>&1 | Out-Null
      if($LASTEXITCODE -eq 0){ $aclOk = $true }
    }
  }catch{ $aclOk = $false }

  # READ THE ACL BACK. An icacls exit code is not proof that the ACL is what we asked for.
  $allowedSids = @('S-1-5-18','S-1-5-32-544','S-1-3-0','S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464')
  $offenders = @()
  try{
    $acl = Get-Acl -LiteralPath $passFile -ErrorAction Stop
    if(-not $acl.AreAccessRulesProtected){ $offenders += 'inheritance is still ENABLED' }
    foreach($ace in $acl.Access){
      $sid = ''
      try{ $sid = $ace.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value }
      catch{ $sid = [string]$ace.IdentityReference }
      if($allowedSids -notcontains $sid){ $offenders += ([string]$ace.IdentityReference + ' (' + $sid + ')') }
    }
  }catch{
    $offenders += ('the ACL could not be read back: ' + $_.Exception.Message)
  }
  if($offenders.Count -gt 0){
    try{ Remove-Item -LiteralPath $passFile -Force -ErrorAction Stop }catch{}
    Exit-Yc 13 ('the ACL on ' + $passFile + ' could not be proven safe (' + ($offenders -join '; ') +
      '). The password file has been DELETED rather than left readable - a Wazuh enrolment password is a manager-wide credential. Re-run from an elevated session.') 'ERROR'
  }
  Write-YcLog ('authd.pass written to ' + $dir + ' and locked to SYSTEM + Administrators (ACL read back and verified)') 'OK'
}else{
  Write-YcLog 'no enrolment password was supplied - this only works if the manager accepts unauthenticated enrolment.' 'WARN'
}

# ------------------------------------------------------------------------------------
# 3. The service must EXIST and be Running. Restart it if we just wrote authd.pass, so
#    the agent retries enrolment with the credential it now has.
# ------------------------------------------------------------------------------------
if($pw){
  try{
    $svc = Get-Service -Name $SvcName -ErrorAction Stop
    if($svc.Status -eq 'Running'){
      Restart-Service -Name $SvcName -Force -ErrorAction Stop
      Write-YcLog ($SvcName + ' restarted so the agent re-enrolls using authd.pass')
    }
  }catch{
    Write-YcLog ('could not restart ' + $SvcName + ': ' + $_.Exception.Message) 'WARN'
  }
}
if(-not (Assert-YcService -Name $SvcName -TimeoutSec 120 -State 'Running' -StartIfStopped -Because 'the Wazuh agent' -Fatal)){
  Exit-Yc 7 ('the ' + $SvcName + ' service is not Running - the agent is not collecting anything. See ' +
    (Join-Path $dir 'ossec.log') + '.') 'ERROR'
}

# ------------------------------------------------------------------------------------
# 4. PROVE enrolment. client.keys only exists once the manager has accepted this agent.
# ------------------------------------------------------------------------------------
$keyFile = Join-Path $dir 'client.keys'
$logFile = Join-Path $dir 'ossec.log'
$enrolled = $false
$sw = [Diagnostics.Stopwatch]::StartNew()
while($sw.Elapsed.TotalSeconds -lt $VerifySec){
  $len = 0
  try{ if(Test-Path -LiteralPath $keyFile){ $len = (Get-Item -LiteralPath $keyFile -ErrorAction Stop).Length } }catch{ $len = 0 }
  if($len -gt 0){ $enrolled = $true; break }
  Start-Sleep -Seconds 5
}
$badLog = @()
if(Test-Path -LiteralPath $logFile){
  try{
    $tail = @(Get-Content -LiteralPath $logFile -Tail 200 -ErrorAction Stop)
    $badLog = @($tail | Where-Object { $_ -match '(?i)(Invalid password \(from manager\)|Unable to add agent \(from manager\)|Duplicate agent name|Invalid agent name|Unable to connect to enrollment service)' })
  }catch{ Write-YcLog ('could not read ' + $logFile + ': ' + $_.Exception.Message) 'WARN' }
}

if(-not $enrolled){
  $why = 'client.keys did not appear in ' + $dir + ' within ' + $VerifySec + 's'
  if($badLog.Count -gt 0){ $why += '. ossec.log says: ' + ($badLog[0].Trim()) }
  $reach = ''
  if(Test-YcTcpPort -ComputerName $Manager -Port $RegistrationPort){ $reach = 'tcp/' + $RegistrationPort + ' on the manager IS reachable, so the manager REFUSED this agent (wrong password, non-existent -Group, or a duplicate agent name)' }
  else{ $reach = 'tcp/' + $RegistrationPort + ' on ' + $Manager + ' is NOT reachable, so enrolment never got as far as the manager - check egress, the address and the manager''s authd service' }
  Exit-Yc 8 ('the agent is installed and ' + $SvcName + ' is Running but it is NOT ENROLLED: ' + $why + '. ' + $reach +
    '. NO firewall rule was created.') 'ERROR'
}
if(-not (Assert-YcFile -Path $keyFile -MinBytes 10 -Because 'the enrolment receipt (client.keys)')){
  Exit-Yc 8 ('client.keys exists in ' + $dir + ' but is empty - this agent has no key and is not enrolled.') 'ERROR'
}
if($badLog.Count -gt 0){
  Write-YcLog ('ossec.log still reports an enrolment problem from an earlier attempt: ' + ($badLog[0].Trim()) +
    ' - client.keys is present, so treat this as history, but check the manager if events do not arrive') 'WARN'
}
Write-YcLog ('ENROLMENT PROVEN: ' + $keyFile + ' exists and is non-empty after ' + [int]$sw.Elapsed.TotalSeconds + 's') 'OK'

$reachEvents = Test-YcTcpPort -ComputerName $Manager -Port $ManagerPort
if($reachEvents){ Write-YcLog ('the manager''s event port ' + $Manager + ':' + $ManagerPort + ' is reachable') 'OK' }
else{ Write-YcLog ('the manager''s event port ' + $Manager + ':' + $ManagerPort + ' is NOT reachable from this host (the agent is enrolled, but events will queue). Check egress.') 'WARN' }

# ------------------------------------------------------------------------------------
# 5. Side effects ONLY now - after the agent is proven installed, running and enrolled.
# ------------------------------------------------------------------------------------
if($SkipFirewall){
  Write-YcLog '-SkipFirewall set: no outbound rule was created.'
}else{
  $scope = @()
  try{
    foreach($ipa in @([System.Net.Dns]::GetHostAddresses($Manager))){
      $s = [string]$ipa.IPAddressToString
      if($s -and ($scope -notcontains $s)){ $scope += $s }
    }
  }catch{
    Write-YcLog ('-Manager ' + $Manager + ' could not be resolved to an address for the firewall scope: ' + $_.Exception.Message) 'WARN'
  }
  if($scope.Count -eq 0){
    if($AllowAnyRemote){
      $scope = @('Any')
      Write-YcLog ('-Manager could not be resolved, and -AllowAnyRemote was given: the outbound rules will allow ' +
        $proto + '/' + $ManagerPort + ' and tcp/' + $RegistrationPort + ' to ANY remote address, as explicitly requested.') 'WARN'
    }else{
      Write-YcLog ('-Manager could not be resolved to an address, so an outbound rule would have to be scoped to Any. Refusing: pass -AllowAnyRemote to accept that, or -SkipFirewall. The agent is enrolled and working; only the rules were skipped.') 'WARN'
    }
  }
  if($scope.Count -gt 0){
    if((Test-YcWorldOpen -Scope $scope) -and -not $AllowAnyRemote){
      Write-YcLog ('the computed firewall scope is open to every remote address (' + ($scope -join ',') +
        '). Refusing to create it without -AllowAnyRemote.') 'WARN'
    }else{
      # OUTBOUND only, one destination. No inbound rule exists because the agent never listens.
      # -Profile Any is deliberate for an outbound rule: a cloud VM's NIC is frequently
      # classified Public and the agent must still reach its manager there.
      $rules = @(
        (New-Object psobject -Property @{ Display = ('YallaCloud Wazuh agent out ' + $ManagerPort); Port = $ManagerPort;      Proto = $proto.ToUpperInvariant(); What = 'agent events' }),
        (New-Object psobject -Property @{ Display = ('YallaCloud Wazuh enrolment out ' + $RegistrationPort); Port = $RegistrationPort; Proto = 'TCP';                     What = 'agent enrolment' })
      )
      foreach($r in $rules){
        if(Get-NetFirewallRule -DisplayName $r.Display -ErrorAction Ignore){
          Write-YcLog ('outbound rule already present: ' + $r.Display)
          continue
        }
        try{
          New-NetFirewallRule -DisplayName $r.Display -Direction Outbound -Action Allow -Protocol $r.Proto `
            -RemotePort $r.Port -RemoteAddress $scope -Profile Any `
            -Description ('Wazuh ' + $r.What + ' to ' + $Manager + '. Managed by YallaCloud.') `
            -ErrorAction Stop | Out-Null
        }catch{
          Exit-Yc 1 ('the agent is enrolled but the outbound rule "' + $r.Display + '" could not be created: ' + $_.Exception.Message) 'ERROR'
        }
        if(-not (Get-NetFirewallRule -DisplayName $r.Display -ErrorAction Ignore)){
          Exit-Yc 1 ('New-NetFirewallRule returned without error but "' + $r.Display + '" does not exist afterwards') 'ERROR'
        }
        Write-YcLog ('outbound allow VERIFIED: ' + $r.Proto + '/' + $r.Port + ' to ' + ($scope -join ',') + ' (' + $r.Display + ')') 'OK'
      }
    }
  }
}

Exit-Yc 0 ('Wazuh agent installed, ' + $SvcName + ' Running, and enrolment PROVEN by client.keys in ' + $dir +
  ' (manager ' + $Manager + ', group "' + $Group + '"). Outbound only: no inbound port was opened.') 'OK'
