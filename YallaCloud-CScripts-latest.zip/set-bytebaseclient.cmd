@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Set-BytebaseClient.ps1" %*
exit /b %ERRORLEVEL%
