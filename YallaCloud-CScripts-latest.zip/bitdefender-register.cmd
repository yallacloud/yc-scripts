@echo off
rem bitdefender-register [-Package <exe>] [-ExtraArgs '<sw>',..] [-Force] [-InstallTimeoutSec 3600]
rem                      [-VerifyTimeoutSec 900] [-InternetUrl <url>] [-Help]
rem Silent GravityZone (BEST) install. -ExtraArgs now APPENDS to the documented base line.
rem Success requires EPSecurityService plus a GravityZone communication service to be Running.
rem Logs to C:\Scripts\bitdefender-register.log  (MSI log: C:\Scripts\bitdefender-msi.log)
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Bitdefender-Register.ps1" %*
exit /b %ERRORLEVEL%
