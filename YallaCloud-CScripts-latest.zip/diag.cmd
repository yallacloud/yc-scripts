@echo off
rem diag [-OutFile <file>] [-MaxEvents 30] [-Help]
rem
rem Forensic/health report (boot, disk + SMART, chkdsk/sfc/DISM, event errors, BSOD) written to
rem C:\Scripts\diag-<yyyyMMdd-HHmmss>.txt. Read-only: nothing is repaired. Every section now
rem records the exception that stopped it instead of hiding behind -ErrorAction SilentlyContinue,
rem and the report file is proven written before this command reports success.
rem Logs to C:\Scripts\diag.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Diag-System.ps1" %*
exit /b %ERRORLEVEL%
