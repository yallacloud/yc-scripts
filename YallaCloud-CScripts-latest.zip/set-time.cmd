@echo off
rem set-time -Status | -Test | -Install | -Uninstall  [-Server "<a> <b>"] [-MaxSkewSec 300] [-Force] [-Help]
rem Make sure this machine knows what time it is. A clock 4h out breaks KMS activation (0xC004F06C);
rem 5 minutes out breaks Kerberos logons. Domain members are left alone unless -Force.
rem Logs to C:\Scripts\set-time.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Set-TimeSync.ps1" %*
exit /b %ERRORLEVEL%
