param(
  [string]$SqlInstance = '.',
  [string]$Database,
  [string]$AsName,
  [string]$Directory,
  [string]$SourceHost,
  [string]$StopAt,
  [switch]$List,
  [switch]$Json,
  [switch]$AllInstances,
  [switch]$NoRecovery,
  [switch]$Force,
  [switch]$WhatIf,
  [switch]$SelfCheck,
  [switch]$Help
)
# ================================================================================================
# Restore-Sql.ps1 - YALLACLOUD day-2 command: restore a database from the backup chain that
# backup-sql and the YC-Sql* scheduled tasks produce, and PROVE it came back.
# PowerShell 5.1 only, ASCII only, Windows Server 2016-2025, SQL Server 2016-2025.
#
# ------------------------------------------------------------------------------------------------
# WHY THIS EXISTS
# ------------------------------------------------------------------------------------------------
# Until 2026-09-01 this payload could back up and verify, and had nothing to restore with. Every
# restore was hand-written T-SQL, which is exactly the wrong thing to be composing at 3am with an
# outage running. The three mistakes that hand-written restores actually make:
#
#   1. THE WRONG DIFFERENTIAL. A differential only belongs to the full whose CheckpointLSN equals
#      the differential's DatabaseBackupLSN. Pick "the newest .bak in DIFF" and you can silently
#      pair a differential with a full it does not belong to; SQL rejects most of those, but the
#      failure reads as corruption rather than as operator error.
#   2. LOGS IN THE WRONG ORDER. Sorting log files by name or timestamp usually works and
#      occasionally does not. FirstLSN is the only ordering that is always right.
#   3. STOPAT WITH TOO MUCH PRECISION. SYSDATETIME() gives datetime2(7). Hand that to STOPAT and
#      SQL Server answers Msg 3217, every log is skipped, and you are left with only the full
#      restored - which looks exactly like data loss but is a bad parameter. Measured live on
#      2026-09-01. This script truncates to whole seconds and says so.
#
# WHAT IT WILL NOT DO
#   - It will not overwrite a live database by accident. Restoring over an existing database
#     needs -Force, or -AsName to restore beside it instead.
#   - It will not invent a chain. If the differential does not match the full, or a log is
#     missing from the middle, it says which file and stops rather than restoring a partial
#     database and reporting success.
#
# EXIT CODES: 0 restored and verified | 1 failure | 2 refused by preflight (no chain, database
#             exists without -Force, bad -StopAt) | 5 not elevated | 99 unhandled
# Log: C:\Scripts\restore-sql.log
# ================================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'restore-sql'
$ErrorActionPreference = 'Continue'

if($Help){
@"
restore-sql  -  restore a database from the backup-sql chain, and prove it came back.

USAGE:
  restore-sql -List                                    WHAT HAVE I GOT? every backup, with size
  restore-sql -List -Database SALES                    just this database
  restore-sql -List -Json                              the same, one JSON object per line
  restore-sql -Database SALES                          newest full + matching diff + all logs
  restore-sql -Database SALES -AsName SALES_COPY       restore BESIDE the live database
  restore-sql -Database SALES -StopAt '2026-09-01 01:04:23'    point in time
  restore-sql -Database SALES -WhatIf                  print the plan, restore nothing
  restore-sql -Database SALES -Force                   overwrite the existing database
  restore-sql -SelfCheck                               built-in assertions, no admin, no changes

OPTIONS:
  -SqlInstance   Default '.'. Use '.\NAME' for a named instance.
  -Database      The database as it was BACKED UP. Required.
  -AsName        Restore under a different name, with the data files renamed to match. This is
                 the safe way to test a restore on a server that already runs the real database.
  -Directory     Backup root. Default: read from the YC-SqlBackup* scheduled tasks, then
                 C:\dbbackupdaily. The layout is <root>\<hostname>\<database>\{FULL,DIFF,LOG}.
  -SourceHost    Restore from another machine's folder under the same root, e.g. after a rename
                 or when restoring a copy taken from a different server.
  -StopAt        Point in time. Any format PowerShell can parse as a date; it is truncated to
                 whole seconds, because STOPAT takes a datetime and datetime2(7) fails Msg 3217.
  -NoRecovery    Leave the database in RESTORING so you can apply more by hand.
  -Force         Allow overwriting an existing database of the target name.
  -WhatIf        Print the restore plan and change nothing.

EXIT CODES: 0 restored and verified, 1 failure, 2 refused by preflight, 5 not elevated,
            99 unhandled.  Log: C:\Scripts\restore-sql.log
"@ | Write-Host -ForegroundColor Cyan
  Stop-YcLog 0; exit 0
}

# ---------------------------------------------------------------------------------------------
# Pure helpers - everything -SelfCheck asserts lives here.
# ---------------------------------------------------------------------------------------------

# STOPAT takes a datetime. datetime2(7) - what SYSDATETIME() returns - is rejected with Msg 3217
# and every log is then skipped, leaving only the full restored. Truncate to whole seconds.
function ConvertTo-YcStopAt{
  param([string]$Value)
  if([string]::IsNullOrWhiteSpace($Value)){ return $null }
  $d = [datetime]::MinValue
  if(-not [datetime]::TryParse($Value,[ref]$d)){ return $null }
  return $d.ToString('yyyy-MM-ddTHH:mm:ss')
}

# A differential belongs to exactly one full: its DatabaseBackupLSN equals that full's
# CheckpointLSN. Any other pairing is not a chain, whatever the timestamps say.
function Test-YcDiffMatchesFull{
  param([string]$DiffDatabaseBackupLSN,[string]$FullCheckpointLSN)
  if(-not $DiffDatabaseBackupLSN -or -not $FullCheckpointLSN){ return $false }
  return ([string]$DiffDatabaseBackupLSN -eq [string]$FullCheckpointLSN)
}

# LSNs are decimal strings wider than [long] and wider than [double] can hold EXACTLY. A real
# LSN is 17+ digits; [double] keeps about 15 significant digits, so 44000000033200001 and
# 44000000033200009 compare EQUAL as doubles. That is how a log chain silently gets ordered
# wrongly or a gap goes undetected. [decimal] holds 28 digits, which covers every LSN SQL Server
# emits. Text comparison is not an option either: it makes 9 sort after 10.
function Compare-YcLsn{
  param([string]$A,[string]$B)
  $x = [decimal]0; $y = [decimal]0
  if(-not [decimal]::TryParse($A,[ref]$x)){ $x = [decimal]0 }
  if(-not [decimal]::TryParse($B,[ref]$y)){ $y = [decimal]0 }
  if($x -lt $y){ return -1 }
  if($x -gt $y){ return 1 }
  return 0
}

# Build the new physical file name when restoring under a different name, so two copies of the
# same database never fight over one .mdf.
function Get-YcMovedFileName{
  param([string]$LogicalName,[string]$OriginalPath,[string]$OldDb,[string]$NewDb,[string]$DataDir)
  $ext = [System.IO.Path]::GetExtension($OriginalPath)
  if(-not $ext){ $ext = '.mdf' }
  $leaf = $LogicalName
  if($OldDb -and $leaf.StartsWith($OldDb,[System.StringComparison]::OrdinalIgnoreCase)){
    $leaf = $NewDb + $leaf.Substring($OldDb.Length)
  } else {
    $leaf = $NewDb + '_' + $leaf
  }
  $leaf = ($leaf -replace '[\\/:*?"<>|]','_')
  return (Join-Path $DataDir ($leaf + $ext))
}

if($SelfCheck){
  $script:n = 0; $script:bad = 0
  function T{
    param([string]$What,[bool]$Ok)
    $script:n++
    if($Ok){ Write-Host ('  ok   ' + $What) -ForegroundColor Green }
    else   { Write-Host ('  FAIL ' + $What) -ForegroundColor Red; $script:bad++ }
  }
  T 'a datetime2(7) string is truncated to whole seconds' ((ConvertTo-YcStopAt '2026-09-01 01:04:23.4881479') -eq '2026-09-01T01:04:23')
  T 'a plain datetime survives'                           ((ConvertTo-YcStopAt '2026-09-01 01:04:23')         -eq '2026-09-01T01:04:23')
  T 'garbage is rejected, not guessed'                    ($null -eq (ConvertTo-YcStopAt 'not-a-date'))
  T 'empty is null'                                       ($null -eq (ConvertTo-YcStopAt ''))
  T 'a diff matching its full is accepted'                (Test-YcDiffMatchesFull '44000000029400001' '44000000029400001')
  T 'a diff from another full is rejected'                (-not (Test-YcDiffMatchesFull '44000000029400001' '44000000031100001'))
  T 'a missing LSN is rejected'                           (-not (Test-YcDiffMatchesFull '' '44000000029400001'))
  T 'LSNs compare as numbers, not text'                   ((Compare-YcLsn '9000000000000001' '10000000000000001') -eq -1)
  T 'equal LSNs compare equal'                            ((Compare-YcLsn '44000000029400001' '44000000029400001') -eq 0)
  # These two differ only in digits a [double] cannot hold. They caught a real precision bug.
  T '17-digit LSNs differing in the last digit compare'   ((Compare-YcLsn '44000000033200001' '44000000033200009') -eq -1)
  T 'and the reverse'                                     ((Compare-YcLsn '44000000033200009' '44000000033200001') -eq 1)
  T 'a renamed file keeps its extension'                  ((Get-YcMovedFileName 'SALES_log' 'D:\x\SALES_log.ldf' 'SALES' 'SALES_COPY' 'C:\Data\') -eq 'C:\Data\SALES_COPY_log.ldf')
  T 'an unrelated logical name is prefixed'               ((Get-YcMovedFileName 'ftrow' 'D:\x\ftrow.ndf' 'SALES' 'COPY' 'C:\Data\') -eq 'C:\Data\COPY_ftrow.ndf')
  Write-Host ''
  if($script:bad -eq 0){ Write-Host ('SELF-CHECK PASSED: ' + $script:n + ' assertions') -ForegroundColor Green; Stop-YcLog 0; exit 0 }
  Write-Host ('SELF-CHECK FAILED: ' + $script:bad + ' of ' + $script:n + ' assertions') -ForegroundColor Red
  Stop-YcLog 1; exit 1
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation -BoundParameters $PSBoundParameters

# -List answers "what have I actually got?" - the question asked before every restore, and the
# one nobody could answer without walking the folders by hand. It shares this script's backup
# root discovery so the list can never disagree with what a restore would pick.
if($List){
  $root = $Directory
  if(-not $root){
    foreach($t in (Get-ScheduledTask -TaskName 'YC-SqlBackup*' -ErrorAction SilentlyContinue)){
      foreach($a in $t.Actions){ if("$($a.Arguments)" -match "@Directory\s*=\s*N'([^']+)'"){ $root = $Matches[1]; break } }
      if($root){ break }
    }
  }
  if(-not $root){ $root = 'C:\dbbackupdaily' }
  if(-not (Test-Path -LiteralPath $root)){ Exit-Yc 2 ('No backup root at ' + $root + '.') 'ERROR' }
  $items = @()
  foreach($hostDir in @(Get-ChildItem -LiteralPath $root -Directory -EA SilentlyContinue)){
    if($SourceHost -and $hostDir.Name -ne $SourceHost){ continue }
    foreach($dbDir in @(Get-ChildItem -LiteralPath $hostDir.FullName -Directory -EA SilentlyContinue)){
      if($Database -and $dbDir.Name -ne $Database){ continue }
      foreach($typeDir in @(Get-ChildItem -LiteralPath $dbDir.FullName -Directory -EA SilentlyContinue)){
        foreach($f in @(Get-ChildItem -LiteralPath $typeDir.FullName -File -EA SilentlyContinue)){
          $items += [pscustomobject]@{
            Host = $hostDir.Name; Database = $dbDir.Name; Type = $typeDir.Name
            When = $f.LastWriteTime.ToString('yyyy-MM-ddTHH:mm:sszzz')
            Bytes = $f.Length; SizeMB = [math]::Round($f.Length/1MB,2)
            File = $f.Name; Location = $f.DirectoryName
          }
        }
      }
    }
  }
  $items = @($items | Sort-Object Database, When)
  if($Json){
    foreach($i in $items){ Write-Output ($i | ConvertTo-Json -Compress -Depth 3) }
    Exit-Yc 0 ('Listed ' + $items.Count + ' backup file(s) as JSON.') 'OK'
  }
  Write-Host ''
  Write-Host ('  {0,-26} {1,-5} {2,-27} {3,10}  {4}' -f 'DATABASE','TYPE','WHEN','SIZE MB','FILE')
  Write-Host ('  ' + ('-' * 128))
  foreach($i in $items){
    Write-Host ('  {0,-26} {1,-5} {2,-27} {3,10}  {4}' -f $i.Database,$i.Type,$i.When,$i.SizeMB,$i.File)
  }
  Write-Host ('  ' + ('-' * 128))
  $tot = 0; foreach($i in $items){ $tot += $i.Bytes }
  $locs = @($items | Select-Object -Expand Location -Unique)
  Write-Host ('  {0} file(s), {1} MB total, across {2} location(s):' -f $items.Count,[math]::Round($tot/1MB,2),$locs.Count)
  foreach($l in $locs){ Write-Host ('    ' + $l) }
  Write-Host ''
  Exit-Yc 0 ('Listed ' + $items.Count + ' backup file(s), ' + [math]::Round($tot/1MB,2) + ' MB, root ' + $root + '.') 'OK'
}

if([string]::IsNullOrWhiteSpace($Database)){
  Exit-Yc 2 '-Database is required. Run restore-sql -Help.' 'ERROR'
}
$target = if($AsName){ $AsName } else { $Database }

$stop = $null
if($StopAt){
  $stop = ConvertTo-YcStopAt $StopAt
  if(-not $stop){ Exit-Yc 2 ('-StopAt "' + $StopAt + '" is not a date this script can parse.') 'ERROR' }
  if($stop -ne $StopAt){
    Write-YcLog ('-StopAt truncated to whole seconds: "' + $stop + '". STOPAT takes a datetime; a ' +
      'datetime2(7) value is rejected with Msg 3217 and every log is then skipped, which looks ' +
      'like data loss but is only a bad parameter.') 'WARN'
  }
}

# ---- connection ------------------------------------------------------------------------------
$script:Cn = $null
try{
  Add-Type -AssemblyName 'System.Data' -ErrorAction SilentlyContinue
  $cs = 'Server=' + $SqlInstance + ';Database=master;Integrated Security=SSPI;Connect Timeout=20' +
        ';Application Name=YallaCloud-restore-sql'
  $script:Cn = New-Object System.Data.SqlClient.SqlConnection $cs
  $script:Cn.Open()
}catch{
  Exit-Yc 1 ('Could not connect to "' + $SqlInstance + '": ' + $_.Exception.Message +
    '. Use HOST\INSTANCE for a named instance and check the service is running.') 'ERROR'
}

function Invoke-YcRows{
  param([string]$Sql,[int]$TimeoutSec = 120)
  $rows = @()
  try{
    $c = $script:Cn.CreateCommand(); $c.CommandText = $Sql; $c.CommandTimeout = $TimeoutSec
    $rd = $c.ExecuteReader()
    while($rd.Read()){
      $h = @{}
      for($i = 0; $i -lt $rd.FieldCount; $i++){ $h[$rd.GetName($i)] = $rd.GetValue($i) }
      $rows += ,$h
    }
    $rd.Close()
    $script:YcErr = ''
  }catch{ $script:YcErr = $_.Exception.Message; return $null }
  return ,$rows
}
function Invoke-YcExec{
  param([string]$Sql,[int]$TimeoutSec = 3600)
  try{
    $c = $script:Cn.CreateCommand(); $c.CommandText = $Sql; $c.CommandTimeout = $TimeoutSec
    [void]$c.ExecuteNonQuery()
    $script:YcErr = ''
    return $true
  }catch{ $script:YcErr = $_.Exception.Message; return $false }
}
# Invoke-YcRows returns $null when the QUERY failed, and @($null) has Count 1 - so wrapping a
# failed query in @() silently produces "one row" of nothing. That produced a MOVE clause with an
# empty logical name and a restore that died on statement 1. Every caller goes through here now:
# a failed query stops the run and says which query, instead of being mistaken for data.
function Get-YcRowsOrFail{
  param([string]$Sql,[string]$What)
  $r = Invoke-YcRows $Sql
  if($null -eq $r){
    Exit-Yc 1 ('Could not ' + $What + ': ' + $script:YcErr) 'ERROR'
  }
  return ,@($r)
}
function Get-YcLit{ param([string]$V) return ("$V" -replace "'","''") }
function Get-YcBr { param([string]$V) return ("$V" -replace '\]',']]') }

# ---- where are the backups? -------------------------------------------------------------------
$root = $Directory
if(-not $root){
  foreach($t in (Get-ScheduledTask -TaskName 'YC-SqlBackup*' -ErrorAction SilentlyContinue)){
    foreach($a in $t.Actions){
      if("$($a.Arguments)" -match "@Directory\s*=\s*N'([^']+)'"){ $root = $Matches[1]; break }
    }
    if($root){ break }
  }
}
if(-not $root){ $root = 'C:\dbbackupdaily' }
$hostFolder = if($SourceHost){ $SourceHost } else { $env:COMPUTERNAME }
$dbRoot = Join-Path (Join-Path $root $hostFolder) $Database
Write-YcLog ('Backup root: ' + $root + '   looking in ' + $dbRoot)
if(-not (Test-Path -LiteralPath $dbRoot)){
  $avail = @()
  $hr = Join-Path $root $hostFolder
  if(Test-Path -LiteralPath $hr){ $avail = @(Get-ChildItem -LiteralPath $hr -Directory -EA SilentlyContinue | Select-Object -Expand Name) }
  Exit-Yc 2 ('No backups for "' + $Database + '" under ' + $dbRoot + '.' +
    $(if($avail.Count){ ' Databases present there: ' + ($avail -join ', ') + '.' }else{ ' That folder does not exist.' }) +
    ' Use -Directory for another root, or -SourceHost for another machine''s folder.') 'ERROR'
}

# ---- read every candidate header ---------------------------------------------------------------
function Get-YcHeader{
  param([string]$Path)
  $r = Invoke-YcRows ("RESTORE HEADERONLY FROM DISK = N'" + (Get-YcLit $Path) + "'")
  if($null -eq $r -or $r.Count -eq 0){ return $null }
  $h = $r[0]
  return [pscustomobject]@{
    Path              = $Path
    Type              = [string]$h['BackupType']
    FirstLSN          = [string]$h['FirstLSN']
    LastLSN           = [string]$h['LastLSN']
    CheckpointLSN     = [string]$h['CheckpointLSN']
    DatabaseBackupLSN = [string]$h['DatabaseBackupLSN']
    RecoveryForkID    = [string]$h['RecoveryForkID']
    ForkPointLSN      = [string]$h['ForkPointLSN']
    Finish            = $h['BackupFinishDate']
  }
}

$fulls = @(Get-ChildItem -LiteralPath (Join-Path $dbRoot 'FULL') -Filter *.bak -File -EA SilentlyContinue | Sort-Object LastWriteTime)
if($fulls.Count -eq 0){ Exit-Yc 2 ('No FULL backup under ' + (Join-Path $dbRoot 'FULL') + '. A chain cannot start without one.') 'ERROR' }

# With -StopAt the NEWEST full is usually the wrong base. If it was taken after the stop time,
# restoring it already carries the database past the point asked for, and SQL answers "The
# specified STOPAT time is too early. All or part of the database is already rolled forward
# beyond that point." The base has to be the newest full finishing at or BEFORE the stop.
# Measured live on 2026-09-01: the first version of this script picked the newest full and hit
# exactly that error.
$stopDt = [datetime]::MinValue
$haveStopDt = $false
if($stop){ $haveStopDt = [datetime]::TryParse($stop,[ref]$stopDt) }

$full = $null
$skippedForStop = 0
for($i = $fulls.Count - 1; $i -ge 0; $i--){
  $h = Get-YcHeader $fulls[$i].FullName
  if(-not $h -or $h.Type -ne '1'){ continue }
  if($haveStopDt){
    $fin = [datetime]::MinValue
    if([datetime]::TryParse([string]$h.Finish,[ref]$fin) -and $fin -gt $stopDt){ $skippedForStop++; continue }
  }
  $full = $h; break
}
if(-not $full){
  if($skippedForStop -gt 0){
    Exit-Yc 2 ('-StopAt ' + $stop + ' is earlier than every full backup present (' + $skippedForStop +
      ' skipped because they finished after that time). A restore needs a full taken at or before ' +
      'the point in time you want; the oldest full here is the earliest point reachable.') 'ERROR'
  }
  Exit-Yc 2 ('None of the ' + $fulls.Count + ' file(s) in FULL could be read as a full database backup.') 'ERROR'
}
if($skippedForStop -gt 0){
  Write-YcLog ('Skipped ' + $skippedForStop + ' full backup(s) taken after -StopAt; using an earlier one as the base.') 'WARN'
}
Write-YcLog ('FULL  : ' + (Split-Path -Leaf $full.Path) + '  finished ' + $full.Finish + '  CheckpointLSN ' + $full.CheckpointLSN)

$diff = $null
foreach($f in @(Get-ChildItem -LiteralPath (Join-Path $dbRoot 'DIFF') -Filter *.bak -File -EA SilentlyContinue | Sort-Object LastWriteTime -Descending)){
  $h = Get-YcHeader $f.FullName
  if(-not $h){ continue }
  if($h.Type -ne '5'){ continue }
  if($haveStopDt){
    $dfin = [datetime]::MinValue
    if([datetime]::TryParse([string]$h.Finish,[ref]$dfin) -and $dfin -gt $stopDt){ continue }
  }
  if(Test-YcDiffMatchesFull -DiffDatabaseBackupLSN $h.DatabaseBackupLSN -FullCheckpointLSN $full.CheckpointLSN){ $diff = $h; break }
}
if($diff){ Write-YcLog ('DIFF  : ' + (Split-Path -Leaf $diff.Path) + '  finished ' + $diff.Finish + ' (DatabaseBackupLSN matches the full)') }
else     { Write-YcLog 'DIFF  : none that belongs to this full - the logs alone will carry the chain forward.' }

$redoFrom = if($diff){ $diff.LastLSN } else { $full.LastLSN }
# EVERY point-in-time restore creates a new RECOVERY FORK, and its later log backups land in the
# same folder as the ones from the original timeline. Their LSNs interleave, so filtering on LSN
# alone eventually picks up a log from a timeline this full never belonged to, and SQL rejects it
# with Msg 4305 as if a backup were missing. Any database that has ever been restored to a point
# in time has this. Keep only the logs on the same fork as the full being restored.
$logs = @()
$otherFork = 0
foreach($f in @(Get-ChildItem -LiteralPath (Join-Path $dbRoot 'LOG') -Filter *.trn -File -EA SilentlyContinue)){
  $h = Get-YcHeader $f.FullName
  if(-not $h -or $h.Type -ne '2'){ continue }
  if((Compare-YcLsn $h.LastLSN $redoFrom) -le 0){ continue }
  if($full.RecoveryForkID -and $h.RecoveryForkID -and $h.RecoveryForkID -ne $full.RecoveryForkID){ $otherFork++; continue }
  $logs += $h
}
if($otherFork -gt 0){
  Write-YcLog ('Ignored ' + $otherFork + ' log backup(s) belonging to a different recovery fork - they came ' +
    'from a timeline created by an earlier point-in-time restore and cannot be applied to this one.') 'WARN'
}
$logs = @($logs | Sort-Object @{ Expression = { [decimal]$_.FirstLSN } })
Write-YcLog ('LOGS  : ' + $logs.Count + ' after the ' + $(if($diff){'differential'}else{'full'}) + ', applied in FirstLSN order.')

# A gap in the middle is the one thing that must not be discovered halfway through a restore.
for($i = 1; $i -lt $logs.Count; $i++){
  if((Compare-YcLsn $logs[$i].FirstLSN $logs[$i-1].LastLSN) -gt 0){
    Write-YcLog ('CHAIN BROKEN: ' + (Split-Path -Leaf $logs[$i].Path) + ' starts at LSN ' + $logs[$i].FirstLSN +
      ' but the previous log ends at ' + $logs[$i-1].LastLSN + '. A log backup is missing between them. ' +
      'Restoring past this point is not possible with the files present.') 'ERROR'
    Exit-Yc 2 'Refusing to restore a broken chain.' 'ERROR'
  }
}

# ---- target database ----------------------------------------------------------------------------
# @($null).Count is 1 in PowerShell, so wrapping a failed query in @() reports "one row" and the
# check below would announce that a database exists whenever the QUERY failed. Distinguish the
# three outcomes explicitly: rows, no rows, or the question could not be asked.
$exists = Get-YcRowsOrFail ("SELECT name FROM sys.databases WHERE name = N'" + (Get-YcLit $target) + "'") ('ask whether "' + $target + '" already exists - refusing to restore while blind to that')
if($exists.Count -gt 0 -and -not $Force -and -not $WhatIf){
  Exit-Yc 2 ('Database "' + $target + '" already exists on ' + $SqlInstance + '. Restoring over it would ' +
    'discard whatever is in it now. Pass -AsName to restore beside it, or -Force to overwrite it ' +
    'deliberately. Nothing was changed.') 'ERROR'
}

$dataDir = ''
$dd = Get-YcRowsOrFail "SELECT CONVERT(nvarchar(400),SERVERPROPERTY('InstanceDefaultDataPath')) AS P" 'read the default data path'
if($dd.Count -gt 0){ $dataDir = [string]$dd[0]['P'] }
if(-not $dataDir){ $dataDir = 'C:\SQLData\Data\' }

$moveClause = ''
if($AsName){
  $files = Get-YcRowsOrFail ("RESTORE FILELISTONLY FROM DISK = N'" + (Get-YcLit $full.Path) + "'") ('read the file list from ' + $full.Path)
  if($files.Count -eq 0){ Exit-Yc 1 ('The file list from ' + $full.Path + ' is empty - that is not a usable full backup.') 'ERROR' }
  $parts = @()
  foreach($f in $files){
    $ln = [string]$f['LogicalName']
    $np = Get-YcMovedFileName -LogicalName $ln -OriginalPath ([string]$f['PhysicalName']) -OldDb $Database -NewDb $AsName -DataDir $dataDir
    $parts += ("MOVE N'" + (Get-YcLit $ln) + "' TO N'" + (Get-YcLit $np) + "'")
    if(-not $ln){ Exit-Yc 1 ('RESTORE FILELISTONLY returned a row with no LogicalName for ' + $full.Path + ' - the backup header is not readable.') 'ERROR' }
    Write-YcLog ('  MOVE ' + $ln + ' -> ' + $np)
  }
  $moveClause = ', ' + ($parts -join ', ')
}

# ---- the plan -----------------------------------------------------------------------------------
$plan = @()
$plan += ("RESTORE DATABASE [" + (Get-YcBr $target) + "] FROM DISK = N'" + (Get-YcLit $full.Path) + "' WITH NORECOVERY, REPLACE" + $moveClause + ";")
if($diff){ $plan += ("RESTORE DATABASE [" + (Get-YcBr $target) + "] FROM DISK = N'" + (Get-YcLit $diff.Path) + "' WITH NORECOVERY;") }
foreach($l in $logs){
  $w = 'WITH NORECOVERY'
  if($stop){ $w += (", STOPAT = N'" + $stop + "'") }
  $plan += ("RESTORE LOG [" + (Get-YcBr $target) + "] FROM DISK = N'" + (Get-YcLit $l.Path) + "' " + $w + ";")
}
if(-not $NoRecovery){ $plan += ("RESTORE DATABASE [" + (Get-YcBr $target) + "] WITH RECOVERY;") }

Write-YcLog ('PLAN  : ' + $plan.Count + ' statement(s), restoring "' + $Database + '" as "' + $target + '"' +
  $(if($stop){ ' to ' + $stop }else{ '' }) + '.')
foreach($p in $plan){ Write-YcLog ('   ' + $p) }

if($WhatIf){
  Write-YcLog 'WHATIF - nothing was restored.' 'WARN'
  Exit-Yc 0 'Plan printed only.' 'OK'
}

# ---- run it ---------------------------------------------------------------------------------------
if($exists.Count -gt 0){
  Write-YcLog ('Taking "' + $target + '" to SINGLE_USER so the restore is not blocked by open sessions.') 'WARN'
  [void](Invoke-YcExec ("ALTER DATABASE [" + (Get-YcBr $target) + "] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;"))
}
$step = 0
foreach($p in $plan){
  $step++
  if(-not (Invoke-YcExec $p)){
    Write-YcLog ('Statement ' + $step + ' of ' + $plan.Count + ' FAILED: ' + $script:YcErr) 'ERROR'
    Write-YcLog ('The database is left in whatever state that statement reached. It has NOT been ' +
      'recovered, so you can still apply more by hand.') 'WARN'
    Exit-Yc 1 'Restore failed.' 'ERROR'
  }
  Write-YcLog ('  ok ' + $step + '/' + $plan.Count)
}

# ---- prove it -------------------------------------------------------------------------------------
if($NoRecovery){
  Write-YcLog ('-NoRecovery: "' + $target + '" is left in RESTORING on purpose. Finish with ' +
    'RESTORE DATABASE [' + $target + '] WITH RECOVERY;') 'WARN'
  Exit-Yc 0 ('Chain applied, database left in RESTORING as asked.') 'OK'
}
$state = Get-YcRowsOrFail ("SELECT CONVERT(nvarchar(60),DATABASEPROPERTYEX(N'" + (Get-YcLit $target) + "','Status')) AS S," +
                           "CONVERT(nvarchar(60),DATABASEPROPERTYEX(N'" + (Get-YcLit $target) + "','Recovery')) AS R") 'read the restored database state'
$st = if($state.Count){ [string]$state[0]['S'] } else { '' }
if($st -ne 'ONLINE'){
  Exit-Yc 1 ('VERIFICATION FAILED: after the restore, "' + $target + '" reports status "' + $st +
    '" instead of ONLINE.') 'ERROR'
}
[void](Invoke-YcExec ("ALTER DATABASE [" + (Get-YcBr $target) + "] SET MULTI_USER;"))
$tabN = '?'
$tab = Invoke-YcRows ("SELECT CONVERT(nvarchar(20),COUNT(*)) AS N FROM [" + (Get-YcBr $target) + "].sys.tables")
if($null -ne $tab -and @($tab).Count -gt 0){ $tabN = [string]@($tab)[0]['N'] }
Write-YcLog ('VERIFIED: "' + $target + '" is ONLINE, recovery ' + $(if($state.Count){[string]$state[0]['R']}else{'?'}) +
  ', ' + $tabN + ' user table(s). Restored from ' +
  (Split-Path -Leaf $full.Path) + $(if($diff){ ' + ' + (Split-Path -Leaf $diff.Path) }else{ '' }) +
  ' + ' + $logs.Count + ' log(s)' + $(if($stop){ ', stopped at ' + $stop }else{ '' }) + '.') 'OK'
Exit-Yc 0 'restore-sql complete.' 'OK'
