param(
  [string]$Profile = 'default',
  [string]$Path,
  [string]$Key,
  [ValidateSet('Upload','Download')]
  [string]$Direction = 'Upload',
  [switch]$Recurse,
  [string]$Prefix,
  [string]$StorageClass,
  [int]$Retries = 4,
  [int]$PartSizeMB = 64,
  [switch]$Checksum,
  [switch]$DeleteSourceOnSuccess,
  [switch]$List,
  [ValidateSet('auto','builtin','module')]
  [string]$Engine = 'auto',
  [switch]$WhatIf,
  [switch]$Help
)
# ================================================================================================
# Transfer-S3.ps1 - YALLACLOUD day-2 command: upload and download files to an S3-COMPATIBLE endpoint
# configured by set-s3config. This is the command collect-logs and backup-sql hand their output to.
# PowerShell 5.1 only, ASCII only, Windows Server 2016-2025.
#
# ------------------------------------------------------------------------------------------------
# THE IMPLEMENTATION DECISION, AND WHY
# ------------------------------------------------------------------------------------------------
# Three options were on the table: the AWS Tools for PowerShell module (AWS.Tools.S3), the AWS CLI
# v2, or a hand-rolled SigV4 signer over the .NET HTTP stack. This command uses BOTH ends of that
# range, deliberately:
#
#   PRIMARY / ALWAYS PRESENT: a built-in AWS Signature Version 4 signer over
#   System.Net.HttpWebRequest, implementing exactly six operations - HEAD object, HEAD bucket,
#   GET object, PUT object, ListObjectsV2, and the four multipart calls (Create/UploadPart/
#   Complete/Abort). Reasons:
#     * ZERO DEPENDENCIES. It works on a sealed, air-gapped Server 2016 golden image with nothing
#       installed but Windows PowerShell 5.1. AWS.Tools.S3 5.x requires .NET Framework 4.7.2 or
#       newer under Windows PowerShell (Server 2016 ships 4.6.2 and needs an update first) and has
#       to be staged offline via Save-Module; the AWS CLI v2 is a 30 MB MSI that also has to be
#       staged and versioned in the image. A backup command that cannot run because a module is
#       missing is worse than a slower one.
#     * THE VERIFICATION HAS TO EXIST ANYWAY. "PROVE the upload" means a real HEAD of the object
#       after the fact. That is a signed request, so the signer is not optional overhead - it is
#       the smallest piece of the job.
#     * IT NEVER PUTS THE SECRET ON A COMMAND LINE. The secret is decrypted from the DPAPI blob in
#       this process and used to derive an HMAC signing key. It is never an argument, never an
#       environment variable, and never appears in a URL: this command does NOT create presigned
#       URLs, because a presigned URL is a bearer credential and would end up in a log.
#     * The correctness risk of a hand-rolled signer is real and is mitigated the only honest way:
#       the signing surface is deliberately tiny (no presigning, no chunked signing, no STS, no
#       SSE-C), UNSIGNED-PAYLOAD is used over HTTPS exactly as the S3 API documents, and every
#       transfer is proved afterwards by an independent HEAD rather than by "the call returned 0".
#
#   OPTIONAL / USED WHEN PRESENT: AWS.Tools.S3 (or AWSPowerShell / AWSPowerShell.NetCore). When the
#   module is importable and -Engine is auto or module, uploads of files larger than the multipart
#   threshold are handed to Write-S3Object, whose TransferUtility does parallel, resumable multipart
#   and is far better tested than anything written here. It is driven with -EndpointUrl and
#   -ForcePathStyleAddressing, which are documented parameters of every S3 cmdlet:
#   -ForcePathStyleAddressing "default value is $true when the EndpointUrl parameter is specified",
#   which is precisely the Wasabi / Ceph RGW / MinIO case.
#   https://docs.aws.amazon.com/powershell/v5/reference/items/Write-S3Object.html
#   Even then the PROOF is done by the built-in signer, so the thing that says "the object is there
#   and it is the right size" is never the same code that put it there.
#
# WHY MULTIPART IS NOT OPTIONAL
#   A single PUT can carry at most 5 GB (AWS S3 documented limit, and every S3-compatible server
#   enforces the same). A SQL Server full backup of any real database exceeds that. Multipart takes
#   an object to 10,000 parts of 5 MiB..5 GiB each. -PartSizeMB defaults to 64, and is raised
#   automatically if the file would otherwise need more than 10,000 parts.
#
# HOW INTEGRITY IS PROVED, EXACTLY
#   * The MD5 of every byte actually written to the socket is computed AS IT IS STREAMED, so it
#     costs no extra disk I/O. For a single PUT that MD5 is the object's ETag, and it is compared
#     against the ETag the server returns. For a multipart upload the part MD5s are combined into
#     the documented composite ETag (MD5 of the concatenated part digests, then "-<partcount>") and
#     compared the same way.
#   * After EVERY transfer, in EVERY engine, the object is HEADed and its Content-Length compared to
#     the local file length. A mismatch is a hard, non-zero failure.
#   * If the machine is in FIPS mode MD5 is unavailable; the command says so and falls back to the
#     size proof rather than pretending it verified a checksum.
#   * -Checksum additionally signs the real SHA-256 payload hash instead of UNSIGNED-PAYLOAD, which
#     makes the SERVER reject a body that was corrupted in flight. It costs one extra read pass over
#     the file, which is why it is opt-in for large files. Over plain http it is forced on, because
#     UNSIGNED-PAYLOAD is only sanctioned for HTTPS.
#
# WHAT IS NEVER LOGGED
#   The secret key, the derived signing key, the Authorization header, and any URL carrying
#   credentials. Only method, host, bucket, key, status code and byte counts are logged.
# ================================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'transfer-s3'
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$script:S3Dir        = 'C:\Scripts\s3'
$script:S3Entropy    = [Text.Encoding]::UTF8.GetBytes('YallaCloud-s3-config-v1')
$script:CtlTimeoutMs = 60000        # control-plane calls: HEAD, list, create/complete multipart
$script:DataTimeoutMs = 3600000     # data-plane calls: PUT of a part, GET of an object
$script:CopyBuffer   = 1MB
$script:SinglePutMax = 5GB          # documented S3 limit for a single PUT
$script:MaxParts     = 10000        # documented S3 limit
$script:Md5Available = $true

trap {
  Write-YcLog ('UNHANDLED ERROR at line ' + $_.InvocationInfo.ScriptLineNumber + ': ' + $_.Exception.Message) 'ERROR'
  if ($_.ScriptStackTrace) { Write-YcLog ('Stack: ' + ($_.ScriptStackTrace -replace "`r?`n", ' | ')) 'ERROR' }
  Exit-Yc 99 'transfer-s3 aborted on an unhandled error.' 'ERROR'
}

if ($Help) {
@"
transfer-s3  -  upload and download files to the S3-compatible endpoint stored by set-s3config.
                Multipart for anything over 5 GB, retries with backoff, and every transfer PROVED
                by an independent HEAD of the object afterwards.

USAGE:
  transfer-s3 -Path <file|folder> [-Key <object key>] [-Prefix <p>] [-Recurse] [-Profile <name>]
  transfer-s3 -Direction Download -Key <object key> -Path <local file|folder> [-Profile <name>]
  transfer-s3 -List [-Prefix <p>] [-Profile <name>]
  transfer-s3 -Help

PARAMETERS:
  -Profile               set-s3config profile to use. Default 'default'.
  -Path                  Upload: the local file or folder to send. Download: where to write.
  -Key                   Remote object key. Upload: defaults to <prefix>/<filename>. Download: required.
  -Direction             Upload (default) or Download.
  -Recurse               Upload every file under -Path, preserving the relative path in the key.
  -Prefix                Key prefix. Overrides the profile's stored prefix. A trailing / is optional.
  -StorageClass          x-amz-storage-class, e.g. STANDARD, STANDARD_IA, GLACIER, or a vendor class
                         such as Wasabi's STANDARD. Sent only when supplied; unknown classes are
                         rejected by the server, and that rejection is reported, not swallowed.
  -Retries               Attempts per HTTP call before giving up. Default 4. Backoff 3s, 6s, 12s, 24s.
                         Only 408/429/5xx and network errors are retried; a 403 is not retried.
  -PartSizeMB            Multipart part size in MB. Default 64. Valid 5-5120. Raised automatically if
                         the file would otherwise need more than 10000 parts.
  -Checksum              Sign the real SHA-256 of every part instead of UNSIGNED-PAYLOAD, so the
                         SERVER rejects a body corrupted in flight, and require the ETag comparison
                         to succeed. Costs one extra read pass over the file. Forced on over http.
  -DeleteSourceOnSuccess Delete the local file, but ONLY after the remote HEAD has proved size (and
                         checksum where available). Never before.
  -List                  List objects under the prefix and exit.
  -Engine                auto (default) | builtin | module. auto uses AWS.Tools.S3 for large uploads
                         when the module is importable, and the built-in SigV4 signer otherwise.
                         The verification HEAD always uses the built-in signer.
  -WhatIf                Show exactly what would be transferred and transfer nothing.
  -Help                  Show this help and exit.

BEHAVIOUR:
  - Idempotent in the only sense that matters for object storage: re-running overwrites the object
    with the same content and re-proves it. Nothing local is deleted unless the remote copy is proved.
  - Objects larger than the part size (and always larger than 5 GB) use multipart upload; an aborted
    or failed multipart upload is explicitly aborted server-side so it does not accrue storage cost.
  - A download is written to <target>.part and only renamed once size (and checksum where the ETag is
    a plain MD5) match, so a truncated download can never masquerade as a good file.
  - The secret key is decrypted from the DPAPI blob in-process. It is never an argument to any
    program, never an environment variable, and never part of a URL.

EXAMPLES:
  transfer-s3 -Path C:\dbbackupdaily\PRODSQL01_SALES_FULL_20260816_011500.bak -Prefix sql/PRODSQL01
  transfer-s3 -Path C:\Scripts\collect-logs-20260816.zip -Key diag/host01/20260816.zip -Checksum
  transfer-s3 -Path D:\exports -Recurse -Prefix exports/host01 -DeleteSourceOnSuccess
  transfer-s3 -Direction Download -Key sql/PRODSQL01/SALES_FULL.bak -Path D:\restore\SALES_FULL.bak
  transfer-s3 -List -Prefix sql/PRODSQL01
  transfer-s3 -Path C:\big.bak -PartSizeMB 256 -Retries 6

EXIT CODES:
   0  Success - every requested transfer completed AND was proved by a remote HEAD.
   1  Generic failure.
   2  Invalid or missing arguments.
   3  The profile does not exist or is not valid JSON (run set-s3config).
   4  The local path does not exist, or no file matched -Path / -Recurse.
   5  Not running as Administrator (from _yc-lib.ps1).
   6  The stored secret could not be decrypted on this machine (DPAPI blob from another host).
   7  Authentication or authorization failed (HTTP 401/403).
   8  The endpoint could not be reached (DNS, TLS, connection, timeout) after all retries.
   9  A transfer failed after all retries.
  10  VERIFICATION FAILED: the object is missing, the wrong size, or the checksum does not match.
      Nothing local was deleted in this case.
  99  Unhandled terminating error.

Log: C:\Scripts\transfer-s3.log   (mirrored to the Application event log, source YallaCloud)
Machine-readable proof lines in the log look like:  [YC-S3-PROOF] key=<k> bytes=<n> etag=<e> http=200
"@ | Write-Host -ForegroundColor Cyan
  Exit-Yc 0
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation -BoundParameters $PSBoundParameters

# ------------------------------------------------------------------------------------------------
# Profile
# ------------------------------------------------------------------------------------------------
Add-Type -AssemblyName System.Security

$profileName = $Profile
if (-not $profileName) { $profileName = 'default' }
$cfgPath = Join-Path $script:S3Dir ($profileName + '.json')
if (-not (Test-Path -LiteralPath $cfgPath)) {
  Exit-Yc 3 ('S3 profile "' + $profileName + '" does not exist (' + $cfgPath + '). Create it with: set-s3config -Endpoint ... -Region ... -Bucket ... -AccessKey ... -SecretKeyFile ...') 'ERROR'
}
$pj = $null
try { $pj = (Get-Content -LiteralPath $cfgPath -Raw) | ConvertFrom-Json } catch {
  Exit-Yc 3 ($cfgPath + ' is not valid JSON: ' + $_.Exception.Message) 'ERROR'
}
$secret = $null
try {
  $blob = [Convert]::FromBase64String([string]$pj.SecretKeyDpapi)
  $sb   = [System.Security.Cryptography.ProtectedData]::Unprotect($blob, $script:S3Entropy, [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
  $secret = [Text.Encoding]::UTF8.GetString($sb)
  for ($i = 0; $i -lt $sb.Length; $i++) { $sb[$i] = 0 }
} catch {
  Exit-Yc 6 ('The secret for profile "' + $profileName + '" could not be decrypted on this machine (' + $_.Exception.Message + '). A DPAPI LocalMachine blob only decrypts on the host that created it - re-run set-s3config here.') 'ERROR'
}
if (-not $secret) { Exit-Yc 6 ('The secret for profile "' + $profileName + '" decrypted to an empty string.') 'ERROR' }

$S3 = @{
  Endpoint     = [string]$pj.Endpoint
  Region       = [string]$pj.Region
  Bucket       = [string]$pj.Bucket
  AccessKey    = [string]$pj.AccessKey
  SecretKey    = $secret
  UsePathStyle = [bool]$pj.UsePathStyle
  Prefix       = [string]$pj.Prefix
}
if ($PSBoundParameters.ContainsKey('Prefix')) { $S3['Prefix'] = $Prefix }
$S3['Prefix'] = ([string]$S3['Prefix']).Trim().Trim('/')
$epUri = $null
try { $epUri = [Uri]$S3['Endpoint'] } catch { $epUri = $null }
if (-not $epUri -or -not $epUri.Host) {
  Exit-Yc 3 ('The profile has an unusable Endpoint value: "' + $S3['Endpoint'] + '". Re-run set-s3config.') 'ERROR'
}
$script:IsHttps = ($epUri.Scheme -eq 'https')
if (-not $script:IsHttps -and -not $Checksum) {
  Write-YcLog 'The endpoint is plain http, so UNSIGNED-PAYLOAD is not appropriate - the real SHA-256 payload hash will be signed for every part (as if -Checksum had been given).' 'WARN'
}
$script:SignPayload = ($Checksum -or -not $script:IsHttps)

Write-YcLog ('Profile "' + $profileName + '": ' + $S3['Endpoint'] + ' bucket ' + $S3['Bucket'] + ' region ' + $S3['Region'] +
             ' ' + $(if ($S3['UsePathStyle']) { 'path-style' } else { 'virtual-host style' }) +
             $(if ($S3['Prefix']) { ' prefix ' + $S3['Prefix'] } else { ' no prefix' }) +
             ' access key ' + (Protect-YcSecret $S3['AccessKey'] -Whole -Keep 4))

if ($Retries -lt 1)      { $Retries = 1 }
if ($Retries -gt 10)     { $Retries = 10 }
if ($PartSizeMB -lt 5)   { Exit-Yc 2 ('-PartSizeMB ' + $PartSizeMB + ' is below the S3 minimum part size of 5 MiB.') 'ERROR' }
if ($PartSizeMB -gt 5120){ Exit-Yc 2 ('-PartSizeMB ' + $PartSizeMB + ' is above the S3 maximum part size of 5 GiB.') 'ERROR' }

Set-YcTls
try { [System.Net.ServicePointManager]::Expect100Continue = $false } catch { }
try { [System.Net.ServicePointManager]::DefaultConnectionLimit = 16 } catch { }

# ------------------------------------------------------------------------------------------------
# SigV4 primitives
# ------------------------------------------------------------------------------------------------
function ConvertTo-YcUriEncoded {
  param([string]$Value,[switch]$KeepSlash)
  $sb = New-Object System.Text.StringBuilder
  foreach ($b in [Text.Encoding]::UTF8.GetBytes($Value)) {
    if ( ($b -ge 65 -and $b -le 90) -or ($b -ge 97 -and $b -le 122) -or ($b -ge 48 -and $b -le 57) -or
         $b -eq 45 -or $b -eq 46 -or $b -eq 95 -or $b -eq 126 ) {
      [void]$sb.Append([char]$b)
    } elseif ($KeepSlash -and $b -eq 47) {
      [void]$sb.Append('/')
    } else {
      [void]$sb.AppendFormat('%{0:X2}', $b)
    }
  }
  return $sb.ToString()
}

function ConvertTo-YcHex {
  param([byte[]]$Bytes)
  return (($Bytes | ForEach-Object { $_.ToString('x2') }) -join '')
}

function Get-YcSha256Hex {
  param([byte[]]$Bytes)
  $sha = New-Object System.Security.Cryptography.SHA256Managed
  try { return (ConvertTo-YcHex -Bytes ($sha.ComputeHash($Bytes))) } finally { $sha.Dispose() }
}

function Get-YcHmacSha256 {
  param([byte[]]$KeyBytes,[string]$Data)
  $h = New-Object System.Security.Cryptography.HMACSHA256
  try { $h.Key = $KeyBytes; return $h.ComputeHash([Text.Encoding]::UTF8.GetBytes($Data)) } finally { $h.Dispose() }
}

# SHA-256 of a byte range of a file, streamed. Only called when the payload must be signed.
function Get-YcFileSha256Hex {
  param([string]$FilePath,[long]$Offset,[long]$Length)
  $sha = New-Object System.Security.Cryptography.SHA256Managed
  $fs  = [System.IO.File]::Open($FilePath,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::Read)
  try {
    [void]$fs.Seek($Offset,[System.IO.SeekOrigin]::Begin)
    $buf = New-Object byte[] $script:CopyBuffer
    $left = $Length
    while ($left -gt 0) {
      $want = [int][Math]::Min([long]$script:CopyBuffer, $left)
      $read = $fs.Read($buf, 0, $want)
      if ($read -le 0) { break }
      [void]$sha.TransformBlock($buf, 0, $read, $null, 0)
      $left = $left - $read
    }
    [void]$sha.TransformFinalBlock((New-Object byte[] 0), 0, 0)
    return (ConvertTo-YcHex -Bytes $sha.Hash)
  } finally {
    $fs.Close(); $sha.Dispose()
  }
}

function New-YcMd5 {
  if (-not $script:Md5Available) { return $null }
  try { return (New-Object System.Security.Cryptography.MD5CryptoServiceProvider) }
  catch {
    $script:Md5Available = $false
    Write-YcLog ('MD5 is not available on this host (' + $_.Exception.Message + ') - this is normal when the FIPS algorithm policy is enabled. ETag comparison will be skipped and transfers will be proved by size only.') 'WARN'
    return $null
  }
}

# ------------------------------------------------------------------------------------------------
# The signed request. Returns an object; never throws for an HTTP status.
#   -InFile/-InOffset/-InLength : stream that byte range as the body (and MD5 it while streaming)
#   -BodyBytes                  : small in-memory body (multipart completion XML)
#   -OutFile                    : stream the response body to this file
# ------------------------------------------------------------------------------------------------
function Invoke-YcS3 {
  param(
    [string]$Method,
    [string]$ObjectKey = '',
    [hashtable]$Query,
    [hashtable]$ExtraHeaders,
    [string]$InFile,
    [long]$InOffset = 0,
    [long]$InLength = -1,
    [byte[]]$BodyBytes,
    [string]$OutFile,
    [int]$TimeoutMs = 0
  )
  if ($TimeoutMs -le 0) { $TimeoutMs = $script:CtlTimeoutMs }
  $ep = [Uri]$S3['Endpoint']
  $epHost = $ep.Host
  $path = '/'
  if ($S3['UsePathStyle']) {
    $path = '/' + $S3['Bucket']
    if ($ObjectKey) { $path = $path + '/' + $ObjectKey }
  } else {
    $epHost = $S3['Bucket'] + '.' + $ep.Host
    if ($ObjectKey) { $path = '/' + $ObjectKey }
  }
  $hostHeader = $epHost
  if (-not $ep.IsDefaultPort) { $hostHeader = $epHost + ':' + $ep.Port }
  $canonUri = ConvertTo-YcUriEncoded -Value $path -KeepSlash

  $qparts = @()
  if ($Query) {
    foreach ($k in ($Query.Keys | Sort-Object -CaseSensitive)) {
      $qparts += ((ConvertTo-YcUriEncoded -Value ([string]$k)) + '=' + (ConvertTo-YcUriEncoded -Value ([string]$Query[$k])))
    }
  }
  $canonQuery = ($qparts -join '&')

  $bodyLen = 0
  if ($BodyBytes) { $bodyLen = $BodyBytes.Length }
  elseif ($InFile) {
    if ($InLength -lt 0) { $InLength = (Get-Item -LiteralPath $InFile).Length - $InOffset }
    $bodyLen = $InLength
  }

  # Payload hash. Empty body -> the empty SHA-256 (always correct and cheap).
  $payloadHash = ''
  if ($bodyLen -eq 0) {
    $payloadHash = Get-YcSha256Hex -Bytes (New-Object byte[] 0)
  } elseif ($BodyBytes) {
    $payloadHash = Get-YcSha256Hex -Bytes $BodyBytes
  } elseif ($script:SignPayload) {
    $payloadHash = Get-YcFileSha256Hex -FilePath $InFile -Offset $InOffset -Length $InLength
  } else {
    $payloadHash = 'UNSIGNED-PAYLOAD'
  }

  $amzDate   = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
  $dateStamp = $amzDate.Substring(0, 8)

  $hdrs = @{}
  $hdrs['host']                 = $hostHeader
  $hdrs['x-amz-content-sha256'] = $payloadHash
  $hdrs['x-amz-date']           = $amzDate
  if ($ExtraHeaders) { foreach ($k in $ExtraHeaders.Keys) { $hdrs[$k.ToLowerInvariant()] = [string]$ExtraHeaders[$k] } }

  $names = @($hdrs.Keys | Sort-Object -CaseSensitive)
  $canonHeaders = ''
  foreach ($n in $names) { $canonHeaders = $canonHeaders + $n + ':' + ([string]$hdrs[$n]).Trim() + "`n" }
  $signedHeaders = ($names -join ';')

  $canonRequest = $Method + "`n" + $canonUri + "`n" + $canonQuery + "`n" + $canonHeaders + "`n" + $signedHeaders + "`n" + $payloadHash
  $scope = $dateStamp + '/' + $S3['Region'] + '/s3/aws4_request'
  $stringToSign = 'AWS4-HMAC-SHA256' + "`n" + $amzDate + "`n" + $scope + "`n" + (Get-YcSha256Hex -Bytes ([Text.Encoding]::UTF8.GetBytes($canonRequest)))

  $kSecret  = [Text.Encoding]::UTF8.GetBytes('AWS4' + $S3['SecretKey'])
  $kDate    = Get-YcHmacSha256 -KeyBytes $kSecret  -Data $dateStamp
  $kRegion  = Get-YcHmacSha256 -KeyBytes $kDate    -Data $S3['Region']
  $kService = Get-YcHmacSha256 -KeyBytes $kRegion  -Data 's3'
  $kSigning = Get-YcHmacSha256 -KeyBytes $kService -Data 'aws4_request'
  $signature = ConvertTo-YcHex -Bytes (Get-YcHmacSha256 -KeyBytes $kSigning -Data $stringToSign)
  for ($i = 0; $i -lt $kSecret.Length; $i++) { $kSecret[$i] = 0 }

  $url = $ep.Scheme + '://' + $hostHeader + $canonUri
  if ($canonQuery) { $url = $url + '?' + $canonQuery }

  $res = [pscustomobject]@{
    StatusCode = 0; StatusText = ''; Headers = @{}; Body = ''; ETag = ''
    ContentLength = -1; Md5Hex = ''; Md5Bytes = $null; Error = ''; Retryable = $false
    SafeUrl = ($Method + ' ' + $ep.Scheme + '://' + $hostHeader + $canonUri + $(if ($canonQuery) { '?' + $canonQuery } else { '' }))
  }

  $req = $null
  try { $req = [System.Net.HttpWebRequest][System.Net.WebRequest]::Create($url) }
  catch { $res.Error = 'could not create the request: ' + $_.Exception.Message; return $res }

  $req.Method            = $Method
  $req.Timeout           = $TimeoutMs
  $req.ReadWriteTimeout  = $TimeoutMs
  $req.UserAgent         = 'YallaCloud-transfer-s3'
  $req.AllowAutoRedirect = $false
  $req.KeepAlive         = $true
  $req.SendChunked       = $false
  foreach ($n in $names) {
    if ($n -eq 'host') { continue }                      # set by the framework from the URL
    if ($n -eq 'content-length') { continue }
    $req.Headers.Add($n, [string]$hdrs[$n])
  }
  $req.Headers.Add('Authorization', ('AWS4-HMAC-SHA256 Credential=' + $S3['AccessKey'] + '/' + $scope + ',SignedHeaders=' + $signedHeaders + ',Signature=' + $signature))

  # ---- request body ----
  if ($bodyLen -gt 0) {
    $req.ContentLength = $bodyLen
    $req.AllowWriteStreamBuffering = $false
    $rs = $null
    try {
      $rs = $req.GetRequestStream()
    } catch {
      $res.Error = 'could not open the request stream: ' + $_.Exception.Message
      $res.Retryable = $true
      return $res
    }
    $md5 = New-YcMd5
    try {
      if ($BodyBytes) {
        if ($md5) { [void]$md5.TransformBlock($BodyBytes, 0, $BodyBytes.Length, $null, 0) }
        $rs.Write($BodyBytes, 0, $BodyBytes.Length)
      } else {
        $fs = [System.IO.File]::Open($InFile,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::Read)
        try {
          [void]$fs.Seek($InOffset,[System.IO.SeekOrigin]::Begin)
          $buf  = New-Object byte[] $script:CopyBuffer
          $left = $InLength
          while ($left -gt 0) {
            $want = [int][Math]::Min([long]$script:CopyBuffer, $left)
            $read = $fs.Read($buf, 0, $want)
            if ($read -le 0) { throw ('the local file ended after ' + ($InLength - $left) + ' of ' + $InLength + ' bytes - it was truncated or replaced while it was being uploaded') }
            if ($md5) { [void]$md5.TransformBlock($buf, 0, $read, $null, 0) }
            $rs.Write($buf, 0, $read)
            $left = $left - $read
          }
        } finally { $fs.Close() }
      }
      if ($md5) {
        [void]$md5.TransformFinalBlock((New-Object byte[] 0), 0, 0)
        $res.Md5Bytes = $md5.Hash
        $res.Md5Hex   = ConvertTo-YcHex -Bytes $md5.Hash
      }
    } catch {
      $res.Error = 'the request body could not be sent: ' + $_.Exception.Message
      $res.Retryable = $true
      try { $rs.Close() } catch { }
      if ($md5) { $md5.Dispose() }
      return $res
    }
    try { $rs.Close() } catch { }
    if ($md5) { $md5.Dispose() }
  }

  # ---- response ----
  $resp = $null
  try {
    $resp = $req.GetResponse()
  } catch [System.Net.WebException] {
    $we = $_.Exception
    if ($we.Response) {
      $resp = $we.Response
    } else {
      $res.Error = $we.Message
      $res.Retryable = $true
      return $res
    }
  } catch {
    $res.Error = $_.Exception.Message
    $res.Retryable = $true
    return $res
  }
  try {
    $hr = [System.Net.HttpWebResponse]$resp
    $res.StatusCode = [int]$hr.StatusCode
    $res.StatusText = [string]$hr.StatusDescription
    foreach ($hk in $hr.Headers.AllKeys) { $res.Headers[$hk.ToLowerInvariant()] = $hr.Headers[$hk] }
    if ($res.Headers.ContainsKey('etag')) { $res.ETag = ([string]$res.Headers['etag']).Trim('"') }
    try { $res.ContentLength = [long]$hr.ContentLength } catch { $res.ContentLength = -1 }
    if ($Method -ne 'HEAD') {
      if ($OutFile -and $res.StatusCode -ge 200 -and $res.StatusCode -lt 300) {
        $md5d = New-YcMd5
        $ins  = $hr.GetResponseStream()
        $outs = [System.IO.File]::Open($OutFile,[System.IO.FileMode]::Create,[System.IO.FileAccess]::Write,[System.IO.FileShare]::None)
        try {
          $buf = New-Object byte[] $script:CopyBuffer
          while ($true) {
            $read = $ins.Read($buf, 0, $buf.Length)
            if ($read -le 0) { break }
            if ($md5d) { [void]$md5d.TransformBlock($buf, 0, $read, $null, 0) }
            $outs.Write($buf, 0, $read)
          }
        } finally { $outs.Close(); $ins.Close() }
        if ($md5d) {
          [void]$md5d.TransformFinalBlock((New-Object byte[] 0), 0, 0)
          $res.Md5Bytes = $md5d.Hash
          $res.Md5Hex   = ConvertTo-YcHex -Bytes $md5d.Hash
          $md5d.Dispose()
        }
      } else {
        $sr = New-Object System.IO.StreamReader($hr.GetResponseStream())
        try { $res.Body = $sr.ReadToEnd() } finally { $sr.Close() }
      }
    }
  } finally {
    if ($resp) { $resp.Close() }
  }
  if ($res.StatusCode -eq 408 -or $res.StatusCode -eq 429 -or $res.StatusCode -ge 500) { $res.Retryable = $true }
  return $res
}

# Retry wrapper. Only network errors, 408, 429 and 5xx are retried - a 403 is a configuration
# problem and retrying it four times just delays the truth.
function Invoke-YcS3Retry {
  param([hashtable]$Call,[string]$What)
  $delay = 3
  for ($attempt = 1; $attempt -le $Retries; $attempt++) {
    $r = Invoke-YcS3 @Call
    if (-not $r.Error -and $r.StatusCode -ge 200 -and $r.StatusCode -lt 300) {
      if ($attempt -gt 1) { Write-YcLog ($What + ' succeeded on attempt ' + $attempt + '.') 'OK' }
      return $r
    }
    $desc = ''
    if ($r.Error) { $desc = 'network/transport error: ' + $r.Error }
    else {
      $desc = 'HTTP ' + $r.StatusCode + ' ' + $r.StatusText
      $code = ''
      if ($r.Body -and $r.Body -match '<Code>([^<]+)</Code>') { $code = $Matches[1] }
      $msg = ''
      if ($r.Body -and $r.Body -match '<Message>([^<]+)</Message>') { $msg = $Matches[1] }
      if ($code) { $desc = $desc + ' (' + $code + $(if ($msg) { ': ' + $msg } else { '' }) + ')' }
    }
    if (-not $r.Retryable -or $attempt -ge $Retries) {
      Write-YcLog ($What + ' FAILED after ' + $attempt + ' attempt(s): ' + $desc) 'ERROR'
      return $r
    }
    Write-YcLog ($What + ' attempt ' + $attempt + '/' + $Retries + ' failed (' + $desc + ') - retrying in ' + $delay + 's.') 'WARN'
    Start-Sleep -Seconds $delay
    $delay = $delay * 2
  }
  return $r
}

function Get-YcS3FailExit {
  param([pscustomobject]$R)
  if ($R.Error -and $R.StatusCode -eq 0) { return 8 }
  if ($R.StatusCode -eq 401 -or $R.StatusCode -eq 403) { return 7 }
  return 9
}

# ------------------------------------------------------------------------------------------------
# THE PROOF. Called after every upload and every download, in every engine.
# ------------------------------------------------------------------------------------------------
function Assert-YcS3Object {
  param([string]$ObjectKey,[long]$ExpectBytes,[string]$ExpectETag)
  $h = Invoke-YcS3Retry -Call @{ Method = 'HEAD'; ObjectKey = $ObjectKey } -What ('HEAD ' + $ObjectKey)
  if ($h.Error -or $h.StatusCode -ne 200) {
    Write-YcLog ('VERIFICATION FAILED: HEAD of ' + $ObjectKey + ' did not return 200 - the object is not there. Nothing local has been deleted.') 'ERROR'
    return $false
  }
  if ($h.ContentLength -ne $ExpectBytes) {
    Write-YcLog ('VERIFICATION FAILED: ' + $ObjectKey + ' is ' + $h.ContentLength + ' bytes on the endpoint but the local file is ' + $ExpectBytes + ' bytes.') 'ERROR'
    return $false
  }
  if ($ExpectETag) {
    if ($h.ETag -ne $ExpectETag) {
      $note = 'the object was stored but its ETag does not match what we computed from the bytes we sent.'
      if ($h.ETag -notmatch '^[0-9a-f]{32}(-[0-9]+)?$') {
        $note = 'the endpoint returned a non-MD5 ETag (' + $h.ETag + '), which happens with server-side encryption or a server that computes ETags differently. Size matched.'
        Write-YcLog ('ETag comparison INCONCLUSIVE for ' + $ObjectKey + ': ' + $note) 'WARN'
        Write-YcLog ('[YC-S3-PROOF] key=' + $ObjectKey + ' bytes=' + $h.ContentLength + ' etag=' + $h.ETag + ' http=200') 'OK'
        return $true
      }
      Write-YcLog ('VERIFICATION FAILED: ' + $note + ' expected ' + $ExpectETag + ', endpoint reports ' + $h.ETag + '.') 'ERROR'
      return $false
    }
    Write-YcLog ('Verified checksum: ' + $ObjectKey + ' ETag ' + $h.ETag + ' matches the MD5 of the bytes this command sent.') 'OK'
  } else {
    Write-YcLog ('Checksum not compared for ' + $ObjectKey + ' - no locally computed digest was available (MD5 disabled by FIPS policy, or the AWS Tools engine performed the multipart upload). The size proof above still holds.') 'WARN'
  }
  Write-YcLog ('PROVED: ' + $ObjectKey + ' exists on ' + $S3['Endpoint'] + '/' + $S3['Bucket'] + ' with ' + $h.ContentLength + ' bytes (HTTP 200).') 'OK'
  Write-YcLog ('[YC-S3-PROOF] key=' + $ObjectKey + ' bytes=' + $h.ContentLength + ' etag=' + $h.ETag + ' http=200') 'OK'
  return $true
}

# ------------------------------------------------------------------------------------------------
# The optional AWS.Tools.S3 engine
# ------------------------------------------------------------------------------------------------
function Import-YcAwsModule {
  if ($script:AwsModule -ne $null) { return $script:AwsModule }
  $script:AwsModule = ''
  foreach ($m in @('AWS.Tools.S3','AWSPowerShell.NetCore','AWSPowerShell')) {
    if (Get-Module -ListAvailable -Name $m) {
      try {
        Import-Module $m -ErrorAction Stop
        $script:AwsModule = $m
        $ver = (Get-Module -Name $m | Select-Object -First 1).Version
        Write-YcLog ('AWS Tools module ' + $m + ' ' + $ver + ' imported - large uploads will use Write-S3Object (TransferUtility multipart). Verification still uses the built-in signer.') 'OK'
        break
      } catch {
        Write-YcLog ('Module ' + $m + ' is present but would not import: ' + $_.Exception.Message) 'WARN'
      }
    }
  }
  if (-not $script:AwsModule) {
    Write-YcLog 'No AWS Tools for PowerShell module on this host - using the built-in SigV4 engine for everything. That is the supported air-gapped configuration, not a fallback failure.'
  }
  return $script:AwsModule
}
$script:AwsModule = $null

function Send-YcS3ViaModule {
  param([string]$FilePath,[string]$ObjectKey)
  $p = @{
    BucketName               = $S3['Bucket']
    Key                      = $ObjectKey
    File                     = $FilePath
    EndpointUrl              = $S3['Endpoint']
    ForcePathStyleAddressing = [bool]$S3['UsePathStyle']
    Region                   = $S3['Region']
    AccessKey                = $S3['AccessKey']
    SecretKey                = $S3['SecretKey']     # in-process only; never a command line
    ErrorAction              = 'Stop'
  }
  if ($StorageClass) { $p['StorageClass'] = $StorageClass }
  try {
    Write-S3Object @p | Out-Null
    return $true
  } catch {
    Write-YcLog ('Write-S3Object FAILED for ' + $ObjectKey + ': ' + (Protect-YcSecret $_.Exception.Message)) 'ERROR'
    return $false
  }
}

# ------------------------------------------------------------------------------------------------
# Upload: single PUT
# ------------------------------------------------------------------------------------------------
function Send-YcS3Single {
  param([string]$FilePath,[string]$ObjectKey,[long]$Size)
  $hdr = @{}
  if ($StorageClass) { $hdr['x-amz-storage-class'] = $StorageClass }
  $r = Invoke-YcS3Retry -Call @{
        Method = 'PUT'; ObjectKey = $ObjectKey; ExtraHeaders = $hdr
        InFile = $FilePath; InOffset = 0; InLength = $Size; TimeoutMs = $script:DataTimeoutMs
      } -What ('PUT ' + $ObjectKey + ' (' + $Size + ' bytes, single part)')
  if ($r.Error -or $r.StatusCode -lt 200 -or $r.StatusCode -ge 300) {
    return [pscustomobject]@{ Ok = $false; ETag = ''; Exit = (Get-YcS3FailExit -R $r) }
  }
  Write-YcLog ('PUT ' + $ObjectKey + ' returned HTTP ' + $r.StatusCode + ' with ETag ' + $r.ETag + '.')
  return [pscustomobject]@{ Ok = $true; ETag = $r.Md5Hex; Exit = 0 }
}

# ------------------------------------------------------------------------------------------------
# Upload: multipart. Returns the expected composite ETag so the HEAD proof can compare it.
# ------------------------------------------------------------------------------------------------
function Send-YcS3Multipart {
  param([string]$FilePath,[string]$ObjectKey,[long]$Size,[long]$PartSize)
  $hdr = @{}
  if ($StorageClass) { $hdr['x-amz-storage-class'] = $StorageClass }
  $create = Invoke-YcS3Retry -Call @{ Method = 'POST'; ObjectKey = $ObjectKey; Query = @{ 'uploads' = '' }; ExtraHeaders = $hdr } -What ('CreateMultipartUpload ' + $ObjectKey)
  if ($create.Error -or $create.StatusCode -ne 200) {
    return [pscustomobject]@{ Ok = $false; ETag = ''; Exit = (Get-YcS3FailExit -R $create) }
  }
  $uploadId = ''
  try {
    $x = [xml]$create.Body
    $uploadId = [string]$x.InitiateMultipartUploadResult.UploadId
  } catch { $uploadId = '' }
  if (-not $uploadId) {
    Write-YcLog ('CreateMultipartUpload returned HTTP 200 but no UploadId could be parsed from the response.') 'ERROR'
    return [pscustomobject]@{ Ok = $false; ETag = ''; Exit = 9 }
  }
  $partCount = [int][Math]::Ceiling([double]$Size / [double]$PartSize)
  Write-YcLog ('Multipart upload started for ' + $ObjectKey + ': ' + $partCount + ' part(s) of up to ' + [int]($PartSize / 1MB) + ' MB, upload id ' + $uploadId.Substring(0, [Math]::Min(12, $uploadId.Length)) + '...')

  $etags   = @()
  $md5cat  = New-Object System.Collections.Generic.List[byte]
  $md5ok   = $true
  $failed  = $false
  $failExit = 9
  for ($n = 1; $n -le $partCount; $n++) {
    $off = [long]($n - 1) * $PartSize
    $len = [long][Math]::Min($PartSize, $Size - $off)
    $pr = Invoke-YcS3Retry -Call @{
            Method = 'PUT'; ObjectKey = $ObjectKey
            Query = @{ 'partNumber' = [string]$n; 'uploadId' = $uploadId }
            InFile = $FilePath; InOffset = $off; InLength = $len; TimeoutMs = $script:DataTimeoutMs
          } -What ('UploadPart ' + $n + '/' + $partCount + ' of ' + $ObjectKey)
    if ($pr.Error -or $pr.StatusCode -lt 200 -or $pr.StatusCode -ge 300 -or -not $pr.ETag) {
      $failed = $true
      $failExit = Get-YcS3FailExit -R $pr
      break
    }
    $etags += [pscustomobject]@{ N = $n; ETag = $pr.ETag }
    if ($pr.Md5Bytes -and $script:Md5Available) {
      if ($pr.Md5Hex -ne $pr.ETag) {
        Write-YcLog ('Part ' + $n + ' of ' + $ObjectKey + ': the endpoint returned ETag ' + $pr.ETag + ' but the MD5 of the bytes sent is ' + $pr.Md5Hex + '. Aborting - this part did not arrive intact.') 'ERROR'
        $failed = $true
        $failExit = 10
        break
      }
      foreach ($b in $pr.Md5Bytes) { [void]$md5cat.Add($b) }
    } else { $md5ok = $false }
    Write-YcLog ('  part ' + $n + '/' + $partCount + ' ok (' + $len + ' bytes, ETag ' + $pr.ETag + ')')
  }

  if ($failed) {
    Write-YcLog ('Aborting the multipart upload of ' + $ObjectKey + ' so the parts already stored do not accrue cost...') 'WARN'
    $ab = Invoke-YcS3Retry -Call @{ Method = 'DELETE'; ObjectKey = $ObjectKey; Query = @{ 'uploadId' = $uploadId } } -What ('AbortMultipartUpload ' + $ObjectKey)
    if ($ab.StatusCode -ge 200 -and $ab.StatusCode -lt 300) { Write-YcLog 'Multipart upload aborted server-side.' 'OK' }
    else { Write-YcLog ('The abort call itself failed (HTTP ' + $ab.StatusCode + '). Check for an incomplete multipart upload on the bucket and set a lifecycle rule to clean it up.') 'WARN' }
    return [pscustomobject]@{ Ok = $false; ETag = ''; Exit = $failExit }
  }

  $sb = New-Object System.Text.StringBuilder
  [void]$sb.Append('<CompleteMultipartUpload>')
  foreach ($e in $etags) { [void]$sb.Append('<Part><PartNumber>' + $e.N + '</PartNumber><ETag>&quot;' + $e.ETag + '&quot;</ETag></Part>') }
  [void]$sb.Append('</CompleteMultipartUpload>')
  $body = [Text.Encoding]::UTF8.GetBytes($sb.ToString())

  $cmp = Invoke-YcS3Retry -Call @{
          Method = 'POST'; ObjectKey = $ObjectKey; Query = @{ 'uploadId' = $uploadId }
          BodyBytes = $body; TimeoutMs = $script:DataTimeoutMs
        } -What ('CompleteMultipartUpload ' + $ObjectKey)
  if ($cmp.Error -or $cmp.StatusCode -ne 200) {
    return [pscustomobject]@{ Ok = $false; ETag = ''; Exit = (Get-YcS3FailExit -R $cmp) }
  }
  # S3 returns 200 with an <Error> body when completion fails after the headers are sent. Do not
  # treat that as success - it is the classic "the call returned 0" trap.
  if ($cmp.Body -match '<Error>') {
    $code = ''
    if ($cmp.Body -match '<Code>([^<]+)</Code>') { $code = $Matches[1] }
    Write-YcLog ('CompleteMultipartUpload returned HTTP 200 but the body is an error document (' + $code + '). The object was NOT created.') 'ERROR'
    return [pscustomobject]@{ Ok = $false; ETag = ''; Exit = 9 }
  }

  $expect = ''
  if ($md5ok -and $script:Md5Available) {
    $md5 = New-YcMd5
    if ($md5) {
      $expect = (ConvertTo-YcHex -Bytes ($md5.ComputeHash($md5cat.ToArray()))) + '-' + $etags.Count
      $md5.Dispose()
    }
  }
  Write-YcLog ('CompleteMultipartUpload for ' + $ObjectKey + ' returned HTTP 200 (' + $etags.Count + ' parts).')
  return [pscustomobject]@{ Ok = $true; ETag = $expect; Exit = 0 }
}

# ------------------------------------------------------------------------------------------------
# One file, end to end, including the proof
# ------------------------------------------------------------------------------------------------
function Send-YcS3File {
  param([string]$FilePath,[string]$ObjectKey)
  $fi = Get-Item -LiteralPath $FilePath
  $size = [long]$fi.Length
  if ($size -eq 0) {
    Write-YcLog ('SKIPPED ' + $FilePath + ': the file is zero bytes. Uploading an empty object would hide the real problem.') 'ERROR'
    return [pscustomobject]@{ Ok = $false; Exit = 4 }
  }
  $partSize = [long]$PartSizeMB * 1MB
  if ($size -gt ($partSize * $script:MaxParts)) {
    $needed = [long][Math]::Ceiling([double]$size / [double]$script:MaxParts)
    $newMb  = [int][Math]::Ceiling([double]$needed / 1MB)
    Write-YcLog ('-PartSizeMB ' + $PartSizeMB + ' would need more than ' + $script:MaxParts + ' parts for a ' + $size + ' byte file. Raising the part size to ' + $newMb + ' MB.') 'WARN'
    $partSize = [long]$newMb * 1MB
  }
  $useMultipart = ($size -gt $partSize) -or ($size -gt $script:SinglePutMax)

  if ($WhatIf) {
    Write-YcLog ('-WhatIf: would upload ' + $FilePath + ' (' + $size + ' bytes) to ' + $S3['Bucket'] + '/' + $ObjectKey +
                 $(if ($useMultipart) { ' as a multipart upload of ' + [int][Math]::Ceiling([double]$size / [double]$partSize) + ' part(s)' } else { ' as a single PUT' }) +
                 $(if ($DeleteSourceOnSuccess) { ', then delete the local file once the remote HEAD proves it' } else { '' }) + '.') 'WARN'
    return [pscustomobject]@{ Ok = $true; Exit = 0 }
  }

  Write-YcLog ('Uploading ' + $FilePath + ' (' + $size + ' bytes) -> ' + $S3['Bucket'] + '/' + $ObjectKey)
  $sw = [Diagnostics.Stopwatch]::StartNew()
  $r  = $null
  $usedModule = $false
  if ($useMultipart -and ($Engine -eq 'module' -or $Engine -eq 'auto')) {
    if (Import-YcAwsModule) {
      $usedModule = $true
      Write-YcLog ('Engine: AWS Tools (' + $script:AwsModule + ') Write-S3Object with -EndpointUrl and -ForcePathStyleAddressing ' + $S3['UsePathStyle'] + '.')
      $ok = Send-YcS3ViaModule -FilePath $FilePath -ObjectKey $ObjectKey
      $r = [pscustomobject]@{ Ok = $ok; ETag = ''; Exit = $(if ($ok) { 0 } else { 9 }) }
    }
  }
  if ($Engine -eq 'module' -and -not $usedModule -and $useMultipart) {
    Write-YcLog '-Engine module was requested but no AWS Tools module could be imported - falling back to the built-in engine rather than failing the backup.' 'WARN'
  }
  if (-not $r) {
    if ($useMultipart) {
      Write-YcLog ('Engine: built-in SigV4, multipart (' + [int]($partSize / 1MB) + ' MB parts).')
      $r = Send-YcS3Multipart -FilePath $FilePath -ObjectKey $ObjectKey -Size $size -PartSize $partSize
    } else {
      Write-YcLog ('Engine: built-in SigV4, single PUT.')
      $r = Send-YcS3Single -FilePath $FilePath -ObjectKey $ObjectKey -Size $size
    }
  }
  $sw.Stop()
  if (-not $r.Ok) {
    Write-YcLog ('Upload of ' + $ObjectKey + ' FAILED after ' + [int]$sw.Elapsed.TotalSeconds + 's. The local file was NOT deleted.') 'ERROR'
    return [pscustomobject]@{ Ok = $false; Exit = $r.Exit }
  }
  $mb = [Math]::Round($size / 1MB, 2)
  $sec = [Math]::Max(1, [int]$sw.Elapsed.TotalSeconds)
  Write-YcLog ('Transfer of ' + $ObjectKey + ' finished in ' + [int]$sw.Elapsed.TotalSeconds + 's (' + $mb + ' MB, about ' + [Math]::Round($mb / $sec, 2) + ' MB/s). Now proving it.')

  if (-not (Assert-YcS3Object -ObjectKey $ObjectKey -ExpectBytes $size -ExpectETag $r.ETag)) {
    return [pscustomobject]@{ Ok = $false; Exit = 10 }
  }

  if ($DeleteSourceOnSuccess) {
    Remove-Item -LiteralPath $FilePath -Force
    if (Test-Path -LiteralPath $FilePath) {
      Write-YcLog ('The remote copy is proved but the local file ' + $FilePath + ' could not be deleted.') 'WARN'
    } else {
      Write-YcLog ('Deleted the local file ' + $FilePath + ' - AFTER the remote copy was proved, never before.') 'OK'
    }
  }
  return [pscustomobject]@{ Ok = $true; Exit = 0 }
}

# ------------------------------------------------------------------------------------------------
# Download
# ------------------------------------------------------------------------------------------------
function Receive-YcS3File {
  param([string]$ObjectKey,[string]$Target)
  $h = Invoke-YcS3Retry -Call @{ Method = 'HEAD'; ObjectKey = $ObjectKey } -What ('HEAD ' + $ObjectKey)
  if ($h.Error -or $h.StatusCode -ne 200) {
    if ($h.StatusCode -eq 404) {
      Write-YcLog ('Object ' + $ObjectKey + ' does not exist on ' + $S3['Bucket'] + ' (HTTP 404). Use transfer-s3 -List to see what is actually there.') 'ERROR'
      return [pscustomobject]@{ Ok = $false; Exit = 10 }
    }
    return [pscustomobject]@{ Ok = $false; Exit = (Get-YcS3FailExit -R $h) }
  }
  $remoteLen = [long]$h.ContentLength
  Write-YcLog ('Remote object ' + $ObjectKey + ': ' + $remoteLen + ' bytes, ETag ' + $h.ETag + '.')

  $dest = $Target
  if (Test-Path -LiteralPath $dest -PathType Container) {
    $leaf = $ObjectKey.Split('/')[-1]
    $dest = Join-Path $dest $leaf
  }
  $destDir = Split-Path -Parent $dest
  if ($destDir -and -not (Test-Path -LiteralPath $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }

  if ($WhatIf) {
    Write-YcLog ('-WhatIf: would download ' + $ObjectKey + ' (' + $remoteLen + ' bytes) to ' + $dest + '.') 'WARN'
    return [pscustomobject]@{ Ok = $true; Exit = 0 }
  }

  $part = $dest + '.part'
  if (Test-Path -LiteralPath $part) { Remove-Item -LiteralPath $part -Force }
  $g = Invoke-YcS3Retry -Call @{ Method = 'GET'; ObjectKey = $ObjectKey; OutFile = $part; TimeoutMs = $script:DataTimeoutMs } -What ('GET ' + $ObjectKey)
  if ($g.Error -or $g.StatusCode -ne 200) {
    if (Test-Path -LiteralPath $part) { Remove-Item -LiteralPath $part -Force }
    return [pscustomobject]@{ Ok = $false; Exit = (Get-YcS3FailExit -R $g) }
  }
  $localLen = (Get-Item -LiteralPath $part).Length
  if ($localLen -ne $remoteLen) {
    Write-YcLog ('VERIFICATION FAILED: downloaded ' + $localLen + ' bytes but the object is ' + $remoteLen + ' bytes. The partial file ' + $part + ' has been deleted.') 'ERROR'
    Remove-Item -LiteralPath $part -Force
    return [pscustomobject]@{ Ok = $false; Exit = 10 }
  }
  if ($g.Md5Hex -and $h.ETag -match '^[0-9a-f]{32}$') {
    if ($g.Md5Hex -ne $h.ETag) {
      Write-YcLog ('VERIFICATION FAILED: the downloaded bytes hash to ' + $g.Md5Hex + ' but the object ETag is ' + $h.ETag + '. The partial file has been deleted.') 'ERROR'
      Remove-Item -LiteralPath $part -Force
      return [pscustomobject]@{ Ok = $false; Exit = 10 }
    }
    Write-YcLog ('Verified checksum: the downloaded file hashes to ' + $g.Md5Hex + ', which matches the object ETag.') 'OK'
  } else {
    Write-YcLog ('Checksum not compared (the ETag ' + $h.ETag + ' is a multipart composite or MD5 is unavailable); size was proved.') 'WARN'
  }
  if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Force }
  Move-Item -LiteralPath $part -Destination $dest -Force
  if (-not (Test-Path -LiteralPath $dest)) {
    Write-YcLog ('The download verified but ' + $dest + ' does not exist after the rename.') 'ERROR'
    return [pscustomobject]@{ Ok = $false; Exit = 10 }
  }
  Write-YcLog ('PROVED: ' + $dest + ' exists with ' + (Get-Item -LiteralPath $dest).Length + ' bytes, matching the remote object.') 'OK'
  Write-YcLog ('[YC-S3-PROOF] key=' + $ObjectKey + ' bytes=' + $remoteLen + ' etag=' + $h.ETag + ' http=200') 'OK'
  return [pscustomobject]@{ Ok = $true; Exit = 0 }
}

# ------------------------------------------------------------------------------------------------
# -List
# ------------------------------------------------------------------------------------------------
if ($List) {
  $q = @{ 'list-type' = '2'; 'max-keys' = '1000' }
  if ($S3['Prefix']) { $q['prefix'] = $S3['Prefix'] }
  $total = 0
  $bytes = [long]0
  $token = ''
  Write-Host ''
  Write-Host ('  {0,-14} {1,16}  {2}' -f 'LAST MODIFIED','BYTES','KEY')
  Write-Host ('  ' + ('-' * 100))
  while ($true) {
    if ($token) { $q['continuation-token'] = $token } else { [void]$q.Remove('continuation-token') }
    $r = Invoke-YcS3Retry -Call @{ Method = 'GET'; Query = $q } -What 'ListObjectsV2'
    if ($r.Error -or $r.StatusCode -ne 200) {
      Exit-Yc (Get-YcS3FailExit -R $r) ('Listing ' + $S3['Bucket'] + ' failed.') 'ERROR'
    }
    $x = $null
    try { $x = [xml]$r.Body } catch { Exit-Yc 9 ('ListObjectsV2 returned HTTP 200 but the body is not parseable XML.') 'ERROR' }
    foreach ($o in @($x.ListBucketResult.Contents)) {
      if (-not $o) { continue }
      $total++
      $bytes = $bytes + [long]$o.Size
      Write-Host ('  {0,-14} {1,16}  {2}' -f ([string]$o.LastModified).Substring(0, [Math]::Min(10, ([string]$o.LastModified).Length)), ([string]$o.Size), ([string]$o.Key))
    }
    if ([string]$x.ListBucketResult.IsTruncated -eq 'true' -and $x.ListBucketResult.NextContinuationToken) {
      $token = [string]$x.ListBucketResult.NextContinuationToken
    } else { break }
  }
  Write-Host ''
  Exit-Yc 0 ($total.ToString() + ' object(s), ' + [Math]::Round($bytes / 1MB, 2) + ' MB under prefix "' + $(if ($S3['Prefix']) { $S3['Prefix'] } else { '(none)' }) + '" in ' + $S3['Bucket'] + '.') 'OK'
}

# ------------------------------------------------------------------------------------------------
# Argument validation for a transfer
# ------------------------------------------------------------------------------------------------
if (-not $Path) { Exit-Yc 2 '-Path is required (the local file or folder). Use -List to list objects, or -Help.' 'ERROR' }

if ($Direction -eq 'Download') {
  if (-not $Key) { Exit-Yc 2 '-Direction Download requires -Key (the remote object key to fetch).' 'ERROR' }
  $res = Receive-YcS3File -ObjectKey $Key -Target $Path
  if ($res.Ok) { Exit-Yc 0 ('Download of ' + $Key + ' completed and PROVED.') 'OK' }
  Exit-Yc $res.Exit ('Download of ' + $Key + ' FAILED.') 'ERROR'
}

# ---- Upload ----
if (-not (Test-Path -LiteralPath $Path)) {
  Exit-Yc 4 ('-Path does not exist: ' + $Path) 'ERROR'
}
$isDir = (Test-Path -LiteralPath $Path -PathType Container)
$files = @()
if ($isDir) {
  if ($Recurse) { $files = @(Get-ChildItem -LiteralPath $Path -File -Recurse) }
  else          { $files = @(Get-ChildItem -LiteralPath $Path -File) }
  if ($files.Count -eq 0) {
    Exit-Yc 4 ('No files found under ' + $Path + $(if ($Recurse) { ' (recursive)' } else { ' (add -Recurse to include subfolders)' }) + '.') 'ERROR'
  }
  if ($Key) {
    Write-YcLog '-Key is ignored when -Path is a folder: each file gets its own key built from the prefix and its relative path.' 'WARN'
  }
} else {
  $files = @(Get-Item -LiteralPath $Path)
}

$rootFull = (Resolve-Path -LiteralPath $Path).Path
$plan = @()
foreach ($f in $files) {
  $k = ''
  if ($isDir) {
    $rel = $f.FullName.Substring($rootFull.Length).TrimStart('\','/')
    $k = $rel -replace '\\','/'
    if ($S3['Prefix']) { $k = $S3['Prefix'] + '/' + $k }
  } elseif ($Key) {
    $k = $Key.TrimStart('/')
  } else {
    $k = $f.Name
    if ($S3['Prefix']) { $k = $S3['Prefix'] + '/' + $k }
  }
  $plan += [pscustomobject]@{ File = $f.FullName; Key = $k; Size = [long]$f.Length }
}
Write-YcLog ($plan.Count.ToString() + ' file(s) to upload, ' + [Math]::Round((($plan | Measure-Object -Property Size -Sum).Sum) / 1MB, 2) + ' MB total.')

$failCount = 0
$okCount   = 0
$lastExit  = 0
foreach ($p in $plan) {
  $r = Send-YcS3File -FilePath $p.File -ObjectKey $p.Key
  if ($r.Ok) { $okCount++ } else { $failCount++; $lastExit = $r.Exit }
}

$S3['SecretKey'] = $null
$secret = $null

if ($failCount -gt 0) {
  Exit-Yc $lastExit ($failCount.ToString() + ' of ' + $plan.Count + ' transfer(s) FAILED (' + $okCount + ' succeeded and were proved). Nothing local was deleted for the failures.') 'ERROR'
}
if ($WhatIf) {
  Exit-Yc 0 ('-WhatIf: ' + $plan.Count + ' file(s) would have been uploaded. Nothing was transferred.') 'WARN'
}
Exit-Yc 0 ($okCount.ToString() + ' of ' + $plan.Count + ' file(s) uploaded to ' + $S3['Bucket'] + ' and PROVED by a remote HEAD.') 'OK'
