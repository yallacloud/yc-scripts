# yc-firstboot.ps1 - the ONE first-boot task on a deployed clone (task name YCFIRSTBOOT,
# registered /sc onstart). It must do its work, PROVE it, and then delete itself.
#
# Stamp: 2026-08-19 - removed the documented exit code 4 'a required file is missing'. It is
#        unreachable here: nothing calls Assert-YcFile/Get-YcFile and the one Invoke-YcInstaller
#        call does not pass -Fatal, so the library never raises 4 from this script.
#
# ============================ WHAT CHANGED, AND WHY ============================
#
# [P0-18] YCFIRSTBOOT COULD NEVER RETIRE, SO FIRST-BOOT LOGIC RAN ON EVERY BOOT FOREVER
#   v253..v263 registered the YCNET / YCNET5 tasks only `if (Test-Path
#   C:\Scripts\yc-net.ps1)` - and yc-net.ps1 is NOT in the payload. The retirement gate
#   at the bottom then demanded `Get-ScheduledTask YCNET`, which therefore never existed,
#   so $okTask was permanently $false and the gate never fired. Consequences, every boot,
#   forever: an ADDITIONAL `netsh advfirewall firewall add rule name="YC-SSH-3222"` was
#   appended (netsh does not deduplicate - the rule list grows without bound), the virtio
#   reinstall was re-attempted, and the licensing step re-ran. Worse, Yallacloud.ps1:117
#   lists YCNET and YCNET5 as DEPRECATED tasks that must NOT exist, so the script was
#   recreating the very tasks the catalog calls a defect.
#   FIXED HERE:
#     1. YCNET and YCNET5 are gone from the task registration entirely, and from the
#        retirement gate. This script now actively DELETES them if a previous build left
#        them behind, which is what the catalog requires.
#     2. The duplicate `netsh ... add rule YC-SSH-3222` is DELETED. yc-boot.ps1 owns that
#        rule and creates it exactly once, only if absent (yc-boot.ps1:17-28). This script
#        now only CLEANS UP the duplicates the old code accumulated.
#     3. The retirement gate depends only on conditions this script can actually satisfy:
#        network profile Private, rearm resolved, built-in Administrator not exposed, and
#        the deprecated tasks absent. Windows ACTIVATION was removed from the gate on
#        purpose: it depends on yc-activate.ps1 / YCActivate and on a reachable KMS, i.e.
#        on things outside this script, and gating on it is exactly the class of
#        never-satisfiable condition that caused this defect. Licence status is LOGGED.
#     4. Retirement is PROVEN: after `schtasks /delete` the task is re-read with
#        Get-ScheduledTask, and if it is still there we escalate to Unregister-ScheduledTask
#        and re-read again. If it survives both, that is an ERROR, not a silent success.
#     5. A SID-KEYED RUN COUNTER (C:\Scripts\.firstboot-runs) caps the number of boots this
#        script may re-arm itself for at $MaxAttempts. After that it logs ERROR, drops a
#        visible alarm file, and RETIRES ITSELF ANYWAY so a permanently failing step can no
#        longer loop at every boot for the life of the VM. The counter is keyed to this
#        machine's account-domain SID (same convention as SSH-FirstBoot.ps1 and
#        yc-keyguard.ps1) so a counter baked into the golden image is recognised as another
#        machine's and reset to zero on the clone - doseal.cmd does not need to delete it.
#
# [P0-19] NO CLONE EVER REARMED ITS EVALUATION LICENCE
#   v263 wrote C:\Scripts\.rearm-done BEFORE checking that the rearm worked, and the task
#   is /sc onstart, so it ran on the BUILD VM and created the marker PRE-SEAL. Every clone
#   then booted, saw the marker, and skipped the rearm it was built to perform.
#   FIXED HERE: the marker is written ONLY after a CONFIRMED DECREMENT of
#   SoftwareLicensingService.RemainingWindowsReArmCount. SUPERSEDED 2026-08-30: this script
#   no longer rearms at all - see section 8. Sysprep does it; a second rearm here destroyed
#   the licensing store on 6 of 6 clones. The note below is kept for history only.
#   (historic) RemainingWindowsReArmCount (read before, run slmgr /rearm,
#   read after), and the marker CONTENT is this machine's SID, so a marker that somehow
#   survives sealing belongs to the build VM and is discarded. doseal.cmd also deletes
#   .rearm-done - belt and braces. If the count does not decrement the marker is NOT
#   written and the next boot retries, bounded by $MaxAttempts.
#   See also Unattend-Seal.xml: the FINAL seal must not set SkipRearm=1, or slmgr /rearm
#   is a documented no-op and the grace period and CMID are never reset.
#     https://learn.microsoft.com/en-us/windows-hardware/customize/desktop/unattend/microsoft-windows-security-spp-skiprearm
#     https://learn.microsoft.com/en-us/previous-versions/windows/desktop/sppwmi/softwarelicensingservice
#
# [P0-20] EVERY CLONE BOOTED WITH THE BUILT-IN ADMINISTRATOR ENABLED AND A BLANK PASSWORD
#   Unattend-Seal.xml shipped an EMPTY plaintext AdministratorPassword and ran
#   `net user Administrator /active:yes` as a FirstLogonCommand, while yc-boot.ps1:17-28
#   opens 3389/5985/5986 with -Profile Any on the same boot. LimitBlankPasswordUse blocks
#   the NETWORK logon, but the CloudStack console and VNC - which the portal exposes to the
#   tenant and to anyone with portal access - are CONSOLE logons and were wide open, and
#   nothing verified that cloudbase-init ever set a password.
#   FIXED HERE: step 7 proves whether the built-in Administrator (RID -500) is ENABLED and
#   accepts an EMPTY password, using an actual interactive LogonUser() attempt - not a
#   guess from Win32_UserAccount.PasswordRequired. If it is, that is logged at ERROR (which
#   the library mirrors to the Application event log as EventId 1003), a loud alarm file is
#   written to C:\Scripts, and the account is DISABLED unless -AlarmOnly was passed. The
#   answer file no longer enables it or sets a blank password in the first place; this check
#   exists so that a re-introduction of that pattern, or a cloudbase-init password failure,
#   cannot ship silently.
#
# HOUSE RULES OBSERVED
#   Windows PowerShell 5.1 only (Server 2016 must work), ASCII only, no ternaries, no ?.
#   No wmic. TLS 1.2 is set by the library before anything reaches the network. Every step
#   is independently guarded so one failure cannot abort the rest (that is what broke v253).
#   Idempotent and re-entrant - this runs at every boot until it retires itself.
#   Every exit path goes through Exit-Yc. Runs as SYSTEM, non-interactive: no prompts.
# ==============================================================================

param([switch]$Help,[switch]$AlarmOnly)

. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'yc-firstboot'

if($Help){
@"
yc-firstboot  -  first-boot task for a deployed clone. Runs the once-per-clone work,
                 verifies it, then deletes its own YCFIRSTBOOT scheduled task.

USAGE:
  yc-firstboot
  yc-firstboot -AlarmOnly
  yc-firstboot -Help

PARAMETERS:
  -AlarmOnly  If the built-in Administrator is found ENABLED with a BLANK password, log
              ERROR and write the alarm file but do NOT disable the account. Default is
              to disable it: a console/VNC-reachable blank-password Administrator is
              remotely exploitable by anyone with CloudStack portal access (P0-20).
  -Help       Show this help and exit.

EXAMPLES:
  yc-firstboot
      Normal unattended run. Registered as the YCFIRSTBOOT task, /sc onstart, SYSTEM.

  yc-firstboot -AlarmOnly
      Same, but never disables the built-in Administrator. Use only where an operator
      has confirmed there is another working administrative path into the VM.

  yc-firstboot -Help

EXIT CODES:
  0   All checks green - YCFIRSTBOOT proven removed, or a legitimate deferral
      (a system shutdown was already in progress; the task fires again next boot).
  2   Not all checks green yet - YCFIRSTBOOT deliberately KEPT, will run again at the
      next boot. Also returned after scheduling the post-rearm reboot.
  3   Attempt budget exhausted ($MaxAttempts boots). ERROR logged, alarm file written,
      and YCFIRSTBOOT retired anyway so it cannot loop at every boot forever.
  5   Not running as Administrator/SYSTEM (from the library).
  11  All checks were green but YCFIRSTBOOT could NOT be removed - it would loop.

Log: C:\Scripts\yc-firstboot.log
"@ | Write-Host -ForegroundColor Cyan
    Exit-Yc 0 'help shown' 'OK'
}

$ErrorActionPreference = 'Continue'
Assert-YcPrereqs -NeedAdmin

# ----------------------------------------------------------------------------------
# Constants and markers
# ----------------------------------------------------------------------------------
$Scripts       = 'C:\Scripts'
$TaskName      = 'YCFIRSTBOOT'
$DeprecatedTsk = @('YCNET','YCNET5')          # Yallacloud.ps1:117 - these must NOT exist
$RunsMarker    = Join-Path $Scripts '.firstboot-runs'
$RearmMarker   = Join-Path $Scripts '.rearm-done'
$GoldenMarker  = Join-Path $Scripts '.goldenimage'
$AlarmFile     = Join-Path $Scripts 'SECURITY-ALARM-yc-firstboot.txt'
$Slmgr         = Join-Path $env:WINDIR 'System32\slmgr.vbs'
$MaxAttempts   = 10
$SshRuleName   = 'YC-SSH-3222'

# ----------------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------------

# Machine identity that sysprep /generalize is guaranteed to change: the local account
# domain SID. Identical convention to SSH-FirstBoot.ps1 and yc-keyguard.ps1, so a marker
# baked into the golden image can never be mistaken for one written on this clone.
function Get-YcMachineId{
    try{
        $u = Get-CimInstance Win32_UserAccount -Filter "LocalAccount=true" -ErrorAction Stop | Select-Object -First 1
        if($u -and $u.SID){
            $s = New-Object System.Security.Principal.SecurityIdentifier($u.SID)
            if($s.AccountDomainSid){ return $s.AccountDomainSid.Value }
            return [string]$u.SID
        }
    }catch{}
    try{
        $g = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name 'MachineGuid' -ErrorAction Stop).MachineGuid
        if($g){ return ('GUID-' + $g) }
    }catch{}
    return ('HOST-' + $env:COMPUTERNAME)
}

# Reads a SID-keyed marker. Returns $true only when the marker exists AND was written on
# THIS machine. A marker from the build VM returns $false and is deleted.
function Test-YcOwnMarker{
    param([string]$Path,[string]$MachineId)
    if(-not (Test-Path -LiteralPath $Path)){ return $false }
    $v = ''
    try{ $v = (('' + (Get-Content -LiteralPath $Path -TotalCount 1 -ErrorAction SilentlyContinue))).Trim() }catch{}
    if($v -eq $MachineId -and $v -ne ''){ return $true }
    Write-YcLog ('marker ' + (Split-Path -Leaf $Path) + ' was written on a DIFFERENT machine (golden-image leftover) - discarding it') 'WARN'
    Remove-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
    return $false
}

function Set-YcOwnMarker{
    param([string]$Path,[string]$MachineId)
    try{ Set-Content -LiteralPath $Path -Value $MachineId -Encoding ascii -Force }catch{
        Write-YcLog ('could not write marker ' + $Path + ': ' + $_.Exception.Message) 'WARN'
    }
}

# The built-in Administrator is the account whose SID ends in -500, whatever it was renamed
# to. Returns the Win32_UserAccount instance, or $null.
function Get-YcBuiltinAdmin{
    $acct = $null
    try{
        $acct = Get-CimInstance Win32_UserAccount -Filter "LocalAccount=true" -ErrorAction Stop |
                Where-Object { $_.SID -like '*-500' } | Select-Object -First 1
    }catch{ $acct = $null }
    return $acct
}

# Definitive blank-password test: attempt an INTERACTIVE LogonUser() with an empty password.
# Win32_UserAccount.PasswordRequired only says a blank password is PERMITTED, not that the
# password IS blank, which is why the old code could not have caught this. LOGON32_LOGON_
# INTERACTIVE is used deliberately: LimitBlankPasswordUse restricts NETWORK logons only, so
# this reproduces exactly the console/VNC path CloudStack exposes to the tenant.
# Returns $true (blank), $false (not blank), or $null (could not determine).
function Test-YcBlankPassword{
    param([string]$UserName)
    $type = $null
    try{
        $src = @'
using System;
using System.Runtime.InteropServices;
public static class YcLogon {
    [DllImport("advapi32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
    public static extern bool LogonUser(string u, string d, string p, int t, int prov, out IntPtr tok);
    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool CloseHandle(IntPtr h);
    public static bool BlankWorks(string user) {
        IntPtr tok = IntPtr.Zero;
        bool ok = LogonUser(user, ".", "", 2, 0, out tok);   // 2 = LOGON32_LOGON_INTERACTIVE
        if (ok && tok != IntPtr.Zero) { CloseHandle(tok); }
        return ok;
    }
}
'@
        if(-not ('YcLogon' -as [type])){ Add-Type -TypeDefinition $src -ErrorAction Stop }
        $type = 'YcLogon' -as [type]
    }catch{
        Write-YcLog ('could not build the LogonUser probe (' + $_.Exception.Message + ') - falling back to Win32_UserAccount.PasswordRequired, which is weaker') 'WARN'
        return $null
    }
    if(-not $type){ return $null }
    $r = $null
    try{ $r = [YcLogon]::BlankWorks($UserName) }catch{
        Write-YcLog ('LogonUser probe threw: ' + $_.Exception.Message) 'WARN'
        return $null
    }
    return [bool]$r
}

# SoftwareLicensingService exposes the remaining rearm count as RemainingWindowsReArmCount
# (Root\CIMV2, uint32, read-only). Older builds spell it RemainingWindowsRearmCount; read a
# FRESH instance every time, because the value is cached on the object.
function Get-YcRearmCount{
    $v = $null
    try{
        $sls = Get-CimInstance -ClassName SoftwareLicensingService -ErrorAction Stop | Select-Object -First 1
        if($sls){
            # [int64], NOT [int]. The property is a uint32 and a DESTROYED licensing store
            # reports 0xFFFFFFFF (4294967295), which does not fit in an Int32: the cast threw,
            # the catch below swallowed it, and the function returned $null - "could not read
            # the rearm count" - for the one state we most need to recognise.
            if($null -ne $sls.RemainingWindowsReArmCount){ $v = [int64]$sls.RemainingWindowsReArmCount }
            elseif($null -ne $sls.RemainingWindowsRearmCount){ $v = [int64]$sls.RemainingWindowsRearmCount }
            # 0xFFFFFFFF is not a count, it is the signature of a store wrecked by a rearm on a
            # converted image. Surface it as itself rather than as a number nobody can act on.
            if($v -eq 4294967295){
                Write-YcLog 'RemainingWindowsReArmCount reads 0xFFFFFFFF - the licensing store is in the DESTROYED state, not a real count. No rearm can help this image; it has to be rebuilt from clean media.' 'ERROR'
            }
        }
    }catch{ $v = $null }
    return $v
}

function Write-YcAlarm{
    param([string]$Text)
    try{
        $stamp = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        Add-Content -LiteralPath $AlarmFile -Value ('[' + $stamp + '] ' + $Text) -Encoding ascii -ErrorAction SilentlyContinue
    }catch{}
}

# ----------------------------------------------------------------------------------
# 0. Defer if a shutdown is already in progress
#    SetupComplete / early OOBE reboots make every CIM call fail with "A system shutdown
#    is in progress". Bail out WITHOUT consuming an attempt and let the task fire again.
# ----------------------------------------------------------------------------------
try{
    $null = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
}catch{
    Exit-Yc 0 'a system shutdown is in progress - deferring to the next boot (no attempt consumed)' 'WARN'
}

$MachineId = Get-YcMachineId
Write-YcLog ('machine id (account domain SID): ' + $MachineId)

# This script must never run on the build VM: doseal.cmd requires C:\Scripts\.goldenimage
# and deletes it as it seals, so its presence means we are pre-seal. Doing the once-per-clone
# work here is precisely how the .rearm-done marker got baked into the image (P0-19).
if(Test-Path -LiteralPath $GoldenMarker){
    Exit-Yc 0 ('C:\Scripts\.goldenimage is present, so this is the golden-image BUILD VM, not a clone. Refusing to run the once-per-clone work here - that is how the pre-seal .rearm-done marker was created. doseal.cmd removes this marker when it seals.') 'WARN'
}

# ----------------------------------------------------------------------------------
# Attempt budget (P0-18). SID-keyed, so a counter baked into the image resets on a clone.
# ----------------------------------------------------------------------------------
$attempt = 0
if(Test-Path -LiteralPath $RunsMarker){
    $raw = ''
    try{ $raw = (('' + (Get-Content -LiteralPath $RunsMarker -TotalCount 1 -ErrorAction SilentlyContinue))).Trim() }catch{}
    $parts = @($raw -split '\|')
    if($parts.Count -ge 2 -and $parts[0] -eq $MachineId){
        $n = 0
        if([int]::TryParse($parts[1],[ref]$n)){ $attempt = $n }
    }elseif($raw -ne ''){
        Write-YcLog 'run counter belongs to another machine (golden-image leftover) - restarting the attempt budget at 0' 'WARN'
    }
}
$attempt = $attempt + 1
try{ Set-Content -LiteralPath $RunsMarker -Value ($MachineId + '|' + $attempt) -Encoding ascii -Force }catch{}
Write-YcLog ('first-boot attempt ' + $attempt + ' of ' + $MaxAttempts + ' on this clone')

# ----------------------------------------------------------------------------------
# 1. virtio: install the staged 0.1.271 build
#    No /delete-driver: ERROR 69 proved it is a no-op on an in-use package, and the enum
#    loop HUNG SetupComplete - the log stopped at the start line and nothing after step 1
#    ever ran. Add-only is safe and fast.
# ----------------------------------------------------------------------------------
try{
    $want = '100.100.104.27100'   # 0.1.271
    $cur  = (Get-NetAdapter -ErrorAction SilentlyContinue | Select-Object -First 1).DriverVersion
    Write-YcLog ('virtio current = ' + $cur)
    if($cur -ne $want -and (Test-Path -LiteralPath 'C:\Scripts\virtio')){
        foreach($d in Get-ChildItem 'C:\Scripts\virtio' -Directory -ErrorAction SilentlyContinue){
            foreach($inf in Get-ChildItem $d.FullName -Filter *.inf -ErrorAction SilentlyContinue){
                & pnputil /add-driver $inf.FullName /install 2>&1 | Out-Null
            }
        }
        $now = (Get-NetAdapter -ErrorAction SilentlyContinue | Select-Object -First 1).DriverVersion
        Write-YcLog ('virtio after install = ' + $now)
    }else{
        Write-YcLog 'virtio already at the target version, or the payload is missing - skipped'
    }
}catch{ Write-YcLog ('virtio step error: ' + $_.Exception.Message) 'ERROR' }

# ----------------------------------------------------------------------------------
# 2. QEMU guest agent - install if absent, then PROVE the service is Running
# ----------------------------------------------------------------------------------
try{
    $qga = Get-Service -Name 'QEMU-GA' -ErrorAction SilentlyContinue
    if(-not $qga){ $qga = Get-Service -DisplayName 'QEMU Guest Agent' -ErrorAction SilentlyContinue }
    if(-not $qga -and (Test-Path -LiteralPath 'C:\Scripts\qemu-ga.msi')){
        $r = Invoke-YcInstaller -FilePath 'msiexec.exe' -ArgumentList @('/i','C:\Scripts\qemu-ga.msi','/qn','/norestart') -SuccessCodes @(0) -TimeoutSec 900
        if(-not $r.Success){ Write-YcLog ('qemu-ga install did not succeed: ' + $r.Meaning) 'ERROR' }
    }
    $qga = Get-Service -Name 'QEMU-GA' -ErrorAction SilentlyContinue
    if($qga){
        Set-Service -Name $qga.Name -StartupType Automatic -ErrorAction SilentlyContinue
        [void](Assert-YcService -Name $qga.Name -TimeoutSec 60 -StartIfStopped -Because 'guest agent must answer the hypervisor')
    }else{
        Write-YcLog 'QEMU guest agent service is not present (no MSI staged?) - continuing' 'WARN'
    }
}catch{ Write-YcLog ('qga step error: ' + $_.Exception.Message) 'ERROR' }

# ----------------------------------------------------------------------------------
# 3. Network profile Private
#    The NIC is often unclassified this early, so retry rather than fire once.
#    P0-18: the `netsh advfirewall firewall add rule name="YC-SSH-3222"` that used to live
#    here is GONE. netsh does not deduplicate, so on a task that never retired it appended
#    an identical rule at EVERY boot. yc-boot.ps1:17-28 owns that rule and creates it once,
#    only if absent. All we do here is clean up the duplicates the old code left behind.
# ----------------------------------------------------------------------------------
try{
    for($i = 0; $i -lt 12; $i++){
        $p = Get-NetConnectionProfile -ErrorAction SilentlyContinue
        if($p -and ($p | Where-Object { $_.NetworkCategory -ne 'Private' })){
            $p | Set-NetConnectionProfile -NetworkCategory Private -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 5
        }elseif($p){ break }else{ Start-Sleep -Seconds 5 }
    }
    $prof = @(Get-NetConnectionProfile -ErrorAction SilentlyContinue)
    Write-YcLog ('network profiles: ' + (($prof | ForEach-Object { $_.Name + '=' + $_.NetworkCategory }) -join ', '))
}catch{ Write-YcLog ('network profile step error: ' + $_.Exception.Message) 'ERROR' }

try{
    $dupes = @(Get-NetFirewallRule -DisplayName $SshRuleName -ErrorAction SilentlyContinue)
    if($dupes.Count -gt 1){
        # Keep exactly one; delete the rest. These are the copies the old netsh line appended
        # once per boot for the life of the VM.
        for($k = 1; $k -lt $dupes.Count; $k++){
            Remove-NetFirewallRule -Name $dupes[$k].Name -ErrorAction SilentlyContinue
        }
        Write-YcLog ('removed ' + ($dupes.Count - 1) + ' DUPLICATE ' + $SshRuleName + ' firewall rule(s) left by the pre-fix netsh line (P0-18); 1 kept') 'OK'
    }else{
        Write-YcLog ($SshRuleName + ' firewall rule count = ' + $dupes.Count + ' (yc-boot.ps1 owns this rule)')
    }
}catch{ Write-YcLog ('firewall dedupe error: ' + $_.Exception.Message) 'WARN' }

# ----------------------------------------------------------------------------------
# 4. sshd authorized-keys ACL
# ----------------------------------------------------------------------------------
try{
    $ak = 'C:\ProgramData\ssh\administrators_authorized_keys'
    if(Test-Path -LiteralPath $ak){
        & icacls $ak /inheritance:r /grant 'NT AUTHORITY\SYSTEM:(F)' /grant 'BUILTIN\Administrators:(F)' 2>&1 | Out-Null
        Write-YcLog 'administrators_authorized_keys ACL set to SYSTEM + Administrators only' 'OK'
    }else{
        Write-YcLog 'administrators_authorized_keys not present yet - yc-keyguard owns it' 'INFO'
    }
}catch{ Write-YcLog ('acl step error: ' + $_.Exception.Message) 'ERROR' }

# ----------------------------------------------------------------------------------
# 5. Scheduled tasks (P0-18)
#    YCNET / YCNET5 are DEPRECATED per Yallacloud.ps1:117 and are no longer created here -
#    the payload has no yc-net.ps1 to run, so the registration was always dead code and the
#    gate that depended on it could never be satisfied. Instead we REMOVE them if an older
#    build left them registered.
# ----------------------------------------------------------------------------------
$deprecatedLeft = @()
try{
    foreach($n in $DeprecatedTsk){
        if(Get-ScheduledTask -TaskName $n -ErrorAction SilentlyContinue){
            Unregister-ScheduledTask -TaskName $n -Confirm:$false -ErrorAction SilentlyContinue
            if(Get-ScheduledTask -TaskName $n -ErrorAction SilentlyContinue){
                & schtasks /delete /tn $n /f 2>&1 | Out-Null
            }
            if(Get-ScheduledTask -TaskName $n -ErrorAction SilentlyContinue){
                $deprecatedLeft += $n
                Write-YcLog ('DEPRECATED task ' + $n + ' could not be removed') 'ERROR'
            }else{
                Write-YcLog ('removed DEPRECATED task ' + $n + ' (Yallacloud.ps1:117 - these must not exist)') 'OK'
            }
        }
    }
    if($deprecatedLeft.Count -eq 0){ Write-YcLog 'no deprecated YCNET/YCNET5 tasks present' 'OK' }
}catch{
    Write-YcLog ('deprecated task cleanup error: ' + $_.Exception.Message) 'ERROR'
    $deprecatedLeft = @($DeprecatedTsk)
}

# ----------------------------------------------------------------------------------
# 6. Shutdown Event Tracker off (re-assert)
# ----------------------------------------------------------------------------------
try{
    $rk = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Reliability'
    if(-not (Test-Path -LiteralPath $rk)){ New-Item -Path $rk -Force | Out-Null }
    New-ItemProperty -Path $rk -Name 'ShutdownReasonOn' -PropertyType DWord -Value 0 -Force | Out-Null
    New-ItemProperty -Path $rk -Name 'ShutdownReasonUI' -PropertyType DWord -Value 0 -Force | Out-Null
    Write-YcLog 'shutdown event tracker disabled' 'OK'
}catch{ Write-YcLog ('tracker step error: ' + $_.Exception.Message) 'ERROR' }

# ----------------------------------------------------------------------------------
# 7. P0-20: the built-in Administrator must NOT be enabled with a blank password
# ----------------------------------------------------------------------------------
$okAdmin = $true
try{
    $adm = Get-YcBuiltinAdmin
    if(-not $adm){
        Write-YcLog 'could not resolve the built-in Administrator (no local account with SID *-500) - cannot verify P0-20 this boot' 'WARN'
        $okAdmin = $false
    }elseif($adm.Disabled){
        Write-YcLog ('built-in Administrator (' + $adm.Name + ') is DISABLED - correct for a clone; cloudbase-init / the CloudStack password channel own the tenant account') 'OK'
    }else{
        $blank = Test-YcBlankPassword -UserName $adm.Name
        if($null -eq $blank){
            # Weaker fallback. PasswordRequired=False means a blank password is PERMITTED.
            if($adm.PasswordRequired -eq $false){
                $blank = $true
                Write-YcLog 'LogonUser probe unavailable; Win32_UserAccount.PasswordRequired is False, so a blank password is permitted on this account - treating as EXPOSED' 'WARN'
            }else{
                $blank = $false
                Write-YcLog 'LogonUser probe unavailable; PasswordRequired is True, so a blank password is not permitted - treating as not exposed, but this boot did NOT prove it' 'WARN'
                $okAdmin = $false
            }
        }
        if($blank){
            $okAdmin = $false
            $msg = ('SECURITY: the built-in Administrator (' + $adm.Name + ') is ENABLED and accepts an EMPTY password. ' +
                    'LimitBlankPasswordUse blocks the network logon, but the CloudStack console and VNC are CONSOLE logons and are wide open to the tenant and to anyone with portal access, ' +
                    'while yc-boot.ps1 has already opened 3389/5985/5986 with -Profile Any. cloudbase-init did not set a password on this account. This is defect P0-20.')
            Write-YcLog $msg 'ERROR'
            Write-YcAlarm $msg
            if($AlarmOnly){
                Write-YcLog '-AlarmOnly was passed, so the account is being LEFT ENABLED. Set a password on it NOW.' 'ERROR'
                Write-YcAlarm 'ACTION REQUIRED: set a password on the built-in Administrator, or disable it: net user <name> /active:no'
            }else{
                & net user $adm.Name /active:no 2>&1 | Out-Null
                Start-Sleep -Seconds 2
                $re = Get-YcBuiltinAdmin
                if($re -and $re.Disabled){
                    Write-YcLog ('built-in Administrator (' + $adm.Name + ') has been DISABLED to close the blank-password console exposure. Re-enable it only after setting a strong password: net user ' + $adm.Name + ' * ; net user ' + $adm.Name + ' /active:yes') 'WARN'
                    Write-YcAlarm ('Account ' + $adm.Name + ' was DISABLED by yc-firstboot because it had a blank password. Use the CloudStack password-reset channel / cloudbase-init account for access.')
                    $okAdmin = $true
                }else{
                    Write-YcLog ('FAILED to disable the blank-password built-in Administrator (' + $adm.Name + ') - the VM is still exposed') 'ERROR'
                    Write-YcAlarm 'FAILED to disable the blank-password Administrator. Do it manually.'
                }
            }
        }else{
            Write-YcLog ('built-in Administrator (' + $adm.Name + ') is enabled but does NOT accept an empty password') 'OK'
        }
    }
}catch{
    Write-YcLog ('administrator password check error: ' + $_.Exception.Message) 'ERROR'
    $okAdmin = $false
}

# ----------------------------------------------------------------------------------
# 8. P0-19: 180-day evaluation rearm, marked done ONLY on a CONFIRMED decrement
# ----------------------------------------------------------------------------------
$okRearm  = $false
$doReboot = $false
try{
    $lic = ''
    try{ $lic = (& cscript //nologo $Slmgr /dlv 2>&1) -join "`n" }catch{}
    if($lic -match 'License Status:\s*(\S+)'){ Write-YcLog ('licence status: ' + $Matches[1]) }

    # ------------------------------------------------------------------------------
    # THIS STEP NO LONGER REARMS. IT MUST NOT.
    #
    # MEASURED 2026-08-30 on SIX clones of the STAGE05-Sealedv3 templates - 2x2016,
    # 2x2019, 2x2022, every one a genuine ServerStandardEval. Identical on all six:
    #
    #     licence status: Initial
    #     RemainingWindowsReArmCount before rearm = 5
    #     ...three seconds later...
    #     RemainingWindowsReArmCount = 0xFFFFFFFF, every slmgr call 0xC004D302
    #
    # The store was HEALTHY at the start of this step and DESTROYED by the end of it.
    # The `slmgr /rearm` that used to sit here is what destroyed it.
    #
    # Why the rearm was never needed: sysprep /generalize with SkipRearm=0 - which is
    # what Unattend-Seal.xml sets - ALREADY performs the rearm. That is why the count
    # reads 5 here and not 6. The grace period and the CMID were reset by sysprep
    # seconds earlier. Rearming again, while the SPP is still reporting "Initial" and
    # has not finished initialising on a freshly generalized clone, corrupts the
    # trusted store beyond recovery. No tokens.dat rebuild brings it back.
    #
    # The earlier diagnosis - "rearming a Volume:GVLK converted image destroys the
    # store" - was too narrow. It happens on plain Evaluation images too. The trigger
    # is the SECOND rearm on a just-generalized clone, not the edition.
    #
    # So: nothing to do. Record it and move on. Left as a marked step rather than
    # deleted so the retirement gate keeps its shape and the log says why.
    # ------------------------------------------------------------------------------
    Set-YcOwnMarker -Path $RearmMarker -MachineId $MachineId
    $okRearm = $true
    Write-YcLog ('rearm SKIPPED BY DESIGN - sysprep /generalize with SkipRearm=0 already rearmed this image (that is why the count reads ' +
                 [string](Get-YcRearmCount) + ' and not the factory 6). A second rearm here destroyed the licensing store on 6 of 6 clones on 2026-08-30. Never reinstate it.') 'OK'
}catch{
    Write-YcLog ('rearm step error: ' + $_.Exception.Message) 'ERROR'
}

# Post-rearm the state is "Initial grace period" until /ato converts it to Licensed. That
# is yc-activate.ps1 / the YCActivate task's job, and it is registered ONLY if the script it
# points at actually exists - registering a task for a missing payload file is precisely
# what created P0-18.
if($doReboot){
    try{
        if(Test-Path -LiteralPath 'C:\Scripts\yc-activate.ps1'){
            & schtasks /create /tn YCActivate /tr 'powershell -NoProfile -ExecutionPolicy Bypass -File C:\Scripts\yc-activate.ps1' /sc onstart /ru SYSTEM /rl HIGHEST /f 2>&1 | Out-Null
            if(Get-ScheduledTask -TaskName 'YCActivate' -ErrorAction SilentlyContinue){
                Write-YcLog 'YCActivate task registered (activation runs after the reboot)' 'OK'
            }else{
                Write-YcLog 'YCActivate task registration did not take effect' 'ERROR'
            }
        }else{
            Write-YcLog 'C:\Scripts\yc-activate.ps1 is NOT in the payload - not registering YCActivate. Activation must be driven another way; a task pointing at a missing file is what caused P0-18.' 'WARN'
        }
    }catch{ Write-YcLog ('YCActivate registration error: ' + $_.Exception.Message) 'ERROR' }

    & shutdown /r /t 30 /c 'YC: applying 180-day evaluation reset' 2>&1 | Out-Null
    Exit-Yc 2 'rearm confirmed - rebooting in 30s to apply it. YCFIRSTBOOT is kept and will verify and retire itself on the next boot.' 'WARN'
}

# ----------------------------------------------------------------------------------
# 9. Retirement gate (P0-18)
#    Only conditions this script can actually satisfy. Windows ACTIVATION is deliberately
#    NOT one of them - see the header.
# ----------------------------------------------------------------------------------
$prof2 = @(Get-NetConnectionProfile -ErrorAction SilentlyContinue)
$okNet = ($prof2.Count -gt 0) -and (@($prof2 | Where-Object { $_.NetworkCategory -ne 'Private' }).Count -eq 0)
$okDep = ($deprecatedLeft.Count -eq 0)

Write-YcLog ('retirement gate: net=' + $okNet + ' rearm=' + $okRearm + ' admin=' + $okAdmin + ' deprecatedTasksGone=' + $okDep)

$budgetBlown = ($attempt -ge $MaxAttempts)
$allGreen    = ($okNet -and $okRearm -and $okAdmin -and $okDep)

if(-not $allGreen -and -not $budgetBlown){
    Exit-Yc 2 ('not all checks green yet (net=' + $okNet + ' rearm=' + $okRearm + ' admin=' + $okAdmin + ' deprecatedTasksGone=' + $okDep + ') - YCFIRSTBOOT kept, attempt ' + $attempt + ' of ' + $MaxAttempts + ', will run again at the next boot') 'WARN'
}

if(-not $allGreen){
    $msg = ('ATTEMPT BUDGET EXHAUSTED: ' + $attempt + ' boots and the first-boot checks are still not green (net=' + $okNet +
            ' rearm=' + $okRearm + ' admin=' + $okAdmin + ' deprecatedTasksGone=' + $okDep + '). ' +
            'YCFIRSTBOOT is being retired anyway so it cannot keep re-running at every boot for the life of this VM (defect P0-18). ' +
            'Investigate C:\Scripts\yc-firstboot.log and re-run yc-firstboot manually once the cause is fixed.')
    Write-YcLog $msg 'ERROR'
    Write-YcAlarm $msg
}

# Retire, and PROVE it. schtasks first (matches how the task was created), then escalate.
$removed = $false
try{
    & schtasks /delete /tn $TaskName /f 2>&1 | Out-Null
    Start-Sleep -Seconds 2
    if(Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue){
        Write-YcLog ('schtasks /delete did not remove ' + $TaskName + ' - escalating to Unregister-ScheduledTask') 'WARN'
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
    }
    $removed = ($null -eq (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue))
}catch{
    Write-YcLog ('retire step error: ' + $_.Exception.Message) 'ERROR'
    $removed = ($null -eq (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue))
}

if(-not $removed){
    $m = ($TaskName + ' still exists after both schtasks /delete and Unregister-ScheduledTask. It WILL run again at the next boot - this is the P0-18 loop. Remove it by hand.')
    Write-YcAlarm $m
    Exit-Yc 11 $m 'ERROR'
}

if($budgetBlown -and -not $allGreen){
    Exit-Yc 3 ($TaskName + ' removed (verified absent) to stop the every-boot loop, but the first-boot checks never went green - see the ERROR above and ' + $AlarmFile) 'ERROR'
}

# ----------------------------------------------------------------------------------
# CLOSE THE TWO THINGS THAT USED TO HAPPEN ONE BOOT LATE
#
# yc-boot.ps1 disables CloudinitAdmin and the cloudbase-init service, but it gates both
# on "yc-firstboot has ENDED" - and on a real clone yc-boot runs BEFORE yc-firstboot
# finishes. MEASURED on the first v4 clone: yc-boot started 13:41:43, yc-firstboot ended
# 13:42:08. The gate was correctly false, so neither happened, and both were left for the
# next reboot. On a VM the customer never reboots, CloudinitAdmin stays enabled forever;
# and when they DO reboot, cloudbase-init - still Automatic - runs once more and re-issues
# the Administrator password before yc-boot gets to disable it.
#
# We are at the end of a fully green first boot here, so "has firstboot ended" is not in
# question. Do both now. yc-boot keeps its copy as the safety net for images where this
# script already ran.
# ----------------------------------------------------------------------------------
try{
    $c = Get-CimInstance Win32_UserAccount -Filter "LocalAccount=true and Name='CloudinitAdmin'" -ErrorAction SilentlyContinue
    if($c -and -not $c.Disabled){
        & net user CloudinitAdmin /active:no 2>&1 | Out-Null
        $c = Get-CimInstance Win32_UserAccount -Filter "LocalAccount=true and Name='CloudinitAdmin'" -ErrorAction SilentlyContinue
        if($c -and $c.Disabled){ Write-YcLog 'CloudinitAdmin disabled - first boot is complete and cloud-init no longer needs it' 'OK' }
        else { Write-YcLog 'CloudinitAdmin could NOT be disabled - it stays enabled on this clone' 'ERROR' }
    }
}catch{ Write-YcLog ('CloudinitAdmin disable failed: ' + $_.Exception.Message) 'ERROR' }

try{
    $svc = Get-CimInstance Win32_Service -Filter "Name='cloudbase-init'" -ErrorAction SilentlyContinue
    if($svc){
        if($svc.State -ne 'Stopped'){
            Write-YcLog ('cloudbase-init is ' + $svc.State + ' - still working, leaving it for yc-boot to disable next boot') 'WARN'
        } elseif($svc.StartMode -match '^(Disabled)$'){
            Write-YcLog 'cloudbase-init already disabled' 'OK'
        } else {
            [void]($svc | Invoke-CimMethod -MethodName ChangeStartMode -Arguments @{ StartMode = 'Disabled' } -ErrorAction SilentlyContinue)
            $now = (Get-CimInstance Win32_Service -Filter "Name='cloudbase-init'" -ErrorAction SilentlyContinue).StartMode
            if($now -eq 'Disabled'){ Write-YcLog 'cloudbase-init DISABLED - it must not re-run and re-issue the Administrator password on later boots' 'OK' }
            else { Write-YcLog ('FAILED to disable cloudbase-init - StartMode is still ' + $now + '. It WILL re-run at the next reboot.') 'ERROR' }
        }
    }
}catch{ Write-YcLog ('cloudbase-init disable failed: ' + $_.Exception.Message) 'ERROR' }

Exit-Yc 0 ('all first-boot checks green and ' + $TaskName + ' removed (verified absent by re-reading the task) after ' + $attempt + ' attempt(s)') 'OK'
