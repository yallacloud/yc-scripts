param(
  [ValidateSet('Office2016Standard','Office2019Standard','Office2021Standard',
               'Excel2016Standard','Excel2019Standard','Excel2021Standard')]
  [string]$Product,
  [string]$MediaPath,
  [string]$OdtSetup,
  [string]$WorkDir = 'C:\Scripts\office-media',
  [ValidateSet('64','32')]
  [string]$Architecture = '64',
  [string]$Language = 'en-us',
  [string]$ProductKey,
  [switch]$DownloadOnly,
  [switch]$Uninstall,
  [switch]$SelfCheck,
  [switch]$Force,
  [switch]$Help
)
# =====================================================================================
# Install-Office.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
#
# WHY THIS EXISTS
# ---------------
# The auditor's list of what this IaaS estate actually runs puts Office Standard and
# standalone Excel just behind SQL Server. Both were being installed by hand, which means
# nobody could say afterwards WHICH edition landed or whether it was licensed.
#
# WHAT IT REFUSES TO PRETEND
# --------------------------
# Office splits cleanly in two and this script does not paper over the seam:
#
#   2019 / 2021 volume  are Click-to-Run. The Office Deployment Tool downloads them
#                       straight from Microsoft's CDN and installs them unattended, so
#                       this script can do the whole job with no media of its own.
#   2016 volume         is Windows Installer (MSI). There is NO Click-to-Run volume build
#                       of Office Standard 2016 or Excel 2016, no Product ID for one, and
#                       no public download. The media is an ISO from VLSC / CSP / SPLA.
#                       With no -MediaPath this script REFUSES (exit 2) and says exactly
#                       what to fetch. It does not silently install something else.
#
# LICENSING is optional here on purpose. Office activation is ospp.vbs, it is independent
# of the install, and this estate's Office keys are not in the payload. Pass -ProductKey to
# do it in the same run; the key is masked in every log line, exactly as activate-sql does.
#
# VERIFICATION. The installer's exit code is a hint. The proof is the registry and the
# binary: ProductReleaseIds / VersionToReport for Click-to-Run, the 16.0 product keys for
# MSI, plus the real EXCEL.EXE or WINWORD.EXE on disk with a version. A run that cannot
# read those back exits non-zero however happy setup looked.
#
# Log: C:\Scripts\install-office.log
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'install-office'
$ErrorActionPreference = 'Stop'

# Evergreen Microsoft-hosted Click-to-Run / ODT setup.exe. This is the same binary that
# ships inside the Office Deployment Tool download, served from Microsoft's own CDN at a
# URL that does not carry a build number, so it does not rot the way the
# officedeploymenttool_<build>.exe links on the Download Center do.
$OdtUrl = 'https://officecdn.microsoft.com/pr/wsus/setup.exe'

# Product ID and update channel per SKU. The 2016 rows carry no Product ID because none
# exists - that is the whole point of the MSI branch below.
$script:YcOfficeMap = @{
  'Office2019Standard' = @{ Kind='C2R'; ProductId='Standard2019Volume'; Channel='PerpetualVL2019'; App='WINWORD.EXE'; Label='Office Standard 2019' }
  'Office2021Standard' = @{ Kind='C2R'; ProductId='Standard2021Volume'; Channel='PerpetualVL2021'; App='WINWORD.EXE'; Label='Office LTSC Standard 2021' }
  'Excel2019Standard'  = @{ Kind='C2R'; ProductId='Excel2019Volume';    Channel='PerpetualVL2019'; App='EXCEL.EXE';   Label='Excel 2019' }
  'Excel2021Standard'  = @{ Kind='C2R'; ProductId='Excel2021Volume';    Channel='PerpetualVL2021'; App='EXCEL.EXE';   Label='Excel LTSC 2021' }
  'Office2016Standard' = @{ Kind='MSI'; ProductId='';                   Channel='';                App='WINWORD.EXE'; Label='Office Standard 2016' }
  'Excel2016Standard'  = @{ Kind='MSI'; ProductId='';                   Channel='';                App='EXCEL.EXE';   Label='Excel 2016' }
}

$HelpText = @"
install-office - install Microsoft Office Standard or standalone Excel unattended, and
                 PROVE which edition landed before reporting success.

USAGE:
  install-office -Product <sku> [-Architecture 64|32] [-Language en-us]
                 [-MediaPath <dir>] [-OdtSetup <setup.exe>] [-WorkDir <dir>]
                 [-ProductKey <KEY>] [-DownloadOnly] [-Force]
  install-office -Product <sku> -Uninstall
  install-office -SelfCheck
  install-office -Help

PARAMETERS (required: -Product, unless -SelfCheck or -Help):
  -Product       One of:
                   Office2019Standard   Office Standard 2019        (Click-to-Run, no media needed)
                   Office2021Standard   Office LTSC Standard 2021   (Click-to-Run, no media needed)
                   Excel2019Standard    Excel 2019 volume           (Click-to-Run, no media needed)
                   Excel2021Standard    Excel LTSC 2021 volume      (Click-to-Run, no media needed)
                   Office2016Standard   Office Standard 2016        (MSI - needs -MediaPath)
                   Excel2016Standard    Excel 2016                  (MSI - needs -MediaPath)
  -Architecture  64 (default) or 32. Must match any Office already on the box.
  -Language      Culture to install, default en-us. Click-to-Run SKUs only.
  -MediaPath     Directory holding setup.exe from the volume-licensed 2016 ISO. REQUIRED
                 for the two 2016 SKUs and ignored by the others.
  -OdtSetup      Use this Office Deployment Tool / Click-to-Run setup.exe instead of
                 downloading one. Point this at a staged copy on an air-gapped host.
  -WorkDir       Where media and the generated configuration.xml go.
                 Default C:\Scripts\office-media.
  -ProductKey    OPTIONAL. 5x5 MAK. Applied with ospp.vbs /inpkey then /act after the
                 install is verified, and masked in every log line. Omit it to install
                 unlicensed and activate later.
  -DownloadOnly  Fetch the media into -WorkDir and stop. Nothing is installed.
  -Uninstall     Remove the product instead of installing it (Click-to-Run only).
  -Force         Reinstall even when the product is already present.
  -SelfCheck     Run the built-in assertions and exit. Changes nothing.
  -Help          Show this help and exit 0.

EXAMPLES:
  install-office -Product Office2019Standard
  install-office -Product Excel2019Standard -Architecture 64
  install-office -Product Office2021Standard -ProductKey XXXXX-XXXXX-XXXXX-XXXXX-XXXXX
  install-office -Product Office2016Standard -MediaPath D:\
  install-office -Product Office2019Standard -DownloadOnly
  install-office -Product Office2019Standard -Uninstall

WHY 2016 NEEDS MEDIA AND 2019/2021 DO NOT:
  Office Standard 2016 and Excel 2016 volume are Windows Installer products. There is no
  Click-to-Run volume build of either, so the Office Deployment Tool has no Product ID for
  them and cannot download them. Get the ISO from VLSC / CSP / your SPLA portal, mount it,
  and pass the folder containing setup.exe as -MediaPath. Office 2019 and 2021 volume ARE
  Click-to-Run (channels PerpetualVL2019 / PerpetualVL2021) and come from Microsoft's CDN,
  so no media is needed for those.

EXIT CODES:
  0  Verified: the requested product is installed and readable from the registry and disk.
  1  Install or verification failed.
  2  Usage error, or a 2016 SKU with no -MediaPath.
  3  Media download failed.
  4  A required file was missing (from _yc-lib Assert-YcFile).
  5  Not elevated (from _yc-lib Assert-YcPrereqs).
  6  No outbound internet for a Click-to-Run install (from _yc-lib Assert-YcPrereqs).
  7  Installed and verified, but activation with -ProductKey did not report ---LICENSED---.

Log: C:\Scripts\install-office.log
"@

if($Help){ Write-Host $HelpText -ForegroundColor Cyan; Stop-YcLog 0; exit 0 }

# ------------------------------------------------------------------ helpers

function Get-YcOfficeC2RConfig{
  # Click-to-Run install state, or $null when no C2R Office is present.
  $k = 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration'
  $ids = Get-YcRegValueOrNull -Path $k -Name 'ProductReleaseIds'
  if(-not $ids){ return $null }
  return [pscustomobject]@{
    ProductReleaseIds = [string]$ids
    Version           = [string](Get-YcRegValueOrNull -Path $k -Name 'VersionToReport')
    Platform          = [string](Get-YcRegValueOrNull -Path $k -Name 'Platform')
    Culture           = [string](Get-YcRegValueOrNull -Path $k -Name 'ClientCulture')
    InstallPath       = [string](Get-YcRegValueOrNull -Path $k -Name 'InstallationPath')
  }
}

function Get-YcOfficeMsiProduct{
  # MSI-era Office. LastProduct is what the 2016 installer stamps.
  $v = Get-YcRegValueOrNull -Path 'HKLM:\SOFTWARE\Microsoft\Office\16.0\Common\ProductVersion' -Name 'LastProduct'
  if($v){ return [string]$v }
  return $null
}

function Find-YcOfficeApp{
  # The binary is the only thing that cannot be faked by a stale registry key.
  param([string]$Exe)
  $roots = @(
    (Join-Path $env:ProgramFiles       'Microsoft Office\root\Office16'),
    (Join-Path $env:ProgramFiles       'Microsoft Office\Office16'),
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft Office\root\Office16'),
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft Office\Office16')
  )
  foreach($r in $roots){
    if(-not $r){ continue }
    $p = Join-Path $r $Exe
    if(Test-Path -LiteralPath $p){ return $p }
  }
  return $null
}

function Get-YcOfficeAppVersion{
  param([string]$Path)
  if(-not $Path){ return '' }
  try{ return [string](Get-Item -LiteralPath $Path).VersionInfo.ProductVersion }catch{ return '' }
}

function New-YcOdtConfig{
  # The ODT configuration.xml. Written, logged and kept, so a failed install can be
  # reproduced by hand from the exact file setup.exe was given.
  param(
    [string]$Path,[string]$ProductId,[string]$Channel,
    [string]$Arch,[string]$Culture,[switch]$Remove
  )
  if($Remove){
    $xml = @"
<Configuration>
  <Remove All="TRUE" />
  <Display Level="None" AcceptEULA="TRUE" />
</Configuration>
"@
  }else{
    $xml = @"
<Configuration>
  <Add OfficeClientEdition="$Arch" Channel="$Channel">
    <Product ID="$ProductId">
      <Language ID="$Culture" />
    </Product>
  </Add>
  <Display Level="None" AcceptEULA="TRUE" />
  <Property Name="AUTOACTIVATE" Value="0" />
  <Property Name="FORCEAPPSHUTDOWN" Value="TRUE" />
  <RemoveMSI />
</Configuration>
"@
  }
  $dir = Split-Path -Parent $Path
  if($dir -and -not (Test-Path -LiteralPath $dir)){ New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  Set-Content -LiteralPath $Path -Value $xml -Encoding ASCII
  return $xml
}

function New-YcMsiConfig{
  # Office 2016 MSI answer file. Display Level none + AcceptEula is the documented
  # unattended form; PIDKEY is deliberately NOT written here - ospp.vbs does licensing
  # afterwards so the key never lands in a file on disk.
  param([string]$Path)
  $xml = @"
<Configuration>
  <Display Level="none" CompletionNotice="no" SuppressModal="yes" AcceptEula="yes" />
  <Setting Id="SETUP_REBOOT" Value="Never" />
</Configuration>
"@
  $dir = Split-Path -Parent $Path
  if($dir -and -not (Test-Path -LiteralPath $dir)){ New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  Set-Content -LiteralPath $Path -Value $xml -Encoding ASCII
  return $xml
}

function Find-YcOspp{
  foreach($r in @(
    (Join-Path $env:ProgramFiles       'Microsoft Office\Office16'),
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft Office\Office16'),
    (Join-Path $env:ProgramFiles       'Microsoft Office\root\Office16'),
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft Office\root\Office16'))){
    if(-not $r){ continue }
    $p = Join-Path $r 'ospp.vbs'
    if(Test-Path -LiteralPath $p){ return $p }
  }
  return $null
}

function Test-YcOsppLicensed{
  param([string]$Text)
  # ospp.vbs /dstatus prints "LICENSE STATUS:  ---LICENSED---" for an activated product.
  if(-not $Text){ return $false }
  return ($Text -match '(?im)^\s*LICENSE\s+STATUS:\s*-+LICENSED-+')
}

function Get-YcOfficeKeyTail{
  param([string]$Key)
  if(-not $Key){ return '' }
  $k = ($Key -replace '[^A-Za-z0-9]','')
  if($k.Length -lt 5){ return '' }
  return $k.Substring($k.Length-5).ToUpperInvariant()
}

# ------------------------------------------------------------------ self-check

if($SelfCheck){
  $n = 0; $bad = 0
  function TT{ param([string]$Name,$Got,$Want)
    $script:n++
    if("$Got" -eq "$Want"){ Write-YcLog ('selfcheck OK   ' + $Name) 'OK' }
    else{ Write-YcLog ('selfcheck FAIL ' + $Name + ' got="' + $Got + '" want="' + $Want + '"') 'ERROR'; $script:bad++ }
  }

  TT 'every SKU is mapped'            $script:YcOfficeMap.Keys.Count 6
  TT '2019 Standard product id'       $script:YcOfficeMap['Office2019Standard'].ProductId 'Standard2019Volume'
  TT '2019 Standard channel'          $script:YcOfficeMap['Office2019Standard'].Channel   'PerpetualVL2019'
  TT '2021 Standard product id'       $script:YcOfficeMap['Office2021Standard'].ProductId 'Standard2021Volume'
  TT '2021 Standard channel'          $script:YcOfficeMap['Office2021Standard'].Channel   'PerpetualVL2021'
  TT 'Excel 2019 product id'          $script:YcOfficeMap['Excel2019Standard'].ProductId  'Excel2019Volume'
  # The 2016 SKUs MUST be MSI with no product id. If either ever grows one, the refusal
  # below silently stops firing and the script would try to install something that
  # does not exist.
  TT '2016 Office is MSI'             $script:YcOfficeMap['Office2016Standard'].Kind 'MSI'
  TT '2016 Office has no product id'  $script:YcOfficeMap['Office2016Standard'].ProductId ''
  TT '2016 Excel is MSI'              $script:YcOfficeMap['Excel2016Standard'].Kind 'MSI'

  $tmp = Join-Path $env:TEMP ('yc-off-' + [guid]::NewGuid().ToString('N'))
  $cfg = Join-Path $tmp 'configuration.xml'
  $x = New-YcOdtConfig -Path $cfg -ProductId 'Standard2019Volume' -Channel 'PerpetualVL2019' -Arch '64' -Culture 'en-us'
  TT 'config carries the product id'  ($x -match 'ID="Standard2019Volume"') 'True'
  TT 'config carries the channel'     ($x -match 'Channel="PerpetualVL2019"') 'True'
  TT 'config is silent'               ($x -match 'Level="None"') 'True'
  TT 'config accepts the EULA'        ($x -match 'AcceptEULA="TRUE"') 'True'
  # AUTOACTIVATE must be 0: a volume install that phones out to activate on its own turns
  # an install failure and a licensing failure into one unreadable error.
  TT 'config does not auto-activate'  ($x -match 'Name="AUTOACTIVATE" Value="0"') 'True'
  TT 'config file was written'        (Test-Path -LiteralPath $cfg) 'True'
  $xr = New-YcOdtConfig -Path $cfg -Remove
  TT 'remove config removes all'      ($xr -match 'Remove All="TRUE"') 'True'
  $xm = New-YcMsiConfig -Path (Join-Path $tmp 'msi.xml')
  TT 'msi config is silent'           ($xm -match 'Level="none"') 'True'
  TT 'msi config accepts the EULA'    ($xm -match 'AcceptEula="yes"') 'True'
  # The key must never reach a file or a log line in full.
  TT 'no PIDKEY in the msi config'    ($xm -match 'PIDKEY') 'False'
  Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue

  TT 'key tail is the last five'      (Get-YcOfficeKeyTail 'AAAAA-BBBBB-CCCCC-DDDDD-6X3JM') '6X3JM'
  TT 'key tail of nothing is empty'   (Get-YcOfficeKeyTail '') ''
  TT 'ospp licensed is recognised'    (Test-YcOsppLicensed "SKU ID: x`r`nLICENSE STATUS:  ---LICENSED---`r`n") 'True'
  TT 'ospp notification is not licensed' (Test-YcOsppLicensed "LICENSE STATUS:  ---NOTIFICATIONS---`r`n") 'False'
  TT 'ospp silence is not licensed'   (Test-YcOsppLicensed '') 'False'

  if($bad -gt 0){ Exit-Yc 1 ($bad.ToString() + ' of ' + $n + ' self-check assertions FAILED.') 'ERROR' }
  Exit-Yc 0 ('self-check PASSED: ' + $n + ' assertions.') 'OK'
}

# ------------------------------------------------------------------ preflight

if(-not $Product){
  Write-Host $HelpText -ForegroundColor Cyan
  Exit-Yc 2 '-Product is required. Run install-office -Help for the list.' 'ERROR'
}

$sku = $script:YcOfficeMap[$Product]
$needNet = ($sku.Kind -eq 'C2R') -and -not $OdtSetup
# Probe the DEFAULT reachability URL, not officecdn.microsoft.com. The CDN answers 400 to a
# bare GET of its root, which the preflight then logs as a terminating Invoke-WebRequest
# error in the transcript of an otherwise perfect run - noise that reads like a failure.
# We want "is there egress", not "does this host like an empty path".
if($needNet){ Assert-YcPrereqs -NeedAdmin -NeedInternet -BoundParameters $PSBoundParameters }
else        { Assert-YcPrereqs -NeedAdmin -BoundParameters $PSBoundParameters }

$keyTail = Get-YcOfficeKeyTail $ProductKey
if($ProductKey){
  if($ProductKey -notmatch '^[A-Za-z0-9]{5}(-[A-Za-z0-9]{5}){4}$'){
    Exit-Yc 2 'PRODUCT KEY REJECTED: expected the documented 5x5 form XXXXX-XXXXX-XXXXX-XXXXX-XXXXX. Nothing was installed.' 'ERROR'
  }
  Write-YcLog ('Product key format OK, will license with a key ending ' + $keyTail + ' after the install is verified.')
  Write-YcLog ('SECRET ON THE COMMAND LINE: the key is visible in the process table and in 4688 events. ' +
               'Only the last 5 characters are ever written to this log.') 'WARN'
}

Write-YcLog ('Parameters: Product=' + $Product + ' (' + $sku.Label + ') Kind=' + $sku.Kind +
             ' Architecture=' + $Architecture + ' Language=' + $Language +
             ' WorkDir=' + $WorkDir + ' Licensing=' + $(if($ProductKey){ 'key ...' + $keyTail }else{ 'none - install only' }))

$before  = Get-YcOfficeC2RConfig
$beforeM = Get-YcOfficeMsiProduct
if($before){  Write-YcLog ('BEFORE (Click-to-Run): ' + $before.ProductReleaseIds + ' v' + $before.Version + ' ' + $before.Platform + '-bit ' + $before.Culture) }
elseif($beforeM){ Write-YcLog ('BEFORE (MSI): ' + $beforeM) }
else{ Write-YcLog 'BEFORE: no Microsoft Office of any kind is installed on this host.' }

if(-not $Force -and -not $Uninstall -and $sku.Kind -eq 'C2R' -and $before -and
   ($before.ProductReleaseIds -split ',') -contains $sku.ProductId){
  $app = Find-YcOfficeApp -Exe $sku.App
  Exit-Yc 0 ($sku.Label + ' is already installed (' + $before.ProductReleaseIds + ' v' + $before.Version +
             ', ' + $(if($app){ $app }else{ 'binary not found' }) + '). Use -Force to reinstall.') 'OK'
}

if(-not (Test-Path -LiteralPath $WorkDir)){ New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null }

# ------------------------------------------------------------------ the 2016 refusal

if($sku.Kind -eq 'MSI' -and -not $MediaPath){
  Write-YcLog ('PREFLIGHT REFUSED: ' + $sku.Label + ' is a Windows Installer (MSI) product. There is no ' +
    'Click-to-Run volume build of it, the Office Deployment Tool has no Product ID for it, and Microsoft ' +
    'publishes no public download. Nothing was installed.') 'ERROR'
  Write-YcLog 'HOW TO INSTALL IT:' 'WARN'
  Write-YcLog '  1. Download the volume-licensed ISO from VLSC, your CSP portal or the SPLA portal.' 'WARN'
  Write-YcLog '     Office Standard 2016 and Excel 2016 are separate ISOs - take the one you are licensed for.' 'WARN'
  Write-YcLog '  2. Mount it, or extract it to a folder.' 'WARN'
  Write-YcLog '  3. install-office -Product <sku> -MediaPath <the folder holding setup.exe>' 'WARN'
  Write-YcLog '  Add -ProductKey <MAK> to that command to license it in the same run.' 'WARN'
  Write-YcLog '  Office 2019 and 2021 need none of this - they are Click-to-Run and come from the CDN.' 'WARN'
  Exit-Yc 2 'no media for an MSI-era Office SKU' 'ERROR'
}

# ------------------------------------------------------------------ media

$setupExe = ''
if($sku.Kind -eq 'C2R'){
  if($OdtSetup){
    if(-not (Assert-YcFile -Path $OdtSetup -MinBytes 100000 -Because 'the Office Deployment Tool setup.exe passed with -OdtSetup')){
      Exit-Yc 4 ('-OdtSetup does not point at a usable setup.exe: ' + $OdtSetup) 'ERROR'
    }
    $setupExe = $OdtSetup
  }else{
    $setupExe = Join-Path $WorkDir 'setup.exe'
    if((Test-Path -LiteralPath $setupExe) -and -not $Force){
      Write-YcLog ('Reusing the Click-to-Run setup.exe already staged at ' + $setupExe + '.')
    }else{
      $got = Get-YcFile -Uri $OdtUrl -OutFile $setupExe -MinBytes 1000000
      if(-not $got){ Exit-Yc 3 ('could not download the Office Deployment Tool from ' + $OdtUrl) 'ERROR' }
    }
    if(-not (Assert-YcFile -Path $setupExe -MinBytes 1000000 -RequireSignature -Because 'the Click-to-Run installer runs as SYSTEM')){
      Exit-Yc 4 'the downloaded setup.exe is not a validly signed Microsoft binary' 'ERROR'
    }
  }
}else{
  $setupExe = Join-Path $MediaPath 'setup.exe'
  if(-not (Assert-YcFile -Path $setupExe -MinBytes 100000 -Because 'the volume-licensed 2016 media')){
    Exit-Yc 4 ('no setup.exe under -MediaPath ' + $MediaPath) 'ERROR'
  }
}

# ------------------------------------------------------------------ run it

$cfgPath = Join-Path $WorkDir ($Product + '-configuration.xml')
$rc = 1

if($Uninstall){
  if($sku.Kind -ne 'C2R'){ Exit-Yc 2 '-Uninstall is Click-to-Run only. Remove an MSI Office from Programs and Features or with its own setup.exe /uninstall.' 'ERROR' }
  New-YcOdtConfig -Path $cfgPath -Remove | Out-Null
  Write-YcLog ('Running: "' + $setupExe + '" /configure "' + $cfgPath + '"  (remove all Click-to-Run Office)')
  & $setupExe /configure $cfgPath | Out-Host
  $rc = $LASTEXITCODE
  $after = Get-YcOfficeC2RConfig
  if($after){ Exit-Yc 1 ('UNINSTALL FAILED: Click-to-Run Office is still registered as ' + $after.ProductReleaseIds + '. setup.exe exit ' + $rc + '.') 'ERROR' }
  Exit-Yc 0 ('Verified: no Click-to-Run Office remains on this host. setup.exe exit ' + $rc + '.') 'OK'
}

if($sku.Kind -eq 'C2R'){
  $xml = New-YcOdtConfig -Path $cfgPath -ProductId $sku.ProductId -Channel $sku.Channel -Arch $Architecture -Culture $Language
  Write-YcLog ('configuration.xml written to ' + $cfgPath + ': ' + (ConvertTo-YcOneLine $xml))

  if($DownloadOnly){
    Write-YcLog ('Running: "' + $setupExe + '" /download "' + $cfgPath + '"')
    & $setupExe /download $cfgPath | Out-Host
    $rc = $LASTEXITCODE
    if($rc -ne 0){ Exit-Yc 3 ('setup.exe /download exit ' + $rc + ' - the media was NOT staged.') 'ERROR' }
    Exit-Yc 0 ('Media for ' + $sku.Label + ' staged under ' + $WorkDir + ' (setup.exe /download exit 0). Nothing was installed.') 'OK'
  }

  Write-YcLog ('Running: "' + $setupExe + '" /configure "' + $cfgPath + '"')
  Write-YcLog 'Click-to-Run streams the product from Microsoft while it installs; on a slow link this takes many minutes and prints nothing.' 'WARN'
  & $setupExe /configure $cfgPath | Out-Host
  $rc = $LASTEXITCODE
}else{
  $msiCfg = Join-Path $WorkDir ($Product + '-msi-config.xml')
  New-YcMsiConfig -Path $msiCfg | Out-Null
  Write-YcLog ('Running: "' + $setupExe + '" /config "' + $msiCfg + '"')
  & $setupExe /config $msiCfg | Out-Host
  $rc = $LASTEXITCODE
}

# A non-zero exit is a hint. The instance on disk is the verdict - same rule activate-sql
# learned the hard way on 2026-09-01, when setup.exe returned a code with no published
# meaning on an upgrade that had in fact worked.
if($rc -eq 0){        Write-YcLog 'setup.exe exit 0.' 'OK' }
elseif($rc -eq 3010){ Write-YcLog 'setup.exe exit 3010 - success, REBOOT REQUIRED.' 'WARN' }
else{                 Write-YcLog ('setup.exe exit ' + $rc + ' - verifying what is actually on disk before deciding.') 'WARN' }

# ------------------------------------------------------------------ proof

$after  = Get-YcOfficeC2RConfig
$afterM = Get-YcOfficeMsiProduct
$app    = Find-YcOfficeApp -Exe $sku.App
$appVer = Get-YcOfficeAppVersion -Path $app

if($sku.Kind -eq 'C2R'){
  if(-not $after){
    Exit-Yc $(if($rc){ $rc }else{ 1 }) ('VERIFICATION FAILED: no Click-to-Run Office is registered after the install. setup.exe exit ' + $rc + '. Setup logs: ' + $env:TEMP) 'ERROR'
  }
  Write-YcLog ('AFTER (Click-to-Run): ProductReleaseIds=' + $after.ProductReleaseIds + ' Version=' + $after.Version +
               ' Platform=' + $after.Platform + ' Culture=' + $after.Culture)
  if(($after.ProductReleaseIds -split ',') -notcontains $sku.ProductId){
    Exit-Yc $(if($rc){ $rc }else{ 1 }) ('VERIFICATION FAILED: expected ' + $sku.ProductId + ' but this host reports "' +
      $after.ProductReleaseIds + '". setup.exe exit ' + $rc + '.') 'ERROR'
  }
}else{
  if(-not $afterM){
    Exit-Yc $(if($rc){ $rc }else{ 1 }) ('VERIFICATION FAILED: no MSI Office product is registered under Office\16.0. setup.exe exit ' + $rc + '.') 'ERROR'
  }
  Write-YcLog ('AFTER (MSI): Office\16.0 LastProduct=' + $afterM)
}

if(-not $app){
  Exit-Yc $(if($rc){ $rc }else{ 1 }) ('VERIFICATION FAILED: the registry says the product is installed but ' + $sku.App +
    ' is not on disk under any known Office16 root.') 'ERROR'
}
Write-YcLog ('VERIFIED: ' + $sku.Label + ' - ' + $app + ' version ' + $appVer) 'OK'

# ------------------------------------------------------------------ licensing (optional)

if($ProductKey){
  $ospp = Find-YcOspp
  if(-not $ospp){
    Write-YcLog ('INSTALL VERIFIED but ospp.vbs was not found, so the key ending ' + $keyTail +
      ' was NOT applied. Activate manually once ospp.vbs is present.') 'ERROR'
    Exit-Yc 7 'activation skipped: ospp.vbs missing' 'ERROR'
  }
  Write-YcLog ('Licensing with ospp.vbs at ' + $ospp + ', key ending ' + $keyTail + '.')
  $inp = & cscript.exe //Nologo $ospp ('/inpkey:' + $ProductKey) 2>&1 | Out-String
  Write-YcLog ('ospp /inpkey: ' + (ConvertTo-YcOneLine (Protect-YcSecret $inp)))
  $act = & cscript.exe //Nologo $ospp '/act' 2>&1 | Out-String
  Write-YcLog ('ospp /act: ' + (ConvertTo-YcOneLine (Protect-YcSecret $act)))
  $st  = & cscript.exe //Nologo $ospp '/dstatus' 2>&1 | Out-String
  Write-YcLog ('ospp /dstatus: ' + (ConvertTo-YcOneLine (Protect-YcSecret $st)))
  if(-not (Test-YcOsppLicensed $st)){
    Exit-Yc 7 ('ACTIVATION FAILED: ospp.vbs /dstatus does not report ---LICENSED--- for the key ending ' +
      $keyTail + '. The product IS installed and verified; only licensing failed.') 'ERROR'
  }
  Write-YcLog ('VERIFIED LICENSED: ospp.vbs reports ---LICENSED--- for the key ending ' + $keyTail + '.') 'OK'
}

if($rc -eq 3010){ Exit-Yc 0 ('Installed and verified. setup.exe asked for a reboot (3010) - schedule one.') 'OK' }
if($rc -ne 0){ Write-YcLog ('Note: setup.exe returned ' + $rc + ' but the install is verified above, so this run SUCCEEDED.') 'WARN' }
Exit-Yc 0 ('install-office complete: ' + $sku.Label + ' verified on this host.') 'OK'
