param(
  [switch]$Online,
  [ValidateSet('AllUsers','CurrentUser')]
  [string]$Scope = 'AllUsers',
  [switch]$Offline,
  [string]$PackagePath,
  [string]$Sha256,
  [string]$LibrarySha256,
  [string]$MinimumVersion = '2.0.0',
  [string]$RequiredVersion,
  [string]$Repository = 'PSGallery',
  [switch]$Force,
  [switch]$Help
)
# =====================================================================================
# Dbatools-Install.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
#
# WHAT CHANGED AND WHY
# --------------------
# The previous version could finish with a module that does not import, or with a bogus
# "dbatools 0.0.0" folder, and still exit 0. Install-Sql.ps1 then failed three files
# downstream and shipped a SQL Server with no backup jobs. Every one of those paths now
# ends in proof or in a non-zero exit.
#
#  1. A FAILED IMPORT IS NOW FATAL (was P1-1, old lines 70-78). Import failure was logged
#     at WARN and $code stayed 0. It is now ERROR + exit 1.
#  2. THE INSTALL IS PROVEN, NOT ASSUMED (was P1-2, old lines 46-58). The offline path
#     used to ExtractToDirectory + Copy-Item + log "Installed" with no check at all, and
#     defaulted the version to '0.0.0' when the .nuspec would not parse. Now: the nuspec
#     version must parse as a [version] or the run fails; the extracted payload must
#     contain dbatools.psd1 before anything is copied; the copy lands in a staging folder
#     that is only renamed into place once complete; and the final proof is
#     Import-Module + Get-Module version >= -MinimumVersion + Get-Command for three
#     real dbatools commands (Connect-DbaInstance, Get-DbaDatabase, Install-DbaInstance).
#  3. OPTIONAL SHA256 PINNING of the staged nupkg(s) (was P2-1). C:\Scripts is on the
#     system PATH and has a Defender exclusion, so an unverified nupkg extracted into
#     C:\Program Files\WindowsPowerShell\Modules is SYSTEM-level code execution. Pass
#     -Sha256 / -LibrarySha256 to pin. When not pinned the script says so at WARN and
#     reports the hash it actually installed, so the value can be pinned next time.
#  4. REAL SERVER 2016 BOOTSTRAP (was P2-3, old lines 61-64). Stock WS2016 ships
#     PowerShellGet 1.0.0.1 / PackageManagement 1.0.0.1 which cannot talk to the current
#     gallery. The online path now: enables TLS 1.2 with -bor (documented form, does not
#     stamp on protocols already enabled); installs/verifies the NuGet provider at the
#     documented minimum 2.8.5.201; if PowerShellGet is < 2.0 it installs the current
#     PowerShellGet and RE-EXECS ITSELF ONCE in a fresh powershell.exe (guarded by an
#     environment variable so it can never loop), because the running session keeps the
#     old assembly loaded; and it asserts the provider/module versions afterwards rather
#     than hoping.
#  5. PSGallery TRUST IS RESTORED (was P3-3). The old script permanently flipped PSGallery
#     to Trusted as a side effect. The previous InstallationPolicy is captured and put back.
#  6. dbatools.library IS HANDLED (offline path). dbatools 2.x will not import without it.
#     The staged-package path now installs dbatools.library too, and refuses to claim
#     success if it is missing.
#  7. STAGED PACKAGES ARE SORTED AS [version], NOT AS STRINGS (was P3-1, old line 12), so
#     2.10.0 no longer loses to 2.9.0. The old glob 'dbatools*.nupkg' also matched
#     dbatools.library.*.nupkg and could install the wrong package as "dbatools" -
#     the two are now matched by distinct patterns.
#  8. -Scope CurrentUser UNDER SYSTEM IS REFUSED (was P2-4). Under NT AUTHORITY\SYSTEM,
#     MyDocuments resolves to C:\Windows\system32\config\systemprofile\Documents and the
#     module is invisible to every real user. Exit 2 unless -Force.
#  9. SAFE IDEMPOTENCY / UPGRADE (was P2-5). Installing over a loaded module used to
#     Remove-Item -EA SilentlyContinue and then merge new files over old, producing a
#     hybrid. Now each version gets its own folder, the new one is staged and renamed,
#     and the old one is only removed after the new one imports.
# 10. UNHANDLED-EXCEPTION GUARD (was P2-6). ZipFile::ExtractToDirectory throws on a
#     corrupt nupkg; that used to leave no [END] line and an open transcript. One
#     try/catch now guarantees Stop-YcLog with the real code on every path.
# 11. -MinimumVersion ASSERTED (was P3-2). dbatools 1.x has no 'Install-DbaInstance
#     -Version 2022/2025' in its ValidateSet, which is exactly what Install-Sql.ps1
#     passes. Default minimum 2.0.0.
#
# PARAMETERS ADDED (none renamed, none removed):
#     -Offline, -PackagePath, -Sha256, -LibrarySha256, -MinimumVersion,
#     -RequiredVersion, -Repository, -Force
#
# Log: C:\Scripts\dbatools-install.log
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'dbatools-install'
$ErrorActionPreference = 'Stop'

$HelpText = @"
dbatools-install - install the dbatools PowerShell module (SQL Server management toolkit)
                   and PROVE it imports before reporting success.

USAGE:
  dbatools-install [-Online] [-Offline] [-Scope AllUsers|CurrentUser]
                   [-PackagePath <dir-or-nupkg>] [-Sha256 <hash>] [-LibrarySha256 <hash>]
                   [-MinimumVersion 2.0.0] [-RequiredVersion <ver>] [-Repository PSGallery]
                   [-Force]
  dbatools-install -Help

PARAMETERS (required: none):
  -Online          Force an online gallery install even when a staged package is present.
  -Offline         Force the staged/air-gapped path and never touch the network. Fails
                   with a clear message if no staged package can be found.
  -Scope           AllUsers (default, needs admin) or CurrentUser. CurrentUser is refused
                   when running as SYSTEM unless -Force, because it would install to
                   C:\Windows\system32\config\systemprofile\Documents where nobody sees it.
  -PackagePath     Staged source. Either a .nupkg file, or a directory produced by
                   'Save-Module dbatools -Path <dir>' (containing dbatools and
                   dbatools.library subfolders). Default search: C:\Scripts.
  -Sha256          Expected SHA256 of the dbatools .nupkg. Pinning is strongly recommended:
                   C:\Scripts is on the system PATH and carries an AV exclusion.
  -LibrarySha256   Expected SHA256 of the dbatools.library .nupkg.
  -MinimumVersion  Minimum acceptable installed version. Default 2.0.0 (1.x cannot drive
                   Install-DbaInstance -Version 2022/2025).
  -RequiredVersion Pin an exact gallery version instead of "latest".
  -Repository      PSRepository name for the online path. Default PSGallery. Point this at
                   an internal repository to avoid the unpinned-nupkg problem entirely.
  -Force           Override the SYSTEM/CurrentUser refusal and reinstall even if the
                   required version is already present and importable.
  -Help            Show this help and exit 0.

EXAMPLES:
  dbatools-install
  dbatools-install -Offline -PackagePath C:\Scripts\dbatools-offline -Sha256 <hash>
  dbatools-install -Online -RequiredVersion 2.8.4
  dbatools-install -Online -Repository YallaCloudInternal -Scope AllUsers
  dbatools-install -Help

AIR-GAPPED WORKFLOW:
  On a connected machine:   Save-Module dbatools -Path C:\temp\offline
  (that also pulls dbatools.library, which dbatools 2.x cannot import without)
  Copy C:\temp\offline to the target, then:
      dbatools-install -Offline -PackagePath C:\temp\offline

EXIT CODES:
  0  Verified: dbatools imported, version >= -MinimumVersion, expected commands present.
  1  Install or verification failed (module missing, wrong version, import failed).
  2  Usage error (-Scope CurrentUser under SYSTEM, or -Online and -Offline together).
  3  No installation source: no staged package found and the online path was not available.
  5  Not elevated (from _yc-lib Assert-YcPrereqs).
  6  No outbound internet on an online install (from _yc-lib Assert-YcPrereqs).

Log: C:\Scripts\dbatools-install.log
"@

if($Help){ Write-Host $HelpText -ForegroundColor Cyan; Stop-YcLog 0; exit 0 }

Assert-YcPrereqs -NeedAdmin
$script:YcExit = 1

# TLS 1.2 before any gallery call. -bor (documented form) so protocols already enabled
# on newer OS builds are not turned off.
[Net.ServicePointManager]::SecurityProtocol =
  [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

# ------------------------------------------------------------------ helpers

function Test-YcRunningAsSystem{
  try{
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    return ($id.User.Value -eq 'S-1-5-18')
  }catch{ return $false }
}

function Get-YcModuleRoot([string]$InstallScope){
  if($InstallScope -eq 'CurrentUser'){
    return (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'WindowsPowerShell\Modules')
  }
  return (Join-Path $env:ProgramFiles 'WindowsPowerShell\Modules')
}

function Get-YcFileSha256([string]$Path){
  return (Get-FileHash -Path $Path -Algorithm SHA256).Hash.ToUpperInvariant()
}

function Assert-YcHash{
  param([string]$Path,[string]$Expected,[string]$Label)
  $actual = Get-YcFileSha256 $Path
  if($Expected){
    if($actual -ne $Expected.Trim().ToUpperInvariant()){
      Write-YcLog ('SHA256 MISMATCH for ' + $Label + ' (' + $Path + '). Expected ' +
        $Expected.Trim().ToUpperInvariant() + ' got ' + $actual + '. Refusing to install.') 'ERROR'
      return $false
    }
    Write-YcLog ('SHA256 verified for ' + $Label + ': ' + $actual) 'OK'
    return $true
  }
  Write-YcLog ('No -Sha256 pin supplied for ' + $Label + '. Installed hash is ' + $actual +
    ' - pin this value on the next run.') 'WARN'
  return $true
}

# Parse "dbatools.2.10.0.nupkg" -> [version]2.10.0 (string sorting gets this wrong).
function Get-YcNupkgVersion([string]$FileName){
  $m = [regex]::Match($FileName,'^(?<id>[A-Za-z0-9_.]+?)\.(?<ver>\d+(\.\d+){1,3})\.nupkg$')
  if(-not $m.Success){ return $null }
  $v = $null
  if([version]::TryParse($m.Groups['ver'].Value,[ref]$v)){ return $v }
  return $null
}

function Find-YcStagedNupkg{
  param([string]$SearchDir,[string]$Id)
  # Match "<Id>.<version>.nupkg" exactly, so 'dbatools' never matches 'dbatools.library'.
  $pat = '^' + [regex]::Escape($Id) + '\.\d+(\.\d+){1,3}\.nupkg$'
  $all = Get-ChildItem -Path $SearchDir -Filter '*.nupkg' -File -ErrorAction Ignore |
         Where-Object { $_.Name -match $pat }
  if(-not $all){ return $null }
  return ($all | Sort-Object { Get-YcNupkgVersion $_.Name } -Descending | Select-Object -First 1)
}

# Extract a nupkg and return the directory holding the module payload, or $null.
function Expand-YcNupkg{
  param([string]$NupkgPath,[string]$Id)
  $tmp = Join-Path $env:TEMP ('ycdbat_' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [System.IO.Compression.ZipFile]::ExtractToDirectory($NupkgPath,$tmp)   # throws on a corrupt zip

  $nuspec = Get-ChildItem -Path $tmp -Filter '*.nuspec' -File | Select-Object -First 1
  if(-not $nuspec){
    Remove-Item -Path $tmp -Recurse -Force
    Write-YcLog ($NupkgPath + ' contains no .nuspec - it is not a PowerShell package.') 'ERROR'
    return $null
  }
  $ver = $null
  try{ $ver = [version](([xml](Get-Content -Path $nuspec.FullName -Raw)).package.metadata.version) }
  catch{ $ver = $null }
  if(-not $ver){
    Remove-Item -Path $tmp -Recurse -Force
    Write-YcLog ('Could not read a parseable <version> from ' + $nuspec.Name + ' in ' +
      $NupkgPath + '. Refusing to install to a "0.0.0" folder.') 'ERROR'
    return $null
  }
  $psd1 = Join-Path $tmp ($Id + '.psd1')
  if(-not (Test-Path -LiteralPath $psd1)){
    Remove-Item -Path $tmp -Recurse -Force
    Write-YcLog ($NupkgPath + ' has no ' + $Id + '.psd1 at its root - truncated or not a ' +
      'PowerShell module package.') 'ERROR'
    return $null
  }
  return (New-Object psobject -Property @{ Path = $tmp; Version = $ver })
}

# Copy a module payload into <root>\<Id>\<version>, staged then renamed.
function Install-YcModulePayload{
  param([string]$SourceDir,[string]$Id,[version]$Version,[string]$ModuleRoot)
  $final = Join-Path $ModuleRoot ($Id + '\' + $Version.ToString())
  $stage = $final + '.yc-staging'
  if(Test-Path -LiteralPath $stage){ Remove-Item -LiteralPath $stage -Recurse -Force }
  New-Item -ItemType Directory -Path $stage -Force | Out-Null

  $exclude = @('_rels','package','[Content_Types].xml')
  Get-ChildItem -Path $SourceDir -Force |
    Where-Object { ($exclude -notcontains $_.Name) -and ($_.Extension -ne '.nuspec') } |
    ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $stage -Recurse -Force }

  $psd1 = Join-Path $stage ($Id + '.psd1')
  if(-not (Test-Path -LiteralPath $psd1)){
    Remove-Item -LiteralPath $stage -Recurse -Force
    Write-YcLog ('Copy of ' + $Id + ' ' + $Version + ' did not produce ' + $Id +
      '.psd1 - install aborted, nothing was changed.') 'ERROR'
    return $false
  }

  $old = $null
  if(Test-Path -LiteralPath $final){
    $old = $final + '.yc-old-' + (Get-Date).ToString('yyyyMMddHHmmss')
    Rename-Item -LiteralPath $final -NewName (Split-Path -Leaf $old)
  }
  Rename-Item -LiteralPath $stage -NewName (Split-Path -Leaf $final)
  if($old){ $script:YcOldModuleDirs += $old }
  Write-YcLog ('Installed ' + $Id + ' ' + $Version + ' -> ' + $final) 'OK'
  return $true
}

function Install-YcFromNupkg{
  param([string]$NupkgPath,[string]$Id,[string]$ExpectedHash,[string]$ModuleRoot)
  if(-not (Assert-YcHash -Path $NupkgPath -Expected $ExpectedHash -Label $Id)){ return $false }
  $x = Expand-YcNupkg -NupkgPath $NupkgPath -Id $Id
  if(-not $x){ return $false }
  try{
    return (Install-YcModulePayload -SourceDir $x.Path -Id $Id -Version $x.Version -ModuleRoot $ModuleRoot)
  }finally{
    if(Test-Path -LiteralPath $x.Path){ Remove-Item -LiteralPath $x.Path -Recurse -Force }
  }
}

# Save-Module layout: <dir>\<Id>\<version>\<Id>.psd1
function Install-YcFromSaveModuleDir{
  param([string]$Dir,[string]$Id,[string]$ModuleRoot)
  $src = Join-Path $Dir $Id
  if(-not (Test-Path -LiteralPath $src)){ return $false }
  $verDir = Get-ChildItem -Path $src -Directory -ErrorAction Ignore |
            Where-Object { $null -ne (Get-YcSafeVersion $_.Name) } |
            Sort-Object { Get-YcSafeVersion $_.Name } -Descending | Select-Object -First 1
  if(-not $verDir){
    # Save-Module on some PowerShellGet versions writes the payload directly under <Id>.
    if(Test-Path -LiteralPath (Join-Path $src ($Id + '.psd1'))){
      $man = Import-PowerShellDataFile -Path (Join-Path $src ($Id + '.psd1'))
      return (Install-YcModulePayload -SourceDir $src -Id $Id -Version ([version]$man.ModuleVersion) -ModuleRoot $ModuleRoot)
    }
    return $false
  }
  return (Install-YcModulePayload -SourceDir $verDir.FullName -Id $Id `
            -Version (Get-YcSafeVersion $verDir.Name) -ModuleRoot $ModuleRoot)
}

function Get-YcSafeVersion([string]$s){
  $v = $null
  if([version]::TryParse($s,[ref]$v)){ return $v }
  return $null
}

# --- online bootstrap ----------------------------------------------------------------
function Get-YcPowerShellGetVersion{
  $m = Get-Module -Name PowerShellGet -ListAvailable |
       Sort-Object Version -Descending | Select-Object -First 1
  if($m){ return $m.Version }
  return ([version]'0.0.0')
}

function Initialize-YcGalleryBootstrap{
  # 1) NuGet package provider at the documented minimum.
  $nuget = Get-PackageProvider -Name NuGet -ListAvailable -ErrorAction Ignore |
           Sort-Object Version -Descending | Select-Object -First 1
  if((-not $nuget) -or ($nuget.Version -lt [version]'2.8.5.201')){
    Write-YcLog 'Bootstrapping the NuGet package provider (minimum 2.8.5.201)...'
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Scope AllUsers | Out-Null
    Import-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force | Out-Null
    $nuget = Get-PackageProvider -Name NuGet -ListAvailable -ErrorAction Ignore |
             Sort-Object Version -Descending | Select-Object -First 1
  }
  if((-not $nuget) -or ($nuget.Version -lt [version]'2.8.5.201')){
    $have = if($nuget){ [string]$nuget.Version } else { 'none' }
    Write-YcLog ('NuGet provider bootstrap FAILED: required 2.8.5.201+, have ' + $have +
      '. This host cannot talk to a NuGet-based repository. Use the offline path ' +
      '(-Offline -PackagePath <dir>).') 'ERROR'
    return $false
  }
  Write-YcLog ('NuGet provider ' + $nuget.Version + ' present.') 'OK'

  # 2) PowerShellGet. Stock Server 2016 ships 1.0.0.1, which cannot install from the
  #    current gallery. Installing a new one does not replace the assembly already loaded
  #    in this session, so re-exec once in a clean process.
  $pgv = Get-YcPowerShellGetVersion
  Write-YcLog ('PowerShellGet available version: ' + $pgv)
  if($pgv -lt [version]'2.0.0'){
    if($env:YC_DBATOOLS_REEXEC -eq '1'){
      Write-YcLog ('PowerShellGet is still ' + $pgv + ' after a bootstrap and re-exec. ' +
        'Install PowerShellGet 2.x manually, or use the offline path.') 'ERROR'
      return $false
    }
    Write-YcLog 'Bootstrapping PowerShellGet 2.x (Server 2016 ships 1.0.0.1)...'
    # Documented form. -SkipPublisherCheck is deliberately NOT used here: it does not
    # exist on PowerShellGet 1.0.0.1, which is exactly the version we are replacing.
    Install-Module -Name PowerShellGet -Repository PSGallery -Force -AllowClobber `
                   -Scope AllUsers | Out-Null
    $pgv = Get-YcPowerShellGetVersion
    if($pgv -lt [version]'2.0.0'){
      Write-YcLog ('PowerShellGet bootstrap FAILED (still ' + $pgv + ').') 'ERROR'
      return $false
    }
    Write-YcLog ('PowerShellGet ' + $pgv + ' installed; re-executing in a clean session so ' +
      'the new module is the one that runs.') 'WARN'
    $script:YcNeedReExec = $true
    return $true
  }
  return $true
}

function Invoke-YcSelfReExec{
  $self = $PSCommandPath
  if(-not $self){ $self = $MyInvocation.MyCommand.Path }
  if(-not $self){
    Write-YcLog 'Cannot determine this script path for the re-exec.' 'ERROR'
    return 1
  }
  $a = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$self)
  if($Online){ $a += '-Online' }
  if($Offline){ $a += '-Offline' }
  if($Force){ $a += '-Force' }
  $a += @('-Scope',$Scope,'-MinimumVersion',$MinimumVersion,'-Repository',$Repository)
  if($RequiredVersion){ $a += @('-RequiredVersion',$RequiredVersion) }
  if($PackagePath){ $a += @('-PackagePath',$PackagePath) }
  if($Sha256){ $a += @('-Sha256',$Sha256) }
  if($LibrarySha256){ $a += @('-LibrarySha256',$LibrarySha256) }
  $env:YC_DBATOOLS_REEXEC = '1'
  Write-YcLog ('Re-exec: powershell.exe ' + ($a -join ' '))
  $p = Start-Process -FilePath 'powershell.exe' -ArgumentList $a -Wait -PassThru -NoNewWindow
  Write-YcLog ('Re-executed run finished with exit ' + $p.ExitCode)
  return [int]$p.ExitCode
}

function Install-YcDbatoolsOnline{
  $prevPolicy = $null
  $repo = Get-PSRepository -Name $Repository -ErrorAction Ignore
  if(-not $repo){
    Write-YcLog ('PSRepository "' + $Repository + '" is not registered on this host.') 'ERROR'
    return $false
  }
  $prevPolicy = $repo.InstallationPolicy
  try{
    if($prevPolicy -ne 'Trusted'){
      Set-PSRepository -Name $Repository -InstallationPolicy Trusted
      Write-YcLog ('Temporarily trusting repository ' + $Repository + ' (was ' + $prevPolicy + ').')
    }
    $ps = @{ Name='dbatools'; Repository=$Repository; Scope=$Scope; Force=$true;
             AllowClobber=$true; SkipPublisherCheck=$true; ErrorAction='Stop' }
    if($RequiredVersion){ $ps['RequiredVersion'] = $RequiredVersion }
    else{ $ps['MinimumVersion'] = $MinimumVersion }
    Write-YcLog ('Install-Module dbatools from ' + $Repository + ' (scope ' + $Scope + ')...')
    Install-Module @ps
    return $true
  }catch{
    Write-YcLog ('Gallery install failed: ' + $_.Exception.Message) 'ERROR'
    return $false
  }finally{
    if($prevPolicy -and $prevPolicy -ne 'Trusted'){
      try{ Set-PSRepository -Name $Repository -InstallationPolicy $prevPolicy
           Write-YcLog ('Restored ' + $Repository + ' InstallationPolicy to ' + $prevPolicy + '.') }
      catch{ Write-YcLog ('Could not restore InstallationPolicy on ' + $Repository + ': ' +
                          $_.Exception.Message) 'WARN' }
    }
  }
}

# --- the proof -----------------------------------------------------------------------
function Assert-YcDbatoolsUsable{
  param([version]$Minimum)
  $expected = @('Connect-DbaInstance','Get-DbaDatabase','Install-DbaInstance')
  try{
    $loaded = Get-Module -Name dbatools
    if($loaded){ try{ Remove-Module -ModuleInfo $loaded -Force }catch{} }
    Import-Module -Name dbatools -Force -ErrorAction Stop
  }catch{
    Write-YcLog ('VERIFICATION FAILED: Import-Module dbatools threw: ' + $_.Exception.Message) 'ERROR'
    $lib = Get-Module -Name dbatools.library -ListAvailable
    if(-not $lib){
      Write-YcLog ('dbatools.library is NOT installed. dbatools 2.x cannot import without it. ' +
        'Save-Module dbatools on a connected host pulls it automatically.') 'ERROR'
    }
    return $false
  }
  $m = Get-Module -Name dbatools | Sort-Object Version -Descending | Select-Object -First 1
  if(-not $m){
    Write-YcLog 'VERIFICATION FAILED: dbatools imported but Get-Module returned nothing.' 'ERROR'
    return $false
  }
  if($m.Version -lt $Minimum){
    Write-YcLog ('VERIFICATION FAILED: dbatools ' + $m.Version + ' is below the required ' +
      'minimum ' + $Minimum + '. 1.x cannot drive Install-DbaInstance -Version 2022/2025.') 'ERROR'
    return $false
  }
  $missing = @()
  foreach($c in $expected){
    $cmd = Get-Command -Module dbatools -Name $c -ErrorAction Ignore
    if(-not $cmd){ $missing += $c }
  }
  if($missing.Count -gt 0){
    Write-YcLog ('VERIFICATION FAILED: dbatools ' + $m.Version + ' imported but these ' +
      'commands are missing: ' + ($missing -join ', ')) 'ERROR'
    return $false
  }
  $libv = ''
  $lib = Get-Module -Name dbatools.library -ListAvailable |
         Sort-Object Version -Descending | Select-Object -First 1
  if($lib){ $libv = ' (dbatools.library ' + $lib.Version + ')' }
  Write-YcLog ('VERIFIED: dbatools ' + $m.Version + $libv + ' imported from ' + $m.ModuleBase +
    '; ' + ($expected -join ', ') + ' all resolve. Command count: ' +
    ((Get-Command -Module dbatools).Count) + '.') 'OK'
  return $true
}

# ------------------------------------------------------------------ main

function Invoke-Main{
  $script:YcOldModuleDirs = @()
  $script:YcNeedReExec    = $false

  if($Online -and $Offline){
    Write-YcLog '-Online and -Offline are mutually exclusive.' 'ERROR'
    $script:YcExit = 2; return
  }
  if($Scope -eq 'CurrentUser' -and (Test-YcRunningAsSystem) -and -not $Force){
    Write-YcLog ('-Scope CurrentUser under NT AUTHORITY\SYSTEM installs to ' +
      'C:\Windows\system32\config\systemprofile\Documents\WindowsPowerShell\Modules, where no ' +
      'real user or service will ever find it. Use -Scope AllUsers, or -Force to override.') 'ERROR'
    $script:YcExit = 2; return
  }

  $minVer = $null
  if(-not [version]::TryParse($MinimumVersion,[ref]$minVer)){
    Write-YcLog ('-MinimumVersion "' + $MinimumVersion + '" is not a valid version.') 'ERROR'
    $script:YcExit = 2; return
  }
  $modRoot = Get-YcModuleRoot $Scope
  Write-YcLog ('Scope=' + $Scope + '  ModuleRoot=' + $modRoot + '  MinimumVersion=' + $minVer)

  # Already good enough? (idempotent, upgrade-safe)
  if(-not $Force -and -not $RequiredVersion){
    $have = Get-Module -Name dbatools -ListAvailable |
            Sort-Object Version -Descending | Select-Object -First 1
    if($have -and $have.Version -ge $minVer){
      Write-YcLog ('dbatools ' + $have.Version + ' is already installed at ' + $have.ModuleBase +
        ' - verifying it actually works rather than assuming.')
      if(Assert-YcDbatoolsUsable -Minimum $minVer){ $script:YcExit = 0; return }
      Write-YcLog 'Existing install did not verify - continuing with a reinstall.' 'WARN'
    }
  }

  # --- pick a source ----------------------------------------------------------------
  $searchDir = if($PackagePath){ $PackagePath } else { 'C:\Scripts' }
  $isDir = ($PackagePath -and (Test-Path -LiteralPath $PackagePath -PathType Container))
  if($PackagePath -and -not (Test-Path -LiteralPath $PackagePath)){
    Write-YcLog ('-PackagePath does not exist: ' + $PackagePath) 'ERROR'
    $script:YcExit = 3; return
  }
  $explicitNupkg = ($PackagePath -and -not $isDir -and ($PackagePath -like '*.nupkg'))
  if($explicitNupkg){ $searchDir = Split-Path -Parent $PackagePath }

  $mainPkg = $null
  $libPkg  = $null
  $saveDir = $null
  if(-not $Online){
    if($explicitNupkg){
      $mainPkg = Get-Item -LiteralPath $PackagePath
      $libPkg  = Find-YcStagedNupkg -SearchDir $searchDir -Id 'dbatools.library'
    }else{
      if($isDir -and (Test-Path -LiteralPath (Join-Path $PackagePath 'dbatools'))){
        $saveDir = $PackagePath
      }else{
        $mainPkg = Find-YcStagedNupkg -SearchDir $searchDir -Id 'dbatools'
        $libPkg  = Find-YcStagedNupkg -SearchDir $searchDir -Id 'dbatools.library'
      }
    }
  }

  $installed = $false
  if($saveDir){
    Write-YcLog ('Offline install from Save-Module directory: ' + $saveDir)
    $okLib = Install-YcFromSaveModuleDir -Dir $saveDir -Id 'dbatools.library' -ModuleRoot $modRoot
    if(-not $okLib){ Write-YcLog ('dbatools.library not present under ' + $saveDir +
      ' - dbatools 2.x will not import without it.') 'WARN' }
    $installed = Install-YcFromSaveModuleDir -Dir $saveDir -Id 'dbatools' -ModuleRoot $modRoot
    if(-not $installed){
      Write-YcLog ('No dbatools module payload found under ' + $saveDir + '.') 'ERROR'
      $script:YcExit = 3; return
    }
  }elseif($mainPkg -and -not $Online){
    Write-YcLog ('Offline install from staged package: ' + $mainPkg.FullName)
    if($libPkg){
      Write-YcLog ('Staged dependency: ' + $libPkg.Name)
      if(-not (Install-YcFromNupkg -NupkgPath $libPkg.FullName -Id 'dbatools.library' `
                                   -ExpectedHash $LibrarySha256 -ModuleRoot $modRoot)){
        $script:YcExit = 1; return
      }
    }else{
      $haveLib = Get-Module -Name dbatools.library -ListAvailable
      if(-not $haveLib){
        Write-YcLog ('No dbatools.library package staged in ' + $searchDir + ' and none is ' +
          'installed. dbatools 2.x cannot import without it. Stage it, or use ' +
          '"Save-Module dbatools -Path <dir>" on a connected host and pass -PackagePath <dir>.') 'WARN'
      }
    }
    $installed = Install-YcFromNupkg -NupkgPath $mainPkg.FullName -Id 'dbatools' `
                                     -ExpectedHash $Sha256 -ModuleRoot $modRoot
    if(-not $installed){ $script:YcExit = 1; return }
  }else{
    if($Offline){
      Write-YcLog ('-Offline was requested but no staged dbatools package was found in ' +
        $searchDir + '. Expected "dbatools.<version>.nupkg" or a Save-Module directory ' +
        'containing a "dbatools" folder.') 'ERROR'
      $script:YcExit = 3; return
    }
    Assert-YcPrereqs -NeedInternet
    if(-not (Initialize-YcGalleryBootstrap)){ $script:YcExit = 1; return }
    if($script:YcNeedReExec){
      $script:YcExit = (Invoke-YcSelfReExec)
      return
    }
    if(-not (Install-YcDbatoolsOnline)){ $script:YcExit = 1; return }
    $installed = $true
  }

  # --- proof -------------------------------------------------------------------------
  if(-not (Assert-YcDbatoolsUsable -Minimum $minVer)){ $script:YcExit = 1; return }

  foreach($old in $script:YcOldModuleDirs){
    try{
      if(Test-Path -LiteralPath $old){ Remove-Item -LiteralPath $old -Recurse -Force }
      Write-YcLog ('Removed superseded module folder ' + $old)
    }catch{
      Write-YcLog ('Superseded module folder left in place (in use?): ' + $old + ' - ' +
        $_.Exception.Message) 'WARN'
    }
  }
  $script:YcExit = 0
}

try{
  Invoke-Main | Out-Null
}catch{
  Write-YcLog ('UNHANDLED EXCEPTION: ' + $_.Exception.Message) 'ERROR'
  if($_.ScriptStackTrace){ Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}

Stop-YcLog $script:YcExit
exit $script:YcExit
