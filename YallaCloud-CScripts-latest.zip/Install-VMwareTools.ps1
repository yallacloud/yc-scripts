param(
  # ---- names preserved from vmware-tools.cmd and the catalog ----
  [switch]$Drivers,                                  # drivers-only install (no guest service)
  # ---- ADDED in this revision ----
  [string]$InstallerPath,                            # explicit installer .exe
  [string]$Url = 'https://packages-prod.broadcom.com/tools/releases/12.5.4/x64/VMware-tools-12.5.4-24964629-x64.exe',
  [string]$Sha256,                                   # expected SHA256 of the downloaded installer
  [int]$TimeoutSec = 1800,                           # hard timeout for the installer
  [switch]$SkipVcRedist,                             # do not touch the VC++ redistributables
  [switch]$Force,                                    # run even though this is NOT a VMware guest (see below)
  [switch]$Help
)
# =====================================================================================
# Install-VMwareTools.ps1 - SILENT install of VMware Tools on a VMware guest.
# PowerShell 5.1, ASCII only. Runs unattended (cloud-init / SYSTEM / RMM).
#
# Stamp: 2026-08-19 - removed the documented exit code 2 'usage error'; there is no usage-error
#        path. Exit 1 was KEPT: it IS reachable where Invoke-YcInstaller reports failure with
#        ExitCode 0 and the code is remapped to 1. No behaviour changed.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P0-22] THE INSTALL WAS NEVER SILENT AND THE FAILURE PRINTED GREEN.
#   1. THE COMMAND LINE WAS WRONG. Line 19 built '/S /v "/qn REBOOT=R"' with a SPACE
#      between /v and its payload. The VMware Tools bootstrapper is InstallShield: the
#      MSI payload must be APPENDED to /v with NO separator. With the space, /v received
#      an empty argument and /qn never reached the embedded MSI, so under SYSTEM in
#      session 0 - where there is no desktop - the install either errored immediately or
#      blocked on an invisible dialog until the deployment timed out.
#      Correct, and what this script now emits:   /S /v"/qn REBOOT=R"
#      https://knowledge.broadcom.com/external/article/376237/installing-vmware-tools-on-a-vmware-vsph.html
#   2. THE EXIT CODE WAS PRINTED IN GREEN WHATEVER IT WAS (old line 21) and returned as
#      the script's exit code with no interpretation. Now Invoke-YcInstaller decodes it,
#      0/1641/3010 are the only success codes, and success additionally requires the
#      VMTools service to be Running.
#   3. THE SCRIPT NEVER DOT-SOURCED _yc-lib.ps1. There was no admin check, no log file,
#      no event-log entry: a failure on a remote VM left no evidence at all. It now uses
#      the standard prologue, Assert-YcPrereqs -NeedAdmin, and Exit-Yc for every exit.
#   4. 'ADDLOCAL=Drivers' IS NOT A DOCUMENTED FEATURE NAME. The old -Drivers path emitted
#      ADDLOCAL=Drivers, which is not one of the components Broadcom documents, so it
#      installed nothing useful. -Drivers now emits the documented component names
#      (PVSCSI, VMXNet3, SVGA, MemCtl, Mouse, VMCI, Sync).
#      https://techdocs.broadcom.com/us/en/vmware-cis/vsphere/tools/12-5-0/vmware-tools-administration-12-5-0/installing-vmware-tools/automatically-install-vmware-tools-on-multiple-windows-virtual-machines/specify-vmware-tools-components-for-silent-installations.html
#   5. HYPERVISOR GATE. YallaCloud runs CloudStack + KVM. PVSCSI, VMXNET3 and the VMware
#      SVGA driver can NEVER bind on a KVM/QEMU guest, and the VMware guest service has
#      no backdoor channel to talk to, so on a KVM VM this package is pure harm: minutes
#      of install time, a reboot flag, unbindable storage/network filter drivers and a
#      permanently unhealthy service. The script now reads
#      (Get-CimInstance Win32_ComputerSystem).Manufacturer and REFUSES to run (exit 12)
#      unless it matches 'VMware'. -Force overrides that, loudly, for lab use only.
#
# OTHER DEFECTS FIXED HERE
#   - The old download loop swallowed every exception (catch{ Start-Sleep 10 }) and could
#     save a proxy login page as a 60MB .exe. Get-YcFile forces TLS 1.2/1.3, retries with
#     backoff, verifies SHA256 when supplied and REFUSES an HTML body saved as .exe.
#   - The old VC++ redist loop was three nested empty catch blocks; its failures are now
#     logged as WARN, and it is skippable with -SkipVcRedist. It is best-effort by design:
#     VMware Tools 12.x carries what it needs, this is belt-and-braces for older images.
#   - Idempotency: a full install is skipped when VMTools already exists AND is Running;
#     if it exists but is stopped, the service is started and proven rather than reported.
#
# EXTERNAL COMMAND LINES EMITTED BY THIS SCRIPT (all vendor-documented):
#   VMware-tools-<v>-x64.exe /S /v"/qn REBOOT=R"
#   VMware-tools-<v>-x64.exe /S /v"/qn REBOOT=R ADDLOCAL=PVSCSI,VMXNet3,SVGA,MemCtl,Mouse,VMCI,Sync"
#   vc_redist.x64.exe /install /quiet /norestart
#     https://learn.microsoft.com/en-us/cpp/windows/redistributing-visual-cpp-files
#   NO undocumented switch is emitted. REBOOT=R suppresses the reboot prompt; the
#   installer may still return 3010 to say a reboot is needed, which is success.
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was installed. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'vmware-tools'

$Usage = @'
vmware-tools  -  SILENT install of VMware Tools on a VMware guest (reboot suppressed).
                 Staged installer: C:\Scripts\VMware-Tools-x64.exe   Log: C:\Scripts\vmware-tools.log

USAGE:
  vmware-tools                                  full VMware Tools (guest service + drivers)
  vmware-tools -Drivers                         drivers only (PVSCSI + VMXNet3 + SVGA + MemCtl + Mouse + VMCI + Sync)
  vmware-tools [-InstallerPath <exe>] [-Url <url> [-Sha256 <hash>]] [-TimeoutSec 1800]
               [-SkipVcRedist] [-Force]
  vmware-tools -Help

THIS COMMAND REFUSES TO RUN ON A NON-VMWARE GUEST.
  YallaCloud runs CloudStack on KVM. On a KVM/QEMU guest the VMware PVSCSI and VMXNET3
  drivers can never bind to any device and the guest service has nothing to talk to, so
  installing VMware Tools there costs a reboot and leaves a permanently failed service.
  The check is (Get-CimInstance Win32_ComputerSystem).Manufacturer -match 'VMware'.
  Use -Force only on a genuine VMware host that reports an unexpected manufacturer.
  On KVM the correct package is virtio-win (netkvm / viostor / vioscsi / balloon).

PARAMETERS:
  -Drivers        Drivers-only install: no guest service (VMTools). Use to repair an image
                  whose drivers are already baked in. Emits the documented component names;
                  'ADDLOCAL=Drivers' - what this script used to emit - is not a real feature.
  -InstallerPath  Explicit installer .exe. Default: C:\Scripts\VMware-Tools-x64.exe, then -Url.
  -Url            Download location if nothing is staged. Default is the Broadcom 12.5.4 x64 build.
  -Sha256         Expected SHA256 of the downloaded installer. Strongly recommended.
  -TimeoutSec     Hard timeout for the installer process (default 1800). It is KILLED on timeout.
  -SkipVcRedist   Do not attempt the Visual C++ redistributables (best-effort, older images only).
  -Force          Run even though this host does not report itself as a VMware guest. Lab use only.
  -Help           Show this help and exit.

PROOF OF SUCCESS (nothing below is assumed):
  full     installer exit 0/3010/1641  AND  service VMTools exists AND is Running
           AND the VMware Tools version is readable from the registry.
  -Drivers installer exit 0/3010/1641  AND  at least one VMware driver service is present.
  A green line is printed only after that. The old script printed green on every exit code.

EXAMPLES:
  vmware-tools
  vmware-tools -Drivers
  vmware-tools -InstallerPath D:\pkg\VMware-tools-12.5.4-24964629-x64.exe
  vmware-tools -Url https://packages-prod.broadcom.com/tools/releases/12.5.4/x64/VMware-tools-12.5.4-24964629-x64.exe -Sha256 <hash>
  vmware-tools -Help

EXIT CODES:
  0   VMware Tools installed and proven (VMTools Running), or already installed
  1   generic failure (the installer reported success but Invoke-YcInstaller did not accept it)
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4   installer missing, too small, or not an executable
  5   not running as Administrator
  6   a download was required but there is no outbound internet
  7   the installer succeeded but the VMTools service is missing or not Running
  9   the installer download failed
  10  the installer did not exit within -TimeoutSec and was killed
  12  this is NOT a VMware guest - refused (use -Force to override)
  <n> any other value is the installer's own exit code

Log: C:\Scripts\vmware-tools.log   (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

# ------------------------------------------------------------------------------------
# 1. HYPERVISOR GATE. This is a CloudStack/KVM shop; refuse on anything but VMware.
# ------------------------------------------------------------------------------------
$mfr   = ''
$model = ''
try{
  $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
  $mfr   = [string]$cs.Manufacturer
  $model = [string]$cs.Model
}catch{
  Write-YcLog ('could not read Win32_ComputerSystem: ' + $_.Exception.Message) 'WARN'
}
Write-YcLog ('platform: Manufacturer="' + $mfr + '" Model="' + $model + '"')
$isVMware = ($mfr -match 'VMware') -or ($model -match 'VMware')
if(-not $isVMware){
  $what = 'an unrecognised platform'
  if($mfr -match 'QEMU' -or $model -match 'KVM' -or $model -match 'Standard PC'){ $what = 'a KVM/QEMU guest' }
  elseif($mfr -match 'Microsoft' -and $model -match 'Virtual Machine'){ $what = 'a Hyper-V guest' }
  elseif($mfr -match 'Xen'){ $what = 'a Xen guest' }
  if($Force){
    Write-YcLog ('-Force: this host reports ' + $what + ' (Manufacturer "' + $mfr + '"), NOT VMware. Installing anyway because -Force was given. PVSCSI/VMXNET3/SVGA cannot bind here and the guest service will have no host to talk to.') 'WARN'
  }else{
    Exit-Yc 12 ('REFUSED: this host is ' + $what + ' (Manufacturer "' + $mfr + '", Model "' + $model + '"), not a VMware guest. VMware Tools installs unbindable storage and network filter drivers here and leaves a permanently failed VMTools service, for the price of a reboot. On KVM install virtio-win instead. Nothing was installed. Use -Force only on a genuine VMware host that misreports its manufacturer.') 'ERROR'
  }
}

# ------------------------------------------------------------------------------------
# 2. Idempotency.
# ------------------------------------------------------------------------------------
$existing = Get-Service -Name 'VMTools' -ErrorAction SilentlyContinue
if($existing -and -not $Drivers){
  if($existing.Status -eq 'Running'){
    $v = ''
    try{ $v = [string](Get-ItemProperty -Path 'HKLM:\SOFTWARE\VMware, Inc.\VMware Tools' -Name 'Version' -ErrorAction SilentlyContinue).Version }catch{}
    Exit-Yc 0 ('VMware Tools is already installed and the VMTools service is Running' + $(if($v){' (version ' + $v + ')'}else{''}) + ' - nothing to do.') 'OK'
  }
  Write-YcLog 'the VMTools service exists but is not Running - starting it before deciding to reinstall' 'WARN'
  if(Assert-YcService -Name 'VMTools' -TimeoutSec 60 -StartIfStopped -Because 'VMware Tools appears to be installed already'){
    Exit-Yc 0 'VMware Tools was already installed; the VMTools service was stopped and has been started. No reinstall was needed.' 'OK'
  }
  Write-YcLog 'the VMTools service exists but will not start - reinstalling over the top' 'WARN'
}

# ------------------------------------------------------------------------------------
# 3. Locate the installer (explicit, staged, or downloaded).
# ------------------------------------------------------------------------------------
$exe = ''
if($InstallerPath){
  $exe = $InstallerPath
}else{
  $staged = 'C:\Scripts\VMware-Tools-x64.exe'
  $ok = $false
  if(Test-Path -LiteralPath $staged){
    $len = 0
    try{ $len = (Get-Item -LiteralPath $staged).Length }catch{}
    if($len -ge 50MB){ $ok = $true }
    else{ Write-YcLog ('staged installer ' + $staged + ' is only ' + $len + ' bytes - discarding it and downloading again') 'WARN' }
  }
  if($ok){
    $exe = $staged
  }else{
    if(-not $Url){ Exit-Yc 4 'no staged installer and no -Url to download from. Nothing was installed.' 'ERROR' }
    Assert-YcPrereqs -NeedInternet
    $got = Get-YcFile -Uri $Url -OutFile $staged -Sha256 $Sha256 -MinBytes 50MB -Retries 4 -TimeoutSec 1800
    if(-not $got){ Exit-Yc 9 ('could not download the VMware Tools installer from ' + $Url + '. Nothing was installed.') 'ERROR' }
    $exe = $got
  }
}
if(-not (Assert-YcFile -Path $exe -MinBytes 50MB -Because 'VMware Tools bootstrapper')){
  Exit-Yc 4 ('unusable VMware Tools installer: ' + $exe) 'ERROR'
}
$sig = 'Unavailable'
try{ $sig = [string](Get-AuthenticodeSignature -LiteralPath $exe -ErrorAction Stop).Status }catch{ $sig = 'Unavailable' }
if($sig -eq 'Valid'){ Write-YcLog ('installer Authenticode signature: Valid (' + (Split-Path -Leaf $exe) + ')') 'OK' }
else{ Write-YcLog ('installer Authenticode signature is ' + $sig + ' for ' + $exe + ' - continuing, but this package is not proven to be the vendor build') 'WARN' }

# ------------------------------------------------------------------------------------
# 4. Visual C++ redistributables (best effort, never fatal, never silent).
# ------------------------------------------------------------------------------------
if(-not $SkipVcRedist){
  foreach($arch in @('x64','x86')){
    $vp = 'C:\Scripts\vc_redist.' + $arch + '.exe'
    $have = $false
    if(Test-Path -LiteralPath $vp){
      $l = 0
      try{ $l = (Get-Item -LiteralPath $vp).Length }catch{}
      if($l -ge 1MB){ $have = $true }
    }
    if(-not $have){
      if(Test-YcInternet){
        $g = Get-YcFile -Uri ('https://aka.ms/vs/17/release/vc_redist.' + $arch + '.exe') -OutFile $vp -MinBytes 1MB -Retries 2 -TimeoutSec 300
        if($g){ $have = $true }
      }else{
        Write-YcLog ('no internet - skipping vc_redist.' + $arch) 'WARN'
      }
    }
    if($have){
      $r = Invoke-YcInstaller -FilePath $vp -ArgumentList @('/install','/quiet','/norestart') -SuccessCodes @(0,1638) -RebootCodes @(3010,1641) -TimeoutSec 900
      if(-not $r.Success -and $r.ExitCode -ne 1638){
        Write-YcLog ('vc_redist.' + $arch + ' returned ' + $r.ExitCode + ' (' + $r.Meaning + ') - continuing; VMware Tools 12.x ships its own runtime') 'WARN'
      }
    }
  }
}

# ------------------------------------------------------------------------------------
# 5. Install. THE COMMAND LINE IS THE WHOLE DEFECT: /v takes its payload with NO space.
#    One array element so Start-Process passes the string through verbatim.
# ------------------------------------------------------------------------------------
$components = 'PVSCSI,VMXNet3,SVGA,MemCtl,Mouse,VMCI,Sync'
$argLine = '/S /v"/qn REBOOT=R"'
if($Drivers){ $argLine = '/S /v"/qn REBOOT=R ADDLOCAL=' + $components + '"' }
Write-YcLog ('installer command line: ' + (Split-Path -Leaf $exe) + ' ' + $argLine)

# -MinSeconds 10: a VMware Tools install never completes in ten seconds. An "instant success"
# is the signature of a bootstrapper that rejected its command line and did nothing - which
# is exactly what the old '/S /v "/qn REBOOT=R"' spacing produced.
$inst = Invoke-YcInstaller -FilePath $exe -ArgumentList @($argLine) -SuccessCodes @(0) -RebootCodes @(3010,1641) -TimeoutSec $TimeoutSec -MinSeconds 10
if($inst.TimedOut){
  Exit-Yc 10 ('the VMware Tools installer did not exit within ' + $TimeoutSec + 's and was killed. Under SYSTEM in session 0 this is the signature of a NON-SILENT install waiting on an invisible dialog - check that the /v payload has no space before it.') 'ERROR'
}
if(-not $inst.Success){
  $code = $inst.ExitCode
  if($code -eq 0){ $code = 1 }
  Exit-Yc $code ('VMware Tools install FAILED: exit ' + $inst.ExitCode + ' - ' + $inst.Meaning + '. Nothing is proven installed.') 'ERROR'
}
if($inst.RebootRequired){
  Write-YcLog ('the installer returned ' + $inst.ExitCode + ': a REBOOT is required to complete VMware Tools. REBOOT=R suppressed the prompt; schedule the reboot.') 'WARN'
}

# ------------------------------------------------------------------------------------
# 6. PROOF.
# ------------------------------------------------------------------------------------
$version = ''
foreach($k in @('HKLM:\SOFTWARE\VMware, Inc.\VMware Tools','HKLM:\SOFTWARE\WOW6432Node\VMware, Inc.\VMware Tools')){
  if($version){ break }
  try{
    $p = Get-ItemProperty -Path $k -ErrorAction SilentlyContinue
    if($p -and $p.Version){ $version = [string]$p.Version }
  }catch{}
}

if($Drivers){
  $drv = @()
  foreach($d in @('pvscsi','vmxnet3','vmci','vmmemctl','vmmouse','vsock')){
    if(Get-Service -Name $d -ErrorAction SilentlyContinue){ $drv += $d }
  }
  if($drv.Count -eq 0){
    Exit-Yc 7 ('the drivers-only install returned ' + $inst.ExitCode + ' but NO VMware driver service (pvscsi/vmxnet3/vmci/vmmemctl/vmmouse/vsock) exists on this host. Nothing usable was installed.') 'ERROR'
  }
  Exit-Yc 0 ('VMware Tools drivers installed (' + ($drv -join ', ') + ')' + $(if($version){' - Tools version ' + $version}else{''}) + $(if($inst.RebootRequired){'; a reboot is required'}else{''}) + '.') 'OK'
}

if(-not (Assert-YcService -Name 'VMTools' -TimeoutSec 180 -StartIfStopped -Because 'the VMware Tools guest service is the whole point of the package')){
  Exit-Yc 7 ('the installer returned ' + $inst.ExitCode + ' but the VMTools service is missing or will not run. VMware Tools is NOT working on this host.') 'ERROR'
}
Exit-Yc 0 ('VMware Tools installed and the VMTools service is Running' + $(if($version){' (version ' + $version + ')'}else{''}) + $(if($inst.RebootRequired){'; a reboot is required to complete'}else{''}) + '.') 'OK'
