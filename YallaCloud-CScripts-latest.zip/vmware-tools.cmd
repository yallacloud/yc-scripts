@echo off
rem vmware-tools [-Drivers] [-InstallerPath <exe>] [-Url <url>] [-Sha256 <hash>]
rem              [-TimeoutSec 1800] [-SkipVcRedist] [-Force] [-Help]
rem
rem SILENT install of VMware Tools. The MSI payload is passed as /S /v"/qn REBOOT=R" with NO
rem space after /v - with the space this installer is NOT silent and blocks forever in
rem session 0 under SYSTEM.
rem
rem THIS COMMAND REFUSES TO RUN ON A NON-VMWARE GUEST (exit 12). YallaCloud is CloudStack on
rem KVM: PVSCSI/VMXNET3/SVGA can never bind on a KVM guest. Install virtio-win there instead.
rem Success means the VMTools service is Running, not merely that the installer exited.
rem Logs to C:\Scripts\vmware-tools.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Install-VMwareTools.ps1" %*
exit /b %ERRORLEVEL%
