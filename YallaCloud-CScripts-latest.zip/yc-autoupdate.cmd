@echo off
setlocal
rem yc-autoupdate - keep C:\Scripts current from the public yc-scripts repo.
rem   yc-autoupdate            check now
rem   yc-autoupdate -Install    register the scheduled task
rem   yc-autoupdate -Help
rem Disable entirely by creating C:\Scripts\.no-auto-update
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Yc-AutoUpdate.ps1" %*
exit /b %ERRORLEVEL%
