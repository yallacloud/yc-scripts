param(
  [ValidateSet('2016','2017','2019','2022','2025')]
  [string]$Version,
  # Widened from ValidateSet('Evaluation') on 2026-09-01. The binder used to reject anything else
  # with "does not belong to the set", exit 1 and no guidance - technically safe, but it told an
  # operator asking for Express or Standard nothing about what to do instead. The values are
  # accepted here and refused in the body, with the actual next command and exit 2.
  [ValidateSet('Evaluation','Express','Standard','Enterprise','Web','Developer')]
  [string]$Edition = 'Evaluation',
  [string]$InstanceName = 'MSSQLSERVER',
  [string]$Features,
  [string]$DataDir = 'C:\SQLData',
  [string]$BackupDir = 'C:\dbbackupdaily',
  [string]$SaPassword,
  [string]$SaPasswordFile,
  [string]$ChadminPassword,
  [ValidateSet('on','off')]
  [string]$Maintenance = 'on',
  [string]$IsoPath,
  [string]$WorkDir = 'C:\Scripts\sql-media',
  [string]$Collation = 'SQL_Latin1_General_CP1_CI_AS',
  [string[]]$SysadminAccounts,
  [int]$Port = 1433,
  [string[]]$ManagementCidr = @('LocalSubnet'),
  [ValidateSet('on','off')]
  [string]$Firewall = 'on',
  [ValidateSet('on','off')]
  [string]$ClientTools = 'on',
  [ValidateSet('on','off')]
  [string]$Ssms = 'on',
  [ValidateSet('auto','22','21','20')]
  [string]$SsmsVersion = 'auto',
  [ValidateSet('on','off')]
  [string]$Patch = 'on',
  [string]$CuPath,
  [int]$MaxDop = 0,
  [int]$MaxServerMemoryMB = 0,
  [int]$CostThreshold = 50,
  [int]$TempDbFileCount = 0,
  [int]$TempDbFileSizeMB = 0,
  [ValidateSet('on','off')]
  [string]$InstantFileInit = 'on',
  [ValidateSet('on','off')]
  [string]$LockPagesInMemory = 'off',
  [ValidateSet('on','off')]
  [string]$PowerPlan = 'on',
  [string]$OlaZipPath,
  [int]$LogBackupMinutes = 15,
  # Rebooting when a reboot is genuinely required is the DEFAULT, because the run now resumes
  # itself afterwards and "install it, but stop dead at the first reboot" is not a useful default
  # for a first-boot deployment. -NoReboot is the brake for a change window where somebody wants to
  # restart the box by hand. -AllowReboot is still accepted so existing userdata and runbooks keep
  # working; it is now a no-op, because it describes what already happens.
  [Alias('ManualReboot')]
  [switch]$NoReboot,
  [switch]$AllowReboot,
  [switch]$KeepMedia,
  [switch]$Force,
  [switch]$Unattended,
  [switch]$Help
)
# ================================================================================================
# Install-Sql.ps1 - YALLACLOUD day-2 command: unattended SQL Server EVALUATION install, patch,
# client tooling (SSMS / sqlcmd / ODBC / OLE DB / SqlServer module), instance configuration, and
# verified Ola Hallengren backups. PowerShell 5.1 only, ASCII only, Windows Server 2016-2025.
#
# WHAT CHANGED IN THIS REWRITE, AND WHY
# -------------------------------------
# P0-6  The flagship command could not complete with its own defaults on its only supported version.
#       -Features defaulted to 'SQLENGINE,REPLICATION,FULLTEXT,CONN,BC,SDK'. Conn, BC, SDK, SNAC_SDK,
#       DREPLAY_CTLR and DREPLAY_CLT are all documented "Applies to: SQL Server 2019 and earlier
#       versions" and SQL 2022/2025 setup rejects them, so `install-sql -Version 2022` (the first
#       example in its own -Help) failed feature validation and exited non-zero AFTER a 1.2 GB
#       download and an ISO mount. FIXED: -Features now has no static default; PHASE 1 picks a
#       version-correct default and hard-rejects legacy/unknown tokens BEFORE anything is downloaded.
#       Secondary consequence, also fixed: Conn is what used to install sqlcmd.exe. On 2022/2025
#       setup installs no sqlcmd at all, Get-YcSqlCmdExe degraded to the bare string 'sqlcmd.exe',
#       and every verification step plus every nightly maintenance task was broken by construction.
#       PHASE 7 now installs the ODBC driver, the OLE DB driver and the standalone Microsoft command
#       line utilities, and the run hard-fails if sqlcmd still cannot be resolved to a real path.
#
# P0-5  SQL Server shipped with no backups and the tooling reported success. $maintOk was set and
#       never read; the script logged "install-sql complete." at OK and exited 0 even when the Ola
#       Hallengren procedures had never been created, having already registered three scheduled
#       tasks that call EXEC dbo.DatabaseBackup against procedures that do not exist. FIXED: PHASE
#       11 verifies the four procedures actually exist in DBA with a live query and refuses to
#       register any scheduled task for a procedure that is not there; PHASE 13 proves the instance
#       works (connect, SELECT @@VERSION, four procedures, tasks present, a real backup that
#       actually succeeds and leaves a file on disk); every failure increments $script:YcFail and
#       the process exits non-zero.
#
# Also new in this rewrite:
#   - PHASE 1 preflight gate placed before any download: SQL/Windows support matrix, answer-file
#     template existence, FEATURES validation, chadmin existence, .NET Framework baseline, free
#     disk, pending-reboot detection, existing-instance detection (idempotency).
#   - PHASE 2 installs the prerequisites the old script only assumed: .NET Framework, the dbatools
#     module ("the dbaas package"), the SqlServer module, the High performance power plan, the
#     Perform volume maintenance tasks right and optionally Lock pages in memory.
#   - PHASE 3 validates media before mounting (real file, plausible size, not an HTML error page).
#   - PHASE 5 uses documented raw setup.exe /ConfigurationFile= as the primary path and treats 0 and
#     3010 as success, surfacing 3010 loudly instead of swallowing it.
#   - PHASE 6 patches to the current CU (UpdateSource=MU during setup, or a staged CU package) and,
#     when it cannot patch, says plainly that the build is unpatched and how far behind it is.
#   - PHASE 9 enables TCP/IP through the documented SMO WMI ManagedComputer object, sets the port,
#     manages SQL Browser for named instances, and scopes the firewall rule to a management CIDR.
#     A database port is never opened to Any.
#   - Secrets: the SA password is never placed on any command line, in any batch file, in the
#     transcript or in the event log. It is written into the generated answer file, which lives in a
#     directory ACLed to SYSTEM + Administrators only and is deleted on every exit path.
#   - Every exit path goes through Invoke-YcExit, which dismounts the ISO, shreds the answer file
#     and calls Stop-YcLog with the real code. No -EA SilentlyContinue on load-bearing operations.
#
# EVALUATION ONLY: no product key / PID is ever written to the generated answer file or passed on
# any command line. A customer who buys a licence runs the existing 'activate-sql' command.
# ================================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'install-sql'
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# ------------------------------------------------------------------------------------------------
# Run state used by the single exit path
# ------------------------------------------------------------------------------------------------
$script:YcFail          = 0        # count of failed stages; becomes the exit code family
$script:YcExitCode      = 0
$script:YcIsoFile       = $null
$script:YcIsoMounted    = $false
$script:YcGenIni        = $null
$script:YcRebootNeeded  = $false
$script:YcStopped       = $false
$script:YcPhase         = 0
$script:NetFxMarker     = 'C:\Scripts\install-sql.netfx-restart-pending'
$script:RunningAsSystem = $false
try { $script:RunningAsSystem = ([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -eq 'S-1-5-18') } catch { }
$script:SqlCmd          = $null
$script:SqlHost         = $null
$script:Summary         = New-Object System.Collections.Generic.List[string]

function Add-YcSummary { param([string]$Key,[string]$Value) [void]$script:Summary.Add(($Key.PadRight(22) + ': ' + $Value)) }

function Write-YcPhase {
  param([int]$Number,[string]$Title)
  $script:YcPhase = $Number
  Write-YcLog ('=============== PHASE ' + $Number + ' - ' + $Title + ' ===============')
}

function Remove-YcAnswerFile {
  if ($script:YcGenIni -and (Test-Path -LiteralPath $script:YcGenIni)) {
    try {
      # The answer file can contain SAPWD. Overwrite the bytes before unlinking so the plaintext is
      # not simply left in a freed cluster on a disk image that gets cloned into a golden template.
      $len = (Get-Item -LiteralPath $script:YcGenIni).Length
      if ($len -gt 0) {
        $pad = New-Object byte[] $len
        [System.IO.File]::WriteAllBytes($script:YcGenIni, $pad)
      }
      Remove-Item -LiteralPath $script:YcGenIni -Force
      Write-YcLog ('Generated answer file shredded and removed: ' + $script:YcGenIni)
    } catch {
      Write-YcLog ('Could not remove the generated answer file ' + $script:YcGenIni + ': ' + $_.Exception.Message) 'WARN'
    }
  }
}

function Invoke-YcExit {
  param([int]$Code)
  # Re-entrancy guard only: this branch is reachable solely after Stop-YcLog has already run for
  # this process, so it is not an exit path that skips Stop-YcLog.
  if ($script:YcStopped) { exit $Code }
  $script:YcStopped = $true
  Remove-YcAnswerFile
  if ($script:YcIsoMounted -and $script:YcIsoFile) {
    try {
      Dismount-DiskImage -ImagePath $script:YcIsoFile | Out-Null
      Write-YcLog ('ISO dismounted: ' + $script:YcIsoFile)
    } catch {
      Write-YcLog ('Could not dismount the ISO ' + $script:YcIsoFile + ': ' + $_.Exception.Message) 'WARN'
    }
  }
  if ($script:Summary.Count -gt 0) {
    Write-Host ''
    Write-Host '=== install-sql summary ===' -ForegroundColor Cyan
    foreach ($s in $script:Summary) { Write-Host ('  ' + $s) }
    Write-Host ''
  }
  if ($Code -eq 0) { Write-YcLog ('install-sql complete (exit 0).') 'OK' }
  else             { Write-YcLog ('install-sql FAILED (exit ' + $Code + ') - see the PHASE lines above for where it stopped.') 'ERROR' }
  Stop-YcLog $Code
  exit $Code
}

# A script-scope trap so an unhandled terminating error still closes the transcript, writes an [END]
# line and returns a real exit code. Without it the log just stops mid-sentence, which is
# indistinguishable from the VM being rebooted.
trap {
  Write-YcLog ('UNHANDLED ERROR in PHASE ' + $script:YcPhase + ' at line ' + $_.InvocationInfo.ScriptLineNumber + ': ' + $_.Exception.Message) 'ERROR'
  if ($_.ScriptStackTrace) { Write-YcLog ('Stack: ' + ($_.ScriptStackTrace -replace "`r?`n", ' | ')) 'ERROR' }
  Invoke-YcExit 99
}

# ------------------------------------------------------------------------------------------------
# -Help
# ------------------------------------------------------------------------------------------------
if ($Help) {
@"
install-sql  -  unattended install of SQL Server EVALUATION edition (2016-2025) plus everything it
                actually needs: prerequisites BEFORE the engine, the correct FEATURES for the
                version, the current cumulative update, SSMS / sqlcmd / ODBC / OLE DB / SqlServer
                module AFTER the engine, instance tuning, a scoped firewall rule, and VERIFIED Ola
                Hallengren backups. No product key is ever used.

QUICK START - the line L1 needs 95% of the time:
  install-sql -Version 2022
        Evaluation edition, sane defaults, verified backups. No product key. ~25 min.
        Everything below is optional tuning.

USAGE:
  install-sql -Version <2016|2017|2019|2022|2025> [switches]     (unattended - no prompts)
  install-sql                                                    (bare, real console only - prompts)
  install-sql -Help

PARAMETERS:
  -Version           SQL Server version: 2016, 2017, 2019, 2022 or 2025. Required unattended.
  -Edition           Fixed to Evaluation (only supported value - no PID / product key path exists).
  -InstanceName      Instance name. Default MSSQLSERVER (default instance).
  -Features          Comma list of setup FEATURES tokens. NO LONGER DEFAULTS TO A FIXED STRING.
                     Omitted => SQLENGINE,REPLICATION,FULLTEXT,CONN,BC,SDK on 2016/2017/2019 and
                     SQLENGINE,REPLICATION,FULLTEXT on 2022/2025, because Conn, BC, SDK, SNAC_SDK,
                     DREPLAY_CTLR and DREPLAY_CLT are documented "SQL Server 2019 and earlier" and
                     are rejected by 2022+ setup. Supplying them on 2022/2025 is refused in PHASE 1,
                     before any download.
  -DataDir           Root for Data/Log/TempDB subfolders. Default C:\SQLData.
  -BackupDir         Backup destination. Default C:\dbbackupdaily. Warned about on the system drive.
  -SaPassword        If given, Mixed Mode is enabled and sa gets this password. INSECURE ON A COMMAND
                     LINE - any local user can read it from the process table. Prefer -SaPasswordFile.
                     Never appears in the log, the transcript, the event log or a child process
                     argument list: it is written into the answer file, which is ACLed to SYSTEM +
                     Administrators and shredded on every exit path.
  -SaPasswordFile    Path to a file whose first line is the sa password. Preferred over -SaPassword.
                     The file is read then left alone; ACL it yourself and delete it when done.
  -ChadminPassword   FALLBACK only: the scheduled tasks try passwordless S4U logon first. If S4U is
                     blocked by policy on the image, supplying this lets Task Scheduler store a
                     credential instead. Without it, a blocked S4U logs an ERROR and fails the run
                     rather than silently running the backups as somebody else.
  -Maintenance       on|off. Default on. 'on' installs the Ola Hallengren procedures AND schedules
                     FULL / DIFF / LOG / integrity / index / restore-verify tasks. 'off' installs the
                     procedures and schedules nothing. Either way the procedures are VERIFIED to
                     exist and the run exits non-zero if they do not.
  -IsoPath           Path to an already-present SQL Server ISO - skips the download entirely.
  -WorkDir           Download/staging directory. Default C:\Scripts\sql-media.
  -Collation         Server collation. Default SQL_Latin1_General_CP1_CI_AS. Cannot be changed later
                     without a reinstall, so it is validated before setup runs.
  -SysadminAccounts  Explicit SQLSYSADMINACCOUNTS list. Omitted => chadmin + the local Administrators
                     group + the identity running this script. On a domain-joined VM the group form
                     can include DOMAIN\Domain Admins - the resolved list is always logged.
  -Port              Static TCP port for the instance. Default 1433.
  -ManagementCidr    One or more remote scopes for the inbound firewall rule. Default LocalSubnet.
                     'Any', 0.0.0.0/0 and ::/0 are REFUSED - a database port is never world-open.
  -Firewall          on|off. Default on.
  -ClientTools       on|off. Default on. ODBC Driver 18, OLE DB Driver 19, the Microsoft command
                     line utilities (sqlcmd/bcp) and the SqlServer PowerShell module. Mandatory in
                     practice on 2022/2025, where setup no longer ships sqlcmd.
  -Ssms              on|off. Default on. SQL Server Management Studio.
  -SsmsVersion       auto|22|21|20. Default auto: SSMS 22 on Windows Server 2019 or later, SSMS 20
                     on Windows Server 2016 (SSMS 21/22 do not support Windows Server 2016).
  -Patch             on|off. Default on. Sets UpdateEnabled/UpdateSource=MU so setup slipstreams the
                     current CU. With -CuPath the staged package is applied after setup instead.
                     Either way the resulting build is reported against the current CU.
  -CuPath            Path to a staged cumulative update package (SQLServer<ver>-KB<n>-x64.exe).
  -MaxDop            max degree of parallelism. 0 (default) = computed from the logical CPU count.
  -MaxServerMemoryMB max server memory in MB. 0 (default) = computed from installed RAM.
  -CostThreshold     cost threshold for parallelism. Default 50.
  -TempDbFileCount   tempdb data file count. 0 (default) = min(8, logical CPUs), per the documented
                     setup default.
  -TempDbFileSizeMB  tempdb data file initial size in MB. 0 (default) = computed (max 1024, the
                     documented setup maximum).
  -InstantFileInit   on|off. Default on. Grants Perform volume maintenance tasks (SE_MANAGE_VOLUME_NAME)
                     to the Database Engine service SID via setup's own SQLSVCINSTANTFILEINIT.
  -LockPagesInMemory on|off. Default off. Grants Lock pages in memory to the Database Engine service
                     SID. Off by default because it is only appropriate on a memory-pinned VM.
  -PowerPlan         on|off. Default on. Selects the High performance power plan.
  -OlaZipPath        Staged Ola Hallengren zip, passed to dbatools -LocalFile so the maintenance
                     solution installs on an egress-restricted VM instead of reaching GitHub.
  -LogBackupMinutes  Transaction-log backup interval in minutes. Default 15. 0 disables log backups
                     (only sane if every database is in SIMPLE recovery).
  -NoReboot          Never restart the machine. Where a reboot is genuinely required the run STOPS
                     and says so, and C:\Scripts\install-sql.reboot-required records it. Use this
                     in a change window where somebody wants to restart the box by hand.
                     Also accepted as -ManualReboot.
                     WITHOUT it (the default) the run reboots when it must and then RESUMES ITSELF
                     via a SYSTEM startup task, so a first-boot deployment finishes on its own.
                     The resume is skipped, with a WARN, if -SaPassword or -ChadminPassword was
                     passed in plaintext, because the task definition would persist the password -
                     use -SaPasswordFile for that.
  -AllowReboot       Accepted for compatibility. It is now the default and changes nothing.
  -KeepMedia         Keep the downloaded ISO in -WorkDir instead of deleting it after a good install.
  -Force             Re-run setup even when an instance of this name already exists. Without it, an
                     existing instance takes the configure-only path (client tools, tuning, network,
                     maintenance, verification) and setup is never re-run.
  -Unattended        Accepted for compatibility. Supplying ANY parameter already suppresses the
                     prompts, so this is only meaningful on a bare `install-sql` with no arguments.
  -Help              Show this help and exit.

BEHAVIOUR:
  - Bare invocation prompts only on a real interactive console. Under a scheduled task, an RMM or
    SYSTEM it runs unattended instead of blocking forever on Read-Host.
  - PHASE 1 refuses unsupported SQL/Windows combinations, missing answer-file templates, invalid
    FEATURES tokens, a missing chadmin account, an insufficient .NET Framework, insufficient free
    disk and a pending reboot - all BEFORE downloading 1.2-3 GB of media.
  - Media is verified by byte size and by a Microsoft-published checksum, and is validated as a real
    file (not an HTML error page) before it is mounted.
  - Setup runs from the version-correct template. A missing template is a hard failure; there is no
    silent fall back to the 2022 template.
  - Setup exit codes 0 and 3010 are success; 3010 leaves C:\Scripts\install-sql.reboot-required and
    a loud WARN, and reboots unless -NoReboot was given.
  - Nothing is reported as done on faith. The engine, the client tools, the network configuration,
    the four maintenance procedures, the scheduled tasks and a real test backup are each proved.

THE ONLY COMMAND MOST PEOPLE NEED:

  install-sql -Version 2019

  That is the whole thing. It installs the engine, patches, client tools, SSMS, the firewall rule,
  the tuning, the backups and the scheduled tasks; it reboots if it has to and carries on by itself
  afterwards; and it exits non-zero if ANY of that could not be proved. Everything below is an
  override for a case where the defaults are wrong - if you do not know that you need one, you
  do not need one.

  Second command, for a change window where YOU want to do the restart:

  install-sql -Version 2019 -NoReboot

MORE EXAMPLES:
  install-sql -Version 2022
  install-sql -Version 2022 -InstanceName SQL2022 -Port 1435 -ManagementCidr 10.20.0.0/16
  install-sql -Version 2019 -SaPasswordFile C:\Scripts\sa.txt -BackupDir D:\dbbackupdaily
  install-sql -Version 2022 -Maintenance off -Ssms off -ClientTools on
  install-sql -Version 2016 -IsoPath C:\Staging\SQLServer2016SP3-FullSlipstream-x64-ENU.iso
  install-sql -Version 2022 -CuPath C:\Staging\SQLServer2022-KB5093420-x64.exe
  install-sql -Version 2019 -ChadminPassword "ChadminActualPw!"   (only if S4U is blocked)
  install-sql                                     (interactive prompts, real console only)

EXIT CODES:
   0  Success. Everything installed and every verification passed.
   1  Unhandled or generic failure (see the last PHASE line in the log).
   2  Preflight refused the run: unsupported SQL/Windows combination, missing answer-file template,
      invalid FEATURES token for this version, missing chadmin, .NET/disk/pending-reboot gate.
   3  Media could not be acquired, verified or mounted.
   4  SQL Server setup failed (exit code other than 0 or 3010).
   5  Not running as Administrator (from _yc-lib.ps1 Assert-YcPrereqs).
   6  No outbound internet where it is required (from _yc-lib.ps1 Assert-YcPrereqs).
   7  Client tooling failed: sqlcmd could not be resolved to a real executable after PHASE 7.
   8  Engine verification failed: service not running, no answer to a live query, or chadmin is not
      sysadmin.
   9  Maintenance failed: the four Ola Hallengren procedures do not exist in DBA. NO scheduled task
      is registered in this case - the run never pretends backups are configured.
  10  Final verification failed: a scheduled task is missing, or the test backup did not succeed.
  99  Unhandled terminating error (the log always ends with an [END] line either way).

Log: C:\Scripts\install-sql.log   (also mirrored to the Application event log, source YallaCloud)
Reboot marker, when setup asked for one: C:\Scripts\install-sql.reboot-required
"@ | Write-Host -ForegroundColor Cyan
  Stop-YcLog 0
  exit 0
}

Assert-YcPrereqs -NeedAdmin

# ================================================================================================
# Helper functions
# ================================================================================================

function Get-YcServiceOrNull {
  param([string]$Name)
  try { return (Get-Service -Name $Name) } catch { return $null }
}

function Test-YcLocalAccountExists {
  param([string]$Name)
  try {
    $u = [ADSI]("WinNT://./" + $Name + ",user")
    $null = $u.Name
    return $true
  } catch { return $false }
}

# Get-YcRegValueOrNull and Get-YcPendingRebootReasons now live in _yc-lib.ps1, dot-sourced at
# the top of this script, so activate-sql can use the same pending-reboot check.

# HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full Release DWORD, per the documented table.
function Get-YcNetFxRelease {
  $v = Get-YcRegValueOrNull -Path 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name 'Release'
  if ($null -eq $v) { return 0 }
  return [int]$v
}

function Get-YcNetFxName {
  param([int]$Release)
  if ($Release -ge 533320) { return '4.8.1' }
  if ($Release -ge 528040) { return '4.8' }
  if ($Release -ge 461808) { return '4.7.2' }
  if ($Release -ge 460798) { return '4.7' }
  if ($Release -ge 394802) { return '4.6.2' }
  if ($Release -ge 393295) { return '4.6' }
  if ($Release -gt 0)      { return ('older than 4.6 (Release=' + $Release + ')') }
  return 'not detected'
}

function Get-YcFreeSpaceGB {
  param([string]$PathOrDrive)
  $root = [System.IO.Path]::GetPathRoot($PathOrDrive)
  if (-not $root) { $root = $env:SystemDrive + '\' }
  $ld = Get-CimInstance -ClassName Win32_LogicalDisk -Filter ("DeviceID='" + $root.TrimEnd('\') + "'")
  if (-not $ld) { return -1 }
  return [Math]::Round($ld.FreeSpace / 1GB, 2)
}

# Native-command wrapper. Local $ErrorActionPreference so stderr from a native exe does not throw
# under the script-wide 'Stop' preference, while the exit code is still checked by the caller.
function Invoke-YcNative {
  param([string]$FilePath,[string[]]$Arguments)
  $ErrorActionPreference = 'Continue'
  $out = & $FilePath @Arguments 2>&1
  $rc  = $LASTEXITCODE
  return [PSCustomObject]@{ ExitCode = $rc; Output = ($out | ForEach-Object { [string]$_ }) }
}

function Get-YcSqlCmdExe {
  # Never degrade to a bare 'sqlcmd.exe'. A bare name is not reliably on the machine PATH, and it
  # used to get baked into three scheduled task actions that then failed every night.
  $roots = @(
    'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\*\Tools\Binn\SQLCMD.EXE',
    'C:\Program Files (x86)\Microsoft SQL Server\Client SDK\ODBC\*\Tools\Binn\SQLCMD.EXE',
    'C:\Program Files\Microsoft SQL Server\*\Tools\Binn\SQLCMD.EXE',
    'C:\Program Files\sqlcmd\sqlcmd.exe'
  )
  foreach ($r in $roots) {
    try {
      $f = Get-ChildItem -Path $r | Sort-Object FullName -Descending | Select-Object -First 1
      if ($f) { return $f.FullName }
    } catch { }
  }
  try {
    $c = Get-Command -Name 'sqlcmd.exe' -CommandType Application | Select-Object -First 1
    if ($c) { return $c.Source }
  } catch { }
  return $null
}

# Runs a query through sqlcmd. -b makes sqlcmd exit non-zero on a T-SQL error instead of exiting 0
# with the error text in stdout. No secret ever reaches these arguments.
function Invoke-YcSql {
  param([string]$Query,[string]$InputFile,[string]$Database,[int]$LoginTimeout = 30,[int]$QueryTimeout = 0)
  if (-not $script:SqlCmd) { throw 'sqlcmd has not been resolved yet.' }
  $a = New-Object System.Collections.Generic.List[string]
  [void]$a.Add('-S'); [void]$a.Add($script:SqlHost)
  [void]$a.Add('-E')
  # -C trusts the server certificate. ODBC Driver 18 changed the default to Encrypt=Mandatory
  # (Driver 17 defaulted to no encryption), and a freshly installed instance has only a
  # self-signed certificate, so without -C every query fails with "the certificate chain was
  # issued by an authority that is not trusted". This is the same problem the script already
  # solves for dbatools with sql.connection.trustcert; the sqlcmd path needs it too. The
  # connection is to this machine's own instance, so trusting its self-signed cert is correct.
  [void]$a.Add('-C')
  [void]$a.Add('-b')
  [void]$a.Add('-h'); [void]$a.Add('-1')
  [void]$a.Add('-W')
  [void]$a.Add('-l'); [void]$a.Add([string]$LoginTimeout)
  if ($QueryTimeout -gt 0) { [void]$a.Add('-t'); [void]$a.Add([string]$QueryTimeout) }
  if ($Database) { [void]$a.Add('-d'); [void]$a.Add($Database) }
  if ($InputFile) {
    # -i runs a script file. Used for Ola Hallengren's MaintenanceSolution.sql, which is far too
    # large and too full of quoting to pass through -Q.
    [void]$a.Add('-i'); [void]$a.Add($InputFile)
  } else {
    [void]$a.Add('-Q'); [void]$a.Add($Query)
  }
  $r = Invoke-YcNative -FilePath $script:SqlCmd -Arguments $a.ToArray()
  $text = ($r.Output -join ' ').Trim()
  return [PSCustomObject]@{ Ok = ($r.ExitCode -eq 0); ExitCode = $r.ExitCode; Text = $text }
}

# Is this copy of MaintenanceSolution.sql actually runnable on this engine? Pure, so it is tested.
#
# Ola publishes TWO builds. The current one is headed "SQL Server 2017, 2019, 2022, 2025" and uses
# STRING_AGG, which is a SQL Server 2017 built-in. On SQL Server 2016 it does not fail cleanly - it
# creates SOME of the procedures and throws seventeen "'STRING_AGG' is not a recognized built-in
# function name" errors for DatabaseBackup, leaving 2 of the 4 procedures behind and no backups.
# Observed on C16B 2026-08-29 16:07:17.
#
# I got this wrong once already: I checked the script for a minimum-VERSION REFUSAL, found none,
# and concluded it would run on 2016. There is no refusal - there is 2017-only T-SQL, which is not
# the same thing and does not show up in a grep for version gates. Hence this check, which looks
# for the actual incompatible syntax rather than for a version banner.
function Test-YcOlaCompatible {
  param([string]$Text,[int]$SqlMajor)
  if ($SqlMajor -ge 14) { return '' }
  # Built-ins introduced in SQL Server 2017 (major 14). Any of them makes the script unusable on 2016.
  foreach ($fn in 'STRING_AGG','CONCAT_WS','TRANSLATE','APPROX_COUNT_DISTINCT') {
    if ($Text -match ('\b' + $fn + '\s*\(')) {
      return ($fn + ' is a SQL Server 2017 built-in and this instance is major version ' + $SqlMajor +
              '. This is the 2017+ build of MaintenanceSolution.sql. Use the build Ola publishes for older engines: ' +
              'https://ola.hallengren.com/scripts/sql-server-2008-2016/MaintenanceSolution.sql')
    }
  }
  return ''
}

# Retarget the three settings in the header of Ola Hallengren's MaintenanceSolution.sql.
# Pure (string in, string out) so the regexes can be tested against a real copy of the file -
# they are the only thing standing between "installs into DBA with no SQL Agent jobs" and
# "installs into master and creates a dozen jobs nobody asked for". Every replacement is
# ASSERTED: if Ola changes the header, this returns $null and the caller refuses, rather than
# running a script it could not retarget.
function Set-YcOlaHeader {
  param([string]$Text,[string]$Database,[string]$BackupPath)
  $edits = @(
    @{ Name = 'database context'; Pattern = '(?m)^USE \[master\]';                                        Replace = ('USE [' + $Database + ']') },
    @{ Name = '@CreateJobs';      Pattern = '(?m)^(DECLARE @CreateJobs nvarchar\(max\)\s*=\s*)''Y''';     Replace = '${1}''N''' },
    @{ Name = '@BackupDirectory'; Pattern = '(?m)^(DECLARE @BackupDirectory nvarchar\(max\)\s*=\s*)NULL'; Replace = ('${1}N''' + $BackupPath + '''') }
  )
  foreach ($e in $edits) {
    if ($Text -notmatch $e.Pattern) {
      Write-YcLog ('MaintenanceSolution.sql does not contain the expected ' + $e.Name + ' line. Refusing to run a script this code cannot retarget - it would install into the wrong database or create SQL Agent jobs.') 'ERROR'
      return $null
    }
    $Text = [regex]::Replace($Text, $e.Pattern, $e.Replace)
  }
  return $Text
}

# Install Ola Hallengren's MaintenanceSolution.sql DIRECTLY with sqlcmd, bypassing
# Install-DbaMaintenanceSolution.
#
# WHY THIS EXISTS. dbatools refuses outright:
#     if ($server.Version.Major -lt 14) {
#         Stop-Function -Message "The Maintenance Solution is not supported on SQL Server version ..."
#     }
# so on SQL Server 2016 (major 13) it always fails - observed on x19B 2026-08-29, build 13.0.5026,
# which produced 0 of 4 procedures and exit 9. NO service pack fixes this: the gate is on the major
# version, not the build. (SQL Server 2016 left extended support on 2026-07-14, which is why both
# dbatools and Ola's own header dropped it.) Ola's SQL script itself has NO minimum-version
# refusal - every @Version test in it is a feature gate that degrades - so running the .sql
# directly creates the four procedures on 2016 just as it does on 2019. The PHASE 11 gate that
# counts those four procedures is what actually proves it worked, and that gate is unchanged.
#
# This path is also the fallback when dbatools is unusable for any other reason, so a broken
# dbatools no longer means a SQL Server with no backups.
function Install-YcOlaDirect {
  param([string]$BackupPath,[string]$Database = 'DBA',[string]$ZipPath,[string]$WorkPath,[int]$SqlMajor = 0)
  $sqlFile = Join-Path $WorkPath 'MaintenanceSolution.sql'
  if (-not (Test-Path -LiteralPath $WorkPath)) { New-Item -ItemType Directory -Path $WorkPath -Force | Out-Null }

  if ($ZipPath -and (Test-Path -LiteralPath $ZipPath -PathType Leaf)) {
    try {
      Add-Type -AssemblyName System.IO.Compression.FileSystem
      $zip = [IO.Compression.ZipFile]::OpenRead((Resolve-Path -LiteralPath $ZipPath).Path)
      try {
        $entry = $zip.Entries | Where-Object { $_.Name -eq 'MaintenanceSolution.sql' } | Select-Object -First 1
        if (-not $entry) { Write-YcLog ('MaintenanceSolution.sql is not inside ' + $ZipPath + '.') 'ERROR'; return $false }
        [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $sqlFile, $true)
      } finally { $zip.Dispose() }
      Write-YcLog ('Extracted MaintenanceSolution.sql from the staged ' + $ZipPath + ' (no GitHub call).')
    } catch {
      Write-YcLog ('Could not extract MaintenanceSolution.sql from ' + $ZipPath + ': ' + $_.Exception.Message) 'ERROR'
      return $false
    }
  } else {
    # Ola ships a separate, still-maintained build for older engines. Below major 14 that is the
    # only one that will actually create all four procedures.
    if ($SqlMajor -gt 0 -and $SqlMajor -lt 14) {
      $url = 'https://ola.hallengren.com/scripts/sql-server-2008-2016/MaintenanceSolution.sql'
      Write-YcLog ('This instance is SQL Server major version ' + $SqlMajor + ', so the SQL Server 2008-2016 build of MaintenanceSolution.sql is used - the current build needs STRING_AGG, which is a 2017 built-in.') 'WARN'
    } else {
      $url = 'https://raw.githubusercontent.com/olahallengren/sql-server-maintenance-solution/master/MaintenanceSolution.sql'
    }
    Write-YcLog ('Downloading MaintenanceSolution.sql from ' + $url + ' (stage a zip and pass -OlaZipPath to avoid this).')
    if (-not (Get-YcVerifiedDownload -Url $url -OutFile $sqlFile -ExpectSize $null -ExpectHash $null -Algo $null -MinBytes 200000)) {
      Write-YcLog 'Could not download MaintenanceSolution.sql.' 'ERROR'
      return $false
    }
  }

  $raw = Get-Content -LiteralPath $sqlFile -Raw
  # Refuse BEFORE running it. Half-creating the procedures and then reporting seventeen syntax
  # errors is strictly worse than one sentence saying which file to use.
  $incompat = Test-YcOlaCompatible -Text $raw -SqlMajor $SqlMajor
  if ($incompat) {
    Write-YcLog ('MaintenanceSolution.sql is not compatible with this engine: ' + $incompat) 'ERROR'
    return $false
  }
  $txt = Set-YcOlaHeader -Text $raw -Database $Database -BackupPath $BackupPath
  if (-not $txt) { return $false }
  # UTF8 WITH a BOM: sqlcmd -i uses the BOM to detect the encoding, and Ola's file ships with one.
  [IO.File]::WriteAllText($sqlFile, $txt, (New-Object Text.UTF8Encoding($true)))
  Write-YcLog ('Retargeted MaintenanceSolution.sql: USE [' + $Database + '], @CreateJobs=N, @BackupDirectory=' + $BackupPath + '.')

  # -InstallJobs / @CreateJobs stays off for the same reason as the dbatools path: SQL Agent job
  # steps run as the Agent service account, and the requirement is that maintenance runs as chadmin,
  # which only a Windows scheduled task can do. PHASE 12 does that.
  $r = Invoke-YcSql -InputFile $sqlFile -Database $Database -QueryTimeout 600
  if (-not $r.Ok) {
    Write-YcLog ('sqlcmd -i MaintenanceSolution.sql FAILED (exit ' + $r.ExitCode + '): ' + $r.Text) 'ERROR'
    return $false
  }
  Write-YcLog 'MaintenanceSolution.sql executed without error.' 'OK'
  return $true
}

function Assert-YcSql {
  param([string]$Query,[string]$Database,[string]$What)
  $r = Invoke-YcSql -Query $Query -Database $Database
  if (-not $r.Ok) {
    Write-YcLog ($What + ' FAILED (sqlcmd exit ' + $r.ExitCode + '): ' + $r.Text) 'ERROR'
    return $null
  }
  return $r.Text
}

# Downloads a file and proves it. Returns $true only when size and (when supplied) checksum match.
function Get-YcVerifiedDownload {
  param([string]$Url,[string]$OutFile,[Nullable[int64]]$ExpectSize,[string]$ExpectHash,[string]$Algo,[int]$MinBytes = 0)
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $cl = $null
  try {
    $req = [System.Net.HttpWebRequest]::Create($Url)
    $req.Method = 'HEAD'
    $req.Timeout = 30000
    $req.UserAgent = 'YallaCloud-install-sql'
    $resp = $req.GetResponse()
    $cl = $resp.ContentLength
    $resp.Close()
  } catch {
    Write-YcLog ('HEAD request failed for ' + $Url + ' (' + $_.Exception.Message + ') - continuing without a Content-Length cross-check.') 'WARN'
  }
  # Already on disk and provably the right bytes? Then downloading it again is 2.9 GB of nothing.
  # The reuse decision uses exactly the same evidence the post-download check uses, so a file kept
  # from a previous run is held to the same standard as one fetched a second ago - never to a
  # weaker one just because it happens to exist.
  if (Test-Path -LiteralPath $OutFile -PathType Leaf) {
    Write-YcLog ($OutFile + ' already exists - verifying it instead of downloading again.')
    $verdict = Get-YcFileVerdict -Path $OutFile -ExpectSize $ExpectSize -ExpectHash $ExpectHash -Algo $Algo -MinBytes $MinBytes -ContentLength $cl
    if ($verdict) {
      Write-YcLog ('DOWNLOAD SKIPPED: the existing ' + $OutFile + ' is already correct (' + $verdict + ').') 'OK'
      return $true
    }
    Write-YcLog ('The existing ' + $OutFile + ' could not be proved correct, so it is being downloaded again.') 'WARN'
  }
  Write-YcLog ('Downloading: ' + $Url)
  Write-YcLog ('  -> ' + $OutFile)
  $ok = $false
  try {
    # BITS uses WinHTTP and does not honour ServicePointManager, so on a hardened Server 2016 it can
    # fail against a TLS 1.2-only endpoint where Invoke-WebRequest succeeds. That is why the
    # Invoke-WebRequest fallback below exists and is not optional.
    Import-Module BitsTransfer
    Start-BitsTransfer -Source $Url -Destination $OutFile
    $ok = $true
  } catch {
    Write-YcLog ('BITS transfer failed (' + $_.Exception.Message + '), falling back to Invoke-WebRequest.') 'WARN'
    try {
      Invoke-WebRequest -Uri $Url -OutFile $OutFile -UseBasicParsing -MaximumRedirection 10 -TimeoutSec 3600
      $ok = $true
    } catch {
      Write-YcLog ('Download failed: ' + $_.Exception.Message) 'ERROR'
    }
  }
  if (-not $ok -or -not (Test-Path -LiteralPath $OutFile)) { return $false }
  $actual = (Get-Item -LiteralPath $OutFile).Length
  if ($MinBytes -gt 0 -and $actual -lt $MinBytes) {
    Write-YcLog ('DOWNLOAD VERIFICATION FAILED: ' + $OutFile + ' is only ' + $actual + ' bytes (expected at least ' + $MinBytes + ').') 'ERROR'
    return $false
  }
  if ($cl -and $cl -gt 0 -and $actual -ne $cl) {
    Write-YcLog ('DOWNLOAD VERIFICATION FAILED: got ' + $actual + ' bytes but the server reported Content-Length ' + $cl + ' - truncated or corrupt.') 'ERROR'
    return $false
  }
  if ($ExpectSize -and $ExpectSize -gt 0 -and $actual -ne $ExpectSize) {
    Write-YcLog ('DOWNLOAD VERIFICATION FAILED: got ' + $actual + ' bytes but expected ' + $ExpectSize + '.') 'ERROR'
    return $false
  }
  if ($ExpectHash -and $Algo) {
    $h = (Get-FileHash -Path $OutFile -Algorithm $Algo).Hash
    if ($h -ne $ExpectHash) {
      Write-YcLog ('CHECKSUM VERIFICATION FAILED: got ' + $Algo + '=' + $h + ', expected ' + $ExpectHash) 'ERROR'
      return $false
    }
    Write-YcLog ('Checksum verified (' + $Algo + '): ' + $h) 'OK'
  }
  Write-YcLog ('Download verified: ' + $actual + ' bytes.') 'OK'
  return $true
}

# Is this actually a complete ISO 9660 image, or just a big file with the right name?
# "Big enough and does not start with HTML" was the old bar, and a 2.9 GB truncated download or a
# renamed .zip clears it easily. Three checks, all cheap:
#   1. ISO 9660 volume descriptors live at LBA 16, 17, 18 - byte offsets 0x8001 / 0x8801 / 0x9001 -
#      and each begins with the standard identifier "CD001". At least one must be there.
#   2. An ISO is a whole number of 2048-byte sectors. A truncated transfer almost never is.
#   3. Read the LAST sector. A file that is sparse, still being written, or sitting on a filesystem
#      that lied about its length fails here rather than half way through setup.exe.
# Returns $true only if all three hold.
function Test-YcIsoStructure {
  param([string]$Path)
  $len = (Get-Item -LiteralPath $Path).Length
  # 32769 + 5 is the smallest file that can contain the first volume descriptor. The real size
  # floor for SQL media is the caller's -MinBytes (500 MB); this one only guards the reads below.
  if ($len -lt 32774) {
    Write-YcLog ('ISO VALIDATION FAILED: ' + $Path + ' is ' + $len + ' bytes - too small to contain a volume descriptor at all.') 'ERROR'
    return $false
  }
  if (($len % 2048) -ne 0) {
    Write-YcLog ('ISO VALIDATION FAILED: ' + $Path + ' is ' + $len + ' bytes, which is not a whole number of 2048-byte ISO sectors (' + ($len % 2048) + ' bytes over). The file is truncated or is not an ISO.') 'ERROR'
    return $false
  }
  $fs = $null
  try {
    $fs = [System.IO.File]::OpenRead($Path)
    $buf = New-Object byte[] 5
    $found = @()
    foreach ($off in 32769, 34817, 36865) {
      if ($len -lt ($off + 5)) { continue }
      [void]$fs.Seek($off, [System.IO.SeekOrigin]::Begin)
      $n = $fs.Read($buf, 0, 5)
      if ($n -eq 5 -and [System.Text.Encoding]::ASCII.GetString($buf, 0, 5) -eq 'CD001') { $found += $off }
    }
    if ($found.Count -eq 0) {
      Write-YcLog ('ISO VALIDATION FAILED: ' + $Path + ' has no "CD001" ISO 9660 volume descriptor at offset 32769, 34817 or 36865. This is not an ISO image, whatever its name and size say.') 'ERROR'
      return $false
    }
    # Prove the tail is really there and really readable.
    $tail = New-Object byte[] 2048
    [void]$fs.Seek($len - 2048, [System.IO.SeekOrigin]::Begin)
    $tn = $fs.Read($tail, 0, 2048)
    if ($tn -ne 2048) {
      Write-YcLog ('ISO VALIDATION FAILED: ' + $Path + ' claims ' + $len + ' bytes but the final sector could not be read (' + $tn + ' of 2048 bytes). The file is incomplete.') 'ERROR'
      return $false
    }
    Write-YcLog ('ISO structure verified: ' + $len + ' bytes, ' + ($len / 2048) + ' sectors, CD001 descriptor at offset ' + ($found -join ' and ') + ', final sector readable.') 'OK'
    return $true
  } catch {
    Write-YcLog ('ISO VALIDATION FAILED: could not read ' + $Path + ': ' + $_.Exception.Message) 'ERROR'
    return $false
  } finally {
    if ($fs) { $fs.Close() }
  }
}

# Does a file ALREADY on disk satisfy everything we know about what it should be? Split out of
# Get-YcVerifiedDownload so the same evidence decides both "was the download good" and "can we skip
# the download entirely". Returns a reason string when it passes, $null when it does not.
function Get-YcFileVerdict {
  param([string]$Path,[Nullable[int64]]$ExpectSize,[string]$ExpectHash,[string]$Algo,[int64]$MinBytes = 0,[Nullable[int64]]$ContentLength,[string]$Kind)
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
  $actual = (Get-Item -LiteralPath $Path).Length
  if ($MinBytes -gt 0 -and $actual -lt $MinBytes) {
    Write-YcLog ('  existing ' + $Path + ' is only ' + $actual + ' bytes (floor ' + $MinBytes + ') - not usable.') 'WARN'
    return $null
  }
  if ($ExpectSize -and $ExpectSize -gt 0 -and $actual -ne $ExpectSize) {
    Write-YcLog ('  existing ' + $Path + ' is ' + $actual + ' bytes but ' + $ExpectSize + ' was expected - not usable.') 'WARN'
    return $null
  }
  if ($ContentLength -and $ContentLength -gt 0 -and $actual -ne $ContentLength) {
    Write-YcLog ('  existing ' + $Path + ' is ' + $actual + ' bytes but the server reports ' + $ContentLength + ' - not usable.') 'WARN'
    return $null
  }
  if ($ExpectHash -and $Algo) {
    Write-YcLog ('  hashing the existing ' + $Path + ' (' + $Algo + ', ' + [int]($actual / 1MB) + ' MB) before deciding whether to download it again...')
    $h = (Get-FileHash -Path $Path -Algorithm $Algo).Hash
    if ($h -ne $ExpectHash) {
      Write-YcLog ('  existing ' + $Path + ' has ' + $Algo + '=' + $h + ' but ' + $ExpectHash + ' was expected - not usable.') 'WARN'
      return $null
    }
    return ($Algo + ' matches ' + $ExpectHash)
  }
  # No hash to check against. Only claim the file is good if SOMETHING exact matched - a mere
  # "it is bigger than the floor" is not evidence, and reusing on that basis is how a half-written
  # file survives forever.
  if ($ExpectSize -and $ExpectSize -gt 0)         { return ('size matches the expected ' + $ExpectSize + ' bytes exactly') }
  if ($ContentLength -and $ContentLength -gt 0)   { return ('size matches the server Content-Length of ' + $ContentLength + ' bytes exactly') }
  return $null
}

# 'e' / 'E' / 'E:' / 'E:\' / ' E: ' all mean the same drive. Normalise to 'E:' or return ''.
# Pure, so it can be tested.
function Format-YcDriveLetter {
  param($Value)
  $t = ([string]$Value).Trim()
  if (-not $t) { return '' }
  if ($t -notmatch '^([A-Za-z])(:\\?)?$') { return '' }
  return ($Matches[1].ToUpperInvariant() + ':')
}

# Find the drive letter of a just-mounted ISO, and PROVE it is the right one.
#
# The old code was `$img | Get-Volume` then `.DriveLetter`, after a flat 3-second sleep. Three ways
# that goes wrong on a real VM:
#   - the volume is not enumerable yet, or has no letter yet, when the 3 seconds are up. A fixed
#     sleep is a guess; this polls until a deadline instead.
#   - Get-Volume returns nothing (or throws) on some builds unless you hop through Get-Disk and
#     Get-Partition, so a single lookup is a single point of failure.
#   - the guest has OTHER optical drives - VMware Tools media, a virtio ISO, a CloudStack config
#     drive - and nothing in the old code checked that the letter it grabbed was the SQL media.
#     A wrong-but-present letter is worse than no letter: setup.exe is simply "not found" and the
#     error blames the ISO.
# So: gather candidates from four independent sources, and accept only a candidate whose root
# actually contains the required file. That last test is what makes it correct rather than lucky.
function Get-YcIsoDriveLetter {
  param([string]$ImagePath,[string]$RequiredFile = 'setup.exe',[int]$TimeoutSec = 60)
  $deadline = (Get-Date).AddSeconds($TimeoutSec)
  $seen = New-Object System.Collections.Generic.List[string]
  do {
    $cand = New-Object System.Collections.Generic.List[string]
    $src  = @{}
    function Add-Cand([string]$L,[string]$From) {
      $n = Format-YcDriveLetter $L
      if ($n -and -not $cand.Contains($n)) { [void]$cand.Add($n); $src[$n] = $From }
    }

    # 1. the direct answer: the disk image's own volume
    try {
      $di = Get-DiskImage -ImagePath $ImagePath -ErrorAction Stop
      if ($di -and $di.Attached) {
        foreach ($v in @($di | Get-Volume -ErrorAction SilentlyContinue)) { Add-Cand $v.DriveLetter 'Get-DiskImage | Get-Volume' }
        # 2. the same thing the long way round - some builds only answer through the disk
        foreach ($v in @($di | Get-Disk -ErrorAction SilentlyContinue | Get-Partition -ErrorAction SilentlyContinue | Get-Volume -ErrorAction SilentlyContinue)) {
          Add-Cand $v.DriveLetter 'Get-DiskImage | Get-Disk | Get-Partition | Get-Volume'
        }
      }
    } catch { }

    # 3. WMI, which answers when the Storage module is unhappy. DriveType 5 = CD-ROM.
    try {
      foreach ($d in @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=5' -ErrorAction SilentlyContinue)) { Add-Cand $d.DeviceID 'Win32_LogicalDisk DriveType=5' }
    } catch { }

    # 4. plain .NET, which needs no WMI and no Storage module at all
    try {
      foreach ($d in [System.IO.DriveInfo]::GetDrives()) {
        if ($d.DriveType -eq 'CDRom' -and $d.IsReady) { Add-Cand $d.Name 'System.IO.DriveInfo' }
      }
    } catch { }

    foreach ($c in $cand) {
      if (-not $seen.Contains($c)) { [void]$seen.Add($c) }
      if (Test-Path -LiteralPath (Join-Path ($c + '\') $RequiredFile) -PathType Leaf) {
        Write-YcLog ('Mounted ISO resolved to ' + $c + ' via ' + $src[$c] + ' (' + $RequiredFile + ' confirmed at its root).') 'OK'
        return $c
      }
    }
    if ((Get-Date) -lt $deadline) { Start-Sleep -Seconds 2 }
  } while ((Get-Date) -lt $deadline)

  if ($seen.Count -gt 0) {
    Write-YcLog ('Optical drive letters were found (' + ($seen -join ', ') + ') but none of them has ' + $RequiredFile + ' at its root. Those are other drives - CloudStack config media, VMware Tools, a virtio ISO - not the SQL Server media.') 'ERROR'
  } else {
    Write-YcLog ('No optical drive letter appeared within ' + $TimeoutSec + ' seconds of mounting ' + $ImagePath + '. All four detection paths (Get-DiskImage/Get-Volume, Get-Disk/Get-Partition, Win32_LogicalDisk, System.IO.DriveInfo) returned nothing.') 'ERROR'
  }
  return ''
}

# A downloaded "installer" that is really an HTML error page, a captive-portal login or a zero-byte
# stub is the classic way an unattended install dies with a meaningless message. Prove the bytes.
function Test-YcDownloadedFile {
  param([string]$Path,[int64]$MinBytes,[string]$Kind)
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
    Write-YcLog ('MEDIA VALIDATION FAILED: ' + $Path + ' does not exist or is not a file.') 'ERROR'
    return $false
  }
  $len = (Get-Item -LiteralPath $Path).Length
  if ($len -lt $MinBytes) {
    Write-YcLog ('MEDIA VALIDATION FAILED: ' + $Path + ' is ' + $len + ' bytes, below the ' + $MinBytes + ' byte floor for a ' + $Kind + '.') 'ERROR'
    return $false
  }
  $fs = [System.IO.File]::OpenRead($Path)
  try {
    $buf = New-Object byte[] 1024
    $n = $fs.Read($buf, 0, 1024)
  } finally { $fs.Close() }
  $head = [System.Text.Encoding]::ASCII.GetString($buf, 0, $n)
  if ($head -match '(?i)<!doctype html|<html|<head>|<title>') {
    Write-YcLog ('MEDIA VALIDATION FAILED: ' + $Path + ' starts with HTML - this is an error page or a portal redirect, not a ' + $Kind + '.') 'ERROR'
    return $false
  }
  if ($Kind -eq 'executable' -and -not ($buf[0] -eq 0x4D -and $buf[1] -eq 0x5A)) {
    Write-YcLog ('MEDIA VALIDATION FAILED: ' + $Path + ' has no MZ header - it is not a Windows executable.') 'ERROR'
    return $false
  }
  # "Plausible" was doing far too much work for an ISO. Prove it structurally.
  if ($Kind -eq 'ISO' -and -not (Test-YcIsoStructure -Path $Path)) { return $false }
  Write-YcLog ('Media validated: ' + $Path + ' (' + $len + ' bytes, verified ' + $Kind + ').') 'OK'
  return $true
}

# Grants a Windows user right via secedit /export + /configure, the documented supported mechanism.
function Grant-YcUserRight {
  param([string]$Right,[string]$Principal)
  $tmp = Join-Path $env:TEMP ('yc-sec-' + [guid]::NewGuid().ToString('N'))
  $inf = $tmp + '.inf'
  $sdb = $tmp + '.sdb'
  $cur = $tmp + '-cur.inf'
  try {
    $e = Invoke-YcNative -FilePath 'secedit.exe' -Arguments @('/export','/cfg',$cur,'/areas','USER_RIGHTS','/quiet')
    if ($e.ExitCode -ne 0) {
      Write-YcLog ('secedit /export failed (exit ' + $e.ExitCode + '): ' + ($e.Output -join ' ')) 'ERROR'
      return $false
    }
    $existing = ''
    foreach ($line in (Get-Content -LiteralPath $cur)) {
      if ($line -match ('^\s*' + [regex]::Escape($Right) + '\s*=\s*(.*)$')) { $existing = $Matches[1].Trim() }
    }
    if ($existing -and ($existing -split ',' | ForEach-Object { $_.Trim() }) -contains $Principal) {
      Write-YcLog ($Principal + ' already holds ' + $Right + '.') 'OK'
      return $true
    }
    $new = if ($existing) { $existing + ',' + $Principal } else { $Principal }
    $body = @(
      '[Unicode]',
      'Unicode=yes',
      '[Version]',
      'signature="$CHICAGO$"',
      'Revision=1',
      '[Privilege Rights]',
      ($Right + ' = ' + $new)
    ) -join "`r`n"
    [System.IO.File]::WriteAllText($inf, $body, [System.Text.Encoding]::Unicode)
    $c = Invoke-YcNative -FilePath 'secedit.exe' -Arguments @('/configure','/db',$sdb,'/cfg',$inf,'/areas','USER_RIGHTS','/quiet')
    if ($c.ExitCode -ne 0) {
      Write-YcLog ('secedit /configure failed (exit ' + $c.ExitCode + '): ' + ($c.Output -join ' ')) 'ERROR'
      return $false
    }
    Write-YcLog ('Granted ' + $Right + ' to ' + $Principal + '.') 'OK'
    return $true
  } catch {
    Write-YcLog ('Granting ' + $Right + ' to ' + $Principal + ' failed: ' + $_.Exception.Message) 'ERROR'
    return $false
  } finally {
    foreach ($f in @($inf,$sdb,$cur)) { if (Test-Path -LiteralPath $f) { try { Remove-Item -LiteralPath $f -Force } catch { } } }
  }
}

function Set-YcHighPerformancePowerPlan {
  # powercfg /list then /setactive <GUID>. The GUID is discovered rather than hard-coded, because
  # only the /list and /setactive syntax is documented, not a literal High performance GUID.
  $l = Invoke-YcNative -FilePath 'powercfg.exe' -Arguments @('/list')
  if ($l.ExitCode -ne 0) {
    Write-YcLog ('powercfg /list failed (exit ' + $l.ExitCode + ') - power plan left unchanged.') 'WARN'
    return $false
  }
  $guid = $null
  foreach ($line in $l.Output) {
    if ($line -match '(?i)GUID:\s*([0-9a-f-]{36}).*\(High performance\)') { $guid = $Matches[1]; break }
  }
  if (-not $guid) {
    Write-YcLog 'powercfg /list did not report a "High performance" scheme on this image - power plan left unchanged.' 'WARN'
    return $false
  }
  $s = Invoke-YcNative -FilePath 'powercfg.exe' -Arguments @('/setactive',$guid)
  if ($s.ExitCode -ne 0) {
    Write-YcLog ('powercfg /setactive ' + $guid + ' failed (exit ' + $s.ExitCode + ').') 'WARN'
    return $false
  }
  Write-YcLog ('Power plan set to High performance (' + $guid + ').') 'OK'
  return $true
}

function Install-YcMsi {
  param([string]$MsiPath,[string[]]$Properties,[string]$Name)
  $log = Join-Path 'C:\Scripts' ('install-sql-' + ($Name -replace '[^A-Za-z0-9]','') + '.msi.log')
  $mArgs = New-Object System.Collections.Generic.List[string]
  [void]$mArgs.Add('/i')
  [void]$mArgs.Add(('"' + $MsiPath + '"'))
  foreach ($prop in $Properties) { [void]$mArgs.Add($prop) }
  [void]$mArgs.Add('/qn')
  # REBOOT=ReallySuppress rather than /norestart: the documented Windows Installer command-line
  # option table does not list /norestart, but REBOOT is a documented public property whose
  # ReallySuppress value suppresses "all restarts and restart prompts at the end of the installation".
  [void]$mArgs.Add('REBOOT=ReallySuppress')
  [void]$mArgs.Add('/l*v')
  [void]$mArgs.Add(('"' + $log + '"'))
  Write-YcLog ('msiexec ' + ($mArgs -join ' '))
  $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList $mArgs.ToArray() -Wait -PassThru
  $rc = $p.ExitCode
  if ($rc -eq 0) { Write-YcLog ($Name + ' installed (msiexec exit 0).') 'OK'; return $true }
  if ($rc -eq 3010 -or $rc -eq 1641) {
    Write-YcLog ($Name + ' installed but a reboot is required (msiexec exit ' + $rc + ').') 'WARN'
    $script:YcRebootNeeded = $true
    return $true
  }
  Write-YcLog ($Name + ' install FAILED (msiexec exit ' + $rc + '). Verbose log: ' + $log) 'ERROR'
  return $false
}

# The per-instance root under -DataDir. Used by BOTH the orphan sweep in PHASE 1 and the answer
# file in PHASE 4; if those two ever disagreed, the sweep would clear the wrong directory or miss
# the right one. Pure, so it is tested.
function Get-YcInstanceDataRoot {
  param([string]$Root,[string]$Instance)
  if ($Instance -eq 'MSSQLSERVER') { return $Root }
  return (Join-Path $Root $Instance)
}

# The minimum BUILD at which a SQL version is supported at all, from the YallaCloud SQL Install and
# Licence Matrix v2.1: SQL 2016 is "SP3 only" on Windows Server 2016/2019, SQL 2014 "SP3 only",
# SQL 2012 "SP4 only". Anything below is not a supported configuration - which is a very different
# statement from "it installed". Returns '' when there is no floor for that version.
#   SQL 2016 SP3 = 13.0.6300 | SQL 2014 SP3 = 12.0.6024 | SQL 2012 SP4 = 11.0.7001
function Get-YcMinSupportedBuild {
  param([string]$SqlVersion)
  switch ($SqlVersion) {
    '2016' { return '13.0.6300' }
    '2014' { return '12.0.6024' }
    '2012' { return '11.0.7001' }
    default { return '' }
  }
}

# The service pack that lifts a version to the floor Get-YcMinSupportedBuild demands, so the script
# can fetch it instead of leaving the operator to hunt for an 821 MB installer by hand. Pure.
# URL and size verified against download.microsoft.com on 2026-08-29 (HTTP 200, Content-Length
# 860976520, Content-Disposition filename SQLServer2016SP3-KB5003279-x64-ENU.exe).
# Only 2016 is reachable today - -Version's ValidateSet does not admit 2014 or 2012 - but the
# shape is here so adding one is a single entry.
function Get-YcServicePackInfo {
  param([string]$SqlVersion)
  switch ($SqlVersion) {
    '2016' {
      return [pscustomobject]@{
        Kb    = 'KB5003279'
        Name  = 'SQL Server 2016 Service Pack 3'
        File  = 'SQLServer2016SP3-KB5003279-x64-ENU.exe'
        Url   = 'https://download.microsoft.com/download/a/7/7/a77b5753-8fe7-4804-bfc5-591d9a626c98/SQLServer2016SP3-KB5003279-x64-ENU.exe'
        Size  = 860976520
        Build = '13.0.6300'
      }
    }
    default { return $null }
  }
}

# SQL Server reports its version TWO different ways, and they are not comparable.
#   registry  HKLM\...\MSSQL13.MSSQLSERVER\Setup  Version / PatchLevel = 13.2.5026.0
#   engine    SERVERPROPERTY('ProductVersion')                        = 13.0.5026.0
# The registry puts the SERVICE PACK NUMBER in the minor octet (SP2 -> 13.2, SP3 -> 13.3); the
# engine always reports minor 0. Both values were read off C16B on 2026-08-29 to confirm it, and
# PatchLevel is NOT the escape hatch - it is 13.2.5026.0 too.
#
# This bit me: comparing the registry's 13.2.5026.0 against the 13.0.6300 floor gave
# "already meets the floor" (13.2 > 13.0) and skipped the service-pack download entirely, on a box
# that is demonstrably SP2. Normalise the minor octet to 0 before ANY comparison. Pure, and tested.
function ConvertTo-YcProductVersion {
  param([string]$RegistryVersion)
  if ("$RegistryVersion" -notmatch '^(\d+)\.(\d+)(\.(\d+))?(\.(\d+))?$') { return '' }
  $maj = $Matches[1]
  $bld = if ($Matches[4]) { $Matches[4] } else { '0' }
  $rev = if ($Matches[6]) { $Matches[6] } else { '0' }
  return ($maj + '.0.' + $bld + '.' + $rev)
}

# The build of an installed instance, read from the registry - PHASE 6 runs before sqlcmd exists,
# so it cannot ask the engine. Returned in PRODUCT VERSION form so it is comparable with the
# floors in Get-YcMinSupportedBuild, which are ProductVersion values.
function Get-YcInstalledSqlBuild {
  param([string]$InstanceName)
  foreach ($root in 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Microsoft SQL Server') {
    $id = Get-YcRegValueOrNull -Path ($root + '\Instance Names\SQL') -Name $InstanceName
    if (-not $id) { continue }
    $v = Get-YcRegValueOrNull -Path ($root + '\' + $id + '\Setup') -Name 'Version'
    if ($v) { return (ConvertTo-YcProductVersion -RegistryVersion ([string]$v)) }
  }
  return ''
}

# Lifecycle, from the same matrix. Returns 'eol' (extended support already ended), 'soon' (ends
# within 180 days) or 'ok'. Pure: the date is passed in so it can be tested.
function Get-YcLifecycleState {
  param([string]$EndDate,[datetime]$Now)
  if (-not $EndDate) { return 'unknown' }
  $d = [datetime]::MinValue
  if (-not [datetime]::TryParseExact($EndDate,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$d)) { return 'unknown' }
  if ($Now -ge $d) { return 'eol' }
  if (($d - $Now).TotalDays -le 180) { return 'soon' }
  return 'ok'
}
function Get-YcSqlEolDate {
  param([string]$SqlVersion)
  switch ($SqlVersion) {
    '2012' { return '2022-07-12' }
    '2014' { return '2024-07-09' }
    '2016' { return '2026-07-14' }
    '2017' { return '2027-10-12' }
    '2019' { return '2030-01-08' }
    '2022' { return '2033-01-11' }
    '2025' { return '2036-01-07' }
    default { return '' }
  }
}
function Get-YcWindowsEolDate {
  param([string]$OsFamily)
  switch ($OsFamily) {
    'WS2016' { return '2027-01-12' }
    'WS2019' { return '2029-01-09' }
    'WS2022' { return '2031-10-15' }
    'WS2025' { return '2034-11-15' }
    default  { return '' }
  }
}

# The .NET Framework Release value this run actually needs. Pure, so it can be unit tested.
# SQL Server 2022/2025 document 4.7.2 (461808); 2016/2017/2019 document 4.6 (393295).
# dbatools.library is a SECOND consumer with its own, higher floor - see the long note in
# section 1f - so the answer is the higher of the two, never just SQL Server's.
function Get-YcRequiredNetRelease {
  param([int]$SqlVersion,[bool]$NeedDbatools)
  $rel = if ($SqlVersion -ge 2022) { 461808 } else { 393295 }
  if ($NeedDbatools -and $rel -lt 461808) { $rel = 461808 }
  return $rel
}

# ------------------------------------------------------------------------------------------------
# Resume after a reboot, unattended.
#
# Installing .NET Framework 4.8 needs a reboot before SQL setup will pass its RebootRequiredCheck
# rule. Without this, rebooting meant "reboot and then a human re-runs install-sql", which is
# not unattended at all - a first-boot deployment would simply stop there. A startup scheduled
# task running as SYSTEM re-runs this command after the reboot with no logon required. (HKLM
# RunOnce is deliberately NOT used: it only fires at an interactive logon, which never happens on
# a headless VM - the same trap that left Activate-Windows staged-but-never-run before v2.1.)
#
# The command line is read back from the OS (Win32_Process.CommandLine for this PID) rather than
# rebuilt out of $PSBoundParameters: reconstructing a correctly quoted command line from typed
# parameters, arrays and switches is its own bug farm, and this is byte-for-byte what was run.
# ------------------------------------------------------------------------------------------------
$script:YcResumeTask = 'YcInstallSqlResume'

function Remove-YcSqlResumeTask {
  try { Unregister-ScheduledTask -TaskName $script:YcResumeTask -Confirm:$false -ErrorAction SilentlyContinue | Out-Null } catch { }
}

function Set-YcSqlResumeTask {
  param([string]$Why)
  $cl = ''
  try { $cl = [string](Get-CimInstance Win32_Process -Filter ('ProcessId=' + $PID) -ErrorAction Stop).CommandLine } catch { }
  if (-not $cl) {
    Write-YcLog 'Cannot read this process command line, so the run cannot be staged to resume itself after the reboot. Re-run install-sql by hand once the machine is back.' 'WARN'
    return $false
  }
  # A plaintext password on the command line would be copied into the task definition and left on
  # disk. Refuse. -SaPasswordFile exists precisely so an unattended run does not need this.
  if ($cl -match '(?i)-(SaPassword|ChadminPassword)\b') {
    Write-YcLog 'NOT staging an automatic resume: the command line carries a plaintext password and the scheduled task definition would persist it on disk. Use -SaPasswordFile instead if you want install-sql to resume itself after the reboot.' 'WARN'
    return $false
  }
  try {
    # NOT cmd.exe. `cmd /c` strips the OUTERMOST quote pair whenever the line holds more than one
    # quoted token, so `cmd /c "<powershell.exe>" ... -Command "& C:\Scripts\Install-Sql.ps1 ..."`
    # lost the quotes around the -Command argument and cmd then read the bare `&` as its own
    # command separator. The task sat in "Running" forever, no child process, no log line, and SQL
    # never resumed. Measured on a pair of Server 2016 lab VMs on 2026-08-31 - it hits EVERY Server 2016 VM,
    # because .NET Framework 4.8 is what forces the reboot there. Register the real executable and
    # its arguments; there is no shell in the middle to re-parse anything.
    $exe = ''; $rest = ''
    if     ($cl -match '^\s*"([^"]+)"\s*(.*)$') { $exe = $Matches[1]; $rest = $Matches[2] }
    elseif ($cl -match '^\s*(\S+)\s*(.*)$')     { $exe = $Matches[1]; $rest = $Matches[2] }
    if (-not $exe) {
      Write-YcLog 'Cannot split the command line into an executable and arguments - not staging a resume that would not run.' 'ERROR'
      return $false
    }
    $act = New-ScheduledTaskAction -Execute $exe -Argument $rest
    $trg = New-ScheduledTaskTrigger -AtStartup
    try { $trg.Delay = 'PT3M' } catch { }   # let the network and the servicing stack settle first
    $pri = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $set = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 6)
    Register-ScheduledTask -TaskName $script:YcResumeTask -Action $act -Trigger $trg -Principal $pri -Settings $set -Force -ErrorAction Stop | Out-Null
    Write-YcLog ('Staged an automatic resume as scheduled task "' + $script:YcResumeTask + '" (at startup, as SYSTEM, 3 min delay) because ' + $Why + '. It removes itself on the next run.') 'OK'
    return $true
  } catch {
    Write-YcLog ('Could not register the resume task: ' + $_.Exception.Message) 'ERROR'
    return $false
  }
}

# ================================================================================================
# PHASE 0 - parameter resolution
# ================================================================================================
Write-YcPhase 0 'Parameter resolution'

# If this run IS the post-reboot resume, clear the task now so it can never loop.
Remove-YcSqlResumeTask

# ONE place decides whether this run may restart the machine. Everything below tests
# $script:DoReboot, never a parameter, so the default can never drift apart between call sites.
$script:DoReboot = (-not $NoReboot)
if ($NoReboot) {
  Write-YcLog 'Reboot policy: -NoReboot. This run will NEVER restart the machine; where a reboot is required it stops and says so, and C:\Scripts\install-sql.reboot-required records it.' 'WARN'
} else {
  Write-YcLog 'Reboot policy: default. If a reboot is genuinely required this run restarts the machine and resumes itself afterwards. Pass -NoReboot to stop instead.'
}
# ContainsKey, not the switch value, so this fires only when somebody actually typed it - and so
# no reboot decision anywhere in this script is ever gated on that switch again.
if ($PSBoundParameters.ContainsKey('AllowReboot')) { Write-YcLog '-AllowReboot is now the default and is accepted only for compatibility - it changes nothing.' }

# A scheduled task configured "run whether user is logged on or not" reports UserInteractive = true,
# so the old bare-invocation test blocked forever on Read-Host under an RMM. Require a real console.
$isRealConsole = $false
try {
  $isRealConsole = ([Environment]::UserInteractive -and
                    -not [Console]::IsInputRedirected -and
                    ($env:SESSIONNAME -notlike 'Services*'))
} catch { $isRealConsole = $false }

if ($PSBoundParameters.Count -eq 0 -and -not $Unattended -and $isRealConsole) {
  Write-Host ''
  Write-Host '  install-sql - interactive setup (no parameters were supplied)' -ForegroundColor Yellow
  Write-Host '  Press Enter to accept the [default] shown.' -ForegroundColor Gray
  Write-Host ''
  do { $v = Read-Host 'SQL Server version (2016/2017/2019/2022/2025)' } while ($v -notin @('2016','2017','2019','2022','2025'))
  $Version = $v
  $in = Read-Host "Instance name [$InstanceName]";        if ($in)  { $InstanceName = $in }
  $fe = Read-Host 'Features (comma list) [version default]'; if ($fe) { $Features = $fe }
  $dd = Read-Host "Data directory root [$DataDir]";       if ($dd)  { $DataDir = $dd }
  $bd = Read-Host "Backup directory [$BackupDir]";        if ($bd)  { $BackupDir = $bd }
  # -AsSecureString so the characters are never echoed to a console that Start-Transcript is
  # capturing into C:\Scripts\install-sql.log.
  $sa = Read-Host 'SA password (blank = Windows Authentication only)' -AsSecureString
  if ($sa -and $sa.Length -gt 0) {
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sa)
    try { $SaPassword = [Runtime.InteropServices.Marshal]::PtrToStringUni($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
  }
  $mt = Read-Host "Maintenance on/off [$Maintenance]";     if ($mt -in @('on','off')) { $Maintenance = $mt }
  $iso = Read-Host 'Path to an existing ISO (blank = download from Microsoft)'; if ($iso) { $IsoPath = $iso }
  Write-Host ''
}

if ($SaPasswordFile) {
  if (-not (Test-Path -LiteralPath $SaPasswordFile -PathType Leaf)) {
    Write-YcLog ('-SaPasswordFile not found: ' + $SaPasswordFile) 'ERROR'
    Invoke-YcExit 2
  }
  $first = (Get-Content -LiteralPath $SaPasswordFile -TotalCount 1)
  if (-not $first) {
    Write-YcLog ('-SaPasswordFile is empty: ' + $SaPasswordFile) 'ERROR'
    Invoke-YcExit 2
  }
  $SaPassword = [string]$first
}

if (-not $Version -and $IsoPath) {
  # Match on the LEAF name only and require exactly one hit. The old code matched the first year
  # found anywhere in the path, so C:\Media2019\SQLServer2022-x64-ENU.iso resolved to 2019 and
  # installed 2022 media with the 2019 answer file.
  $leaf = [IO.Path]::GetFileName($IsoPath)
  $hits = @()
  foreach ($y in '2016','2017','2019','2022','2025') { if ($leaf -match $y) { $hits += $y } }
  if ($hits.Count -eq 1) {
    $Version = $hits[0]
    Write-YcLog ('-Version inferred from the media file name "' + $leaf + '": ' + $Version) 'WARN'
  } elseif ($hits.Count -gt 1) {
    Write-YcLog ('-Version cannot be inferred: the media file name "' + $leaf + '" contains more than one version (' + ($hits -join ', ') + '). Pass -Version explicitly.') 'ERROR'
    Invoke-YcExit 2
  }
}

if (-not $Version) {
  Write-YcLog '-Version is required in unattended mode (and could not be inferred from -IsoPath). Use -Help.' 'ERROR'
  Invoke-YcExit 2
}

$VersionMajor  = @{ '2016' = 13; '2017' = 14; '2019' = 15; '2022' = 16; '2025' = 17 }[$Version]
$VersionInt    = [int]$Version
$isDefaultInst = ($InstanceName -eq 'MSSQLSERVER')
$script:SqlHost = if ($isDefaultInst) { $env:COMPUTERNAME } else { $env:COMPUTERNAME + '\' + $InstanceName }
$svcName       = if ($isDefaultInst) { 'MSSQLSERVER' } else { 'MSSQL$' + $InstanceName }
$agentSvcName  = if ($isDefaultInst) { 'SQLSERVERAGENT' } else { 'SQLAGENT$' + $InstanceName }
$sqlSvcSid     = if ($isDefaultInst) { 'NT SERVICE\MSSQLSERVER' } else { 'NT SERVICE\MSSQL$' + $InstanceName }
$agtSvcSid     = if ($isDefaultInst) { 'NT SERVICE\SQLSERVERAGENT' } else { 'NT SERVICE\SQLAGENT$' + $InstanceName }
$chadminLogin  = $env:COMPUTERNAME + '\chadmin'

# This media tier downloads EVALUATION media and only Evaluation media. -Edition used to be
# ValidateSet('Evaluation'), so anything else died in the parameter binder with "does not belong
# to the set", exit 1, and not one word about what to do instead. The value is accepted now and
# refused here, where the message can name the command that actually does the job.
if ($Edition -notmatch '(?i)^Evaluation$') {
  if ($Edition -match '(?i)^Express$') {
    Write-YcLog ('PREFLIGHT REFUSED: -Edition Express. This command downloads EVALUATION media and ' +
      'cannot install Express from it. Express is a separate free product with its own installer, ' +
      'and it has no SQL Server Agent and no backup compression, so this run would fail when it ' +
      'started the Agent service even if the media were right.') 'ERROR'
    Write-YcLog 'HOW TO INSTALL EXPRESS BY HAND. Every link below was resolved live on 2026-09-01, and both install shapes were proven end to end.' 'WARN'
    Write-YcLog '  2012  https://download.microsoft.com/download/8/D/D/8DD7BDBA-CEF7-4D8E-8C16-D9F69527F909/ENU/x64/SQLEXPR_x64_ENU.exe   (132 MB, full package; 2012 is long out of support)'
    Write-YcLog '  2016  https://download.microsoft.com/download/9/0/7/907AD35F-9F9C-43A5-9789-52470555DB90/ENU/SQLEXPR_x64_ENU.exe        (411 MB, full package)'
    Write-YcLog '  2017  https://go.microsoft.com/fwlink/?linkid=853017   -> SQLServer2017-SSEI-Expr.exe   (PROVEN: installs 14.0.1000.169)'
    Write-YcLog '  2019  https://go.microsoft.com/fwlink/?linkid=866658   -> SQL2019-SSEI-Expr.exe'
    Write-YcLog '  2022  https://go.microsoft.com/fwlink/?linkid=2215160  -> SQL2022-SSEI-Expr.exe         (PROVEN: installs 16.0.1000.6)'
    Write-YcLog '  2025  https://aka.ms/sql2025express                    -> SQL2025-SSEI-Expr.exe'
    Write-YcLog '  TRAP: fwlink 2216019, the link most pages still give for "2022 Express", now serves the 2025 package. Do not use it. Likewise the link widely cited as 2016 Express (fwlink 829176) actually delivers 2017 - verified by extracting it.' 'WARN'
    Write-YcLog '  TWO SHAPES: 2012 and 2016 are a FULL self-extracting package - run it with /q /x:<dir>, then <dir>\setup.exe. 2017 and later are a small BOOTSTRAPPER - run it with /Action=Download /MediaPath=<dir> /MediaType=Core /Quiet first, which fetches the real package, then extract that.'
    Write-YcLog '  THEN: run setup.exe with a ConfigurationFile FROM A SYSTEM SCHEDULED TASK. Run from a remote shell (SSH, WinRM) it fails with "There was an error generating the XML document" and a CryptographicException - VSS-style DPAPI needs a loaded profile. Verified three times.' 'WARN'
    Write-YcLog '  CHOCOLATEY is not used and here is why: the community package sql-server-express exists and is Approved, but it is maintained by a community author (flcdrg/au-packages), not Microsoft, it currently covers 2022 only, and it adds the Chocolatey feed as a second trust boundary for a Microsoft-sourced install. It does accept /ConfigurationFile, so it is a reasonable choice for an estate already standardised on Chocolatey and only needing 2022.'
    Invoke-YcExit 2
  }
  Write-YcLog ('PREFLIGHT REFUSED: -Edition ' + $Edition + '. This command installs EVALUATION media ' +
    'and nothing else, on purpose: that is the BYOL path this toolkit is built around. Install ' +
    'Evaluation, then convert it with your own key - "activate-sql -ProductKey <KEY> ' +
    '-TargetEdition ' + $Edition + '" - which is the only supported way to reach ' + $Edition +
    ' and is the step that proves the edition actually changed. -Edition accepts Evaluation.') 'ERROR'
  Invoke-YcExit 2
}

Write-YcLog ('Parameters: Version=' + $Version + ' Edition=' + $Edition + ' InstanceName=' + $InstanceName +
             ' DataDir=' + $DataDir + ' BackupDir=' + $BackupDir + ' Port=' + $Port +
             ' Maintenance=' + $Maintenance + ' ClientTools=' + $ClientTools + ' Ssms=' + $Ssms +
             ' Patch=' + $Patch + ' Firewall=' + $Firewall +
             # NOT "SaPassword=..." - the log redactor matches any *password* key and masks the
             # next token, so "(not set - Windows Auth only)" became "**** set - Windows Auth only)",
             # which reads as though a password IS set. The redactor is right to be greedy; the
             # key name is what was wrong. SqlAuth is not a secret name, so it survives intact.
             ' SqlAuth=' + $(if ($SaPassword) { 'mixed (sa password set, never logged)' } else { 'windows-only' }))

# ================================================================================================
# PHASE 1 - preflight gate. Everything here runs BEFORE a single byte of media is downloaded.
# ================================================================================================
Write-YcPhase 1 'Preflight gate (before any download)'

# --- 1a. SQL Server / Windows support matrix -----------------------------------------------------
$os        = Get-CimInstance -ClassName Win32_OperatingSystem
$osCaption = [string]$os.Caption
$osBuild   = [int]($os.BuildNumber)
$isServer  = ($os.ProductType -ne 1)
Write-YcLog ('Operating system: ' + $osCaption + ' (build ' + $osBuild + ', ' + $(if ($isServer) { 'Server' } else { 'Client' }) + ')')

$osFamily = 'Unknown'
if ($isServer) {
  if     ($osBuild -ge 26100) { $osFamily = 'WS2025' }
  elseif ($osBuild -ge 20348) { $osFamily = 'WS2022' }
  elseif ($osBuild -ge 17763) { $osFamily = 'WS2019' }
  elseif ($osBuild -ge 14393) { $osFamily = 'WS2016' }
  else                        { $osFamily = 'WS-Older' }
} else {
  if     ($osBuild -ge 22000) { $osFamily = 'Win11' }
  elseif ($osBuild -ge 10240) { $osFamily = 'Win10' }
  else                        { $osFamily = 'Win-Older' }
}

# Source: "Version requirements for SQL Server in Windows operating system" compatibility matrix.
$supportMatrix = @{
  'WS2025' = @('2019','2022','2025')
  'WS2022' = @('2017','2019','2022','2025')
  'WS2019' = @('2016','2017','2019','2022','2025')
  'WS2016' = @('2016','2017','2019','2022')
  'Win11'  = @('2017','2019','2022','2025')
  'Win10'  = @('2016','2017','2019','2022','2025')
}
if ($supportMatrix.ContainsKey($osFamily)) {
  if ($supportMatrix[$osFamily] -notcontains $Version) {
    Write-YcLog ('PREFLIGHT REFUSED: SQL Server ' + $Version + ' is NOT supported on ' + $osCaption +
                 ' (' + $osFamily + '). Supported here: ' + ($supportMatrix[$osFamily] -join ', ') +
                 '. Setup would block this at rule check AFTER the download, so it is refused now.') 'ERROR'
    Invoke-YcExit 2
  }
  Write-YcLog ('Supported combination: SQL Server ' + $Version + ' on ' + $osFamily + '.') 'OK'
  $minBuild = Get-YcMinSupportedBuild -SqlVersion $Version
  if ($minBuild) {
    Write-YcLog ('SQL Server ' + $Version + ' is only a supported configuration at build ' + $minBuild + ' or later (that is the service-pack floor). The media must be a slipstream at or above it, or the service pack must be applied afterwards - PHASE 8 checks the build that actually resulted and does not take this on trust.') 'WARN'
  }
  # Lifecycle. Out-of-support software installs perfectly well and is still a problem, so say it.
  $nowUtc = (Get-Date)
  $sqlEol = Get-YcSqlEolDate -SqlVersion $Version
  switch (Get-YcLifecycleState -EndDate $sqlEol -Now $nowUtc) {
    'eol'  { Write-YcLog ('LIFECYCLE: SQL Server ' + $Version + ' left extended support on ' + $sqlEol + '. It receives no security updates. Installing it is a lifecycle decision, not a default - raise a ticket.') 'WARN'
             Add-YcSummary 'SQL lifecycle' ('OUT OF SUPPORT since ' + $sqlEol) }
    'soon' { Write-YcLog ('LIFECYCLE: SQL Server ' + $Version + ' leaves extended support on ' + $sqlEol + ', within 180 days.') 'WARN'
             Add-YcSummary 'SQL lifecycle' ('support ends ' + $sqlEol) }
  }
  $winEol = Get-YcWindowsEolDate -OsFamily $osFamily
  switch (Get-YcLifecycleState -EndDate $winEol -Now $nowUtc) {
    'eol'  { Write-YcLog ('LIFECYCLE: ' + $osFamily + ' left extended support on ' + $winEol + '.') 'WARN'
             Add-YcSummary 'Windows lifecycle' ('OUT OF SUPPORT since ' + $winEol) }
    'soon' { Write-YcLog ('LIFECYCLE: ' + $osFamily + ' leaves extended support on ' + $winEol + ', within 180 days.') 'WARN'
             Add-YcSummary 'Windows lifecycle' ('support ends ' + $winEol) }
  }
} else {
  Write-YcLog ('Could not classify this Windows version (' + $osCaption + ' build ' + $osBuild + '). Proceeding, but the SQL/Windows support matrix was NOT checked.') 'WARN'
}

# --- 1b. Answer-file template must exist for THIS version, before any download --------------------
$tmplPath = 'C:\Scripts\sql-templates\ConfigurationFile-' + $Version + '.ini.tmpl'
if (-not (Test-Path -LiteralPath $tmplPath -PathType Leaf)) {
  Write-YcLog ('PREFLIGHT REFUSED: no answer-file template for SQL Server ' + $Version + ' at ' + $tmplPath +
               '. There is deliberately NO fall back to the 2022 template - installing 2016 media from a 2022 answer file is worse than not installing.') 'ERROR'
  Invoke-YcExit 2
}
$tmplRaw = Get-Content -LiteralPath $tmplPath -Raw
if (-not $tmplRaw -or $tmplRaw.Trim().Length -eq 0) {
  Write-YcLog ('PREFLIGHT REFUSED: the answer-file template ' + $tmplPath + ' is empty.') 'ERROR'
  Invoke-YcExit 2
}
Write-YcLog ('Answer-file template present: ' + $tmplPath) 'OK'

# --- 1c. FEATURES: version-aware default plus a hard rejection of legacy tokens (P0-6) ------------
# Conn, BC, SDK, SNAC_SDK, DREPLAY_CTLR, DREPLAY_CLT and the Tools parent are each documented
# "Applies to: SQL Server 2019 and earlier versions"; RS / RS_SHP / RS_SHPWFE are documented
# "Applies to: SQL Server 2016 and earlier versions". Passing any of them to a newer setup fails
# feature validation and exits non-zero after the whole download.
$LegacyThrough2019 = @('CONN','BC','SDK','SNAC_SDK','DREPLAY_CTLR','DREPLAY_CLT','TOOLS')
$LegacyThrough2016 = @('RS','RS_SHP','RS_SHPWFE')
$KnownFeatures = @(
  'SQL','SQLENGINE','REPLICATION','FULLTEXT','DQ','DQC','POLYBASE','POLYBASECORE','POLYBASEJAVA',
  'ADVANCEDANALYTICS','SQL_INST_MR','SQL_INST_MPY','SQL_INST_JAVA','SQL_SHARED_MR','SQL_SHARED_MPY',
  'AS','AS_SPI','IS','IS_MASTER','IS_WORKER','MDS','LOCALDB','AZUREEXTENSION','SQLODBC','SQLODBC_SDK'
) + $LegacyThrough2019 + $LegacyThrough2016

if (-not $Features) {
  $Features = if ($VersionInt -ge 2022) { 'SQLENGINE,REPLICATION,FULLTEXT' }
              else                      { 'SQLENGINE,REPLICATION,FULLTEXT,CONN,BC,SDK' }
  Write-YcLog ('-Features not supplied; using the version-correct default for SQL ' + $Version + ': ' + $Features)
}
$featTokens = @($Features -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
if ($featTokens.Count -eq 0) {
  Write-YcLog 'PREFLIGHT REFUSED: -Features resolved to an empty list.' 'ERROR'
  Invoke-YcExit 2
}
$featUpper  = @($featTokens | ForEach-Object { $_.ToUpperInvariant() })
$badUnknown = @($featUpper | Where-Object { $KnownFeatures -notcontains $_ })
if ($badUnknown.Count -gt 0) {
  Write-YcLog ('PREFLIGHT REFUSED: unknown FEATURES token(s): ' + ($badUnknown -join ',') +
               '. Setup validates FEATURES and rejects the whole install, so this is refused before the download.') 'ERROR'
  Invoke-YcExit 2
}
if ($VersionInt -ge 2022) {
  $badLegacy = @($featUpper | Where-Object { $LegacyThrough2019 -contains $_ })
  if ($badLegacy.Count -gt 0) {
    Write-YcLog ('PREFLIGHT REFUSED: FEATURES token(s) not valid on SQL Server ' + $Version + ': ' + ($badLegacy -join ',') +
                 '. Each is documented "Applies to: SQL Server 2019 and earlier versions" and was removed from setup. ' +
                 'Use -Features SQLENGINE,REPLICATION,FULLTEXT and let PHASE 7 install sqlcmd / ODBC / OLE DB separately.') 'ERROR'
    Invoke-YcExit 2
  }
}
if ($VersionInt -ge 2017) {
  $badRs = @($featUpper | Where-Object { $LegacyThrough2016 -contains $_ })
  if ($badRs.Count -gt 0) {
    Write-YcLog ('PREFLIGHT REFUSED: FEATURES token(s) not valid on SQL Server ' + $Version + ': ' + ($badRs -join ',') +
                 '. Reporting Services is documented "Applies to: SQL Server 2016 and earlier versions" and ships as a separate installer from 2017 onward.') 'ERROR'
    Invoke-YcExit 2
  }
}
# ------------------------------------------------------------------------------------------
# VERSION FLOORS AND CEILINGS FOR THE SUB-FEATURES.
# Every token above is a REAL token, so the unknown-token check passes them all - but several
# only exist in a window of versions, and setup rejects the whole install when one is wrong.
# That rejection arrives AFTER the media download, which is the expensive way to find out.
#
# These boundaries come from Microsoft's documented "Applies to" statements for each feature,
# the same source the CONN/BC/SDK and RS gates above already use. They are NOT derived from
# installing every feature on every version.
# ------------------------------------------------------------------------------------------
$featureWindow = @(
  @{ T='SQL_INST_MPY';  Min=2017; Max=2022; What='Machine Learning Services - Python';
     Why='Python arrived in SQL Server 2017 (2016 had R only) and Machine Learning Services was removed from SQL Server setup after 2022.' }
  @{ T='SQL_SHARED_MPY';Min=2017; Max=2019; What='Machine Learning Server (standalone) - Python';
     Why='The standalone Machine Learning Server was discontinued and is not in 2022 or later setup.' }
  @{ T='SQL_INST_MR';   Min=2016; Max=2022; What='Machine Learning Services - R';
     Why='R was the original 2016 Advanced Analytics feature; Machine Learning Services was removed from SQL Server setup after 2022.' }
  @{ T='SQL_SHARED_MR'; Min=2016; Max=2019; What='Machine Learning Server (standalone) - R';
     Why='The standalone Machine Learning Server was discontinued and is not in 2022 or later setup.' }
  @{ T='ADVANCEDANALYTICS'; Min=2016; Max=2022; What='Machine Learning Services (the parent feature)';
     Why='Introduced in 2016 as R Services and removed from SQL Server setup after 2022.' }
  @{ T='SQL_INST_JAVA'; Min=2019; Max=2022; What='Java language extension';
     Why='Java in-database arrived in SQL Server 2019 and left setup with the rest of the language extensions after 2022.' }
  @{ T='POLYBASEJAVA';  Min=2019; Max=0;    What='PolyBase Java connector for HDFS';
     Why='The Java connector is a 2019-and-later PolyBase sub-feature; on 2016 and 2017 PolyBase is a single POLYBASE token.' }
  @{ T='POLYBASECORE';  Min=2019; Max=0;    What='PolyBase core';
     Why='POLYBASECORE became a separate token in 2019; earlier versions take POLYBASE alone.' }
)
foreach ($fw in $featureWindow) {
  if ($featUpper -notcontains $fw.T) { continue }
  if ($VersionInt -lt $fw.Min) {
    Write-YcLog ('PREFLIGHT REFUSED: FEATURES token ' + $fw.T + ' (' + $fw.What + ') does not exist in SQL Server ' +
                 $Version + '. It is available from SQL Server ' + $fw.Min + ' onward. ' + $fw.Why +
                 ' Setup would reject the entire install - after downloading the media.') 'ERROR'
    Invoke-YcExit 2
  }
  if ($fw.Max -gt 0 -and $VersionInt -gt $fw.Max) {
    Write-YcLog ('PREFLIGHT REFUSED: FEATURES token ' + $fw.T + ' (' + $fw.What + ') was REMOVED after SQL Server ' +
                 $fw.Max + ' and is not in SQL Server ' + $Version + ' setup. ' + $fw.Why +
                 ' Setup would reject the entire install - after downloading the media.') 'ERROR'
    Invoke-YcExit 2
  }
}

if ($featUpper -contains 'AZUREEXTENSION') {
  if ($VersionInt -lt 2022) {
    Write-YcLog ('PREFLIGHT REFUSED: AZUREEXTENSION is documented "Applies to: SQL Server 2022 and later versions".') 'ERROR'
  } else {
    Write-YcLog ('PREFLIGHT REFUSED: AZUREEXTENSION also requires PRODUCTCOVEREDBYSA and the AZURE* settings, which these answer-file templates deliberately do not carry (this is an Evaluation, non-Arc build). Remove it from -Features.') 'ERROR'
  }
  Invoke-YcExit 2
}
if ($featUpper -notcontains 'SQLENGINE' -and $featUpper -notcontains 'SQL') {
  Write-YcLog 'PREFLIGHT REFUSED: FEATURES does not include SQLENGINE (or the SQL parent). This command installs a database engine.' 'ERROR'
  Invoke-YcExit 2
}
$Features = ($featTokens -join ',')
Write-YcLog ('FEATURES validated for SQL Server ' + $Version + ': ' + $Features) 'OK'

# --- 1d. Answer-file values that setup validates ---------------------------------------------------
if ($InstanceName -notmatch '^[A-Za-z][A-Za-z0-9_$]{0,15}$') {
  Write-YcLog ('PREFLIGHT REFUSED: -InstanceName "' + $InstanceName + '" is not a valid SQL Server instance name (letter first, up to 16 characters, letters/digits/underscore/$).') 'ERROR'
  Invoke-YcExit 2
}
if ($Collation -notmatch '^[A-Za-z0-9_]+$') {
  Write-YcLog ('PREFLIGHT REFUSED: -Collation "' + $Collation + '" is not a plausible collation name. A wrong collation cannot be changed later without a reinstall.') 'ERROR'
  Invoke-YcExit 2
}
foreach ($pair in @(@('-DataDir',$DataDir), @('-BackupDir',$BackupDir), @('-WorkDir',$WorkDir))) {
  if (-not $pair[1] -or -not [System.IO.Path]::IsPathRooted($pair[1])) {
    Write-YcLog ('PREFLIGHT REFUSED: ' + $pair[0] + ' must be an absolute path (got "' + $pair[1] + '").') 'ERROR'
    Invoke-YcExit 2
  }
  if ($pair[1] -match '["<>|?*]') {
    Write-YcLog ('PREFLIGHT REFUSED: ' + $pair[0] + ' contains a character that cannot appear in an answer-file path: ' + $pair[1]) 'ERROR'
    Invoke-YcExit 2
  }
}
if ($SaPassword) {
  if ($SaPassword -match '"') {
    Write-YcLog 'PREFLIGHT REFUSED: the sa password contains a double-quote, which cannot be represented in a setup answer file. Choose a different password.' 'ERROR'
    Invoke-YcExit 2
  }
  if ($SaPassword.Length -lt 8) {
    Write-YcLog 'PREFLIGHT REFUSED: the sa password is shorter than 8 characters and will fail SQL Server password policy.' 'ERROR'
    Invoke-YcExit 2
  }
}
if ($Port -lt 1 -or $Port -gt 65535) {
  Write-YcLog ('PREFLIGHT REFUSED: -Port ' + $Port + ' is out of range.') 'ERROR'
  Invoke-YcExit 2
}

# A NAMED instance must not be forced onto the default instance's port. SQL Server setup does not
# object to two instances configured on the same TCP port: the install finishes clean, and then
# MSSQL$<name> silently refuses to start forever after. All the operator sees is
# "Cannot start service SQLAgent$<name>", with the real cause - "Tcp port is already in use",
# error 26023 - buried in that instance's own ERRORLOG. Observed on the 2016, 2019 and 2022
# clones on 2026-08-31 while installing a second instance to test the SQL Web-edition keys.
# If -Port was given explicitly that is the operator's decision and it is honoured as-is.
if ($InstanceName -ne 'MSSQLSERVER' -and -not $PSBoundParameters.ContainsKey('Port')) {
  $takenPorts = @()
  try {
    $takenPorts = @([System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() |
                    ForEach-Object { $_.Port })
  } catch {
    Write-YcLog ('Could not enumerate listening TCP ports (' + $_.Exception.Message + '); the port choice below is made blind.') 'WARN'
  }
  if ($takenPorts -contains $Port) {
    $pickedPort = 0
    foreach ($cand in 1434..1499) { if ($takenPorts -notcontains $cand) { $pickedPort = $cand; break } }
    if ($pickedPort -eq 0) { $pickedPort = 1435 }
    Write-YcLog ('TCP ' + $Port + ' is already in use on this machine and ' + $InstanceName +
                 ' is a NAMED instance, so it cannot have that port. Using TCP ' + $pickedPort +
                 ' instead - pass -Port to choose your own. Two instances on one port install ' +
                 'without complaint and then the named one never starts.') 'WARN'
    $Port = $pickedPort
  } else {
    Write-YcLog ('Named instance ' + $InstanceName + ' will use TCP ' + $Port + ', which nothing is listening on.')
  }
}
foreach ($cidr in $ManagementCidr) {
  if ($cidr -match '(?i)^(any|0\.0\.0\.0/0|::/0|\*)$') {
    Write-YcLog ('PREFLIGHT REFUSED: -ManagementCidr "' + $cidr + '" would open a database port to every network. Give a real management scope (a CIDR, an IP range, or the LocalSubnet keyword).') 'ERROR'
    Invoke-YcExit 2
  }
}
if ($BackupDir -like ($env:SystemDrive + '*')) {
  # Deliberate default, not an oversight: a backup on C: beats no backup, and this script cannot
  # know which of a VM's other volumes (if any) is meant for backups. Keep an eye on free space, or
  # pass -BackupDir D:\dbbackupdaily once a data volume exists. @CleanupTime = 168 on the scheduled
  # backups means files older than a week are removed, which bounds the growth.
  Write-YcLog ('-BackupDir is on the system drive (' + $BackupDir + '). That is the default and it is fine, but watch free space on ' + $env:SystemDrive + ' - retention is 168 hours. Pass -BackupDir <volume>\dbbackupdaily when a data volume exists.') 'WARN'
}

# --- 1e. Service accounts and the chadmin account ------------------------------------------------
if (-not (Test-YcLocalAccountExists -Name 'chadmin')) {
  Write-YcLog ('PREFLIGHT REFUSED: the local account chadmin does not exist. It is required in SQLSYSADMINACCOUNTS and it is the identity the maintenance tasks run as. ' +
               'SQL setup validates SQLSYSADMINACCOUNTS and would fail the install after the download.') 'ERROR'
  Invoke-YcExit 2
}
Write-YcLog 'Local account chadmin exists.' 'OK'

function Get-YcSqlAdminAccounts {
  $accs = New-Object System.Collections.Generic.List[string]
  if ($SysadminAccounts -and $SysadminAccounts.Count -gt 0) {
    foreach ($a in $SysadminAccounts) { if ($a -and ($accs -notcontains $a)) { [void]$accs.Add($a) } }
    return $accs
  }
  try {
    $grp = [ADSI]'WinNT://./Administrators,group'
    foreach ($m in $grp.Invoke('Members')) {
      $path  = $m.GetType().InvokeMember('AdsPath', 'GetProperty', $null, $m, $null)
      $clean = $path -replace 'WinNT://', ''
      $parts = $clean -split '/'
      if ($parts.Count -ge 2) { $name = $parts[-2] + '\' + $parts[-1] } else { $name = $parts[-1] }
      if ($name -and ($accs -notcontains $name)) { [void]$accs.Add($name) }
    }
  } catch {
    Write-YcLog ('Could not enumerate the local Administrators group: ' + $_.Exception.Message) 'WARN'
  }
  if ($accs -notcontains $chadminLogin) { [void]$accs.Add($chadminLogin) }
  # Whoever runs this script (an interactive Administrator, or NT AUTHORITY\SYSTEM under cloud-init)
  # must be sysadmin too: creating the DBA database and installing the maintenance solution happen
  # as that identity after setup, and SYSTEM is not in the local Administrators group.
  $me = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
  if ($me -and ($accs -notcontains $me)) { [void]$accs.Add($me) }
  return $accs
}
$adminAccounts = Get-YcSqlAdminAccounts
if ($adminAccounts.Count -eq 0) {
  Write-YcLog 'PREFLIGHT REFUSED: SQLSYSADMINACCOUNTS resolved to an empty list.' 'ERROR'
  Invoke-YcExit 2
}
Write-YcLog ('SQLSYSADMINACCOUNTS will be: ' + ($adminAccounts -join ', '))
if (-not $SysadminAccounts -and ($adminAccounts | Where-Object { $_ -match '(?i)domain admins|enterprise admins' })) {
  Write-YcLog 'The local Administrators group contains a domain admin group, so the whole domain-admin population becomes SQL sysadmin. Pass -SysadminAccounts to bound this explicitly.' 'WARN'
}

# --- 1f. .NET Framework baseline -----------------------------------------------------------------
$netRelease = Get-YcNetFxRelease
$netName    = Get-YcNetFxName -Release $netRelease
# SQL Server 2022 and 2025 both document ".NET Framework 4.7.2". SQL Server 2016 and 2017 document
# ".NET Framework 4.6". The 2019 requirements page states only that the minimum OS includes the
# minimum .NET Framework, so 4.6 is used as the floor there too rather than inventing a number.
$sqlOnlyMin = Get-YcRequiredNetRelease -SqlVersion $VersionInt -NeedDbatools $false

# SQL Server is NOT the only consumer of .NET here, and treating it as the only one is what
# broke x16B on 2026-08-29. dbatools.library 2023.x and later ship Microsoft.Data.SqlClient,
# which binds System.Data.Common 4.2.0.0 - a .NET Standard 2.0 facade that a stock Windows
# Server 2016 (in-box .NET 4.6.2, Release=394802) does not have. So this run passed the SQL
# 2019 floor of 4.6, skipped the .NET install in PHASE 2a, and then died in PHASE 2d with
#     Couldn't import ...\dbatools.library\2026.5.3\desktop\lib\Microsoft.Data.SqlClient.dll
#     Could not load file or assembly 'System.Data.Common, Version=4.2.0.0' ...
# and, because -Maintenance was on, exit 9 - a SQL Server that installed fine but has no
# backups. The floor must be the HIGHER of the two consumers, not just SQL Server's.
$script:WantDbatools = ($Maintenance -eq 'on') -or
                       (Test-Path -LiteralPath 'C:\Scripts\Dbatools-Install.ps1') -or
                       [bool](Get-Module -ListAvailable -Name dbatools -ErrorAction SilentlyContinue)
$netMin     = Get-YcRequiredNetRelease -SqlVersion $VersionInt -NeedDbatools $script:WantDbatools
$netMinName = Get-YcNetFxName -Release $netMin
if ($netMin -gt $sqlOnlyMin) {
  Write-YcLog ('SQL Server ' + $Version + ' only requires .NET Framework ' + (Get-YcNetFxName -Release $sqlOnlyMin) +
    ', but dbatools.library requires 4.7.2 (Microsoft.Data.SqlClient binds System.Data.Common 4.2.0.0). ' +
    'Raising the floor to 4.7.2 so Import-Module dbatools does not fail after the engine is already installed.') 'INFO'
}
Write-YcLog ('.NET Framework installed: ' + $netName + ' (Release=' + $netRelease + '); this run requires ' + $netMinName + '.')

$script:NetFxNeedsInstall = ($netRelease -lt $netMin)

# SAY IT UP FRONT, KEYED ON THE OS, not four phases later when it is already happening.
# Windows Server 2016 (build 14393) ships .NET 4.6.2 in the box; every later Server ships
# 4.7.2 or 4.8. So on 2016 - and ONLY on 2016 - this run installs .NET 4.8 and the machine
# MUST reboot before SQL setup will pass its own RebootRequiredCheck rule. That reboot is
# where the resume task lives, and a broken resume task is exactly what left SQL half
# installed on both 2016 VMs on 2026-08-31 (fixed in the same release as this note).
# An operator watching the log deserves to know that before the reboot, not after it.
$osBuild = 0
try { $osBuild = [int](Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).BuildNumber }
catch { try { $osBuild = [int][Environment]::OSVersion.Version.Build } catch { $osBuild = 0 } }
if ($osBuild -le 14393) {
  if ($script:NetFxNeedsInstall) {
    Write-YcLog ('OS is Windows Server 2016 (build ' + $osBuild + '), which ships .NET Framework 4.6.2. ' +
      'THIS RUN WILL INSTALL .NET FRAMEWORK 4.8 AND REBOOT ONCE, then resume itself automatically ' +
      'via the "' + $script:YcResumeTask + '" scheduled task. Expect the SSH session to drop. ' +
      'Pass -NoReboot to stop before the reboot instead.') 'WARN'
  } else {
    Write-YcLog ('OS is Windows Server 2016 (build ' + $osBuild + '), but .NET ' + $netName +
      ' is already present - no .NET install and no reboot needed on this run.') 'OK'
  }
} elseif ($osBuild -gt 0) {
  Write-YcLog ('OS build ' + $osBuild + ' ships .NET Framework 4.7.2 or later in the box' +
    $(if ($script:NetFxNeedsInstall) { ', but the installed release is below this run''s floor so .NET 4.8 will still be installed' } else { ' - no .NET install and no reboot needed on this run' }) + '.') $(if ($script:NetFxNeedsInstall) { 'WARN' } else { 'OK' })
}
# Anti-loop. The marker is written when .NET 4.8 installs and asks for a restart. If we come back
# after that restart and .NET is STILL below the floor, installing it a second time will not help -
# something else is wrong (a blocked servicing stack, a pending CBS operation, a policy). Stop and
# say so, rather than reboot-installing forever.
if ($script:NetFxNeedsInstall -and (Test-Path -LiteralPath $script:NetFxMarker)) {
  $when = (Get-Content -LiteralPath $script:NetFxMarker -Raw -ErrorAction SilentlyContinue)
  Write-YcLog ('PREFLIGHT REFUSED: .NET Framework 4.8 was already installed and the machine was already restarted for it (' + ($when -replace '\s+',' ') + '), but the registry still reports ' + $netName + ' (Release=' + $netRelease + '). Installing it again will not help. Check the Windows servicing stack: "dism /online /cleanup-image /restorehealth", then the .NET setup log in %TEMP%. Delete ' + $script:NetFxMarker + ' to let this run try again anyway.') 'ERROR'
  Invoke-YcExit 2
}
if (-not $script:NetFxNeedsInstall) { Remove-Item -LiteralPath $script:NetFxMarker -Force -ErrorAction SilentlyContinue }
if ($script:NetFxNeedsInstall) {
  Write-YcLog ('.NET Framework ' + $netMinName + ' or later is missing. PHASE 2 will install .NET Framework 4.8 before setup runs, because SQL setup installing it itself sets a pending reboot that then trips its own RebootRequiredCheck rule on the next step.') 'WARN'
}

# --- 1g. Free disk -------------------------------------------------------------------------------
# SQL Server documents "a minimum of 6 GB of available hard drive space" on the system drive, plus
# whatever the media itself needs.
# 12 GB is the budget for a full run: ~1.5 GB of downloaded media, the extracted setup, the engine,
# a CU and SSMS. A CONFIGURE-ONLY run - the instance already exists and -Force was not passed -
# downloads nothing and installs nothing, so charging it the full budget refused runs that could
# not possibly have run out of space. Look the instance up here (a registry read; the authoritative
# detection still happens in 1i) and charge the honest number.
$willInstall = $true
if (-not $Force) {
  foreach ($r in 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Microsoft SQL Server') {
    if (Get-YcRegValueOrNull -Path ($r + '\Instance Names\SQL') -Name $InstanceName) { $willInstall = $false; break }
  }
}
$needSysGB   = if (-not $willInstall) { 2 } elseif ($IsoPath) { 8 } else { 12 }
if (-not $willInstall) {
  Write-YcLog ('Instance ' + $InstanceName + ' already exists and -Force was not supplied, so this run installs nothing. Free-disk requirement lowered to ' + $needSysGB + ' GB.')
}
$freeSysGB   = Get-YcFreeSpaceGB -PathOrDrive ($env:SystemDrive + '\')
$freeDataGB  = Get-YcFreeSpaceGB -PathOrDrive $DataDir
Write-YcLog ('Free space: system drive ' + $freeSysGB + ' GB (need ' + $needSysGB + ' GB), DataDir volume ' + $freeDataGB + ' GB.')
if ($freeSysGB -ge 0 -and $freeSysGB -lt $needSysGB) {
  # -Force is documented as the override for every other preflight on this script, but this one
  # ignored it, so a deliberate engine-only install on a 40 GB template disk - which genuinely
  # needs far less than the 12 GB budgeted for a full install with media, patching and SSMS -
  # could not be run at all. -Force now downgrades this to a WARN. It does NOT make the disk
  # bigger: if setup really does run out of space it fails at PHASE 4 with its own error.
  if ($Force) {
    Write-YcLog ('Only ' + $freeSysGB + ' GB free on ' + $env:SystemDrive + ' and this run wants ' + $needSysGB +
                 ' GB, but -Force was supplied so the run continues. If SQL setup exhausts the disk it will fail ' +
                 'in PHASE 4 with a setup error instead of here.') 'WARN'
  } else {
    Write-YcLog ('PREFLIGHT REFUSED: only ' + $freeSysGB + ' GB free on ' + $env:SystemDrive + '. SQL Server documents a 6 GB minimum on the system drive, and the media needs several GB more. Pass -Force to override this check.') 'ERROR'
    Invoke-YcExit 2
  }
}
if ($freeDataGB -ge 0 -and $freeDataGB -lt 10) {
  Write-YcLog ('Only ' + $freeDataGB + ' GB free on the -DataDir volume. tempdb sizing below is reduced to fit.') 'WARN'
}

# --- 1h. Pending reboot ---------------------------------------------------------------------------
$pending = Get-YcPendingRebootReasons
if ($pending.Count -gt 0) {
  Write-YcLog ('A reboot is pending: ' + ($pending -join '; ') + '. SQL Server setup fails its RebootRequiredCheck rule in this state.') 'WARN'
  if ($script:DoReboot) {
    $resumed = Set-YcSqlResumeTask -Why 'a reboot was already pending before this run started'
    Write-YcLog ('Rebooting now.' + $(if ($resumed) { ' The run resumes by itself after the reboot.' } else { ' Re-run install-sql after the machine comes back.' })) 'WARN'
    Add-YcSummary 'Result' $(if ($resumed) { 'Rebooted to clear a pending reboot - resumes automatically' } else { 'Rebooted to clear a pending reboot - re-run install-sql' })
    Set-Content -LiteralPath 'C:\Scripts\install-sql.reboot-required' -Value ((Get-Date).ToString('s') + ' pending reboot before install: ' + ($pending -join '; ')) -Encoding ASCII
    Stop-YcLog 0
    Restart-Computer -Force
    exit 0
  }
  Write-YcLog 'PREFLIGHT REFUSED: a reboot is pending and -NoReboot was supplied, so this run will not clear it. Restart the machine and run install-sql again, or drop -NoReboot and it will do both by itself. Refusing here rather than failing in the middle of setup after a 1.2 GB download.' 'ERROR'
  Invoke-YcExit 2
}
Write-YcLog 'No pending reboot.' 'OK'

# --- 1i. Existing instance: idempotency ------------------------------------------------------------
$script:InstanceExists = $false
foreach ($root in 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Microsoft SQL Server') {
  $names = Get-YcRegValueOrNull -Path ($root + '\Instance Names\SQL') -Name $InstanceName
  if ($names) { $script:InstanceExists = $true; $script:InstanceId = [string]$names }
}
$doSetup = $true
if ($script:InstanceExists) {
  Write-YcLog ('Instance ' + $InstanceName + ' already exists on this machine (InstanceID=' + $script:InstanceId + ').') 'WARN'
  # An instance that already exists can have outlived a computer rename. Detect it and say so -
  # do NOT repair it here. The repair restarts SQL Server and has to refuse clustered, AlwaysOn
  # and replicated instances, which is not something an installer should decide mid-run.
  [void](Write-YcSqlNameDriftWarning -Drift (Get-YcSqlNameDrift -Target $(if ($InstanceName -eq 'MSSQLSERVER') { '.' } else { '.\' + $InstanceName })) -InstanceName $InstanceName)
  if ($Force) {
    Write-YcLog '-Force was supplied, so setup will run again. ACTION=Install against an existing instance normally fails - this is your choice.' 'WARN'
  } else {
    Write-YcLog 'Taking the configure-only path: media, setup and patching are SKIPPED; client tooling, instance configuration, network, maintenance and verification still run. Pass -Force to re-run setup.' 'OK'
    $doSetup = $false
  }
}
# Create the backup directory NOW rather than at PHASE 11. If the path is unusable this run should
# find out before it downloads 1.2 GB of media, and the directory existing early means nothing
# downstream has to wonder whether it is there. The ACL is granted at PHASE 11, because the principal
# that needs it - the Database Engine service SID - does not exist until the engine is installed.
if (-not (Test-Path -LiteralPath $BackupDir)) {
  try {
    New-Item -ItemType Directory -Path $BackupDir -Force -ErrorAction Stop | Out-Null
    Write-YcLog ('Created backup directory ' + $BackupDir + '.') 'OK'
  } catch {
    Write-YcLog ('PREFLIGHT REFUSED: could not create -BackupDir ' + $BackupDir + ': ' + $_.Exception.Message) 'ERROR'
    Invoke-YcExit 2
  }
} else {
  Write-YcLog ('Backup directory ' + $BackupDir + ' already exists.') 'OK'
}

# --- 1j. Orphaned data files from a previous FAILED install -------------------------------------
# SQL Server setup refuses to create a database file that already exists. A run that dies part way
# through - and there have been several on this fleet - leaves tempdb.mdf and friends behind, and
# every attempt after that fails with
#     Exit code (Decimal): -2061893586
#     The tempdb database file tempdb.mdf already exists in C:\SQLData\TempDB.
# which says nothing about the real problem and sent people looking at .NET, the network and the
# media instead. Observed on C25B 2026-08-29 15:07:22.
#
# Only orphans are touched: if the instance IS registered in the registry, these files belong to a
# real installation and nothing here goes near them. Files are MOVED to a timestamped folder beside
# them, never deleted, so a wrong call can be undone.
if ($doSetup -and -not $script:InstanceExists) {
  $instRootPre = Get-YcInstanceDataRoot -Root $DataDir -Instance $InstanceName
  $orphans = @()
  foreach ($sub in 'Data','Log','TempDB') {
    $d = Join-Path $instRootPre $sub
    if (Test-Path -LiteralPath $d) {
      $orphans += @(Get-ChildItem -LiteralPath $d -File -Include '*.mdf','*.ndf','*.ldf' -Recurse -ErrorAction SilentlyContinue)
    }
  }
  if ($orphans.Count -gt 0) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $quar  = Join-Path $instRootPre ('orphaned-' + $stamp)
    Write-YcLog ('Found ' + $orphans.Count + ' database file(s) under ' + $instRootPre + ' but NO registered instance named ' + $InstanceName + '. These are left over from an install that did not finish; SQL Server setup would refuse with "the tempdb database file tempdb.mdf already exists". Moving them to ' + $quar + ' - they are moved, not deleted.') 'WARN'
    try {
      New-Item -ItemType Directory -Path $quar -Force -ErrorAction Stop | Out-Null
      foreach ($o in $orphans) {
        Move-Item -LiteralPath $o.FullName -Destination (Join-Path $quar $o.Name) -Force -ErrorAction Stop
        Write-YcLog ('  moved ' + $o.FullName)
      }
      Write-YcLog ('Cleared ' + $orphans.Count + ' orphaned database file(s). Delete ' + $quar + ' by hand once this install is known good.') 'OK'
      Add-YcSummary 'Orphaned files' ($orphans.Count.ToString() + ' moved to ' + $quar)
    } catch {
      Write-YcLog ('PREFLIGHT REFUSED: could not move the orphaned database files out of the way: ' + $_.Exception.Message + '. Move or delete everything under ' + $instRootPre + ' by hand, then run install-sql again.') 'ERROR'
      Invoke-YcExit 2
    }
  }
}

Write-YcLog 'Preflight gate passed.' 'OK'

# ================================================================================================
# PHASE 2 - prerequisites (the half of the owner's complaint that comes BEFORE the engine)
# ================================================================================================
Write-YcPhase 2 'Prerequisites'

$needInternet = (-not $IsoPath) -or ($ClientTools -eq 'on') -or ($Ssms -eq 'on') -or (-not $OlaZipPath)
if ($needInternet) {
  if (Test-YcInternet) {
    Write-YcLog 'Outbound internet reachable.' 'OK'
  } else {
    Write-YcLog ('No outbound internet. This run needs it for: ' +
      $(if (-not $IsoPath) { 'the installation media; ' } else { '' }) +
      $(if ($ClientTools -eq 'on') { 'ODBC/OLE DB/sqlcmd/SqlServer module; ' } else { '' }) +
      $(if ($Ssms -eq 'on') { 'SSMS; ' } else { '' }) +
      $(if (-not $OlaZipPath) { 'the Ola Hallengren maintenance solution; ' } else { '' }) +
      'stage those locally (-IsoPath, -OlaZipPath) or fix egress.') 'ERROR'
    Invoke-YcExit 6
  }
}

# --- 2a. .NET Framework 4.8 ----------------------------------------------------------------------
if ($script:NetFxNeedsInstall) {
  if (-not (Test-Path -LiteralPath $WorkDir)) { New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null }
  $ndp = Join-Path $WorkDir 'NDP48-x86-x64-AllOS-ENU.exe'
  # Microsoft's own permanent link for the .NET Framework 4.8 offline installer.
  if (Get-YcVerifiedDownload -Url 'https://go.microsoft.com/fwlink/?linkid=2088631' -OutFile $ndp -ExpectSize $null -ExpectHash $null -Algo $null -MinBytes 50000000) {
    if (Test-YcDownloadedFile -Path $ndp -MinBytes 50000000 -Kind 'executable') {
      Write-YcLog 'Installing .NET Framework 4.8 (NDP48-x86-x64-AllOS-ENU.exe /q /norestart)...'
      $p = Start-Process -FilePath $ndp -ArgumentList @('/q','/norestart') -Wait -PassThru
      # Documented .NET Framework redistributable return codes: 0 success, 1641 and 3010 success but
      # a restart is required, 5100 the machine does not meet system requirements.
      if ($p.ExitCode -eq 0) {
        Write-YcLog '.NET Framework 4.8 installed.' 'OK'
      } elseif ($p.ExitCode -eq 3010 -or $p.ExitCode -eq 1641) {
        Write-YcLog '.NET Framework 4.8 installed and a restart is required.' 'WARN'
        $script:YcRebootNeeded = $true
      } else {
        Write-YcLog ('.NET Framework 4.8 install FAILED (exit ' + $p.ExitCode + '). SQL Server ' + $Version + ' requires .NET ' + $netMinName + '.') 'ERROR'
        Invoke-YcExit 2
      }
      # DO NOT read the Release value yet when the installer asked for a restart. The registry is
      # only updated by the post-reboot servicing step, so on Server 2016 - where .NET 4.8 ALWAYS
      # returns 3010 - checking here reported "still 4.6.2" and exited 2 every single time, before
      # the reboot branch below was ever reached. Observed on x16B 2026-08-29 14:42:51. The correct
      # verification point is PHASE 1 of the NEXT run, which re-reads the Release value anyway; the
      # marker file below is what stops that turning into an install-reboot loop.
      if (-not $script:YcRebootNeeded) {
        $rel2 = Get-YcNetFxRelease
        if ($rel2 -lt $netMin) {
          Write-YcLog ('VERIFICATION FAILED: the installer reported success without asking for a restart, but the registry still reports Release=' + $rel2 + ' (' + (Get-YcNetFxName -Release $rel2) + ').') 'ERROR'
          Invoke-YcExit 2
        }
        Write-YcLog ('Verified: .NET Framework is now ' + (Get-YcNetFxName -Release $rel2) + '.') 'OK'
        Remove-Item -LiteralPath $script:NetFxMarker -Force -ErrorAction SilentlyContinue
      } else {
        Write-YcLog 'Not reading the .NET Release value yet - it is only updated by the servicing step that runs during the restart. PHASE 1 of the resumed run verifies it.'
      }
      if ($script:YcRebootNeeded) {
        Set-Content -LiteralPath $script:NetFxMarker -Value ((Get-Date).ToString('s') + ' NDP48 returned ' + $p.ExitCode + ' (restart required)') -Encoding ASCII
        if ($script:DoReboot) {
          Set-Content -LiteralPath 'C:\Scripts\install-sql.reboot-required' -Value ((Get-Date).ToString('s') + ' reboot required after .NET Framework 4.8') -Encoding ASCII
          $resumed = Set-YcSqlResumeTask -Why '.NET Framework 4.8 needs a reboot before SQL setup will pass its RebootRequiredCheck rule'
          Write-YcLog ('Rebooting now.' + $(if ($resumed) { ' The run resumes by itself after the reboot.' } else { ' Re-run install-sql after the machine comes back.' })) 'WARN'
          Add-YcSummary 'Result' $(if ($resumed) { 'Rebooted after .NET Framework install - resumes automatically' } else { 'Rebooted after .NET Framework install - re-run install-sql' })
          Stop-YcLog 0
          Restart-Computer -Force
          exit 0
        }
        Write-YcLog 'PREFLIGHT REFUSED: .NET Framework wants a reboot, SQL setup will fail its RebootRequiredCheck rule, and -NoReboot was supplied. Restart the machine and run install-sql again, or drop -NoReboot and it will reboot and resume by itself.' 'ERROR'
        Invoke-YcExit 2
      }
    } else {
      Invoke-YcExit 2
    }
  } else {
    Write-YcLog 'Could not download the .NET Framework 4.8 offline installer.' 'ERROR'
    Invoke-YcExit 2
  }
}

# --- 2b. Windows features that SQL Server setup depends on ---------------------------------------
# SQL setup requires .NET Framework 3.5 only for specific optional features; the Database Engine
# does not. What matters on a Core/minimal image is that the servicing stack is healthy, which the
# pending-reboot check above already covers. NetFx3 is installed only when a feature needs it.
$needNetFx3 = ($featUpper -contains 'AS' -or $featUpper -contains 'IS' -or $featUpper -contains 'MDS' -or $featUpper -contains 'DQC')
if ($needNetFx3) {
  try {
    $f = Get-WindowsFeature -Name NET-Framework-Features
    if ($f -and -not $f.Installed) {
      Write-YcLog 'Installing the NET-Framework-Features (.NET 3.5) Windows feature, required by the selected FEATURES...'
      $r = Install-WindowsFeature -Name NET-Framework-Features
      if (-not $r.Success) {
        Write-YcLog ('Install-WindowsFeature NET-Framework-Features failed: ' + $r.ExitCode) 'ERROR'
        Invoke-YcExit 2
      }
      if ($r.RestartNeeded -eq 'Yes') { $script:YcRebootNeeded = $true }
      Write-YcLog 'NET-Framework-Features installed.' 'OK'
    } else {
      Write-YcLog 'NET-Framework-Features already present.' 'OK'
    }
  } catch {
    Write-YcLog ('Could not evaluate Windows features (' + $_.Exception.Message + '). Continuing - the Database Engine itself does not need .NET 3.5.') 'WARN'
  }
}

# --- 2c. Power plan ------------------------------------------------------------------------------
if ($PowerPlan -eq 'on') { [void](Set-YcHighPerformancePowerPlan) }

# --- 2d. dbatools ("the dbaas package") and the SqlServer module -----------------------------------
function Install-YcPsModule {
  param([string]$Name,[string]$MinimumVersion)
  $have = Get-Module -ListAvailable -Name $Name | Sort-Object Version -Descending | Select-Object -First 1
  if ($have -and (-not $MinimumVersion -or $have.Version -ge [version]$MinimumVersion)) {
    Write-YcLog ($Name + ' already present, version ' + $have.Version + '.') 'OK'
    return $true
  }
  # A staged nupkg dropped by Dbatools-Install.ps1 is preferred on an egress-restricted VM.
  try {
    if (-not (Get-PackageProvider -Name NuGet -ListAvailable)) {
      Write-YcLog 'Bootstrapping the NuGet package provider...'
      Install-PackageProvider -Name NuGet -MinimumVersion '2.8.5.201' -Force | Out-Null
    }
  } catch {
    Write-YcLog ('Could not bootstrap the NuGet provider: ' + $_.Exception.Message) 'WARN'
  }
  try {
    Write-YcLog ('Installing the ' + $Name + ' module for all users from the PowerShell Gallery...')
    Install-Module -Name $Name -Scope AllUsers -Force -AllowClobber
  } catch {
    Write-YcLog ('Install-Module ' + $Name + ' failed: ' + $_.Exception.Message) 'ERROR'
    return $false
  }
  $have = Get-Module -ListAvailable -Name $Name | Sort-Object Version -Descending | Select-Object -First 1
  if (-not $have) {
    Write-YcLog ($Name + ' is still not available after Install-Module.') 'ERROR'
    return $false
  }
  if ($MinimumVersion -and $have.Version -lt [version]$MinimumVersion) {
    Write-YcLog ($Name + ' is version ' + $have.Version + ', below the required ' + $MinimumVersion + '.') 'ERROR'
    return $false
  }
  Write-YcLog ($Name + ' installed, version ' + $have.Version + '.') 'OK'
  return $true
}

$script:DbatoolsOk = $false
if (Test-Path -LiteralPath 'C:\Scripts\Dbatools-Install.ps1') {
  if (-not (Get-Module -ListAvailable -Name dbatools)) {
    Write-YcLog 'dbatools is not installed; running the toolkit''s own C:\Scripts\Dbatools-Install.ps1 first (this is the "requires dbaas package before" step).'
    try {
      & 'C:\Scripts\Dbatools-Install.ps1' | Out-Null
      Write-YcLog ('Dbatools-Install.ps1 exit code: ' + $LASTEXITCODE)
    } catch {
      Write-YcLog ('Dbatools-Install.ps1 threw: ' + $_.Exception.Message) 'WARN'
    }
  }
}
if (Install-YcPsModule -Name 'dbatools' -MinimumVersion '2.0.0') {
  try {
    Import-Module dbatools
    # A freshly installed instance only has a self-signed certificate, and the bundled
    # Microsoft.Data.SqlClient defaults to Encrypt=Mandatory with certificate validation, so
    # same-box admin connections otherwise fail with an untrusted-chain error.
    Set-DbatoolsConfig -FullName sql.connection.trustcert -Value $true
    $script:DbatoolsOk = $true
    Write-YcLog 'dbatools imported.' 'OK'
  } catch {
    Write-YcLog ('dbatools installed but Import-Module failed: ' + $_.Exception.Message) 'ERROR'
  }
}
if (-not $script:DbatoolsOk -and $Maintenance -eq 'on') {
  Write-YcLog 'dbatools is unusable and -Maintenance is on. The maintenance solution cannot be installed, which means no backups - refusing to continue and report success.' 'ERROR'
  Invoke-YcExit 9
}

# --- 2e. Instant file initialization and Lock pages in memory decisions ----------------------------
# Instant file initialization is requested through setup's own SQLSVCINSTANTFILEINIT for a new
# install (setup grants SE_MANAGE_VOLUME_NAME to the Database Engine service SID). For the
# configure-only path the right is granted directly here instead.
if ($InstantFileInit -eq 'on' -and -not $doSetup) {
  [void](Grant-YcUserRight -Right 'SeManageVolumePrivilege' -Principal $sqlSvcSid)
}
if ($LockPagesInMemory -eq 'on') {
  # Microsoft recommends assigning this to the SERVICE SID rather than to a named account, so the
  # grant survives a service-account change.
  if (Grant-YcUserRight -Right 'SeLockMemoryPrivilege' -Principal $sqlSvcSid) {
    Write-YcLog 'Lock pages in memory granted to the Database Engine service SID. It takes effect at the next instance restart.' 'OK'
  } else {
    Write-YcLog 'Lock pages in memory could not be granted.' 'WARN'
  }
}

# ================================================================================================
# PHASE 3 - media acquisition and validation
# ================================================================================================
$driveLetter = $null
if ($doSetup) {
  Write-YcPhase 3 'Media acquisition and validation'

  # Per-version Evaluation media. Primary tier resolves the download from Microsoft's own SSEI
  # bootstrapper manifest; the fallback tier is a pinned URL + checksum. When the primary tier does
  # not produce a verified download the fall through is logged at WARN, loudly, because the pinned
  # hashes go stale the moment Microsoft reissues an ISO.
  $SqlVersionMap = @{
    '2016' = @{ Bootstrap='https://download.microsoft.com/download/A/C/6/AC6F2802-4CC4-40B2-B333-395A4291EF29/SQLServer2016-SSEI-Eval.exe'
                IsoName='SQLServer2016SP2-FullSlipstream-x64-ENU.iso'
                FallbackUrl='https://download.microsoft.com/download/4/1/A/41AD6EDE-9794-44E3-B3D5-A1AF62CD7A6F/sql16_sp2_dlc/en-us/SQLServer2016SP2-FullSlipstream-x64-ENU.iso'
                FallbackHash='6309d729a0f063d11c0bb7f840f1069483406755'; FallbackSize=2970245120; FallbackAlgo='SHA1' }
    '2017' = @{ Bootstrap='https://go.microsoft.com/fwlink/?linkid=853015'
                IsoName='SQLServer2017-x64-ENU.iso'
                FallbackUrl='https://download.microsoft.com/download/E/F/2/EF23C21D-7860-4F05-88CE-39AA114B014B/SQLServer2017-x64-ENU.iso'
                FallbackHash='f6491f577fe476e9c964eec09084b1a3091ee875'; FallbackSize=1546242048; FallbackAlgo='SHA1' }
    '2019' = @{ Bootstrap='https://go.microsoft.com/fwlink/?linkid=866664'
                IsoName='SQLServer2019-x64-ENU.iso'
                FallbackUrl='https://download.microsoft.com/download/8/4/c/84c6c430-e0f5-476d-bf43-eaaa222a72e0/SQLServer2019-x64-ENU.iso'
                FallbackHash='43d3909de13e1ae6d184fd55fe63ebc0486a9c07'; FallbackSize=1433972736; FallbackAlgo='SHA1' }
    '2022' = @{ Bootstrap='https://go.microsoft.com/fwlink/?linkid=2215202'
                IsoName='SQLServer2022-x64-ENU.iso'
                FallbackUrl='https://download.microsoft.com/download/3/8/d/38de7036-2433-4207-8eae-06e247e17b25/SQLServer2022-x64-ENU.iso'
                FallbackHash='3f0c358fa28fceb7de850adc598509d034fd4ef4'; FallbackSize=1163051008; FallbackAlgo='SHA1' }
    '2025' = @{ Bootstrap='https://aka.ms/sql2025eval'
                IsoName='SQLServer2025-x64-ENU.iso'
                FallbackUrl='https://download.microsoft.com/download/dea8c210-c44a-4a9d-9d80-0c81578860c5/ENU/SQLServer2025-x64-ENU.iso'
                FallbackHash='439402edebf34cdee8d7c231e761077fbc23c70fceff92910854ac6e42f09087'; FallbackSize=1265686528; FallbackAlgo='SHA256' }
  }

  function Get-YcAsciiStrings {
    param([byte[]]$Bytes,[int]$MinLen = 6)
    $s = [System.Text.Encoding]::GetEncoding(28591).GetString($Bytes)
    $rx = [System.Text.RegularExpressions.Regex]::new('[\x20-\x7E]{' + $MinLen + ',}')
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($m in $rx.Matches($s)) { [void]$out.Add($m.Value) }
    return $out
  }

  function Get-YcSqlManifestEntry {
    param([System.Collections.Generic.List[string]]$Lines,[string]$TargetFileName)
    $needle = '<FileName>' + $TargetFileName + '</FileName>'
    for ($i = 0; $i -lt $Lines.Count; $i++) {
      if ($Lines[$i].Contains($needle)) {
        $root = $null; $hash = $null
        $jStart = [Math]::Max(0, $i - 5)
        for ($j = $i - 1; $j -ge $jStart; $j--) {
          if (-not $hash -and $Lines[$j] -match '<FileHash>(.+)</FileHash>')         { $hash = $Matches[1] }
          if (-not $root -and $Lines[$j] -match '<DownloadRoot>(.+)</DownloadRoot>') { $root = $Matches[1] }
        }
        $size = $null
        $kEnd = [Math]::Min($Lines.Count, $i + 4000)
        for ($k = $i; $k -lt $kEnd; $k++) {
          if ($Lines[$k] -match '<FileSize>(\d+)</FileSize>') { $size = [int64]$Matches[1]; break }
        }
        if ($root -and $hash -and $size) {
          $algo = if ($hash.Length -eq 64) { 'SHA256' } elseif ($hash.Length -eq 40) { 'SHA1' } else { $null }
          if ($algo) { return [PSCustomObject]@{ Url = ($root + '/' + $TargetFileName); Hash = $hash; Size = $size; Algo = $algo } }
        }
      }
    }
    return $null
  }

  if ($IsoPath) {
    if (-not (Test-Path -LiteralPath $IsoPath -PathType Leaf)) {
      Write-YcLog ('-IsoPath does not exist or is not a file: ' + $IsoPath) 'ERROR'
      Invoke-YcExit 3
    }
    if (-not (Test-YcDownloadedFile -Path $IsoPath -MinBytes 500000000 -Kind 'ISO')) { Invoke-YcExit 3 }
    $script:YcIsoFile = (Resolve-Path -LiteralPath $IsoPath).Path
    # Identity cross-check, reported but NOT fatal. A staged ISO that matches the pinned checksum is
    # provably the image this script was written against. A mismatch is not automatically wrong -
    # a newer reissue or a different service pack level is a legitimate thing to stage - so it is a
    # WARN that names the difference instead of a refusal that blocks a valid install.
    $vinfoStaged = $SqlVersionMap[$Version]
    if ($vinfoStaged -and $vinfoStaged.FallbackHash -and $vinfoStaged.FallbackAlgo) {
      $hStaged = (Get-FileHash -Path $script:YcIsoFile -Algorithm $vinfoStaged.FallbackAlgo).Hash
      if ($hStaged -eq $vinfoStaged.FallbackHash.ToUpperInvariant()) {
        Write-YcLog ('Staged ISO identity confirmed: ' + $vinfoStaged.FallbackAlgo + '=' + $hStaged + ' matches the ' + $vinfoStaged.IsoName + ' checksum pinned in this script.') 'OK'
      } else {
        Write-YcLog ('Staged ISO is structurally valid but is NOT the image pinned in this script (' + $vinfoStaged.FallbackAlgo + '=' + $hStaged + ', pinned ' + $vinfoStaged.FallbackHash.ToUpperInvariant() + '). That is fine for a newer reissue or a different service pack level - just be sure it is the media you meant.') 'WARN'
      }
    }
    Write-YcLog ('Using supplied -IsoPath (download skipped): ' + $script:YcIsoFile) 'OK'
  } else {
    $vinfo = $SqlVersionMap[$Version]
    if (-not (Test-Path -LiteralPath $WorkDir)) { New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null }
    $isoOut = Join-Path $WorkDir $vinfo.IsoName
    $dynOk = $false

    # Before touching the network AT ALL: is the ISO already in $WorkDir from a previous run, and is
    # it genuinely the right, complete image? Re-fetching 2.9 GB because nobody looked is the single
    # most expensive thing this script can do, and the old code did exactly that on every run - the
    # fallback tier even deleted the existing file first. The bar for reuse is the same bar a fresh
    # download has to clear: pinned checksum, exact size, and the ISO 9660 structure check.
    if (Test-Path -LiteralPath $isoOut -PathType Leaf) {
      Write-YcLog ($isoOut + ' is already present - verifying it before deciding whether to download anything.')
      $existingVerdict = Get-YcFileVerdict -Path $isoOut -ExpectSize $vinfo.FallbackSize -ExpectHash $vinfo.FallbackHash -Algo $vinfo.FallbackAlgo -MinBytes 500000000
      if ($existingVerdict -and (Test-YcDownloadedFile -Path $isoOut -MinBytes 500000000 -Kind 'ISO')) {
        Write-YcLog ('MEDIA DOWNLOAD SKIPPED: the ISO already in ' + $WorkDir + ' is correct (' + $existingVerdict + ') and structurally complete.') 'OK'
        Add-YcSummary 'Media' ('reused the existing ' + $vinfo.IsoName + ' - no download')
        $dynOk = $true
      } else {
        Write-YcLog ('The ISO already in ' + $WorkDir + ' could not be proved correct against the pinned checksum, so the normal acquisition path runs. It may still be matched against the CURRENT manifest checksum below, which is the better test when Microsoft has reissued the image.') 'WARN'
      }
    }

    if (-not $dynOk) {
    Write-YcLog ('Resolving the SQL Server ' + $Version + ' Evaluation ISO (primary tier: manifest inside Microsoft''s own SSEI bootstrapper).')
    try {
      $bootExe = Join-Path $WorkDir ('sql-ssei-' + $Version + '.exe')
      if (Get-YcVerifiedDownload -Url $vinfo.Bootstrap -OutFile $bootExe -ExpectSize $null -ExpectHash $null -Algo $null -MinBytes 100000) {
        if (Test-YcDownloadedFile -Path $bootExe -MinBytes 100000 -Kind 'executable') {
          $bytes = [System.IO.File]::ReadAllBytes($bootExe)
          $lines = Get-YcAsciiStrings -Bytes $bytes -MinLen 6
          $entry = Get-YcSqlManifestEntry -Lines $lines -TargetFileName $vinfo.IsoName
          if ($entry) {
            Write-YcLog ('Manifest resolved: URL=' + $entry.Url + ' size=' + $entry.Size + ' ' + $entry.Algo + '=' + $entry.Hash)
            if (Get-YcVerifiedDownload -Url $entry.Url -OutFile $isoOut -ExpectSize $entry.Size -ExpectHash $entry.Hash -Algo $entry.Algo -MinBytes 500000000) { $dynOk = $true }
          } else {
            Write-YcLog ('No "' + $vinfo.IsoName + '" entry found in the bootstrapper manifest.') 'WARN'
          }
        }
      }
    } catch {
      Write-YcLog ('Primary (dynamic) media source failed: ' + $_.Exception.Message) 'WARN'
    }
    }
    if (-not $dynOk) {
      Write-YcLog ('MEDIA FALLBACK IN USE: the dynamic manifest tier produced nothing, so this install depends entirely on the pinned URL and checksum for ' + $Version +
                   '. Those were captured by hand and go stale whenever Microsoft reissues an ISO - if this fails, refresh them or stage the ISO and use -IsoPath.') 'WARN'
      # The old code deleted any existing ISO here before falling back, which threw away a perfectly
      # good 2.9 GB file every time the manifest tier had a bad day. Get-YcVerifiedDownload now
      # verifies what is on disk and only downloads when it cannot prove it, so deleting first is
      # both unnecessary and actively harmful.
      if (-not (Get-YcVerifiedDownload -Url $vinfo.FallbackUrl -OutFile $isoOut -ExpectSize $vinfo.FallbackSize -ExpectHash $vinfo.FallbackHash -Algo $vinfo.FallbackAlgo -MinBytes 500000000)) {
        Write-YcLog ('Could not download and verify the SQL Server ' + $Version + ' Evaluation ISO from either tier. Refusing to install from unverified media.') 'ERROR'
        Invoke-YcExit 3
      }
    }
    if (-not (Test-YcDownloadedFile -Path $isoOut -MinBytes 500000000 -Kind 'ISO')) { Invoke-YcExit 3 }
    $script:YcIsoFile = $isoOut
  }

  # --- mount ---
  $driveLetter = ''
  try {
    $existing = $null
    try { $existing = Get-DiskImage -ImagePath $script:YcIsoFile -ErrorAction Stop } catch { $existing = $null }
    if ($existing -and $existing.Attached) {
      Write-YcLog 'The ISO is already attached - reusing that mount (this run will not dismount it).' 'WARN'
    } else {
      Mount-DiskImage -ImagePath $script:YcIsoFile -ErrorAction Stop | Out-Null
      $script:YcIsoMounted = $true
      Write-YcLog ('Mounted ' + $script:YcIsoFile + ' - waiting for the volume to appear.')
    }
  } catch {
    Write-YcLog ('Failed to mount the ISO: ' + $_.Exception.Message) 'ERROR'
    Invoke-YcExit 3
  }
  # Resolution and proof are the same step: the letter is only accepted if setup.exe is really at
  # its root. See Get-YcIsoDriveLetter for why a single Get-Volume lookup was not enough.
  $driveLetter = Get-YcIsoDriveLetter -ImagePath $script:YcIsoFile -RequiredFile 'setup.exe' -TimeoutSec 60
  if (-not $driveLetter) {
    Write-YcLog 'Could not resolve the mounted ISO to a drive letter holding setup.exe. The image mounted but its media root is not SQL Server installation media, or the volume never surfaced.' 'ERROR'
    Invoke-YcExit 3
  }
  Write-YcLog ('ISO mounted at ' + $driveLetter + '; setup.exe present.') 'OK'
} else {
  Write-YcPhase 3 'Media acquisition and validation - SKIPPED (instance already exists)'
}

# ================================================================================================
# PHASE 4 - answer file generation and validation
# ================================================================================================
$genIni = $null
if ($doSetup) {
  Write-YcPhase 4 'Answer file generation'

  $cores  = [int](Get-CimInstance -ClassName Win32_ComputerSystem).NumberOfLogicalProcessors
  if ($cores -lt 1) { $cores = 1 }
  $ramMB  = [int]([Math]::Round((Get-CimInstance -ClassName Win32_ComputerSystem).TotalPhysicalMemory / 1MB))
  Write-YcLog ('Machine: ' + $cores + ' logical processors, ' + $ramMB + ' MB RAM.')

  # tempdb: the documented setup default is 8 files or the core count, whichever is lower. The
  # documented maximum initial data-file size and log-file size are both 1024 MB.
  $tdbCount = if ($TempDbFileCount -gt 0) { [Math]::Min($TempDbFileCount, $cores) } else { [Math]::Min(8, $cores) }
  if ($tdbCount -lt 1) { $tdbCount = 1 }
  $tdbSize = if ($TempDbFileSizeMB -gt 0) { [Math]::Min($TempDbFileSizeMB, 1024) } else { 1024 }
  if ($freeDataGB -ge 0) {
    # Never size tempdb into a full volume: keep total tempdb under a quarter of the free space.
    $budgetMB = [int](($freeDataGB * 1024) / 4)
    if ($budgetMB -gt 0 -and ($tdbSize * $tdbCount) -gt $budgetMB) {
      $tdbSize = [Math]::Max(64, [int]($budgetMB / $tdbCount))
      Write-YcLog ('tempdb data file size reduced to ' + $tdbSize + ' MB each to fit the free space on the -DataDir volume.') 'WARN'
    }
  }
  $tdbLogSize = [Math]::Min(1024, [Math]::Max(64, $tdbSize))

  # MAXDOP, per the documented max degree of parallelism guidance for a single NUMA node: up to the
  # logical processor count when there are 8 or fewer, otherwise 8.
  $maxDopValue = if ($MaxDop -gt 0) { $MaxDop } elseif ($cores -le 8) { $cores } else { 8 }

  # max server memory, per the documented manual server-memory guidance: leave the OS 1 GB, then
  # 1 GB for every 4 GB of RAM up to 16 GB, then 1 GB for every further 8 GB.
  function Get-YcRecommendedMaxMemoryMB {
    param([int]$TotalMB)
    $gb = [Math]::Floor($TotalMB / 1024)
    if ($gb -le 4) { return [Math]::Max(1024, $TotalMB - 1024) }
    $reserveGB = 1
    $reserveGB += [Math]::Floor([Math]::Min($gb, 16) / 4)
    if ($gb -gt 16) { $reserveGB += [Math]::Floor(($gb - 16) / 8) }
    $val = ($gb - $reserveGB) * 1024
    if ($val -lt 1024) { $val = 1024 }
    return [int]$val
  }
  $maxMemValue = if ($MaxServerMemoryMB -gt 0) { $MaxServerMemoryMB } else { Get-YcRecommendedMaxMemoryMB -TotalMB $ramMB }

  $instanceDataRoot = Get-YcInstanceDataRoot -Root $DataDir -Instance $InstanceName
  $sysadminLine     = ($adminAccounts | ForEach-Object { '"' + $_ + '"' }) -join ' '

  $securityLines = ''
  if ($SaPassword) {
    # SAPWD goes IN THE FILE, never on a command line. The old code appended /SAPWD="..." to the
    # setup.exe argument list, where any local user could read it out of Win32_Process.CommandLine.
    $securityLines = 'SECURITYMODE="SQL"' + "`r`n" + 'SAPWD="' + $SaPassword + '"'
  }
  $maxdopLines = ''
  $memoryLines = ''
  if ($VersionInt -ge 2019) {
    $maxdopLines = 'SQLMAXDOP="' + $maxDopValue + '"'
    # USESQLRECOMMENDEDMEMORYLIMITS is documented as incompatible with SQLMAXMEMORY/SQLMINMEMORY,
    # so exactly one of the two forms is emitted.
    if ($MaxServerMemoryMB -gt 0) { $memoryLines = 'SQLMAXMEMORY="' + $maxMemValue + '"' }
    else                          { $memoryLines = 'USESQLRECOMMENDEDMEMORYLIMITS="True"' }
  }

  $updateEnabled = if ($Patch -eq 'on' -and -not $CuPath) { 'True' } else { 'False' }
  $updateSource  = if ($Patch -eq 'on' -and -not $CuPath) { 'MU' } else { 'MU' }

  $replacements = @{
    '@@FEATURES@@'                 = $Features
    '@@INSTANCENAME@@'             = $InstanceName
    '@@AGTSVCACCOUNT@@'            = $agtSvcSid
    '@@SQLSVCACCOUNT@@'            = $sqlSvcSid
    '@@SQLSVCINSTANTFILEINIT@@'    = $(if ($InstantFileInit -eq 'on') { 'True' } else { 'False' })
    '@@SQLSYSADMINACCOUNTS@@'      = $sysadminLine
    '@@SECURITYMODE_LINES@@'       = $securityLines
    '@@MAXDOP_LINES@@'             = $maxdopLines
    '@@MEMORY_LINES@@'             = $memoryLines
    '@@SQLCOLLATION@@'             = $Collation
    '@@SQLUSERDBDIR@@'             = (Join-Path $instanceDataRoot 'Data')
    '@@SQLUSERDBLOGDIR@@'          = (Join-Path $instanceDataRoot 'Log')
    '@@SQLTEMPDBDIR@@'             = (Join-Path $instanceDataRoot 'TempDB')
    '@@SQLTEMPDBLOGDIR@@'          = (Join-Path $instanceDataRoot 'TempDB')
    '@@SQLBACKUPDIR@@'             = $BackupDir
    '@@SQLTEMPDBFILECOUNT@@'       = [string]$tdbCount
    '@@SQLTEMPDBFILESIZE@@'        = [string]$tdbSize
    '@@SQLTEMPDBFILEGROWTH@@'      = '512'
    '@@SQLTEMPDBLOGFILESIZE@@'     = [string]$tdbLogSize
    '@@SQLTEMPDBLOGFILEGROWTH@@'   = '512'
    '@@BROWSERSVCSTARTUPTYPE@@'    = $(if ($isDefaultInst) { 'Disabled' } else { 'Automatic' })
    '@@UPDATEENABLED@@'            = $updateEnabled
    '@@UPDATESOURCE@@'             = $updateSource
  }
  $ini = $tmplRaw
  foreach ($k in $replacements.Keys) { $ini = $ini.Replace($k, [string]$replacements[$k]) }

  $leftover = [regex]::Matches($ini, '@@[A-Z0-9_]+@@')
  if ($leftover.Count -gt 0) {
    $names = ($leftover | ForEach-Object { $_.Value } | Sort-Object -Unique) -join ', '
    Write-YcLog ('The answer-file template ' + $tmplPath + ' has token(s) this script does not fill: ' + $names + '. Refusing to hand a half-substituted file to setup.') 'ERROR'
    Invoke-YcExit 2
  }
  # Empty optional token lines leave blank lines; drop them so the file is clean and greppable.
  $ini = (($ini -split "`r?`n") | Where-Object { $_.Trim().Length -gt 0 }) -join "`r`n"

  # ACL the directory BEFORE writing anything into it, so the answer file is never briefly readable.
  $genDir = 'C:\Scripts\sql-configs'
  if (-not (Test-Path -LiteralPath $genDir)) { New-Item -ItemType Directory -Path $genDir -Force | Out-Null }
  $aclOk = $false
  try {
    # Documented .NET file-security API rather than a command-line ACL tool: inheritance is broken
    # with SetAccessRuleProtection and only SYSTEM (S-1-5-18) and BUILTIN\Administrators
    # (S-1-5-32-544) are granted, by well-known SID so it works on any UI language.
    $acl = Get-Acl -LiteralPath $genDir
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($r in @($acl.Access)) { [void]$acl.RemoveAccessRule($r) }
    foreach ($sid in @('S-1-5-18','S-1-5-32-544')) {
      $id = New-Object System.Security.Principal.SecurityIdentifier($sid)
      $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
        $id, [System.Security.AccessControl.FileSystemRights]::FullControl,
        ([System.Security.AccessControl.InheritanceFlags]::ObjectInherit -bor [System.Security.AccessControl.InheritanceFlags]::ContainerInherit),
        [System.Security.AccessControl.PropagationFlags]::None,
        [System.Security.AccessControl.AccessControlType]::Allow)
      $acl.AddAccessRule($rule)
    }
    Set-Acl -LiteralPath $genDir -AclObject $acl
    $aclOk = $true
  } catch {
    Write-YcLog ('Could not lock down ' + $genDir + ': ' + $_.Exception.Message) 'ERROR'
  }
  if (-not $aclOk) {
    if ($SaPassword) {
      Write-YcLog 'Refusing to write a file containing SAPWD into a directory whose permissions could not be set.' 'ERROR'
      Invoke-YcExit 2
    }
    Write-YcLog 'No sa password is in play, so continuing with the existing directory permissions.' 'WARN'
  } else {
    Write-YcLog ($genDir + ' restricted to SYSTEM and BUILTIN\Administrators (inheritance removed).') 'OK'
  }

  $genIni = Join-Path $genDir ('ConfigurationFile-' + $Version + '-' + $InstanceName + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.ini')
  # Default (ANSI) encoding rather than pure ASCII so a non-ASCII password or path is not mangled.
  [System.IO.File]::WriteAllText($genIni, $ini, [System.Text.Encoding]::Default)
  $script:YcGenIni = $genIni

  if (Select-String -Path $genIni -Pattern '^\s*PID\s*=' -Quiet) {
    Write-YcLog 'SAFETY ABORT: the generated answer file contains a PID= line. Evaluation-only policy violated - not installing.' 'ERROR'
    Invoke-YcExit 2
  }
  # Prove the file setup will actually read, rather than trusting the substitution.
  $check = Get-Content -LiteralPath $genIni
  foreach ($must in @('ACTION="Install"','IACCEPTSQLSERVERLICENSETERMS="True"',('INSTANCENAME="' + $InstanceName + '"'),('FEATURES=' + $Features))) {
    if (-not ($check | Where-Object { $_.Trim() -eq $must })) {
      Write-YcLog ('Answer file self-check FAILED: expected line not present: ' + $must) 'ERROR'
      Invoke-YcExit 2
    }
  }
  if ($SaPassword -and -not ($check | Where-Object { $_.Trim() -eq 'SECURITYMODE="SQL"' })) {
    Write-YcLog 'Answer file self-check FAILED: an sa password was supplied but SECURITYMODE="SQL" is not in the file. Setup would ignore the password and leave Windows-only auth.' 'ERROR'
    Invoke-YcExit 2
  }
  Write-YcLog ('Answer file generated and self-checked (Evaluation, no PID): ' + $genIni) 'OK'
  Write-YcLog ('  FEATURES=' + $Features)
  Write-YcLog ('  SQLCOLLATION=' + $Collation)
  Write-YcLog ('  SQLSYSADMINACCOUNTS=' + $sysadminLine)
  Write-YcLog ('  SECURITYMODE=' + $(if ($SaPassword) { 'SQL (mixed) - SAPWD is in the answer file only, never on a command line' } else { '(Windows authentication only)' }))
  Write-YcLog ('  tempdb: ' + $tdbCount + ' data files x ' + $tdbSize + ' MB, log ' + $tdbLogSize + ' MB')
  if ($VersionInt -ge 2019) { Write-YcLog ('  SQLMAXDOP=' + $maxDopValue + '  memory=' + $memoryLines) }
  Write-YcLog ('  UpdateEnabled=' + $updateEnabled + ' UpdateSource=' + $updateSource)
} else {
  Write-YcPhase 4 'Answer file generation - SKIPPED (instance already exists)'
}

# ================================================================================================
# PHASE 5 - engine install
# ================================================================================================
if ($doSetup) {
  Write-YcPhase 5 'SQL Server engine install'
  $setupExe = Join-Path ($driveLetter + '\') 'setup.exe'
  # Documented unattended form. /Q and the two acceptance settings live in the answer file; the
  # command line carries only the answer file path, so no secret is ever visible in the process
  # table. Reference: Install SQL Server from the command prompt.
  $setupArgs = @(('/ConfigurationFile="' + $genIni + '"'))
  Write-YcLog ('Running: "' + $setupExe + '" ' + ($setupArgs -join ' '))
  $sw = [Diagnostics.Stopwatch]::StartNew()
  $p = Start-Process -FilePath $setupExe -ArgumentList $setupArgs -Wait -PassThru
  $sw.Stop()
  $rc = $p.ExitCode
  Write-YcLog ('setup.exe exit code: ' + $rc + ' after ' + [int]$sw.Elapsed.TotalMinutes + ' minutes.')
  if ($rc -eq 0) {
    Write-YcLog 'SQL Server setup reported success.' 'OK'
  } elseif ($rc -eq 3010) {
    # 3010 is ERROR_SUCCESS_REBOOT_REQUIRED: success, but the machine must be restarted. It is
    # surfaced here rather than swallowed.
    Write-YcLog 'SQL Server setup succeeded but REQUIRES A REBOOT (exit 3010). This is surfaced, not swallowed - see the summary and C:\Scripts\install-sql.reboot-required.' 'WARN'
    $script:YcRebootNeeded = $true
    Set-Content -LiteralPath 'C:\Scripts\install-sql.reboot-required' -Value ((Get-Date).ToString('s') + ' SQL Server setup returned 3010 for instance ' + $InstanceName) -Encoding ASCII
  } else {
    # ---------------------------------------------------------------------------------------
    # A failed Microsoft Update check must not cost the whole install.
    # MEASURED 2026-08-30 on a 2022 clone: setup exited -2022834173 and the summary said
    #     Exit message: Setup encountered a failure while running job UpdateResult.
    #     Product Update Status: Failure to check for updates.
    # The engine never got a chance to install. UpdateEnabled=True makes the ENTIRE install
    # depend on Microsoft Update being reachable at that moment, and a cloud guest behind a
    # proxy, an offline WU, or a transient MU outage loses everything. PHASE 6 already patches
    # afterwards, so slipstreaming is a convenience, not a requirement. Retry once without it.
    # ---------------------------------------------------------------------------------------
    $muFail = $false
    try{
      $sum = 'C:\Program Files\Microsoft SQL Server\' + $VersionMajor + '0\Setup Bootstrap\Log\Summary.txt'
      if(Test-Path -LiteralPath $sum){
        $sumTxt = Get-Content -LiteralPath $sum -Raw -ErrorAction SilentlyContinue
        $muFail = ($sumTxt -match 'job UpdateResult') -or ($sumTxt -match 'Failure to check for updates')
      }
    }catch{}
    if($muFail -and $updateEnabled -eq 'True' -and (Test-Path -LiteralPath $genIni)){
      Write-YcLog ('Setup failed inside the Microsoft Update slipstream (job UpdateResult / "Failure to check for updates"), NOT in the engine install. ' +
                   'Microsoft Update is not reachable from this machine. Retrying ONCE with UpdateEnabled=False - PHASE 6 patches afterwards, which reaches the same build in one more step.') 'WARN'
      try{
        (Get-Content -LiteralPath $genIni) -replace '(?i)^UpdateEnabled=.*$','UpdateEnabled="False"' |
          Set-Content -LiteralPath $genIni -Encoding ASCII
        $sw2 = [Diagnostics.Stopwatch]::StartNew()
        $p2  = Start-Process -FilePath $setupExe -ArgumentList $setupArgs -Wait -PassThru
        $sw2.Stop()
        $rc  = $p2.ExitCode
        Write-YcLog ('setup.exe retry (UpdateEnabled=False) exit code: ' + $rc + ' after ' + [int]$sw2.Elapsed.TotalMinutes + ' minutes.')
      }catch{
        Write-YcLog ('the UpdateEnabled=False retry could not be started: ' + $_.Exception.Message) 'ERROR'
      }
    }
    # ---------------------------------------------------------------------------------------
    # THE REMOTE-SESSION FAILURE. Setup exits -2146233079 with
    #     Exit message: There was an error generating the XML document.
    # and Detail.txt names the real cause:
    #     Inner exception type: System.Security.Cryptography.CryptographicException
    #     Access is denied.
    # Setup encrypts values into its own settings XML through DPAPI, and DPAPI needs a loaded
    # user profile. An SSH or WinRM session does not have one, so setup dies before it installs
    # anything. It is not the media, the answer file, the account or the disk.
    #
    # MEASURED 2026-09-01: it killed SQL 2019 installs on two hosts, and the identical failure
    # was reproduced three times installing SQL Express by hand. In every case the SAME
    # configuration run by a SYSTEM SCHEDULED TASK succeeded first time - SYSTEM has a usable
    # profile. This payload already uses a SYSTEM one-shot task for the reboot-resume, so the
    # mechanism is proven here; this reuses it rather than failing the run.
    # ---------------------------------------------------------------------------------------
    if($rc -ne 0 -and $rc -ne 3010){
      $dpapi = $false
      try{
        $logRoot = 'C:\Program Files\Microsoft SQL Server\' + $VersionMajor + '0\Setup Bootstrap\Log'
        $sumTxt2 = ''
        $sumPath = Join-Path $logRoot 'Summary.txt'
        if(Test-Path -LiteralPath $sumPath){ $sumTxt2 = Get-Content -LiteralPath $sumPath -Raw -ErrorAction SilentlyContinue }
        if($sumTxt2 -match 'error generating the XML document'){ $dpapi = $true }
        if(-not $dpapi){
          $newest = Get-ChildItem -LiteralPath $logRoot -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime | Select-Object -Last 1
          if($newest){
            $det = Join-Path $newest.FullName 'Detail.txt'
            if(Test-Path -LiteralPath $det){
              $tail = (Get-Content -LiteralPath $det -Tail 400 -ErrorAction SilentlyContinue) -join "`n"
              if($tail -match 'CryptographicException'){ $dpapi = $true }
            }
          }
        }
      }catch{}
      if($dpapi){
        Write-YcLog ('Setup failed with a DPAPI CryptographicException ("There was an error generating the XML document"). ' +
                     'That is this session having no loaded user profile, not a problem with the media or the answer file. ' +
                     'Retrying the SAME configuration as a SYSTEM scheduled task, which does have one.') 'WARN'
        $tn  = 'YcInstallSqlSetupRetry'
        $rcf = 'C:\Scripts\install-sql.setup-retry.rc'
        try{
          Remove-Item -LiteralPath $rcf -Force -ErrorAction SilentlyContinue
          & schtasks.exe /delete /tn $tn /f 2>&1 | Out-Null
          $jobPs = 'C:\Scripts\install-sql.setup-retry.ps1'
          $body  = '$p = Start-Process -FilePath ''' + $setupExe + ''' -ArgumentList ''' + ($setupArgs -replace "'","''") + ''' -Wait -PassThru' + "`r`n" +
                   'Set-Content -LiteralPath ''' + $rcf + ''' -Value $p.ExitCode -Encoding ASCII'
          Set-Content -LiteralPath $jobPs -Value $body -Encoding ASCII
          $act = New-ScheduledTaskAction -Execute 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -Argument ('-NoProfile -ExecutionPolicy Bypass -File "' + $jobPs + '"')
          Register-ScheduledTask -TaskName $tn -Action $act -User 'SYSTEM' -RunLevel Highest -Force | Out-Null
          Start-ScheduledTask -TaskName $tn
          $deadline = (Get-Date).AddMinutes([Math]::Max(20, $TimeoutMinutes))
          do{
            Start-Sleep -Seconds 20
            $stt = (Get-ScheduledTask -TaskName $tn -ErrorAction SilentlyContinue).State
          } while($stt -eq 'Running' -and (Get-Date) -lt $deadline)
          if(Test-Path -LiteralPath $rcf){
            $rc = [int]((Get-Content -LiteralPath $rcf -Raw).Trim())
            Write-YcLog ('setup.exe SYSTEM-task retry exit code: ' + $rc) $(if($rc -eq 0 -or $rc -eq 3010){'OK'}else{'ERROR'})
          } else {
            Write-YcLog 'The SYSTEM-task retry produced no exit code file - treating the original failure as final.' 'ERROR'
          }
          & schtasks.exe /delete /tn $tn /f 2>&1 | Out-Null
          Remove-Item -LiteralPath $jobPs -Force -ErrorAction SilentlyContinue
        }catch{
          Write-YcLog ('The SYSTEM-task retry could not be started: ' + $_.Exception.Message) 'ERROR'
        }
      }
    }

    if($rc -eq 0){
      Write-YcLog 'SQL Server setup reported success on the retry.' 'OK'
    }elseif($rc -eq 3010){
      Write-YcLog 'SQL Server setup succeeded on the retry but REQUIRES A REBOOT (exit 3010).' 'WARN'
      $script:YcRebootNeeded = $true
      Set-Content -LiteralPath 'C:\Scripts\install-sql.reboot-required' -Value ((Get-Date).ToString('s') + ' SQL Server setup returned 3010 for instance ' + $InstanceName) -Encoding ASCII
    }else{
      Write-YcLog ('SQL SERVER SETUP FAILED with exit code ' + $rc + '. Read the setup summary at ' +
                   'C:\Program Files\Microsoft SQL Server\' + $VersionMajor + '0\Setup Bootstrap\Log\Summary.txt.') 'ERROR'
      Invoke-YcExit 4
    }
  }
  # The answer file has done its job and may contain SAPWD - remove it now, not at the end.
  Remove-YcAnswerFile
  $script:YcGenIni = $null
  if ($script:YcIsoMounted) {
    try {
      Dismount-DiskImage -ImagePath $script:YcIsoFile | Out-Null
      $script:YcIsoMounted = $false
      Write-YcLog 'ISO dismounted.'
    } catch {
      Write-YcLog ('Could not dismount the ISO: ' + $_.Exception.Message) 'WARN'
    }
  }
} else {
  Write-YcPhase 5 'SQL Server engine install - SKIPPED (instance already exists; pass -Force to re-run setup)'
}

# ================================================================================================
# PHASE 6 - patch level
# ================================================================================================
Write-YcPhase 6 'Patch level'
# Latest cumulative update per version at the time this script was written, taken from the Microsoft
# build-versions articles. Used only to REPORT how far behind the instance is - never to decide
# silently that it is fine.
$LatestCu = @{
  '2016' = @{ Name = 'SP3 + latest GDR';  Build = '13.0.7095.1'  }
  '2017' = @{ Name = 'CU31 (final CU)';   Build = '14.0.3456.2'  }
  '2019' = @{ Name = 'CU32 (final CU)';   Build = '15.0.4430.1'  }
  '2022' = @{ Name = 'CU26';              Build = '16.0.4265.3'  }
  '2025' = @{ Name = 'CU6';               Build = '17.0.4055.5'  }
}
# Below the licence-matrix floor? Then the engine is installed but the configuration is NOT
# supported, and PHASE 8 fails the run for it. Fetch the documented service pack and apply it
# through the -CuPath path below, rather than reporting the problem and leaving it.
# -Patch off, or an explicit -CuPath, both mean "do not go and get one".
if (-not $CuPath -and $Patch -eq 'on') {
  $spFloor = Get-YcMinSupportedBuild -SqlVersion $Version
  $spInfo  = Get-YcServicePackInfo  -SqlVersion $Version
  if ($spFloor -and $spInfo) {
    $spInstalled = Get-YcInstalledSqlBuild -InstanceName $InstanceName
    if (-not $spInstalled) {
      Write-YcLog ('Could not read the installed build of ' + $InstanceName + ' from the registry, so the ' + $spInfo.Name + ' floor cannot be checked here. PHASE 8 still checks it against the live instance.') 'WARN'
    } else {
      $below = $false
      try { $below = ([version]$spInstalled -lt [version]$spFloor) } catch { }
      if (-not $below) {
        Write-YcLog ('Installed build ' + $spInstalled + ' (normalised from the registry, where the service pack sits in the minor octet) already meets the ' + $spFloor + ' floor - ' + $spInfo.Name + ' is not needed.') 'OK'
      } else {
        Write-YcLog ('Installed build ' + $spInstalled + ' is below the ' + $spFloor + ' floor for SQL Server ' + $Version +
                     '. Downloading ' + $spInfo.Name + ' (' + $spInfo.Kb + ', ' + [int]($spInfo.Size / 1MB) + ' MB) and applying it - without this the instance runs but is not a supported configuration.') 'WARN'
        if (-not (Test-Path -LiteralPath $WorkDir)) { New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null }
        $spFile = Join-Path $WorkDir $spInfo.File
        if (Get-YcVerifiedDownload -Url $spInfo.Url -OutFile $spFile -ExpectSize $spInfo.Size -ExpectHash $null -Algo $null -MinBytes 100000000) {
          if (Test-YcDownloadedFile -Path $spFile -MinBytes 100000000 -Kind 'executable') {
            $CuPath = $spFile
            Write-YcLog ($spInfo.Name + ' staged at ' + $spFile + ' - applying it through the patch path below.') 'OK'
          } else {
            Write-YcLog ('The downloaded ' + $spInfo.Name + ' did not validate; the instance stays below the floor.') 'ERROR'
            $script:YcFail++
          }
        } else {
          Write-YcLog ('Could not download ' + $spInfo.Name + ' from ' + $spInfo.Url + '. The instance stays below the ' + $spFloor + ' floor - stage the service pack and pass -CuPath.') 'ERROR'
          $script:YcFail++
        }
      }
    }
  }
}

if ($CuPath) {
  if (-not (Test-Path -LiteralPath $CuPath -PathType Leaf)) {
    Write-YcLog ('-CuPath does not exist: ' + $CuPath) 'ERROR'
    $script:YcFail++
  } elseif (Test-YcDownloadedFile -Path $CuPath -MinBytes 50000000 -Kind 'executable') {
    # Documented update command line: <package>.exe /qs /IAcceptSQLServerLicenseTerms /Action=Patch
    # /InstanceName=<name>
    $cuArgs = @('/quiet','/IAcceptSQLServerLicenseTerms','/Action=Patch',('/InstanceName=' + $InstanceName))
    Write-YcLog ('Applying the staged update: "' + $CuPath + '" ' + ($cuArgs -join ' '))
    $p = Start-Process -FilePath $CuPath -ArgumentList $cuArgs -Wait -PassThru
    if ($p.ExitCode -eq 0) {
      Write-YcLog 'Update applied.' 'OK'
    } elseif ($p.ExitCode -eq 3010) {
      Write-YcLog 'Update applied and REQUIRES A REBOOT (exit 3010).' 'WARN'
      $script:YcRebootNeeded = $true
      Set-Content -LiteralPath 'C:\Scripts\install-sql.reboot-required' -Value ((Get-Date).ToString('s') + ' CU patch returned 3010') -Encoding ASCII
    } else {
      Write-YcLog ('Update FAILED (exit ' + $p.ExitCode + ').') 'ERROR'
      $script:YcFail++
    }
  } else {
    $script:YcFail++
  }
} elseif ($Patch -eq 'on' -and $doSetup) {
  Write-YcLog 'Patching was requested through setup itself (UpdateEnabled=True, UpdateSource=MU). The resulting build is reported below.'
} else {
  Write-YcLog 'No patching was requested for this run (-Patch off, or the configure-only path). The build is reported below either way.' 'WARN'
}

# ================================================================================================
# PHASE 7 - client tooling. This is the "requires ssms after the database is installed" half.
# ================================================================================================
Write-YcPhase 7 'Client tooling (ODBC, OLE DB, sqlcmd, SqlServer module, SSMS)'
if (-not (Test-Path -LiteralPath $WorkDir)) { New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null }

if ($ClientTools -eq 'on') {
  # --- ODBC Driver 18 for SQL Server -------------------------------------------------------------
  # Documented silent install: msiexec /quiet /passive /qn /i msodbcsql.msi
  # IACCEPTMSODBCSQLLICENSETERMS=YES ADDLOCAL=ALL
  $odbcMsi = Join-Path $WorkDir 'msodbcsql.msi'
  if (Get-YcVerifiedDownload -Url 'https://go.microsoft.com/fwlink/?linkid=2358430' -OutFile $odbcMsi -ExpectSize $null -ExpectHash $null -Algo $null -MinBytes 1000000) {
    if (Test-YcDownloadedFile -Path $odbcMsi -MinBytes 1000000 -Kind 'MSI') {
      if (-not (Install-YcMsi -MsiPath $odbcMsi -Properties @('IACCEPTMSODBCSQLLICENSETERMS=YES','ADDLOCAL=ALL') -Name 'ODBC Driver 18 for SQL Server')) { $script:YcFail++ }
    } else { $script:YcFail++ }
  } else {
    Write-YcLog 'Could not download the ODBC Driver for SQL Server. sqlcmd (ODBC) will not work without it.' 'ERROR'
    $script:YcFail++
  }

  # --- OLE DB Driver 19 for SQL Server -----------------------------------------------------------
  # Documented: msiexec /i msoledbsql.msi ADDLOCAL=ALL, and IACCEPTMSOLEDBSQLLICENSETERMS=YES is
  # required whenever /passive, /qn, /qb or /qr is used. SQL Server Native Client is gone from 2022+,
  # so legacy applications need this driver explicitly.
  $oledbMsi = Join-Path $WorkDir 'msoledbsql.msi'
  if (Get-YcVerifiedDownload -Url 'https://go.microsoft.com/fwlink/?linkid=2364027' -OutFile $oledbMsi -ExpectSize $null -ExpectHash $null -Algo $null -MinBytes 1000000) {
    if (Test-YcDownloadedFile -Path $oledbMsi -MinBytes 1000000 -Kind 'MSI') {
      if (-not (Install-YcMsi -MsiPath $oledbMsi -Properties @('IACCEPTMSOLEDBSQLLICENSETERMS=YES','ADDLOCAL=ALL') -Name 'OLE DB Driver 19 for SQL Server')) { $script:YcFail++ }
    } else { $script:YcFail++ }
  } else {
    Write-YcLog 'Could not download the OLE DB Driver for SQL Server.' 'WARN'
  }

  # --- Microsoft command line utilities (sqlcmd, bcp) --------------------------------------------
  # On 2022/2025 setup no longer installs sqlcmd, because the Conn feature was removed. This is the
  # direct fix for the broken verification path and the broken nightly maintenance tasks.
  $cmdMsi = Join-Path $WorkDir 'MsSqlCmdLnUtils.msi'
  if (Get-YcVerifiedDownload -Url 'https://go.microsoft.com/fwlink/?linkid=2370127' -OutFile $cmdMsi -ExpectSize $null -ExpectHash $null -Algo $null -MinBytes 500000) {
    if (Test-YcDownloadedFile -Path $cmdMsi -MinBytes 500000 -Kind 'MSI') {
      if (-not (Install-YcMsi -MsiPath $cmdMsi -Properties @('IACCEPTMSSQLCMDLNUTILSLICENSETERMS=YES') -Name 'Microsoft Command Line Utilities for SQL Server')) { $script:YcFail++ }
    } else { $script:YcFail++ }
  } else {
    Write-YcLog 'Could not download the Microsoft command line utilities (sqlcmd/bcp).' 'ERROR'
    $script:YcFail++
  }

  # --- SqlServer PowerShell module (not the deprecated SQLPS) -------------------------------------
  if (-not (Install-YcPsModule -Name 'SqlServer')) {
    Write-YcLog 'The SqlServer PowerShell module could not be installed. Later automation that calls Invoke-Sqlcmd will fail.' 'WARN'
  }
} else {
  Write-YcLog '-ClientTools off: ODBC / OLE DB / sqlcmd / SqlServer module were NOT installed.' 'WARN'
}

# --- sqlcmd must now resolve to a real executable, or nothing below can be verified ---------------
$script:SqlCmd = Get-YcSqlCmdExe
if (-not $script:SqlCmd) {
  Write-YcLog ('sqlcmd could not be resolved to a real executable. On SQL Server 2022 and 2025 setup does not install it at all (the Conn feature was removed), so it must come from the ' +
               'Microsoft command line utilities. Re-run with -ClientTools on, or install MsSqlCmdLnUtils.msi manually. Every verification step and every maintenance task depends on it.') 'ERROR'
  Invoke-YcExit 7
}
Write-YcLog ('sqlcmd resolved to: ' + $script:SqlCmd) 'OK'

# --- SSMS ----------------------------------------------------------------------------------------
function Get-YcSsmsPath {
  $hits = @()
  foreach ($g in @(
      'C:\Program Files\Microsoft SQL Server Management Studio*\Release\Common7\IDE\Ssms.exe',
      'C:\Program Files (x86)\Microsoft SQL Server Management Studio*\Common7\IDE\Ssms.exe',
      'C:\Program Files\Microsoft SQL Server Management Studio*\Common7\IDE\Ssms.exe')) {
    try { $hits += @(Get-ChildItem -Path $g) } catch { }
  }
  if ($hits.Count -gt 0) { return ($hits | Sort-Object FullName -Descending | Select-Object -First 1).FullName }
  return $null
}

if ($Ssms -eq 'on') {
  $existingSsms = Get-YcSsmsPath
  if ($existingSsms) {
    Write-YcLog ('SSMS is already installed: ' + $existingSsms + ' - skipping.') 'OK'
  } else {
    $wantSsms = $SsmsVersion
    if ($wantSsms -eq 'auto') {
      # SSMS 22 documents Windows Server 2025 / 2022 / 2019 support only. Windows Server 2016 is not
      # in that list, so SSMS 20 (the last standalone installer) is used there.
      $wantSsms = if ($osBuild -ge 17763) { '22' } else { '20' }
      Write-YcLog ('SSMS version auto-selected for ' + $osFamily + ': SSMS ' + $wantSsms + '.')
    }
    if ($wantSsms -in @('21','22')) {
      $bootUrl = 'https://aka.ms/ssms/' + $wantSsms + '/release/vs_SSMS.exe'
      $bootExe = Join-Path $WorkDir ('vs_SSMS-' + $wantSsms + '.exe')
      if (Get-YcVerifiedDownload -Url $bootUrl -OutFile $bootExe -ExpectSize $null -ExpectHash $null -Algo $null -MinBytes 1000000) {
        if (Test-YcDownloadedFile -Path $bootExe -MinBytes 1000000 -Kind 'executable') {
          # SSMS 21 and later ship as a Visual Studio Installer bundle, NOT the old standalone MSI
          # bootstrapper. Documented switches: --quiet (suppress UI), --norestart (requires --quiet
          # or --passive), --wait (wait for completion before returning the exit code).
          $ssmsArgs = @('--quiet','--norestart','--wait')
          Write-YcLog ('Installing SSMS ' + $wantSsms + ': "' + $bootExe + '" ' + ($ssmsArgs -join ' '))
          $p = Start-Process -FilePath $bootExe -ArgumentList $ssmsArgs -Wait -PassThru
          $rc = $p.ExitCode
          # Documented SSMS installer exit codes: 0 success, 3010 success but reboot required,
          # 1641 success and reboot initiated, 8010 operating system not supported.
          if ($rc -eq 0) {
            Write-YcLog ('SSMS ' + $wantSsms + ' installer returned 0.') 'OK'
          } elseif ($rc -eq 3010 -or $rc -eq 1641) {
            Write-YcLog ('SSMS ' + $wantSsms + ' installed and a reboot is required (exit ' + $rc + ').') 'WARN'
            $script:YcRebootNeeded = $true
          } elseif ($rc -eq 8010) {
            Write-YcLog ('SSMS ' + $wantSsms + ' refused to install: operating system not supported (exit 8010). ' + $osCaption + ' needs SSMS 20 - re-run with -SsmsVersion 20.') 'ERROR'
            $script:YcFail++
          } else {
            Write-YcLog ('SSMS ' + $wantSsms + ' installer returned ' + $rc + '.') 'ERROR'
            $script:YcFail++
          }
        } else { $script:YcFail++ }
      } else {
        Write-YcLog 'Could not download the SSMS installer.' 'ERROR'
        $script:YcFail++
      }
    } else {
      # SSMS 20 is the last version with a standalone installer. Microsoft's current SSMS
      # documentation set covers only the Visual Studio Installer form, so the /install /quiet
      # /norestart switch set below is NOT covered by current product documentation - it comes from
      # a Microsoft Q&A answer and from the WiX Burn bundle convention this installer uses. That is
      # exactly why the result is verified by locating Ssms.exe rather than by trusting the exit code.
      $ssmsExe = Join-Path $WorkDir 'SSMS-Setup-ENU.exe'
      if (Get-YcVerifiedDownload -Url 'https://go.microsoft.com/fwlink/?linkid=2313753' -OutFile $ssmsExe -ExpectSize $null -ExpectHash $null -Algo $null -MinBytes 100000000) {
        if (Test-YcDownloadedFile -Path $ssmsExe -MinBytes 100000000 -Kind 'executable') {
          # /log is always passed now: SSMS 20 is a WiX Burn bundle and its own log is the only
          # place that says WHY it refused. Without it, exit 1626 (ERROR_FUNCTION_NOT_CALLED) is
          # all anyone gets - which is what happened on x16B 2026-08-29 at 14:59:34, where the
          # bundle bailed in 10 seconds under NT AUTHORITY\SYSTEM. The same file with the same
          # switches then installed in 61 seconds and returned 0 when run as a local administrator.
          $ssmsBurnLog = 'C:\Scripts\install-sql-ssms-burn.log'
          $ssmsArgs = @('/install','/quiet','/norestart','/log',$ssmsBurnLog)
          Write-YcLog ('Installing SSMS 20 (legacy standalone installer): "' + $ssmsExe + '" ' + ($ssmsArgs -join ' '))
          Write-YcLog 'NOTE: these legacy switches are not in the current Microsoft SSMS documentation set. The install is confirmed by locating Ssms.exe afterwards, not by the exit code.' 'WARN'
          if ($script:RunningAsSystem) {
            Write-YcLog 'This run is executing as NT AUTHORITY\SYSTEM. The SSMS 20 bundle is unreliable in that context (observed: exit 1626 after 10 seconds). It is attempted anyway and retried once; if it still fails, re-run install-sql from an elevated interactive session to add SSMS - nothing else in this run depends on it.' 'WARN'
          }
          $p = Start-Process -FilePath $ssmsExe -ArgumentList $ssmsArgs -Wait -PassThru
          if ($p.ExitCode -eq 1626) {
            Write-YcLog 'SSMS 20 returned 1626 (ERROR_FUNCTION_NOT_CALLED) - the bundle refused to start. Retrying once.' 'WARN'
            Start-Sleep -Seconds 10
            $p = Start-Process -FilePath $ssmsExe -ArgumentList $ssmsArgs -Wait -PassThru
          }
          Write-YcLog ('SSMS 20 installer exit code: ' + $p.ExitCode)
          if ($p.ExitCode -eq 3010 -or $p.ExitCode -eq 1641) { $script:YcRebootNeeded = $true }
        } else { $script:YcFail++ }
      } else {
        Write-YcLog 'Could not download the SSMS 20 installer.' 'ERROR'
        $script:YcFail++
      }
    }
    $ssmsPath = Get-YcSsmsPath
    if ($ssmsPath) {
      Write-YcLog ('Verified: SSMS is installed at ' + $ssmsPath) 'OK'
      Add-YcSummary 'SSMS' $ssmsPath
    } else {
      Write-YcLog 'VERIFICATION FAILED: no Ssms.exe was found after the SSMS install. Do not trust the installer exit code alone.' 'ERROR'
      $script:YcFail++
      Add-YcSummary 'SSMS' 'NOT INSTALLED'
    }
  }
} else {
  Write-YcLog '-Ssms off: SQL Server Management Studio was NOT installed.' 'WARN'
  Add-YcSummary 'SSMS' 'skipped (-Ssms off)'
}

# ================================================================================================
# PHASE 8 - engine verification
# ================================================================================================
Write-YcPhase 8 'Engine verification'
$svc = Get-YcServiceOrNull -Name $svcName
if (-not $svc) {
  Write-YcLog ('VERIFICATION FAILED: the Windows service ' + $svcName + ' does not exist.') 'ERROR'
  Invoke-YcExit 8
}
if ($svc.Status -ne 'Running') {
  Write-YcLog ('Service ' + $svcName + ' is ' + $svc.Status + ' - starting it.') 'WARN'
  try { Start-Service -Name $svcName } catch { Write-YcLog ('Start-Service ' + $svcName + ' failed: ' + $_.Exception.Message) 'ERROR' }
  for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Seconds 2
    $svc = Get-YcServiceOrNull -Name $svcName
    if ($svc -and $svc.Status -eq 'Running') { break }
  }
}
if (-not $svc -or $svc.Status -ne 'Running') {
  Write-YcLog ('VERIFICATION FAILED: service ' + $svcName + ' is not Running.') 'ERROR'
  Invoke-YcExit 8
}
Write-YcLog ('Verified: service ' + $svcName + ' is Running.') 'OK'

# ISNULL on EVERY term. SERVERPROPERTY('ProductUpdateLevel') returns NULL on an instance with no
# CU applied (a plain SP slipstream, which is exactly what x19B was), and in T-SQL
# 'anything' + NULL = NULL - so the ENTIRE concatenation collapsed to the string "NULL". The run
# then logged "Verified: live query answered - NULL" as OK, recorded Build=NULL in the summary,
# threw "Cannot convert value NULL to type System.Version" in the patch comparison, and silently
# skipped the Evaluation-expiry warning because the edition string was gone too. One missing
# ISNULL destroyed four separate checks at once.
$verQuery = "SET NOCOUNT ON; SELECT ISNULL(CONVERT(varchar(50),SERVERPROPERTY('ProductVersion')),'') + '|' + ISNULL(CONVERT(varchar(60),SERVERPROPERTY('Edition')),'') + '|' + ISNULL(CONVERT(varchar(30),SERVERPROPERTY('ProductLevel')),'') + '|' + ISNULL(CONVERT(varchar(30),SERVERPROPERTY('ProductUpdateLevel')),'')"
$verText = Assert-YcSql -Query $verQuery -What ('Live test query against ' + $script:SqlHost)
if (-not $verText) { Invoke-YcExit 8 }
Write-YcLog ('Verified: live query answered - ' + $verText) 'OK'
$parts       = $verText -split '\|'
$buildNumber = $parts[0].Trim()
# Never let a non-version string reach [version] again - it is a hard throw, and the catch that
# used to swallow it turned a broken read into a WARN nobody acted on.
$script:BuildOk = ($buildNumber -match '^\d+(\.\d+){1,3}$')
if (-not $script:BuildOk) {
  Write-YcLog ('VERIFICATION FAILED: the instance reported its build as "' + $verText + '", which is not a version number. SERVERPROPERTY returned nothing usable, so patch level, edition and the Evaluation expiry cannot be trusted for this run.') 'ERROR'
  $script:YcFail++
}
$script:BuildMajor = 0
if ($script:BuildOk) { $script:BuildMajor = [int](($buildNumber -split '\.')[0]) }
$editionName = if ($parts.Count -gt 1) { $parts[1].Trim() } else { '(unknown)' }
$script:FinalEdition = $editionName
$updateLevel = if ($parts.Count -gt 3) { $parts[3].Trim() } else { '' }
Add-YcSummary 'Instance' $script:SqlHost
Add-YcSummary 'Edition' $editionName
Add-YcSummary 'Build' ($buildNumber + $(if ($updateLevel -and $updateLevel -ne 'NULL') { ' (' + $updateLevel + ')' } else { '' }))

# The service-pack floor from the licence matrix, checked against the build that ACTUALLY resulted -
# not against the media, and not on trust. x19B ended up on 13.0.5026 (SQL 2016 SP2) and nothing
# said the configuration was unsupported; it only surfaced later when dbatools refused the instance.
$minBuildReq = Get-YcMinSupportedBuild -SqlVersion $Version
if ($minBuildReq -and $script:BuildOk) {
  try {
    if ([version]$buildNumber -lt [version]$minBuildReq) {
      Write-YcLog ('UNSUPPORTED CONFIGURATION: this instance is build ' + $buildNumber + ', below the ' + $minBuildReq +
                   ' floor for SQL Server ' + $Version + '. Per the licence matrix this combination is "' + $minBuildReq +
                   ' only" - it is running, but it is not a supported configuration and it will not receive fixes. ' +
                   'Apply the service pack, or install from slipstream media at or above that build.') 'ERROR'
      Add-YcSummary 'Supported config' ('NO - build ' + $buildNumber + ' is below the ' + $minBuildReq + ' floor')
      $script:YcFail++
    } else {
      Write-YcLog ('Supported configuration: build ' + $buildNumber + ' meets the ' + $minBuildReq + ' floor for SQL Server ' + $Version + '.') 'OK'
      Add-YcSummary 'Supported config' ('yes - at or above ' + $minBuildReq)
    }
  } catch {
    Write-YcLog ('Could not compare build ' + $buildNumber + ' against the ' + $minBuildReq + ' floor: ' + $_.Exception.Message) 'WARN'
  }
}

# Patch reporting: say plainly whether the instance is behind the current cumulative update.
$cu = $LatestCu[$Version]
if ($cu -and $script:BuildOk) {
  try {
    if ([version]$buildNumber -ge [version]$cu.Build) {
      Write-YcLog ('Patch level: build ' + $buildNumber + ' is at or above the ' + $cu.Name + ' build ' + $cu.Build + ' known to this script.') 'OK'
      Add-YcSummary 'Patch level' ('at/above ' + $cu.Name)
    } else {
      Write-YcLog ('THIS INSTANCE IS UNPATCHED RELATIVE TO THE CURRENT CUMULATIVE UPDATE: build ' + $buildNumber +
                   ' is behind SQL Server ' + $Version + ' ' + $cu.Name + ' (' + $cu.Build + '). Apply the CU with -CuPath, or through Windows Update / WSUS.') 'WARN'
      Add-YcSummary 'Patch level' ('UNPATCHED - behind ' + $cu.Name + ' (' + $cu.Build + ')')
    }
  } catch {
    Write-YcLog ('Could not compare build ' + $buildNumber + ' against ' + $cu.Build + ': ' + $_.Exception.Message) 'WARN'
  }
}
if ($editionName -match 'Evaluation') {
  Write-YcLog 'This is Evaluation edition. It stops after 180 days from installation. Convert it with the activate-sql command before then.' 'WARN'
  Add-YcSummary 'Evaluation expiry' ((Get-Date).AddDays(180).ToString('yyyy-MM-dd') + ' (approx: install date + 180 days)')
}

# chadmin must really be sysadmin, and a failure here is fatal instead of being printed as
# "confirmed" unconditionally the way the old summary did.
$checkQuery = "SET NOCOUNT ON; SELECT ISNULL(CONVERT(varchar(3),IS_SRVROLEMEMBER('sysadmin', N'$chadminLogin')),'NULL')"
$chk = Assert-YcSql -Query $checkQuery -What 'chadmin sysadmin check'
if ($chk -ne '1') {
  Write-YcLog ('chadmin is not sysadmin (IS_SRVROLEMEMBER returned "' + $chk + '") - adding it explicitly.') 'WARN'
  $fixQuery = "IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'$chadminLogin') CREATE LOGIN [$chadminLogin] FROM WINDOWS; IF NOT EXISTS (SELECT 1 FROM sys.server_role_members rm JOIN sys.server_principals r ON rm.role_principal_id = r.principal_id JOIN sys.server_principals m ON rm.member_principal_id = m.principal_id WHERE r.name = 'sysadmin' AND m.name = N'$chadminLogin') ALTER SERVER ROLE sysadmin ADD MEMBER [$chadminLogin];"
  if ($null -eq (Assert-YcSql -Query $fixQuery -What 'Adding chadmin to sysadmin')) { Invoke-YcExit 8 }
  $chk = Assert-YcSql -Query $checkQuery -What 'chadmin sysadmin re-check'
  if ($chk -ne '1') {
    Write-YcLog ('VERIFICATION FAILED: chadmin is still not sysadmin after being added (result "' + $chk + '").') 'ERROR'
    Invoke-YcExit 8
  }
}
Write-YcLog 'Verified: chadmin is sysadmin.' 'OK'
Add-YcSummary 'chadmin sysadmin' 'confirmed by IS_SRVROLEMEMBER'

if ($SaPassword) {
  $modeText = Assert-YcSql -Query "SET NOCOUNT ON; SELECT CONVERT(varchar(3),SERVERPROPERTY('IsIntegratedSecurityOnly'))" -What 'Authentication mode check'
  if ($modeText -eq '0') {
    Write-YcLog 'Verified: mixed mode authentication is active (an sa password was supplied).' 'OK'
  } else {
    Write-YcLog ('An sa password was supplied but the instance reports IsIntegratedSecurityOnly=' + $modeText + ' - mixed mode did NOT take effect.') 'ERROR'
    $script:YcFail++
  }
}
# Clear the plaintext password from memory as soon as it can no longer be needed.
$SaPassword = $null

# ================================================================================================
# PHASE 9 - network configuration
# ================================================================================================
Write-YcPhase 9 'Network configuration (TCP/IP, port, Browser, firewall)'
$tcpChanged = $false
try {
  # Documented approach for enabling a server network protocol without SQL Server Configuration
  # Manager: the SMO WMI ManagedComputer object. SQL Server Setup puts the assembly in the GAC.
  [void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SqlWmiManagement')
  $wmi = New-Object 'Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer' $env:COMPUTERNAME
  $inst = $wmi.ServerInstances[$InstanceName]
  if (-not $inst) { throw ('ManagedComputer does not expose an instance called ' + $InstanceName) }
  $tcp = $inst.ServerProtocols['Tcp']
  if (-not $tcp) { throw 'The Tcp server protocol is not exposed by ManagedComputer.' }
  if (-not $tcp.IsEnabled) {
    $tcp.IsEnabled = $true
    $tcp.Alter()
    $tcpChanged = $true
    Write-YcLog 'TCP/IP protocol enabled.' 'OK'
  } else {
    Write-YcLog 'TCP/IP protocol already enabled.' 'OK'
  }
  # When Listen All is Yes, only the IPAll TcpPort / TcpDynamicPorts values are used.
  $ipAll = $tcp.IPAddresses['IPAll']
  if ($ipAll) {
    $curPort    = [string]$ipAll.IPAddressProperties['TcpPort'].Value
    $curDynamic = [string]$ipAll.IPAddressProperties['TcpDynamicPorts'].Value
    if ($curPort -ne [string]$Port -or $curDynamic -ne '') {
      $ipAll.IPAddressProperties['TcpDynamicPorts'].Value = ''
      $ipAll.IPAddressProperties['TcpPort'].Value = [string]$Port
      $tcp.Alter()
      $tcpChanged = $true
      Write-YcLog ('Static TCP port set to ' + $Port + ' on IPAll (dynamic ports cleared).') 'OK'
    } else {
      Write-YcLog ('Static TCP port already ' + $Port + ' on IPAll.') 'OK'
    }
  } else {
    Write-YcLog 'The IPAll entry was not exposed - the port was not changed.' 'WARN'
    $script:YcFail++
  }
} catch {
  Write-YcLog ('TCP/IP configuration FAILED: ' + $_.Exception.Message) 'ERROR'
  $script:YcFail++
}

if ($tcpChanged) {
  Write-YcLog 'Restarting the Database Engine so the protocol/port change takes effect (documented requirement).'
  try {
    Restart-Service -Name $svcName -Force
    for ($i = 0; $i -lt 30; $i++) {
      Start-Sleep -Seconds 2
      $svc = Get-YcServiceOrNull -Name $svcName
      if ($svc -and $svc.Status -eq 'Running') { break }
    }
    if (-not $svc -or $svc.Status -ne 'Running') { throw ('service ' + $svcName + ' did not come back') }
    Write-YcLog ('Service ' + $svcName + ' restarted and Running.') 'OK'
  } catch {
    Write-YcLog ('Restarting ' + $svcName + ' FAILED: ' + $_.Exception.Message) 'ERROR'
    Invoke-YcExit 8
  }
}

# SQL Server Browser: needed by clients resolving a NAMED instance; pointless for a default instance
# on a fixed port, and it is one more listening service, so it is disabled there.
$brw = Get-YcServiceOrNull -Name 'SQLBrowser'
if ($brw) {
  try {
    if ($isDefaultInst) {
      if ($brw.Status -eq 'Running') { Stop-Service -Name 'SQLBrowser' -Force }
      Set-Service -Name 'SQLBrowser' -StartupType Disabled
      Write-YcLog 'SQL Server Browser disabled (default instance on a fixed port does not need it).' 'OK'
    } else {
      Set-Service -Name 'SQLBrowser' -StartupType Automatic
      if ((Get-YcServiceOrNull -Name 'SQLBrowser').Status -ne 'Running') { Start-Service -Name 'SQLBrowser' }
      $brw = Get-YcServiceOrNull -Name 'SQLBrowser'
      if ($brw.Status -ne 'Running') { throw 'SQL Server Browser did not start' }
      Write-YcLog 'SQL Server Browser set to Automatic and Running (named instance).' 'OK'
    }
  } catch {
    Write-YcLog ('SQL Server Browser configuration FAILED: ' + $_.Exception.Message) 'ERROR'
    $script:YcFail++
  }
} else {
  Write-YcLog 'The SQL Server Browser service is not present on this machine.' 'WARN'
}

if ($Firewall -eq 'on') {
  $scope = @($ManagementCidr)
  function Set-YcFirewallRule {
    param([string]$Name,[string]$Protocol,[int]$LocalPort,[string[]]$Remote)
    try {
      $existing = $null
      try { $existing = Get-NetFirewallRule -DisplayName $Name } catch { $existing = $null }
      if ($existing) { Remove-NetFirewallRule -DisplayName $Name }
      New-NetFirewallRule -DisplayName $Name -Direction Inbound -Action Allow -Protocol $Protocol `
                          -LocalPort $LocalPort -RemoteAddress $Remote -Profile Any | Out-Null
      Write-YcLog ('Firewall rule created: ' + $Name + ' (' + $Protocol + '/' + $LocalPort + ' from ' + ($Remote -join ', ') + ').') 'OK'
      return $true
    } catch {
      Write-YcLog ('Firewall rule ' + $Name + ' FAILED: ' + $_.Exception.Message) 'ERROR'
      return $false
    }
  }
  if (-not (Set-YcFirewallRule -Name ('YC-SQL-' + $InstanceName + '-TCP-' + $Port) -Protocol 'TCP' -LocalPort $Port -Remote $scope)) { $script:YcFail++ }
  if (-not $isDefaultInst) {
    if (-not (Set-YcFirewallRule -Name ('YC-SQL-' + $InstanceName + '-Browser-UDP-1434') -Protocol 'UDP' -LocalPort 1434 -Remote $scope)) { $script:YcFail++ }
  }
  Add-YcSummary 'Firewall' ('TCP ' + $Port + ' from ' + ($scope -join ', '))
} else {
  Write-YcLog '-Firewall off: no inbound rule was created. The instance is unreachable from other hosts.' 'WARN'
  Add-YcSummary 'Firewall' 'skipped (-Firewall off)'
}

# ================================================================================================
# PHASE 10 - instance configuration
# ================================================================================================
Write-YcPhase 10 'Instance configuration (memory, MAXDOP, cost threshold, backup compression)'
$cores  = [int](Get-CimInstance -ClassName Win32_ComputerSystem).NumberOfLogicalProcessors
if ($cores -lt 1) { $cores = 1 }
$ramMB  = [int]([Math]::Round((Get-CimInstance -ClassName Win32_ComputerSystem).TotalPhysicalMemory / 1MB))
function Get-YcRecommendedMaxMemoryMB2 {
  param([int]$TotalMB)
  $gb = [Math]::Floor($TotalMB / 1024)
  if ($gb -le 4) { return [Math]::Max(1024, $TotalMB - 1024) }
  $reserveGB = 1
  $reserveGB += [Math]::Floor([Math]::Min($gb, 16) / 4)
  if ($gb -gt 16) { $reserveGB += [Math]::Floor(($gb - 16) / 8) }
  $val = ($gb - $reserveGB) * 1024
  if ($val -lt 1024) { $val = 1024 }
  return [int]$val
}
$wantMaxDop = if ($MaxDop -gt 0) { $MaxDop } elseif ($cores -le 8) { $cores } else { 8 }
$wantMaxMem = if ($MaxServerMemoryMB -gt 0) { $MaxServerMemoryMB } else { Get-YcRecommendedMaxMemoryMB2 -TotalMB $ramMB }

$cfgQuery = @"
SET NOCOUNT ON;
EXEC sp_configure 'show advanced options', 1; RECONFIGURE;
EXEC sp_configure 'max server memory (MB)', $wantMaxMem; RECONFIGURE;
EXEC sp_configure 'max degree of parallelism', $wantMaxDop; RECONFIGURE;
EXEC sp_configure 'cost threshold for parallelism', $CostThreshold; RECONFIGURE;
EXEC sp_configure 'backup compression default', 1; RECONFIGURE;
EXEC sp_configure 'show advanced options', 0; RECONFIGURE;
"@
if ($null -eq (Assert-YcSql -Query $cfgQuery -What 'Instance configuration (sp_configure)')) {
  $script:YcFail++
} else {
  $readBack = Assert-YcSql -Query "SET NOCOUNT ON; SELECT CONVERT(varchar(20),(SELECT CONVERT(int,value_in_use) FROM sys.configurations WHERE name='max server memory (MB)')) + '|' + CONVERT(varchar(20),(SELECT CONVERT(int,value_in_use) FROM sys.configurations WHERE name='max degree of parallelism')) + '|' + CONVERT(varchar(20),(SELECT CONVERT(int,value_in_use) FROM sys.configurations WHERE name='cost threshold for parallelism')) + '|' + CONVERT(varchar(20),(SELECT CONVERT(int,value_in_use) FROM sys.configurations WHERE name='backup compression default'))" -What 'Instance configuration read-back'
  if ($readBack) {
    Write-YcLog ('Verified from sys.configurations - maxmem|maxdop|costthreshold|backupcompression = ' + $readBack) 'OK'
    Add-YcSummary 'Instance config' ('max mem ' + $wantMaxMem + ' MB, MAXDOP ' + $wantMaxDop + ', cost threshold ' + $CostThreshold + ', backup compression on')
  } else { $script:YcFail++ }
}

$tdbInfo = Assert-YcSql -Query "SET NOCOUNT ON; SELECT CONVERT(varchar(10),COUNT(*)) + ' files, ' + CONVERT(varchar(20),MIN(size/128)) + '-' + CONVERT(varchar(20),MAX(size/128)) + ' MB' FROM tempdb.sys.database_files WHERE type = 0" -What 'tempdb sizing read-back'
if ($tdbInfo) {
  Write-YcLog ('tempdb data files: ' + $tdbInfo) 'OK'
  Add-YcSummary 'tempdb' $tdbInfo
}

# ================================================================================================
# PHASE 11 - maintenance solution, with the verification gate that used to be missing
# ================================================================================================
Write-YcPhase 11 'Ola Hallengren maintenance solution'
if (-not (Test-Path -LiteralPath $BackupDir)) {
  New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
  Write-YcLog ('Created backup directory ' + $BackupDir + '.')
}
# BACKUP DATABASE runs inside the engine, so the files are created by the Database Engine SERVICE
# account, not by chadmin, who merely invokes sqlcmd. The old code granted chadmin and ignored the
# result; the service SID is the principal that actually needs write access.
$ic = Invoke-YcNative -FilePath 'icacls.exe' -Arguments @($BackupDir,'/grant',($sqlSvcSid + ':(OI)(CI)F'),'/t')
if ($ic.ExitCode -ne 0) {
  Write-YcLog ('icacls FAILED granting ' + $sqlSvcSid + ' on ' + $BackupDir + ' (exit ' + $ic.ExitCode + '): ' + ($ic.Output -join ' ') + '. Backups will fail with operating system error 5.') 'ERROR'
  $script:YcFail++
} else {
  Write-YcLog ('Backup directory ' + $BackupDir + ' granted (OI)(CI)F to ' + $sqlSvcSid + '.') 'OK'
}
$ic2 = Invoke-YcNative -FilePath 'icacls.exe' -Arguments @($BackupDir,'/grant',($chadminLogin + ':(OI)(CI)RX'),'/t')
if ($ic2.ExitCode -ne 0) {
  Write-YcLog ('icacls could not grant chadmin read access on ' + $BackupDir + ' (exit ' + $ic2.ExitCode + ').') 'WARN'
}

if ($null -eq (Assert-YcSql -Query "IF DB_ID('DBA') IS NULL CREATE DATABASE [DBA];" -What 'Creating the DBA database')) {
  Write-YcLog 'The DBA database could not be created, so the maintenance solution cannot be installed.' 'ERROR'
  Invoke-YcExit 9
}
if ($null -eq (Assert-YcSql -Query "IF EXISTS (SELECT 1 FROM sys.databases WHERE name='DBA' AND recovery_model_desc <> 'SIMPLE') ALTER DATABASE [DBA] SET RECOVERY SIMPLE;" -What 'Setting DBA recovery model')) {
  Write-YcLog 'Could not set the DBA database to SIMPLE recovery.' 'WARN'
}

$maintInstalled = $false

# dbatools' Install-DbaMaintenanceSolution refuses any instance with Version.Major < 14, so SQL
# Server 2016 can never go through it. Use the direct sqlcmd path there, and also whenever dbatools
# itself is unusable - a broken dbatools must not mean a SQL Server with no backups.
$useDirectOla = $false
$directReason = ''
if ($script:BuildMajor -gt 0 -and $script:BuildMajor -lt 14) {
  $useDirectOla = $true
  $directReason = ('the instance is SQL Server major version ' + $script:BuildMajor + ' and Install-DbaMaintenanceSolution refuses anything below 14')
} elseif (-not $script:DbatoolsOk) {
  $useDirectOla = $true
  $directReason = 'dbatools is not usable in this session'
}

if ($useDirectOla) {
  Write-YcLog ('Installing the maintenance solution with sqlcmd instead of dbatools, because ' + $directReason + '.') 'WARN'
  if ($script:BuildMajor -eq 13) {
    Write-YcLog 'Note: SQL Server 2016 left extended support on 2026-07-14. The procedures install and work, but neither dbatools nor Ola Hallengren list 2016 as supported any more. Plan an upgrade.' 'WARN'
  }
  $maintInstalled = Install-YcOlaDirect -BackupPath $BackupDir -Database 'DBA' -ZipPath $OlaZipPath -WorkPath $WorkDir -SqlMajor $script:BuildMajor
}

if (-not $useDirectOla) {
try {
  Import-Module dbatools
  $solParams = @{
    SqlInstance     = $script:SqlHost
    Database        = 'DBA'
    BackupLocation  = $BackupDir
    Solution        = 'All'
    LogToTable      = $true
    ReplaceExisting = $true
    EnableException = $true
    Confirm         = $false
  }
  if ($OlaZipPath) {
    if (-not (Test-Path -LiteralPath $OlaZipPath -PathType Leaf)) {
      Write-YcLog ('-OlaZipPath does not exist: ' + $OlaZipPath) 'ERROR'
      Invoke-YcExit 9
    }
    # -LocalFile is the documented offline alternative to Install-DbaMaintenanceSolution's default
    # run-time download from GitHub, which is what silently killed the maintenance half on any
    # egress-restricted VM.
    $solParams.LocalFile = $OlaZipPath
    Write-YcLog ('Installing the maintenance solution from the staged local file ' + $OlaZipPath + ' (no GitHub call).')
  } else {
    Write-YcLog 'Installing the maintenance solution (dbatools downloads Ola Hallengren''s scripts from GitHub; stage a zip and pass -OlaZipPath to avoid that).'
  }
  # -InstallJobs is deliberately NOT used: SQL Agent job steps run as the Agent service account, and
  # the requirement here is that the maintenance literally runs as chadmin, which only a Windows
  # scheduled task can do. PHASE 12 does that, and only after the procedures below are proved.
  Install-DbaMaintenanceSolution @solParams | Out-Null
  $maintInstalled = $true
  Write-YcLog 'Install-DbaMaintenanceSolution completed without throwing.' 'OK'
} catch {
  Write-YcLog ('Install-DbaMaintenanceSolution FAILED: ' + $_.Exception.Message) 'ERROR'
  # The wrapper failed but Ola's script itself may still be fine here - try it directly rather than
  # leaving the instance with no maintenance at all.
  Write-YcLog 'Falling back to installing MaintenanceSolution.sql directly with sqlcmd.' 'WARN'
  $maintInstalled = Install-YcOlaDirect -BackupPath $BackupDir -Database 'DBA' -ZipPath $OlaZipPath -WorkPath $WorkDir -SqlMajor $script:BuildMajor
}
}

# ---- THE GATE. The old script set $maintOk here and never read it again, then registered three
# ---- scheduled tasks calling EXEC dbo.DatabaseBackup against procedures that did not exist, printed
# ---- "Maintenance : on", and returned 0 to cloud-init.
$procQuery = "SET NOCOUNT ON; SELECT CONVERT(varchar(10),COUNT(*)) FROM sys.procedures WHERE name IN ('DatabaseBackup','DatabaseIntegrityCheck','IndexOptimize','CommandExecute')"
$procCount = Assert-YcSql -Query $procQuery -Database 'DBA' -What 'Counting the Ola Hallengren procedures in DBA'
$maintVerified = ($procCount -eq '4')
if (-not $maintVerified) {
  Write-YcLog ('VERIFICATION FAILED: the DBA database contains ' + $(if ($procCount) { $procCount } else { 'an unreadable number of' }) +
               ' of the 4 required procedures (DatabaseBackup, DatabaseIntegrityCheck, IndexOptimize, CommandExecute). ' +
               'NO scheduled task will be registered for a procedure that does not exist, and this run will NOT report success.') 'ERROR'
  Add-YcSummary 'Maintenance' 'FAILED - procedures missing, NO backup tasks registered'
  $script:YcFail++
} else {
  Write-YcLog 'Verified: all four Ola Hallengren procedures exist in DBA.' 'OK'
}
if (-not $maintInstalled -and $maintVerified) {
  Write-YcLog 'The cmdlet failed but the procedures are present from a previous run - proceeding on the evidence, not on the cmdlet.' 'WARN'
}

# ================================================================================================
# PHASE 12 - scheduled tasks (only for procedures that were proved to exist)
# ================================================================================================
Write-YcPhase 12 'Scheduled maintenance tasks'
$enableTasks = ($Maintenance -eq 'on' -and $maintVerified)
if ($Maintenance -eq 'on' -and -not $maintVerified) {
  Write-YcLog 'Maintenance was requested but the procedures do not exist, so no task is being registered. This is the whole point of the gate above.' 'ERROR'
}

# The ORDER in which to try logon types for the maintenance tasks. Pure, so it is tested.
#
# S4U (TASK_LOGON_S4U) is passwordless and keeps the maintenance attributable to chadmin, so it is
# ALWAYS tried first. It is not predictable, though: on 2026-08-29 it registered fine on C22B
# ("runs as chadmin via S4U") and was refused on x16B with "Access is denied" - as SYSTEM AND as a
# local administrator - even though chadmin already held SeBatchLogonRight through Administrators
# (S-1-5-32-544). Both machines are workgroup members, so domain membership is NOT the
# discriminator and predicting the outcome would be guessing. Decide it by TRYING it.
#
# What matters is that a refusal no longer ends the story. Before this, a blocked S4U meant zero
# maintenance tasks registered, -Maintenance on failed the whole run, and the server had NO BACKUPS.
#   s4u      - passwordless, runs as chadmin. Best. Always attempted.
#   password - -ChadminPassword was supplied: still chadmin, at the cost of a stored credential.
#   system   - last resort: runs as NT AUTHORITY\SYSTEM. Not attributable to chadmin, which is a
#              real loss, but SYSTEM can already do anything to this instance (it owns the service,
#              the data files and single-user startup), so it is not a new capability - and a
#              working backup beats a correctly-attributed absence of one.
function Get-YcTaskLogonOrder {
  param([bool]$HasPassword)
  $o = @('s4u')
  if ($HasPassword) { $o += 'password' }
  $o += 'system'
  return ,$o
}

# Make NT AUTHORITY\SYSTEM a sysadmin. Needed ONLY if the tasks actually fall back to SYSTEM, so it
# is called at that point and not before - this is not a privilege to hand out speculatively.
function Grant-YcSystemSysadmin {
  $q = "IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'NT AUTHORITY\SYSTEM') CREATE LOGIN [NT AUTHORITY\SYSTEM] FROM WINDOWS; " +
       "IF NOT EXISTS (SELECT 1 FROM sys.server_role_members rm JOIN sys.server_principals r ON rm.role_principal_id = r.principal_id JOIN sys.server_principals m ON rm.member_principal_id = m.principal_id WHERE r.name = 'sysadmin' AND m.name = N'NT AUTHORITY\SYSTEM') ALTER SERVER ROLE sysadmin ADD MEMBER [NT AUTHORITY\SYSTEM];"
  if ($null -eq (Assert-YcSql -Query $q -What 'Granting NT AUTHORITY\SYSTEM sysadmin for the maintenance tasks')) { return $false }
  return $true
}

function Set-YcSqlSchedTask {
  param([string]$Name,[string]$SqlCmdArgs,[string]$TriggerType,[string]$At,[int]$RepeatMinutes,[bool]$Enable)
  $backupXml = $null
  $existed   = $false
  try {
    $t = Get-ScheduledTask -TaskName $Name
    if ($t) {
      $existed = $true
      # Capture the working definition BEFORE destroying it, so a failed re-registration cannot
      # leave the machine with no backup task where it previously had one.
      $backupXml = Export-ScheduledTask -TaskName $Name
    }
  } catch { $existed = $false }

  if (-not $Enable) {
    if ($existed) {
      Unregister-ScheduledTask -TaskName $Name -Confirm:$false
      Write-YcLog ('Maintenance off: removed scheduled task ' + $Name + '.') 'WARN'
    }
    return $false
  }

  if ($existed) { Unregister-ScheduledTask -TaskName $Name -Confirm:$false }

  $action = New-ScheduledTaskAction -Execute $script:SqlCmd -Argument $SqlCmdArgs
  $atTime = [datetime]::ParseExact($At, 'HH:mm', [Globalization.CultureInfo]::InvariantCulture)
  if ($TriggerType -eq 'Daily') {
    $trigger = New-ScheduledTaskTrigger -Daily -At $atTime
  } elseif ($TriggerType -eq 'Weekly') {
    $trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At $atTime
  } else {
    $trigger = New-ScheduledTaskTrigger -Once -At $atTime `
                 -RepetitionInterval (New-TimeSpan -Minutes $RepeatMinutes) `
                 -RepetitionDuration (New-TimeSpan -Days 3650)
  }
  $settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopOnIdleEnd -ExecutionTimeLimit (New-TimeSpan -Hours 6)

  foreach ($how in $script:TaskLogonOrder) {
    try {
      if ($how -eq 's4u') {
        $principal = New-ScheduledTaskPrincipal -UserId $chadminLogin -LogonType S4U -RunLevel Highest
        Register-ScheduledTask -TaskName $Name -Action $action -Trigger $trigger -Principal $principal -Settings $settings -ErrorAction Stop | Out-Null
        Write-YcLog ('Scheduled task registered: ' + $Name + ' (runs as chadmin via S4U, no stored password).') 'OK'
        return $true
      } elseif ($how -eq 'password') {
        Register-ScheduledTask -TaskName $Name -Action $action -Trigger $trigger -Settings $settings `
                               -User $chadminLogin -Password $ChadminPassword -RunLevel Highest -ErrorAction Stop | Out-Null
        Write-YcLog ('Scheduled task registered: ' + $Name + ' (runs as chadmin using the stored credential from -ChadminPassword).') 'OK'
        return $true
      } else {
        # Grant SYSTEM its SQL login the first time we actually need it, not before.
        if (-not $script:SystemSysadminDone) {
          Write-YcLog 'Falling back to NT AUTHORITY\SYSTEM for the maintenance tasks. They WILL run, but they are attributed to SYSTEM rather than to chadmin. Pass -ChadminPassword to keep them as chadmin.' 'WARN'
          Add-YcSummary 'Maintenance identity' 'NT AUTHORITY\SYSTEM (S4U refused, no -ChadminPassword)'
          $script:SystemSysadminDone = $true
          if (Grant-YcSystemSysadmin) {
            Write-YcLog 'NT AUTHORITY\SYSTEM is a sysadmin, so the SYSTEM-run maintenance tasks can connect.' 'OK'
          } else {
            Write-YcLog 'NT AUTHORITY\SYSTEM could not be made a sysadmin, so tasks running as SYSTEM will fail to connect.' 'ERROR'
            $script:YcFail++
          }
        }
        $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
        Register-ScheduledTask -TaskName $Name -Action $action -Trigger $trigger -Principal $principal -Settings $settings -ErrorAction Stop | Out-Null
        Write-YcLog ('Scheduled task registered: ' + $Name + ' (runs as NT AUTHORITY\SYSTEM, NOT as chadmin).') 'WARN'
        return $true
      }
    } catch {
      Write-YcLog ('Registration of ' + $Name + ' via ' + $how + ' failed: ' + ($_.Exception.Message -replace '\s+',' ')) 'WARN'
    }
  }
  Write-YcLog ('Could not register ' + $Name + ' by any method (' + ($script:TaskLogonOrder -join ', ') + ').') 'ERROR'
  if ($backupXml) {
    try {
      Register-ScheduledTask -TaskName $Name -Xml $backupXml -Force | Out-Null
      Write-YcLog ('Restored the previous definition of ' + $Name + ' so this machine is not left with no task at all.') 'WARN'
    } catch {
      Write-YcLog ('Could not restore the previous definition of ' + $Name + ': ' + $_.Exception.Message) 'ERROR'
    }
  }
  return $false
}

function New-YcSqlCmdArgs {
  param([string]$Tsql)
  # -b so a T-SQL failure produces a non-zero task result instead of a green task that did nothing.
  # -C for the same reason as Invoke-YcSql: without it every scheduled backup, integrity check and
  # index job fails nightly on the ODBC Driver 18 certificate check, which is exactly the class of
  # silent-backup-failure this script exists to prevent.
  # NOT $script:SqlHost. That is "<COMPUTERNAME>" (or "<COMPUTERNAME>\<instance>") frozen at
  # install time, and it is baked into six scheduled tasks that then live for the life of the VM.
  # Rename the machine - which a customer may do on day one - and every one of them starts failing
  # with rc=1: no backups, no integrity check, no index maintenance, no restore verify, and nothing
  # says a word. Measured on a Server 2022 lab VM on 2026-08-31: renamed WINDOWS-IUL8F66 -> YC-RENAMED-06,
  # fired YC-SqlBackupFull, rc=1. (SQL LOGIN access survives a rename - Windows logins are stored by
  # SID and a local SID does not change - so this is the only thing a rename actually breaks.)
  # "." always means the local default instance; ".\<instance>" the local named one. Neither
  # contains the host name, so neither can rot.
  $target = if ($isDefaultInst) { '.' } else { '.\' + $InstanceName }
  return ('-S "' + $target + '" -E -C -b -d DBA -Q "' + $Tsql + '"')
}
$backupFull = New-YcSqlCmdArgs -Tsql ('EXEC dbo.DatabaseBackup @Databases = ''ALL_DATABASES'', @Directory = N''' + $BackupDir + ''', @BackupType = ''FULL'', @Verify = ''Y'', @Compress = ''Y'', @CheckSum = ''Y'', @CleanupTime = 168, @LogToTable = ''Y''')
$backupDiff = New-YcSqlCmdArgs -Tsql ('EXEC dbo.DatabaseBackup @Databases = ''USER_DATABASES'', @Directory = N''' + $BackupDir + ''', @BackupType = ''DIFF'', @Verify = ''Y'', @Compress = ''Y'', @CheckSum = ''Y'', @ChangeBackupType = ''Y'', @CleanupTime = 168, @LogToTable = ''Y''')
$backupLog  = New-YcSqlCmdArgs -Tsql ('EXEC dbo.DatabaseBackup @Databases = ''USER_DATABASES'', @Directory = N''' + $BackupDir + ''', @BackupType = ''LOG'', @Verify = ''Y'', @Compress = ''Y'', @CheckSum = ''Y'', @ChangeBackupType = ''Y'', @CleanupTime = 168, @LogToTable = ''Y''')
$integArgs  = New-YcSqlCmdArgs -Tsql 'EXEC dbo.DatabaseIntegrityCheck @Databases = ''ALL_DATABASES'', @CheckCommands = ''CHECKDB'', @LogToTable = ''Y'''
$idxArgs    = New-YcSqlCmdArgs -Tsql 'EXEC dbo.IndexOptimize @Databases = ''ALL_DATABASES'', @LogToTable = ''Y'''

$taskResults = @{}
$script:SystemSysadminDone = $false
$domainJoined = $false
try { $domainJoined = [bool](Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).PartOfDomain } catch { }
$script:TaskLogonOrder = Get-YcTaskLogonOrder -HasPassword ([bool]$ChadminPassword)
Write-YcLog ('Maintenance task logon order: ' + ($script:TaskLogonOrder -join ' -> ') + '. (domain-joined=' + $domainJoined + '; S4U is attempted first everywhere because it is passwordless and keeps the tasks running as chadmin, and whether it is permitted is not predictable from the machine role.)')

$taskResults['YC-SqlBackupFull-' + $InstanceName]  = Set-YcSqlSchedTask -Name ('YC-SqlBackupFull-' + $InstanceName)  -SqlCmdArgs $backupFull -TriggerType 'Daily'  -At '01:15' -RepeatMinutes 0 -Enable $enableTasks
$taskResults['YC-SqlBackupDiff-' + $InstanceName]  = Set-YcSqlSchedTask -Name ('YC-SqlBackupDiff-' + $InstanceName)  -SqlCmdArgs $backupDiff -TriggerType 'Daily'  -At '13:15' -RepeatMinutes 0 -Enable $enableTasks
if ($LogBackupMinutes -gt 0) {
  # model ships in FULL recovery, so every user database created on this instance is in FULL
  # recovery. Without a LOG backup the transaction log never truncates and eventually fills the
  # volume and stops the instance. The old script only ever took FULL backups.
  $taskResults['YC-SqlBackupLog-' + $InstanceName] = Set-YcSqlSchedTask -Name ('YC-SqlBackupLog-' + $InstanceName)   -SqlCmdArgs $backupLog  -TriggerType 'Repeat' -At '00:05' -RepeatMinutes $LogBackupMinutes -Enable $enableTasks
} else {
  Write-YcLog '-LogBackupMinutes 0: NO transaction-log backups are scheduled. Every database in FULL recovery will grow its log without bound.' 'WARN'
}
$taskResults['YC-SqlIntegrity-' + $InstanceName]   = Set-YcSqlSchedTask -Name ('YC-SqlIntegrity-' + $InstanceName)   -SqlCmdArgs $integArgs  -TriggerType 'Weekly' -At '02:15' -RepeatMinutes 0 -Enable $enableTasks
$taskResults['YC-SqlIndexOpt-' + $InstanceName]    = Set-YcSqlSchedTask -Name ('YC-SqlIndexOpt-' + $InstanceName)    -SqlCmdArgs $idxArgs    -TriggerType 'Weekly' -At '03:15' -RepeatMinutes 0 -Enable $enableTasks

if ($enableTasks) {
  $failedTasks = @($taskResults.Keys | Where-Object { -not $taskResults[$_] })
  if ($failedTasks.Count -gt 0) {
    Write-YcLog ('Scheduled task registration FAILED for: ' + ($failedTasks -join ', ')) 'ERROR'
    $script:YcFail++
    Add-YcSummary 'Maintenance tasks' ('FAILED for ' + ($failedTasks -join ', '))
  } else {
    # Say who these tasks ACTUALLY run as, in BOTH the log line and the summary. Both were
    # hardcoded to "chadmin" and both printed it on C16B 2026-08-29 while the same run reported
    # the identity as SYSTEM. One value, computed once, used everywhere.
    $ranAs = if ($script:SystemSysadminDone) { 'NT AUTHORITY\SYSTEM' } elseif ($ChadminPassword) { 'chadmin (stored credential)' } else { 'chadmin (S4U)' }
    Write-YcLog ('Maintenance ON: FULL daily 01:15, DIFF daily 13:15' +
                 $(if ($LogBackupMinutes -gt 0) { ', LOG every ' + $LogBackupMinutes + ' minutes' } else { ', NO log backups' }) +
                 ', integrity check Sunday 02:15, index optimize Sunday 03:15 - all as ' + $ranAs + ', backups to ' + $BackupDir + '.') 'OK'
    Add-YcSummary 'Maintenance tasks' ($taskResults.Count.ToString() + ' registered, running as ' + $ranAs)
  }
} elseif ($Maintenance -eq 'off') {
  Write-YcLog 'Maintenance OFF: the procedures are installed but nothing is scheduled. Re-run with -Maintenance on to enable.' 'WARN'
  Add-YcSummary 'Maintenance tasks' 'none (-Maintenance off)'
}

# ================================================================================================
# PHASE 13 - final verification. Nothing below is taken on faith.
# ================================================================================================
Write-YcPhase 13 'Final verification'

$vv = Assert-YcSql -Query "SET NOCOUNT ON; SELECT REPLACE(REPLACE(CONVERT(varchar(300),@@VERSION),CHAR(13),' '),CHAR(10),' ')" -What 'SELECT @@VERSION'
if ($vv) { Write-YcLog ('Verified: @@VERSION = ' + $vv) 'OK' } else { $script:YcFail++ }

$procCount2 = Assert-YcSql -Query $procQuery -Database 'DBA' -What 'Re-counting the maintenance procedures'
if ($procCount2 -eq '4') {
  Write-YcLog 'Verified: the four maintenance procedures are present in DBA.' 'OK'
} else {
  Write-YcLog ('FINAL VERIFICATION FAILED: only ' + $procCount2 + ' of the 4 maintenance procedures exist in DBA.') 'ERROR'
  $script:YcFail++
}

if ($enableTasks) {
  foreach ($tn in $taskResults.Keys) {
    $exists = $null
    try { $exists = Get-ScheduledTask -TaskName $tn } catch { $exists = $null }
    if ($exists) {
      Write-YcLog ('Verified: scheduled task present - ' + $tn + ' (state ' + $exists.State + ').') 'OK'
    } else {
      Write-YcLog ('FINAL VERIFICATION FAILED: scheduled task ' + $tn + ' does not exist.') 'ERROR'
      $script:YcFail++
    }
  }
  # A backup job that has never run is not a backup. Run one for real and require a file on disk.
  $testTask = 'YC-SqlBackupFull-' + $InstanceName
  try {
    Write-YcLog ('Running ' + $testTask + ' once now to prove the whole chain actually works...')
    Start-ScheduledTask -TaskName $testTask
    $deadline = (Get-Date).AddMinutes(20)
    do {
      Start-Sleep -Seconds 10
      $info = Get-ScheduledTaskInfo -TaskName $testTask
      $state = (Get-ScheduledTask -TaskName $testTask).State
    } while ($state -eq 'Running' -and (Get-Date) -lt $deadline)
    $info = Get-ScheduledTaskInfo -TaskName $testTask
    if ($state -eq 'Running') {
      Write-YcLog ('FINAL VERIFICATION FAILED: ' + $testTask + ' was still running after 20 minutes.') 'ERROR'
      $script:YcFail++
    } elseif ($info.LastTaskResult -ne 0) {
      Write-YcLog ('FINAL VERIFICATION FAILED: ' + $testTask + ' finished with LastTaskResult=' + $info.LastTaskResult +
                   '. That is exactly the nightly failure nobody would have looked at. Check ' + $BackupDir + ' and the CommandLog table in DBA.') 'ERROR'
      $script:YcFail++
    } else {
      Write-YcLog ('Verified: ' + $testTask + ' ran and returned 0.') 'OK'
    }
  } catch {
    Write-YcLog ('FINAL VERIFICATION FAILED: could not run ' + $testTask + ': ' + $_.Exception.Message) 'ERROR'
    $script:YcFail++
  }
  # And prove a real backup file landed on disk.
  try {
    $bakFiles = @(Get-ChildItem -Path $BackupDir -Recurse -Filter '*.bak' | Sort-Object LastWriteTime -Descending)
    if ($bakFiles.Count -gt 0) {
      Write-YcLog ('Verified: ' + $bakFiles.Count + ' backup file(s) on disk; newest is ' + $bakFiles[0].FullName + ' (' + [int]($bakFiles[0].Length / 1KB) + ' KB, ' + $bakFiles[0].LastWriteTime.ToString('s') + ').') 'OK'
      Add-YcSummary 'Test backup' ('OK - ' + $bakFiles[0].Name)
    } else {
      Write-YcLog ('FINAL VERIFICATION FAILED: no .bak file exists anywhere under ' + $BackupDir + ' after running the backup task.') 'ERROR'
      $script:YcFail++
      Add-YcSummary 'Test backup' 'FAILED - no backup file on disk'
    }
  } catch {
    Write-YcLog ('FINAL VERIFICATION FAILED: could not inspect ' + $BackupDir + ': ' + $_.Exception.Message) 'ERROR'
    $script:YcFail++
  }
  # A weekly RESTORE VERIFYONLY over the newest full backup, because a backup that is never
  # restore-tested is not a backup.
  $verifyTsql = 'DECLARE @f nvarchar(4000); SELECT TOP 1 @f = mf.physical_device_name FROM msdb.dbo.backupmediafamily mf JOIN msdb.dbo.backupset bs ON bs.media_set_id = mf.media_set_id WHERE bs.type = ''D'' ORDER BY bs.backup_finish_date DESC; IF @f IS NULL RAISERROR(''No full backup is recorded in msdb'',16,1); ELSE RESTORE VERIFYONLY FROM DISK = @f;'
  [void](Set-YcSqlSchedTask -Name ('YC-SqlRestoreVerify-' + $InstanceName) -SqlCmdArgs (New-YcSqlCmdArgs -Tsql $verifyTsql) -TriggerType 'Weekly' -At '04:15' -RepeatMinutes 0 -Enable $true)
}

$sqlcmdVer = Invoke-YcNative -FilePath $script:SqlCmd -Arguments @('-?')
if ($sqlcmdVer.ExitCode -eq 0 -or ($sqlcmdVer.Output -join ' ') -match '(?i)version') {
  Write-YcLog ('Verified: sqlcmd is executable at ' + $script:SqlCmd) 'OK'
  Add-YcSummary 'sqlcmd' $script:SqlCmd
} else {
  Write-YcLog ('FINAL VERIFICATION FAILED: ' + $script:SqlCmd + ' did not respond to -?.') 'ERROR'
  $script:YcFail++
}

# ================================================================================================
# PHASE 14 - cleanup, summary, exit
# ================================================================================================
Write-YcPhase 14 'Cleanup and summary'
if (-not $KeepMedia -and $doSetup -and -not $IsoPath -and $script:YcIsoFile -and $script:YcFail -eq 0) {
  try {
    if (-not $script:YcIsoMounted) {
      Remove-Item -LiteralPath $script:YcIsoFile -Force
      Write-YcLog ('Removed the downloaded ISO ' + $script:YcIsoFile + ' (pass -KeepMedia to keep it).')
      $script:YcIsoFile = $null
    }
  } catch {
    Write-YcLog ('Could not remove the downloaded ISO: ' + $_.Exception.Message) 'WARN'
  }
}
try {
  # One timestamped answer file per run used to accumulate forever. Keep the last five for audit.
  $old = @(Get-ChildItem -Path 'C:\Scripts\sql-configs' -Filter 'ConfigurationFile-*.ini' | Sort-Object LastWriteTime -Descending | Select-Object -Skip 5)
  foreach ($f in $old) { Remove-Item -LiteralPath $f.FullName -Force }
} catch {
  Write-YcLog ('Could not rotate old generated answer files: ' + $_.Exception.Message) 'WARN'
}

# Report the edition the INSTANCE reports, not the one that was asked for. The summary used to
# echo -Edition back, which is how "-Edition Express" produced a summary line claiming Express on
# an Evaluation instance.
$reportedEdition = $Edition
if ($script:FinalEdition) { $reportedEdition = $script:FinalEdition }
Add-YcSummary 'Version' ('SQL Server ' + $Version + ' ' + $reportedEdition)
$svcNow = Get-YcServiceOrNull -Name $svcName
Add-YcSummary 'Service' ($svcName + ' (' + $(if ($svcNow) { [string]$svcNow.Status } else { 'not found' }) + ')')
Add-YcSummary 'Features' $Features
Add-YcSummary 'Backup dir' $BackupDir
Add-YcSummary 'Maintenance' ($Maintenance + $(if ($maintVerified) { ' - 4/4 procedures verified' } else { ' - PROCEDURES MISSING' }))
Add-YcSummary 'Log' 'C:\Scripts\install-sql.log'

if ($script:YcRebootNeeded) {
  Write-YcLog 'A REBOOT IS REQUIRED to complete this installation (an installer returned 3010/1641). The marker file C:\Scripts\install-sql.reboot-required records it.' 'WARN'
  Add-YcSummary 'Reboot required' 'YES - see C:\Scripts\install-sql.reboot-required'
  if (-not (Test-Path -LiteralPath 'C:\Scripts\install-sql.reboot-required')) {
    Set-Content -LiteralPath 'C:\Scripts\install-sql.reboot-required' -Value ((Get-Date).ToString('s') + ' reboot required after install-sql') -Encoding ASCII
  }
} else {
  Add-YcSummary 'Reboot required' 'no'
}

if ($script:YcFail -gt 0) {
  Write-YcLog ([string]$script:YcFail + ' stage(s) failed. This run is NOT a success and returns a non-zero exit code so cloud-init and the RMM see it.') 'ERROR'
  if (-not $maintVerified)                    { Invoke-YcExit 9 }
  Invoke-YcExit 10
}

if ($script:YcRebootNeeded -and $script:DoReboot) {
  Write-YcLog 'Everything verified. Rebooting now because an installer asked for a restart.' 'WARN'
  Add-YcSummary 'Result' 'Success - rebooting'
  $script:YcStopped = $true
  Remove-YcAnswerFile
  Write-Host ''
  Write-Host '=== install-sql summary ===' -ForegroundColor Cyan
  foreach ($s in $script:Summary) { Write-Host ('  ' + $s) }
  Write-Host ''
  Write-YcLog 'install-sql complete (exit 0) - restarting the machine now.' 'OK'
  Stop-YcLog 0
  Restart-Computer -Force
  exit 0
}
Add-YcSummary 'Result' 'Success - every verification passed'
Invoke-YcExit 0
