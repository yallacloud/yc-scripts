# yc-health.ps1 - daily health pass. Replaces GIDiskGuard + GIWatchdog.
# This is the YC-Health-Chkdsk task Yallacloud.ps1 already documented at 03:30.
$ErrorActionPreference='SilentlyContinue'
$log='C:\Scripts\yc-health.log'
function L($m){ Add-Content $log ("[{0}] {1}" -f (Get-Date -f 'yyyy-MM-dd HH:mm:ss'), $m) -Encoding ascii }
L '--- yc-health start ---'
foreach($d in (Get-Volume | Where-Object { $_.DriveLetter -and $_.FileSystem -eq 'NTFS' } | ForEach-Object { $_.DriveLetter })){
  if((cmd /c "fsutil dirty query ${d}:") -match 'is Dirty'){ L "${d}: DIRTY -> chkdsk /spotfix"; cmd /c "echo Y| chkdsk ${d}: /spotfix" | Out-Null }
  else { L "${d}: online /scan"; cmd /c "chkdsk ${d}: /scan" | Out-Null }
}
try { & powershell -NoProfile -ExecutionPolicy Bypass -File C:\Scripts\Root-Cause.ps1 -Latest | Out-Null; L 'rootcause snapshot written' } catch { L "rootcause: $($_.Exception.Message)" }
L '--- yc-health end ---'
