@echo off
rem convert-edition - convert a Windows Server EDITION in place (Evaluation -> retail/volume,
rem   Standard -> Datacenter) with DISM /Set-Edition, and PROVE the target is legal first.
rem
rem   This is the edition change. It is NOT activation - run activate-windows afterwards.
rem   activate-windows already does the eval->full change during its own flow; use this when
rem   you want the edition change on its own, or when you need to see what an image can
rem   legally become before touching it.
rem
rem   convert-edition -List
rem   convert-edition -TargetEdition ServerStandard [-ProductKey <XXXXX-...>] [-AllowReboot] [-Force]
rem   convert-edition -TargetEdition ServerDatacenter -WhatIf
rem   convert-edition -SelfCheck
rem
rem ALWAYS run -List first. The list of legal targets is read LIVE from
rem   DISM /Online /Get-TargetEditions - it is never hardcoded, because some Windows Server
rem   2025 evaluation ISOs offer only ServerTurbine (Datacenter: Azure Edition) and
rem   ServerDatacenter, with ServerStandard absent entirely.
rem
rem THIS IS IRREVERSIBLE and needs TWO reboots. Windows cannot go to a lower edition and
rem   /Set-Edition cannot be re-run on an image that has already been converted.
rem
rem Refuses outright: domain controllers, and Server Core -> Desktop Experience. Both are
rem   documented by Microsoft as impossible, not as difficult.
rem
rem Exit codes: 0 done or list-only, 2 domain controller, 3 DISM gave no current edition,
rem             4 target not offered by this image, 5 bad key or unmappable edition,
rem             6 confirmation declined, 7 DISM failed.
rem Log: C:\Scripts\convert-edition.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Convert-Edition.ps1" %*
exit /b %ERRORLEVEL%
