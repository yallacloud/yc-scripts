@echo off
rem winupdate [-Security|-Critical|-All|-Drivers] [-List|-Download|-Install] [-Reboot] [-IncludeKB ..] [-ExcludeKB ..] [-Help]
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Win-Update.ps1" %*
