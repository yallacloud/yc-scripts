# SQL Server answer-file templates - why each setting is or is not there

Verified against Microsoft Learn on **2026-08-16**. These templates are consumed by
`Install-Sql.ps1`, which substitutes placeholder tokens and then refuses to run if any
unsubstituted token is left in the file.

Read this before adding anything back. Every removal below was checked against the version
selector on the Microsoft parameter reference, not against memory or against a
ConfigurationFile.ini that some setup GUI produced years ago.

## Documentation used

| Purpose | URL |
| --- | --- |
| Command-prompt parameter reference (2017) | https://learn.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt?view=sql-server-2017 |
| Command-prompt parameter reference (2019) | https://learn.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt?view=sql-server-ver15 |
| Command-prompt parameter reference (2022) | https://learn.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt?view=sql-server-ver16 |
| Command-prompt parameter reference (2025) | https://learn.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt?view=sql-server-ver17 |
| Install using a configuration file | https://learn.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-using-a-configuration-file |
| Windows service accounts and permissions (virtual accounts) | https://learn.microsoft.com/en-us/sql/database-engine/configure-windows/configure-windows-service-accounts-and-permissions |
| Database instant file initialization (setup support) | https://learn.microsoft.com/en-us/sql/relational-databases/databases/database-instant-file-initialization |
| Archived 2016 view of the parameter reference | https://web.archive.org/web/20220701073057/https://docs.microsoft.com/en-us/sql/database-engine/install-windows/install-sql-server-from-the-command-prompt?view=sql-server-2016 |

**There is no live SQL Server 2016 parameter reference any more.** The current article declares
`monikerRange: ">=sql-server-2017"`, and a request for `?view=sql-server-2016` is redirected to
`?view=sql-server-ver17`. What survives for 2016 is the per-parameter "Applies to: SQL Server 2016
(13.x) and later versions" / "and earlier versions" annotations on the current article, plus the
archived 2016 view. The archived 2016 view is **not** trustworthy parameter by parameter: it also
listed `SQLMAXDOP` and `USESQLRECOMMENDEDMEMORYLIMITS` under the 2016 selector, and the current
article restricts both to "SQL Server 2019 (15.x) and later versions". It was one shared,
unannotated table.

## First version each version-gated setting is valid in

| Setting | First valid version | Source wording |
| --- | --- | --- |
| SQLTEMPDBFILECOUNT | 2016 | no Applies-to note; tempdb file configuration in setup starts with 2016 |
| SQLTEMPDBFILEGROWTH | 2016 | no Applies-to note |
| SQLTEMPDBFILESIZE | 2016 | Applies to: SQL Server 2016 (13.x) and later versions |
| SQLTEMPDBLOGFILESIZE | 2016 | Applies to: SQL Server 2016 (13.x) and later versions |
| SQLTEMPDBLOGFILEGROWTH | 2016 | Applies to: SQL Server 2016 (13.x) and later versions |
| SQLTEMPDBDIR, SQLTEMPDBLOGDIR | pre-2016 | no Applies-to note |
| SQLSVCINSTANTFILEINIT | 2016 | "In SQL Server 2016 (13.x) and later versions, this permission can be granted to the Database Engine service SID at install time, during setup" |
| SUPPRESSPRIVACYSTATEMENTNOTICE | 2017 (treated as) | documented Required with /Q or /QS on the >=2017 article; no live 2016 documentation - see the 2016 note below |
| SQLMAXDOP | 2019 | Applies to: SQL Server 2019 (15.x) and later versions |
| USESQLRECOMMENDEDMEMORYLIMITS | 2019 | Applies to: SQL Server 2019 (15.x) and later versions |
| SQLMAXMEMORY, SQLMINMEMORY | 2019 | Applies to: SQL Server 2019 (15.x) and later versions |
| SQL_INST_JAVA, SQLJAVADIR | 2019 only | Applies to: SQL Server 2019 (15.x) only |
| PRODUCTCOVEREDBYSA | 2022 | Applies to: SQL Server 2022 (16.x) and later versions; Required when installing the Azure Extension feature |
| AZUREEXTENSION and every AZURE setting | 2022 | Applies to: SQL Server 2022 (16.x) and later versions |
| IACCEPTDQUNINSTALL | 2025 | Applies to: SQL Server 2025 (17.x) and later versions - **UPGRADE action, not Install** |

## Last version each legacy setting is valid in

| Setting or FEATURES value | Last valid version | Source wording |
| --- | --- | --- |
| RS, RS_SHP, RS_SHPWFE | 2016 | Applies to: SQL Server 2016 (13.x) and earlier versions |
| RSINSTALLMODE, RSSVCACCOUNT, RSSVCPASSWORD, RSSVCStartupType | 2016 | Applies to: SQL Server 2016 (13.x) and earlier versions |
| Tools, BC, Conn, SDK, SNAC_SDK, DREPLAY_CTLR, DREPLAY_CLT | 2019 | Applies to: SQL Server 2019 (15.x) and earlier versions |
| ERRORREPORTING, SQMREPORTING | 2014 | Applies to: SQL Server 2014 (12.x) and earlier versions |

## Removed from every template (all five versions)

| Setting | Why it is gone |
| --- | --- |
| Product-key line | No key means setup installs Evaluation, which is the whole point of this build. Install-Sql.ps1 aborts if such a line ever appears in a generated answer file. |
| IACCEPTROPENLICENSETERMS | Documented Required only for unattended installs "that include the Microsoft R Open package". FEATURES never includes AdvancedAnalytics or SQL_INST_MR. From 2022 onward setup does not lay down the R, Python or Java runtimes at all. |
| ADDCURRENTUSERASSQLADMIN | Documented for Express editions or ROLE=AllFeatures_WithDefaults, and it already defaults to False on every non-Express edition. SQLSYSADMINACCOUNTS satisfies the documented "either one or the other is required" rule. |
| X86 | Not present anywhere in the current setup parameter reference. |
| HELP | A console switch for an interactive run; meaningless in an answer file used with QUIET. |
| INDICATEPROGRESS | Same - it pipes the verbose log to a console that does not exist here. |
| QUIETSIMPLE | /QS shows a progress UI, and the reference states /Q overrides /QS. Carrying both is contradictory GUI noise. |
| INSTANCEID | Omitted so setup applies its documented default. The reference states that if INSTANCEID is not specified, setup substitutes INSTANCENAME for it. The pre-repair template also carried an INSTANCEID token that Install-Sql.ps1 does not substitute, so it shipped a literal placeholder into setup and the run aborted. |

## Per-version summary

### 2016

* **Not present:** SUPPRESSPRIVACYSTATEMENTNOTICE, SQLMAXDOP, USESQLRECOMMENDEDMEMORYLIMITS,
  SQLMAXMEMORY, SQLMINMEMORY, PRODUCTCOVEREDBYSA, every AZURE setting.
* **Present and version-checked:** SQLSVCINSTANTFILEINIT (2016 and later), the full tempdb set
  (2016 and later).
* **No MAXDOP or memory placeholder tokens.** Install-Sql.ps1 only produces those values from 2019
  up, so nothing is silently dropped; it sets max server memory and MAXDOP with `sp_configure`
  after setup on 2016 and 2017.
* On the privacy notice: omitting is the safe direction. If the setting were unsupported on 2016,
  including it makes setup reject the entire answer file; if it were supported, it cannot be
  mandatory, because 2016 shipped in 2016 and its silent installs never needed it.
* FEATURES on 2016 may legally include RS / RS_SHP / RS_SHPWFE, but this template carries no
  RSSVCACCOUNT, which is Required whenever Reporting Services is selected. Keep FEATURES to
  Database Engine values.

### 2017

* **Added versus 2016:** SUPPRESSPRIVACYSTATEMENTNOTICE ("Required, when the /Q or /QS parameter is
  specified for unattended installations").
* **Still not present:** SQLMAXDOP and the memory limits (2019 and later), PRODUCTCOVEREDBYSA and
  the AZURE settings (2022 and later).
* FEATURES must no longer contain RS, RS_SHP or RS_SHPWFE - Reporting Services became a separate
  download from 2017.
* FEATURES may still contain Conn, BC, SDK, SNAC_SDK, DREPLAY_CTLR, DREPLAY_CLT and Tools.

### 2019

* **Added versus 2017:** the MAXDOP and memory placeholder lines. SQLMAXDOP,
  USESQLRECOMMENDEDMEMORYLIMITS, SQLMAXMEMORY and SQLMINMEMORY are all "SQL Server 2019 (15.x) and
  later versions" - 2019 is the first version that accepts them.
* Install-Sql.ps1 emits **exactly one** memory form, because the reference states
  USESQLRECOMMENDEDMEMORYLIMITS "can't be used with /SQLMINMEMORY and /SQLMAXMEMORY".
* Last version whose setup accepts Conn, BC, SDK, SNAC_SDK, DREPLAY_CTLR, DREPLAY_CLT and Tools.
* **Still not present:** PRODUCTCOVEREDBYSA and the AZURE settings (2022 and later);
  SQL_INST_JAVA / SQLJAVADIR (2019 only, and this build does not want Java).

### 2022

* Same parameter set as 2019.
* **PRODUCTCOVEREDBYSA is deliberately absent** even though 2022 is the first version that has it:
  it is documented Required *only* when installing the Azure Extension feature, and this template
  never installs AZUREEXTENSION. Every AZURE setting is absent for the same reason.
* FEATURES must not contain Conn, BC, SDK, SNAC_SDK, DREPLAY_CTLR, DREPLAY_CLT or Tools. Because
  Conn is gone, setup no longer installs sqlcmd - Install-Sql.ps1 installs the ODBC driver, the
  OLE DB driver and the standalone command line utilities afterwards.

### 2025

* **Parameter set is identical to 2022 for a Database Engine only install.** The only 2025-specific
  additions in the reference are IACCEPTDQUNINSTALL, which belongs to the **Upgrade** action and
  would be rejected in an Install answer file, and the extension of AZUREEXTENSION to SQL Server on
  Azure VM.
* PRODUCTCOVEREDBYSA and every AZURE setting stay absent.
* FEATURES restrictions are the same as 2022.

## Settings that differ between versions - the short version

| Setting | 2016 | 2017 | 2019 | 2022 | 2025 |
| --- | --- | --- | --- | --- | --- |
| SUPPRESSPRIVACYSTATEMENTNOTICE | no | yes | yes | yes | yes |
| MAXDOP placeholder line | no | no | yes | yes | yes |
| memory placeholder line | no | no | yes | yes | yes |
| everything else in the file | same | same | same | same | same |

## Value syntax rules that these files follow

Taken from "Proper use of setup parameters" on the parameter reference.

```ini
; single value settings are quoted
SQLSVCSTARTUPTYPE="Automatic"

; boolean switches spell out True / False
SQLSVCINSTANTFILEINIT="True"

; protocol settings are 1 / 0, not True / False
TCPENABLED="1"
NPENABLED="0"

; FEATURES is the documented exception: comma delimited, no spaces, not quoted
FEATURES=SQLENGINE,REPLICATION,FULLTEXT

; multi value settings are space separated with each value quoted
SQLSYSADMINACCOUNTS="CONTOSO\chadmin" "CONTOSO\SqlAdmins"

; mixed mode only - both lines together, or neither
SECURITYMODE="SQL"
SAPWD="..."
```

## Service account model

Per-service virtual accounts, never a shared domain account, and never a password in the file.

```text
Default instance  SQLSVCACCOUNT = NT SERVICE\MSSQLSERVER
                  AGTSVCACCOUNT = NT Service\SQLSERVERAGENT
Named instance    SQLSVCACCOUNT = NT SERVICE\MSSQL$<InstanceName>
                  AGTSVCACCOUNT = NT Service\SQLAGENT$<InstanceName>
```

SQLSVCPASSWORD and AGTSVCPASSWORD are deliberately absent: the reference states the password
parameters must not be supplied for a managed service account, virtual account or built-in account.
AGTSVCSTARTUPTYPE is `Automatic`, because a golden image whose Agent does not start on boot has no
scheduled backups. BROWSERSVCSTARTUPTYPE is filled by the script - `Disabled` for a default
instance, `Automatic` for a named instance, which is the only case that needs the Browser.

## Documented gotcha that these templates avoid

The reference warns that if `INSTANCEDIR` and `SQLUSERDBDIR` are the same path, SQL Server Agent
and Full Text Search fail to start because of missing permissions. `INSTANCEDIR` here stays under
Program Files and `SQLUSERDBDIR` is always filled from the data volume. Do not "simplify" this by
pointing both at the same place.

## Placeholder tokens

The five templates use only tokens that `Install-Sql.ps1` substitutes. Twenty-three tokens exist in
that script's replacement table; 2016 and 2017 use twenty-one of them and deliberately omit the
MAXDOP and memory tokens, 2019/2022/2025 use all twenty-three.

Two rules, both enforced by the script:

1. A token in a template that the script does not replace ships a literal placeholder into setup.
   The script scans the finished file and aborts instead.
2. A token the script replaces that no template contains silently drops that setting - which is
   fine only when the script also declines to produce a value for it, as with the MAXDOP and memory
   tokens below 2019.

The scan does **not** skip comment lines, so never write a doubled-at-sign token inside a comment.

## If you add a feature

Adding `AS` or `IS` to FEATURES also makes ASSVCACCOUNT / ASSYSADMINACCOUNTS / ISSVCACCOUNT
Required. None of them are in these templates, and adding them needs matching tokens in
`Install-Sql.ps1` first. Adding `AZUREEXTENSION` additionally requires PRODUCTCOVEREDBYSA and the
AZURE settings; the script refuses that feature outright for this Evaluation, non-Arc build.
