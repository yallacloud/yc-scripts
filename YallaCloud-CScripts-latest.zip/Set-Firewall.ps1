# Set-Firewall.ps1 - YALLACLOUD inbound/outbound firewall policy.
#
# WHAT CHANGED AND WHY (repair of audit finding P0-7)
#   BEFORE: one inbound TCP rule covering 32 entries (1433 1443 1521 3306 5432 3389 3222 5985 5986
#           and the range 5000-5500) plus a UDP rule for 5000-5500, both created with -Profile Any and
#           NO -RemoteAddress, i.e. reachable from 0.0.0.0/0. 'File and Printer Sharing' was enabled by
#           default, publishing 445 and 137-139 on Domain, Public and Private. On a CloudStack instance
#           with a public IP that exposed SQL Server, MySQL, PostgreSQL, Oracle, RDP, SMB and plaintext
#           WinRM to the internet. It was documented in the help as "the YALLACLOUD standard".
#   AFTER:  1) The default set is management-only: RDP (3389) and SSH (3222), -Profile Domain,Private,
#              always scoped with -RemoteAddress (default 'LocalSubnet', never 'Any').
#           2) Database ports, monitoring/exporter ports, WinRM and file sharing are OPT-IN switches and
#              every one of them REQUIRES an explicit -MgmtCidr. A world-open rule for a database port is
#              refused outright and cannot be forced.
#           3) 5985 is plaintext WinRM. It is never opened unless -Winrm -AllowPlaintextWinrm is given
#              together with an explicit -MgmtCidr, and it warns loudly every run. -Winrm alone opens 5986
#              only, and warns if no HTTPS listener/certificate is present.
#           4) The legacy wide-open rules this script used to create are DELETED on every run, so
#              upgrading the script actually closes the ports it previously opened.
#           5) Every rule is created with -ErrorAction Stop inside try/catch. No -EA SilentlyContinue on
#              anything load bearing. Every rule has a stable -Name and is rebuilt, so re-running never
#              duplicates a rule.
#           6) After applying, the live rule set is read back from Windows and logged, so the log records
#              what is ACTUALLY configured rather than what was intended.
#           7) Every exit path calls Stop-YcLog <code> first; Write-YcLog is always passed a level STRING.
#
# OVERLAP WITH yc-boot.ps1 (documented, not duplicated)
#   yc-boot.ps1 step 3 creates, at every boot when absent, these inbound rules with -Profile Any and no
#   -RemoteAddress, i.e. world open:
#       YC-SSH-3222 (TCP 3222), YC-RDP-3389 (TCP 3389),
#       YC-WinRM-5985 (TCP 5985, PLAINTEXT), YC-WinRM-5986 (TCP 5986), YC-ICMPv4 (ICMPv4 echo).
#   That directly contradicts the policy in this script: scoping 3389/3222/5985/5986 here would be
#   pointless while yc-boot leaves an unscoped duplicate of the same ports in place. yc-boot only creates
#   a rule when one does not already exist, so this script does NOT delete those rules (deleting them
#   would make yc-boot recreate them world open at the next boot). Instead it RE-SCOPES them in place to
#   -RemoteAddress <MgmtCidr> -Profile Domain,Private, and disables YC-WinRM-5985 unless plaintext WinRM
#   was explicitly requested. Use -SkipBootRuleHardening to leave them alone. yc-boot.ps1 itself still
#   needs fixing; that is a separate task and is NOT done here.
#
# PowerShell 5.1, Windows Server 2016-2025, ASCII only, unattended safe (no prompts).

param(
  [switch]$NoRdp,
  [switch]$NoSharing,
  [switch]$NoIcmp,
  [string[]]$ExtraTcpIn,
  [string[]]$ExtraUdpIn,
  [string[]]$MgmtCidr = @('LocalSubnet'),
  [string[]]$RemoteAddress = @('Any'),
  [switch]$Web,
  [switch]$Monitoring,
  [switch]$Database,
  [switch]$Winrm,
  [switch]$AllowPlaintextWinrm,
  [switch]$EnableSharing,
  [switch]$IncludePublicProfile,
  [switch]$OpenOutbound,
  [switch]$SkipBootRuleHardening,
  [switch]$WhatIf,
  [switch]$Force,
  [switch]$Help
)

. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'set-firewall'
$ErrorActionPreference = 'Continue'   # per-operation -ErrorAction Stop inside try/catch is used instead

if($Help){
@"
set-firewall  -  YALLACLOUD inbound firewall policy. SAFE BY DEFAULT: management ports only, always
                 scoped to a management network. Nothing sensitive is opened unless you ask for it AND
                 give it a management CIDR.

WHAT IT OPENS BY DEFAULT (and nothing else)
  TCP 3389 (RDP) and TCP 3222 (SSH), -Profile Domain,Private, scoped to -MgmtCidr (default LocalSubnet).
  ICMPv4 echo, scoped to -MgmtCidr (suppress with -NoIcmp).
  Outbound stays default-allow, so every agent that dials out (Salt, Wazuh, Zabbix, GLPI, Acronis,
  Bitdefender, Site24x7, telemetry push, Windows Update, choco/pip) keeps working with no rules.

WHAT IS NO LONGER OPENED BY DEFAULT (this is the P0-7 fix)
  Databases 1433 1443 1521 3306 5432 - now -Database, and an explicit -MgmtCidr is MANDATORY.
  Plaintext WinRM 5985            - now -Winrm -AllowPlaintextWinrm, explicit -MgmtCidr MANDATORY.
  File and Printer Sharing 445, 137-139 - now -EnableSharing, explicit -MgmtCidr MANDATORY.
  Web 80 443 8080 8443            - now -Web.
  Exporters/agents 9100 9182 9104 9187 9399 9273 12345 4317 4318 10050 62354 44445, SNMP 161/162
                                  - now -Monitoring, explicit -MgmtCidr MANDATORY.
  The ranges 5000-5500 TCP and UDP are GONE. If you need them, pass them via -ExtraTcpIn / -ExtraUdpIn
  with a real -RemoteAddress.
  A rule that is world open (-RemoteAddress Any) for a database port is REFUSED and cannot be forced.

USAGE:
  set-firewall                                            baseline: RDP + SSH + ICMP on LocalSubnet
  set-firewall -MgmtCidr 10.20.0.0/16                     baseline scoped to your management network
  set-firewall -MgmtCidr 10.20.0.0/16 -Database           add MSSQL/Oracle/MySQL/Postgres for that CIDR
  set-firewall -MgmtCidr 10.20.0.0/16 -Monitoring -Winrm  add exporters + WinRM HTTPS (5986)
  set-firewall -Web                                       add 80/443/8080/8443 to -RemoteAddress (Any)
  set-firewall -Web -RemoteAddress 203.0.113.0/24         add web, but only for that source range
  set-firewall -MgmtCidr 10.20.0.0/16 -EnableSharing      SMB, scoped, opt-in
  set-firewall -WhatIf -MgmtCidr 10.20.0.0/16 -Database   print the plan, change nothing
  set-firewall -Help

PARAMETERS:
  -MgmtCidr <list>       Management source scope for every sensitive rule (RDP, SSH, WinRM, databases,
                         monitoring, SMB, ICMP). Accepts CIDR (10.20.0.0/16), single IPs, ranges
                         (10.0.0.4-10.0.0.9) or the keywords LocalSubnet / Intranet.
                         DEFAULT 'LocalSubnet'. 'LocalSubnet' counts as NOT explicit: -Database,
                         -EnableSharing, -Monitoring and -AllowPlaintextWinrm all refuse to run until you
                         pass a real CIDR. Never accepts 'Any'.
  -RemoteAddress <list>  Source scope for the -Web ports and for -ExtraTcpIn/-ExtraUdpIn only.
                         DEFAULT 'Any', because 80/443 are usually meant to be public.
  -Web                   Open TCP 80,443,8080,8443 scoped to -RemoteAddress.
  -Monitoring            Open the exporter/agent ports + SNMP, scoped to -MgmtCidr (explicit required).
  -Database              Open 1433,1443,1521,3306,5432, scoped to -MgmtCidr (explicit required).
                         Refused outright if the scope is world open. -Force does not override this.
  -Winrm                 Open TCP 5986 (WinRM over HTTPS) scoped to -MgmtCidr. Warns if this host has no
                         HTTPS WinRM listener / certificate, because 5986 without a cert is not usable.
  -AllowPlaintextWinrm   With -Winrm, ALSO open TCP 5985. 5985 is UNENCRYPTED: credentials and session
                         data cross the wire in the clear. Requires an explicit -MgmtCidr and logs a
                         WARN on every run. Prefer fixing the 5986 listener instead.
  -EnableSharing         Enable File and Printer Sharing (445, 137-139) AND re-scope that whole rule
                         group to -MgmtCidr on Domain,Private. Requires an explicit -MgmtCidr.
  -NoSharing             Kept for wrapper compatibility. Sharing is now OFF by default, so this is only
                         needed to veto an -EnableSharing passed on the same line. -NoSharing wins.
  -NoRdp                 Do not open 3389.
  -NoIcmp                Do not open ICMPv4 echo.
  -ExtraTcpIn <list>     Extra inbound TCP ports/ranges, scoped to -RemoteAddress. Well known sensitive
                         ports are rejected when the scope is world open (databases always; the rest
                         unless -Force).
  -ExtraUdpIn <list>     Same, UDP.
  -IncludePublicProfile  Also apply the management rules to the Public profile (still CIDR scoped). See
                         LOCKOUT GUARD below.
  -OpenOutbound          Recreate the explicit 'allow all outbound' rule. Not needed: the default
                         outbound action is already Allow, which is why this is now opt-in.
  -SkipBootRuleHardening Do not touch the world-open rules yc-boot.ps1 creates (see OVERLAP below).
  -WhatIf                Print every rule that would be created or deleted and exit. Changes nothing.
  -Force                 Allow non-database sensitive ports in -ExtraTcpIn/-ExtraUdpIn with a world-open
                         scope, and bypass the lockout guard. Never allows a world-open database port.
  -Help                  Show this help and exit.

LOCKOUT GUARD
  Management rules are created on Domain,Private only. A CloudStack NIC on an unidentified network is
  classified Public, where those rules do not apply. If any connected interface is Public and you did not
  pass -IncludePublicProfile, this script REFUSES to change anything and exits 2 rather than enabling a
  default-block firewall that your own RDP session does not match. Fix it either way:
      set-firewall -MgmtCidr <cidr> -IncludePublicProfile
      Set-NetConnectionProfile -InterfaceIndex <n> -NetworkCategory Private   (then re-run)

OVERLAP WITH yc-boot.ps1
  yc-boot.ps1 recreates YC-SSH-3222, YC-RDP-3389, YC-WinRM-5985, YC-WinRM-5986 and YC-ICMPv4 at boot with
  -Profile Any and no source scope, i.e. world open, whenever they are absent. This script therefore does
  not delete them (deletion just brings them back at next boot) - it re-scopes them in place to your
  -MgmtCidr on Domain,Private and disables YC-WinRM-5985 unless you asked for plaintext WinRM. Suppress
  with -SkipBootRuleHardening. yc-boot.ps1 still needs its own fix.

EXIT CODES: 0 ok, 2 refused (unsafe or missing arguments, lockout guard), 3 one or more rules failed,
            5 not elevated.
Log: C:\Scripts\set-firewall.log
"@ | Write-Host -ForegroundColor Cyan
  Stop-YcLog 0
  exit 0
}

Assert-YcPrereqs -NeedAdmin

# ---------------------------------------------------------------- helpers
$script:YcFail    = 0
$script:MgmtGiven = $PSBoundParameters.ContainsKey('MgmtCidr')

# Test-YcWorldOpen ("is this scope open to the whole internet?") now lives in _yc-lib.ps1 so
# that this script and the exporter registrars share ONE implementation. Dot-sourced above.

# Parse '5000-5010' / '445' into interval objects. NOT capped: every safety DECISION is taken
# from these intervals, because Set-YcFwRule is handed the raw entry and opens the whole range.
function Get-YcPortRanges{
  param([string[]]$Entries)
  $out = New-Object System.Collections.ArrayList
  foreach($e in $Entries){
    if([string]::IsNullOrEmpty($e)){ continue }
    $t = $e.Trim()
    if($t -match '^\s*(\d+)\s*-\s*(\d+)\s*$'){
      $a = [int]$matches[1]; $b = [int]$matches[2]
      if($b -lt $a){ $tmp=$a; $a=$b; $b=$tmp }
      [void]$out.Add(@{ a=$a; b=$b })
    } elseif($t -match '^\s*\d+\s*$'){
      $n = [int]$t
      [void]$out.Add(@{ a=$n; b=$n })
    }
  }
  return $out.ToArray()
}

# Which members of $List fall inside ANY interval of $Entries. Interval overlap, never
# enumeration: '20000-65535' is 45536 ports and enumerating a truncated prefix of it is exactly
# how 27017 (MongoDB) and 50000 (DB2) used to slip past the guard and reach 0.0.0.0/0.
function Get-YcPortsInRanges{
  param([string[]]$Entries,[int[]]$List)
  $hit = New-Object System.Collections.ArrayList
  foreach($r in @(Get-YcPortRanges -Entries $Entries)){
    $a = [int]$r.a; $b = [int]$r.b
    foreach($p in @($List | Where-Object { $_ -ge $a -and $_ -le $b })){
      if(-not $hit.Contains([int]$p)){ [void]$hit.Add([int]$p) }
    }
  }
  return $hit.ToArray()
}

# Enumerate the individual port numbers, capped so a silly range cannot hang us. FOR LOG TEXT
# AND THE READ-BACK DISPLAY ONLY - never for a safety decision. See Get-YcPortsInRanges.
function Expand-YcPorts{
  param([string[]]$Entries)
  $out = New-Object System.Collections.ArrayList
  foreach($r in @(Get-YcPortRanges -Entries $Entries)){
    $a = [int]$r.a; $b = [int]$r.b
    if(($b - $a) -gt 4096){ $b = $a + 4096 }   # display cap only; the decision never uses this
    for($i=$a; $i -le $b; $i++){ [void]$out.Add($i) }
  }
  return $out
}

# Ports that must never face the internet. Databases are a hard refusal; the rest need -Force.
$script:YcDbPorts        = @(1433,1443,1521,3306,5432,1830,27017,6379,9200,5984,7000,7001,9042,11211,50000)
$script:YcSensitivePorts = @(21,22,23,25,53,110,135,137,138,139,143,389,445,464,636,1723,3222,3268,3389,
                             5060,5432,5900,5985,5986,6379,7001,8009,9042,9200,11211,27017)

function Test-YcPortsAllowed{
  param([string]$Label,[string[]]$Entries,[string[]]$Scope)
  # returns $true when it is safe to create the rule
  if(-not (Test-YcWorldOpen -Scope $Scope)){ return $true }
  $db = @(Get-YcPortsInRanges -Entries $Entries -List $script:YcDbPorts | Sort-Object)
  if($db.Count -gt 0){
    Write-YcLog ("REFUSED: " + $Label + " would publish database port(s) " + ($db -join ',') +
                 " to the whole internet (-RemoteAddress is Any). Pass -MgmtCidr / -RemoteAddress with a real network. This cannot be forced.") 'ERROR'
    return $false
  }
  $sens = @(Get-YcPortsInRanges -Entries $Entries -List $script:YcSensitivePorts | Sort-Object)
  if($sens.Count -gt 0){
    if($Force){
      Write-YcLog ("-Force: " + $Label + " publishes sensitive port(s) " + ($sens -join ',') +
                   " to the whole internet. This is your explicit choice and it is being logged.") 'WARN'
      return $true
    }
    Write-YcLog ("REFUSED: " + $Label + " would publish sensitive port(s) " + ($sens -join ',') +
                 " to the whole internet. Scope it with -RemoteAddress, or re-run with -Force if that is genuinely intended.") 'ERROR'
    return $false
  }
  return $true
}

# Idempotent rule writer: stable -Name, delete then recreate, -ErrorAction Stop, reported failures.
function Set-YcFwRule{
  param(
    [string]$Name,
    [string]$DisplayName,
    [string]$Protocol,
    [string[]]$LocalPort,
    [string[]]$FwProfile,
    [string[]]$Scope,
    [int]$IcmpType = -1
  )
  $desc = ($Name + ' [' + $Protocol +
           $(if($LocalPort){ ' ' + ($LocalPort -join ',') } elseif($IcmpType -ge 0){ ' type ' + $IcmpType } else { '' }) +
           '] profile=' + ($FwProfile -join ',') + ' from=' + ($Scope -join ','))
  if($WhatIf){ Write-YcLog ('WHATIF would create ' + $desc) 'INFO'; return $true }
  try{
    $existing = $null
    try{ $existing = Get-NetFirewallRule -Name $Name -ErrorAction Stop }catch{ $existing = $null }
    if($existing){ Remove-NetFirewallRule -Name $Name -ErrorAction Stop }   # rebuild = idempotent, no duplicates
    $p = @{
      Name          = $Name
      DisplayName   = $DisplayName
      Group         = 'YallaCloud'
      Direction     = 'Inbound'
      Action        = 'Allow'
      Protocol      = $Protocol
      Profile       = ($FwProfile -join ',')
      RemoteAddress = $Scope
      Enabled       = 'True'
      ErrorAction   = 'Stop'
    }
    if($LocalPort){ $p['LocalPort'] = $LocalPort }
    if($IcmpType -ge 0){ $p['IcmpType'] = [string]$IcmpType }
    New-NetFirewallRule @p | Out-Null
    Write-YcLog ('created ' + $desc) 'OK'
    return $true
  }catch{
    $script:YcFail++
    Write-YcLog ('FAILED to create ' + $desc + ' : ' + $_.Exception.Message) 'ERROR'
    return $false
  }
}

function Remove-YcRuleByDisplayName{
  param([string]$DisplayName,[string]$Why)
  try{
    $r = $null
    try{ $r = Get-NetFirewallRule -DisplayName $DisplayName -ErrorAction Stop }catch{ $r = $null }
    if(-not $r){ return }
    if($WhatIf){ Write-YcLog ("WHATIF would DELETE legacy rule '" + $DisplayName + "' (" + $Why + ")") 'INFO'; return }
    Remove-NetFirewallRule -DisplayName $DisplayName -ErrorAction Stop
    Write-YcLog ("DELETED legacy rule '" + $DisplayName + "' (" + $Why + ")") 'OK'
  }catch{
    $script:YcFail++
    Write-YcLog ("could not delete legacy rule '" + $DisplayName + "': " + $_.Exception.Message) 'ERROR'
  }
}

# ---------------------------------------------------------------- argument validation (before any change)
if(Test-YcWorldOpen -Scope $MgmtCidr){
  Write-YcLog ("REFUSED: -MgmtCidr resolves to a world-open scope (" + ($MgmtCidr -join ',') +
               "). The management scope must be a real network, e.g. -MgmtCidr 10.20.0.0/16.") 'ERROR'
  Stop-YcLog 2; exit 2
}
if($NoSharing -and $EnableSharing){
  Write-YcLog '-NoSharing and -EnableSharing were both given. The safe option wins: file sharing stays OFF.' 'WARN'
  $EnableSharing = $false
}
foreach($needsCidr in @(
    @{ n='-Database';   on=[bool]$Database },
    @{ n='-Monitoring'; on=[bool]$Monitoring },
    @{ n='-EnableSharing'; on=[bool]$EnableSharing },
    @{ n='-AllowPlaintextWinrm'; on=[bool]$AllowPlaintextWinrm })){
  if($needsCidr.on -and -not $script:MgmtGiven){
    Write-YcLog ("REFUSED: " + $needsCidr.n + " requires an explicit -MgmtCidr. The default 'LocalSubnet' is not " +
                 "specific enough to publish that traffic. Re-run with -MgmtCidr <your management network>.") 'ERROR'
    Stop-YcLog 2; exit 2
  }
}
if($AllowPlaintextWinrm -and -not $Winrm){
  Write-YcLog '-AllowPlaintextWinrm has no effect without -Winrm. Ignoring it; 5985 stays closed.' 'WARN'
  $AllowPlaintextWinrm = $false
}

# Lockout guard: management rules land on Domain,Private only, so a Public-classified NIC would not match.
$mgmtProfiles = @('Domain','Private')
if($IncludePublicProfile){ $mgmtProfiles += 'Public' }
try{
  $pub = @(Get-NetConnectionProfile -ErrorAction Stop | Where-Object { $_.NetworkCategory -eq 'Public' })
}catch{
  $pub = @()
  Write-YcLog ('could not read connection profiles (' + $_.Exception.Message + '); lockout guard skipped') 'WARN'
}
if($pub.Count -gt 0 -and -not $IncludePublicProfile){
  foreach($p in $pub){ Write-YcLog ("interface " + $p.InterfaceIndex + " '" + $p.InterfaceAlias + "' is classified Public") 'WARN' }
  if($Force -or $WhatIf){
    Write-YcLog 'Lockout guard bypassed (-Force/-WhatIf). Management rules will NOT apply to the Public interfaces above.' 'WARN'
  }else{
    Write-YcLog ("REFUSED: a connected interface is classified Public, but the management rules are being created " +
                 "for Domain,Private only - enabling a default-block firewall now could drop your own session. " +
                 "Re-run with -IncludePublicProfile (rules stay scoped to -MgmtCidr), or reclassify the interface " +
                 "with Set-NetConnectionProfile -NetworkCategory Private, then re-run.") 'ERROR'
    Stop-YcLog 2; exit 2
  }
}

Write-YcLog ("mode=" + $(if($WhatIf){'WHATIF (nothing will be changed)'}else{'APPLY'}) +
             " mgmtCidr=" + ($MgmtCidr -join ',') + " (explicit=" + $script:MgmtGiven + ")" +
             " remoteAddress=" + ($RemoteAddress -join ',') + " mgmtProfiles=" + ($mgmtProfiles -join ',')) 'INFO'
if(-not $script:MgmtGiven){
  Write-YcLog "no -MgmtCidr given: management rules are scoped to 'LocalSubnet'. That is safe but broad - pass -MgmtCidr <your management network> for a tighter rule." 'WARN'
}

# ---------------------------------------------------------------- 1. profiles
try{
  if($WhatIf){
    Write-YcLog 'WHATIF would set Domain,Public,Private: Enabled=True DefaultInboundAction=Block DefaultOutboundAction=Allow' 'INFO'
  }else{
    Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True -DefaultInboundAction Block -DefaultOutboundAction Allow -ErrorAction Stop
    Write-YcLog 'firewall enabled on Domain,Public,Private (inbound default Block, outbound default Allow)' 'OK'
  }
}catch{
  $script:YcFail++
  Write-YcLog ('FAILED to set firewall profiles: ' + $_.Exception.Message) 'ERROR'
}

# ---------------------------------------------------------------- 2. remove the legacy wide-open rules
# These are exactly what the old version of this script created. Leaving them behind would mean the fix
# changes nothing on an already-deployed host.
Remove-YcRuleByDisplayName -DisplayName 'YC App Ports TCP In' -Why 'P0-7: 32 port entries incl. databases, 5985 and 5000-5500, Profile Any, no source scope'
Remove-YcRuleByDisplayName -DisplayName 'YC App Ports UDP In' -Why 'P0-7: UDP 5000-5500, Profile Any, no source scope'
Remove-YcRuleByDisplayName -DisplayName 'ICMPv4 Echo In'      -Why 'replaced by YC-ICMP4-Echo-In, scoped to -MgmtCidr'
if(-not $OpenOutbound){
  Remove-YcRuleByDisplayName -DisplayName 'YC Allow All Outbound' -Why 'redundant: DefaultOutboundAction is already Allow'
}

# ---------------------------------------------------------------- 3. outbound (default-allow already covers agents)
if($OpenOutbound){
  if($WhatIf){
    Write-YcLog 'WHATIF would create YC-Outbound-All-Out (explicit allow-all egress)' 'INFO'
  }else{
    try{
      $ex = $null
      try{ $ex = Get-NetFirewallRule -Name 'YC-Outbound-All-Out' -ErrorAction Stop }catch{ $ex = $null }
      if($ex){ Remove-NetFirewallRule -Name 'YC-Outbound-All-Out' -ErrorAction Stop }
      New-NetFirewallRule -Name 'YC-Outbound-All-Out' -DisplayName 'YC Allow All Outbound' -Group 'YallaCloud' `
        -Direction Outbound -Action Allow -Profile Any -Enabled 'True' -ErrorAction Stop | Out-Null
      Write-YcLog 'created YC-Outbound-All-Out (explicit allow-all egress)' 'OK'
    }catch{
      $script:YcFail++
      Write-YcLog ('FAILED to create the outbound allow-all rule: ' + $_.Exception.Message) 'ERROR'
    }
  }
}else{
  Write-YcLog 'outbound left at default Allow - Salt, Wazuh, Zabbix, GLPI, Acronis, Bitdefender, Site24x7 and telemetry all dial OUT and need no inbound rule' 'INFO'
}

# ---------------------------------------------------------------- 4. base management set
if(-not $NoRdp){
  Set-YcFwRule -Name 'YC-Mgmt-RDP-TCP-In' -DisplayName 'YC Mgmt RDP TCP In' -Protocol TCP `
               -LocalPort @('3389') -FwProfile $mgmtProfiles -Scope $MgmtCidr | Out-Null
  if(-not $WhatIf){
    try{
      Set-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -Value 0 -ErrorAction Stop
      Write-YcLog 'Remote Desktop connections enabled (fDenyTSConnections=0)' 'OK'
    }catch{
      $script:YcFail++
      Write-YcLog ('FAILED to enable Remote Desktop (fDenyTSConnections): ' + $_.Exception.Message) 'ERROR'
    }
  }
}else{
  Write-YcLog '-NoRdp: 3389 not opened' 'INFO'
}

Set-YcFwRule -Name 'YC-Mgmt-SSH-TCP-In' -DisplayName 'YC Mgmt SSH TCP In' -Protocol TCP `
             -LocalPort @('3222') -FwProfile $mgmtProfiles -Scope $MgmtCidr | Out-Null

if(-not $NoIcmp){
  # NOTE overlap: yc-boot.ps1 also creates 'YC-ICMPv4' (ICMPv4 echo, -Profile Any, no source scope).
  Set-YcFwRule -Name 'YC-ICMP4-Echo-In' -DisplayName 'YC ICMPv4 Echo In' -Protocol ICMPv4 `
               -FwProfile @('Domain','Private','Public') -Scope $MgmtCidr -IcmpType 8 | Out-Null
}

# ---------------------------------------------------------------- 5. opt-in sets
if($Web){
  $webPorts = @('80','443','8080','8443')
  if(Test-YcPortsAllowed -Label 'YC-Web-TCP-In' -Entries $webPorts -Scope $RemoteAddress){
    $webProfiles = @('Domain','Private','Public')   # web is meant to be reachable; the scope is -RemoteAddress
    Set-YcFwRule -Name 'YC-Web-TCP-In' -DisplayName 'YC Web TCP In' -Protocol TCP `
                 -LocalPort $webPorts -FwProfile $webProfiles -Scope $RemoteAddress | Out-Null
    if(Test-YcWorldOpen -Scope $RemoteAddress){
      Write-YcLog 'YC-Web-TCP-In is open to the whole internet (that is the point of -Web). 8080 and 8443 are often admin consoles - scope them with -RemoteAddress if they are not meant to be public.' 'WARN'
    }
  }else{
    # A refusal is a refusal: record the failure and take the documented exit 2. Falling through
    # here used to reach the final 'no world-open sensitive ports created' OK line and exit 0.
    $script:YcFail++
    Stop-YcLog 2; exit 2
  }
}

if($Monitoring){
  $monTcp = @('9100','9182','9104','9187','9399','9273','12345','4317','4318','10050','62354','44445')
  $monUdp = @('161','162')
  Set-YcFwRule -Name 'YC-Monitoring-TCP-In' -DisplayName 'YC Monitoring TCP In' -Protocol TCP `
               -LocalPort $monTcp -FwProfile $mgmtProfiles -Scope $MgmtCidr | Out-Null
  Set-YcFwRule -Name 'YC-Monitoring-UDP-In' -DisplayName 'YC Monitoring UDP In' -Protocol UDP `
               -LocalPort $monUdp -FwProfile $mgmtProfiles -Scope $MgmtCidr | Out-Null
  Write-YcLog 'exporters expose host inventory, process lists and metrics without authentication - they are scoped to -MgmtCidr on purpose' 'INFO'
}

if($Database){
  $dbPorts = @('1433','1443','1521','3306','5432')
  if(Test-YcPortsAllowed -Label 'YC-Database-TCP-In' -Entries $dbPorts -Scope $MgmtCidr){
    Set-YcFwRule -Name 'YC-Database-TCP-In' -DisplayName 'YC Database TCP In' -Protocol TCP `
                 -LocalPort $dbPorts -FwProfile $mgmtProfiles -Scope $MgmtCidr | Out-Null
  }else{
    $script:YcFail++
    Stop-YcLog 2; exit 2
  }
}

if($Winrm){
  Set-YcFwRule -Name 'YC-WinRM-HTTPS-TCP-In' -DisplayName 'YC WinRM HTTPS TCP In' -Protocol TCP `
               -LocalPort @('5986') -FwProfile $mgmtProfiles -Scope $MgmtCidr | Out-Null
  # 5986 without an HTTPS listener + certificate is a dead port, so say so rather than pretend it works.
  $httpsListener = $false
  try{
    $ls = Get-ChildItem 'WSMan:\localhost\Listener' -ErrorAction Stop
    foreach($l in $ls){
      try{
        $t = (Get-ChildItem ($l.PSPath) -ErrorAction Stop | Where-Object { $_.Name -eq 'Transport' }).Value
        if($t -eq 'HTTPS'){ $httpsListener = $true }
      }catch{}   # probe only: an unreadable listener just means "assume no HTTPS", which warns. Not load bearing.
    }
  }catch{
    Write-YcLog ('could not query WinRM listeners (' + $_.Exception.Message + ')') 'WARN'
  }
  if($httpsListener){
    Write-YcLog 'WinRM HTTPS listener present; 5986 is usable' 'OK'
  }else{
    Write-YcLog 'no WinRM HTTPS listener found. 5986 is open but nothing is listening on it. Create the listener with a server certificate (winrm quickconfig -transport:https) before relying on this rule.' 'WARN'
  }
  if($AllowPlaintextWinrm){
    if(Test-YcWorldOpen -Scope $MgmtCidr){
      Write-YcLog 'REFUSED: 5985 cannot be opened with a world-open scope.' 'ERROR'
      Stop-YcLog 2; exit 2
    }
    Write-YcLog '*** WARNING *** opening TCP 5985 - WinRM over HTTP is UNENCRYPTED. Credentials and all session traffic are readable by anything on the path. This is scoped to -MgmtCidr, but it should be a temporary measure only: configure the 5986 HTTPS listener and drop -AllowPlaintextWinrm.' 'WARN'
    Set-YcFwRule -Name 'YC-WinRM-HTTP-TCP-In' -DisplayName 'YC WinRM PLAINTEXT HTTP TCP In' -Protocol TCP `
                 -LocalPort @('5985') -FwProfile $mgmtProfiles -Scope $MgmtCidr | Out-Null
  }else{
    # Make sure a previously opened 5985 rule from this script does not linger.
    Remove-YcRuleByDisplayName -DisplayName 'YC WinRM PLAINTEXT HTTP TCP In' -Why 'plaintext WinRM not requested this run'
  }
}

if($EnableSharing){
  if($WhatIf){
    Write-YcLog ("WHATIF would enable the 'File and Printer Sharing' group and re-scope it to " +
                 ($MgmtCidr -join ',') + " on " + ($mgmtProfiles -join ',')) 'INFO'
  }else{
    try{
      Enable-NetFirewallRule -DisplayGroup 'File and Printer Sharing' -ErrorAction Stop
      # Enabling the group alone would publish 445 and 137-139 on Domain, Public and Private with no source
      # scope. Constrain the group before leaving it enabled.
      Set-NetFirewallRule -DisplayGroup 'File and Printer Sharing' -RemoteAddress $MgmtCidr -Profile ($mgmtProfiles -join ',') -ErrorAction Stop
      Write-YcLog ("File and Printer Sharing enabled and scoped to " + ($MgmtCidr -join ',') +
                   " on " + ($mgmtProfiles -join ',') + " (SMB 445 and NetBIOS 137-139)") 'OK'
    }catch{
      $script:YcFail++
      Write-YcLog ('FAILED to enable/scope File and Printer Sharing: ' + $_.Exception.Message) 'ERROR'
    }
  }
}else{
  Write-YcLog 'file sharing not enabled (445 / 137-139 stay closed). Use -EnableSharing -MgmtCidr <cidr> if you need SMB.' 'INFO'
}

# ---------------------------------------------------------------- 6. extra ports
if($ExtraTcpIn){
  if(Test-YcPortsAllowed -Label 'YC-Extra-TCP-In' -Entries $ExtraTcpIn -Scope $RemoteAddress){
    Set-YcFwRule -Name 'YC-Extra-TCP-In' -DisplayName 'YC Extra TCP In' -Protocol TCP `
                 -LocalPort $ExtraTcpIn -FwProfile @('Domain','Private','Public') -Scope $RemoteAddress | Out-Null
  }else{
    $script:YcFail++
    Stop-YcLog 2; exit 2
  }
}else{
  Remove-YcRuleByDisplayName -DisplayName 'YC Extra TCP In' -Why 'no -ExtraTcpIn this run'
}
if($ExtraUdpIn){
  if(Test-YcPortsAllowed -Label 'YC-Extra-UDP-In' -Entries $ExtraUdpIn -Scope $RemoteAddress){
    Set-YcFwRule -Name 'YC-Extra-UDP-In' -DisplayName 'YC Extra UDP In' -Protocol UDP `
                 -LocalPort $ExtraUdpIn -FwProfile @('Domain','Private','Public') -Scope $RemoteAddress | Out-Null
  }else{
    $script:YcFail++
    Stop-YcLog 2; exit 2
  }
}else{
  Remove-YcRuleByDisplayName -DisplayName 'YC Extra UDP In' -Why 'no -ExtraUdpIn this run'
}

# ---------------------------------------------------------------- 7. harden the rules yc-boot.ps1 creates
# See the OVERLAP note in the header. yc-boot recreates these world open only when they are ABSENT, so we
# re-scope in place instead of deleting.
if(-not $SkipBootRuleHardening){
  $bootRules = @(
    @{ dn='YC-SSH-3222';   scope=$MgmtCidr; note='TCP 3222 SSH' },
    @{ dn='YC-RDP-3389';   scope=$MgmtCidr; note='TCP 3389 RDP' },
    @{ dn='YC-WinRM-5986'; scope=$MgmtCidr; note='TCP 5986 WinRM HTTPS' },
    @{ dn='YC-ICMPv4';     scope=$MgmtCidr; note='ICMPv4 echo' }
  )
  foreach($b in $bootRules){
    try{
      $r = $null
      try{ $r = Get-NetFirewallRule -DisplayName $b.dn -ErrorAction Stop }catch{ $r = $null }
      if(-not $r){ continue }
      if($WhatIf){
        Write-YcLog ("WHATIF would re-scope yc-boot rule '" + $b.dn + "' (" + $b.note + ") to " +
                     ($b.scope -join ',') + " on " + ($mgmtProfiles -join ',')) 'INFO'
        continue
      }
      Set-NetFirewallRule -DisplayName $b.dn -RemoteAddress $b.scope -Profile ($mgmtProfiles -join ',') -ErrorAction Stop
      Write-YcLog ("re-scoped yc-boot rule '" + $b.dn + "' (" + $b.note + ", was Profile Any / any source) to " +
                   ($b.scope -join ',') + " on " + ($mgmtProfiles -join ',')) 'OK'
    }catch{
      $script:YcFail++
      Write-YcLog ("could not re-scope yc-boot rule '" + $b.dn + "': " + $_.Exception.Message) 'ERROR'
    }
  }
  # YC-WinRM-5985 from yc-boot is world-open PLAINTEXT WinRM. Scope it if plaintext was asked for, else disable it.
  try{
    $r5985 = $null
    try{ $r5985 = Get-NetFirewallRule -DisplayName 'YC-WinRM-5985' -ErrorAction Stop }catch{ $r5985 = $null }
    if($r5985){
      if($WhatIf){
        Write-YcLog ("WHATIF would " + $(if($AllowPlaintextWinrm){'re-scope'}else{'DISABLE'}) + " yc-boot rule 'YC-WinRM-5985' (plaintext WinRM)") 'INFO'
      }elseif($AllowPlaintextWinrm){
        Set-NetFirewallRule -DisplayName 'YC-WinRM-5985' -RemoteAddress $MgmtCidr -Profile ($mgmtProfiles -join ',') -ErrorAction Stop
        Write-YcLog ("re-scoped yc-boot rule 'YC-WinRM-5985' (PLAINTEXT WinRM, was world open) to " + ($MgmtCidr -join ',')) 'WARN'
      }else{
        Set-NetFirewallRule -DisplayName 'YC-WinRM-5985' -Enabled False -ErrorAction Stop
        Write-YcLog "DISABLED yc-boot rule 'YC-WinRM-5985' - it published UNENCRYPTED WinRM to any source on any profile. Re-enable deliberately with -Winrm -AllowPlaintextWinrm -MgmtCidr <cidr> if you really need it." 'OK'
      }
    }
  }catch{
    $script:YcFail++
    Write-YcLog ("could not harden yc-boot rule 'YC-WinRM-5985': " + $_.Exception.Message) 'ERROR'
  }
}else{
  Write-YcLog '-SkipBootRuleHardening: the world-open YC-SSH-3222 / YC-RDP-3389 / YC-WinRM-5985 / YC-WinRM-5986 / YC-ICMPv4 rules created by yc-boot.ps1 were left untouched. Those ports remain reachable from any source.' 'WARN'
}

# ---------------------------------------------------------------- 8. read back and log what is ACTUALLY configured
if($WhatIf){
  Write-YcLog 'WHATIF complete - nothing was changed.' 'OK'
  Stop-YcLog 0
  exit 0
}

Write-YcLog '--- live inbound allow rules now in effect (read back from Windows) ---' 'INFO'
try{
  $live = Get-NetFirewallRule -Direction Inbound -Action Allow -Enabled True -ErrorAction Stop
  $worldOpenSensitive = 0
  foreach($r in $live){
    $pf = $null; $af = $null
    # Read-back only, and it fails safe: an unreadable address filter is reported as 'Any', which raises the
    # WARN rather than hiding it. Nothing here changes state, so a failure must not abort the post-check.
    try{ $pf = $r | Get-NetFirewallPortFilter -ErrorAction Stop }catch{}
    try{ $af = $r | Get-NetFirewallAddressFilter -ErrorAction Stop }catch{}
    $ports  = if($pf -and $pf.LocalPort){ (@($pf.LocalPort) -join ',') } else { 'n/a' }
    $proto  = if($pf -and $pf.Protocol){ $pf.Protocol } else { 'n/a' }
    $remote = if($af -and $af.RemoteAddress){ (@($af.RemoteAddress) -join ',') } else { 'Any' }
    if($ports -eq 'n/a' -and $proto -eq 'Any'){ continue }
    $isWorld = Test-YcWorldOpen -Scope @($remote)
    $hit = @()
    if($isWorld -and $ports -ne 'n/a'){
      $expanded = Expand-YcPorts -Entries @($ports -split ',')
      $hit = @($expanded | Where-Object { $script:YcSensitivePorts -contains $_ -or $script:YcDbPorts -contains $_ } | Select-Object -Unique)
    }
    $line = ("LIVE  " + $r.DisplayName + " | " + $proto + " " + $ports + " | profile=" + $r.Profile + " | from=" + $remote)
    if($hit.Count -gt 0){
      $worldOpenSensitive++
      Write-YcLog ($line + "  <== SENSITIVE PORT(S) " + ($hit -join ',') + " REACHABLE FROM ANY SOURCE") 'WARN'
    }else{
      Write-YcLog $line 'INFO'
    }
  }
  if($worldOpenSensitive -gt 0){
    Write-YcLog ("post-check: " + $worldOpenSensitive + " enabled inbound rule(s) still expose sensitive ports to any source. They were NOT created by this script (check GPO, the application installers, or -SkipBootRuleHardening) - review them by hand.") 'WARN'
  }else{
    Write-YcLog 'post-check: no enabled inbound rule exposes a sensitive port to an unrestricted source' 'OK'
  }
}catch{
  Write-YcLog ('could not read back the live rule set: ' + $_.Exception.Message) 'WARN'
}

try{
  foreach($p in (Get-NetFirewallProfile -ErrorAction Stop)){
    Write-YcLog ("LIVE  profile " + $p.Name + " enabled=" + $p.Enabled + " inbound=" + $p.DefaultInboundAction + " outbound=" + $p.DefaultOutboundAction) 'INFO'
  }
}catch{
  Write-YcLog ('could not read back the firewall profiles: ' + $_.Exception.Message) 'WARN'
}

if($script:YcFail -gt 0){
  Write-YcLog ("finished with " + $script:YcFail + " failure(s) - see the ERROR lines above") 'ERROR'
  Stop-YcLog 3
  exit 3
}

Write-YcLog 'firewall applied: management-scoped inbound, default-allow outbound, no world-open sensitive ports created' 'OK'
Stop-YcLog 0
exit 0
