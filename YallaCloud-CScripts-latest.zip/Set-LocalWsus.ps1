<#
  Set-LocalWsus.ps1 - point this machine at the YallaCloud local update server, or put it
  back on Microsoft. One script, four verbs, nothing to remember.

      set-local-wsus -Status        what am I pointed at right now?
      set-local-wsus -Test          can I actually reach the local server?
      set-local-wsus -Install       use the local server
      set-local-wsus -Uninstall     go back to Microsoft Update

  WHY: every VM that patches from Microsoft pulls the same gigabytes over the same link.
  Pointed at ycwsus01 they pull it once, from inside.

  READ THIS BEFORE YOU USE IT - THERE IS NO AUTOMATIC FALLBACK.
  Windows does not "try WSUS and then try Microsoft". Once a machine is pointed at a WSUS
  server, that server IS the source: if it is unreachable, the scan FAILS (0x8024401C /
  0x80244022) and the machine silently stops patching. It does not quietly go to Microsoft.
  That is a Windows behaviour, not a gap in this script, and it is why:
    - -Install REFUSES on a server it cannot reach (use -Force only if you know why),
    - -Status exits 1 on the dangerous state (configured but unreachable),
    - going back is ONE command, and that command is the fallback.

  Windows Server 2016-2025, PowerShell 5.1, ASCII only.
#>
param(
  [switch]$Install,
  [switch]$Uninstall,
  [switch]$Status,
  [switch]$Test,
  [string]$Server = '93.177.125.166',
  [int]$Port      = 8530,
  [switch]$Force,
  [switch]$Help
)

. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'set-local-wsus'
$ErrorActionPreference = 'Continue'

if($Help -or -not ($Install -or $Uninstall -or $Status -or $Test)){
@"
set-local-wsus  -  use the YallaCloud local update server (ycwsus01) instead of Microsoft.

USAGE:
  set-local-wsus -Status                     what this machine is pointed at, and is it healthy
  set-local-wsus -Test                       can this machine reach the local server (changes nothing)
  set-local-wsus -Install                    point this machine at the local server
  set-local-wsus -Uninstall                  put it back on Microsoft Update
  set-local-wsus -Install -Server 10.0.0.5   a different server (default $Server)
  set-local-wsus -Install -Port 8531         a different port (default 8530)
  set-local-wsus -Help

PARAMETERS:
  -Install     Point Windows Update at the local server. Runs -Test first and REFUSES if the
               server does not answer, because a machine pointed at an unreachable update
               server stops patching WITHOUT SAYING SO.
               Saves the current settings first, so -Uninstall can put them back exactly.
  -Uninstall   Remove the local-server policy and go back to Microsoft Update. THIS IS THE
               FALLBACK. Safe to run on a machine that was never configured.
  -Status      Print what is configured, whether the server answers, and when this machine
               last successfully scanned. Changes nothing.
  -Test        Reachability only: TCP to the port, then the WSUS web service. Changes nothing.
  -Server      Update server IP or hostname. Default $Server (ycwsus01).
  -Port        8530 for HTTP (default), 8531 for HTTPS.
  -Force       With -Install: configure even though the server did not answer. You are
               choosing to stop this machine patching until the server is back.

THERE IS NO AUTOMATIC FALLBACK TO MICROSOFT:
  Windows does not try the local server and then Microsoft. Once pointed at it, that server
  IS the source. If it goes away, scans fail and patching silently stops - so -Status exits 1
  on that state, and 'set-local-wsus -Uninstall' is how you go back. One command.

EXIT CODES:
  0  did what you asked / configured and healthy
  1  -Status: configured but the server does NOT answer (patching is silently dead)
     -Test:   the server does not answer
  2  refused - bad arguments, or -Install on an unreachable server without -Force
  3  something failed part-way; the log says which step
  5  not running as Administrator

LOG:  C:\Scripts\set-local-wsus.log        UNDO: C:\Scripts\set-local-wsus.undo.json
"@ | Write-Host
  Exit-Yc 0
}

$picked = @($Install,$Uninstall,$Status,$Test | Where-Object { $_ }).Count
if($picked -gt 1){ Exit-Yc 2 'Pick ONE of -Install, -Uninstall, -Status, -Test.' 'ERROR' }
if($Port -lt 1 -or $Port -gt 65535){ Exit-Yc 2 ("-Port $Port is not a port.") 'ERROR' }

if(-not (Get-Command Get-YcRegValueOrNull -EA SilentlyContinue)){
  function Get-YcRegValueOrNull{
    param([string]$Path,[string]$Name)
    try{ (Get-ItemProperty -Path $Path -Name $Name -EA Stop).$Name }catch{ $null }
  }
}

$WU     = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
$AU     = "$WU\AU"
$UNDO   = 'C:\Scripts\set-local-wsus.undo.json'
$MUID   = '7971f918-a847-4430-9279-4a52d1efe18d'   # the Microsoft Update service id
$BaseUrl= 'http://' + $Server + ':' + $Port
if($Port -eq 8531){ $BaseUrl = 'https://' + $Server + ':' + $Port }

# ---------------------------------------------------------------- reachability
function Test-YcWsus {
  param([string]$Url,[string]$Target,[int]$Tcp)
  $r = [ordered]@{ tcp = $false; http = $false; ms = $null; detail = '' }
  try {
    $c = New-Object Net.Sockets.TcpClient
    $ia = $c.BeginConnect($Target,$Tcp,$null,$null)
    $r.tcp = $ia.AsyncWaitHandle.WaitOne(5000,$false) -and $c.Connected
    $c.Close()
  } catch { $r.detail = $_.Exception.Message }
  if(-not $r.tcp){ $r.detail = "TCP $Tcp did not open"; return $r }
  # The client web service is what a real Windows Update scan talks to, so it is the only
  # test worth trusting - an open port proves a listener, not a working WSUS.
  try {
    Set-YcTls | Out-Null
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $resp = Invoke-WebRequest -Uri ($Url + '/ClientWebService/client.asmx') -UseBasicParsing -TimeoutSec 15
    $sw.Stop()
    $r.http = ($resp.StatusCode -eq 200)
    $r.ms   = [int]$sw.ElapsedMilliseconds
    if(-not $r.http){ $r.detail = 'HTTP ' + $resp.StatusCode }
  } catch { $r.detail = 'web service: ' + $_.Exception.Message }
  return $r
}

function Get-YcWsusState {
  [ordered]@{
    WUServer       = Get-YcRegValueOrNull -Path $WU -Name 'WUServer'
    WUStatusServer = Get-YcRegValueOrNull -Path $WU -Name 'WUStatusServer'
    UseWUServer    = Get-YcRegValueOrNull -Path $AU -Name 'UseWUServer'
    AUOptions      = Get-YcRegValueOrNull -Path $AU -Name 'AUOptions'
    NoAutoUpdate   = Get-YcRegValueOrNull -Path $AU -Name 'NoAutoUpdate'
  }
}

function Get-YcLastScan {
  $p = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\Results\Detect'
  Get-YcRegValueOrNull -Path $p -Name 'LastSuccessTime'
}

function Restart-YcWu {
  # A policy change is not seen until the service restarts, and a scan is not attempted until
  # something asks for one. Doing neither is the classic "I set it and nothing happened".
  try { Stop-Service wuauserv -Force -EA Stop; Start-Service wuauserv -EA Stop; Write-YcLog 'wuauserv restarted.' 'OK' }
  catch { Write-YcLog ('could not restart wuauserv: ' + $_.Exception.Message) 'WARN' }
  try { (New-Object -ComObject Microsoft.Update.AutoUpdate).DetectNow(); Write-YcLog 'scan requested.' 'OK' }
  catch {
    try { & "$env:SystemRoot\System32\UsoClient.exe" StartScan 2>&1 | Out-Null; Write-YcLog 'scan requested (UsoClient).' 'OK' }
    catch { Write-YcLog 'could not request a scan; it will happen on the normal schedule.' 'WARN' }
  }
}

# ---------------------------------------------------------------- TEST
if($Test){
  Write-YcLog ('testing ' + $BaseUrl)
  $t = Test-YcWsus -Url $BaseUrl -Target $Server -Tcp $Port
  Write-Host ''
  Write-Host ('  local update server : ' + $BaseUrl)
  Write-Host ('  TCP ' + $Port + '            : ' + $(if($t.tcp){'OPEN'}else{'CLOSED'}))
  Write-Host ('  WSUS web service    : ' + $(if($t.http){'ANSWERS (' + $t.ms + ' ms)'}else{'NO'}))
  if($t.detail){ Write-Host ('  detail              : ' + $t.detail) }
  Write-Host ''
  if($t.http){ Exit-Yc 0 'Local update server is reachable.' 'OK' }
  Exit-Yc 1 ('Local update server NOT reachable - ' + $t.detail + '. Check the firewall allows this machine to ' + $Server + ':' + $Port + '.') 'ERROR'
}

# ---------------------------------------------------------------- STATUS
if($Status){
  $s = Get-YcWsusState
  $on = ($s.UseWUServer -eq 1 -and $s.WUServer)
  $t  = $null
  if($on){
    $u = [uri]$s.WUServer
    $t = Test-YcWsus -Url $s.WUServer -Target $u.Host -Tcp $u.Port
  }
  Write-Host ''
  Write-Host ('  source          : ' + $(if($on){'LOCAL - ' + $s.WUServer}else{'MICROSOFT UPDATE (default)'}))
  if($on){
    Write-Host ('  server answers  : ' + $(if($t.http){'YES (' + $t.ms + ' ms)'}else{'NO - ' + $t.detail}))
  }
  Write-Host ('  UseWUServer     : ' + $(if($null -eq $s.UseWUServer){'(not set)'}else{$s.UseWUServer}))
  $scan = Get-YcLastScan
  Write-Host ('  last good scan  : ' + $(if($scan){$scan}else{'never / not recorded'}))
  Write-Host ('  undo file       : ' + $(if(Test-Path $UNDO){'present'}else{'none'}))
  Write-Host ''
  if(-not $on){ Exit-Yc 0 'Pointed at Microsoft Update.' 'OK' }
  if($t.http){ Exit-Yc 0 ('Pointed at the local update server and it answers: ' + $s.WUServer) 'OK' }
  # The dangerous state: configured, unreachable, patching silently dead.
  Exit-Yc 1 ('POINTED AT ' + $s.WUServer + ' AND IT DOES NOT ANSWER - this machine is not patching. Run: set-local-wsus -Uninstall') 'ERROR'
}

# ---- everything below changes the machine ----
if(-not (Test-YcAdmin)){ Exit-Yc 5 'Run this from an elevated prompt (Run as Administrator).' 'ERROR' }

# ---------------------------------------------------------------- INSTALL
if($Install){
  Write-YcLog ('install: ' + $BaseUrl)
  $t = Test-YcWsus -Url $BaseUrl -Target $Server -Tcp $Port
  if(-not $t.http){
    if(-not $Force){
      Exit-Yc 2 ('REFUSED: ' + $BaseUrl + ' did not answer (' + $t.detail + '). A machine pointed at an ' +
                 'unreachable update server STOPS PATCHING and says nothing. Fix reachability, or pass ' +
                 '-Force if you are deliberately configuring ahead of the server being up.') 'ERROR'
    }
    Write-YcLog ('-Force: configuring anyway, but ' + $BaseUrl + ' did not answer - this machine will not patch until it does.') 'WARN'
  } else {
    Write-YcLog ('server answers in ' + $t.ms + ' ms.') 'OK'
  }

  # Undo BEFORE the change, never after - if the change goes wrong there is still a way back.
  try {
    (Get-YcWsusState | ConvertTo-Json -Depth 4) | Set-Content -Path $UNDO -Encoding ascii
    Write-YcLog ('previous settings saved to ' + $UNDO) 'OK'
  } catch { Write-YcLog ('could not write the undo file: ' + $_.Exception.Message) 'WARN' }

  $fail = 0
  try {
    foreach($k in @($WU,$AU)){ if(-not (Test-Path $k)){ New-Item -Path $k -Force | Out-Null } }
    New-ItemProperty $WU -Name 'WUServer'       -Value $BaseUrl -PropertyType String -Force | Out-Null
    New-ItemProperty $WU -Name 'WUStatusServer' -Value $BaseUrl -PropertyType String -Force | Out-Null
    # 0 = do NOT cut this machine off from Microsoft's internet endpoints. The local server is
    # the source of WHAT to install; content and Microsoft Update products can still come from
    # Microsoft. Setting this to 1 is what people mean by "it broke everything".
    New-ItemProperty $WU -Name 'DoNotConnectToWindowsUpdateInternetLocations' -Value 0 -PropertyType DWord -Force | Out-Null
    # Without these four, 1809+ "dual scan" can quietly send some update classes to Microsoft
    # anyway, which is exactly the bandwidth we are trying not to spend.
    foreach($c in 'QualityUpdates','FeatureUpdates','DriverUpdates','OtherUpdates'){
      New-ItemProperty $WU -Name ('SetPolicyDrivenUpdateSourceFor' + $c) -Value 1 -PropertyType DWord -Force | Out-Null
    }
    New-ItemProperty $AU -Name 'UseWUServer'  -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty $AU -Name 'NoAutoUpdate' -Value 0 -PropertyType DWord -Force | Out-Null
    # 3 = download automatically, notify to install. Servers do not get surprise reboots.
    New-ItemProperty $AU -Name 'AUOptions'    -Value 3 -PropertyType DWord -Force | Out-Null
    Write-YcLog ('policy written: WUServer=' + $BaseUrl) 'OK'
  } catch { $fail++; Write-YcLog ('writing the policy failed: ' + $_.Exception.Message) 'ERROR' }

  # SQL Server CUs and other Microsoft products arrive through Microsoft Update, which is a
  # separate opt-in from Windows Update. Without this, "sql update" finds nothing.
  try {
    $sm = New-Object -ComObject Microsoft.Update.ServiceManager
    $sm.AddService2($MUID,7,'') | Out-Null
    Write-YcLog 'Microsoft Update registered (SQL Server and other MS products).' 'OK'
  } catch { Write-YcLog ('could not register Microsoft Update: ' + $_.Exception.Message) 'WARN' }

  Restart-YcWu
  if($fail){ Exit-Yc 3 ($fail.ToString() + ' step(s) failed - see the log.') 'ERROR' }
  Exit-Yc 0 ('Now using the local update server ' + $BaseUrl + '. Go back any time with: set-local-wsus -Uninstall') 'OK'
}

# ---------------------------------------------------------------- UNINSTALL
if($Uninstall){
  Write-YcLog 'uninstall: back to Microsoft Update'
  $before = Get-YcWsusState
  if(-not $before.WUServer -and $null -eq $before.UseWUServer){
    Write-YcLog 'nothing to undo - this machine was already on Microsoft Update.' 'OK'
  }
  $fail = 0
  try {
    # Remove the values rather than zeroing them: absent is the real Windows default, and a
    # leftover UseWUServer=0 confuses the next person reading the registry.
    foreach($n in 'WUServer','WUStatusServer','DoNotConnectToWindowsUpdateInternetLocations',
                  'SetPolicyDrivenUpdateSourceForQualityUpdates','SetPolicyDrivenUpdateSourceForFeatureUpdates',
                  'SetPolicyDrivenUpdateSourceForDriverUpdates','SetPolicyDrivenUpdateSourceForOtherUpdates'){
      Remove-ItemProperty -Path $WU -Name $n -Force -EA SilentlyContinue
    }
    foreach($n in 'UseWUServer','AUOptions','NoAutoUpdate'){
      Remove-ItemProperty -Path $AU -Name $n -Force -EA SilentlyContinue
    }
    Write-YcLog 'local-server policy removed.' 'OK'
  } catch { $fail++; Write-YcLog ('removing the policy failed: ' + $_.Exception.Message) 'ERROR' }

  if(Test-Path $UNDO){
    try { Remove-Item $UNDO -Force -EA Stop; Write-YcLog 'undo file cleared.' 'OK' } catch {}
  }
  Restart-YcWu
  if($fail){ Exit-Yc 3 'Partly reverted - see the log.' 'ERROR' }
  Exit-Yc 0 'Back on Microsoft Update.' 'OK'
}

Exit-Yc 2 'Nothing to do.' 'ERROR'
