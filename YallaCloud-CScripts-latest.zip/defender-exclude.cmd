@echo off
rem defender-exclude [<path> ...] [-Process <exe>,..] [-Extension <ext>,..] [-Remove]
rem                  [-AcceptPrivEscRisk] [-AllowAbsent] [-Help]      (default path: C:\Scripts)
rem Adds/removes Microsoft Defender exclusions and VERIFIES them by reading Get-MpPreference back.
rem REFUSES a directory that non-administrators can write to unless -AcceptPrivEscRisk.
rem Logs to C:\Scripts\defender-exclude.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Defender-Exclude.ps1" %*
exit /b %ERRORLEVEL%
