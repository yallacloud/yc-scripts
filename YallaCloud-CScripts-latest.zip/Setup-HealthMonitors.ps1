<#  Setup-HealthMonitors.ps1  -  daily fleet health monitors for the YallaCloud golden image.
    PowerShell 5.1+  |  Windows Server 2016-2025  |  runs as SYSTEM, fully unattended.

    Every check writes BOTH:
      * a dated file in  C:\Scripts\Health\  (hidden folder, auto-created), with timestamp + PASS/FAIL + reason, AND
      * a Windows EVENT LOG entry (Application log, source "YallaCloudHealth") so it is shipped by Grafana Alloy /
        OpenTelemetry (windowseventlog / loki.source.windowsevent on the Application channel) to OpenObserve.

    Monitors installed by  -Install  (registers SYSTEM daily scheduled tasks that re-run THIS script):
      1) CHKDSK read-only (/scan, online, non-disruptive) per NTFS volume + dirty-bit check   -> PASS/FAIL + why.
      2) Logon / Logoff / Shutdown / Restart / unexpected-shutdown digest (Security + System event logs, last 24h).
      3) SQL Server corruption watch: scans SQL ERRORLOG(s) for 823/824/825 + DBCC/"consistency"/"suspect", and
         msdb.dbo.suspect_pages (if sqlcmd present)  -> PASS/FAIL.
      (optional)  -Sysmon  installs Sysinternals Sysmon (free auditing) with a sane default config.

    USAGE:
      Setup-HealthMonitors.ps1 -Install            # create logs + event source + register the 3 daily SYSTEM tasks
      Setup-HealthMonitors.ps1 -Install -Sysmon    # also install Sysmon (free Windows auditing)
      Setup-HealthMonitors.ps1 -RunChkdsk | -RunSession | -RunSql    # run one check now (also called by the tasks)
      Setup-HealthMonitors.ps1 -Help
#>
#Requires -RunAsAdministrator
param([switch]$Install,[switch]$RunChkdsk,[switch]$RunSession,[switch]$RunSql,[switch]$Sysmon,[switch]$Help)
$ErrorActionPreference='Continue'
$Root='C:\Scripts'; $H="$Root\Health"; $Src='YallaCloudHealth'
if($Help){ (Get-Content $MyInvocation.MyCommand.Path -Raw) -split "#>" | Select-Object -First 1; exit 0 }
New-Item -ItemType Directory -Force $Root,$H | Out-Null
try{ (Get-Item $Root).Attributes='Directory,Hidden'; (Get-Item $H).Attributes='Directory,Hidden' }catch{}
# event source (Application log) so Alloy/OTel pick it up; safe to call repeatedly
try{ if(-not [System.Diagnostics.EventLog]::SourceExists($Src)){ New-EventLog -LogName Application -Source $Src -EA SilentlyContinue } }catch{}

function HLog($category,$status,$msg,$id=9001){
  $line="$(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  [$category] $status - $msg"
  $file="$H\$category-$(Get-Date -f yyyyMMdd).log"
  try{ $line | Out-File -Append $file -Encoding ascii }catch{}
  $type = if($status -eq 'PASS'){'Information'} elseif($status -eq 'WARN'){'Warning'} else {'Error'}
  try{ Write-EventLog -LogName Application -Source $Src -EventId $id -EntryType $type -Message "$category $status`n$msg" -EA SilentlyContinue }catch{}
  Write-Host $line
}

# ---------------- 1) CHKDSK read-only ----------------
function Do-Chkdsk {
  $vols = Get-Volume -EA SilentlyContinue | Where-Object { $_.DriveLetter -and $_.FileSystem -eq 'NTFS' }
  foreach($v in $vols){
    $d=$v.DriveLetter
    $dirty = ((cmd /c "fsutil dirty query ${d}:") 2>$null) -match 'is Dirty'
    $out = & cmd /c "echo n| chkdsk ${d}: /scan" 2>&1     # /scan = online, read-only; echo n declines any prompt
    $code = $LASTEXITCODE
    $badLines = ($out | Select-String -Pattern 'errors|corrupt|bad sector|repair|found problems|could not be' -EA SilentlyContinue | Select-Object -First 3) -join ' | '
    if($code -eq 0 -and -not $dirty){ HLog 'chkdsk' 'PASS' "${d}: clean (exit=0, dirty=$dirty)" 9001 }
    else { HLog 'chkdsk' 'FAIL' "${d}: exit=$code dirty=$dirty  reason: $badLines" 9002 }
  }
}

# ---------------- 2) Logon/Logoff/Shutdown/Restart digest ----------------
function Do-Session {
  $since=(Get-Date).AddHours(-24)
  function Cnt($log,$ids){ try{ @(Get-WinEvent -FilterHashtable @{LogName=$log;Id=$ids;StartTime=$since} -EA SilentlyContinue).Count }catch{ 0 } }
  $logon   = Cnt 'Security' 4624
  $logoff  = Cnt 'Security' @(4634,4647)
  $failed  = Cnt 'Security' 4625
  $shut    = Cnt 'System'   1074      # shutdown/restart initiated (by whom is in the message)
  $unexp   = Cnt 'System'   6008      # unexpected shutdown
  $kpower  = Cnt 'System'   41        # kernel-power (dirty power off)
  $boots   = Cnt 'System'   6005      # event log service started (= boot)
  # capture the initiators of the last few shutdown/restart events for the log
  $who = try{ (Get-WinEvent -FilterHashtable @{LogName='System';Id=1074;StartTime=$since} -EA SilentlyContinue | Select-Object -First 3 | ForEach-Object { ($_.Message -split "`n")[0] }) -join ' | ' }catch{ '' }
  $msg = "logon=$logon logoff=$logoff failedLogon=$failed shutdown/restart=$shut unexpected=$unexp kernelPower41=$kpower boots=$boots. recent: $who"
  if($unexp -gt 0 -or $kpower -gt 0 -or $failed -ge 20){ HLog 'session' 'WARN' $msg 9011 } else { HLog 'session' 'PASS' $msg 9011 }
}

# ---------------- 3) SQL Server corruption watch ----------------
function Do-Sql {
  $logs = Get-ChildItem 'C:\Program Files\Microsoft SQL Server\MSSQL*\MSSQL\Log\ERRORLOG*' -EA SilentlyContinue
  if(-not $logs){ HLog 'sqlcorruption' 'PASS' 'no SQL Server ERRORLOG found (SQL not installed) - nothing to check' 9021; return }
  $rx='Error: 82[345]|DBCC CHECKDB.*(error|found)|consistency errors|torn page|checksum|suspect|I/O error|823|824|825'
  $hits=@()
  foreach($f in $logs){ try{ $hits += Select-String -Path $f.FullName -Pattern $rx -EA SilentlyContinue | Select-Object -Last 5 }catch{} }
  # msdb.dbo.suspect_pages is the authoritative corruption ledger
  $suspect=0; $sqlcmd=(Get-Command sqlcmd -EA SilentlyContinue).Source
  if($sqlcmd){ try{ $r = & $sqlcmd -S localhost -E -h -1 -W -Q "SET NOCOUNT ON; SELECT COUNT(*) FROM msdb.dbo.suspect_pages" 2>$null; if($r){ $suspect=[int]($r | Select-Object -First 1) } }catch{} }
  if(($hits.Count -eq 0) -and $suspect -eq 0){ HLog 'sqlcorruption' 'PASS' "no corruption indicators in ERRORLOG; suspect_pages=$suspect" 9021 }
  else { $why=($hits | ForEach-Object { ($_.Line).Trim() } | Select-Object -First 3) -join ' | '; HLog 'sqlcorruption' 'FAIL' "suspect_pages=$suspect  ERRORLOG: $why" 9022 }
}

# ---------------- optional: Sysmon (free Sysinternals auditing) ----------------
function Do-Sysmon {
  $sm = Get-ChildItem "$Root" -Recurse -Filter 'Sysmon64.exe' -EA SilentlyContinue | Select-Object -First 1
  if(-not $sm){
    try{ [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
      Invoke-WebRequest 'https://download.sysinternals.com/files/Sysmon.zip' -OutFile "$Root\Sysmon.zip" -UseBasicParsing -TimeoutSec 120
      Expand-Archive "$Root\Sysmon.zip" "$Root\Sysmon" -Force; $sm=Get-ChildItem "$Root\Sysmon" -Filter 'Sysmon64.exe' | Select-Object -First 1 }catch{ HLog 'sysmon' 'WARN' "Sysmon download failed: $($_.Exception.Message)" 9031; return }
  }
  # minimal built-in config: process create + network + driver/image load (expand with SwiftOnSecurity/olafhartong config)
  $cfg="$Root\Sysmon\sysmon.xml"
  @'
<Sysmon schemaversion="4.90">
  <EventFiltering>
    <ProcessCreate onmatch="exclude" />
    <NetworkConnect onmatch="exclude" />
    <DriverLoad onmatch="exclude" />
    <FileCreateTime onmatch="exclude" />
  </EventFiltering>
</Sysmon>
'@ | Set-Content $cfg -Encoding ascii
  try{ & $sm.FullName -accepteula -i $cfg 2>$null | Out-Null; HLog 'sysmon' 'PASS' 'Sysmon installed (Microsoft-Windows-Sysmon/Operational channel; collect via Alloy/OTel)' 9031 }
  catch{ HLog 'sysmon' 'WARN' "Sysmon install error: $($_.Exception.Message)" 9031 }
}

# ---------------- install: register the daily SYSTEM tasks ----------------
function Do-Install {
  $self=$MyInvocation.MyCommand.Path; if(-not $self){ $self="$Root\Setup-HealthMonitors.ps1" }
  if($self -ne "$Root\Setup-HealthMonitors.ps1"){ Copy-Item $self "$Root\Setup-HealthMonitors.ps1" -Force -EA SilentlyContinue; $self="$Root\Setup-HealthMonitors.ps1" }
  $prn=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -RunLevel Highest
  $set=New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 3)
  function Reg($name,$arg,$at){ $a=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$self`" $arg"; Register-ScheduledTask $name -Action $a -Trigger (New-ScheduledTaskTrigger -Daily -At ([datetime]$at)) -Principal $prn -Settings $set -Force | Out-Null }
  Reg 'YC-Health-Chkdsk'  '-RunChkdsk'  '03:30'
  Reg 'YC-Health-Session' '-RunSession' '23:55'
  Reg 'YC-Health-SQL'     '-RunSql'     '04:00'
  HLog 'install' 'PASS' 'daily monitors registered: YC-Health-Chkdsk 03:30, YC-Health-Session 23:55, YC-Health-SQL 04:00 -> logs in C:\Scripts\Health + Application event log (source YallaCloudHealth)' 9000
  if($Sysmon){ Do-Sysmon }
}

if($Install){ Do-Install }
elseif($RunChkdsk){ Do-Chkdsk }
elseif($RunSession){ Do-Session }
elseif($RunSql){ Do-Sql }
elseif($Sysmon){ Do-Sysmon }
else { Write-Host 'Nothing to do. Use -Install (setup daily tasks) or -RunChkdsk/-RunSession/-RunSql, or -Help.' -ForegroundColor Yellow }
