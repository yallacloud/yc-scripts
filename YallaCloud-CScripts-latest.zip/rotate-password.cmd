@echo off
rem Stamp 2026-08-19: rewritten - this wrapper previously had no usage block at all.
rem rotate-password (-User <name> | -Administrator) (-Password "<pw>" | -Random [-Length <n>]) [-Help]
rem
rem Rotates a local account password and VERIFIES the new password actually authenticates.
rem -Administrator targets the built-in Administrator account and enables it.
rem -Random generates a strong password; -Length sets its length (default 20, minimum 14).
rem Double-quote the password: @ # ! $ are literal inside double quotes in cmd.
rem
rem OUTPUT: on success the new password is printed to STDOUT ONCE as   NEWPASSWORD=<value>
rem It is deliberately NOT written to the log file and NOT written to the Windows event log.
rem Capture it from the console / RMM output - there is no second chance.
rem
rem EXIT CODES: 0 rotated and verified, 1 usage error, 2 user not found, 3 the password could not be
rem             set or failed verification, 5 not elevated.
rem Logs to C:\Scripts\rotate-password.log  (the password is NOT in this file)
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Rotate-Password.ps1" %*
exit /b %ERRORLEVEL%
