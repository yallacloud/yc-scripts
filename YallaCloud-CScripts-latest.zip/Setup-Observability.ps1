param(
  [ValidateSet('alloy','otel','prometheus','all')][string]$Collector='alloy',
  [string]$OOEndpoint, [string]$OOOrg='default', [string]$OOAuth, [string]$OOStream='default',
  [string]$OOUser, [string]$OOPass,
  [string]$SqlInstance='localhost', [string]$SqlUser, [string]$SqlPass,
  [int]$PromPort=9182, [int]$SqlExporterPort=9399,
  [switch]$NoMaintenance, [switch]$NoDbatools, [switch]$Help,
  [string]$OOPassFile, [string]$OOAuthFile, [string]$SqlPassFile,
  [string]$ScriptDir='C:\Scripts',
  [string[]]$RemoteAddress=@('LocalSubnet'),
  [string[]]$FirewallProfile=@('Domain','Private'),
  [int]$EventLogMB=256,
  [switch]$TrustedAuth,
  [switch]$EnableCmdLineAudit,
  [switch]$ForwardSecurityLog,
  [switch]$SkipAudit,
  [switch]$AllowAnyRemote,
  [switch]$SkipFirewall,
  [switch]$Force
)
# =====================================================================================
# Setup-Observability.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
# Windows audit hardening + ONE collector stack, installed through the *-Register.ps1
# commands that own each product, with every generated config validated by the vendor's
# own validator before any service is touched.
#
# ############### READ THIS FIRST: THIS SCRIPT CAN EXFILTRATE PASSWORDS ###############
# The old version ALWAYS did two things together:
#   (a) line 110 set ProcessCreationIncludeCmdLine_Enabled = 1, so Windows event 4688
#       records the FULL COMMAND LINE of every process started on the box, and
#   (b) line 154 forwarded the SECURITY channel to OpenObserve.
# Together they mean: any password typed on any command line anywhere on this machine -
# including the -MyPassword / -PgPassword / -SqlPassword / -OOPass / -OOAuth that the
# .cmd wrappers in C:\Scripts forward with %* - is captured in a 4688 event and SHIPPED
# OFF-BOX to the observability platform, where it is searchable by anyone with access to
# it, forever. That is a credential-exfiltration pipeline built by the monitoring setup.
# BOTH ARE NOW OPT-IN: -EnableCmdLineAudit and -ForwardSecurityLog. Neither is enabled by
# default, and enabling either logs a loud WARN naming the consequence. If you enable
# them, use the *PasswordFile parameters everywhere and never type a secret on a command
# line on this host.
# #####################################################################################
#
# WHAT CHANGED AND WHY
# --------------------
#  1. [P0-26a] THE ALLOY CONFIG WAS A SYNTAX ERROR, SO ALLOY SHIPPED NOTHING AT ALL.
#     Old lines 152-154 wrote three attributes on ONE line:
#       loki.source.windowsevent "app" { eventlog_name = "Application" use_incoming_timestamp = true forward_to = [...] }
#     Alloy's configuration syntax spec: "All block and attribute definitions must end with
#     a newline, which Alloy calls a terminator." Three attributes on one line is a parse
#     failure, and Alloy refuses to load the WHOLE file - so no metrics and no logs, not
#     just no event logs. The generated config now emits exactly one attribute per line
#     (the generator builds it as a line array so it cannot regress), and Alloy-Register.ps1
#     additionally REFUSES any config with two assignments on one line.
#  2. [P0-26b] THE OTEL CONFIG ENABLED THE 'processes' HOSTMETRICS SCRAPER, which upstream
#     documents as Linux/Mac/FreeBSD/OpenBSD ONLY, so otelcol-contrib failed at startup on
#     Windows every single time. It is GONE. The scrapers now emitted - cpu, memory, disk,
#     filesystem, network, paging, system - are all listed as supported on Windows.
#  3. [P0-26c] THE windows_exporter COLLECTOR LIST CONTAINED 'cs', WHICH WAS REMOVED FROM
#     windows_exporter; an enabled removed collector makes the exporter silently fail to
#     start. Both places that named it (this script and the Alloy windows exporter block)
#     now use cpu,cpu_info,logical_disk,memory,net,os,physical_disk,process,service,system,
#     tcp,time - every name checked against the current collector table.
#  4. [P0-26d + P0-26 validators] THIS SCRIPT NO LONGER INSTALLS ANYTHING ITSELF.
#     It generates the configuration and then calls the command that owns each product:
#       alloy   -> C:\Scripts\Alloy-Register.ps1      (runs 'alloy validate', proves /-/ready + /-/healthy)
#       otel    -> C:\Scripts\Otelcol-Register.ps1    (runs 'validate --config=', proves /metrics)
#       prom    -> C:\Scripts\WinExporter-Register.ps1 (proves /metrics has windows_exporter_build_info)
#                  C:\Scripts\SqlExporter-Register.ps1 (runs '-config.check', proves mssql_up)
#     and it FAILS if any of them fails. That removes the second, contradictory
#     implementation this file used to be: two otelcol services (YC-OtelCollector vs
#     otelcol-contrib), two sql_exporters both defaulting to port 9399 so one could never
#     bind, two install directories, two collector definitions with the same metric names
#     and different semantics, and an Alloy config written where the service never read it.
#     One service name, one install directory, one port, one collector file per product.
#  5. [P0-27] THE SQL-MAINTENANCE BLOCK IS DELETED, NOT FIXED. It wrote
#       set AUTH=-U sa -P "pw"
#     into C:\SQL_Maintenance\Run-Maintenance.cmd with default ACLs, and the 02:00 Sunday
#     SYSTEM task then spawned  sqlcmd -S x -U sa -P pw  - a password on a command line,
#     readable by any local user and captured by the 4688 auditing this same script
#     enabled and forwarded off-box. A password containing & ^ | > or % either broke the
#     batch file or injected commands into a SYSTEM-context cmd.exe. It also registered
#     weekly tasks calling IndexOptimize and DatabaseIntegrityCheck - procedures that DID
#     NOT EXIST, because the script only downloaded Ola Hallengren's SQL and told the
#     operator to deploy it by hand, so both tasks failed every week in silence.
#     WHY DELETE RATHER THAN FIX: C:\Scripts\Install-Sql.ps1 already does this job properly
#     - it installs the maintenance solution, COUNTS the four procedures in DBA and refuses
#     to register any task unless all four exist, and its tasks run sqlcmd with -E
#     (integrated auth) and -b, so no password is ever on a command line and a T-SQL failure
#     makes the task fail. Fixing the same thing twice guarantees the two copies drift; the
#     duplicate is removed and this script now points at install-sql. -NoMaintenance and
#     -NoDbatools are kept (the .cmd wrappers pass them) and are now no-ops that say so.
#  6. THE DEFAULT CODE PATH NO LONGER RUNS ON A NULL. With -Collector alloy (the default)
#     and no -OOEndpoint, ($OOEndpoint.TrimEnd('/')) was a method call on $null; under
#     $ErrorActionPreference='Continue' execution carried on, url = "" was written into the
#     config, and Alloy was installed pointing at nothing. Parameters are validated up front
#     now and a missing endpoint is exit 2.
#  7. SECRETS. -OOPassFile / -OOAuthFile / -SqlPassFile read the credential from a file, so
#     it never reaches a command line, a 4688 event or the transcript header; the old
#     -OOPass / -OOAuth / -SqlPass still work but log a loud WARN. Generated configs are
#     written with inheritance stripped and SYSTEM + Administrators only, and the ACL is
#     verified. The child commands are invoked with -ConfigFile / -SqlPasswordFile, so no
#     secret is ever placed on a child process's command line either.
#  8. DSN CORRECTNESS. The SQL connection string is built with [uri]::EscapeDataString on
#     user and password (go-mssqldb requires percent-encoding), a named instance becomes
#     sqlserver://host/instance instead of a backslash inside the URL authority, and Windows
#     auth uses authenticator=winsspi - '?trusted_connection=true' is not a go-mssqldb
#     parameter and only ever appeared to work because the user was empty.
#  9. IT USES THE SHARED LIBRARY. The old script logged 100% of its output through a private
#     'L' function into C:\Scripts\Observability\observability-setup.log, never called
#     Write-YcLog, never called Stop-YcLog on ANY path (including -Help), and so left a
#     transcript permanently open with no [END] line and nothing in the Windows event log.
#     Everything now goes through Write-YcLog / Exit-Yc.
# 10. EXPORTER PORTS ARE NO LONGER WORLD-OPEN: -RemoteAddress (default LocalSubnet) and
#     -FirewallProfile (default Domain,Private) are passed to the exporter commands, which
#     create the rule only AFTER /metrics is proven.
#
# PARAMETERS ADDED (none renamed, none removed): -OOPassFile, -OOAuthFile, -SqlPassFile,
#     -ScriptDir, -RemoteAddress, -FirewallProfile, -EventLogMB, -TrustedAuth,
#     -EnableCmdLineAudit, -ForwardSecurityLog, -SkipAudit, -AllowAnyRemote, -SkipFirewall,
#     -Force.
# BEHAVIOUR CHANGES TO REPORT: ProcessCreationIncludeCmdLine and Security-channel forwarding
#     are now OPT-IN; the SQL maintenance block and the dbatools install are gone (delegated
#     to install-sql / dbatools-install); -NoMaintenance and -NoDbatools are accepted no-ops.
#
# VERIFIED AGAINST THE CURRENT RELEASE (docs, not memory):
#   Alloy newline terminator rule
#     https://grafana.com/docs/alloy/latest/get-started/configuration-syntax/syntax/
#   loki.source.windowsevent arguments; prometheus.exporter.windows enabled_collectors and
#   the note that cs/logon are removed; prometheus.exporter.mssql connection_string
#     https://grafana.com/docs/alloy/latest/reference/components/loki/loki.source.windowsevent/
#     https://grafana.com/docs/alloy/latest/reference/components/prometheus/prometheus.exporter.windows/
#     https://grafana.com/docs/alloy/latest/reference/components/prometheus/prometheus.exporter.mssql/
#   hostmetrics scraper platform table ('processes' is not Windows)
#     https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/main/receiver/hostmetricsreceiver/README.md
#   windows_exporter collector table (no 'cs')
#     https://github.com/prometheus-community/windows_exporter/blob/master/README.md
#   OpenObserve ingestion paths /api/<org>/prometheus/api/v1/write and /api/<org>/loki/api/v1/push
#     https://openobserve.ai/docs/ingestion/metrics/prometheus/
#     https://openobserve.ai/docs/reference/api/ingestion/logs/loki/
#   go-mssqldb requires URL-encoded credentials
#     https://github.com/microsoft/go-mssqldb/blob/main/README.md
#
# Log: C:\Scripts\observability-register.log
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'observability-register'
$ErrorActionPreference = 'Stop'

$WinCollectors = 'cpu,cpu_info,logical_disk,memory,net,os,physical_disk,process,service,system,tcp,time'

$HelpText = @"
observability-register - Windows audit hardening + ONE observability collector stack, installed
                         through the per-product register commands, every generated config checked
                         by the vendor's own validator, nothing reported as working unless proven.

USAGE:
  observability-register -OOEndpoint https://oo.example.com -OOOrg default -OOUser <u> -OOPassFile <f>
  observability-register -Collector otel -OOEndpoint https://oo.example.com -OOAuthFile <f>
  observability-register -Collector prometheus -RemoteAddress 10.20.0.11
  observability-register -Help

PARAMETERS:
  -Collector          alloy (default) | otel | prometheus | all.
                        alloy      = Grafana Alloy: built-in windows + mssql exporters and Windows
                                     event logs -> OpenObserve (Prometheus remote_write + Loki push).
                        otel       = otelcol-contrib: hostmetrics + windowseventlog + sqlserver +
                                     SQL ERRORLOG -> OpenObserve OTLP.
                        prometheus = standalone windows_exporter + sql_exporter (pull model).
                        all        = every collector above.
  -OOEndpoint         OpenObserve endpoint URL. REQUIRED for alloy/otel/all.
  -OOOrg              OpenObserve organization (default default).
  -OOAuth             OpenObserve auth header value for the OTLP exporter, e.g. "Basic BASE64".
                      DEPRECATED on the command line - use -OOAuthFile.
  -OOAuthFile         File whose first line is the OpenObserve auth header value. PREFERRED.
  -OOStream           OpenObserve stream (default default).
  -OOUser             OpenObserve basic-auth user (Alloy remote_write / Loki push).
  -OOPass             OpenObserve basic-auth password. DEPRECATED on the command line.
  -OOPassFile         File whose first line is the OpenObserve basic-auth password. PREFERRED.
  -SqlInstance        SQL Server instance to monitor (default localhost; HOST\INSTANCE supported).
  -SqlUser            SQL auth login for the exporters.
  -SqlPass            SQL auth password. DEPRECATED on the command line.
  -SqlPassFile        File whose first line is the SQL password. PREFERRED.
  -TrustedAuth        Use Windows integrated auth for SQL instead of -SqlUser (authenticator=winsspi).
                      The identity is the SERVICE account (LocalSystem = the machine account): create
                      that login and grant it VIEW SERVER STATE.
  -PromPort           windows_exporter port (default 9182).
  -SqlExporterPort    sql_exporter port (default 9399).
  -RemoteAddress      Sources allowed through exporter inbound rules. Default LocalSubnet.
  -FirewallProfile    Profiles for those rules. Default Domain,Private.
  -AllowAnyRemote     Pass through to the exporter commands to allow a world-open rule. Loud WARN.
  -SkipFirewall       Do not create exporter inbound rules at all.
  -EventLogMB         Max size in MB for the Application/System (and Security) channels. Default 256.
  -SkipAudit          Skip the audit-hardening section entirely.
  -EnableCmdLineAudit OPT-IN. Sets ProcessCreationIncludeCmdLine_Enabled=1 so 4688 records full
                      command lines. READ THE WARNING AT THE TOP OF THIS FILE: combined with
                      -ForwardSecurityLog this ships every password ever typed on a command line to
                      your observability platform. Off by default (it used to be unconditional).
  -ForwardSecurityLog OPT-IN. Adds the Security channel to the collector's log pipeline. Same
                      warning. Off by default (it used to be unconditional).
  -NoMaintenance      ACCEPTED NO-OP, kept for the .cmd wrapper. SQL maintenance now belongs to
                      install-sql, which verifies the Ola Hallengren procedures exist before it
                      registers any task and uses integrated auth so no password reaches a command line.
  -NoDbatools         ACCEPTED NO-OP, kept for the .cmd wrapper. Use dbatools-install.
  -ScriptDir          Where the register commands live. Default C:\Scripts.
  -Force              Pass -Force through to the register commands (rewrite unchanged configs).
  -Help               Show this help and exit 0.

EXAMPLES:
  observability-register -OOEndpoint https://oo.example.com -OOUser ingest -OOPassFile C:\Scripts\.oo.pw
  observability-register -Collector otel -OOEndpoint https://oo.example.com -OOAuthFile C:\Scripts\.oo.auth
  observability-register -Collector prometheus -RemoteAddress 10.20.0.11 -TrustedAuth
  observability-register -Collector all -OOEndpoint https://oo.example.com -OOAuthFile C:\Scripts\.oo.auth -OOUser ingest -OOPassFile C:\Scripts\.oo.pw
  observability-register -Help

PROOF PERFORMED:
  This command proves nothing by itself and claims nothing by itself. It generates configuration,
  hands each product to its own register command, and propagates that command's exit code. Each of
  those commands runs the vendor validator (alloy validate / otelcol validate --config= /
  sql_exporter -config.check), then requires the service to be Running and to STAY Running, then
  requires an HTTP GET of the product's own endpoint to answer. If any of them fails, this command
  fails.

EXIT CODES:
  0  Everything requested was installed AND proven.
  1  At least one component failed (the failing component's log is named in the summary).
  2  Usage error (e.g. -Collector alloy without -OOEndpoint).
  5  Not elevated.

Log: C:\Scripts\observability-register.log
  plus the per-product logs: alloy-register.log, otelcol-register.log, winexporter-register.log,
  sqlexporter-register.log
"@

if($Help){ Write-Host $HelpText -ForegroundColor Cyan; Exit-Yc 0 'help shown' 'OK' }

Assert-YcPrereqs -NeedAdmin
$script:YcExit    = 0
$script:YcSummary = @()
$script:YcSecrets = @()

# ------------------------------------------------------------------ helpers

function Write-YcAsciiFile{
  param([string]$Path,[string]$Content)
  $sw = New-Object System.IO.StreamWriter($Path,$false,(New-Object System.Text.ASCIIEncoding))
  try{ $sw.Write($Content) } finally{ $sw.Close() }
}

function Invoke-YcNative{
  param([string]$File,[string[]]$Arguments)
  $ErrorActionPreference = 'Continue'
  $out = & $File @Arguments 2>&1
  $rc  = $LASTEXITCODE
  $txt = @()
  foreach($o in $out){ if($null -ne $o){ $txt += ([string]$o) } }
  return (New-Object psobject -Property @{ Output = $txt; ExitCode = $rc })
}

function Get-YcRedacted([string]$Text){
  $t = $Text
  foreach($s in $script:YcSecrets){
    if($s){ $t = ($t -replace [regex]::Escape($s),'***REDACTED***') }
  }
  return (Protect-YcSecret $t)
}

function Protect-YcFileAcl{
  param([string]$Path)
  $r1 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/inheritance:r')
  $r2 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/grant','*S-1-5-18:(F)','*S-1-5-32-544:(F)')
  if($r1.ExitCode -ne 0 -or $r2.ExitCode -ne 0){
    Write-YcLog ('icacls FAILED on ' + $Path + ': ' + (($r1.Output + $r2.Output) -join ' ')) 'ERROR'
    return $false
  }
  $allowed = @('S-1-5-18','S-1-5-32-544')
  $acl = Get-Acl -LiteralPath $Path
  if(-not $acl.AreAccessRulesProtected){
    Write-YcLog ('VERIFICATION FAILED: inheritance is still enabled on ' + $Path) 'ERROR'
    return $false
  }
  foreach($ace in $acl.Access){
    $sid = $null
    try{ $sid = $ace.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch{ $sid = [string]$ace.IdentityReference }
    if($allowed -notcontains $sid){
      Write-YcLog ('VERIFICATION FAILED: ' + $Path + ' is still accessible to ' +
        [string]$ace.IdentityReference + '. It contains credentials.') 'ERROR'
      return $false
    }
  }
  Write-YcLog ('ACL verified on ' + $Path + ': SYSTEM + Administrators only.') 'OK'
  return $true
}

function Get-YcFirstLine{
  param([string]$Path,[string]$What)
  if(-not (Test-Path -LiteralPath $Path)){
    Write-YcLog ($What + ' file not found: ' + $Path) 'ERROR'
    return $null
  }
  foreach($l in (Get-Content -LiteralPath $Path)){
    if($null -ne $l -and $l.Trim().Length -gt 0){ return $l.Trim() }
  }
  Write-YcLog ($What + ' file ' + $Path + ' is empty.') 'ERROR'
  return $null
}

function Get-YcSecretValue{
  param([string]$File,[string]$Inline,[string]$Name)
  if($File){
    $v = Get-YcFirstLine -Path $File -What $Name
    if($v){ Write-YcLog ($Name + ' read from ' + $File + ' (never on a command line).') }
    return $v
  }
  if($Inline){
    Write-YcLog ('-' + $Name + ' was passed on the command line. That value is visible in ' +
      'Win32_Process.CommandLine, in Windows event 4688 when command-line auditing is on, and in ' +
      'the PowerShell transcript header. Use -' + $Name + 'File instead. It is scrubbed from this ' +
      'log when the run ends.') 'WARN'
    return $Inline
  }
  return $null
}

# Runs a sibling register command as a SEPARATE PROCESS so its own transcript, exit code and
# event-log lines stay its own. No secret is ever placed on the child command line: credentials
# travel by file (-ConfigFile / -SqlPasswordFile).
function Invoke-YcRegisterCommand{
  param([string]$Script,[string[]]$Arguments,[string]$What)
  $path = Join-Path $ScriptDir $Script
  if(-not (Test-Path -LiteralPath $path)){
    Write-YcLog ($What + ': ' + $path + ' is missing. This command orchestrates the register ' +
      'commands and cannot do their job itself.') 'ERROR'
    return 1
  }
  $a = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$path) + $Arguments
  Write-YcLog ('--> ' + $What + ': powershell.exe -File "' + $path + '" ' + (Get-YcRedacted ($Arguments -join ' ')))
  $r = Invoke-YcNative -File 'powershell.exe' -Arguments $a
  foreach($l in $r.Output){ if($l.Trim().Length -gt 0){ Write-Host ('    | ' + (Get-YcRedacted $l)) } }
  if($r.ExitCode -eq 0){
    Write-YcLog ('<-- ' + $What + ' VERIFIED (exit 0).') 'OK'
  }else{
    Write-YcLog ('<-- ' + $What + ' FAILED with exit ' + $r.ExitCode + '. See its own log in ' +
      $ScriptDir + '.') 'ERROR'
  }
  return $r.ExitCode
}

function Add-YcSummary{
  param([string]$Item,[string]$Result)
  $script:YcSummary += ($Item + ': ' + $Result)
}

function Get-YcSqlHostInstance{
  param([string]$Instance)
  $h = $Instance
  $i = $null
  if($Instance -like '*\*'){
    $parts = $Instance.Split('\',2)
    $h = $parts[0]
    $i = $parts[1]
  }
  return (New-Object psobject -Property @{ Host_ = $h; Instance = $i })
}

# go-mssqldb URL DSN. Credentials percent-encoded; a named instance is a PATH segment, not a
# backslash inside the authority; Windows auth is authenticator=winsspi.
# https://github.com/microsoft/go-mssqldb/blob/main/README.md
function New-YcMssqlDsn{
  param([string]$Instance,[string]$User,[string]$Password,[bool]$Trusted)
  $hi = Get-YcSqlHostInstance -Instance $Instance
  $auth = ''
  if(-not $Trusted -and $User){
    $auth = [uri]::EscapeDataString($User) + ':' + [uri]::EscapeDataString($Password) + '@'
  }
  $authority = $hi.Host_
  if($hi.Instance){ $authority = $hi.Host_ + '/' + [uri]::EscapeDataString($hi.Instance) }
  else{ $authority = $hi.Host_ + ':1433' }
  $q = @('database=master','encrypt=true','trustservercertificate=true')
  if($Trusted -or -not $User){ $q += 'authenticator=winsspi' }
  $q += 'app+name=YallaCloud+observability'
  return ('sqlserver://' + $auth + $authority + '?' + ($q -join '&'))
}

function Test-YcSqlPresent{
  try{
    if(Test-Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server'){
      $p = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server' -ErrorAction SilentlyContinue
      if($p -and $p.InstalledInstances){ return $true }
    }
  }catch{}
  return $false
}

function Get-YcSqlErrorLogGlob{
  foreach($base in @('C:\Program Files\Microsoft SQL Server','C:\Program Files (x86)\Microsoft SQL Server')){
    if(Test-Path -LiteralPath $base){
      $d = Get-ChildItem -Path $base -Directory -Filter 'MSSQL*' -ErrorAction SilentlyContinue |
           Where-Object { Test-Path (Join-Path $_.FullName 'MSSQL\Log\ERRORLOG') } |
           Select-Object -First 1
      if($d){ return (Join-Path $d.FullName 'MSSQL\Log\ERRORLOG') }
    }
  }
  return $null
}

# ------------------------------------------------------------------ sections

# Sets $script:YcExit on failure and returns nothing: a function whose value is tested is a
# function that can be broken by any statement that happens to emit.
function Invoke-AuditHardening{
  if($SkipAudit){ Write-YcLog '-SkipAudit: audit hardening skipped.'; Add-YcSummary 'Audit hardening' 'skipped'; return }
  $bytes = [string]([int64]$EventLogMB * 1MB)
  $channels = @('Application','System')
  if($ForwardSecurityLog -or $EnableCmdLineAudit){ $channels += 'Security' }
  $failed = @()
  foreach($ch in $channels){
    $r = Invoke-YcNative -File 'wevtutil.exe' -Arguments @('sl',$ch,('/ms:' + $bytes))
    if($r.ExitCode -ne 0){ $failed += ($ch + ' (' + ($r.Output -join ' ') + ')') }
  }
  if($failed.Count -gt 0){
    Write-YcLog ('wevtutil could not resize: ' + ($failed -join '; ')) 'WARN'
  }else{
    Write-YcLog ('Event log max size set to ' + $EventLogMB + ' MB on ' + ($channels -join ', ') + '.') 'OK'
  }
  foreach($cat in @('Logon/Logoff','Account Management')){
    $r = Invoke-YcNative -File 'auditpol.exe' -Arguments @('/set',('/category:' + $cat),'/success:enable','/failure:enable')
    if($r.ExitCode -ne 0){ Write-YcLog ('auditpol /category:' + $cat + ' returned ' + $r.ExitCode + ': ' + ($r.Output -join ' ')) 'WARN' }
  }
  $r = Invoke-YcNative -File 'auditpol.exe' -Arguments @('/set','/subcategory:Process Creation','/success:enable','/failure:enable')
  if($r.ExitCode -ne 0){ Write-YcLog ('auditpol /subcategory:"Process Creation" returned ' + $r.ExitCode + ': ' + ($r.Output -join ' ')) 'WARN' }

  $k = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit'
  $cur = $null
  try{ if(Test-Path $k){ $cur = (Get-ItemProperty -Path $k -ErrorAction SilentlyContinue).ProcessCreationIncludeCmdLine_Enabled } }catch{}
  if($EnableCmdLineAudit){
    Write-YcLog ('-EnableCmdLineAudit: setting ProcessCreationIncludeCmdLine_Enabled=1. Every 4688 ' +
      'event on this host will now contain the FULL COMMAND LINE of the process, including any ' +
      'password an operator or a .cmd wrapper puts there. If the Security channel is also forwarded ' +
      'off-box, those passwords leave this machine. Use the *PasswordFile parameters everywhere.') 'WARN'
    New-Item -Path $k -Force | Out-Null
    Set-ItemProperty -Path $k -Name 'ProcessCreationIncludeCmdLine_Enabled' -Value 1 -Type DWord -ErrorAction Stop
    $back = (Get-ItemProperty -Path $k).ProcessCreationIncludeCmdLine_Enabled
    if($back -ne 1){
      Write-YcLog 'VERIFICATION FAILED: ProcessCreationIncludeCmdLine_Enabled did not take.' 'ERROR'
      $script:YcExit = 1
      return
    }
    Add-YcSummary 'Command-line auditing' 'ENABLED (opt-in)'
  }else{
    if($cur -eq 1){
      Write-YcLog ('ProcessCreationIncludeCmdLine_Enabled is already 1 on this host (the previous ' +
        'version of this script set it unconditionally). Every 4688 event contains full command ' +
        'lines, so any password typed on a command line here is recorded - and is exfiltrated if the ' +
        'Security channel is forwarded. This run did NOT change it. To turn it off: ' +
        'Set-ItemProperty "' + $k + '" ProcessCreationIncludeCmdLine_Enabled 0') 'WARN'
      Add-YcSummary 'Command-line auditing' 'already ENABLED (left as found)'
    }else{
      Write-YcLog ('Command-line auditing (ProcessCreationIncludeCmdLine) left OFF. It used to be ' +
        'enabled unconditionally here; it is now -EnableCmdLineAudit.')
      Add-YcSummary 'Command-line auditing' 'off (opt-in)'
    }
  }
  Add-YcSummary 'Audit hardening' 'applied'
}

function New-YcAlloyConfig{
  param([string]$Path,[string]$OoUserV,[string]$OoPassV,[string]$SqlDsn)
  $rw   = ($OOEndpoint.TrimEnd('/')) + '/api/' + $OOOrg + '/prometheus/api/v1/write'
  $loki = ($OOEndpoint.TrimEnd('/')) + '/api/' + $OOOrg + '/loki/api/v1/push'
  # ONE ATTRIBUTE PER LINE. Alloy requires a newline terminator after every attribute and
  # every block; the old generator put three on one line and Alloy loaded nothing at all.
  $L = @()
  $L += '// YallaCloud Grafana Alloy config - Windows metrics + event logs -> OpenObserve.'
  $L += '// Generated by C:\Scripts\Setup-Observability.ps1. Do not hand-edit: it is regenerated.'
  $L += '// Every attribute is on its own line: Alloy requires a newline terminator after each one.'
  $L += ''
  $L += 'prometheus.exporter.windows "win" {'
  $L += ('  enabled_collectors = ["' + (($WinCollectors -split ',') -join '","') + '"]')
  $L += '}'
  $L += ''
  if($SqlDsn){
    $L += 'prometheus.exporter.mssql "sql" {'
    $L += ('  connection_string = "' + $SqlDsn + '"')
    $L += '}'
    $L += ''
  }
  $L += 'prometheus.scrape "win_scrape" {'
  $L += '  targets = prometheus.exporter.windows.win.targets'
  $L += '  forward_to = [prometheus.remote_write.oo.receiver]'
  $L += '  scrape_interval = "30s"'
  $L += '}'
  $L += ''
  if($SqlDsn){
    $L += 'prometheus.scrape "sql_scrape" {'
    $L += '  targets = prometheus.exporter.mssql.sql.targets'
    $L += '  forward_to = [prometheus.remote_write.oo.receiver]'
    $L += '  scrape_interval = "30s"'
    $L += '}'
    $L += ''
  }
  $L += 'prometheus.remote_write "oo" {'
  $L += '  endpoint {'
  $L += ('    url = "' + $rw + '"')
  $L += '    basic_auth {'
  $L += ('      username = "' + $OoUserV + '"')
  $L += ('      password = "' + $OoPassV + '"')
  $L += '    }'
  $L += '  }'
  $L += '}'
  $L += ''
  $L += 'loki.source.windowsevent "app" {'
  $L += '  eventlog_name = "Application"'
  $L += '  use_incoming_timestamp = true'
  $L += '  forward_to = [loki.write.oo.receiver]'
  $L += '}'
  $L += ''
  $L += 'loki.source.windowsevent "sys" {'
  $L += '  eventlog_name = "System"'
  $L += '  use_incoming_timestamp = true'
  $L += '  forward_to = [loki.write.oo.receiver]'
  $L += '}'
  $L += ''
  if($ForwardSecurityLog){
    $L += '// -ForwardSecurityLog was passed. If ProcessCreationIncludeCmdLine is enabled on this'
    $L += '// host, 4688 events contain full command lines and this block ships them off-box.'
    $L += 'loki.source.windowsevent "sec" {'
    $L += '  eventlog_name = "Security"'
    $L += '  use_incoming_timestamp = true'
    $L += '  forward_to = [loki.write.oo.receiver]'
    $L += '}'
    $L += ''
  }
  $L += 'loki.write "oo" {'
  $L += '  endpoint {'
  $L += ('    url = "' + $loki + '"')
  $L += '    basic_auth {'
  $L += ('      username = "' + $OoUserV + '"')
  $L += ('      password = "' + $OoPassV + '"')
  $L += '    }'
  $L += '  }'
  $L += '}'
  Write-YcAsciiFile -Path $Path -Content (($L -join "`r`n") + "`r`n")
  Write-YcLog ('Alloy config generated: ' + $Path + ' (' + $L.Count + ' lines, one attribute per line).')
  return $true
}

function New-YcOtelConfig{
  param([string]$Path,[string]$AuthV)
  $endpoint = ($OOEndpoint.TrimEnd('/')) + '/api/' + $OOOrg
  $errorlog = Get-YcSqlErrorLogGlob
  $sqlPresent = Test-YcSqlPresent
  $L = @()
  $L += '# YallaCloud otelcol-contrib config - generated by C:\Scripts\Setup-Observability.ps1.'
  $L += '# The hostmetrics "processes" scraper is deliberately ABSENT: upstream documents it as'
  $L += '# Linux/Mac/FreeBSD/OpenBSD only, and enabling it makes the collector fail at startup on'
  $L += '# Windows. Every scraper below is documented as supported on Windows.'
  $L += 'receivers:'
  $L += '  hostmetrics:'
  $L += '    collection_interval: 30s'
  $L += '    scrapers:'
  $L += '      cpu: {}'
  $L += '      memory: {}'
  $L += '      disk: {}'
  $L += '      filesystem: {}'
  $L += '      network: {}'
  $L += '      paging: {}'
  $L += '      system: {}'
  $L += '  windowseventlog/system:'
  $L += '    channel: System'
  $L += '  windowseventlog/application:'
  $L += '    channel: Application'
  if($ForwardSecurityLog){
    $L += '  # -ForwardSecurityLog was passed: 4688 events (which contain full command lines when'
    $L += '  # ProcessCreationIncludeCmdLine is enabled) are shipped off-box by this receiver.'
    $L += '  windowseventlog/security:'
    $L += '    channel: Security'
  }
  if($sqlPresent){
    $L += '  sqlserver:'
    $L += '    collection_interval: 30s'
  }
  if($errorlog){
    $L += '  filelog/sqlerrorlog:'
    $L += ("    include: [ '" + $errorlog + "' ]")
    $L += '    start_at: end'
    $L += '    include_file_path: true'
  }
  $L += 'processors:'
  $L += '  batch:'
  $L += '    timeout: 10s'
  $L += '    send_batch_size: 8192'
  $L += '  resourcedetection:'
  $L += '    detectors: [ system ]'
  $L += '    system:'
  $L += '      hostname_sources: [ os ]'
  $L += 'exporters:'
  $L += '  otlphttp/openobserve:'
  $L += ('    endpoint: ' + $endpoint)
  $L += '    headers:'
  $L += ('      Authorization: "' + $AuthV + '"')
  $L += ('      stream-name: ' + $OOStream)
  $L += 'service:'
  $L += '  telemetry:'
  $L += '    logs:'
  $L += '      level: warn'
  $L += '  pipelines:'
  $metricRx = 'hostmetrics'
  if($sqlPresent){ $metricRx = 'hostmetrics, sqlserver' }
  $L += '    metrics:'
  $L += ('      receivers: [ ' + $metricRx + ' ]')
  $L += '      processors: [ resourcedetection, batch ]'
  $L += '      exporters: [ otlphttp/openobserve ]'
  $logRx = @('windowseventlog/system','windowseventlog/application')
  if($ForwardSecurityLog){ $logRx += 'windowseventlog/security' }
  if($errorlog){ $logRx += 'filelog/sqlerrorlog' }
  $L += '    logs:'
  $L += ('      receivers: [ ' + ($logRx -join ', ') + ' ]')
  $L += '      processors: [ resourcedetection, batch ]'
  $L += '      exporters: [ otlphttp/openobserve ]'
  Write-YcAsciiFile -Path $Path -Content (($L -join "`r`n") + "`r`n")
  Write-YcLog ('otelcol config generated: ' + $Path + ' (sqlserver=' + $sqlPresent + ', ERRORLOG=' +
    $(if($errorlog){$errorlog}else{'none found'}) + ').')
  return $true
}

# ------------------------------------------------------------------ main

function Invoke-Main{
  # Validate BEFORE creating anything: a usage error must not leave a directory behind.
  $needOO = ($Collector -eq 'alloy' -or $Collector -eq 'otel' -or $Collector -eq 'all')
  if($needOO -and -not $OOEndpoint){
    Write-YcLog ('-Collector ' + $Collector + ' requires -OOEndpoint. The old script accepted this ' +
      'combination, called .TrimEnd() on $null, carried on because ErrorActionPreference was ' +
      'Continue, wrote url = "" into the config and installed a collector pointing at nothing.') 'ERROR'
    $script:YcExit = 2; return
  }
  $Obs = Join-Path $ScriptDir 'Observability'
  if(-not (Test-Path -LiteralPath $Obs)){ New-Item -ItemType Directory -Path $Obs -Force | Out-Null }
  if($NoMaintenance -or $NoDbatools){
    Write-YcLog ('-NoMaintenance / -NoDbatools are accepted no-ops now. The SQL maintenance bundle ' +
      'this script used to write is gone: it baked the sa password into ' +
      'C:\SQL_Maintenance\Run-Maintenance.cmd and then put it on a sqlcmd command line from a weekly ' +
      'SYSTEM task, and it scheduled IndexOptimize and DatabaseIntegrityCheck against procedures ' +
      'that did not exist. Use install-sql (which verifies the procedures before registering any ' +
      'task and uses -E integrated auth) and dbatools-install.')
  }

  $ooPassV = Get-YcSecretValue -File $OOPassFile -Inline $OOPass -Name 'OOPass'
  $ooAuthV = Get-YcSecretValue -File $OOAuthFile -Inline $OOAuth -Name 'OOAuth'
  $sqlPassV = Get-YcSecretValue -File $SqlPassFile -Inline $SqlPass -Name 'SqlPass'
  foreach($s in @($ooPassV,$ooAuthV,$sqlPassV)){ if($s){ $script:YcSecrets += $s } }
  if($SqlUser -and -not $sqlPassV -and -not $TrustedAuth){
    Write-YcLog ('-SqlUser was given with no password. Supply -SqlPassFile <file>, or use ' +
      '-TrustedAuth. An empty password produces a DSN that authenticates against nothing while the ' +
      'exporter still answers /metrics.') 'ERROR'
    $script:YcExit = 2; return
  }

  # ---- 1) Windows audit hardening ----------------------------------------------------
  Invoke-AuditHardening | Out-Null

  # ---- 2) Grafana Alloy ---------------------------------------------------------------
  if($Collector -eq 'alloy' -or $Collector -eq 'all'){
    if(-not $OOUser -or -not $ooPassV){
      Write-YcLog ('Alloy needs OpenObserve basic-auth credentials for remote_write and Loki push: ' +
        'pass -OOUser and -OOPassFile. Without them Alloy starts, collects, and every push is ' +
        'rejected - which the old script reported as success.') 'ERROR'
      Add-YcSummary 'Alloy' 'NOT installed (no -OOUser/-OOPassFile)'
      $script:YcExit = 1
    }else{
      $dsn = $null
      $sqlHere = Test-YcSqlPresent
      if($sqlHere -or $SqlUser -or $TrustedAuth){
        if($sqlHere){
          $dsn = New-YcMssqlDsn -Instance $SqlInstance -User $SqlUser -Password $sqlPassV -Trusted ([bool]$TrustedAuth)
          Write-YcLog ('SQL Server detected: adding prometheus.exporter.mssql (DSN redacted).')
        }else{
          Write-YcLog ('No SQL Server instance is registered on this host; the mssql exporter block ' +
            'is omitted instead of being pointed at nothing.')
        }
      }
      $cfg = Join-Path $Obs 'config.alloy'
      New-YcAlloyConfig -Path $cfg -OoUserV $OOUser -OoPassV $ooPassV -SqlDsn $dsn | Out-Null
      if(-not (Protect-YcFileAcl -Path $cfg)){ $script:YcExit = 1 }
      else{
        $a = @('-ConfigFile',$cfg)
        if($Force){ $a += '-Force' }
        $rc = Invoke-YcRegisterCommand -Script 'Alloy-Register.ps1' -Arguments $a -What 'Grafana Alloy'
        if($rc -ne 0){ $script:YcExit = 1; Add-YcSummary 'Alloy' ('FAILED (exit ' + $rc + ')') }
        else{ Add-YcSummary 'Alloy' 'verified: validated, Running, ready and healthy' }
      }
    }
  }

  # ---- 3) OpenTelemetry Collector ------------------------------------------------------
  if($Collector -eq 'otel' -or $Collector -eq 'all'){
    if(-not $ooAuthV){
      Write-YcLog ('otelcol needs the OpenObserve Authorization header: pass -OOAuthFile (preferred) ' +
        'or -OOAuth.') 'ERROR'
      Add-YcSummary 'otelcol-contrib' 'NOT installed (no -OOAuthFile)'
      $script:YcExit = 1
    }else{
      $cfg = Join-Path $Obs 'otelcol-config.yaml'
      New-YcOtelConfig -Path $cfg -AuthV $ooAuthV | Out-Null
      if(-not (Protect-YcFileAcl -Path $cfg)){ $script:YcExit = 1 }
      else{
        $a = @('-ConfigFile',$cfg)
        if($Force){ $a += '-Force' }
        $rc = Invoke-YcRegisterCommand -Script 'Otelcol-Register.ps1' -Arguments $a -What 'OpenTelemetry Collector'
        if($rc -ne 0){ $script:YcExit = 1; Add-YcSummary 'otelcol-contrib' ('FAILED (exit ' + $rc + ')') }
        else{ Add-YcSummary 'otelcol-contrib' 'verified: validated, Running, telemetry served' }
      }
    }
  }

  # ---- 4) Standalone Prometheus exporters ---------------------------------------------
  if($Collector -eq 'prometheus' -or $Collector -eq 'all'){
    $a = @('-ListenPort',[string]$PromPort,'-Collectors',$WinCollectors,
           '-RemoteAddress',($RemoteAddress -join ','),'-FirewallProfile',($FirewallProfile -join ','))
    if($AllowAnyRemote){ $a += '-AllowAnyRemote' }
    if($SkipFirewall){ $a += '-SkipFirewall' }
    $rc = Invoke-YcRegisterCommand -Script 'WinExporter-Register.ps1' -Arguments $a -What 'windows_exporter'
    if($rc -ne 0){ $script:YcExit = 1; Add-YcSummary 'windows_exporter' ('FAILED (exit ' + $rc + ')') }
    else{ Add-YcSummary 'windows_exporter' ('verified: /metrics on ' + $PromPort) }

    if(Test-YcSqlPresent){
      # SqlExporter-Register.ps1 takes [string[]]$RemoteAddress, and an argument passed through
      # powershell.exe -File arrives as ONE string - so a comma-joined list would become a single
      # bogus address. Pass one address and say so, rather than creating a rule that cannot match.
      $sxRemote = $RemoteAddress[0]
      if($RemoteAddress.Count -gt 1){
        Write-YcLog ('sql_exporter''s inbound rule will be scoped to ' + $sxRemote + ' only; ' +
          'sqlexporter-register takes a list but a -File argument cannot carry one. Run ' +
          'sqlexporter-register directly with -RemoteAddress ' + ($RemoteAddress -join ',') +
          ' if you need all of them.') 'WARN'
      }
      $b = @('-ListenPort',[string]$SqlExporterPort,'-SqlServer',$SqlInstance,
             '-RemoteAddress',$sxRemote)
      if($TrustedAuth -or -not $SqlUser){ $b += '-TrustedAuth' }
      else{
        # The password goes to the child in a FILE, never on its command line.
        $pf = Join-Path $Obs '.sqlexporter.pw'
        Write-YcAsciiFile -Path $pf -Content $sqlPassV
        if(-not (Protect-YcFileAcl -Path $pf)){ $script:YcExit = 1; return }
        $b += @('-SqlUser',$SqlUser,'-SqlPasswordFile',$pf)
      }
      if($SkipFirewall){ $b += '-SkipFirewall' }
      $rc2 = Invoke-YcRegisterCommand -Script 'SqlExporter-Register.ps1' -Arguments $b -What 'sql_exporter'
      if($rc2 -ne 0){ $script:YcExit = 1; Add-YcSummary 'sql_exporter' ('FAILED (exit ' + $rc2 + ')') }
      else{ Add-YcSummary 'sql_exporter' ('verified: mssql_up on ' + $SqlExporterPort) }
    }else{
      Write-YcLog ('No SQL Server instance is registered on this host - sql_exporter is not installed ' +
        '(the old script installed and started it regardless, pointed at nothing).')
      Add-YcSummary 'sql_exporter' 'skipped (no SQL Server on this host)'
    }
  }

  # ---- 5) SQL maintenance: DELEGATED, NOT DUPLICATED ----------------------------------
  if(Test-YcSqlPresent){
    Write-YcLog ('SQL Server is installed on this host. SQL maintenance is NOT configured here any ' +
      'more. Run:  install-sql -Version <ver> -Maintenance on   (or, if the engine is already ' +
      'installed, re-run install-sql) - it installs the Ola Hallengren solution, COUNTS the four ' +
      'procedures in DBA and refuses to register a task unless all four exist, and its tasks call ' +
      'sqlcmd with -E and -b, so no password ever reaches a command line and a T-SQL failure makes ' +
      'the task fail loudly. The block that used to live here wrote the sa password into ' +
      'C:\SQL_Maintenance\Run-Maintenance.cmd and scheduled procedures that did not exist.') 'WARN'
    Add-YcSummary 'SQL maintenance' 'delegated to install-sql (duplicate removed)'
  }

  # ---- summary -------------------------------------------------------------------------
  Write-YcLog '--- summary ---'
  foreach($s in $script:YcSummary){ Write-YcLog ('  ' + $s) }
}

try{
  Invoke-Main | Out-Null
}catch{
  Write-YcLog ('UNHANDLED EXCEPTION: ' + (Get-YcRedacted $_.Exception.Message)) 'ERROR'
  if($_.ScriptStackTrace){ Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}

if($script:YcExit -eq 0){
  Exit-Yc 0 'observability-register: every requested component was installed AND proven by its own register command.' 'OK'
}
Exit-Yc $script:YcExit 'observability-register FAILED - at least one component is not proven. See the summary above and the per-product logs.' 'ERROR'
