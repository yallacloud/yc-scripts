param(
  # ---- name preserved from grow-disk.cmd and the catalog ----
  [switch]$Help,
  # ---- ADDED in this revision ----
  [string[]]$DriveLetter,          # restrict to these drive letters (default: every eligible one)
  [int]$MinGrowMB = 64,            # ignore a growth opportunity smaller than this
  [switch]$WhatIf                  # report the plan and change NOTHING
)
# =====================================================================================
# Grow-Disk.ps1 - extend a partition into adjacent unallocated space after the hypervisor
# has grown the virtual disk. PowerShell 5.1, ASCII only, unattended.
#
# 2026-08-19: repaired. Added the library guard + Exit-Yc on every path (it had a bare
#             'exit 0' in the -Help branch and no Stop-YcLog at all, so a run left the
#             transcript open with no [END] line); added -WhatIf, -DriveLetter and
#             -MinGrowMB; the script now REFUSES a partition whose layout does not match
#             the "grow the last partition into trailing free space" assumption instead of
#             swallowing the failure with -ErrorAction SilentlyContinue; and every resize
#             is PROVEN by reading the partition and volume size back afterwards.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P0] IT WAS A SILENT DESTRUCTIVE OPERATION.
#   Resize-Partition rewrites the partition table. The old script set
#   $ErrorActionPreference='SilentlyContinue', wrapped every step in try{}catch{} with an
#   EMPTY catch block, and printed "extended D: -> 120 GB" from the fact that
#   Resize-Partition did not throw. Nothing was read back, nothing was logged when it
#   failed, and there was no way to see what it was about to do before it did it.
#   NOW: -WhatIf prints the plan and changes nothing; every resize is followed by a
#   read-back of Get-Partition and Get-Volume; a resize that does not actually grow the
#   partition is an ERROR and exit 1.
#
# [P1] IT ASSUMED A LAYOUT IT NEVER CHECKED.
#   "Extend every drive to fill unallocated space" only makes sense when the partition is
#   the LAST one on its disk. On a golden image with a trailing recovery partition, the
#   free space is behind the recovery partition and Get-PartitionSupportedSize reports no
#   headroom - which the old script silently reported as nothing to do. Worse, it also
#   walked removable and non-NTFS volumes.
#   NOW each candidate must satisfy ALL of:
#     the disk is Online and not read-only,
#     the partition is not read-only and carries a drive letter,
#     the volume is NTFS or ReFS,
#     NO other partition on the same disk starts at a HIGHER offset,
#     Get-PartitionSupportedSize reports at least -MinGrowMB of headroom.
#   Anything else is REFUSED with the reason named, not skipped in silence.
#
# No vendor tooling is involved: Update-HostStorageCache, Get-Partition,
# Get-PartitionSupportedSize and Resize-Partition are all in the in-box Storage module
# (Server 2012 R2 and later, so Server 2016 through 2025).
#   https://learn.microsoft.com/en-us/powershell/module/storage/resize-partition
#   https://learn.microsoft.com/en-us/powershell/module/storage/get-partitionsupportedsize
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** No partition was touched. Re-deploy the C:\Scripts payload and re-run. ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'grow-disk'

$Usage = @'
grow-disk  -  extend a partition into ADJACENT unallocated space after the hypervisor has
              grown the virtual disk. Online, no reboot. THIS REWRITES THE PARTITION TABLE.

USAGE:
  grow-disk
  grow-disk -WhatIf
  grow-disk -DriveLetter D
  grow-disk -DriveLetter C,D -MinGrowMB 1024
  grow-disk -Help

PARAMETERS:
  -DriveLetter  Only consider these drive letters (C or C: both accepted). Default: every
                partition that carries a drive letter and satisfies the layout check.
  -MinGrowMB    Ignore headroom smaller than this, so a run does not rewrite the partition
                table for a few unusable megabytes. Default 64.
  -WhatIf       Report exactly what WOULD be resized, and change nothing. Run this first.
  -Help         Show this help and exit.

REFUSED (with the reason named, never skipped in silence):
  the disk is Offline or read-only, the partition is read-only, the volume is not NTFS or
  ReFS, or ANOTHER partition on the same disk starts at a higher offset - in that last case
  the unallocated space is not behind this partition and extending it is not possible.
  Delete or move the trailing partition first; this command will not do it for you.

EXAMPLES:
  grow-disk -WhatIf
  grow-disk
  grow-disk -DriveLetter D
  grow-disk -DriveLetter C,D -MinGrowMB 1024
  grow-disk -Help

PROOF OF SUCCESS (nothing is assumed):
  after each resize the partition size and the volume size are READ BACK, and a partition
  that did not actually grow is reported as a FAILURE. -WhatIf proves nothing because it
  changes nothing, and says so.

EXIT CODES:
  0  every eligible partition is at its maximum size (or -WhatIf reported the plan)
  1  at least one resize failed, or grew but could not be proven, or the Storage module
     could not enumerate this system's partitions at all
  2  usage error (-MinGrowMB below 1, or -DriveLetter names no existing partition)
  3  C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  5  not running as Administrator

Log: C:\Scripts\grow-disk.log   (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

if($MinGrowMB -lt 1){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 ('-MinGrowMB must be at least 1, got ' + $MinGrowMB + '. Nothing was touched.') 'ERROR'
}
$minBytes = [int64]$MinGrowMB * 1MB

$want = @()
foreach($d in @($DriveLetter)){
  if(-not $d){ continue }
  $t = ([string]$d).Trim().TrimEnd(':').ToUpperInvariant()
  if($t.Length -ne 1){
    Write-Host $Usage -ForegroundColor Cyan
    Exit-Yc 2 ('-DriveLetter "' + $d + '" is not a single drive letter. Nothing was touched.') 'ERROR'
  }
  if($want -notcontains $t){ $want += $t }
}

# Pick up a disk the hypervisor grew while Windows was running.
$rescanned = ''
try{
  Update-HostStorageCache -ErrorAction Stop
  $rescanned = 'Update-HostStorageCache'
}catch{
  Write-YcLog ('Update-HostStorageCache failed (' + $_.Exception.Message + ') - falling back to diskpart rescan') 'WARN'
  try{
    'rescan' | diskpart | Out-Null
    if($LASTEXITCODE -eq 0){ $rescanned = 'diskpart rescan' }
    else{ Write-YcLog ('diskpart rescan exited ' + $LASTEXITCODE) 'WARN' }
  }catch{
    Write-YcLog ('diskpart rescan failed: ' + $_.Exception.Message) 'WARN'
  }
}
if($rescanned){ Write-YcLog ('storage rescanned via ' + $rescanned) }
else{ Write-YcLog 'the storage cache could NOT be refreshed - a disk grown seconds ago may still look its old size below' 'WARN' }

$parts = @()
try{
  $parts = @(Get-Partition -ErrorAction Stop)
}catch{
  Exit-Yc 1 ('Get-Partition failed: ' + $_.Exception.Message + '. Nothing was touched.') 'ERROR'
}
if($parts.Count -eq 0){
  Exit-Yc 1 'Get-Partition returned nothing - the Storage module cannot see this system''s disks. Nothing was touched.' 'ERROR'
}

$lettered = @($parts | Where-Object { $_.DriveLetter -and ([string]$_.DriveLetter).Trim() })
if($want.Count -gt 0){
  $matched = @($lettered | Where-Object { $want -contains ([string]$_.DriveLetter).ToUpperInvariant() })
  if($matched.Count -eq 0){
    Exit-Yc 2 ('-DriveLetter ' + ($want -join ',') + ' matches no partition with a drive letter (present: ' +
      ((@($lettered | ForEach-Object { [string]$_.DriveLetter }) | Sort-Object) -join ',') + '). Nothing was touched.') 'ERROR'
  }
  $lettered = $matched
}

$grown    = @()
$atMax    = @()
$refused  = @()
$failed   = @()
$planned  = @()

foreach($p in $lettered){
  $dl  = ([string]$p.DriveLetter).ToUpperInvariant()
  $why = ''

  $disk = $null
  try{ $disk = Get-Disk -Number $p.DiskNumber -ErrorAction Stop }catch{ $why = 'the parent disk could not be read: ' + $_.Exception.Message }
  if(-not $why -and $disk){
    if([string]$disk.OperationalStatus -ne 'Online'){ $why = 'disk ' + $p.DiskNumber + ' is ' + $disk.OperationalStatus + ', not Online' }
    elseif($disk.IsReadOnly){ $why = 'disk ' + $p.DiskNumber + ' is read-only' }
  }
  if(-not $why){
    $ro = $false
    try{ $ro = [bool]$p.IsReadOnly }catch{ $ro = $false }
    if($ro){ $why = 'the partition is read-only' }
  }
  if(-not $why){
    $fs = ''
    try{ $fs = [string](Get-Volume -DriveLetter $dl -ErrorAction Stop).FileSystem }catch{ $fs = '' }
    if($fs -ne 'NTFS' -and $fs -ne 'ReFS'){ $why = 'the volume filesystem is "' + $fs + '", and only NTFS and ReFS can be extended online' }
  }
  if(-not $why){
    # The layout assumption: the free space must be BEHIND this partition.
    $behind = @($parts | Where-Object { $_.DiskNumber -eq $p.DiskNumber -and [int64]$_.Offset -gt [int64]$p.Offset })
    if($behind.Count -gt 0){
      $why = 'partition ' + $behind[0].PartitionNumber + ' on disk ' + $p.DiskNumber + ' starts after it, so any unallocated space is not adjacent to ' + $dl + ':'
    }
  }
  if($why){
    Write-YcLog ($dl + ': REFUSED - ' + $why) 'WARN'
    $refused += ($dl + ' (' + $why + ')')
    continue
  }

  $max = 0
  try{ $max = [int64](Get-PartitionSupportedSize -DriveLetter $dl -ErrorAction Stop).SizeMax }
  catch{
    Write-YcLog ($dl + ': REFUSED - Get-PartitionSupportedSize failed: ' + $_.Exception.Message) 'WARN'
    $refused += ($dl + ' (supported size unknown)')
    continue
  }
  $cur = [int64]$p.Size
  if(($max - $cur) -lt $minBytes){
    Write-YcLog ($dl + ': already at its maximum size (' + [math]::Round($cur/1GB,2) + ' GB, headroom ' +
      [math]::Round(($max-$cur)/1MB,1) + ' MB is under -MinGrowMB ' + $MinGrowMB + ')') 'OK'
    $atMax += $dl
    continue
  }

  $plan = ($dl + ': ' + [math]::Round($cur/1GB,2) + ' GB -> ' + [math]::Round($max/1GB,2) + ' GB (+' + [math]::Round(($max-$cur)/1GB,2) + ' GB)')
  if($WhatIf){
    Write-YcLog ('-WhatIf: WOULD extend ' + $plan)
    $planned += $plan
    continue
  }

  Write-YcLog ('extending ' + $plan + ' - this rewrites the partition table')
  try{
    Resize-Partition -DriveLetter $dl -Size $max -ErrorAction Stop
  }catch{
    Write-YcLog ($dl + ': Resize-Partition FAILED: ' + $_.Exception.Message) 'ERROR'
    $failed += ($dl + ' (resize threw: ' + $_.Exception.Message + ')')
    continue
  }

  # PROOF: read the partition and the volume back. A resize that did not throw is not a
  # resize that happened - that assumption is what this whole programme exists to remove.
  $newSize = 0
  $volSize = 0
  try{ $newSize = [int64](Get-Partition -DriveLetter $dl -ErrorAction Stop).Size }catch{}
  try{ $volSize = [int64](Get-Volume -DriveLetter $dl -ErrorAction Stop).Size }catch{}
  if($newSize -le $cur){
    Write-YcLog ($dl + ': Resize-Partition returned without error but the partition is still ' +
      [math]::Round($newSize/1GB,2) + ' GB (was ' + [math]::Round($cur/1GB,2) + ' GB). NOT grown.') 'ERROR'
    $failed += ($dl + ' (no growth on read-back)')
    continue
  }
  if($volSize -lt ($newSize - 64MB)){
    Write-YcLog ($dl + ': the partition is now ' + [math]::Round($newSize/1GB,2) + ' GB but the volume reports only ' +
      [math]::Round($volSize/1GB,2) + ' GB - the filesystem did not follow the partition.') 'ERROR'
    $failed += ($dl + ' (filesystem not extended)')
    continue
  }
  Write-YcLog ($dl + ': extended and VERIFIED - partition ' + [math]::Round($newSize/1GB,2) + ' GB, volume ' +
    [math]::Round($volSize/1GB,2) + ' GB') 'OK'
  $grown += ($dl + ' -> ' + [math]::Round($newSize/1GB,2) + ' GB')
}

$summary = ('grown: ' + $(if($grown.Count){($grown -join ', ')}else{'none'}) +
            ' | already at max: ' + $(if($atMax.Count){($atMax -join ',')}else{'none'}) +
            ' | refused: ' + $(if($refused.Count){($refused -join '; ')}else{'none'}) +
            ' | failed: ' + $(if($failed.Count){($failed -join '; ')}else{'none'}))

if($failed.Count -gt 0){
  Exit-Yc 1 ('grow-disk FAILED on ' + $failed.Count + ' partition(s). ' + $summary) 'ERROR'
}
if($WhatIf){
  Exit-Yc 0 ('-WhatIf: nothing was changed. Planned: ' + $(if($planned.Count){($planned -join '; ')}else{'nothing - no partition has usable adjacent free space'}) +
    ' | already at max: ' + $(if($atMax.Count){($atMax -join ',')}else{'none'}) +
    ' | refused: ' + $(if($refused.Count){($refused -join '; ')}else{'none'})) 'OK'
}
Exit-Yc 0 $summary 'OK'
