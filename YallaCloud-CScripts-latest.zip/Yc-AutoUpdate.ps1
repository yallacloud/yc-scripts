#Requires -Version 5.1
<#
  Yc-AutoUpdate.ps1 - keep C:\Scripts current from the public yc-scripts repo.

  WHY THIS IS CHEAP ON GITHUB
    The check fetches the 97-byte .sha256 sidecar, NOT the 745 KB zip, and sends an
    If-None-Match with the ETag saved from the last run - so an unchanged payload costs a
    304 with an empty body. The zip is downloaded ONLY when the sidecar hash differs from
    what is installed. raw.githubusercontent.com is a CDN and is not the REST API, so these
    reads do not consume the API rate limit at all; the ETag keeps even the CDN traffic near
    zero. A fleet of a thousand VMs checking once a day is about 100 KB of total traffic.

  WHEN IT RUNS
    - at boot
    - when a network becomes available (NetworkProfile event 10000), because a VM very often
      has no egress at first boot and we must not miss the moment it appears
    - daily at 00:01
    All three land on the same script, and a mutex plus a 60 minute cooldown stamp mean
    firing three times in a minute still costs exactly one check. The cooldown is NOT a
    rate-limit workaround - raw.githubusercontent.com has no rate limit and the conditional
    GET returns HTTP 304 with an empty body. It exists only to collapse trigger storms.

  HOW TO TURN IT OFF
    Create C:\Scripts\.no-auto-update  (any content, or empty). Checked on every run,
    before any network call.

  Log: C:\Scripts\yc-autoupdate.log

  Exit codes: 0 up to date or updated | 1 bad args | 2 disabled by lock file
              3 no egress (will retry) | 4 sidecar unreadable | 5 update failed
#>
[CmdletBinding()]
param(
  [string]$Url      = 'https://raw.githubusercontent.com/yallacloud/yc-scripts/main/YallaCloud-CScripts-latest.zip',
  [string]$ShaUrl   = 'https://raw.githubusercontent.com/yallacloud/yc-scripts/main/YallaCloud-CScripts-latest.sha256',
  # Refuse anything published before this. Guards against a rolled-back or hijacked sidecar
  # pointing the fleet at an ancient payload.
  [datetime]$MinPublished = '2026-08-30',
  [switch]$Install,
  [switch]$Force,
  [switch]$Help
)

$ErrorActionPreference = 'Continue'
$Scripts = 'C:\Scripts'
$Log     = Join-Path $Scripts 'yc-autoupdate.log'
$Lock    = Join-Path $Scripts '.no-auto-update'
$State   = Join-Path $Scripts '.autoupdate-state'
$Stamp   = Join-Path $Scripts '.autoupdate-lastcheck'

function L([string]$m,[string]$lvl='INFO'){
  $line = ('{0}  [YC-AUTOUPDATE] [{1}] {2}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'),$lvl,$m)
  Write-Host $line
  try{ Add-Content -LiteralPath $Log -Value $line -Encoding ASCII -EA SilentlyContinue }catch{}
}

if($Help){
@"
yc-autoupdate  -  keep C:\Scripts current from the public yc-scripts repo.

USAGE:
  yc-autoupdate                 check once now, update only if the payload changed
  yc-autoupdate -Force          check even if one already ran today
  yc-autoupdate -Install        register the scheduled task (boot + network + 00:01 daily)
  yc-autoupdate -Help

DISABLE:  create C:\Scripts\.no-auto-update   -   re-enable by deleting it.
LOG:      C:\Scripts\yc-autoupdate.log

COST: the check is a conditional GET of a 97-byte sidecar with an ETag, so an unchanged
payload transfers nothing. The zip is fetched only when the hash actually differs.
"@ | Write-Host -ForegroundColor Cyan
  exit 0
}

# --- TLS: Server 2016 defaults .NET to TLS 1.0. -bor, never =, so TLS 1.3 survives on 2022/2025.
try{
  $want = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
  if([enum]::GetNames([Net.SecurityProtocolType]) -contains 'Tls13'){
    try{ $want = $want -bor ([Net.SecurityProtocolType]'Tls13') }catch{}
  }
  [Net.ServicePointManager]::SecurityProtocol = $want
}catch{ L ('could not raise TLS: ' + $_.Exception.Message) 'WARN' }

# --- install the task and exit -------------------------------------------------------------
if($Install){
  $ps  = Join-Path $Scripts 'Yc-AutoUpdate.ps1'
  $act = New-ScheduledTaskAction -Execute 'powershell.exe' `
           -Argument ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $ps + '"')
  $trg = @()
  $trg += New-ScheduledTaskTrigger -AtStartup
  # RandomDelay belongs on the TRIGGER. It was being set on the settings set, where the
  # property does not exist - Server 2019 threw "The property 'RandomDelay' cannot be found
  # on this object", the exception was swallowed, and the log still claimed a 30 minute
  # spread. Every VM in the fleet would have hit raw.githubusercontent.com at 00:01 exactly,
  # which is the rate-limit spike this task was written to avoid.
  $daily = New-ScheduledTaskTrigger -Daily -At '00:01'
  $spread = $false
  try{ $daily.RandomDelay = 'PT30M'; $spread = $true }catch{}
  $trg += $daily
  # Network-available trigger: fires the moment a profile connects, which is how a VM that
  # booted with no egress picks the update up without us polling.
  $cls = Get-CimClass MSFT_TaskEventTrigger -Namespace Root/Microsoft/Windows/TaskScheduler
  $evt = New-CimInstance -CimClass $cls -ClientOnly
  $evt.Subscription = '<QueryList><Query Id="0" Path="Microsoft-Windows-NetworkProfile/Operational"><Select Path="Microsoft-Windows-NetworkProfile/Operational">*[System[EventID=10000]]</Select></Query></QueryList>'
  $evt.Enabled = $true
  $trg += $evt
  $pri = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  $set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
           -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 30)
  try{
    Register-ScheduledTask -TaskName 'YC-AutoUpdate' -Action $act -Trigger $trg -Principal $pri `
      -Settings $set -Force | Out-Null
    if(Get-ScheduledTask -TaskName 'YC-AutoUpdate' -EA SilentlyContinue){
      # Say what actually happened. Claiming a spread that was never applied is how this
      # went unnoticed in the first place.
      L ('YC-AutoUpdate registered (startup + network-available + daily 00:01, SYSTEM, ' +
         $(if($spread){'30 min random delay'}else{'NO random delay - this build would not accept one, so the fleet is not spread'}) +
         '), existence confirmed.') $(if($spread){'OK'}else{'WARN'})
      exit 0
    }
    L 'Register-ScheduledTask returned without error but the task is not there.' 'ERROR'; exit 5
  }catch{ L ('could not register the task: ' + $_.Exception.Message) 'ERROR'; exit 5 }
}

# --- the check ------------------------------------------------------------------------------
L ('START host=' + $env:COMPUTERNAME + ' build=' + [Environment]::OSVersion.Version.Build)

if(Test-Path -LiteralPath $Lock){
  L ('disabled: ' + $Lock + ' exists. Delete it to re-enable. Nothing was checked or changed.') 'WARN'
  L 'END exit=2'; exit 2
}

# A COOLDOWN, not a daily quota.
#
# This used to skip until the next calendar day. That cost a full day of freshness and
# bought nothing, because it was protecting against a limit that does not exist on the
# endpoint we use. MEASURED 2026-08-31 from a guest:
#
#   raw.githubusercontent.com  no x-ratelimit-* headers at all (Fastly CDN,
#                              cache-control: max-age=300). 25 rapid conditional GETs
#                              returned 25 x HTTP 304 and ZERO bytes, no throttling.
#   api.github.com             x-ratelimit-limit: 60 - the 60/hour limit people mean.
#                              This script never touches it.
#
# So the check is genuinely free. The stamp's real job is only to stop the three triggers
# - boot, network-available, daily 00:01 - from all firing within the same minute. An hour
# does that just as well, is comfortably above the CDN's own 5 minute cache, and lets a
# payload published this morning reach the fleet this morning.
$CooldownMinutes = 60
if(-not $Force){
  try{
    if(Test-Path -LiteralPath $Stamp){
      $raw  = (Get-Content -LiteralPath $Stamp -Raw).Trim()
      $last = [datetime]::MinValue
      # 'o' round-trip is what we write now; the bare date is what older images wrote.
      if(-not [datetime]::TryParse($raw,[ref]$last)){ $last = [datetime]::MinValue }
      if($last -gt [datetime]::MinValue){
        $mins = ((Get-Date) - $last).TotalMinutes
        if($mins -ge 0 -and $mins -lt $CooldownMinutes){
          L ('checked ' + [int]$mins + ' minute(s) ago, cooldown is ' + $CooldownMinutes + ' - skipping (use -Force to override).')
          L 'END exit=0'; exit 0
        }
      }
    }
  }catch{}
}

# Egress first. No network is the normal state at first boot and is NOT an error - the
# network-available trigger brings us straight back.
$net = $false
try{
  $u = [uri]$ShaUrl
  $c = New-Object Net.Sockets.TcpClient
  $ia = $c.BeginConnect($u.Host,443,$null,$null)
  $net = $ia.AsyncWaitHandle.WaitOne(8000,$false)
  $c.Close()
}catch{ $net = $false }
if(-not $net){
  L ('no egress to ' + ([uri]$ShaUrl).Host + ':443 - will retry when a network appears or at 00:01.') 'WARN'
  L 'END exit=3'; exit 3
}

# Conditional GET of the sidecar. This is the whole cost of a no-change day.
$etag = ''
try{ if(Test-Path -LiteralPath $State){ $etag = (Get-Content -LiteralPath $State -Raw).Trim() } }catch{}

$remoteSha = ''
try{
  $req = [Net.HttpWebRequest]::Create($ShaUrl)
  $req.UserAgent = 'yc-autoupdate/1.0'
  $req.Timeout   = 60000
  if($etag){ $req.Headers.Add('If-None-Match', $etag) }
  $resp = $req.GetResponse()
  $newEtag = $resp.Headers['ETag']
  $sr = New-Object IO.StreamReader($resp.GetResponseStream())
  $body = $sr.ReadToEnd(); $sr.Close(); $resp.Close()
  if($body -match '([0-9a-fA-F]{64})'){ $remoteSha = $Matches[1].ToUpper() }
  if($newEtag){ Set-Content -LiteralPath $State -Value $newEtag -Encoding ASCII -EA SilentlyContinue }
}catch [Net.WebException] {
  $r = $_.Exception.Response
  if($r -and [int]$r.StatusCode -eq 304){
    L 'sidecar unchanged (HTTP 304, no body transferred) - C:\Scripts is current.' 'OK'
    Set-Content -LiteralPath $Stamp -Value (Get-Date).ToString('o') -Encoding ASCII -EA SilentlyContinue
    L 'END exit=0'; exit 0
  }
  L ('sidecar fetch failed: ' + $_.Exception.Message) 'ERROR'; L 'END exit=4'; exit 4
}catch{
  L ('sidecar fetch failed: ' + $_.Exception.Message) 'ERROR'; L 'END exit=4'; exit 4
}

if(-not $remoteSha){ L 'the sidecar held no SHA256 - refusing to act on it.' 'ERROR'; L 'END exit=4'; exit 4 }

# What is installed? yc-payload-version.txt carries the hash of the payload that was applied.
$localSha = ''
try{
  # .payload-sha256 is written by Update-YcScripts AFTER the gate passes, so it is the hash of
  # what is actually installed. yc-payload-version.txt is a BUILD artefact carrying the hash of
  # whatever the golden image was assembled from - it drifts the moment a payload is synced, so
  # it can never answer "am I current?" and must not be used for the comparison.
  $sf = Join-Path $Scripts '.payload-sha256'
  if(Test-Path -LiteralPath $sf){
    $t = (Get-Content -LiteralPath $sf -Raw).Trim()
    if($t -match '([0-9a-fA-F]{64})'){ $localSha = $Matches[1].ToUpper() }
  }
}catch{}

if($localSha -and ($localSha -eq $remoteSha)){
  L ('payload already current (' + $remoteSha.Substring(0,12) + '...).') 'OK'
  Set-Content -LiteralPath $Stamp -Value (Get-Date).ToString('o') -Encoding ASCII -EA SilentlyContinue
  L 'END exit=0'; exit 0
}

L ('payload differs - remote ' + $remoteSha.Substring(0,12) + '... local ' + $(if($localSha){$localSha.Substring(0,12)+'...'}else{'(unknown)'}))

$upd = Join-Path $Scripts 'Update-YcScripts.ps1'
if(-not (Test-Path -LiteralPath $upd)){
  L 'Update-YcScripts.ps1 is not on this machine, so the payload cannot be applied. It must be baked into the template before sealing.' 'ERROR'
  L 'END exit=5'; exit 5
}

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $upd -Url $Url -ShaUrl $ShaUrl -Zip 'C:\Windows\Temp\yc-update.zip'
$rc = $LASTEXITCODE
Set-Content -LiteralPath $Stamp -Value (Get-Date).ToString('o') -Encoding ASCII -EA SilentlyContinue
if($rc -eq 0){ L 'payload updated and verified.' 'OK'; L 'END exit=0'; exit 0 }
L ('Update-YcScripts exited ' + $rc + ' - see C:\Windows\Temp\update-yc-scripts.log. It rolls itself back, so C:\Scripts is not half-updated.') 'ERROR'
L 'END exit=5'; exit 5
