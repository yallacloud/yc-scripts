param(
  [string]$Token,
  [string]$TokenFile,
  [string]$Url,
  [ValidateSet('','AE','SG')]
  [string]$Region = '',
  [string]$Exe = 'C:\Scripts\CyberProtect_AgentForWindows_web.exe',
  [string]$InstallerUrl,
  [string[]]$AddComponents = @('agentForWindows','commandLine','trayMonitor'),
  [int]$InstallTimeoutSec = 3600,
  [int]$MinInstallSeconds = 60,
  [int]$ServiceTimeoutSec = 300,
  [int]$TailLines = 60,
  [switch]$RequireSignature,
  [switch]$SkipFirewall,
  [switch]$Diagnose,
  [switch]$Force,
  [switch]$Help
)
# =====================================================================================
# Register-Acronis.ps1 v3 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
# Installs and registers the Acronis Cyber Protect agent, and PROVES the agent is running
# before it claims success or touches the firewall.
#
# ============================ WHAT CHANGED AND WHY ============================
# v2 (the shipped version) failed 14 times over two days and reported the failure in cyan
# text. Its entire command line was:
#
#   --add-components=agentForWindows,commandLine,trayMonitor --reg-token=$Token
#   --reg-address=$Url --quiet --log="$Log"
#
#  1. THE ROOT CAUSE: --log= IS NOT AN ACRONIS SWITCH (old line 30).
#     The documented switch is --log-dir=<path>. The Acronis bootstrapper does not ignore
#     an unknown switch; it rejects the WHOLE command line, exits in about 4 seconds with
#     6452566, and installs nothing. v3 emits only Acronis-documented switches:
#       --quiet, --registration=[skip|by-credentials|by-token|device-flow], --reg-token,
#       --reg-address, --reg-login, --reg-password, --add-components, --log-dir
#     Docs used (verified 2026-08):
#       https://www.acronis.com/en/blog/posts/how-to-personalize-unattended-acronis-agent-installation-on-windows/
#         - full switch list, and the '=' form:
#           .\AcronisCyberProtect_AgentForWindows_x64.exe --quiet
#             --reg-address=https://dev-cloud.acronis.com --reg-token=0454-BAA1-4A1F
#         - and: --quiet --add-components=agentForWindows --registration=skip
#       https://www.acronis.com/en/blog/posts/how-to-automate-acronis-agent-installations/
#         - Acronis' own automation example uses the SPACE form:
#           .\Cyber_Protection_Agent_for_Windows_x64.exe --quiet --registration by-token
#             --reg-token $token --reg-address $baseUrl
#         - and states --reg-token must not be combined with --reg-login/--reg-password.
#     Because BOTH forms are documented and different builds of the bootstrapper have
#     accepted different ones, v3 tries the SPACE form first, and on 6452566 (or on a
#     "success" that finished implausibly fast) automatically retries the '=' form and then
#     a MINIMAL set, logging WHICH variant this image's installer actually accepted and
#     caching that choice in C:\Scripts\acronis-cmdline-variant.txt for the next run.
#
#  2. IT NO LONGER DECLARES SUCCESS FROM AN EXIT CODE (old lines 32-35). The install goes
#     through Invoke-YcInstaller, which enforces a timeout, decodes 6452566 explicitly, and
#     flags a "success" that finished under -MinInstallSeconds as Suspicious. Success is
#     then PROVEN by waiting for the Acronis Managed Machine Service (MMS) to reach Running
#     via Assert-YcService, and by reporting the installed agent version. A run where the
#     installer returns 0 but MMS never starts now exits 7, not 0.
#
#  3. THE FIREWALL RULES ARE NO LONGER CREATED ON THE FAILED PATH (old line 33). v2 created
#     four outbound rules unconditionally, which is why 14 failed installs looked like 14
#     successful ones from the outside. v3 creates them only after MMS is proven Running.
#
#  4. PLACEHOLDER AND NON-HTTPS URLS ARE REJECTED BEFORE ANYTHING RUNS.
#     https://your-dc-cloud.acronis.com - the literal example from the old help text - was
#     actually run twice in production. -Region AE and -Region SG are provided so nobody has
#     to paste a URL at all.
#
#  5. THE INSTALLER BINARY IS VALIDATED BEFORE LAUNCH (Assert-YcFile + PE magic + signature).
#     A truncated download or an HTML proxy error page saved as .exe fails EXACTLY like a
#     rejected command line: a few seconds, a non-zero code, nothing installed. -InstallerUrl
#     fetches it through Get-YcFile, which refuses to save an HTML error page as an .exe.
#
#  6. THE DATA CENTER IS PROVED REACHABLE ON 443 BEFORE THE INSTALLER IS LAUNCHED, so a
#     network problem is reported as a network problem instead of as an installer failure.
#
#  7. THE INSTALLER'S OWN BOOTSTRAPPER LOG IS HARVESTED. %ProgramData%\Acronis\InstallationLogs
#     is searched recursively, plus the --log-dir we passed; the newest log is copied to
#     C:\Scripts\acronis-install.log and its TAIL is echoed into this wrapper's transcript,
#     so the rejected switch is visible in C:\Scripts\acronis-register.log without an RDP
#     session. This is the single change that would have ended the incident on day one.
#
#  8. -Diagnose INSTALLS NOTHING: it checks the binary, the MMS service, DC reachability,
#     the agent version, the firewall rules, and dumps the last installer log.
#
#  9. SECRET HANDLING. The token is never written to the console, the transcript or the
#     Windows Application event log: only a Protect-YcSecret fingerprint (last 4 characters)
#     is logged, and Invoke-YcInstaller redacts --reg-token in BOTH the '=' and the space
#     form before logging the argument list.
#     NOTE / IMPORTANT: PowerShell's own transcript header records the HOST PROCESS COMMAND
#     LINE. If the token is passed as -Token on the command line it is therefore visible in
#     the process table, in Windows Security event 4688, and (until the library scrubs it at
#     exit) in the transcript header. Prefer -TokenFile <path> or the environment variable
#     YC_ACRONIS_TOKEN, neither of which appears on any command line. The .cmd wrapper
#     documents both.
#
# 9b. LIBRARY DEFECT GUARD - THE SPACE FORM DEFEATS _yc-lib v2's REDACTOR.
#     Verified against /tmp/repair2/_yc-lib.ps1 v2.0.0:
#       Protect-YcSecret '--registration by-token --reg-token ABC12-DEF34-SECRET'
#         returns '--registration by-token **** ABC12-DEF34-SECRET'
#     $YcSecretRxParam is '-(?:Token|Password|...)(?=[\s:=])' with NO left-hand anchor, so
#     it matches the '-token' INSIDE the literal 'by-token' and then consumes the NEXT word
#     ('--reg-token') as the value - masking the switch NAME and leaving the actual token in
#     the clear. Because Invoke-YcInstaller logs its argument list through Protect-YcSecret
#     and Write-YcEvent mirrors that line into the Application event log, shipping variant 1
#     unguarded would put the registration token in C:\Scripts\acronis-register.log AND in
#     the Windows Application event log - the exact outcome this script must prevent.
#     This script therefore installs a hardened Protect-YcSecret over the library's one,
#     immediately after dot-sourcing and before Start-YcLog. It (a) requires the flag to
#     start at a whitespace/quote/line boundary so 'by-token' can no longer anchor a match,
#     (b) refuses to treat a following '-switch' as a value, (c) keeps the library's
#     assignment pattern, which is correct, and (d) masks the resolved token by literal
#     string match as a belt-and-braces final pass. Nothing in the library is edited.
#
# 10. IDEMPOTENT. If MMS is already installed and Running the script reports the version and
#     exits 0 without reinstalling, unless -Force is given. Firewall rules are created only
#     when absent.
#
# Every exit is through Exit-Yc. No -ErrorAction SilentlyContinue on a load-bearing step.
# =====================================================================================

. 'C:\Scripts\_yc-lib.ps1'

# ------------------------------------------------------------------------------------
# HARDENED Protect-YcSecret - see item 9b in the header. Installed before Start-YcLog so
# that every library call site (Write-YcLog, Write-YcEvent, Invoke-YcInstaller's argument
# line) uses it. The library file itself is NOT modified.
# ------------------------------------------------------------------------------------
$script:YcKnownSecrets = @()
$script:YcFlagSecretNames = @('reg-token','reg-password','anti-tamper-password','agent-account-password') + $script:YcSecretParams
$script:YcRxFlagSecret = '(?i)(?<=^|[\s"''])(-{1,2}[\w.]*(?:' +
    ((($script:YcFlagSecretNames | Sort-Object { $_.Length } -Descending) | Select-Object -Unique) -join '|') +
    ')[\w.-]*)([:=]|\s+)(?![-/])("[^"]*"|''[^'']*''|[^\s;,&|]+)'

function Protect-YcSecret{
    param([string]$Value,[int]$Keep=0,[switch]$Whole)
    if($null -eq $Value){ return '' }
    if($Value.Length -eq 0){ return '' }
    if($Whole){
        if($Keep -gt 0 -and $Value.Length -gt $Keep){ return ('****' + $Value.Substring($Value.Length - $Keep)) }
        return '****'
    }
    $out = $Value
    # 1. anchored flag form:  --reg-token <t> | --reg-token=<t> | -Token <t> | -SaPassword <p>
    try{ $out = [regex]::Replace($out,$script:YcRxFlagSecret,{ param($m) $m.Groups[1].Value + $m.Groups[2].Value + '****' }) }catch{}
    # 2. the library's assignment form, which is correct:  name=value | name: value
    try{ $out = [regex]::Replace($out,$script:YcSecretRxAssign,{ param($m) $m.Groups[1].Value + $m.Groups[2].Value + '****' }) }catch{}
    # 3. belt and braces: the resolved token, wherever it appears and in whatever form
    foreach($s in $script:YcKnownSecrets){
        if($s -and $s.Length -ge 6){ try{ $out = $out.Replace($s,'****') }catch{} }
    }
    return $out
}

if($Token){ $script:YcKnownSecrets += $Token }
if($env:YC_ACRONIS_TOKEN){ $script:YcKnownSecrets += ([string]$env:YC_ACRONIS_TOKEN).Trim() }

Start-YcLog 'acronis-register'

if($Help){
@"
acronis-register  -  SILENT / unattended install + REGISTRATION of the Acronis Cyber Protect
                     agent, with proof that the agent is actually running.

USAGE:
  acronis-register -Region AE  -TokenFile C:\Scripts\.acronis.token
  acronis-register -Region SG  -Token <REGISTRATION_TOKEN>
  acronis-register -Url https://ae01-cloud.acronis.com -Token <REGISTRATION_TOKEN>
  acronis-register -Diagnose
  acronis-register -Help

GET TOKEN : Acronis console > Devices > + Add > "Register via token".
GET URL   : your Acronis login data center, e.g. https://ae01-cloud.acronis.com
            -Region AE = https://ae01-cloud.acronis.com
            -Region SG = https://sg-cloud.acronis.com

HOW THE TOKEN SHOULD BE SUPPLIED (in order of preference):
  1. -TokenFile <path>        the file holds the token and nothing else; not on any cmdline
  2. $env:YC_ACRONIS_TOKEN    set it in the calling shell / cloud-init unit
  3. -Token <token>           WORKS, but the value is then visible in the process table, in
                              Windows Security event 4688, and in the PowerShell transcript
                              header (PowerShell writes the host command line there). The
                              library scrubs the header when this command exits; the window
                              before that is real. Use 1 or 2 in production.

PARAMETERS:
  -Token              Acronis registration token. Prefer -TokenFile / YC_ACRONIS_TOKEN.
  -TokenFile          File containing the registration token (first non-empty line).
  -Url                Acronis data center URL. Must be https:// and must not be a placeholder.
  -Region             AE or SG - shorthand for the data center URL. Ignored if -Url is given.
  -Exe                Installer path. Default C:\Scripts\CyberProtect_AgentForWindows_web.exe
  -InstallerUrl       If -Exe is missing, download it from here first (TLS 1.2, HTML-page
                      protection, retries). Optional.
  -AddComponents      Components to install. Default agentForWindows,commandLine,trayMonitor
  -InstallTimeoutSec  Kill the installer after this many seconds. Default 3600.
  -MinInstallSeconds  A "successful" install faster than this is treated as a rejected
                      command line, not a success. Default 60.
  -ServiceTimeoutSec  How long to wait for MMS to reach Running. Default 300.
  -TailLines          Lines of the installer's own log to echo into this log. Default 60.
  -RequireSignature   Make an Authenticode status other than Valid a hard failure.
                      By default only NotSigned / HashMismatch are fatal, because a sealed
                      image with no egress cannot always check revocation.
  -SkipFirewall       Do not create the outbound firewall rules.
  -Diagnose           Install NOTHING. Report binary, MMS service, DC reachability, agent
                      version, firewall rules and the last installer log.
  -Force              Reinstall even if MMS is already installed and Running.
  -Help               Show this help and exit.

WHAT IT PROVES BEFORE REPORTING SUCCESS:
  1. the installer binary exists, is > 1 MB, starts with the MZ PE signature, and is signed
  2. the data center answers on TCP 443
  3. the installer exited with a success code AND took longer than -MinInstallSeconds
  4. the Acronis Managed Machine Service reaches Running (waited for, not assumed)
  5. the installed agent version can be read back
  Only after 4 and 5 are the outbound firewall rules created.

EXIT CODES:
  0  agent installed, MMS Running, version reported (or already installed and Running)
  1  installation failed - the installer rejected every documented command-line variant,
     or failed for another reason. See the echoed installer log tail.
  2  usage error (no token, no URL, placeholder URL, bad URL)
  3  installed, but Windows must be rebooted to complete
  4  the installer binary is missing, truncated, not a PE, or not signed
  5  not running as Administrator
  6  the Acronis data center is not reachable on TCP 443
  7  the installer reported success but the MMS service never reached Running

EXAMPLES:
  acronis-register -Region AE -TokenFile C:\Scripts\.acronis.token
  acronis-register -Region SG -Token ABC12-DEF34
  acronis-register -Url https://ae01-cloud.acronis.com -Token ABC12-DEF34 -AddComponents agentForWindows
  acronis-register -Diagnose
  acronis-register -Help

NOTES: run on the DEPLOYED VM, not on the golden image. Alternative authentication is
       --reg-login / --reg-password; Acronis documents that neither may be combined with
       --reg-token, so this command uses the token form only.

Log: C:\Scripts\acronis-register.log
     Installer's own log copied to C:\Scripts\acronis-install.log
     Accepted command-line variant cached in C:\Scripts\acronis-cmdline-variant.txt
"@ | Write-Host -ForegroundColor Cyan
  Exit-Yc 0 'help shown' 'INFO'
}

Assert-YcPrereqs -NeedAdmin
Set-YcTls

# ------------------------------------------------------------------------------------
# Constants and helpers
# ------------------------------------------------------------------------------------

$RegionMap = @{
  'AE' = 'https://ae01-cloud.acronis.com'
  'SG' = 'https://sg-cloud.acronis.com'
}
$AcronisPorts     = @(443,8443,44445,9877)
$InstallLogCopy   = 'C:\Scripts\acronis-install.log'
$VariantCacheFile = 'C:\Scripts\acronis-cmdline-variant.txt'
$InstallerLogRoot = 'C:\Scripts\acronis-installer-logs'
$VendorLogRoot    = Join-Path $env:ProgramData 'Acronis\InstallationLogs'

# Placeholder fragments that must never reach the installer. The first entry is the literal
# value from the old help text that was run twice in production.
$UrlPlaceholders = @('your-dc','your-datacenter','yourdc','your-cloud','example.com',
                     'example.org','changeme','change-me','placeholder','<','>','{','}',
                     'xxxx','dc-name','datacenter-name')

function Get-YcTcpOpen{
  param([string]$HostName,[int]$Port=443,[int]$TimeoutMs=6000)
  $client = New-Object System.Net.Sockets.TcpClient
  $ok = $false
  try{
    $iar = $client.BeginConnect($HostName,$Port,$null,$null)
    if($iar.AsyncWaitHandle.WaitOne($TimeoutMs,$false)){
      $client.EndConnect($iar)
      $ok = $true
    }
  }catch{
    $ok = $false
  }finally{
    try{ $client.Close() }catch{}
  }
  return $ok
}

function Test-YcAcronisUrl{
  param([string]$Candidate)
  $r = [pscustomobject]@{ Ok=$false; Reason=''; HostName='' }
  if(-not $Candidate){ $r.Reason = 'no URL supplied'; return $r }
  $u = $Candidate.Trim().TrimEnd('/')
  $low = $u.ToLowerInvariant()
  foreach($p in $UrlPlaceholders){
    if($low.Contains($p)){
      $r.Reason = ("the URL contains the placeholder fragment '" + $p + "' - this is the example from the old help text, not a real data center. Use -Region AE / -Region SG, or the URL you log in to.")
      return $r
    }
  }
  if($low -notlike 'https://*'){
    $r.Reason = 'the URL must start with https:// - the registration token is sent over it'
    return $r
  }
  $parsed = $null
  try{ $parsed = [uri]$u }catch{ $parsed = $null }
  if(-not $parsed -or -not $parsed.Host){
    $r.Reason = 'the URL does not parse as a URI'
    return $r
  }
  if($parsed.Scheme -ne 'https'){
    $r.Reason = ('scheme is ' + $parsed.Scheme + ', expected https')
    return $r
  }
  if($parsed.Host -notmatch '^[A-Za-z0-9]([A-Za-z0-9\-\.]*[A-Za-z0-9])?$' -or $parsed.Host -notlike '*.*'){
    $r.Reason = ('"' + $parsed.Host + '" is not a resolvable-looking host name')
    return $r
  }
  $r.HostName = $parsed.Host
  $r.Ok = $true
  return $r
}

# Resolves the Acronis Managed Machine Service under whatever name this build registered it.
# Returns the SERVICE NAME (not the display name), or '' if no candidate exists.
function Get-YcMmsName{
  $names = @('MMS','AcronisAgent','Acronis Managed Machine Service')
  foreach($n in $names){
    $s = $null
    try{ $s = Get-Service -Name $n -ErrorAction SilentlyContinue }catch{ $s = $null }
    if($s){ return [string]$s.Name }
  }
  $all = @()
  try{ $all = @(Get-Service -ErrorAction Stop) }catch{ $all = @() }
  foreach($s in $all){
    $dn = [string]$s.DisplayName
    if($dn -like '*Managed Machine Service*' -or $dn -like 'Acronis Agent*' -or $dn -like 'Acronis Managed*'){
      return [string]$s.Name
    }
  }
  return ''
}

# Best-effort agent version, from the MMS binary and from the uninstall registry.
function Get-YcAcronisVersion{
  param([string]$ServiceName)
  $found = @()
  if($ServiceName){
    $path = ''
    try{
      $ws = Get-CimInstance -ClassName Win32_Service -Filter ("Name='" + $ServiceName + "'") -ErrorAction Stop
      if($ws){ $path = [string]$ws.PathName }
    }catch{ $path = '' }
    if($path){
      $exe = $path.Trim()
      if($exe.StartsWith('"')){
        $end = $exe.IndexOf('"',1)
        if($end -gt 1){ $exe = $exe.Substring(1,$end-1) }
      }else{
        $sp = $exe.IndexOf('.exe ')
        if($sp -gt 0){ $exe = $exe.Substring(0,$sp+4) }
      }
      if(Test-Path -LiteralPath $exe){
        try{
          $vi = (Get-Item -LiteralPath $exe).VersionInfo
          $found += ((Split-Path -Leaf $exe) + ' ' + [string]$vi.ProductVersion + ' (file ' + [string]$vi.FileVersion + ')')
        }catch{}
      }
    }
  }
  $keys = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
  try{
    $apps = Get-ItemProperty -Path $keys -ErrorAction SilentlyContinue |
              Where-Object { $_.DisplayName -and ([string]$_.DisplayName) -like 'Acronis*' }
    foreach($a in $apps){ $found += (([string]$a.DisplayName) + ' ' + ([string]$a.DisplayVersion)) }
  }catch{}
  if($found.Count -eq 0){ return @('version not readable') }
  return ($found | Sort-Object -Unique)
}

# Copies the newest Acronis bootstrapper log to C:\Scripts\acronis-install.log and echoes its
# tail into this transcript. Returns the source path, or '' when there is nothing to harvest.
function Copy-YcAcronisInstallLog{
  param([string[]]$SearchRoots,[int]$Tail = 60)
  $cands = @()
  foreach($root in $SearchRoots){
    if(-not $root){ continue }
    if(-not (Test-Path -LiteralPath $root)){ continue }
    try{
      $cands += @(Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue |
                    Where-Object { $_.Extension -match '(?i)^\.(log|txt)$' -and $_.Length -gt 0 })
    }catch{}
  }
  if($cands.Count -eq 0){
    Write-YcLog ('no Acronis bootstrapper log found under: ' + ($SearchRoots -join ' ; ') + '. If the installer never started, there will be none.') 'WARN'
    return ''
  }
  $newest = $cands | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  try{
    Copy-Item -LiteralPath $newest.FullName -Destination $InstallLogCopy -Force -ErrorAction Stop
    Write-YcLog ('installer log: ' + $newest.FullName + ' (' + $newest.Length + ' bytes, ' + $newest.LastWriteTime + ') copied to ' + $InstallLogCopy) 'OK'
  }catch{
    Write-YcLog ('could not copy ' + $newest.FullName + ' to ' + $InstallLogCopy + ': ' + $_.Exception.Message) 'WARN'
  }
  $lines = @()
  try{ $lines = @(Get-Content -LiteralPath $newest.FullName -Tail $Tail -ErrorAction Stop) }
  catch{
    try{ $lines = @(Get-Content -LiteralPath $InstallLogCopy -Tail $Tail -ErrorAction Stop) }catch{ $lines = @() }
  }
  if($lines.Count -gt 0){
    Write-Host ''
    Write-Host ('----- tail of ' + $newest.Name + ' (' + $lines.Count + ' lines, secrets masked) -----') -ForegroundColor Cyan
    foreach($ln in $lines){
      $safeLine = Protect-YcSecret ([string]$ln)
      Write-Host ('  | ' + $safeLine)
    }
    Write-Host '----- end of installer log tail -----' -ForegroundColor Cyan
    Write-Host ''
  }
  # Pull the lines that name a rejected switch to the top of the wrapper log.
  $hits = @()
  try{
    $all = Get-Content -LiteralPath $newest.FullName -ErrorAction Stop
    foreach($ln in $all){
      if(([string]$ln) -match '(?i)(unknown|unrecognis|unrecogniz|invalid|not supported|unsupported|rejected|bad).{0,40}(option|switch|parameter|argument|command)'){
        $hits += (Protect-YcSecret ([string]$ln)).Trim()
      }
    }
  }catch{}
  foreach($h in ($hits | Select-Object -Unique -First 5)){
    Write-YcLog ('installer complained: ' + $h) 'ERROR'
  }
  return $newest.FullName
}

function New-YcAcronisFirewallRules{
  param([int[]]$Ports)
  $made = @()
  $kept = @()
  foreach($pt in $Ports){
    $name = 'Acronis out ' + $pt
    $existing = $null
    try{ $existing = Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue }catch{ $existing = $null }
    if($existing){ $kept += $pt; continue }
    try{
      New-NetFirewallRule -DisplayName $name -Direction Outbound -Action Allow -Protocol TCP `
                          -RemotePort $pt -Profile Any -ErrorAction Stop | Out-Null
      $made += $pt
    }catch{
      Write-YcLog ('could not create outbound firewall rule "' + $name + '": ' + $_.Exception.Message) 'WARN'
    }
  }
  if($made.Count -gt 0){ Write-YcLog ('outbound firewall rules created for TCP ' + ($made -join ',')) 'OK' }
  if($kept.Count -gt 0){ Write-YcLog ('outbound firewall rules already present for TCP ' + ($kept -join ',')) 'INFO' }
}

# ------------------------------------------------------------------------------------
# Resolve the token (file / environment / parameter) and the URL (region / parameter)
# ------------------------------------------------------------------------------------

$tokenSource = ''
if($TokenFile){
  if(-not (Test-Path -LiteralPath $TokenFile)){
    Exit-Yc 2 ('-TokenFile does not exist: ' + $TokenFile) 'ERROR'
  }
  $fileLines = @()
  try{ $fileLines = @(Get-Content -LiteralPath $TokenFile -ErrorAction Stop) }
  catch{ Exit-Yc 2 ('-TokenFile could not be read: ' + $_.Exception.Message) 'ERROR' }
  foreach($ln in $fileLines){
    $t = ([string]$ln).Trim()
    if($t.Length -gt 0 -and -not $t.StartsWith('#')){ $Token = $t; break }
  }
  if(-not $Token){ Exit-Yc 2 ('-TokenFile is empty: ' + $TokenFile) 'ERROR' }
  $script:YcKnownSecrets += $Token   # register it before anything can log it
  $tokenSource = 'TokenFile'
}elseif($env:YC_ACRONIS_TOKEN){
  $Token = ([string]$env:YC_ACRONIS_TOKEN).Trim()
  $tokenSource = 'environment YC_ACRONIS_TOKEN'
}elseif($Token){
  $tokenSource = '-Token on the command line'
}

if($Url){
  $Url = $Url.Trim().TrimEnd('/')
}elseif($Region){
  $Url = $RegionMap[$Region.ToUpperInvariant()]
}

if(-not $Diagnose){
  if(-not $Token){
    Exit-Yc 2 'no registration token. Supply -TokenFile <path> (preferred), set YC_ACRONIS_TOKEN, or pass -Token. Run "acronis-register -Help".' 'ERROR'
  }
  if(-not $Url){
    Exit-Yc 2 'no data center URL. Use -Region AE, -Region SG, or -Url https://<your-dc>.acronis.com. Run "acronis-register -Help".' 'ERROR'
  }
}

$dcHost = ''
if($Url){
  $chk = Test-YcAcronisUrl -Candidate $Url
  if(-not $chk.Ok){
    Exit-Yc 2 ('REFUSING the data center URL "' + $Url + '": ' + $chk.Reason) 'ERROR'
  }
  $dcHost = $chk.HostName
  Write-YcLog ('data center URL accepted: ' + $Url + ' (host ' + $dcHost + ')') 'OK'
}

if($Token){
  # Only a fingerprint is ever logged. The raw token never reaches the console, the
  # transcript or the Application event log.
  $tokenFingerprint = Protect-YcSecret -Value $Token -Whole -Keep 4
  Write-YcLog ('registration token supplied via ' + $tokenSource + ' (fingerprint ' + $tokenFingerprint + ', length ' + $Token.Length + ')') 'INFO'
  if($tokenSource -eq '-Token on the command line'){
    Write-YcLog 'the token was passed on the command line: it is visible in the process table and in Windows Security event 4688, and PowerShell wrote the host command line into this transcript header (the library scrubs it at exit). Prefer -TokenFile or YC_ACRONIS_TOKEN.' 'WARN'
  }
}

# ------------------------------------------------------------------------------------
# -Diagnose : install nothing, report everything
# ------------------------------------------------------------------------------------

if($Diagnose){
  Write-YcLog 'DIAGNOSE mode - nothing will be installed, registered or changed.' 'INFO'
  $problems = 0

  # 1. installer binary
  if(Test-Path -LiteralPath $Exe){
    $sizeMB = 0
    try{ $sizeMB = [math]::Round((Get-Item -LiteralPath $Exe).Length / 1MB,1) }catch{}
    $kind = Get-YcFileKind -Path $Exe
    $sig = 'Unavailable'
    try{ $sig = [string](Get-AuthenticodeSignature -LiteralPath $Exe -ErrorAction Stop).Status }catch{ $sig = 'Unavailable' }
    $lvl = 'OK'
    if($kind -ne 'PE' -or $sizeMB -lt 1){ $lvl = 'ERROR'; $problems++ }
    Write-YcLog ('installer: ' + $Exe + ' - ' + $sizeMB + ' MB, content looks like ' + $kind + ', Authenticode ' + $sig) $lvl
  }else{
    Write-YcLog ('installer NOT present: ' + $Exe) 'WARN'
  }

  # 2. MMS service
  $svcName = Get-YcMmsName
  if($svcName){
    $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
    $st = 'unknown'
    if($svc){ $st = [string]$svc.Status }
    $lvl = 'OK'
    if($st -ne 'Running'){ $lvl = 'ERROR'; $problems++ }
    Write-YcLog ('Acronis MMS service "' + $svcName + '" is ' + $st) $lvl
    foreach($v in (Get-YcAcronisVersion -ServiceName $svcName)){ Write-YcLog ('agent: ' + $v) 'INFO' }
  }else{
    Write-YcLog 'no Acronis Managed Machine Service is registered on this host - the agent is NOT installed.' 'ERROR'
    $problems++
  }

  # 3. data center reachability
  if($dcHost){
    if(Get-YcTcpOpen -HostName $dcHost -Port 443){
      Write-YcLog ($dcHost + ':443 is reachable') 'OK'
    }else{
      Write-YcLog ($dcHost + ':443 is NOT reachable - registration cannot work from this host') 'ERROR'
      $problems++
    }
  }else{
    Write-YcLog 'no -Url / -Region given, so data center reachability was not tested.' 'INFO'
  }

  # 4. firewall rules
  foreach($pt in $AcronisPorts){
    $rule = $null
    try{ $rule = Get-NetFirewallRule -DisplayName ('Acronis out ' + $pt) -ErrorAction SilentlyContinue }catch{ $rule = $null }
    if($rule){ Write-YcLog ('firewall rule "Acronis out ' + $pt + '" present (' + $rule.Enabled + ')') 'INFO' }
    else     { Write-YcLog ('firewall rule "Acronis out ' + $pt + '" absent') 'INFO' }
  }

  # 5. cached command-line variant + last installer log
  if(Test-Path -LiteralPath $VariantCacheFile){
    try{ Write-YcLog ('last accepted installer command-line variant: ' + ((Get-Content -LiteralPath $VariantCacheFile -ErrorAction Stop) -join ' ')) 'INFO' }catch{}
  }
  [void](Copy-YcAcronisInstallLog -SearchRoots @($VendorLogRoot,$InstallerLogRoot) -Tail $TailLines)

  if($problems -eq 0){ Exit-Yc 0 'DIAGNOSE: the Acronis agent looks healthy on this host.' 'OK' }
  Exit-Yc 1 ('DIAGNOSE: ' + $problems + ' problem(s) found - see the ERROR lines above and the installer log tail.') 'ERROR'
}

# ------------------------------------------------------------------------------------
# Idempotence: already installed and running?
# ------------------------------------------------------------------------------------

$existingSvc = Get-YcMmsName
if($existingSvc -and -not $Force){
  $svc = Get-Service -Name $existingSvc -ErrorAction SilentlyContinue
  if($svc -and $svc.Status -eq 'Running'){
    foreach($v in (Get-YcAcronisVersion -ServiceName $existingSvc)){ Write-YcLog ('agent already installed: ' + $v) 'OK' }
    if(-not $SkipFirewall){ New-YcAcronisFirewallRules -Ports $AcronisPorts }
    Exit-Yc 0 ('the Acronis agent is already installed and the "' + $existingSvc + '" service is Running - nothing to do. Use -Force to reinstall.') 'OK'
  }
  Write-YcLog ('the "' + $existingSvc + '" service exists but is ' + $(if($svc){$svc.Status}else{'unreadable'}) + ' - continuing with the install/repair.') 'WARN'
}

# ------------------------------------------------------------------------------------
# Preflight: installer binary, then data center reachability
# ------------------------------------------------------------------------------------

if(-not (Test-Path -LiteralPath $Exe) -and $InstallerUrl){
  # Explicit TLS 1.2 (ORed, so TLS 1.3 is not dropped on Server 2022/2025) before any download.
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
  Write-YcLog ('installer missing - downloading from ' + $InstallerUrl) 'INFO'
  $got = Get-YcFile -Uri $InstallerUrl -OutFile $Exe -MinBytes 1048576 -Retries 3 -TimeoutSec 900
  if(-not $got){
    Exit-Yc 4 ('the installer could not be downloaded from ' + $InstallerUrl + ' - nothing was installed.') 'ERROR'
  }
}

# exists and is at least 1 MB; a truncated download or an HTML error page fails here
[void](Assert-YcFile -Path $Exe -MinBytes 1048576 -Because 'the Acronis agent installer' -Fatal)

$kind = Get-YcFileKind -Path $Exe
if($kind -ne 'PE'){
  Exit-Yc 4 ('the installer at ' + $Exe + ' is not a Windows executable - its content looks like ' + $kind + '. A truncated download or an HTML proxy/error page saved with a .exe name fails exactly like a rejected command line. Re-download it.') 'ERROR'
}

$sigStatus = 'Unavailable'
$sigSubject = ''
try{
  $sg = Get-AuthenticodeSignature -LiteralPath $Exe -ErrorAction Stop
  $sigStatus = [string]$sg.Status
  if($sg.SignerCertificate){ $sigSubject = [string]$sg.SignerCertificate.Subject }
}catch{
  $sigStatus = 'Unavailable'
}
if($sigStatus -eq 'Valid'){
  Write-YcLog ('installer signature Valid: ' + $sigSubject) 'OK'
  if($sigSubject -and $sigSubject -notmatch '(?i)acronis'){
    Write-YcLog ('the installer is signed, but not by Acronis: ' + $sigSubject) 'WARN'
  }
}elseif($sigStatus -eq 'NotSigned' -or $sigStatus -eq 'HashMismatch'){
  Exit-Yc 4 ('the installer at ' + $Exe + ' has Authenticode status ' + $sigStatus + ' - refusing to run it.') 'ERROR'
}else{
  if($RequireSignature){
    Exit-Yc 4 ('the installer Authenticode status is ' + $sigStatus + ' and -RequireSignature was given - refusing to run it.') 'ERROR'
  }
  Write-YcLog ('installer Authenticode status is ' + $sigStatus + ' (not Valid). This is common on a sealed image with no egress for revocation checking; continuing. Use -RequireSignature to make this fatal.') 'WARN'
}

if(-not (Get-YcTcpOpen -HostName $dcHost -Port 443)){
  Exit-Yc 6 ('the Acronis data center ' + $dcHost + ' does not answer on TCP 443. Registration cannot succeed, so the installer was NOT launched. Check DNS, egress and any proxy.') 'ERROR'
}
Write-YcLog ($dcHost + ':443 reachable - proceeding') 'OK'

# ------------------------------------------------------------------------------------
# The command-line variants. Every switch below is Acronis-documented.
# ------------------------------------------------------------------------------------

if(-not (Test-Path -LiteralPath $InstallerLogRoot)){
  New-Item -ItemType Directory -Path $InstallerLogRoot -Force | Out-Null
}
$compList = ($AddComponents -join ',')

# variant 1 - SPACE form, exactly as Acronis' own automation blog writes it:
#   --quiet --registration by-token --reg-token <t> --reg-address <url>
# variant 2 - '=' form, as the Acronis "personalize unattended installation" post writes it:
#   --quiet --registration=by-token --reg-token=<t> --reg-address=<url> --add-components=<c>
# variant 3 - MINIMAL: no components, no log directory. This is the shortest documented
#   working example; if this one is also rejected, the problem is not the switch syntax.

function Get-YcAcronisArgs{
  param([string]$Variant,[string]$LogDir,[string]$RegToken,[string]$RegAddress,[string]$Components)
  switch($Variant){
    'space' {
      return @('--quiet',
               '--registration','by-token',
               '--reg-token',$RegToken,
               '--reg-address',$RegAddress,
               '--add-components',$Components,
               '--log-dir',$LogDir)
    }
    'equals' {
      return @('--quiet',
               '--registration=by-token',
               ('--reg-token=' + $RegToken),
               ('--reg-address=' + $RegAddress),
               ('--add-components=' + $Components),
               ('--log-dir=' + $LogDir))
    }
    default {
      return @('--quiet',
               ('--reg-token=' + $RegToken),
               ('--reg-address=' + $RegAddress))
    }
  }
}

# If a previous run learned which variant this image accepts, try that one first.
$order = @('space','equals','minimal')
if(Test-Path -LiteralPath $VariantCacheFile){
  $cached = ''
  try{ $cached = (('' + (Get-Content -LiteralPath $VariantCacheFile -ErrorAction Stop | Select-Object -First 1)).Trim()) }catch{ $cached = '' }
  if($order -contains $cached){
    $order = @($cached) + @($order | Where-Object { $_ -ne $cached })
    Write-YcLog ('a previous run recorded that this image accepts the "' + $cached + '" command-line form - trying it first.') 'INFO'
  }
}

$result   = $null
$accepted = ''
$attempt  = 0

foreach($vname in $order){
  $attempt++
  $logDir = Join-Path $InstallerLogRoot ('attempt-' + $attempt + '-' + $vname)
  if(Test-Path -LiteralPath $logDir){ Remove-Item -LiteralPath $logDir -Recurse -Force -ErrorAction SilentlyContinue }
  New-Item -ItemType Directory -Path $logDir -Force | Out-Null

  $argList = Get-YcAcronisArgs -Variant $vname -LogDir $logDir -RegToken $Token -RegAddress $Url -Components $compList
  Write-YcLog ('attempt ' + $attempt + '/' + $order.Count + ' using the "' + $vname + '" documented switch form') 'INFO'

  $result = Invoke-YcInstaller -FilePath $Exe -ArgumentList $argList `
                               -SuccessCodes @(0) -RebootCodes @(3010,1641) `
                               -TimeoutSec $InstallTimeoutSec -MinSeconds $MinInstallSeconds

  if($result.Success){ $accepted = $vname; break }

  $rejected = ($result.ExitCode -eq 6452566) -or ($result.ExitCode -eq 1639) -or
              ($result.Status -eq 'Suspicious') -or
              ($result.ExitCode -eq 1 -and $result.DurationSec -lt $MinInstallSeconds)

  # Harvest the installer's own log for THIS attempt so the rejected switch is on record.
  [void](Copy-YcAcronisInstallLog -SearchRoots @($logDir,$VendorLogRoot) -Tail $TailLines)

  if(-not $rejected){
    Write-YcLog ('the installer failed with exit ' + $result.ExitCode + ' (' + $result.Meaning + '). That is not a command-line rejection, so the remaining switch forms will NOT be tried.') 'ERROR'
    break
  }
  if($attempt -lt $order.Count){
    Write-YcLog ('the "' + $vname + '" form was REJECTED (exit ' + $result.ExitCode + ', ' + $result.DurationSec + 's). Retrying with the next documented form.') 'WARN'
  }
}

if(-not $result -or -not $result.Success){
  [void](Copy-YcAcronisInstallLog -SearchRoots @($InstallerLogRoot,$VendorLogRoot) -Tail $TailLines)
  $tail = 'no installer log was produced'
  if($result){ $tail = ('last exit ' + $result.ExitCode + ' - ' + $result.Meaning) }
  Exit-Yc 1 ('the Acronis agent was NOT installed. Every documented command-line form was tried (' + ($order -join ', ') + '). ' + $tail + '. The installer log tail is above and in ' + $InstallLogCopy + '. NO firewall rules were created.') 'ERROR'
}

Write-YcLog ('the installer ACCEPTED the "' + $accepted + '" switch form (exit ' + $result.ExitCode + ' in ' + $result.DurationSec + 's).') 'OK'
try{ Set-Content -LiteralPath $VariantCacheFile -Value $accepted -Encoding ascii -ErrorAction Stop }catch{}

# Harvest the successful run's log too - registration warnings live there.
[void](Copy-YcAcronisInstallLog -SearchRoots @($InstallerLogRoot,$VendorLogRoot) -Tail $TailLines)

# ------------------------------------------------------------------------------------
# PROOF: the service must reach Running, and the version must be readable.
# ------------------------------------------------------------------------------------

$svcName = ''
$deadline = (Get-Date).AddSeconds(120)
while(-not $svcName -and (Get-Date) -lt $deadline){
  $svcName = Get-YcMmsName
  if(-not $svcName){ Start-Sleep -Seconds 5 }
}
if(-not $svcName){
  Exit-Yc 7 ('the installer reported success (exit ' + $result.ExitCode + ') but NO Acronis Managed Machine Service was registered within 120s. Nothing was installed. See ' + $InstallLogCopy + '. NO firewall rules were created.') 'ERROR'
}

$running = Assert-YcService -Name $svcName -TimeoutSec $ServiceTimeoutSec -State 'Running' -StartIfStopped `
                            -Because 'the Acronis agent is only registered once MMS is running'
if(-not $running){
  Exit-Yc 7 ('the installer reported success but the "' + $svcName + '" service did not reach Running within ' + $ServiceTimeoutSec + 's. The agent is NOT protecting this host. See ' + $InstallLogCopy + '. NO firewall rules were created.') 'ERROR'
}

$versions = Get-YcAcronisVersion -ServiceName $svcName
foreach($v in $versions){ Write-YcLog ('installed agent: ' + $v) 'OK' }

# ------------------------------------------------------------------------------------
# Only now: the outbound firewall rules.
# ------------------------------------------------------------------------------------

if($SkipFirewall){
  Write-YcLog '-SkipFirewall given - outbound rules not created. The agent needs outbound TCP 443/8443/44445/9877.' 'WARN'
}else{
  New-YcAcronisFirewallRules -Ports $AcronisPorts
}

if($result.RebootRequired){
  Exit-Yc 3 ('the Acronis agent is installed and "' + $svcName + '" is Running, but the installer requested a REBOOT (exit ' + $result.ExitCode + ') to complete. Reboot this VM.') 'WARN'
}

Exit-Yc 0 ('Acronis agent installed and registered against ' + $Url + '. Service "' + $svcName + '" is Running, version reported above, outbound rules in place. Installer log: ' + $InstallLogCopy + '.') 'OK'
