# test-autoupdate-state.ps1 - the 304 trap, in four assertions.
#
# A 304 on the sidecar means "the published hash is still the one you cached".
# It does NOT mean "this box carries that payload". Yc-AutoUpdate used to treat
# the two as the same thing and exit 0, so a box that fetched the sidecar and
# then never applied the zip reported "current" forever. These assertions fail
# against that version of the file.
#
#   powershell -NoProfile -ExecutionPolicy Bypass -File test-autoupdate-state.ps1
$ErrorActionPreference = 'Stop'
$src = Join-Path $PSScriptRoot 'Yc-AutoUpdate.ps1'
if(-not (Test-Path -LiteralPath $src)){ Write-Host "SKIP - Yc-AutoUpdate.ps1 not beside this test"; exit 0 }
$t = Get-Content -LiteralPath $src -Raw
$fail = 0
function A([string]$name,[bool]$ok){
  if($ok){ Write-Host ("PASS  " + $name) } else { Write-Host ("FAIL  " + $name); $script:fail++ }
}

# 1. The state file must carry the hash, not just the ETag - a 304 is useless without it.
A '304 path has a cached hash to fall back on' ($t -match '\$cachedSha')
# 2. The 304 branch must not short-circuit the run.
$branch = ''
if($t -match '(?s)StatusCode\s*-eq\s*304\s*\)\s*\{(.*?)\n\s{2}\}'){ $branch = $Matches[1] }
A '304 branch does not exit'          ($branch -notmatch 'exit\s+0')
A '304 branch reuses the cached hash' ($branch -match '\$remoteSha\s*=\s*\$cachedSha')
# 3. -Force must be able to break a stale ETag, or the operator has no escape hatch.
A '-Force drops If-None-Match'        ($t -match '-not\s+\$cachedSha\s+-or\s+\$Force\s*\)\s*\{\s*\$etag\s*=')

# 4. The parsing block itself, run for real.
$tmp = Join-Path $env:TEMP ('yc-au-' + [guid]::NewGuid().ToString('N') + '.txt')
$sha = ('A' * 64)
Set-Content -LiteralPath $tmp -Value @('"abc123"', $sha.ToLower()) -Encoding ASCII
$etag = ''; $cachedSha = ''
$lines = @(Get-Content -LiteralPath $tmp | ForEach-Object { $_.Trim() } | Where-Object { $_ })
if($lines.Count -ge 1){ $etag = $lines[0] }
if($lines.Count -ge 2 -and $lines[1] -match '([0-9a-fA-F]{64})'){ $cachedSha = $Matches[1].ToUpper() }
Remove-Item -LiteralPath $tmp -Force -EA SilentlyContinue
A 'two-line state parses to etag + upper-case hash' ($etag -eq '"abc123"' -and $cachedSha -eq $sha)

if($fail){ Write-Host ("`n{0} assertion(s) failed." -f $fail); exit 1 }
Write-Host "`nAll assertions passed."
exit 0
