@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Yallacloud.ps1" %*
