param(
  # ---- names preserved from rootcause.cmd and the catalog ----
  [switch]$Latest,                                   # write to a fixed file instead of a timestamped one
  # ---- ADDED in this revision ----
  [switch]$Analyze,                                  # RUN THE KERNEL DEBUGGER. Off by default. See below.
  [int]$AnalyzeTimeoutSec = 120,                     # hard timeout for cdb; it is KILLED at this point
  [string]$SymbolPath = 'srv*C:\symbols*https://msdl.microsoft.com/download/symbols',
  [string]$DumpPath,                                 # analyse this dump instead of the newest minidump
  [switch]$Force,                                    # run even if another instance holds the lock
  [switch]$Help
)
# =====================================================================================
# Root-Cause.ps1 - root-cause report: BSOD bugchecks, disk/NTFS/network errors, SMART,
# minidumps, and (only on demand) a bounded cdb !analyze.
# PowerShell 5.1, ASCII only. Runs unattended (cloud-init / SYSTEM / RMM / boot task).
#
# Stamp: 2026-08-19 - removed the documented exit code 1 'generic failure'; it is unreachable.
#        No behaviour changed.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P0-28] THIS SCRIPT HUNG THE BOOT OF EVERY VM IT RAN ON.
#   Old line 42 ran, unattended and as SYSTEM:
#       (& $cdb -z $dmp.FullName -c "!analyze -v; q")
#   with NO -y symbol path and NO timeout, and yc-health.ps1:11 invokes this script at
#   every boot and again at 03:30. Two failure modes, both fatal on a remote VM:
#     * With no symbol path the output is worthless - !analyze cannot name a module.
#     * If _NT_SYMBOL_PATH is set machine-wide (an SCCM/DDK image, a UNC symbol share)
#       cdb blocks on a symbol download with no timeout and no console to cancel it. The
#       health task never completes, and the next boot stacks another copy on top of it.
#   NOW:
#     * The debugger runs ONLY behind the explicit -Analyze switch. The boot path
#       (yc-health.ps1 calls "Root-Cause.ps1 -Latest") therefore never starts a debugger.
#     * When it does run it is Start-Process -PassThru with WaitForExit(<ms>) and a Kill()
#       on timeout, exactly the pattern below, output redirected to a temp file:
#         -y srv*C:\symbols*https://msdl.microsoft.com/download/symbols -z <dump> -c "!analyze -v; q"
#     * _NT_SYMBOL_PATH is overridden for the child process so a machine-wide UNC symbol
#       path cannot hijack the resolution and block on an unreachable share.
#     * SINGLE INSTANCE: a named mutex (Global\YallaCloud-RootCause) plus a breadcrumb
#       lock file. A second invocation exits IMMEDIATELY with code 11 instead of stacking.
#       The mutex is released by the OS when the process ends, so a killed run cannot
#       leave the machine permanently locked out.
#
# OTHER DEFECTS FIXED HERE
#   - Old line 22 set $ErrorActionPreference='SilentlyContinue' for the WHOLE script, so a
#     failure to create the report file itself was invisible and the script still "worked".
#     The preference is now 'Continue'; the report file is created with -ErrorAction Stop;
#     -ErrorAction SilentlyContinue survives ONLY on the event-log probes, where a missing
#     provider (vioscsi on a VMware box, netkvm on Hyper-V) is expected and not an error.
#   - The script never exited through Exit-Yc and never wrote an [END] line. It does now.
#   - `cmd /c fsutil dirty query X:` is now `fsutil dirty query X:` directly - no cmd.exe.
#
# VENDOR VERIFICATION
#   cdb -y <SymbolPath> / -z <DumpFile> / -c "<commands>" and the semicolon-separated
#   initial command are documented options:
#     https://learn.microsoft.com/en-us/windows-hardware/drivers/debugger/cdb-command-line-options
#   The symbol server syntax srv*<local cache>*https://msdl.microsoft.com/download/symbols:
#     https://learn.microsoft.com/en-us/windows-hardware/drivers/debugger/symbol-path
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** No report was written. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'rootcause'

$Usage = @'
rootcause  -  root-cause report: BSOD bugchecks, disk/NTFS/network errors, SMART, minidumps,
              and OPTIONALLY a bounded cdb !analyze.   Log: C:\Scripts\rootcause.log

USAGE:
  rootcause [-Latest]
  rootcause -Analyze [-AnalyzeTimeoutSec 120] [-SymbolPath <path>] [-DumpPath <dmp>]
  rootcause -Help

THE DEBUGGER IS OFF BY DEFAULT, ON PURPOSE.
  This script is invoked by yc-health.ps1 at every boot and at 03:30. The previous version
  ran cdb with no symbol path and no timeout at boot, as SYSTEM: with a machine-wide
  _NT_SYMBOL_PATH it blocked on a symbol download forever, the health task never finished,
  and the next boot stacked another copy on top. Pass -Analyze only when you are actually
  investigating a crash, and expect it to take up to -AnalyzeTimeoutSec seconds.

PARAMETERS:
  -Latest             Write to the fixed file C:\Scripts\rootcause-latest.txt instead of a
                      timestamped one. (This is what the boot/health task uses.)
  -Analyze            Run cdb !analyze -v on the newest minidump. NOT run without this switch.
  -AnalyzeTimeoutSec  Hard timeout for cdb (default 120). The process is KILLED at that point
                      and the report says so - it never hangs.
  -SymbolPath         Symbol path handed to cdb -y and exported as _NT_SYMBOL_PATH for the
                      child. Default: srv*C:\symbols*https://msdl.microsoft.com/download/symbols
                      Symbol download needs egress to msdl.microsoft.com; on an air-gapped
                      host pass a local store, e.g. -SymbolPath 'C:\symbols'.
  -DumpPath           Analyse this dump file instead of the newest C:\Windows\Minidump\*.dmp.
  -Force              Run even if another instance holds the lock. Use only to break a stuck lock.
  -Help               Show this help and exit.

SINGLE INSTANCE:
  A named mutex (Global\YallaCloud-RootCause) plus C:\Scripts\rootcause.lock. A second run
  exits immediately with code 11 rather than piling up behind the first.

EXAMPLES:
  rootcause
  rootcause -Latest
  rootcause -Analyze
  rootcause -Analyze -SymbolPath C:\symbols -AnalyzeTimeoutSec 300
  rootcause -Help

EXIT CODES:
  0   report written
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  5   not running as Administrator
  11  another instance is already running (this one did nothing)
  12  the report file could not be created
  13  the report was written but the -Analyze cdb pass did not complete

Log: C:\Scripts\rootcause.log   Report: C:\Scripts\rootcause-*.txt
     (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

# ------------------------------------------------------------------------------------
# SINGLE INSTANCE. Nothing below this point can stack.
# The mutex handle is released by the OS when this process dies, however it dies, so a
# killed or crashed run cannot lock the machine out permanently.
# ------------------------------------------------------------------------------------
$LockFile = 'C:\Scripts\rootcause.lock'
$mutex    = $null
$haveLock = $false
try{
  $mutex = New-Object System.Threading.Mutex($false,'Global\YallaCloud-RootCause')
  try{ $haveLock = $mutex.WaitOne(0) }
  catch [System.Threading.AbandonedMutexException] {
    # A previous holder died without releasing. We now own it.
    $haveLock = $true
    Write-YcLog 'the previous rootcause instance died without releasing the lock - taking it over' 'WARN'
  }
}catch{
  Write-YcLog ('could not create the single-instance mutex (' + $_.Exception.Message + ') - falling back to the lock file only') 'WARN'
  $haveLock = -not (Test-Path -LiteralPath $LockFile)
}

if(-not $haveLock){
  $who = ''
  try{ if(Test-Path -LiteralPath $LockFile){ $who = ' (' + ((Get-Content -LiteralPath $LockFile -Raw -ErrorAction SilentlyContinue) -replace '[\r\n]+',' ').Trim() + ')' } }catch{}
  if($Force){
    Write-YcLog ('-Force: another rootcause instance holds the lock' + $who + ' - running anyway. Two debuggers on one dump is exactly what -Force is for breaking, not for routine use.') 'WARN'
  }else{
    Exit-Yc 11 ('another rootcause instance is already running' + $who + ' - this run did nothing. That is deliberate: the old version had no lock, so a stuck boot-time run had the next boot stack another copy on top of it.') 'ERROR'
  }
}
try{
  Set-Content -LiteralPath $LockFile -Value ('pid=' + $PID + ' started=' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' analyze=' + [bool]$Analyze) -Encoding ascii -ErrorAction SilentlyContinue
}catch{}

# ------------------------------------------------------------------------------------
# Report file.
# ------------------------------------------------------------------------------------
$out = 'C:\Scripts\rootcause-latest.txt'
if(-not $Latest){ $out = 'C:\Scripts\rootcause-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt' }
try{
  Set-Content -LiteralPath $out -Value '' -Encoding ascii -ErrorAction Stop
}catch{
  Exit-Yc 12 ('could not create the report file ' + $out + ': ' + $_.Exception.Message) 'ERROR'
}
function W([string]$m){
  try{ Add-Content -LiteralPath $out -Value $m -Encoding ascii -ErrorAction Stop }
  catch{ Write-YcLog ('could not append to the report: ' + $_.Exception.Message) 'WARN' }
}

$stop = @{
  '0x0000007a'='DISK/storage read fault (KERNEL_DATA_INPAGE)'
  '0x00000077'='DISK (KERNEL_STACK_INPAGE)'
  '0x0000007b'='DISK/controller/driver (INACCESSIBLE_BOOT_DEVICE)'
  '0x00000024'='NTFS corruption (NTFS_FILE_SYSTEM)'
  '0x000000f4'='OS/DISK (CRITICAL_OBJECT_TERMINATION)'
  '0x000000ef'='OS (CRITICAL_PROCESS_DIED)'
  '0x000000d1'='DRIVER (DRIVER_IRQL_NOT_LESS_OR_EQUAL)'
  '0x0000000a'='DRIVER (IRQL_NOT_LESS_OR_EQUAL)'
  '0x0000003b'='DRIVER/OS (SYSTEM_SERVICE_EXCEPTION)'
  '0x0000001e'='DRIVER (KMODE_EXCEPTION)'
  '0x00000050'='RAM/DRIVER (PAGE_FAULT_IN_NONPAGED_AREA)'
  '0x00000133'='DRIVER/storage (DPC_WATCHDOG)'
  '0x00000139'='DRIVER (KERNEL_SECURITY_CHECK)'
}

W ('ROOT-CAUSE REPORT  ' + (Get-Date) + '  ' + $env:COMPUTERNAME)
W ('generated by rootcause; debugger ' + $(if($Analyze){'ENABLED (-Analyze)'}else{'DISABLED (pass -Analyze to run cdb)'}))
W ''

# From here on, -ErrorAction SilentlyContinue is used ONLY on the event-log probes, where a
# provider that does not exist on this platform (vioscsi on VMware, netkvm on Hyper-V) is
# an expected absence and not a failure. Nothing load-bearing is silenced.
W '== BSOD bugchecks (System event 1001) =='
$bug = @(Get-WinEvent -FilterHashtable @{LogName='System';Id=1001} -MaxEvents 8 -ErrorAction SilentlyContinue)
if($bug.Count -eq 0){ W '  (none)' }
foreach($e in $bug){
  $c = ([regex]'0x[0-9a-fA-F]{8}').Match($e.Message).Value.ToLowerInvariant()
  $meaning = 'look up this STOP code'
  if($c -and $stop.ContainsKey($c)){ $meaning = $stop[$c] }
  W ('  ' + $e.TimeCreated + '  ' + $c + '  => ' + $meaning)
}

W ''
W '== Disk / storage / NTFS errors (Ntfs, disk, volmgr, vioscsi, viostor, storahci, stornvme) =='
$disk = @(Get-WinEvent -FilterHashtable @{LogName='System';ProviderName='Ntfs','disk','volmgr','vioscsi','viostor','storahci','stornvme'} -MaxEvents 20 -ErrorAction SilentlyContinue)
if($disk.Count -eq 0){ W '  (none)' } else { W (($disk | Format-Table TimeCreated,Id,ProviderName -AutoSize | Out-String)) }

W '== SMART / physical disk health =='
$pd = @(Get-PhysicalDisk -ErrorAction SilentlyContinue)
if($pd.Count -eq 0){ W '  (Get-PhysicalDisk returned nothing on this platform)' }
else{ W (($pd | Format-Table FriendlyName,HealthStatus,OperationalStatus,@{n='GB';e={[int]($_.Size/1GB)}} -AutoSize | Out-String)) }

W '== NTFS dirty bit =='
foreach($v in @(Get-Volume -ErrorAction SilentlyContinue | Where-Object { $_.DriveLetter })){
  $dl = [string]$v.DriveLetter
  $res = ''
  try{ $res = (& fsutil dirty query ($dl + ':') 2>&1 | Out-String).Trim() }
  catch{ $res = 'fsutil failed: ' + $_.Exception.Message }
  W ('  ' + $res)
}

W ''
W '== Network adapter / TCP / DHCP errors =='
$net = @(Get-WinEvent -FilterHashtable @{LogName='System';ProviderName='netkvm','NDIS','Tcpip','Tcpip6','Microsoft-Windows-Dhcp-Client'} -MaxEvents 15 -ErrorAction SilentlyContinue)
if($net.Count -eq 0){ W '  (none)' } else { W (($net | Format-Table TimeCreated,Id,ProviderName -AutoSize | Out-String)) }

W '== Recent System criticals/errors =='
$crit = @(Get-WinEvent -FilterHashtable @{LogName='System';Level=1,2} -MaxEvents 25 -ErrorAction SilentlyContinue)
if($crit.Count -eq 0){ W '  (none)' } else { W (($crit | Format-Table TimeCreated,Id,ProviderName -AutoSize | Out-String)) }

W '== Latest minidumps =='
$dumps = @(Get-ChildItem -Path 'C:\Windows\Minidump\*.dmp' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
if($dumps.Count -eq 0){ W '  (none)' }
else{ W (($dumps | Select-Object -First 5 Name,LastWriteTime | Out-String)) }

# ------------------------------------------------------------------------------------
# THE DEBUGGER. Gated, bounded, and given a symbol path. Never reached without -Analyze.
# ------------------------------------------------------------------------------------
if(-not $Analyze){
  W '== cdb !analyze -v =='
  W '  SKIPPED: the debugger only runs with -Analyze. This is the boot-safe default:'
  W '  cdb with no timeout and no symbol path used to hang this task at every boot.'
  W '  Run "rootcause -Analyze" by hand when investigating a crash.'
  Write-YcLog 'debugger not run (no -Analyze) - this is the boot-safe path'
}else{
  W '== cdb !analyze -v (culprit driver/module) =='
  $cdb = ''
  $cand = @(Get-ChildItem -Path 'C:\Program Files*\Windows Kits\*\Debuggers\x64\cdb.exe' -ErrorAction SilentlyContinue | Sort-Object FullName -Descending)
  if($cand.Count -gt 0){ $cdb = $cand[0].FullName }
  $dmp = ''
  if($DumpPath){
    if(Test-Path -LiteralPath $DumpPath){ $dmp = $DumpPath }
    else{ W ('  -DumpPath not found: ' + $DumpPath); Write-YcLog ('-DumpPath not found: ' + $DumpPath) 'WARN' }
  }elseif($dumps.Count -gt 0){
    $dmp = $dumps[0].FullName
  }

  if(-not $cdb){
    W '  cdb.exe not found (install the Windows SDK/WDK Debugging Tools) - no analysis performed.'
    Write-YcLog 'cdb.exe not found - skipping the analysis' 'WARN'
  }elseif(-not $dmp){
    W '  no crash dump to analyse.'
    Write-YcLog 'no dump file to analyse' 'WARN'
  }else{
    $tmpOut = Join-Path $env:TEMP ('rootcause-cdb-' + [guid]::NewGuid().ToString('N') + '.txt')
    $tmpErr = Join-Path $env:TEMP ('rootcause-cdb-' + [guid]::NewGuid().ToString('N') + '.err')
    # Override any machine-wide _NT_SYMBOL_PATH for the CHILD process. A UNC symbol share
    # in that variable is exactly what used to block cdb forever at boot.
    $prevSym = $env:_NT_SYMBOL_PATH
    $env:_NT_SYMBOL_PATH = $SymbolPath
    # ONE pre-quoted argument string, deliberately. PowerShell 5.1's Start-Process joins an
    # -ArgumentList ARRAY with spaces and does NOT re-quote the elements, so passing
    # @('-c','!analyze -v; q') would reach cdb as four separate arguments and misparse.
    # -c must arrive as a single quoted argument, and -y / -z are quoted in case the symbol
    # path or the dump path contains a space.
    $cdbArgs = '-y "' + $SymbolPath + '" -z "' + $dmp + '" -c "!analyze -v; q"'
    Write-YcLog ('running cdb on ' + $dmp + ' with a ' + $AnalyzeTimeoutSec + 's hard timeout: ' + (Split-Path -Leaf $cdb) + ' ' + $cdbArgs)
    $p = $null
    $script:YcAnalyzeFailed = $false
    try{
      $p = Start-Process -FilePath $cdb `
                         -ArgumentList $cdbArgs `
                         -PassThru -NoNewWindow `
                         -RedirectStandardOutput $tmpOut -RedirectStandardError $tmpErr -ErrorAction Stop
    }catch{
      W ('  could not start cdb: ' + $_.Exception.Message)
      Write-YcLog ('could not start cdb: ' + $_.Exception.Message) 'ERROR'
      $script:YcAnalyzeFailed = $true
    }
    if($p){
      $exited = $false
      try{ $exited = $p.WaitForExit($AnalyzeTimeoutSec * 1000) }catch{ $exited = $false }
      if(-not $exited){
        try{ $p.Kill() }catch{}
        Start-Sleep -Seconds 1
        W ('  cdb TIMED OUT after ' + $AnalyzeTimeoutSec + 's and was killed (symbol download is the usual cause).')
        Write-YcLog ('cdb timed out after ' + $AnalyzeTimeoutSec + 's and was killed') 'WARN'
        $script:YcAnalyzeFailed = $true
      }else{
        # The exit code is COMPARED, not merely printed. Capturing a code and then
        # reporting OK regardless is the exact defect that made a sibling script look
        # healthy through fourteen consecutive failed installs.
        if($p.ExitCode -eq 0){
          Write-YcLog ('cdb exited with ' + $p.ExitCode) 'OK'
        }else{
          W ('  cdb exited with ' + $p.ExitCode + ' - the analysis did not complete.')
          Write-YcLog ('cdb exited with ' + $p.ExitCode + ' - analysis did not complete') 'ERROR'
          $script:YcAnalyzeFailed = $true
        }
      }
      $txt = ''
      try{ $txt = [string](Get-Content -LiteralPath $tmpOut -Raw -ErrorAction SilentlyContinue) }catch{}
      $err = ''
      try{ $err = [string](Get-Content -LiteralPath $tmpErr -Raw -ErrorAction SilentlyContinue) }catch{}
      $hits = @()
      foreach($line in (($txt + "`n" + $err) -split "`r?`n")){
        if($line -match 'BUGCHECK_CODE|BUGCHECK_P\d|MODULE_NAME|IMAGE_NAME|FAILURE_BUCKET_ID|Probably caused by|PROCESS_NAME'){ $hits += $line.Trim() }
      }
      if($hits.Count -gt 0){ foreach($h in $hits){ W ('  ' + $h) } }
      else{
        W '  cdb produced no recognisable !analyze output (symbols unavailable, or the dump is unreadable).'
        Write-YcLog 'cdb produced no recognisable !analyze output - treat this report as EMPTY, not as a clean result' 'WARN'
        $script:YcAnalyzeFailed = $true
      }
      Remove-Item -LiteralPath $tmpOut,$tmpErr -Force -ErrorAction SilentlyContinue
    }
    $env:_NT_SYMBOL_PATH = $prevSym
  }
}

try{ Remove-Item -LiteralPath $LockFile -Force -ErrorAction SilentlyContinue }catch{}

# The report is always written - that is the point of the command - but a run whose
# -Analyze pass did not actually produce an analysis must NOT report OK. Exit 13 says
# "the report exists but the debugger step failed", which is a different thing from
# "there was nothing wrong". Collection-only runs (no -Analyze) are always 0.
if($Analyze -and $script:YcAnalyzeFailed){
  Exit-Yc 13 ('root-cause report written: ' + $out + ' - but the cdb !analyze pass did NOT complete, so the report contains no crash analysis. Re-run with a longer -AnalyzeTimeoutSec, or check symbol access.') 'ERROR'
}
Exit-Yc 0 ('root-cause report written: ' + $out + $(if($Analyze){' (with a bounded cdb !analyze)'}else{' (no debugger - pass -Analyze to run cdb)'})) 'OK'
