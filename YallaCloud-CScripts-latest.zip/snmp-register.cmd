@echo off
rem snmp-register -Community <c> -Managers <ip[,ip]> [-Trap <ip>] [-TrapCommunity <c>]
rem               [-Location <l>] [-Contact <c>] [-SysServices 79] [-NoFirewall] [-Help]
rem
rem -Managers IS NOW MANDATORY and -Community 'public'/'private' is REFUSED. An empty
rem PermittedManagers list means ACCEPT FROM ANY HOST, which is how this used to ship,
rem together with an inbound UDP 161 rule on every profile. The rule is now scoped
rem -RemoteAddress <managers> and is created only after the agent is proven running.
rem
rem The community string is a SECRET: prefer  set YC_SNMP_COMMUNITY=...  over passing it on
rem the command line, where it is visible in the process table and in 4688 events.
rem Windows SNMP is v1/v2c ONLY - no authentication, no encryption. Management network only.
rem Logs to C:\Scripts\snmp-register.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Snmp-Register.ps1" %*
exit /b %ERRORLEVEL%
