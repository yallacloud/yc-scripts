param(
  [string]$Endpoint,
  [string]$Region,
  [string]$Bucket,
  [string]$AccessKey,
  [string]$SecretKey,
  [string]$SecretKeyFile,
  [string]$Prefix,
  [switch]$UsePathStyle,
  [switch]$VirtualHostStyle,
  [switch]$NoSsl,
  [string]$Profile = 'default',
  [switch]$Test,
  [switch]$List,
  [switch]$Remove,
  [switch]$WhatIf,
  [switch]$Help
)
# ================================================================================================
# Set-S3Config.ps1 - YALLACLOUD day-2 command: store and PROVE an S3-compatible endpoint
# configuration for this host, so Transfer-S3 / Backup-Sql / Collect-Logs never have to be handed a
# secret again. PowerShell 5.1 only, ASCII only, Windows Server 2016-2025.
#
# WHAT THIS IS
#   One config file per profile at C:\Scripts\s3\<profile>.json. The access key id, endpoint,
#   region, bucket, prefix and addressing style are plain fields. The SECRET KEY is a DPAPI blob.
#
# WHY DPAPI WITH THE LocalMachine SCOPE, AND WHAT IT DOES NOT PROTECT
#   The consumer of this secret is a SYSTEM scheduled task (backup-sql at 01:15) and an RMM agent -
#   not a human. That rules out every user-scoped mechanism:
#     * ConvertTo-SecureString | ConvertFrom-SecureString (no -Key) is DPAPI CurrentUser. A blob
#       written by an interactive admin CANNOT be read by SYSTEM, and vice versa. This is the single
#       most common way a "secure" credential file silently breaks a scheduled task.
#     * ConvertFrom-SecureString -Key <bytes> only moves the problem: the key has to live somewhere,
#       in the clear, next to the blob.
#     * The SecretManagement / SecretStore modules are not present on a golden image, need a vault
#       password or a user profile, and are not installable air-gapped.
#   System.Security.Cryptography.ProtectedData with DataProtectionScope.LocalMachine encrypts under
#   the MACHINE key, so every principal on this host - SYSTEM, Administrators, a scheduled task -
#   can decrypt it, and no other machine can. That is exactly the trust boundary we want, and it is
#   documented behaviour of the API (System.Security.dll, .NET Framework 4.7.2+ / Server 2016+).
#   LIMITATION, STATED PLAINLY: any local administrator on this box can decrypt this file with three
#   lines of PowerShell, because they can run as SYSTEM. LocalMachine DPAPI protects the secret
#   against FILE EXFILTRATION - a copied C:\Scripts folder, a stolen VHD, a Proxmox Backup Server
#   image restored elsewhere, a backup of C:\ - not against a local administrator. If you need
#   protection from a local admin, the answer is a short-lived credential from an external broker,
#   not a file on this disk. The directory ACL (SYSTEM + Administrators only, inheritance broken) is
#   what stops a non-admin from reading the blob in the first place.
#   The optional entropy below is a CONSTANT IN THIS SCRIPT. It is NOT a secret and adds no strength
#   against anyone holding this file; it only binds the blob to this tool so an unrelated DPAPI
#   consumer cannot decrypt it by accident.
#
# WHY -SecretKey ON THE COMMAND LINE IS A WARNING, NOT A CONVENIENCE
#   An argument to powershell.exe is visible in the process table to every local account for the
#   life of the process, is captured verbatim in Security event 4688 (Process Creation) when command
#   line auditing is on, and is written into the PowerShell transcript header. _yc-lib.ps1 v2 masks
#   it in the transcript afterwards, but it cannot un-log a 4688. -SecretKeyFile and the interactive
#   prompt are the documented paths; -SecretKey works and warns loudly.
#
# WHY THIS ESTATE NEEDS -Endpoint / -UsePathStyle / an arbitrary -Region
#   The targets are Wasabi, Ceph RGW, MinIO-alikes and Backblaze B2's S3 API - not AWS. Those need a
#   custom endpoint host; many of them only support PATH-style addressing (https://host/bucket/key)
#   because their TLS certificate does not cover <bucket>.host; and their region string is often
#   arbitrary but still forms part of the SigV4 credential scope, so it has to match the server's
#   expectation exactly or every request fails 403 SignatureDoesNotMatch. All three are stored here
#   and all three are exercised by -Test.
#
# WHY -Test DOES A REAL REQUEST
#   "Configuration saved" proves nothing. -Test performs a real, minimal, signed S3 request against
#   the configured endpoint (HEAD <bucket>, then GET ?list-type=2&max-keys=1) and reports the actual
#   HTTP status line plus the diagnostic headers the S3-compatible servers return, so a wrong region,
#   a wrong addressing style, a clock skew or a bad key are each distinguishable.
#
# WHY THIS SCRIPT CARRIES ITS OWN SIGNER
#   Set-S3Config is the BOOTSTRAP command: it must be able to validate a brand new endpoint on a host
#   where no AWS module is installed and where Transfer-S3.ps1 may not have been deployed yet. It
#   therefore contains a deliberately minimal SigV4 signer for no-body GET/HEAD only. Transfer-S3.ps1
#   owns the full engine (PUT, multipart, retries). The duplication is ~50 lines and is intentional.
# ================================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'set-s3config'
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$script:S3Dir      = 'C:\Scripts\s3'
$script:S3Entropy  = [Text.Encoding]::UTF8.GetBytes('YallaCloud-s3-config-v1')
$script:SchemaVer  = 1

trap {
  Write-YcLog ('UNHANDLED ERROR at line ' + $_.InvocationInfo.ScriptLineNumber + ': ' + $_.Exception.Message) 'ERROR'
  if ($_.ScriptStackTrace) { Write-YcLog ('Stack: ' + ($_.ScriptStackTrace -replace "`r?`n", ' | ')) 'ERROR' }
  Exit-Yc 99 'set-s3config aborted on an unhandled error.' 'ERROR'
}

if ($Help) {
@"
set-s3config  -  store and PROVE an S3-compatible endpoint configuration for this host, so that
                 transfer-s3, backup-sql and collect-logs never need the secret key again.
                 Wasabi / Ceph RGW / MinIO-alikes / Backblaze B2 S3 / AWS S3.

USAGE:
  set-s3config -Endpoint <url> -Region <r> -Bucket <b> -AccessKey <id> -SecretKeyFile <path>
  set-s3config -Endpoint <url> -Region <r> -Bucket <b> -AccessKey <id>          (prompts for the secret)
  set-s3config -Profile archive -Bucket other-bucket                            (update one field)
  set-s3config -Test [-Profile <name>]
  set-s3config -List
  set-s3config -Remove -Profile <name> [-WhatIf]
  set-s3config -Help

PARAMETERS:
  -Endpoint          Endpoint URL or bare host. https is assumed when no scheme is given.
                     Examples: https://s3.eu-central-1.wasabisys.com, https://rgw.dc1.yalla.local,
                     http://minio.lan:9000, https://s3.us-west-004.backblazeb2.com
  -Region            Region string used in the SigV4 credential scope. It does NOT have to be an AWS
                     region, but it MUST match what the server expects or every request returns 403
                     SignatureDoesNotMatch. Default us-east-1 (what most MinIO-alikes accept).
  -Bucket            Bucket name. Required for a new profile.
  -AccessKey         Access key id. Not a secret, but still stored in an ACL-hardened directory.
  -SecretKey         Secret access key. INSECURE ON A COMMAND LINE: it is visible in the process
                     table to every local account, is recorded verbatim in Security event 4688 when
                     command line auditing is on, and lands in the transcript header. Prefer
                     -SecretKeyFile or the prompt. Using it logs a WARNING.
  -SecretKeyFile     Path to a file whose first non-empty line is the secret key. PREFERRED. The file
                     is read and left alone - ACL it and delete it yourself when done.
  -Prefix            Default key prefix for this profile, e.g. sql/PRODSQL01. Optional.
  -UsePathStyle      Force PATH-style addressing (https://host/bucket/key). Default for a NEW profile,
                     because most S3-compatible endpoints have no wildcard certificate for
                     bucket.host. On an existing profile the stored value is kept unless changed.
  -VirtualHostStyle  Force VIRTUAL-HOST style (https://bucket.host/key). Use for AWS S3 proper.
  -NoSsl             Use http instead of https. Only meaningful when -Endpoint has no scheme; an
                     explicit https:// endpoint combined with -NoSsl is refused as contradictory.
                     Plain http sends the SigV4 signature and the payload unencrypted - use only on a
                     trusted storage VLAN.
  -Profile           Profile name. Default 'default'. One JSON file per profile.
  -Test              Perform a REAL signed request against the endpoint and report the HTTP status.
  -List              List the profiles on this host and whether each secret still decrypts here.
  -Remove            Delete a profile. Honours -WhatIf.
  -WhatIf            Show what would change and change nothing.
  -Help              Show this help and exit.

BEHAVIOUR:
  - Idempotent and incremental. Re-running with a subset of parameters UPDATES those fields on an
    existing profile and leaves the rest, including the stored secret, untouched.
  - C:\Scripts\s3 is created with inheritance broken and Full access for SYSTEM and Administrators
    only, and the resulting ACL is READ BACK and verified, not assumed.
  - The secret key is encrypted with DPAPI, DataProtectionScope.LocalMachine, so a SYSTEM scheduled
    task can read it and no other machine can. Any local administrator on THIS host can decrypt it -
    this protects against a stolen file or image, not against a local admin.
  - Nothing is ever written to the log, the console or the event log that contains the secret.
  - Saving a new or changed configuration automatically runs the same live -Test and the command
    exits non-zero if the endpoint does not answer.

EXAMPLES:
  set-s3config -Endpoint https://s3.eu-central-1.wasabisys.com -Region eu-central-1 -Bucket yc-backups -AccessKey AK123 -SecretKeyFile C:\Scripts\s3key.txt
  set-s3config -Endpoint https://rgw.dc1.yalla.local -Region dc1 -Bucket sqlbackups -AccessKey AK123 -UsePathStyle
  set-s3config -Endpoint https://s3.amazonaws.com -Region eu-west-1 -Bucket yc-prod -AccessKey AK123 -VirtualHostStyle
  set-s3config -Profile archive -Endpoint http://minio.lan:9000 -Region us-east-1 -Bucket archive -AccessKey AK9 -NoSsl
  set-s3config -Test -Profile archive
  set-s3config -List
  set-s3config -Remove -Profile archive -WhatIf

EXIT CODES:
   0  Success - configuration written and the live endpoint test passed, or -List / -Help.
   1  Generic failure.
   2  Invalid or missing arguments (no bucket for a new profile, contradictory switches, bad URL).
   3  The requested profile does not exist, or its file is unreadable / not valid JSON.
   4  The config directory or its ACL could not be created or verified.
   5  Not running as Administrator (from _yc-lib.ps1).
   6  The stored secret could not be decrypted on this machine (DPAPI blob from another host).
   7  The endpoint answered, but authentication or authorization FAILED (HTTP 401/403).
   8  The endpoint could not be reached at all (DNS, TLS, connection, timeout).
  10  The endpoint answered but the test FAILED for another reason (404 no such bucket, 301/400
      wrong region, 5xx). The actual status code is in the log.
  99  Unhandled terminating error.

Log: C:\Scripts\set-s3config.log   (mirrored to the Application event log, source YallaCloud)
Config: C:\Scripts\s3\<profile>.json
"@ | Write-Host -ForegroundColor Cyan
  Exit-Yc 0
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation -BoundParameters $PSBoundParameters

$profileName = $Profile
if (-not $profileName) { $profileName = 'default' }
if ($profileName -notmatch '^[A-Za-z0-9._-]{1,64}$') {
  Exit-Yc 2 ('-Profile "' + $profileName + '" is not a valid profile name. Use 1-64 characters from A-Z a-z 0-9 . _ - (it becomes a file name).') 'ERROR'
}

# ------------------------------------------------------------------------------------------------
# Config directory, hardened and VERIFIED
# ------------------------------------------------------------------------------------------------
$script:AllowedSids = @('S-1-5-18','S-1-5-32-544','S-1-3-0','S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464')

function Assert-YcS3Dir {
  if (-not (Test-Path -LiteralPath $script:S3Dir)) {
    New-Item -ItemType Directory -Path $script:S3Dir -Force | Out-Null
    Write-YcLog ('Created ' + $script:S3Dir + '.')
  }
  $out = & icacls.exe $script:S3Dir /inheritance:r /grant 'NT AUTHORITY\SYSTEM:(OI)(CI)F' 'BUILTIN\Administrators:(OI)(CI)F' 2>&1
  if ($LASTEXITCODE -ne 0) {
    $out = & icacls.exe $script:S3Dir /inheritance:r /grant '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' 2>&1
  }
  if ($LASTEXITCODE -ne 0) {
    Write-YcLog ('icacls FAILED hardening ' + $script:S3Dir + ' (exit ' + $LASTEXITCODE + '): ' + (($out | ForEach-Object { [string]$_ }) -join ' ')) 'ERROR'
    Exit-Yc 4 ('Could not harden the ACL on ' + $script:S3Dir + ' - refusing to store a secret in a directory whose permissions are unknown.') 'ERROR'
  }
  # Read the ACL back. "icacls returned 0" is not proof that the directory is safe.
  $loose = @()
  $acl = Get-Acl -Path $script:S3Dir
  foreach ($ace in $acl.Access) {
    $sid = ''
    try { $sid = $ace.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value } catch { $sid = [string]$ace.IdentityReference }
    if ($script:AllowedSids -notcontains $sid) { $loose += ([string]$ace.IdentityReference) }
  }
  if ($acl.AreAccessRulesProtected -ne $true) { $loose += 'inheritance still enabled' }
  if ($loose.Count -gt 0) {
    Exit-Yc 4 ('ACL VERIFICATION FAILED on ' + $script:S3Dir + ' - still accessible to: ' + ($loose -join ', ') + '. Refusing to store a secret there.') 'ERROR'
  }
  Write-YcLog ('Verified: ' + $script:S3Dir + ' grants SYSTEM + Administrators only, inheritance broken.') 'OK'
}

# ------------------------------------------------------------------------------------------------
# DPAPI (LocalMachine)
# ------------------------------------------------------------------------------------------------
Add-Type -AssemblyName System.Security

function Protect-YcS3Key {
  param([string]$Plain)
  $bytes = [Text.Encoding]::UTF8.GetBytes($Plain)
  try {
    $blob = [System.Security.Cryptography.ProtectedData]::Protect($bytes, $script:S3Entropy, [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
    return [Convert]::ToBase64String($blob)
  } finally {
    for ($i = 0; $i -lt $bytes.Length; $i++) { $bytes[$i] = 0 }
  }
}

# Returns the plaintext secret, or $null when the blob was produced on a different machine.
function Unprotect-YcS3Key {
  param([string]$B64)
  if (-not $B64) { return $null }
  try {
    $blob  = [Convert]::FromBase64String($B64)
    $bytes = [System.Security.Cryptography.ProtectedData]::Unprotect($blob, $script:S3Entropy, [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
    $s = [Text.Encoding]::UTF8.GetString($bytes)
    for ($i = 0; $i -lt $bytes.Length; $i++) { $bytes[$i] = 0 }
    return $s
  } catch {
    Write-YcLog ('DPAPI could not decrypt the stored secret: ' + $_.Exception.Message + '. A LocalMachine blob is bound to the machine that created it - re-run set-s3config on THIS host to store the key again.') 'ERROR'
    return $null
  }
}

# ------------------------------------------------------------------------------------------------
# Profile file I/O
# ------------------------------------------------------------------------------------------------
function Get-YcS3Path { param([string]$Name) return (Join-Path $script:S3Dir ($Name + '.json')) }

function Read-YcS3Profile {
  param([string]$Name,[switch]$MustExist)
  $p = Get-YcS3Path $Name
  if (-not (Test-Path -LiteralPath $p)) {
    if ($MustExist) { Exit-Yc 3 ('Profile "' + $Name + '" does not exist (' + $p + '). Run: set-s3config -Endpoint ... -Bucket ... -AccessKey ...') 'ERROR' }
    return $null
  }
  $raw = Get-Content -LiteralPath $p -Raw
  $o = $null
  try { $o = $raw | ConvertFrom-Json } catch {
    Exit-Yc 3 ($p + ' is not valid JSON: ' + $_.Exception.Message + '. Delete it and re-create the profile.') 'ERROR'
  }
  return $o
}

function Write-YcS3Profile {
  param($Data,[string]$Name)
  $p = Get-YcS3Path $Name
  $json = ($Data | ConvertTo-Json -Depth 4)
  if ($WhatIf) {
    Write-YcLog ('-WhatIf: would write ' + $p + ' (endpoint ' + $Data['Endpoint'] + ', bucket ' + $Data['Bucket'] + ', region ' + $Data['Region'] + ', pathstyle ' + $Data['UsePathStyle'] + ') - the secret would be re-encrypted with DPAPI LocalMachine.') 'WARN'
    return $false
  }
  $tmp = $p + '.new'
  Set-Content -LiteralPath $tmp -Value $json -Encoding Ascii -Force
  Move-Item -LiteralPath $tmp -Destination $p -Force
  $out = & icacls.exe $p /inheritance:r /grant 'NT AUTHORITY\SYSTEM:F' 'BUILTIN\Administrators:F' 2>&1
  if ($LASTEXITCODE -ne 0) {
    $out = & icacls.exe $p /inheritance:r /grant '*S-1-5-18:F' '*S-1-5-32-544:F' 2>&1
  }
  if ($LASTEXITCODE -ne 0) {
    Write-YcLog ('Could not harden the ACL on ' + $p + ': ' + (($out | ForEach-Object { [string]$_ }) -join ' ')) 'ERROR'
    Exit-Yc 4 'The profile file was written but its ACL could not be set - delete it and investigate.' 'ERROR'
  }
  $len = (Get-Item -LiteralPath $p).Length
  Write-YcLog ('Wrote ' + $p + ' (' + $len + ' bytes, SYSTEM + Administrators only).') 'OK'
  return $true
}

# ------------------------------------------------------------------------------------------------
# Endpoint parsing
# ------------------------------------------------------------------------------------------------
function Resolve-YcEndpoint {
  param([string]$Raw,[bool]$WantNoSsl)
  $t = $Raw.Trim()
  $hasScheme = ($t -match '^(?i)https?://')
  if ($hasScheme -and $WantNoSsl -and ($t -match '^(?i)https://')) {
    Exit-Yc 2 ('-Endpoint is https:// but -NoSsl was also given. Those contradict each other - drop -NoSsl, or give the endpoint as a bare host.') 'ERROR'
  }
  if (-not $hasScheme) {
    if ($WantNoSsl) { $t = 'http://' + $t } else { $t = 'https://' + $t }
  }
  $u = $null
  try { $u = [Uri]$t } catch { $u = $null }
  if (-not $u -or -not $u.Host) {
    Exit-Yc 2 ('-Endpoint "' + $Raw + '" could not be parsed as a URL or host name.') 'ERROR'
  }
  if ($u.AbsolutePath -and $u.AbsolutePath -ne '/') {
    Exit-Yc 2 ('-Endpoint "' + $Raw + '" contains a path (' + $u.AbsolutePath + '). The endpoint is the SERVICE address only - the bucket goes in -Bucket and the key prefix in -Prefix.') 'ERROR'
  }
  $port = ''
  if (-not $u.IsDefaultPort) { $port = ':' + $u.Port }
  return ($u.Scheme + '://' + $u.Host + $port)
}

# ------------------------------------------------------------------------------------------------
# Minimal SigV4 signer - no-body GET / HEAD only. See the header for why this is duplicated here.
# ------------------------------------------------------------------------------------------------
function ConvertTo-YcUriEncoded {
  param([string]$Value,[switch]$KeepSlash)
  $sb = New-Object System.Text.StringBuilder
  foreach ($b in [Text.Encoding]::UTF8.GetBytes($Value)) {
    if ( ($b -ge 65 -and $b -le 90) -or ($b -ge 97 -and $b -le 122) -or ($b -ge 48 -and $b -le 57) -or
         $b -eq 45 -or $b -eq 46 -or $b -eq 95 -or $b -eq 126 ) {
      [void]$sb.Append([char]$b)
    } elseif ($KeepSlash -and $b -eq 47) {
      [void]$sb.Append('/')
    } else {
      [void]$sb.AppendFormat('%{0:X2}', $b)
    }
  }
  return $sb.ToString()
}

function Get-YcSha256Hex {
  param([byte[]]$Bytes)
  $sha = New-Object System.Security.Cryptography.SHA256Managed
  try {
    $h = $sha.ComputeHash($Bytes)
    return (($h | ForEach-Object { $_.ToString('x2') }) -join '')
  } finally { $sha.Dispose() }
}

function Get-YcHmacSha256 {
  param([byte[]]$KeyBytes,[string]$Data)
  $h = New-Object System.Security.Cryptography.HMACSHA256
  try {
    $h.Key = $KeyBytes
    return $h.ComputeHash([Text.Encoding]::UTF8.GetBytes($Data))
  } finally { $h.Dispose() }
}

# Performs one signed GET/HEAD and returns an object. Never logs or returns the Authorization value.
function Invoke-YcS3Simple {
  param([hashtable]$C,[string]$Method,[string]$Key,[hashtable]$Query,[int]$TimeoutSec = 30)
  Set-YcTls
  $ep = [Uri]$C['Endpoint']
  $epHost = $ep.Host
  $path   = '/'
  if ($C['UsePathStyle']) {
    $path = '/' + $C['Bucket']
    if ($Key) { $path = $path + '/' + $Key }
  } else {
    $epHost = $C['Bucket'] + '.' + $ep.Host
    if ($Key) { $path = '/' + $Key }
  }
  $hostHeader = $epHost
  if (-not $ep.IsDefaultPort) { $hostHeader = $epHost + ':' + $ep.Port }

  $canonUri = ConvertTo-YcUriEncoded -Value $path -KeepSlash
  $qparts = @()
  if ($Query) {
    foreach ($k in ($Query.Keys | Sort-Object -CaseSensitive)) {
      $qparts += ((ConvertTo-YcUriEncoded -Value ([string]$k)) + '=' + (ConvertTo-YcUriEncoded -Value ([string]$Query[$k])))
    }
  }
  $canonQuery = ($qparts -join '&')

  $amzDate   = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
  $dateStamp = $amzDate.Substring(0, 8)
  $payloadHash = Get-YcSha256Hex -Bytes (New-Object byte[] 0)   # every request here has an empty body

  $canonHeaders = 'host:' + $hostHeader + "`n" + 'x-amz-content-sha256:' + $payloadHash + "`n" + 'x-amz-date:' + $amzDate + "`n"
  $signedHeaders = 'host;x-amz-content-sha256;x-amz-date'
  $canonRequest = $Method + "`n" + $canonUri + "`n" + $canonQuery + "`n" + $canonHeaders + "`n" + $signedHeaders + "`n" + $payloadHash
  $scope = $dateStamp + '/' + $C['Region'] + '/s3/aws4_request'
  $stringToSign = 'AWS4-HMAC-SHA256' + "`n" + $amzDate + "`n" + $scope + "`n" + (Get-YcSha256Hex -Bytes ([Text.Encoding]::UTF8.GetBytes($canonRequest)))

  $kSecret = [Text.Encoding]::UTF8.GetBytes('AWS4' + $C['SecretKey'])
  $kDate    = Get-YcHmacSha256 -KeyBytes $kSecret -Data $dateStamp
  $kRegion  = Get-YcHmacSha256 -KeyBytes $kDate   -Data $C['Region']
  $kService = Get-YcHmacSha256 -KeyBytes $kRegion -Data 's3'
  $kSigning = Get-YcHmacSha256 -KeyBytes $kService -Data 'aws4_request'
  $sigBytes = Get-YcHmacSha256 -KeyBytes $kSigning -Data $stringToSign
  $signature = (($sigBytes | ForEach-Object { $_.ToString('x2') }) -join '')
  for ($i = 0; $i -lt $kSecret.Length; $i++) { $kSecret[$i] = 0 }

  $url = $ep.Scheme + '://' + $hostHeader + $canonUri
  if ($canonQuery) { $url = $url + '?' + $canonQuery }

  $res = [pscustomobject]@{ StatusCode = 0; StatusText = ''; Headers = @{}; Body = ''; Url = $url; Error = '' }
  $req = $null
  try {
    $req = [System.Net.HttpWebRequest][System.Net.WebRequest]::Create($url)
  } catch {
    $res.Error = 'could not create the request for ' + $url + ': ' + $_.Exception.Message
    return $res
  }
  $req.Method            = $Method
  $req.Timeout           = $TimeoutSec * 1000
  $req.ReadWriteTimeout  = $TimeoutSec * 1000
  $req.UserAgent         = 'YallaCloud-set-s3config'
  $req.AllowAutoRedirect = $false
  $req.Headers.Add('x-amz-date', $amzDate)
  $req.Headers.Add('x-amz-content-sha256', $payloadHash)
  $req.Headers.Add('Authorization', ('AWS4-HMAC-SHA256 Credential=' + $C['AccessKey'] + '/' + $scope + ',SignedHeaders=' + $signedHeaders + ',Signature=' + $signature))

  $resp = $null
  try {
    $resp = $req.GetResponse()
  } catch [System.Net.WebException] {
    $we = $_.Exception
    if ($we.Response) { $resp = $we.Response } else { $res.Error = $we.Message; return $res }
  } catch {
    $res.Error = $_.Exception.Message
    return $res
  }
  try {
    $hr = [System.Net.HttpWebResponse]$resp
    $res.StatusCode = [int]$hr.StatusCode
    $res.StatusText = [string]$hr.StatusDescription
    foreach ($hk in $hr.Headers.AllKeys) { $res.Headers[$hk.ToLowerInvariant()] = $hr.Headers[$hk] }
    if ($Method -ne 'HEAD') {
      $sr = New-Object System.IO.StreamReader($hr.GetResponseStream())
      try { $res.Body = $sr.ReadToEnd() } finally { $sr.Close() }
    }
  } finally {
    if ($resp) { $resp.Close() }
  }
  return $res
}

function Write-YcS3Diag {
  param([pscustomobject]$R,[string]$What)
  $extra = @()
  foreach ($h in @('x-amz-request-id','x-amz-id-2','x-amz-bucket-region','server','date')) {
    if ($R.Headers.ContainsKey($h)) { $extra += ($h + '=' + $R.Headers[$h]) }
  }
  Write-YcLog ($What + ': HTTP ' + $R.StatusCode + ' ' + $R.StatusText + $(if ($extra.Count -gt 0) { '  [' + ($extra -join '; ') + ']' } else { '' }))
}

# Runs the live proof. Returns 0 on success or the exit code to use.
function Test-YcS3Config {
  param([hashtable]$C)
  Write-YcLog ('Testing ' + $C['Endpoint'] + ' bucket "' + $C['Bucket'] + '" region "' + $C['Region'] + '" ' +
               $(if ($C['UsePathStyle']) { 'path-style' } else { 'virtual-host style' }) + ' with access key ' + (Protect-YcSecret $C['AccessKey'] -Whole -Keep 4) + '...')

  $head = Invoke-YcS3Simple -C $C -Method 'HEAD' -Key '' -Query $null
  if ($head.Error) {
    Write-YcLog ('The endpoint could not be reached: ' + $head.Error) 'ERROR'
    Write-YcLog 'Check DNS for the endpoint host, egress to its port, and the TLS chain (a private Ceph RGW usually needs its CA in the Windows trust store).' 'ERROR'
    return 8
  }
  Write-YcS3Diag -R $head -What ('HEAD ' + $C['Bucket'])

  if ($head.StatusCode -eq 401 -or $head.StatusCode -eq 403) {
    $hint = 'the access key or secret key is wrong, the key has no permission on this bucket, the region in the credential scope does not match the server, or this host clock is more than 15 minutes off UTC.'
    if ($head.Headers.ContainsKey('x-amz-bucket-region')) { $hint = 'the server says this bucket lives in region "' + $head.Headers['x-amz-bucket-region'] + '" - re-run with -Region ' + $head.Headers['x-amz-bucket-region'] + '.' }
    Write-YcLog ('AUTHENTICATION/AUTHORIZATION FAILED (HTTP ' + $head.StatusCode + '): ' + $hint) 'ERROR'
    Write-YcLog ('This host clock reads ' + ((Get-Date).ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss')) + ' UTC.') 'INFO'
    return 7
  }
  if ($head.StatusCode -eq 404) {
    Write-YcLog ('The endpoint answered but bucket "' + $C['Bucket'] + '" DOES NOT EXIST (HTTP 404). Create it, or fix -Bucket.') 'ERROR'
    return 10
  }
  if ($head.StatusCode -eq 301 -or $head.StatusCode -eq 307 -or $head.StatusCode -eq 400) {
    $r = ''
    if ($head.Headers.ContainsKey('x-amz-bucket-region')) { $r = ' The server reports the correct region as "' + $head.Headers['x-amz-bucket-region'] + '".' }
    Write-YcLog ('HTTP ' + $head.StatusCode + ' - this is normally the WRONG REGION or the wrong addressing style.' + $r +
                 ' Try the other addressing style (-UsePathStyle / -VirtualHostStyle).') 'ERROR'
    return 10
  }
  if ($head.StatusCode -lt 200 -or $head.StatusCode -ge 300) {
    Write-YcLog ('HEAD on the bucket returned HTTP ' + $head.StatusCode + ' ' + $head.StatusText + ' - the configuration is NOT usable.') 'ERROR'
    return 10
  }
  Write-YcLog ('PROVED: HEAD ' + $C['Bucket'] + ' returned HTTP ' + $head.StatusCode + ' - the endpoint, credentials, region and addressing style are all correct.') 'OK'

  # Second, independent proof: a real ListObjectsV2 that also exercises the prefix.
  $q = @{ 'list-type' = '2'; 'max-keys' = '1' }
  if ($C['Prefix']) { $q['prefix'] = $C['Prefix'] }
  $lst = Invoke-YcS3Simple -C $C -Method 'GET' -Key '' -Query $q
  if ($lst.Error) {
    Write-YcLog ('The list call failed after a successful HEAD: ' + $lst.Error) 'ERROR'
    return 8
  }
  Write-YcS3Diag -R $lst -What 'GET ?list-type=2&max-keys=1'
  if ($lst.StatusCode -ne 200) {
    Write-YcLog ('The key can reach the bucket but CANNOT LIST it (HTTP ' + $lst.StatusCode + '). transfer-s3 -List and the upload proof both need s3:ListBucket on this bucket.') 'ERROR'
    return 10
  }
  $keyCount = 'unknown'
  try {
    $x = [xml]$lst.Body
    if ($x.ListBucketResult -and $null -ne $x.ListBucketResult.KeyCount) { $keyCount = [string]$x.ListBucketResult.KeyCount }
  } catch { $keyCount = 'unparseable response body' }
  Write-YcLog ('PROVED: ListObjectsV2 returned HTTP 200, KeyCount=' + $keyCount + ' for prefix "' + $(if ($C['Prefix']) { $C['Prefix'] } else { '(none)' }) + '".') 'OK'
  return 0
}

# ------------------------------------------------------------------------------------------------
# -List
# ------------------------------------------------------------------------------------------------
if ($List) {
  if (-not (Test-Path -LiteralPath $script:S3Dir)) {
    Write-YcLog ('No S3 profiles on this host: ' + $script:S3Dir + ' does not exist. Create one with: set-s3config -Endpoint ... -Bucket ... -AccessKey ...') 'WARN'
    Exit-Yc 0
  }
  $files = @(Get-ChildItem -LiteralPath $script:S3Dir -Filter '*.json' -File | Sort-Object Name)
  if ($files.Count -eq 0) {
    Write-YcLog ('No S3 profiles on this host (' + $script:S3Dir + ' is empty).') 'WARN'
    Exit-Yc 0
  }
  Write-Host ''
  Write-Host ('  {0,-14} {1,-42} {2,-20} {3,-14} {4,-10} {5}' -f 'PROFILE','ENDPOINT','BUCKET','REGION','STYLE','SECRET')
  Write-Host ('  ' + ('-' * 118))
  foreach ($f in $files) {
    $o = $null
    try { $o = (Get-Content -LiteralPath $f.FullName -Raw) | ConvertFrom-Json } catch { $o = $null }
    if (-not $o) {
      Write-Host ('  {0,-14} {1}' -f $f.BaseName, '*** unreadable / not valid JSON ***')
      continue
    }
    $sec = 'MISSING'
    if ($o.SecretKeyDpapi) {
      $plain = $null
      try {
        $blob = [Convert]::FromBase64String($o.SecretKeyDpapi)
        $b = [System.Security.Cryptography.ProtectedData]::Unprotect($blob, $script:S3Entropy, [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
        for ($i = 0; $i -lt $b.Length; $i++) { $b[$i] = 0 }
        $plain = 'ok'
      } catch { $plain = $null }
      if ($plain) { $sec = 'decrypts OK' } else { $sec = 'WILL NOT DECRYPT HERE' }
    }
    $style = 'virtual'
    if ($o.UsePathStyle) { $style = 'path' }
    Write-Host ('  {0,-14} {1,-42} {2,-20} {3,-14} {4,-10} {5}' -f $f.BaseName, ([string]$o.Endpoint), ([string]$o.Bucket), ([string]$o.Region), $style, $sec)
    if ($o.Prefix) { Write-Host ('  {0,-14} prefix: {1}' -f '', ([string]$o.Prefix)) }
  }
  Write-Host ''
  Write-YcLog ($files.Count.ToString() + ' profile(s) listed. No secret value was printed.') 'OK'
  Exit-Yc 0
}

# ------------------------------------------------------------------------------------------------
# -Remove
# ------------------------------------------------------------------------------------------------
if ($Remove) {
  $p = Get-YcS3Path $profileName
  if (-not (Test-Path -LiteralPath $p)) {
    Exit-Yc 3 ('Profile "' + $profileName + '" does not exist - nothing to remove (' + $p + ').') 'ERROR'
  }
  if ($WhatIf) {
    Write-YcLog ('-WhatIf: would delete ' + $p + '. Nothing was changed.') 'WARN'
    Exit-Yc 0
  }
  Remove-Item -LiteralPath $p -Force
  if (Test-Path -LiteralPath $p) {
    Exit-Yc 1 ('Remove-Item returned but ' + $p + ' still exists.') 'ERROR'
  }
  Exit-Yc 0 ('Deleted profile "' + $profileName + '" (' + $p + '). Verified: the file is gone.') 'OK'
}

# ------------------------------------------------------------------------------------------------
# -Test only (no configuration change)
# ------------------------------------------------------------------------------------------------
$existing = Read-YcS3Profile -Name $profileName
$noChangeRequested = -not ($Endpoint -or $Region -or $Bucket -or $AccessKey -or $SecretKey -or $SecretKeyFile -or $Prefix -or $UsePathStyle -or $VirtualHostStyle -or $NoSsl)

if ($Test -and $noChangeRequested) {
  if (-not $existing) {
    Exit-Yc 3 ('Profile "' + $profileName + '" does not exist, so there is nothing to test. Create it first.') 'ERROR'
  }
  $secret = Unprotect-YcS3Key -B64 ([string]$existing.SecretKeyDpapi)
  if (-not $secret) { Exit-Yc 6 ('The stored secret for profile "' + $profileName + '" cannot be decrypted on this machine.') 'ERROR' }
  $cfg = @{
    Endpoint = [string]$existing.Endpoint; Region = [string]$existing.Region; Bucket = [string]$existing.Bucket
    Prefix = [string]$existing.Prefix; AccessKey = [string]$existing.AccessKey; SecretKey = $secret
    UsePathStyle = [bool]$existing.UsePathStyle
  }
  $rc = Test-YcS3Config -C $cfg
  $cfg['SecretKey'] = $null
  if ($rc -eq 0) { Exit-Yc 0 ('Profile "' + $profileName + '" is PROVEN working against ' + $cfg['Endpoint'] + '.') 'OK' }
  Exit-Yc $rc ('Profile "' + $profileName + '" FAILED its live endpoint test.') 'ERROR'
}

# ------------------------------------------------------------------------------------------------
# Create / update
# ------------------------------------------------------------------------------------------------
if ($noChangeRequested) {
  Exit-Yc 2 ('Nothing to do. Supply at least -Endpoint / -Bucket / -AccessKey to create or update profile "' + $profileName + '", or use -Test, -List, -Remove, -Help.') 'ERROR'
}

if ($UsePathStyle -and $VirtualHostStyle) {
  Exit-Yc 2 '-UsePathStyle and -VirtualHostStyle contradict each other. Pick one.' 'ERROR'
}

Assert-YcS3Dir

# Start from the existing profile so an update never silently drops a field.
$newEndpoint = ''
$newRegion   = 'us-east-1'
$newBucket   = ''
$newPrefix   = ''
$newAccess   = ''
$newBlob     = ''
$newPath     = $true
if ($existing) {
  $newEndpoint = [string]$existing.Endpoint
  if ($existing.Region) { $newRegion = [string]$existing.Region }
  $newBucket   = [string]$existing.Bucket
  $newPrefix   = [string]$existing.Prefix
  $newAccess   = [string]$existing.AccessKey
  $newBlob     = [string]$existing.SecretKeyDpapi
  $newPath     = [bool]$existing.UsePathStyle
  Write-YcLog ('Updating the existing profile "' + $profileName + '" - fields you did not supply keep their current value.')
} else {
  Write-YcLog ('Creating a new profile "' + $profileName + '".')
}

if ($Endpoint) { $newEndpoint = Resolve-YcEndpoint -Raw $Endpoint -WantNoSsl ([bool]$NoSsl) }
if ($Region)   { $newRegion   = $Region.Trim() }
if ($Bucket)   { $newBucket   = $Bucket.Trim() }
if ($PSBoundParameters.ContainsKey('Prefix')) { $newPrefix = $Prefix.Trim().TrimStart('/') }
if ($AccessKey){ $newAccess   = $AccessKey.Trim() }
if ($UsePathStyle)     { $newPath = $true }
if ($VirtualHostStyle) { $newPath = $false }

if (-not $newEndpoint) { Exit-Yc 2 '-Endpoint is required for a new profile.' 'ERROR' }
if (-not $newBucket)   { Exit-Yc 2 '-Bucket is required for a new profile.' 'ERROR' }
if (-not $newAccess)   { Exit-Yc 2 '-AccessKey is required for a new profile.' 'ERROR' }
if ($newBucket -notmatch '^[A-Za-z0-9._-]{3,63}$') {
  Exit-Yc 2 ('-Bucket "' + $newBucket + '" is not a plausible bucket name (3-63 characters, letters, digits, dot, dash, underscore).') 'ERROR'
}
if (-not $newPath -and ($newBucket -cmatch '[A-Z_]' -or $newBucket -match '\.')) {
  Write-YcLog ('Bucket "' + $newBucket + '" contains an uppercase letter, an underscore or a dot. Virtual-host style addressing will break on it (DNS label and TLS certificate rules). Use -UsePathStyle.') 'WARN'
}
if (([Uri]$newEndpoint).Scheme -eq 'http') {
  Write-YcLog ('Endpoint ' + $newEndpoint + ' is PLAIN HTTP. The SigV4 signature and every byte of every backup will cross the network unencrypted. Only acceptable on a trusted storage VLAN.') 'WARN'
}

# ---- the secret ----
$plainSecret = $null
if ($SecretKeyFile) {
  if (-not (Test-Path -LiteralPath $SecretKeyFile -PathType Leaf)) {
    Exit-Yc 2 ('-SecretKeyFile does not exist: ' + $SecretKeyFile) 'ERROR'
  }
  $lines = @(Get-Content -LiteralPath $SecretKeyFile | Where-Object { $_.Trim().Length -gt 0 })
  if ($lines.Count -eq 0) { Exit-Yc 2 ('-SecretKeyFile ' + $SecretKeyFile + ' is empty.') 'ERROR' }
  $plainSecret = $lines[0].Trim()
  Write-YcLog ('Read the secret key from ' + $SecretKeyFile + ' (' + $plainSecret.Length + ' characters). Delete that file when you are done - this command does not touch it.')
} elseif ($SecretKey) {
  $plainSecret = $SecretKey
  Write-YcLog 'SECRET ON THE COMMAND LINE: -SecretKey was passed as an argument. It is visible in the process table to every local account, is recorded in Security event 4688 when command line auditing is enabled, and was written into this transcript header by PowerShell before it could be masked. ROTATE THIS KEY if the host is not trusted, and use -SecretKeyFile next time.' 'WARN'
} elseif (-not $newBlob) {
  $interactive = $true
  try { $interactive = [Environment]::UserInteractive } catch { }
  if (-not $interactive) {
    Exit-Yc 2 ('No secret key was supplied and this session is not interactive (cloud-init / SYSTEM / RMM), so there is nobody to prompt. Pass -SecretKeyFile <path>.') 'ERROR'
  }
  $ss = Read-Host -Prompt ('Secret access key for profile "' + $profileName + '"') -AsSecureString
  $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($ss)
  try { $plainSecret = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
  if (-not $plainSecret) { Exit-Yc 2 'No secret key was entered.' 'ERROR' }
  Write-YcLog ('Secret key read from the console prompt (' + $plainSecret.Length + ' characters). It never reached a command line.')
}

if ($plainSecret) {
  if ($plainSecret.Length -lt 8) {
    Exit-Yc 2 ('The supplied secret key is only ' + $plainSecret.Length + ' characters - that is not a plausible S3 secret access key.') 'ERROR'
  }
  $newBlob = Protect-YcS3Key -Plain $plainSecret
  Write-YcLog ('Secret key encrypted with DPAPI, DataProtectionScope.LocalMachine (' + $newBlob.Length + ' base64 characters). A SYSTEM scheduled task on THIS host can decrypt it; no other machine can.') 'OK'
} elseif ($newBlob) {
  Write-YcLog 'No new secret was supplied - keeping the secret already stored for this profile.'
} else {
  Exit-Yc 2 'No secret key is stored for this profile and none was supplied. Use -SecretKeyFile <path>.' 'ERROR'
}

# ---- prove the configuration BEFORE and AFTER writing it ----
$secretForTest = $plainSecret
if (-not $secretForTest) { $secretForTest = Unprotect-YcS3Key -B64 $newBlob }
if (-not $secretForTest) { Exit-Yc 6 'The stored secret for this profile cannot be decrypted on this machine, so the configuration cannot be tested.' 'ERROR' }

$cfg = @{
  Endpoint = $newEndpoint; Region = $newRegion; Bucket = $newBucket; Prefix = $newPrefix
  AccessKey = $newAccess; SecretKey = $secretForTest; UsePathStyle = $newPath
}
$rc = Test-YcS3Config -C $cfg
$cfg['SecretKey'] = $null
$secretForTest    = $null
$plainSecret      = $null
[GC]::Collect()

if ($rc -ne 0) {
  Write-YcLog 'The configuration was NOT written, because it does not work. Fix the endpoint / region / bucket / key and re-run.' 'ERROR'
  Exit-Yc $rc ('set-s3config FAILED its live endpoint test for profile "' + $profileName + '".') 'ERROR'
}

$data = [ordered]@{
  SchemaVersion  = $script:SchemaVer
  Profile        = $profileName
  Endpoint       = $newEndpoint
  Region         = $newRegion
  Bucket         = $newBucket
  Prefix         = $newPrefix
  AccessKey      = $newAccess
  SecretKeyDpapi = $newBlob
  UsePathStyle   = $newPath
  UpdatedUtc     = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
  UpdatedBy      = ($env:USERDOMAIN + '\' + $env:USERNAME)
  Host           = $env:COMPUTERNAME
}
$written = Write-YcS3Profile -Data $data -Name $profileName
if (-not $written) {
  Exit-Yc 0 ('-WhatIf: the configuration for profile "' + $profileName + '" PASSED the live endpoint test but was not written to disk.') 'WARN'
}

# Read it back and prove the round trip - the file, the JSON and the DPAPI blob together.
$verify = Read-YcS3Profile -Name $profileName -MustExist
$rt = Unprotect-YcS3Key -B64 ([string]$verify.SecretKeyDpapi)
if (-not $rt) {
  Exit-Yc 6 ('The profile was written but its DPAPI blob does not decrypt when read back. Do not rely on this profile.') 'ERROR'
}
$rt = $null
Write-YcLog ('Verified round trip: ' + (Get-YcS3Path $profileName) + ' parses as JSON and its secret decrypts on this host.') 'OK'
Write-YcLog ('Profile "' + $profileName + '" -> ' + $verify.Endpoint + ' bucket ' + $verify.Bucket + ' region ' + $verify.Region +
             ' ' + $(if ($verify.UsePathStyle) { 'path-style' } else { 'virtual-host style' }) +
             $(if ($verify.Prefix) { ' prefix ' + $verify.Prefix } else { '' }) + '. Use it with: transfer-s3 -Profile ' + $profileName) 'OK'
Exit-Yc 0 ('set-s3config complete for profile "' + $profileName + '" - configuration stored and PROVEN against the live endpoint.') 'OK'
