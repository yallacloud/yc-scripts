# Set-Nic.ps1 - configure NICs on a CloudStack VM (DHCP or static), rescan for hot-added NICs,
#               clean ghost NICs. Windows Server 2016-2025, PowerShell 5.1, ASCII only.
#
# WHAT CHANGED AND WHY (repair of audit finding P0-11)
#   BEFORE: the static path removed EVERY IPv4 address and route on the interface, then added the new
#           address under $ErrorActionPreference='SilentlyContinue' with -EA SilentlyContinue and
#           | Out-Null. New-NetIPAddress fails routinely - duplicate address on the segment, gateway
#           outside the prefix, gateway omitted - and every one of those failures was invisible. The
#           interface was left with no address and no default route while the script printed the
#           intended configuration in green. On a single-NIC CloudStack VM the operator's session dies
#           mid-command and the box becomes console-only. There was no snapshot and no rollback.
#   AFTER:  1) VALIDATE BEFORE DESTROYING. The address, prefix, gateway and DNS servers are parsed; the
#              gateway is checked to be inside IP/Prefix by real bitmask arithmetic (not by comparing the
#              first three octets); a gateway equal to the host address is rejected; an omitted gateway
#              is rejected when the interface currently has a default route; and the target address is
#              probed on the segment first so a duplicate is caught BEFORE anything is removed.
#           2) SNAPSHOT. The full live configuration (addresses, prefixes, default gateways, routes, DNS
#              servers and the DHCP flag, plus the raw Get-NetIPConfiguration output) is exported to
#              C:\Scripts\set-nic-rollback-<timestamp>.xml before the first destructive call.
#           3) DEAD-MAN'S SWITCH. Before applying, a one-shot scheduled task (YC-SetNic-Rollback) is
#              registered to restore that snapshot in -RollbackMinutes minutes (default 5) as SYSTEM.
#              If the change kills the operator's session, the box restores itself. The operator keeps
#              the change by re-running the command with -Commit, which cancels the task.
#           4) APPLY WITH -ErrorAction Stop inside try/catch. Any failure triggers an immediate restore
#              of the snapshot, logs ERROR, calls Stop-YcLog 1 and exits 1.
#           5) VERIFY AFTER APPLYING. The address is re-read from Windows and the gateway is probed with
#              Test-NetConnection (falling back to neighbour/ARP resolution, because plenty of gateways
#              drop ICMP). Failure rolls back.
#           6) -WhatIf prints exactly what would change and exits without touching anything.
#           7) IDEMPOTENT. If the interface already has the requested address, prefix, gateway and DNS,
#              nothing is destroyed at all - the script reports "already configured" and exits 0.
#           8) $ErrorActionPreference is no longer SilentlyContinue; every exit path calls Stop-YcLog
#              <code> first; every Write-YcLog call passes a level STRING, never an event id.
#
# RELATION TO yc-boot.ps1
#   yc-boot.ps1 step 2 calls this script with -CleanGhosts only. That path is non-destructive to IP
#   configuration and is unaffected by the guards below: the snapshot, the dead-man's switch and the
#   commit requirement apply only to -DHCP and -IP. yc-boot also creates firewall rules; this script
#   creates none. See Set-Firewall.ps1 for the firewall overlap notes.
#
# ROLLBACK ARTEFACTS (all under C:\Scripts)
#   set-nic-rollback-<timestamp>.xml   the snapshot
#   set-nic-rollback.ps1               the generated restore runner (regenerated every run)
#   set-nic-rollback-latest.txt        pointer to the snapshot the armed task will restore
#   scheduled task YC-SetNic-Rollback  the one-shot dead-man's switch

param(
  [string]$Name,
  [switch]$DHCP,
  [string]$IP,
  [int]$Prefix = 24,
  [string]$Gateway,
  [string[]]$DNS,
  [switch]$Rescan,
  [switch]$CleanGhosts,
  [switch]$List,
  [switch]$Commit,
  [switch]$Rollback,
  [int]$RollbackMinutes = 5,
  [switch]$NoRollbackGuard,
  [switch]$WhatIf,
  [switch]$Force,
  [switch]$Help
)

. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'set-nic'
$ErrorActionPreference = 'Continue'   # per-operation -ErrorAction Stop inside try/catch is used instead

$YcRbTask   = 'YC-SetNic-Rollback'
$YcDir      = 'C:\Scripts'
$YcRbRunner = Join-Path $YcDir 'set-nic-rollback.ps1'
$YcRbLatest = Join-Path $YcDir 'set-nic-rollback-latest.txt'

if($Help -or (-not $DHCP -and -not $IP -and -not $Rescan -and -not $CleanGhosts -and -not $List -and -not $Commit -and -not $Rollback)){
@"
set-nic  -  configure NICs on a CloudStack VM (DHCP or static IP/subnet/gateway/DNS), detect a live-added
            NIC, and clean ghost NICs left by MAC changes. Works 2016-2025.

SAFETY MODEL (read this before changing the address of a remote VM)
  Changing the IP of a single-NIC VM drops your own session. This script therefore never destroys the
  current configuration until it has proved the replacement is valid, and it always leaves itself a way
  back:
    1. It validates the address, prefix, gateway and DNS first, refuses a gateway outside the subnet,
       refuses an omitted gateway when a default route exists, and refuses an address that already
       answers on the segment.
    2. It snapshots the live configuration to C:\Scripts\set-nic-rollback-<timestamp>.xml.
    3. It arms a one-shot scheduled task (YC-SetNic-Rollback) that restores that snapshot in
       -RollbackMinutes minutes (default 5), running as SYSTEM.
    4. It applies the change, then re-reads the interface and probes the gateway. If either fails it
       restores the snapshot immediately and exits 1.
    5. If it worked, YOU MUST CONFIRM within the window:   set-nic -Commit
       If you do not (because you got disconnected), the box restores its old address by itself.
  Use -WhatIf first to see exactly what would change. Use -NoRollbackGuard only on a console session.

USAGE:
  set-nic -List                                    show adapters (name, MAC, status, IP)
  set-nic -Rescan                                  detect a live hot-added NIC (no reboot)
  set-nic -Name <name|auto> -DHCP                  set the NIC to DHCP (IP + DNS)
  set-nic -Name <name|auto> -IP 10.0.0.5 -Prefix 24 -Gateway 10.0.0.1 -DNS 8.8.8.8,1.1.1.1   (static)
  set-nic -Commit                                  keep the change and cancel the pending rollback
  set-nic -Rollback                                restore the last snapshot right now
  set-nic -CleanGhosts                             remove hidden/ghost NICs left by MAC changes

PARAMETERS:
  -Name             NIC name or MAC, or 'auto' for the first connected NIC.
  -DHCP             Set the NIC to DHCP (IP + DNS). Guarded exactly like a static change: if no lease
                    arrives, the previous configuration is restored.
  -IP               Static IPv4 address.
  -Prefix           Subnet prefix length for static (default 24, valid 1-32).
  -Gateway          Default gateway for static. MUST be inside IP/Prefix - that is checked with real
                    bitmask arithmetic, so 10.0.0.5/22 with gateway 10.0.3.1 is accepted and
                    10.0.0.5/24 with gateway 10.0.1.1 is refused. Omitting it is refused when the
                    interface already has a default route, unless you pass -Force.
  -DNS              One or more DNS servers.
  -Commit           Confirm the last change: cancels the pending YC-SetNic-Rollback task. Run this from
                    the NEW address once you can reach the box again.
  -Rollback         Restore the most recent snapshot immediately and cancel the pending task.
  -RollbackMinutes  Dead-man's-switch window in minutes (default 5, valid 1-1440). Give yourself enough
                    time to reconnect on the new address and run -Commit.
  -NoRollbackGuard  Do not arm the scheduled task. The snapshot is still written and an immediate
                    failure still rolls back - you just lose the protection against losing your session.
                    Console/local sessions only.
  -WhatIf           Print the current configuration, the intended configuration and every step that
                    would run, then exit. Changes nothing.
  -Force            Override the refusals that are advisory rather than fatal: missing gateway, an
                    address that already answers on the segment, and a rollback still armed from a
                    previous run. It does NOT override the gateway-outside-subnet check.
  -Rescan           Detect a live hot-added NIC (no reboot).
  -CleanGhosts      Remove hidden/ghost NICs left by MAC changes.
  -List             Show adapters (name, MAC, status, IP).
  -Help             Show this help and exit.

EXAMPLES:
  set-nic -List
  set-nic -Name auto -IP 10.0.0.5 -Prefix 24 -Gateway 10.0.0.1 -DNS 8.8.8.8,1.1.1.1 -WhatIf
  set-nic -Name auto -IP 10.0.0.5 -Prefix 24 -Gateway 10.0.0.1 -DNS 8.8.8.8,1.1.1.1
  (reconnect on 10.0.0.5, then)
  set-nic -Commit
  set-nic -Name auto -IP 10.0.0.5 -Prefix 24 -Gateway 10.0.0.1 -RollbackMinutes 15
  set-nic -Rollback

NOTES: run as Administrator. New NICs default to DHCP automatically (virtio NetKVM is injected).
       -Name auto = first connected NIC. Re-running the same static command is a no-op: if the address,
       prefix, gateway and DNS already match, nothing is removed and nothing is re-created.

EXIT CODES: 0 ok, 1 change failed and was rolled back, 2 refused (invalid or unsafe arguments),
            5 not elevated.
Log: C:\Scripts\set-nic.log
"@ | Write-Host -ForegroundColor Cyan
  Stop-YcLog 0
  exit 0
}

Assert-YcPrereqs -NeedAdmin

# ---------------------------------------------------------------- IPv4 maths and validation helpers
function Test-YcIPv4{
  param([string]$Addr)
  if([string]::IsNullOrEmpty($Addr)){ return $false }
  $parsed = $null
  if(-not [System.Net.IPAddress]::TryParse($Addr.Trim(),[ref]$parsed)){ return $false }
  if($parsed.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork){ return $false }
  # TryParse accepts things like '10.5' - insist on four dotted octets
  if(($Addr.Trim() -split '\.').Count -ne 4){ return $false }
  # TryParse also accepts OCTAL and HEX octets: '010.0.0.5' parses as 8.0.0.5 and '0x0a.0.0.5'
  # as 10.0.0.5. The subnet/gateway maths runs on the PARSED value while New-NetIPAddress is
  # handed the RAW string, so the two would disagree about which address is being configured.
  # Insist the text is already the canonical dotted-decimal form of what it parsed to.
  if($parsed.IPAddressToString -ne $Addr.Trim()){ return $false }
  return $true
}

# Canonical dotted-decimal form of an address that has ALREADY passed Test-YcIPv4. Used to make
# sure the string validated is byte-for-byte the string handed to New-NetIPAddress.
function ConvertTo-YcIPv4Canonical{
  param([string]$Addr)
  return ([System.Net.IPAddress]::Parse($Addr.Trim())).IPAddressToString
}

function ConvertTo-YcU32{
  param([string]$Addr)
  $b = ([System.Net.IPAddress]::Parse($Addr.Trim())).GetAddressBytes()
  [array]::Reverse($b)
  return [System.BitConverter]::ToUInt32($b,0)
}

# Build the prefix mask bit by bit. No floating point, no shift-overflow surprises in PS 5.1.
function Get-YcMaskU32{
  param([int]$PrefixLen)
  if($PrefixLen -le 0){ return [uint32]0 }
  if($PrefixLen -ge 32){ return [uint32]4294967295 }
  $v = [uint64]0
  for($i = 0; $i -lt $PrefixLen; $i++){ $v = $v -bor ([uint64]1 -shl (31 - $i)) }
  return [uint32]$v
}

function ConvertFrom-YcU32{
  param([uint32]$Value)
  $b = [System.BitConverter]::GetBytes([uint32]$Value)
  [array]::Reverse($b)
  return ([System.Net.IPAddress]($b)).IPAddressToString
}

function Test-YcSameSubnet{
  param([string]$A,[string]$B,[int]$PrefixLen)
  $m  = Get-YcMaskU32 -PrefixLen $PrefixLen
  $na = [uint32](([uint64](ConvertTo-YcU32 -Addr $A)) -band [uint64]$m)
  $nb = [uint32](([uint64](ConvertTo-YcU32 -Addr $B)) -band [uint64]$m)
  return ($na -eq $nb)
}

function Get-YcAdapter{
  param([string]$Wanted)
  try{
    if($Wanted -and $Wanted -ne 'auto'){
      $norm = ($Wanted -replace '[:.]','-').ToUpper()
      return (Get-NetAdapter -ErrorAction Stop |
              Where-Object { $_.Name -eq $Wanted -or $_.InterfaceAlias -eq $Wanted -or ($_.MacAddress -and $_.MacAddress.ToUpper() -eq $norm) } |
              Select-Object -First 1)
    }
    return (Get-NetAdapter -ErrorAction Stop | Where-Object { $_.Status -eq 'Up' } | Sort-Object ifIndex | Select-Object -First 1)
  }catch{
    Write-YcLog ('could not enumerate network adapters: ' + $_.Exception.Message) 'ERROR'
    return $null
  }
}

# Gateway reachability. ICMP first; many gateways drop echo, so fall back to neighbour resolution,
# which still proves the address, mask and L2 path are correct.
function Test-YcGatewayReach{
  param([string]$Gw,[int]$Tries = 4)
  for($i = 1; $i -le $Tries; $i++){
    try{
      if(Test-NetConnection -ComputerName $Gw -InformationLevel Quiet -ErrorAction Stop){
        return @{ Ok = $true; How = 'icmp' }
      }
    }catch{
      Write-YcLog ('gateway probe attempt ' + $i + ' errored: ' + $_.Exception.Message) 'WARN'
    }
    Start-Sleep -Seconds 2
  }
  try{
    $n = @(Get-NetNeighbor -IPAddress $Gw -AddressFamily IPv4 -ErrorAction Stop |
           Where-Object { $_.State -eq 'Reachable' -or $_.State -eq 'Stale' -or $_.State -eq 'Permanent' -or $_.State -eq 'Delay' })
    if($n.Count -gt 0){ return @{ Ok = $true; How = 'neighbor' } }
  }catch{
    Write-YcLog ('neighbour lookup for ' + $Gw + ' failed: ' + $_.Exception.Message) 'WARN'
  }
  return @{ Ok = $false; How = 'none' }
}

function Write-YcLiveState{
  param([int]$Idx,[string]$Label)
  try{
    $addrs = @(Get-NetIPAddress -InterfaceIndex $Idx -AddressFamily IPv4 -ErrorAction Stop |
               ForEach-Object { $_.IPAddress + '/' + $_.PrefixLength + '(' + $_.PrefixOrigin + ')' })
  }catch{ $addrs = @() }
  try{
    $gws = @(Get-NetRoute -InterfaceIndex $Idx -AddressFamily IPv4 -ErrorAction Stop |
             Where-Object { $_.DestinationPrefix -eq '0.0.0.0/0' } | ForEach-Object { $_.NextHop })
  }catch{ $gws = @() }
  try{
    $dns = @((Get-DnsClientServerAddress -InterfaceIndex $Idx -AddressFamily IPv4 -ErrorAction Stop).ServerAddresses)
  }catch{ $dns = @() }
  try{
    $dhcp = (Get-NetIPInterface -InterfaceIndex $Idx -AddressFamily IPv4 -ErrorAction Stop).Dhcp
  }catch{ $dhcp = 'unknown' }
  Write-YcLog ($Label + ' ifIndex=' + $Idx +
               ' dhcp=' + $dhcp +
               ' addr=' + $(if($addrs.Count){ $addrs -join ',' } else { 'NONE' }) +
               ' gw=' + $(if($gws.Count){ $gws -join ',' } else { 'NONE' }) +
               ' dns=' + $(if($dns.Count){ $dns -join ',' } else { 'NONE' })) 'INFO'
  return @{ Addr = $addrs; Gw = $gws; Dns = $dns; Dhcp = $dhcp }
}

# ---------------------------------------------------------------- rollback plumbing
function Get-YcRbTask{
  try{ return (Get-ScheduledTask -TaskName $YcRbTask -ErrorAction Stop) }catch{ return $null }
}

function Unregister-YcRbTask{
  param([string]$Why)
  $t = Get-YcRbTask
  if(-not $t){ return $false }
  try{
    Unregister-ScheduledTask -TaskName $YcRbTask -Confirm:$false -ErrorAction Stop
    Write-YcLog ('pending rollback cancelled (' + $Why + ')') 'OK'
    return $true
  }catch{
    Write-YcLog ('FAILED to cancel the pending rollback task ' + $YcRbTask + ': ' + $_.Exception.Message +
                 ' - cancel it by hand with: Unregister-ScheduledTask -TaskName ' + $YcRbTask + ' -Confirm:0') 'ERROR'
    return $false
  }
}

# The restore logic lives in ONE place: a generated runner script. The dead-man's-switch task and the
# immediate failure path both invoke it, so an automatic rollback and a manual rollback behave identically.
# It is DELIBERATELY self-contained - it does NOT dot-source C:\Scripts\_yc-lib.ps1, so it therefore does
# not (and cannot) call Stop-YcLog before its own exits. That is intentional: this is the safety net, and
# it must still restore the interface if the library is missing, corrupt, or locked by the parent's
# transcript. It writes the same [YALLACLOUD][set-nic-rollback] tagged lines into C:\Scripts\set-nic.log
# and the same Application event log source, so log collection is unaffected.
$YcRbBody = @'
param([string]$Snapshot,[string]$Reason = 'deadman')
$ErrorActionPreference = 'Continue'
$log  = 'C:\Scripts\set-nic.log'
$task = 'YC-SetNic-Rollback'
function L{
  param([string]$m,[string]$lvl = 'INFO')
  $line = ('{0}  [YALLACLOUD][set-nic-rollback] [{1}] {2}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'),$lvl,$m)
  Write-Host $line
  try{ Add-Content -Path $log -Value $line -Encoding ascii }catch{}
  try{
    $t = 'Information'
    if($lvl -eq 'ERROR'){ $t = 'Error' } elseif($lvl -eq 'WARN'){ $t = 'Warning' }
    if([System.Diagnostics.EventLog]::SourceExists('YallaCloud')){
      Write-EventLog -LogName Application -Source 'YallaCloud' -EntryType $t -EventId 1002 -Message ('[set-nic-rollback] ' + $m)
    }
  }catch{}
}
L ('restore starting, reason=' + $Reason + ' snapshot=' + $Snapshot)
if(-not (Test-Path $Snapshot)){
  L ('snapshot file missing: ' + $Snapshot + ' - cannot restore') 'ERROR'
  try{ Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction Stop }catch{}
  exit 1
}
try{ $s = Import-Clixml -Path $Snapshot }catch{ L ('snapshot unreadable: ' + $_.Exception.Message) 'ERROR'; exit 1 }
$idx = [int]$s.InterfaceIndex
L ('restoring ifIndex=' + $idx + ' alias=' + $s.InterfaceAlias + ' dhcp=' + $s.Dhcp)

try{
  $cur = @(Get-NetIPAddress -InterfaceIndex $idx -AddressFamily IPv4 -ErrorAction Stop)
  foreach($a in $cur){
    try{ Remove-NetIPAddress -InputObject $a -Confirm:$false -ErrorAction Stop }
    catch{ L ('could not remove ' + $a.IPAddress + ': ' + $_.Exception.Message) 'WARN' }
  }
}catch{ L ('no current IPv4 address to remove (' + $_.Exception.Message + ')') 'WARN' }
try{
  $rts = @(Get-NetRoute -InterfaceIndex $idx -AddressFamily IPv4 -ErrorAction Stop | Where-Object { $_.DestinationPrefix -eq '0.0.0.0/0' })
  foreach($r in $rts){
    try{ Remove-NetRoute -InputObject $r -Confirm:$false -ErrorAction Stop }
    catch{ L ('could not remove default route via ' + $r.NextHop + ': ' + $_.Exception.Message) 'WARN' }
  }
}catch{ L 'no default route to remove' 'WARN' }

if($s.Dhcp -eq 'Enabled'){
  try{
    Set-NetIPInterface -InterfaceIndex $idx -Dhcp Enabled -ErrorAction Stop
    Set-DnsClientServerAddress -InterfaceIndex $idx -ResetServerAddresses -ErrorAction Stop
    $null = & ipconfig /renew
    L 'restored to DHCP' 'OK'
  }catch{ L ('DHCP restore failed: ' + $_.Exception.Message) 'ERROR' }
}else{
  try{ Set-NetIPInterface -InterfaceIndex $idx -Dhcp Disabled -ErrorAction Stop }catch{ L ('could not disable DHCP: ' + $_.Exception.Message) 'WARN' }
  foreach($a in @($s.Addresses)){
    try{
      New-NetIPAddress -InterfaceIndex $idx -IPAddress $a.IPAddress -PrefixLength ([int]$a.PrefixLength) -ErrorAction Stop | Out-Null
      L ('restored address ' + $a.IPAddress + '/' + $a.PrefixLength) 'OK'
    }catch{ L ('could not restore address ' + $a.IPAddress + ': ' + $_.Exception.Message) 'ERROR' }
  }
  foreach($g in @($s.DefaultGateways)){
    if(-not $g){ continue }
    try{
      New-NetRoute -InterfaceIndex $idx -DestinationPrefix '0.0.0.0/0' -NextHop $g -ErrorAction Stop | Out-Null
      L ('restored default gateway ' + $g) 'OK'
    }catch{ L ('could not restore default gateway ' + $g + ': ' + $_.Exception.Message) 'ERROR' }
  }
  try{
    if(@($s.DnsServers).Count -gt 0 -and -not $s.DnsFromDhcp){
      Set-DnsClientServerAddress -InterfaceIndex $idx -ServerAddresses @($s.DnsServers) -ErrorAction Stop
      L ('restored DNS ' + (@($s.DnsServers) -join ',')) 'OK'
    }else{
      Set-DnsClientServerAddress -InterfaceIndex $idx -ResetServerAddresses -ErrorAction Stop
      L 'restored DNS to automatic' 'OK'
    }
  }catch{ L ('could not restore DNS: ' + $_.Exception.Message) 'ERROR' }
}

try{
  $a = @(Get-NetIPAddress -InterfaceIndex $idx -AddressFamily IPv4 -ErrorAction Stop | ForEach-Object { $_.IPAddress + '/' + $_.PrefixLength })
  $g = @(Get-NetRoute -InterfaceIndex $idx -AddressFamily IPv4 -ErrorAction Stop | Where-Object { $_.DestinationPrefix -eq '0.0.0.0/0' } | ForEach-Object { $_.NextHop })
  L ('LIVE after restore: addr=' + $(if($a.Count){ $a -join ',' }else{ 'NONE' }) + ' gw=' + $(if($g.Count){ $g -join ',' }else{ 'NONE' })) 'OK'
}catch{ L ('could not read back the interface after restore: ' + $_.Exception.Message) 'ERROR' }

try{ Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction Stop; L 'rollback task removed' }catch{}
try{ Remove-Item -Path 'C:\Scripts\set-nic-rollback-latest.txt' -Force -ErrorAction Stop }catch{}
L 'restore finished'
exit 0
'@

function Write-YcRbRunner{
  try{
    Set-Content -Path $YcRbRunner -Value $YcRbBody -Encoding ascii -Force -ErrorAction Stop
    return $true
  }catch{
    Write-YcLog ('FAILED to write the rollback runner ' + $YcRbRunner + ': ' + $_.Exception.Message) 'ERROR'
    return $false
  }
}

function New-YcSnapshot{
  param([int]$Idx,[string]$Alias,[string]$Mac)
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $path  = Join-Path $YcDir ('set-nic-rollback-' + $stamp + '.xml')
  try{
    $ipcfg = Get-NetIPConfiguration -InterfaceIndex $Idx -ErrorAction Stop
    $dhcp  = (Get-NetIPInterface -InterfaceIndex $Idx -AddressFamily IPv4 -ErrorAction Stop).Dhcp
    $addrs = @(Get-NetIPAddress -InterfaceIndex $Idx -AddressFamily IPv4 -ErrorAction Stop |
               ForEach-Object { @{ IPAddress = $_.IPAddress; PrefixLength = [int]$_.PrefixLength; PrefixOrigin = [string]$_.PrefixOrigin } })
    $routes = @()
    $gws    = @()
    try{
      $routes = @(Get-NetRoute -InterfaceIndex $Idx -AddressFamily IPv4 -ErrorAction Stop |
                  ForEach-Object { @{ DestinationPrefix = $_.DestinationPrefix; NextHop = $_.NextHop; RouteMetric = [int]$_.RouteMetric } })
      $gws = @($routes | Where-Object { $_.DestinationPrefix -eq '0.0.0.0/0' } | ForEach-Object { $_.NextHop })
    }catch{ Write-YcLog ('no IPv4 routes captured for ifIndex ' + $Idx + ' (' + $_.Exception.Message + ')') 'WARN' }
    $dnsObj  = Get-DnsClientServerAddress -InterfaceIndex $Idx -AddressFamily IPv4 -ErrorAction Stop
    $dnsFrom = $false
    try{
      $key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
      $g   = (Get-NetAdapter -InterfaceIndex $Idx -ErrorAction Stop).InterfaceGuid
      $ns  = (Get-ItemProperty -Path (Join-Path $key $g) -Name NameServer -ErrorAction Stop).NameServer
      $dnsFrom = [string]::IsNullOrEmpty($ns)
    }catch{ $dnsFrom = ($dhcp -eq 'Enabled') }
    $snap = [pscustomobject]@{
      TimeStamp       = (Get-Date).ToString('s')
      ComputerName    = $env:COMPUTERNAME
      InterfaceIndex  = $Idx
      InterfaceAlias  = $Alias
      MacAddress      = $Mac
      Dhcp            = [string]$dhcp
      Addresses       = $addrs
      DefaultGateways = $gws
      Routes          = $routes
      DnsServers      = @($dnsObj.ServerAddresses)
      DnsFromDhcp     = $dnsFrom
      IpConfig        = $ipcfg
    }
    $snap | Export-Clixml -Path $path -Force -ErrorAction Stop
    Set-Content -Path $YcRbLatest -Value $path -Encoding ascii -Force -ErrorAction Stop
    Write-YcLog ('snapshot written: ' + $path + ' (dhcp=' + $dhcp +
                 ' addr=' + $(if($addrs.Count){ (@($addrs | ForEach-Object { $_.IPAddress + '/' + $_.PrefixLength }) -join ',') }else{ 'NONE' }) +
                 ' gw=' + $(if($gws.Count){ $gws -join ',' }else{ 'NONE' }) +
                 ' dns=' + $(if(@($dnsObj.ServerAddresses).Count){ (@($dnsObj.ServerAddresses) -join ',') }else{ 'NONE' }) + ')') 'OK'
    return $path
  }catch{
    Write-YcLog ('FAILED to snapshot the current configuration: ' + $_.Exception.Message +
                 ' - refusing to change the interface without a way back') 'ERROR'
    return $null
  }
}

function Register-YcDeadMan{
  param([string]$SnapshotPath,[int]$Minutes)
  try{
    $when = (Get-Date).AddMinutes($Minutes)
    $arg  = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $YcRbRunner +
            '" -Snapshot "' + $SnapshotPath + '" -Reason deadman'
    $act  = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arg -ErrorAction Stop
    $trg  = New-ScheduledTaskTrigger -Once -At $when -ErrorAction Stop
    $pri  = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest -ErrorAction Stop
    $set  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
              -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -ErrorAction Stop
    Register-ScheduledTask -TaskName $YcRbTask -Action $act -Trigger $trg -Principal $pri -Settings $set -Force -ErrorAction Stop | Out-Null
    Write-YcLog ('DEAD-MAN SWITCH ARMED: scheduled task ' + $YcRbTask + ' will restore ' + $SnapshotPath +
                 ' at ' + $when.ToString('yyyy-MM-dd HH:mm:ss') + ' (in ' + $Minutes + ' minute(s)) unless you run: set-nic -Commit') 'OK'
    return $true
  }catch{
    Write-YcLog ('FAILED to arm the rollback task: ' + $_.Exception.Message) 'ERROR'
    return $false
  }
}

function Invoke-YcRollbackNow{
  param([string]$SnapshotPath,[string]$Reason)
  Write-YcLog ('ROLLING BACK now (' + $Reason + ') from ' + $SnapshotPath) 'WARN'
  try{
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $YcRbRunner -Snapshot $SnapshotPath -Reason $Reason 2>&1 |
      ForEach-Object { Write-YcLog ('rollback: ' + $_) 'INFO' }
    Write-YcLog 'rollback runner finished' 'OK'
  }catch{
    Write-YcLog ('the rollback runner itself failed: ' + $_.Exception.Message +
                 ' - restore by hand from ' + $SnapshotPath + ' via the console') 'ERROR'
  }
}

# ---------------------------------------------------------------- -Commit / -Rollback (no IP change)
if($Commit){
  $t = Get-YcRbTask
  if($t){
    if(Unregister-YcRbTask -Why 'operator confirmed with -Commit'){
      try{ Remove-Item -Path $YcRbLatest -Force -ErrorAction Stop }catch{}   # cosmetic cleanup of the pointer file
      Write-YcLog 'change COMMITTED. The snapshot XML is kept in C:\Scripts for reference.' 'OK'
    }else{
      Stop-YcLog 1; exit 1
    }
  }else{
    Write-YcLog 'nothing to commit: no rollback is armed.' 'WARN'
  }
  try{
    $ad = Get-YcAdapter -Wanted $(if($Name){ $Name } else { 'auto' })
    if($ad){ Write-YcLiveState -Idx $ad.ifIndex -Label 'LIVE' | Out-Null }
  }catch{}   # informational read-back after commit; failing to print it must not fail the commit itself
  Stop-YcLog 0
  exit 0
}

if($Rollback){
  $snapPath = $null
  if(Test-Path $YcRbLatest){
    try{ $snapPath = (Get-Content -Path $YcRbLatest -ErrorAction Stop | Select-Object -First 1).Trim() }catch{ $snapPath = $null }
  }
  if(-not $snapPath){
    try{
      $snapPath = (Get-ChildItem -Path (Join-Path $YcDir 'set-nic-rollback-*.xml') -ErrorAction Stop |
                   Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
    }catch{ $snapPath = $null }
  }
  if(-not $snapPath -or -not (Test-Path $snapPath)){
    Write-YcLog 'no snapshot found to roll back to (C:\Scripts\set-nic-rollback-*.xml)' 'ERROR'
    Stop-YcLog 2; exit 2
  }
  if(-not (Write-YcRbRunner)){ Stop-YcLog 1; exit 1 }
  Invoke-YcRollbackNow -SnapshotPath $snapPath -Reason 'manual'
  Stop-YcLog 0
  exit 0
}

# ---------------------------------------------------------------- informational actions
if($Rescan){
  try{
    $out = & "$env:WINDIR\System32\pnputil.exe" /scan-devices 2>&1
    Write-YcLog ('rescanned for new hardware: ' + (($out | Out-String).Trim() -replace '\s+',' ')) 'OK'
  }catch{
    Write-YcLog ('hardware rescan failed: ' + $_.Exception.Message) 'ERROR'
  }
}

if($List){
  try{
    Get-NetAdapter -ErrorAction Stop | Sort-Object ifIndex | ForEach-Object {
      $a = $null
      try{ $a = (Get-NetIPAddress -InterfaceIndex $_.ifIndex -AddressFamily IPv4 -ErrorAction Stop | Select-Object -First 1).IPAddress }catch{ $a = $null }
      [pscustomobject]@{ Name = $_.Name; MAC = $_.MacAddress; Status = $_.Status; ifIndex = $_.ifIndex; IP = $a }
    } | Format-Table -AutoSize | Out-String | ForEach-Object { Write-Host $_ }
  }catch{
    Write-YcLog ('could not list adapters: ' + $_.Exception.Message) 'ERROR'
  }
}

if($CleanGhosts){
  $c = 0
  try{
    $ghosts = @(Get-PnpDevice -Class Net -ErrorAction Stop | Where-Object { $_.Status -eq 'Unknown' })
    foreach($g in $ghosts){
      try{
        & "$env:WINDIR\System32\pnputil.exe" /remove-device $g.InstanceId 2>&1 | Out-Null
        $c++
      }catch{
        Write-YcLog ('could not remove ghost NIC ' + $g.InstanceId + ': ' + $_.Exception.Message) 'WARN'
      }
    }
    Write-YcLog ('cleaned ' + $c + ' ghost NIC(s) of ' + $ghosts.Count + ' found') 'OK'
  }catch{
    Write-YcLog ('ghost NIC scan failed: ' + $_.Exception.Message) 'ERROR'
  }
}

if(-not $DHCP -and -not $IP){
  Stop-YcLog 0
  exit 0
}

# ---------------------------------------------------------------- VALIDATE BEFORE DESTROYING
if($DHCP -and $IP){
  Write-YcLog 'REFUSED: -DHCP and -IP are mutually exclusive. Pick one.' 'ERROR'
  Stop-YcLog 2; exit 2
}
if($RollbackMinutes -lt 1 -or $RollbackMinutes -gt 1440){
  Write-YcLog ('REFUSED: -RollbackMinutes must be between 1 and 1440 (got ' + $RollbackMinutes + ')') 'ERROR'
  Stop-YcLog 2; exit 2
}

$ad = Get-YcAdapter -Wanted $(if($Name){ $Name } else { 'auto' })
if(-not $ad){
  Write-YcLog ("no matching NIC for -Name '" + $(if($Name){ $Name } else { 'auto' }) + "'. Run: set-nic -List") 'ERROR'
  Stop-YcLog 2; exit 2
}
$idx = [int]$ad.ifIndex
Write-YcLog ('target adapter: ' + $ad.Name + ' ifIndex=' + $idx + ' mac=' + $ad.MacAddress + ' status=' + $ad.Status) 'INFO'
$before = Write-YcLiveState -Idx $idx -Label 'BEFORE'

if($IP){
  if(-not (Test-YcIPv4 -Addr $IP)){
    Write-YcLog ("REFUSED: -IP '" + $IP + "' is not a valid IPv4 address (four dotted DECIMAL octets; octal '010.0.0.5' and hex '0x0a.0.0.5' forms are refused because the validator and New-NetIPAddress would not agree on what they mean)") 'ERROR'
    Stop-YcLog 2; exit 2
  }
  $IP = ConvertTo-YcIPv4Canonical -Addr $IP
  if($Prefix -lt 1 -or $Prefix -gt 32){
    Write-YcLog ('REFUSED: -Prefix must be 1-32 (got ' + $Prefix + ')') 'ERROR'
    Stop-YcLog 2; exit 2
  }
  if($Gateway){
    if(-not (Test-YcIPv4 -Addr $Gateway)){
      Write-YcLog ("REFUSED: -Gateway '" + $Gateway + "' is not a valid IPv4 address (four dotted DECIMAL octets; octal '010.0.0.5' and hex '0x0a.0.0.5' forms are refused because the validator and New-NetIPAddress would not agree on what they mean)") 'ERROR'
      Stop-YcLog 2; exit 2
    }
    $Gateway = ConvertTo-YcIPv4Canonical -Addr $Gateway
    if($Gateway.Trim() -eq $IP.Trim()){
      Write-YcLog 'REFUSED: -Gateway is the same address as -IP' 'ERROR'
      Stop-YcLog 2; exit 2
    }
    # This is the check the old script did not do at all. Real bitmask arithmetic, not octet eyeballing.
    if(-not (Test-YcSameSubnet -A $IP -B $Gateway -PrefixLen $Prefix)){
      $net = ConvertFrom-YcU32 -Value ([uint32](([uint64](ConvertTo-YcU32 -Addr $IP)) -band [uint64](Get-YcMaskU32 -PrefixLen $Prefix)))
      Write-YcLog ('REFUSED: gateway ' + $Gateway + ' is outside ' + $IP + '/' + $Prefix + ' (network ' + $net + '/' + $Prefix +
                   '). New-NetIPAddress would fail and the interface would be left with no address. This cannot be forced.') 'ERROR'
      Stop-YcLog 2; exit 2
    }
    Write-YcLog ('gateway ' + $Gateway + ' verified inside ' + $IP + '/' + $Prefix) 'OK'
  }else{
    if($before.Gw.Count -gt 0 -and -not $Force){
      Write-YcLog ('REFUSED: no -Gateway given but this interface currently routes via ' + ($before.Gw -join ',') +
                   '. Applying a static address without a gateway would remove the default route and cut the box off. ' +
                   'Pass -Gateway, or -Force if this NIC genuinely has no gateway.') 'ERROR'
      Stop-YcLog 2; exit 2
    }
    Write-YcLog 'no -Gateway given: this interface will have no default route' 'WARN'
  }
  foreach($d in @($DNS)){
    if($d -and -not (Test-YcIPv4 -Addr $d)){
      $p = $null
      if(-not [System.Net.IPAddress]::TryParse($d,[ref]$p)){
        Write-YcLog ("REFUSED: -DNS entry '" + $d + "' is not a valid IP address") 'ERROR'
        Stop-YcLog 2; exit 2
      }
    }
  }

  # Idempotency: if it is already exactly what was asked for, do not destroy anything.
  $wantAddr = ($IP.Trim() + '/' + $Prefix)
  $haveAddr = @($before.Addr | ForEach-Object { ($_ -split '\(')[0] })
  $gwOk     = if($Gateway){ ($before.Gw -contains $Gateway.Trim()) } else { $true }
  $dnsOk    = if($DNS){ ((@($DNS) -join ',') -eq (@($before.Dns) -join ',')) } else { $true }
  if(($haveAddr -contains $wantAddr) -and $gwOk -and $dnsOk -and $before.Dhcp -ne 'Enabled'){
    Write-YcLog ('already configured: ' + $wantAddr + $(if($Gateway){ ' gw ' + $Gateway } else { '' }) +
                 ' is live on ' + $ad.Name + '. Nothing removed, nothing changed.') 'OK'
    Stop-YcLog 0; exit 0
  }

  # Duplicate address detection BEFORE the destructive part. New-NetIPAddress' own DAD only fires after
  # the old address is already gone.
  if(-not ($haveAddr -contains $wantAddr)){
    $dup = $false
    try{ $dup = [bool](Test-Connection -ComputerName $IP -Count 2 -Quiet -ErrorAction Stop) }
    catch{ $dup = $false }
    if($dup){
      if($Force){
        Write-YcLog ('-Force: ' + $IP + ' already answers on the segment. Continuing anyway - expect a duplicate address conflict.') 'WARN'
      }else{
        Write-YcLog ('REFUSED: ' + $IP + ' already answers to ping on this segment, so it belongs to another host. ' +
                     'Assigning it would give both hosts a duplicate address. Pick a free address, or -Force if you know the reply is stale.') 'ERROR'
        Stop-YcLog 2; exit 2
      }
    }else{
      Write-YcLog ($IP + ' does not answer on the segment - free to assign') 'OK'
    }
  }
}

# A rollback still pending from an earlier run means the "before" state is already the changed state.
# Snapshotting it would destroy the only good copy.
$pending = Get-YcRbTask
if($pending -and -not $Force){
  Write-YcLog ('REFUSED: a rollback from a previous run is still armed (' + $YcRbTask + '). Snapshotting now would ' +
               'capture the already-changed configuration and lose the good one. Run: set-nic -Commit (keep the ' +
               'previous change) or set-nic -Rollback (undo it), then re-run this command.') 'ERROR'
  Stop-YcLog 2; exit 2
}elseif($pending){
  Write-YcLog ('-Force: overwriting the rollback armed by a previous run. The earlier snapshot stays on disk in ' + $YcDir) 'WARN'
}

# ---------------------------------------------------------------- -WhatIf: print the plan, change nothing
if($WhatIf){
  Write-YcLog '=== WHATIF: nothing below is executed ===' 'INFO'
  Write-YcLog ('WHATIF adapter        : ' + $ad.Name + ' (ifIndex ' + $idx + ', mac ' + $ad.MacAddress + ')') 'INFO'
  Write-YcLog ('WHATIF current addr   : ' + $(if($before.Addr.Count){ $before.Addr -join ',' }else{ 'NONE' })) 'INFO'
  Write-YcLog ('WHATIF current gw     : ' + $(if($before.Gw.Count){ $before.Gw -join ',' }else{ 'NONE' })) 'INFO'
  Write-YcLog ('WHATIF current dns    : ' + $(if($before.Dns.Count){ $before.Dns -join ',' }else{ 'NONE' })) 'INFO'
  Write-YcLog ('WHATIF current dhcp   : ' + $before.Dhcp) 'INFO'
  if($DHCP){
    Write-YcLog 'WHATIF intended       : DHCP for both address and DNS' 'INFO'
    Write-YcLog 'WHATIF would run      : Remove-NetIPAddress (manual addresses only); Set-NetIPInterface -Dhcp Enabled; Set-DnsClientServerAddress -ResetServerAddresses; ipconfig /renew' 'INFO'
  }else{
    Write-YcLog ('WHATIF intended addr  : ' + $IP + '/' + $Prefix) 'INFO'
    Write-YcLog ('WHATIF intended gw    : ' + $(if($Gateway){ $Gateway }else{ 'NONE' })) 'INFO'
    Write-YcLog ('WHATIF intended dns   : ' + $(if($DNS){ @($DNS) -join ',' }else{ 'unchanged' })) 'INFO'
    Write-YcLog 'WHATIF would run      : Remove-NetIPAddress (all IPv4); Remove-NetRoute (default routes); New-NetIPAddress -ErrorAction Stop; Set-DnsClientServerAddress' 'INFO'
  }
  Write-YcLog ('WHATIF would snapshot : ' + $YcDir + '\set-nic-rollback-<timestamp>.xml') 'INFO'
  if($NoRollbackGuard){
    Write-YcLog 'WHATIF rollback guard : DISABLED by -NoRollbackGuard' 'WARN'
  }else{
    Write-YcLog ('WHATIF would arm      : scheduled task ' + $YcRbTask + ', firing in ' + $RollbackMinutes +
                 ' minute(s), restoring the snapshot unless you run: set-nic -Commit') 'INFO'
  }
  Write-YcLog 'WHATIF complete - the interface was not touched.' 'OK'
  Stop-YcLog 0
  exit 0
}

# ---------------------------------------------------------------- SNAPSHOT + ARM, THEN APPLY
if(-not (Write-YcRbRunner)){ Stop-YcLog 1; exit 1 }
$snapPath = New-YcSnapshot -Idx $idx -Alias $ad.Name -Mac $ad.MacAddress
if(-not $snapPath){
  Write-YcLog 'aborting before any change was made - there is no snapshot to roll back to' 'ERROR'
  Stop-YcLog 1; exit 1
}

# Arm BEFORE applying: if the change kills this session mid-flight, the switch is already in place.
$armed = $false
if($NoRollbackGuard){
  Write-YcLog '-NoRollbackGuard: no scheduled rollback armed. If this change cuts the network you will need console access.' 'WARN'
}else{
  $armed = Register-YcDeadMan -SnapshotPath $snapPath -Minutes $RollbackMinutes
  if(-not $armed){
    if($Force){
      Write-YcLog '-Force: continuing without a dead-man switch (the snapshot and the immediate-failure rollback still apply)' 'WARN'
    }else{
      Write-YcLog 'REFUSED: could not arm the rollback task, so this change is not recoverable if it drops the session. Fix the Task Scheduler error, or re-run with -NoRollbackGuard (console only) or -Force.' 'ERROR'
      Stop-YcLog 2; exit 2
    }
  }
}

$applyOk  = $true
$applyErr = ''
try{
  if($DHCP){
    $manual = @(Get-NetIPAddress -InterfaceIndex $idx -AddressFamily IPv4 -ErrorAction Stop | Where-Object { $_.PrefixOrigin -eq 'Manual' })
    foreach($a in $manual){ Remove-NetIPAddress -InputObject $a -Confirm:$false -ErrorAction Stop }
    if($manual.Count -gt 0){ Write-YcLog ('removed ' + $manual.Count + ' manual address(es) before enabling DHCP') 'INFO' }
    Set-NetIPInterface -InterfaceIndex $idx -Dhcp Enabled -ErrorAction Stop
    Set-DnsClientServerAddress -InterfaceIndex $idx -ResetServerAddresses -ErrorAction Stop
    $renew = & ipconfig /renew 2>&1
    Write-YcLog ('ipconfig /renew: ' + (($renew | Out-String).Trim() -replace '\s+',' ')) 'INFO'
  }else{
    $cur = @(Get-NetIPAddress -InterfaceIndex $idx -AddressFamily IPv4 -ErrorAction Stop)
    foreach($a in $cur){ Remove-NetIPAddress -InputObject $a -Confirm:$false -ErrorAction Stop }
    Write-YcLog ('removed ' + $cur.Count + ' existing IPv4 address(es)') 'INFO'
    try{
      $defRoutes = @(Get-NetRoute -InterfaceIndex $idx -AddressFamily IPv4 -ErrorAction Stop | Where-Object { $_.DestinationPrefix -eq '0.0.0.0/0' })
      foreach($r in $defRoutes){ Remove-NetRoute -InputObject $r -Confirm:$false -ErrorAction Stop }
      Write-YcLog ('removed ' + $defRoutes.Count + ' default route(s)') 'INFO'
    }catch{
      Write-YcLog ('no default route to remove (' + $_.Exception.Message + ')') 'INFO'
    }
    Set-NetIPInterface -InterfaceIndex $idx -Dhcp Disabled -ErrorAction Stop
    if($Gateway){
      New-NetIPAddress -InterfaceIndex $idx -IPAddress $IP -PrefixLength $Prefix -DefaultGateway $Gateway -ErrorAction Stop | Out-Null
    }else{
      New-NetIPAddress -InterfaceIndex $idx -IPAddress $IP -PrefixLength $Prefix -ErrorAction Stop | Out-Null
    }
    Write-YcLog ('New-NetIPAddress accepted ' + $IP + '/' + $Prefix + $(if($Gateway){ ' gw ' + $Gateway }else{ '' })) 'OK'
    if($DNS){
      Set-DnsClientServerAddress -InterfaceIndex $idx -ServerAddresses @($DNS) -ErrorAction Stop
      Write-YcLog ('DNS set to ' + (@($DNS) -join ',')) 'OK'
    }
  }
}catch{
  $applyOk  = $false
  $applyErr = $_.Exception.Message
  Write-YcLog ('APPLY FAILED: ' + $applyErr) 'ERROR'
}

if(-not $applyOk){
  Invoke-YcRollbackNow -SnapshotPath $snapPath -Reason 'apply-failed'
  Write-YcLiveState -Idx $idx -Label 'AFTER-ROLLBACK' | Out-Null
  Write-YcLog ('the interface was restored to its previous configuration. Reason: ' + $applyErr) 'ERROR'
  Stop-YcLog 1
  exit 1
}

# ---------------------------------------------------------------- VERIFY THE LIVE RESULT
Start-Sleep -Seconds 3
$after   = Write-YcLiveState -Idx $idx -Label 'AFTER'
$verifOk = $true
$verifWhy = ''

if($DHCP){
  $leased = $false
  for($i = 0; $i -lt 10; $i++){
    try{
      $l = @(Get-NetIPAddress -InterfaceIndex $idx -AddressFamily IPv4 -ErrorAction Stop |
             Where-Object { $_.PrefixOrigin -eq 'Dhcp' -and $_.IPAddress -notlike '169.254.*' })
      if($l.Count -gt 0){ $leased = $true; break }
    }catch{}   # poll: a read failure just means "not leased yet". If the loop never succeeds, $leased stays
               # $false and the verification below rolls the interface back - the failure is never swallowed.
    Start-Sleep -Seconds 3
  }
  if(-not $leased){
    $verifOk = $false
    $verifWhy = 'no DHCP lease arrived within 30 seconds (an APIPA 169.254.x.x address does not count)'
  }else{
    $after = Write-YcLiveState -Idx $idx -Label 'AFTER-LEASE'
    if($after.Gw.Count -gt 0){
      $r = Test-YcGatewayReach -Gw $after.Gw[0]
      if(-not $r.Ok){
        $verifOk = $false
        $verifWhy = ('the DHCP-supplied gateway ' + $after.Gw[0] + ' is not reachable by ICMP or ARP')
      }else{
        Write-YcLog ('gateway ' + $after.Gw[0] + ' reachable (via ' + $r.How + ')') 'OK'
      }
    }
  }
}else{
  $wantAddr = ($IP.Trim() + '/' + $Prefix)
  $haveAddr = @($after.Addr | ForEach-Object { ($_ -split '\(')[0] })
  if(-not ($haveAddr -contains $wantAddr)){
    $verifOk = $false
    $verifWhy = ('the interface does not carry ' + $wantAddr + ' after the change (live: ' +
                 $(if($haveAddr.Count){ $haveAddr -join ',' }else{ 'NONE' }) + ')')
  }elseif($Gateway){
    if(-not ($after.Gw -contains $Gateway.Trim())){
      $verifOk = $false
      $verifWhy = ('no default route via ' + $Gateway + ' after the change (live: ' +
                   $(if($after.Gw.Count){ $after.Gw -join ',' }else{ 'NONE' }) + ')')
    }else{
      $r = Test-YcGatewayReach -Gw $Gateway
      if(-not $r.Ok){
        $verifOk = $false
        $verifWhy = ('gateway ' + $Gateway + ' does not respond to ICMP and does not resolve in the neighbour cache - the new configuration is not usable')
      }else{
        Write-YcLog ('gateway ' + $Gateway + ' reachable (via ' + $r.How + ')') 'OK'
      }
    }
  }
}

if(-not $verifOk){
  Write-YcLog ('VERIFICATION FAILED: ' + $verifWhy) 'ERROR'
  Invoke-YcRollbackNow -SnapshotPath $snapPath -Reason 'verify-failed'
  Write-YcLiveState -Idx $idx -Label 'AFTER-ROLLBACK' | Out-Null
  Stop-YcLog 1
  exit 1
}

# ---------------------------------------------------------------- SUCCESS
Write-YcLog ('applied and verified on ' + $ad.Name + ' - live configuration read back from Windows above') 'OK'

if($armed){
  Write-YcLog ('*** ACTION REQUIRED WITHIN ' + $RollbackMinutes + ' MINUTE(S) ***') 'WARN'
  Write-YcLog ('The change is live but NOT yet committed. Reconnect to the box' +
               $(if($IP){ ' on ' + $IP } else { '' }) + ' and run:   set-nic -Commit') 'WARN'
  Write-YcLog ('If you do not, scheduled task ' + $YcRbTask + ' restores ' + $snapPath + ' automatically.') 'WARN'
}else{
  Write-YcLog ('no rollback armed. Snapshot kept at ' + $snapPath + ' - restore it with: set-nic -Rollback') 'INFO'
}

Stop-YcLog 0
exit 0
