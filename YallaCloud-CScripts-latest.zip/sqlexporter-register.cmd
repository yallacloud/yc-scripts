@echo off
rem sqlexporter-register - install burningalchemist sql_exporter as a verified Windows service.
rem
rem CHANGED: the previous wrapper's example put the SQL password on the command line.
rem   Anything passed here lands in Win32_Process.CommandLine and in Windows Security
rem   event 4688 (ProcessCreationIncludeCmdLine is enabled in this estate and the Security
rem   channel is forwarded off-box), and in the PowerShell transcript header.
rem   Use -SqlPasswordFile <file>, or set YC_SQLEXPORTER_PASSWORD before calling.
rem
rem PREFERRED:
rem   set YC_SQLEXPORTER_PASSWORD=...
rem   sqlexporter-register -SqlUser mon -RemoteAddress 10.20.0.11
rem   sqlexporter-register -SqlUser mon -SqlPasswordFile C:\Scripts\.sqlexporter.pw
rem   sqlexporter-register -TrustedAuth
rem   sqlexporter-register -ConfigFile C:\Scripts\sql_exporter.yml
rem   sqlexporter-register -Help
rem
rem Exit codes: 0 verified, 1 failed, 2 usage, 5 not elevated, 6 no internet.
rem Log: C:\Scripts\sqlexporter-register.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\SqlExporter-Register.ps1" %*
exit /b %ERRORLEVEL%
