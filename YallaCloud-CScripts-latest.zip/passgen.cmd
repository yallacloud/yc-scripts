@echo off
setlocal
rem ================================================================================================
rem passgen - generate a password that survives PowerShell, cmd, JSON, sqlcmd and a handover sheet.
rem           Wrapper for C:\Scripts\PassGen.ps1.
rem
rem   passgen                  one 16-character password
rem   passgen -Length 12       any length from 8 to 16
rem   passgen -Count 10        ten of them, one per line
rem   passgen -NoSymbols       letters and digits only (weaker - only if a consumer demands it)
rem   passgen -SelfCheck       assertions only, changes nothing
rem   passgen -Help
rem
rem GUARANTEES one upper, one lower, one digit and one symbol, so it clears SQL Server's
rem three-of-four password policy and Windows complexity together.
rem
rem EXCLUDES the characters that break the plumbing rather than the password:
rem   ' " ` $ \ %% ^& ^| ^< ^> ^^ ! / and space   quoting in PowerShell, cmd and JSON
rem   O 0 o I l 1                                 ambiguous to a human reading it back
rem A password that breaks quoting fails LATE: the VM builds for forty minutes and then cannot
rem log in, with an error that blames SQL rather than the apostrophe.
rem
rem Uses RNGCryptoServiceProvider. Get-Random is seeded from the clock and two VMs built in the
rem same second would get the same password.
rem
rem EXIT CODES: 0 generated | 1 selfcheck failed | 2 usage
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\PassGen.ps1" %*
exit /b %ERRORLEVEL%
