param(
  [string]$DSN,
  [string]$SqlServer = 'localhost',
  [int]$SqlPort = 1433,
  [string]$SqlUser,
  [string]$SqlPassword,
  [string]$Database = 'master',
  [switch]$TrustedAuth,
  [int]$ListenPort = 9399,
  [string]$ConfigFile,
  [string]$InstallDir = 'C:\Program Files\sql_exporter',
  [string]$SqlPasswordFile,
  [ValidateSet('true','false','disable','strict')]
  [string]$Encrypt = 'true',
  [string]$ServiceName = 'sql_exporter',
  [string[]]$RemoteAddress = @('Any'),
  [string]$BindAddress = '',
  [string]$ZipPath,
  [string]$DownloadUrl,
  [string]$Sha256,
  [switch]$SkipFirewall,
  [switch]$Force,
  [switch]$Help
)
# =====================================================================================
# SqlExporter-Register.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
# Installs burningalchemist/sql_exporter as a native Windows service and PROVES it scrapes.
#
# WHAT CHANGED AND WHY
# --------------------
# The previous version could literally format the string "sql_exporter service: not
# created", tag that line OK, and exit 0. That is the Acronis defect verbatim. It also
# wrote a SQL password into a file that BUILTIN\Users can read.
#
#  1. IT NO LONGER LIES (was P0-2 / obs-#1, old lines 140-143). The run now ends in three
#     pieces of evidence, in order, and any one of them failing is a non-zero exit:
#       a. the vendor's own validator, BEFORE the service is touched:
#          sql_exporter.exe -config.file <cfg> -config.check
#       b. Get-Service ... Status -eq 'Running', polled, then RE-CHECKED after a settle
#          window (a Go binary without a service dispatcher dies at ~30s with error 1053;
#          sql_exporter has one - see 4 below - and this proves it stayed up),
#       c. HTTP GET http://127.0.0.1:<port>/metrics returning 200, whose body must be
#          Prometheus exposition text AND must contain the collector's own metric name.
#     -ErrorAction SilentlyContinue removed from New-Service, Start-Service, sc.exe and
#     the firewall rule.
#  2. THE PASSWORD LEAVES THE COMMAND LINE AND THE WORLD-READABLE FILE (was P0-1 / obs-#5).
#     - Preferred input is -SqlPasswordFile <path> or the environment variable
#       YC_SQLEXPORTER_PASSWORD. Neither appears in the process table, in a Windows 4688
#       ProcessCreation event, or in the PowerShell transcript header.
#     - -SqlPassword still works for compatibility but now logs a loud WARN naming the
#       exposure, and the value is scrubbed out of C:\Scripts\sqlexporter-register.log
#       after the transcript is closed.
#     - The DSN is never passed on any command line: not to the service (ImagePath carries
#       only -config.file / -web.listen-address), and not to -config.check. The exporter's
#       -config.data-source-name flag is deliberately NOT used for that reason.
#     - sql_exporter.yml gets inheritance stripped and an ACL of SYSTEM + Administrators
#       only, and is written BEFORE anything else can read it.
#  3. THE DSN IS BUILT CORRECTLY (was P1-1/obs-#2/#3/#4/#7, old lines 74-76).
#     - user and password are percent-encoded ([uri]::EscapeDataString) - go-mssqldb
#       requires it and 'P@ss' from the old help text is exactly the value that broke it;
#     - a named instance becomes sqlserver://host/instance (path form), not host\inst
#       inside the URL authority;
#     - Windows auth uses authenticator=winsspi, the documented go-mssqldb mechanism.
#       'trusted_connection=yes' is not a go-mssqldb parameter and only ever worked by
#       accident because the user was empty;
#     - encrypt now defaults to true with trustservercertificate=true instead of
#       encrypt=disable, and is exposed as -Encrypt;
#     - -SqlUser with no password is now a hard error instead of an empty-password DSN
#       that authenticates against nothing and reports OK.
#  4. NATIVE WINDOWS SERVICE - VERIFIED, NOT ASSUMED. cmd/sql_exporter/main.go imports
#     _ "github.com/kardianos/minwinsvc", so the binary answers the SCM dispatcher and
#     does NOT need NSSM or WinSW. (Two sibling scripts in this toolkit call New-Service
#     on Go binaries that have no dispatcher; those exporters have never run. This one is
#     genuinely service-capable, and step 1b proves it on this host rather than trusting
#     the source read.)
#  5. SERVICE RE-CREATION IS NO LONGER RACY OR SILENT (was P1-2, old lines 127-129).
#     sc.exe delete only MARKS a service for deletion. The script now polls for the
#     service to actually disappear (up to 60s) and hard-fails if it does not, instead of
#     sleeping 2 seconds, letting New-Service fail silently, and then starting the OLD
#     binary with the OLD binPath while logging OK. If the existing service already has
#     the right binPath, it is reconfigured in place instead of deleted.
#  6. NO SIDE EFFECT BEFORE THE THING IT SUPPORTS EXISTS. The inbound firewall rule is
#     created only after /metrics has answered 200. -RemoteAddress scopes it to the
#     Prometheus servers (default Any, with a WARN), and -BindAddress can pin the listener.
#  7. IDEMPOTENT AND UPGRADE-SAFE (was P2-6/obs-#10). The collector file used to be written
#     only when absent (so metric fixes never landed) while sql_exporter.yml was clobbered
#     every run (so operator edits vanished). Now both are content-compared: unchanged
#     files are left alone, changed ones are backed up to <name>.bak-<timestamp>. -Force
#     rewrites unconditionally. -ConfigFile is respected and -DSN/-Sql* are refused
#     alongside it rather than silently ignored.
#  8. COLLECTOR SQL FIXED (was P3-1/obs-#8/#9). mssql_buffer_cache_hit_ratio now divides by
#     its base counter and is a real percentage instead of a raw ~600 counter value;
#     mssql_database_size_mb filters type = 0 so log files stop being reported as data.
#     mssql_up is retained as the liveness metric the /metrics probe asserts on.
#  9. UNHANDLED-EXCEPTION GUARD + TEMP CLEANUP (was P2-1). Expand-Archive throws on a
#     corrupt zip; that used to leave no [END] line, an open transcript and a leaked GUID
#     directory in %TEMP%. All paths now reach Stop-YcLog and clean up.
# 10. OPTIONAL ONLINE INSTALL, DONE SAFELY. -DownloadUrl / -Sha256 set TLS 1.2 first,
#     verify the payload really is a ZIP (PK\x03\x04 magic bytes, not an HTML error page
#     saved with a .zip extension), and optionally pin the SHA256. The installed version
#     is always reported from 'sql_exporter.exe -version'.
#
# PARAMETERS ADDED (none renamed, none removed):
#     -SqlPasswordFile, -Encrypt, -ServiceName, -RemoteAddress, -BindAddress, -ZipPath,
#     -DownloadUrl, -Sha256, -SkipFirewall, -Force
#
# Log: C:\Scripts\sqlexporter-register.log
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'sqlexporter-register'
$ErrorActionPreference = 'Stop'

$HelpText = @"
sqlexporter-register - install burningalchemist sql_exporter (Prometheus MSSQL exporter) as a
                       Windows service, validate the config with the vendor's own validator,
                       and prove /metrics answers before adding a firewall rule.

USAGE:
  sqlexporter-register -SqlUser <u> -SqlPasswordFile <file> [-SqlServer localhost] [-SqlPort 1433]
                       [-Database master] [-ListenPort 9399] [-Encrypt true]
  sqlexporter-register -TrustedAuth [-SqlServer localhost] [-ListenPort 9399]
  sqlexporter-register -ConfigFile C:\Scripts\sql_exporter.yml
  sqlexporter-register -DSN '<full go-mssqldb URL DSN>'
  sqlexporter-register -Help

PARAMETERS:
  -SqlUser          SQL auth login (a least-privilege monitoring login with VIEW SERVER STATE).
  -SqlPasswordFile  PREFERRED. File whose first line is the password. Never appears in the
                    process table, in a 4688 event, or in the transcript header.
  -SqlPassword      DEPRECATED, kept for compatibility. The value is visible in
                    Win32_Process.CommandLine and in Windows event 4688 for the life of the
                    process, and in the transcript header. Use -SqlPasswordFile or the
                    environment variable YC_SQLEXPORTER_PASSWORD instead. When used, the
                    value is scrubbed from the log file at the end of the run.
  -TrustedAuth      Windows integrated auth (authenticator=winsspi). The identity is the
                    SERVICE account: LocalSystem presents the computer account. Create a login for
                    it (the machine account) with VIEW SERVER STATE, or the exporter will
                    start and collect nothing.
  -SqlServer        Host, or HOST\INSTANCE for a named instance. Default localhost.
  -SqlPort          TCP port. Default 1433. Ignored when a named instance is given without an
                    explicit -SqlPort (SQL Browser resolves the port).
  -Database         Initial database. Default master.
  -Encrypt          true (default) | false | disable | strict. true also sets
                    trustservercertificate=true, which is appropriate for a self-signed
                    same-host certificate. 'disable' puts every query and result set on the
                    wire in cleartext - do not ship it.
  -DSN              Full go-mssqldb URL DSN; overrides the -Sql* builders. Mutually exclusive
                    with -ConfigFile.
  -ConfigFile       Use an existing sql_exporter.yml verbatim. Mutually exclusive with -DSN
                    and the -Sql* builders (the old version silently ignored them).
  -ListenPort       Scrape port. Default 9399.
  -BindAddress      Listen address. Default '' = all interfaces. Set 127.0.0.1 to keep
                    /metrics local-only.
  -RemoteAddress    Sources allowed through the inbound rule. Default Any (logged at WARN).
                    Pass your Prometheus servers, e.g. -RemoteAddress 10.0.0.5,10.0.0.6
  -SkipFirewall     Do not create an inbound rule at all.
  -ServiceName      Windows service name. Default sql_exporter.
  -InstallDir       Install folder. Default C:\Program Files\sql_exporter.
  -ZipPath          Explicit staged sql_exporter zip. Default: newest
                    C:\Scripts\sql_exporter-*windows-amd64.zip by parsed version.
  -DownloadUrl      Optional. Download the release zip over TLS 1.2 instead of using a staged
                    one. The payload is checked for ZIP magic bytes before use.
  -Sha256           Expected SHA256 of the zip (staged or downloaded). Strongly recommended.
  -Force            Rewrite sql_exporter.yml and the collector file even if unchanged.
  -Help             Show this help and exit 0.

EXAMPLES:
  sqlexporter-register -SqlUser mon -SqlPasswordFile C:\Scripts\.sqlexporter.pw
  sqlexporter-register -TrustedAuth -RemoteAddress 10.20.0.11
  sqlexporter-register -SqlServer db01\SQL2022 -SqlUser mon -SqlPasswordFile C:\Scripts\.pw
  sqlexporter-register -ConfigFile C:\Scripts\sql_exporter.yml -ListenPort 9399
  sqlexporter-register -Help

PROOF PERFORMED (in this order):
  1. sql_exporter.exe -version                          -> version recorded in the log
  2. sql_exporter.exe -config.file <cfg> -config.check  -> vendor validator, BEFORE the service
  3. Get-Service <name>.Status -eq 'Running', polled, then re-checked after a settle window
  4. HTTP GET http://127.0.0.1:<port>/metrics -> 200, body is Prometheus text and contains
     mssql_up (or, with -ConfigFile, at least one '# HELP' line)
  5. only then is the inbound firewall rule created

EXIT CODES:
  0  Verified: service Running and /metrics returned 200 with the expected metric present.
  1  Failure at any step (no installer, bad config, service not created, not Running,
     /metrics unreachable or missing the expected metric).
  2  Usage error (missing/contradictory parameters, -SqlUser with no password).
  5  Not elevated (from _yc-lib Assert-YcPrereqs).
  6  No outbound internet when -DownloadUrl was used (from _yc-lib Assert-YcPrereqs).

Log: C:\Scripts\sqlexporter-register.log   Exporter log: <InstallDir>\sql_exporter.log
"@

if($Help){ Write-Host $HelpText -ForegroundColor Cyan; Stop-YcLog 0; exit 0 }
if(-not $DSN -and -not $SqlUser -and -not $TrustedAuth -and -not $ConfigFile){
  Write-Host $HelpText -ForegroundColor Cyan
  Write-YcLog 'One of -SqlUser, -TrustedAuth, -DSN or -ConfigFile is required.' 'ERROR'
  Stop-YcLog 2; exit 2
}

Assert-YcPrereqs -NeedAdmin
$script:YcExit   = 1
$script:YcTemp       = $null
$script:YcSecret     = $null
$script:YcDownloaded = $null

# ------------------------------------------------------------------ helpers

function Write-YcAsciiFile{
  param([string]$Path,[string]$Content)
  # ASCII, LF->CRLF normalised, no BOM. Out-File -Encoding ascii is fine for the byte set
  # we emit but always appends a trailing newline; that is harmless for YAML.
  $sw = New-Object System.IO.StreamWriter($Path,$false,(New-Object System.Text.ASCIIEncoding))
  try{ $sw.Write($Content) } finally{ $sw.Close() }
}

# Run a native executable, capture stdout+stderr and the exit code, without
# $ErrorActionPreference='Stop' turning redirected stderr into a NativeCommandError throw.
function Invoke-YcNative{
  param([string]$File,[string[]]$Arguments)
  $ErrorActionPreference = 'Continue'      # function scope only
  $out = & $File @Arguments 2>&1
  $rc  = $LASTEXITCODE
  $txt = @()
  foreach($o in $out){ if($o -ne $null){ $txt += ([string]$o) } }
  return (New-Object psobject -Property @{ Output = $txt; ExitCode = $rc })
}

function Protect-YcFileAcl{
  param([string]$Path)
  # https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/icacls
  # SID form (*S-1-5-18 / *S-1-5-32-544) so this works on a non-English Windows too.
  $r1 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/inheritance:r')
  $r2 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/grant','*S-1-5-18:(F)','*S-1-5-32-544:(F)')
  if($r1.ExitCode -ne 0 -or $r2.ExitCode -ne 0){
    Write-YcLog ('icacls failed on ' + $Path + ' (inheritance rc=' + $r1.ExitCode +
      ', grant rc=' + $r2.ExitCode + '): ' + (($r1.Output + $r2.Output) -join ' ')) 'ERROR'
    return $false
  }
  # PROVE the ACL: no inheritance, and no trustee other than SYSTEM / Administrators.
  $allowed = @('S-1-5-18','S-1-5-32-544')
  $acl = Get-Acl -LiteralPath $Path
  if(-not $acl.AreAccessRulesProtected){
    Write-YcLog ('VERIFICATION FAILED: inheritance is still enabled on ' + $Path) 'ERROR'
    return $false
  }
  $bad = @()
  foreach($ace in $acl.Access){
    $sid = $null
    try{
      $sid = $ace.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
    }catch{ $sid = [string]$ace.IdentityReference }
    if($allowed -notcontains $sid){ $bad += ([string]$ace.IdentityReference + ' (' + $sid + ')') }
  }
  if($bad.Count -gt 0){
    Write-YcLog ('VERIFICATION FAILED: ' + $Path + ' is still accessible to: ' +
      ($bad -join ', ') + '. It contains a database password.') 'ERROR'
    return $false
  }
  Write-YcLog ('ACL verified on ' + $Path + ': inheritance removed, trustees are exactly ' +
    'SYSTEM and BUILTIN\Administrators.') 'OK'
  return $true
}

function Get-YcSqlExporterPassword{
  if($SqlPasswordFile){
    if(-not (Test-Path -LiteralPath $SqlPasswordFile)){
      Write-YcLog ('-SqlPasswordFile not found: ' + $SqlPasswordFile) 'ERROR'
      return $null
    }
    $lines = Get-Content -LiteralPath $SqlPasswordFile
    $pw = ''
    foreach($l in $lines){ if($l -ne $null -and $l.Trim().Length -gt 0){ $pw = $l.Trim(); break } }
    if($pw.Length -eq 0){
      Write-YcLog ('-SqlPasswordFile ' + $SqlPasswordFile + ' is empty.') 'ERROR'
      return $null
    }
    Write-YcLog ('Password read from ' + $SqlPasswordFile + ' (never on a command line).')
    return $pw
  }
  if($env:YC_SQLEXPORTER_PASSWORD){
    Write-YcLog 'Password read from environment variable YC_SQLEXPORTER_PASSWORD.'
    return $env:YC_SQLEXPORTER_PASSWORD
  }
  if($SqlPassword){
    Write-YcLog ('-SqlPassword was passed on the command line. That value is visible in ' +
      'Win32_Process.CommandLine, in Windows Security event 4688 (this estate enables ' +
      'ProcessCreationIncludeCmdLine and forwards Security off-box) and in the PowerShell ' +
      'transcript header. Use -SqlPasswordFile or YC_SQLEXPORTER_PASSWORD instead. The ' +
      'value will be scrubbed from this log at the end of the run.') 'WARN'
    return $SqlPassword
  }
  return $null
}

function New-YcMssqlDsn{
  param([string]$Server,[int]$Port,[bool]$PortExplicit,[string]$User,[string]$Password,
        [string]$Db,[bool]$Trusted,[string]$EncryptMode)
  $host_ = $Server
  $inst  = $null
  if($Server -like '*\*'){
    $parts = $Server.Split('\',2)
    $host_ = $parts[0]
    $inst  = $parts[1]
  }
  $auth = ''
  if(-not $Trusted){
    $auth = [uri]::EscapeDataString($User) + ':' + [uri]::EscapeDataString($Password) + '@'
  }
  $authority = $host_
  if($inst){
    # sqlserver://host/instance - the documented named-instance form. A port is only
    # appended when the caller explicitly asked for one; otherwise SQL Browser resolves it.
    if($PortExplicit){ $authority = $host_ + ':' + $Port }
    $authority = $authority + '/' + [uri]::EscapeDataString($inst)
  }else{
    $authority = $host_ + ':' + $Port
  }
  $q = @('database=' + [uri]::EscapeDataString($Db))
  $q += ('encrypt=' + $EncryptMode)
  if($EncryptMode -eq 'true'){ $q += 'trustservercertificate=true' }
  if($Trusted){ $q += 'authenticator=winsspi' }
  $q += 'app+name=YallaCloud+sql_exporter'
  return ('sqlserver://' + $auth + $authority + '?' + ($q -join '&'))
}

function Get-YcRedacted([string]$Text){
  if($script:YcSecret){ return ($Text -replace [regex]::Escape($script:YcSecret),'***REDACTED***') }
  return $Text
}

# Write a file only when the content differs; back up what was there. Idempotent.
function Set-YcManagedFile{
  param([string]$Path,[string]$Content,[switch]$Always)
  if(Test-Path -LiteralPath $Path){
    $cur = Get-Content -LiteralPath $Path -Raw
    if($cur -eq $Content -and -not $Always){
      Write-YcLog ('Unchanged, left in place: ' + $Path)
      return $true
    }
    if($cur -ne $Content){
      $bak = $Path + '.bak-' + (Get-Date).ToString('yyyyMMddHHmmss')
      Copy-Item -LiteralPath $Path -Destination $bak -Force
      Write-YcLog ('Content changed; previous file backed up to ' + $bak) 'WARN'
    }
  }
  Write-YcAsciiFile -Path $Path -Content $Content
  Write-YcLog ('Wrote ' + $Path)
  return $true
}

function Test-YcZipMagic([string]$Path){
  $fs = [System.IO.File]::OpenRead($Path)
  try{
    $b = New-Object byte[] 4
    $n = $fs.Read($b,0,4)
    if($n -lt 4){ return $false }
    return ($b[0] -eq 0x50 -and $b[1] -eq 0x4B -and $b[2] -eq 0x03 -and $b[3] -eq 0x04)
  }finally{ $fs.Close() }
}

function Get-YcExporterZip{
  if($ZipPath){
    if(-not (Test-Path -LiteralPath $ZipPath)){
      Write-YcLog ('-ZipPath not found: ' + $ZipPath) 'ERROR'; return $null
    }
    return (Get-Item -LiteralPath $ZipPath)
  }
  if($DownloadUrl){
    Assert-YcPrereqs -NeedInternet
    [Net.ServicePointManager]::SecurityProtocol =
      [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $dst = Join-Path $env:TEMP ('sql_exporter_' + [guid]::NewGuid().ToString('N') + '.zip')
    Write-YcLog ('Downloading ' + $DownloadUrl + ' (TLS 1.2) -> ' + $dst)
    Invoke-WebRequest -Uri $DownloadUrl -OutFile $dst -UseBasicParsing -TimeoutSec 300
    if(-not (Test-Path -LiteralPath $dst)){
      Write-YcLog 'Download produced no file.' 'ERROR'; return $null
    }
    $len = (Get-Item -LiteralPath $dst).Length
    if(-not (Test-YcZipMagic $dst)){
      $head = ''
      try{ $head = (Get-Content -LiteralPath $dst -TotalCount 3) -join ' ' }catch{}
      Remove-Item -LiteralPath $dst -Force
      Write-YcLog ('Downloaded file is NOT a zip archive (no PK\x03\x04 magic, ' + $len +
        ' bytes). First bytes: "' + $head + '". This is almost certainly an HTML error ' +
        'or proxy page saved with a .zip extension. Aborting.') 'ERROR'
      return $null
    }
    Write-YcLog ('Download verified as a real ZIP archive (' + $len + ' bytes).') 'OK'
    $script:YcDownloaded = $dst
    return (Get-Item -LiteralPath $dst)
  }
  $all = Get-ChildItem -Path 'C:\Scripts\sql_exporter-*windows-amd64.zip' -File -ErrorAction Ignore
  if(-not $all){ return $null }
  # Parse the version out of the name so 0.10.0 does not lose to 0.9.0 in a string sort.
  $pick = $all | Sort-Object {
      $m = [regex]::Match($_.Name,'(\d+\.\d+\.\d+)')
      if($m.Success){ [version]$m.Groups[1].Value } else { [version]'0.0.0' }
    } -Descending | Select-Object -First 1
  return $pick
}

function Get-YcServiceObject([string]$Name){
  return (Get-Service | Where-Object { $_.Name -eq $Name } | Select-Object -First 1)
}

function Remove-YcServiceAndWait{
  param([string]$Name,[int]$TimeoutSec = 60)
  $svc = Get-YcServiceObject $Name
  if(-not $svc){ return $true }
  if($svc.Status -ne 'Stopped'){
    Write-YcLog ('Stopping existing service ' + $Name + '...')
    try{ Stop-Service -Name $Name -Force -ErrorAction Stop }
    catch{ Write-YcLog ('Stop-Service ' + $Name + ' failed: ' + $_.Exception.Message) 'WARN' }
  }
  $d = Invoke-YcNative -File 'sc.exe' -Arguments @('delete',$Name)
  if($d.ExitCode -ne 0){
    Write-YcLog ('sc.exe delete ' + $Name + ' returned ' + $d.ExitCode + ': ' +
                 ($d.Output -join ' ')) 'WARN'
  }
  # sc.exe delete only MARKS for deletion. Poll until it is really gone.
  $deadline = (Get-Date).AddSeconds($TimeoutSec)
  while((Get-Date) -lt $deadline){
    if(-not (Get-YcServiceObject $Name)){
      Write-YcLog ('Service ' + $Name + ' removed.')
      return $true
    }
    Start-Sleep -Seconds 2
  }
  Write-YcLog ('Service ' + $Name + ' is still present ' + $TimeoutSec + 's after sc.exe ' +
    'delete (deletion pending - something holds an open handle, e.g. services.msc). ' +
    'Close it and re-run; refusing to continue and start the OLD binary.') 'ERROR'
  return $false
}

function Invoke-YcMetricsProbe{
  param([int]$Port,[string]$MustContain,[int]$TimeoutSec = 20)
  $url = 'http://127.0.0.1:' + $Port + '/metrics'
  $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec $TimeoutSec
  if($r.StatusCode -ne 200){
    Write-YcLog ('VERIFICATION FAILED: ' + $url + ' returned HTTP ' + $r.StatusCode + '.') 'ERROR'
    return $false
  }
  $body = [string]$r.Content
  if($body -notmatch '(?m)^# HELP '){
    Write-YcLog ('VERIFICATION FAILED: ' + $url + ' returned 200 but the body is not ' +
      'Prometheus exposition text (no "# HELP" line).') 'ERROR'
    return $false
  }
  if($MustContain -and ($body -notmatch [regex]::Escape($MustContain))){
    Write-YcLog ('VERIFICATION FAILED: ' + $url + ' answered 200 with Prometheus text but ' +
      'metric "' + $MustContain + '" is absent. The exporter is running but is NOT ' +
      'collecting from SQL Server - check the DSN, the monitoring login and its VIEW ' +
      'SERVER STATE grant. Exporter log: ' + (Join-Path $InstallDir 'sql_exporter.log')) 'ERROR'
    return $false
  }
  $names = ($body -split "`n" | Where-Object { $_ -like '# HELP *' }).Count
  Write-YcLog ('VERIFIED: GET ' + $url + ' -> 200, ' + $body.Length + ' bytes, ' + $names +
    ' metric families' + $(if($MustContain){ ', "' + $MustContain + '" present' }else{ '' }) + '.') 'OK'
  return $true
}

# ------------------------------------------------------------------ main

function Invoke-Main{

  # --- 0. usage validation ----------------------------------------------------------
  if($ConfigFile -and ($DSN -or $SqlUser -or $TrustedAuth)){
    Write-YcLog ('-ConfigFile is exclusive: -DSN / -SqlUser / -TrustedAuth would be silently ' +
      'ignored, so they are refused instead. Pick one.') 'ERROR'
    $script:YcExit = 2; return
  }
  if($DSN -and ($SqlUser -or $TrustedAuth)){
    Write-YcLog '-DSN is exclusive with -SqlUser / -TrustedAuth.' 'ERROR'
    $script:YcExit = 2; return
  }
  if($SqlUser -and $TrustedAuth){
    Write-YcLog '-SqlUser and -TrustedAuth are mutually exclusive.' 'ERROR'
    $script:YcExit = 2; return
  }
  if($ListenPort -lt 1 -or $ListenPort -gt 65535){
    Write-YcLog ('-ListenPort ' + $ListenPort + ' is out of range.') 'ERROR'
    $script:YcExit = 2; return
  }

  $pw = $null
  if($SqlUser){
    $pw = Get-YcSqlExporterPassword
    if(-not $pw){
      Write-YcLog ('-SqlUser "' + $SqlUser + '" was given with no password. The old script ' +
        'built sqlserver://' + $SqlUser + ':@host/... , started the exporter, failed every ' +
        'scrape and reported OK. Supply -SqlPasswordFile <file>, set ' +
        'YC_SQLEXPORTER_PASSWORD, or (not recommended) pass -SqlPassword.') 'ERROR'
      $script:YcExit = 2; return
    }
    $script:YcSecret = $pw
  }
  if($Encrypt -eq 'disable'){
    Write-YcLog ('-Encrypt disable sends every query and result set to SQL Server in ' +
      'cleartext. Only acceptable for a same-host loopback connection you have separately ' +
      'reasoned about.') 'WARN'
  }

  # --- 1. installer ------------------------------------------------------------------
  $zip = Get-YcExporterZip
  if(-not $zip){
    Write-YcLog ('No sql_exporter installer. Stage C:\Scripts\sql_exporter-<ver>-windows-amd64.zip, ' +
      'or pass -ZipPath <file>, or -DownloadUrl <release zip url>.') 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Test-YcZipMagic $zip.FullName)){
    Write-YcLog ($zip.FullName + ' is not a ZIP archive (no PK\x03\x04 magic). Refusing to ' +
      'extract it.') 'ERROR'
    $script:YcExit = 1; return
  }
  $zipHash = (Get-FileHash -Path $zip.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
  if($Sha256){
    if($zipHash -ne $Sha256.Trim().ToUpperInvariant()){
      Write-YcLog ('SHA256 MISMATCH on ' + $zip.Name + ': expected ' +
        $Sha256.Trim().ToUpperInvariant() + ', got ' + $zipHash + '. Refusing to install.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('SHA256 verified: ' + $zipHash) 'OK'
  }else{
    Write-YcLog ('No -Sha256 pin supplied. Installed archive hash is ' + $zipHash +
      ' - pin this value on the next run.') 'WARN'
  }

  if(-not (Test-Path -LiteralPath $InstallDir)){
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
  }
  $script:YcTemp = Join-Path $env:TEMP ('sqlexp_' + [guid]::NewGuid().ToString('N'))
  Write-YcLog ('Extracting ' + $zip.Name + ' -> ' + $script:YcTemp)
  Expand-Archive -Path $zip.FullName -DestinationPath $script:YcTemp -Force
  $src = Get-ChildItem -Path $script:YcTemp -Recurse -Filter 'sql_exporter.exe' -File |
         Select-Object -First 1
  if(-not $src){
    Write-YcLog ('sql_exporter.exe not found inside ' + $zip.Name + '.') 'ERROR'
    $script:YcExit = 1; return
  }
  $exePath = Join-Path $InstallDir 'sql_exporter.exe'

  # Upgrade over an existing install: the running service holds the binary open.
  $existing = Get-YcServiceObject $ServiceName
  if($existing -and $existing.Status -eq 'Running'){
    Write-YcLog ('Existing service ' + $ServiceName + ' is Running; stopping it to replace ' +
      'the binary (upgrade path).')
    Stop-Service -Name $ServiceName -Force -ErrorAction Stop
    Start-Sleep -Seconds 2
  }
  Copy-Item -LiteralPath $src.FullName -Destination $exePath -Force
  if(-not (Test-Path -LiteralPath $exePath)){
    Write-YcLog ('Copy of sql_exporter.exe to ' + $exePath + ' did not produce a file.') 'ERROR'
    $script:YcExit = 1; return
  }

  # --- 2. PROOF: the binary runs and reports its version -----------------------------
  $ver = Invoke-YcNative -File $exePath -Arguments @('-version')
  $verLine = ($ver.Output | Where-Object { $_.Trim().Length -gt 0 } | Select-Object -First 1)
  if($ver.ExitCode -ne 0 -and -not $verLine){
    Write-YcLog ('sql_exporter.exe -version failed (exit ' + $ver.ExitCode + '). The extracted ' +
      'binary is not runnable on this host.') 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Installed binary: ' + $exePath + ' -- ' + ([string]$verLine).Trim()) 'OK'

  # --- 3. configuration --------------------------------------------------------------
  $cfgPath = Join-Path $InstallDir 'sql_exporter.yml'
  $colPath = Join-Path $InstallDir 'mssql_standard.collector.yml'
  $probeMetric = 'mssql_up'

  if($ConfigFile){
    if(-not (Test-Path -LiteralPath $ConfigFile)){
      Write-YcLog ('-ConfigFile not found: ' + $ConfigFile) 'ERROR'
      $script:YcExit = 1; return
    }
    $supplied = Get-Content -LiteralPath $ConfigFile -Raw
    Set-YcManagedFile -Path $cfgPath -Content $supplied -Always:$Force | Out-Null
    $probeMetric = ''   # unknown collector: assert Prometheus text only
    Write-YcLog ('Using supplied config ' + $ConfigFile + '. The /metrics probe will assert ' +
      'Prometheus exposition text but cannot assert a specific metric name.') 'WARN'
  }else{
    $portExplicit = $PSBoundParameters.ContainsKey('SqlPort')
    $effectiveDsn = $DSN
    if(-not $effectiveDsn){
      $effectiveDsn = New-YcMssqlDsn -Server $SqlServer -Port $SqlPort -PortExplicit $portExplicit `
                        -User $SqlUser -Password $pw -Db $Database -Trusted ([bool]$TrustedAuth) `
                        -EncryptMode $Encrypt
    }
    if($TrustedAuth){
      Write-YcLog ('Windows integrated auth selected (authenticator=winsspi). The exporter ' +
        'service runs as LocalSystem, so SQL Server sees the machine account. Create that ' +
        'login and grant it VIEW SERVER STATE, or every scrape will fail.') 'WARN'
    }
    Write-YcLog ('DSN built (credentials redacted): ' + (Get-YcRedacted $effectiveDsn))
    # YAML single-quoted scalar: a literal apostrophe must be doubled. The credential path
    # cannot produce one ([uri]::EscapeDataString emits %27 per RFC 3986 on .NET 4.5+), but
    # a caller-supplied -DSN can, and an unescaped quote would silently truncate the DSN.
    $dsnYaml = $effectiveDsn -replace "'","''"

    $cfg = @"
# Managed by YallaCloud sqlexporter-register. Regenerated on every run when the content
# changes; the previous file is kept as sql_exporter.yml.bak-<timestamp>.
# This file contains a database password. Its ACL is stripped to SYSTEM + Administrators.
global:
  scrape_timeout_offset: 500ms
  min_interval: 0s
  max_connections: 3
  max_idle_connections: 3
target:
  data_source_name: '$dsnYaml'
  collectors: [mssql_standard]
collector_files:
  - '*.collector.yml'
"@
    $col = @"
# Managed by YallaCloud sqlexporter-register.
collector_name: mssql_standard
metrics:
  - metric_name: mssql_up
    type: gauge
    help: 'Database is reachable (1 = up).'
    values: [up]
    query: 'SELECT 1 AS up'
  - metric_name: mssql_connections
    type: gauge
    help: 'Active user connections.'
    values: [connections]
    query: 'SELECT COUNT(*) AS connections FROM sys.dm_exec_sessions WHERE is_user_process = 1'
  - metric_name: mssql_batch_requests_total
    type: counter
    help: 'Cumulative SQL batch requests since instance startup.'
    values: [cntr_value]
    query: "SELECT cntr_value FROM sys.dm_os_performance_counters WHERE counter_name = 'Batch Requests/sec' AND object_name LIKE '%SQL Statistics%'"
  - metric_name: mssql_buffer_cache_hit_ratio
    type: gauge
    help: 'Buffer cache hit ratio, percent (ratio counter divided by its base counter).'
    values: [ratio]
    query: |
      SELECT CAST(ISNULL(100.0
                  * MAX(CASE WHEN counter_name = 'Buffer cache hit ratio' THEN cntr_value END)
                  / NULLIF(MAX(CASE WHEN counter_name = 'Buffer cache hit ratio base' THEN cntr_value END), 0)
                  , 0) AS DECIMAL(9,4)) AS ratio
      FROM sys.dm_os_performance_counters
      WHERE object_name LIKE '%Buffer Manager%'
        AND counter_name IN ('Buffer cache hit ratio', 'Buffer cache hit ratio base')
  - metric_name: mssql_database_data_size_mb
    type: gauge
    help: 'Database ROWS (data) file size in MB. Log files are excluded (type = 0).'
    key_labels: [database_name]
    values: [size_mb]
    query: "SELECT DB_NAME(database_id) AS database_name, CAST(SUM(size) * 8.0 / 1024 AS DECIMAL(18,2)) AS size_mb FROM sys.master_files WHERE type = 0 GROUP BY database_id"
  - metric_name: mssql_database_log_size_mb
    type: gauge
    help: 'Database LOG file size in MB (type = 1).'
    key_labels: [database_name]
    values: [size_mb]
    query: "SELECT DB_NAME(database_id) AS database_name, CAST(SUM(size) * 8.0 / 1024 AS DECIMAL(18,2)) AS size_mb FROM sys.master_files WHERE type = 1 GROUP BY database_id"
"@
    Set-YcManagedFile -Path $colPath -Content $col -Always:$Force | Out-Null
    Set-YcManagedFile -Path $cfgPath -Content $cfg -Always:$true  | Out-Null
  }

  if(-not (Protect-YcFileAcl -Path $cfgPath)){ $script:YcExit = 1; return }

  # --- 4. PROOF: the VENDOR's validator, before the service is touched ----------------
  # Documented flag: -config.check ("Check configuration and exit"), README + main.go.
  Write-YcLog ('Validating configuration with the vendor validator: "' + $exePath +
               '" -config.file "' + $cfgPath + '" -config.check')
  $chk = Invoke-YcNative -File $exePath -Arguments @('-config.file',$cfgPath,'-config.check')
  foreach($l in $chk.Output){ if($l.Trim().Length -gt 0){ Write-Host ('    ' + (Get-YcRedacted $l)) } }
  if($chk.ExitCode -ne 0){
    Write-YcLog ('VERIFICATION FAILED: sql_exporter -config.check exited ' + $chk.ExitCode +
      '. The configuration is invalid; the service was NOT created or started.') 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog 'Vendor config validation passed (-config.check exit 0).' 'OK'

  # --- 5. service --------------------------------------------------------------------
  # sql_exporter imports github.com/kardianos/minwinsvc, so it implements the Windows
  # service dispatcher natively - no NSSM/WinSW wrapper is required. Step 6 proves it.
  $listen = ':' + $ListenPort
  if($BindAddress){ $listen = $BindAddress + ':' + $ListenPort }
  $bin = '"' + $exePath + '" -config.file "' + $cfgPath + '" -web.listen-address "' + $listen +
         '" -log.file "' + (Join-Path $InstallDir 'sql_exporter.log') + '"'

  $svc = Get-YcServiceObject $ServiceName
  $needCreate = $true
  if($svc){
    $curBin = ''
    $k = 'HKLM:\SYSTEM\CurrentControlSet\Services\' + $ServiceName
    if(Test-Path $k){ try{ $curBin = [string](Get-ItemProperty -Path $k).ImagePath }catch{} }
    if($curBin -eq $bin){
      Write-YcLog ('Service ' + $ServiceName + ' already exists with the correct binPath - ' +
                   'reusing it (idempotent).')
      $needCreate = $false
    }else{
      Write-YcLog ('Service ' + $ServiceName + ' exists with a different binPath; recreating.')
      Write-YcLog ('  old: ' + $curBin)
      Write-YcLog ('  new: ' + $bin)
      if(-not (Remove-YcServiceAndWait -Name $ServiceName)){ $script:YcExit = 1; return }
    }
  }

  if($needCreate){
    try{
      New-Service -Name $ServiceName -BinaryPathName $bin `
                  -DisplayName 'Prometheus sql_exporter (YallaCloud)' `
                  -Description 'Exports SQL Server metrics for Prometheus. Managed by C:\Scripts\SqlExporter-Register.ps1.' `
                  -StartupType Automatic -ErrorAction Stop | Out-Null
    }catch{
      Write-YcLog ('New-Service ' + $ServiceName + ' FAILED: ' + $_.Exception.Message) 'ERROR'
      $script:YcExit = 1; return
    }
    $svc = Get-YcServiceObject $ServiceName
    if(-not $svc){
      Write-YcLog ('VERIFICATION FAILED: service ' + $ServiceName + ' does not exist after ' +
        'New-Service returned.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('Service ' + $ServiceName + ' created.') 'OK'
  }

  # Delayed auto-start: consistent with Setup-Observability.ps1 and sysprep-safe.
  # https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sc-config
  $sc1 = Invoke-YcNative -File 'sc.exe' -Arguments @('config',$ServiceName,'start=','delayed-auto')
  if($sc1.ExitCode -ne 0){
    Write-YcLog ('sc.exe config ' + $ServiceName + ' start= delayed-auto returned ' +
                 $sc1.ExitCode + ': ' + ($sc1.Output -join ' ')) 'WARN'
  }
  # https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-r2-and-2012/cc742019(v=ws.11)
  $sc2 = Invoke-YcNative -File 'sc.exe' `
           -Arguments @('failure',$ServiceName,'reset=','60','actions=','restart/5000/restart/5000/restart/30000')
  if($sc2.ExitCode -ne 0){
    Write-YcLog ('sc.exe failure ' + $ServiceName + ' returned ' + $sc2.ExitCode + ': ' +
                 ($sc2.Output -join ' ')) 'WARN'
  }

  # --- 6. PROOF: the service actually runs and STAYS running --------------------------
  try{
    Start-Service -Name $ServiceName -ErrorAction Stop
  }catch{
    Write-YcLog ('Start-Service ' + $ServiceName + ' FAILED: ' + $_.Exception.Message +
      '. Exporter log: ' + (Join-Path $InstallDir 'sql_exporter.log')) 'ERROR'
    $script:YcExit = 1; return
  }
  $svc = Get-YcServiceObject $ServiceName
  for($i = 0; $i -lt 20 -and $svc.Status -ne 'Running'; $i++){
    Start-Sleep -Seconds 2
    $svc = Get-YcServiceObject $ServiceName
    if(-not $svc){ break }
  }
  if((-not $svc) -or ($svc.Status -ne 'Running')){
    $st = if($svc){ [string]$svc.Status } else { 'absent' }
    Write-YcLog ('VERIFICATION FAILED: service ' + $ServiceName + ' is "' + $st +
      '" after 40s. Exporter log: ' + (Join-Path $InstallDir 'sql_exporter.log')) 'ERROR'
    $script:YcExit = 1; return
  }
  # A Go binary with no service dispatcher is killed by the SCM at ~30s with error 1053.
  # Re-check after the settle window so "Running" means running, not "starting".
  Start-Sleep -Seconds 15
  $svc = Get-YcServiceObject $ServiceName
  if((-not $svc) -or ($svc.Status -ne 'Running')){
    $st = if($svc){ [string]$svc.Status } else { 'absent' }
    Write-YcLog ('VERIFICATION FAILED: service ' + $ServiceName + ' reached Running but is ' +
      'now "' + $st + '" 15s later (the classic no-service-dispatcher / error 1053 pattern, ' +
      'or the exporter crashed on startup). Exporter log: ' +
      (Join-Path $InstallDir 'sql_exporter.log')) 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Service ' + $ServiceName + ' is Running and stayed Running.') 'OK'

  # --- 7. PROOF: /metrics answers and carries a real metric ---------------------------
  $probed = $false
  for($i = 0; $i -lt 6 -and -not $probed; $i++){
    try{
      $probed = Invoke-YcMetricsProbe -Port $ListenPort -MustContain $probeMetric
      if($probed){ break }
    }catch{
      Write-YcLog ('/metrics attempt ' + ($i + 1) + '/6: ' + $_.Exception.Message)
    }
    Start-Sleep -Seconds 5
  }
  if(-not $probed){
    Write-YcLog ('VERIFICATION FAILED: http://127.0.0.1:' + $ListenPort + '/metrics did not ' +
      'return a usable Prometheus response. No firewall rule was created. Exporter log: ' +
      (Join-Path $InstallDir 'sql_exporter.log')) 'ERROR'
    $script:YcExit = 1; return
  }

  # --- 8. side effects ONLY after the thing they support is proven --------------------
  if($SkipFirewall){
    Write-YcLog '-SkipFirewall set: no inbound rule created.'
  }else{
    $rn = 'YallaCloud sql_exporter in ' + $ListenPort
    $existingRule = Get-NetFirewallRule -DisplayName $rn -ErrorAction Ignore
    if($existingRule){
      Write-YcLog ('Inbound firewall rule already present: ' + $rn)
    }else{
      if($RemoteAddress.Count -eq 1 -and $RemoteAddress[0] -eq 'Any'){
        Write-YcLog ('Opening TCP ' + $ListenPort + ' to ANY remote address. /metrics exposes ' +
          'database names and sizes with no TLS and no auth. Pass -RemoteAddress <prometheus ' +
          'hosts> to scope it, or -BindAddress 127.0.0.1 with a local scrape agent.') 'WARN'
      }
      try{
        New-NetFirewallRule -DisplayName $rn -Direction Inbound -Action Allow -Protocol TCP `
          -LocalPort $ListenPort -RemoteAddress $RemoteAddress -Profile Any `
          -Description 'Prometheus scrape of sql_exporter. Managed by YallaCloud.' `
          -ErrorAction Stop | Out-Null
      }catch{
        Write-YcLog ('Firewall rule creation FAILED: ' + $_.Exception.Message + '. The exporter ' +
          'is verified and running but is not reachable from off-box.') 'ERROR'
        $script:YcExit = 1; return
      }
      $chk2 = Get-NetFirewallRule -DisplayName $rn -ErrorAction Ignore
      if(-not $chk2){
        Write-YcLog ('VERIFICATION FAILED: firewall rule "' + $rn + '" does not exist after ' +
          'New-NetFirewallRule returned.') 'ERROR'
        $script:YcExit = 1; return
      }
      Write-YcLog ('Inbound allow verified: TCP ' + $ListenPort + ' from ' +
                   ($RemoteAddress -join ',')) 'OK'
    }
  }

  Write-YcLog ('DONE. ' + $ServiceName + ' Running, config validated by -config.check, ' +
    'http://127.0.0.1:' + $ListenPort + '/metrics returned 200' +
    $(if($probeMetric){ ' with ' + $probeMetric }else{ '' }) + '.') 'OK'
  $script:YcExit = 0
}

try{
  Invoke-Main | Out-Null
}catch{
  Write-YcLog ('UNHANDLED EXCEPTION: ' + (Get-YcRedacted $_.Exception.Message)) 'ERROR'
  if($_.ScriptStackTrace){ Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}finally{
  if($script:YcTemp -and (Test-Path -LiteralPath $script:YcTemp)){
    try{ Remove-Item -LiteralPath $script:YcTemp -Recurse -Force }
    catch{ Write-YcLog ('Could not remove temp dir ' + $script:YcTemp + ': ' + $_.Exception.Message) 'WARN' }
  }
  if($DownloadUrl -and $script:YcDownloaded -and (Test-Path -LiteralPath $script:YcDownloaded)){
    try{ Remove-Item -LiteralPath $script:YcDownloaded -Force }catch{}
  }
}

Stop-YcLog $script:YcExit

# Transcript is closed now, so the log file handle is free. If a password ever reached the
# command line (deprecated -SqlPassword), Start-Transcript recorded it in the "Host
# Application:" header before this script got control. Scrub it from the file on disk.
if($script:YcSecret -and $SqlPassword){
  $logPath = 'C:\Scripts\sqlexporter-register.log'
  try{
    if(Test-Path -LiteralPath $logPath){
      $t = Get-Content -LiteralPath $logPath -Raw
      $n = $t -replace [regex]::Escape($script:YcSecret),'***REDACTED***'
      if($n -ne $t){
        Set-Content -LiteralPath $logPath -Value $n -Encoding Ascii -Force
        Write-Host 'Scrubbed the -SqlPassword value from C:\Scripts\sqlexporter-register.log.'
      }
    }
  }catch{
    Write-Host ('WARNING: could not scrub the password from ' + $logPath + ': ' + $_.Exception.Message)
  }
}

exit $script:YcExit
