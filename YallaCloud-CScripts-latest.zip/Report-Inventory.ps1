param(
  # ---- names preserved from report-inventory.cmd and the catalog ----
  [string]$PostUrl,
  [string]$Tag,
  [switch]$Install,
  [string]$Time = '03:00',
  [switch]$Uninstall,
  [switch]$Help,
  # ---- ADDED in this revision ----
  [string]$OutDir = 'C:\Scripts\inventory-report',   # where the JSON reports are written
  [string]$PostTokenFile                            # file holding a bearer token for -PostUrl
)
# =====================================================================================
# Report-Inventory.ps1 - collect CloudStack instance metadata + guest facts into a JSON
# report, optionally POST it, optionally register the SYSTEM scheduled task that repeats it.
# PowerShell 5.1, ASCII only, unattended. OUTBOUND ONLY - no inbound port is opened.
#
# 2026-08-19: repaired. Added the library guard + Exit-Yc on every path (three bare exits,
#             no Stop-YcLog); the scheduled task is now registered ONLY AFTER a report has
#             actually been produced and verified, and the registration is read back; the
#             report file is PROVEN written and PROVEN to be valid JSON; a failed POST is now
#             a failure instead of a red line and exit 0; free-form cloud metadata and the
#             Windows partial product key are SCRUBBED out of the report; and
#             $ErrorActionPreference='SilentlyContinue' is gone. Added -OutDir and
#             -PostTokenFile.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P0] THE SCHEDULED TASK WAS REGISTERED BEFORE ANYTHING WAS KNOWN TO WORK.
#   Old lines 38-48 ran Register-ScheduledTask 'YC-Inventory' as the FIRST thing -Install
#   did, then printed "Installed scheduled task ... Running once now..." and only then tried
#   to collect. If collection or the POST then failed, the host was left with a SYSTEM task
#   firing at every boot and every night, doing nothing useful, while the deployment log said
#   the inventory feed was installed. That is the same shape as the Acronis incident: the
#   artefacts of a working feature, committed before the feature was proven.
#   NOW: collect -> write -> PROVE the file -> POST (if asked) -> and only then register the
#   task, whose registration is itself read back with Get-ScheduledTask.
#
# [P0] A FAILED POST WAS REPORTED AS SUCCESS.
#   Old lines 158-160 caught the exception, printed "POST failed: ..." in red and then ran
#   'exit 0'. Every collector that consumed this exit code was told the inventory had been
#   delivered. NOW: the POST is retried three times with backoff and a hard failure is
#   exit 12.
#
# [P0] THE REPORT COULD LEAK CREDENTIALS OFF THE BOX.
#   The report embedded the whole 'meta' object from the ConfigDrive meta_data.json. That
#   object is operator-supplied free-form metadata and on OpenStack-style ConfigDrives it can
#   carry admin_pass, injected keys and similar material - which was then written to
#   C:\Scripts\inventory-report\*.json AND POSTed to -PostUrl. It also emitted
#   PartialProductKey for every Windows licence.
#   NOW: every metadata key whose name looks like a credential is replaced with a marker,
#   every remaining string value goes through Protect-YcSecret, and the partial product key
#   is not emitted at all - activation STATUS is what an inventory needs, not key material.
#   A bearer token for -PostUrl is read from -PostTokenFile or the
#   YC_INVENTORY_POST_TOKEN environment variable, so it is never on the command line.
#
# [P1] EVERYTHING WAS -ErrorAction SilentlyContinue.
#   $ErrorActionPreference='SilentlyContinue' at the top of the file meant a broken CIM
#   repository or an unreadable registry hive produced an empty section and no complaint.
#   NOW every collector is wrapped and logs what it could not read. Probing the
#   root\SecurityCenter2 namespace (absent on Server SKUs by design) and Get-MpComputerStatus
#   (absent without Defender) are the two documented exceptions, and both are probes rather
#   than load-bearing reads.
#
# REFERENCES
#   ConfigDrive / NoCloud layout (openstack/latest/meta_data.json, meta-data):
#     https://docs.openstack.org/nova/latest/user/metadata.html
#   CloudStack virtual-router metadata (http://<dhcp-server>/latest/meta-data/...):
#     https://docs.cloudstack.apache.org/en/latest/adminguide/virtual_machines.html#user-data-and-meta-data
#   SoftwareLicensingProduct.LicenseStatus values:
#     https://learn.microsoft.com/en-us/previous-versions/windows/desktop/sppwmi/softwarelicensingproduct
#   Register-ScheduledTask / New-ScheduledTaskPrincipal:
#     https://learn.microsoft.com/en-us/powershell/module/scheduledtasks/register-scheduledtask
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** No report was written. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'report-inventory'
Set-YcTls

$TaskName = 'YC-Inventory'

$Usage = @'
report-inventory  -  collect CloudStack instance metadata + guest facts into JSON.
                     OUTBOUND ONLY: no inbound port is opened and no listener is started.

COLLECTS: instance metadata (instance-id, zone, service offering, public/local IP) AND guest
          facts (SQL Server edition/version/eval, Windows activation status, antivirus,
          backup agent, hardware, disks, network, installed software).

USAGE:
  report-inventory
  report-inventory -PostUrl https://collector.example.com/api [-PostTokenFile C:\Scripts\collector.token]
  report-inventory -Tag ACME
  report-inventory -Install [-PostUrl <u>] [-Tag <t>] [-Time 03:00] [-OutDir <dir>]
  report-inventory -Uninstall
  report-inventory -Help

PARAMETERS:
  -PostUrl        HTTPS collector URL to POST the JSON to (outbound 443). A failed POST is a
                  FAILURE (exit 12), not a red line followed by exit 0.
  -PostTokenFile  File holding a bearer token for -PostUrl. The token may also be supplied in
                  the YC_INVENTORY_POST_TOKEN environment variable. Never put it on the
                  command line: it would be visible in the process table and in 4688 events.
  -Tag            Customer/entity tag stamped into the report.
  -Install        Register the SYSTEM scheduled task YC-Inventory (at startup + daily). The
                  task is registered ONLY AFTER this run has produced a verified report.
  -Time           Daily run time for -Install, HH:mm (default 03:00).
  -Uninstall      Remove the YC-Inventory scheduled task and prove it is gone.
  -OutDir         Where the reports are written. Default C:\Scripts\inventory-report.
  -Help           Show this help and exit.

WHAT IS NOT IN THE REPORT (deliberately):
  free-form cloud metadata keys whose name looks like a credential (admin_pass, *_key,
  *secret*, *token*, *password*) are replaced with a marker, every remaining string value is
  passed through Protect-YcSecret, and the Windows PartialProductKey is not emitted at all.
  This report is written to disk and may be POSTed off the host; it must not carry secrets.

EXAMPLES:
  report-inventory
  report-inventory -PostUrl https://collector.example.com/api -PostTokenFile C:\Scripts\collector.token
  report-inventory -Tag ACME
  report-inventory -Install -Time 03:00 -PostUrl https://collector.example.com/api -Tag ACME
  report-inventory -Uninstall
  report-inventory -Help

PROOF OF SUCCESS (nothing is assumed):
  the JSON file is written, then proven to exist, to be at least 512 bytes, and to PARSE as
  JSON containing this host's name; latest.json is proven to be a copy of it; a -PostUrl POST
  must return a 2xx within its retries; and -Install / -Uninstall are proven by reading the
  scheduled task back with Get-ScheduledTask.

EXIT CODES:
  0   the report was written and verified (and posted / task registered, if asked)
  1   collection or the report write failed
  2   usage error (bad -Time, bad -PostUrl, unreadable -PostTokenFile)
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4   the report file is missing or too small after writing
  5   not running as Administrator
  11  the scheduled task could not be registered or removed, or did not read back
  12  the POST to -PostUrl failed

Log: C:\Scripts\report-inventory.log   Reports: <OutDir>\<HOST>-<stamp>.json + latest.json
     (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

# ------------------------------------------------------------------------------------
# Argument validation - before anything is created or written.
# ------------------------------------------------------------------------------------
if($Time -notmatch '^\s*([01]?\d|2[0-3]):([0-5]\d)\s*$'){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 ('-Time must be HH:mm in 24-hour form, got "' + $Time + '"') 'ERROR'
}
$dailyAt = $null
try{ $dailyAt = [datetime]::ParseExact($Time.Trim(),'H:mm',[Globalization.CultureInfo]::InvariantCulture) }
catch{
  try{ $dailyAt = [datetime]::ParseExact($Time.Trim(),'HH:mm',[Globalization.CultureInfo]::InvariantCulture) }
  catch{ Exit-Yc 2 ('-Time could not be parsed as a time of day: "' + $Time + '"') 'ERROR' }
}

if($PostUrl){
  if($PostUrl -notmatch '(?i)^https?://'){
    Write-Host $Usage -ForegroundColor Cyan
    Exit-Yc 2 ('-PostUrl must be an http(s) URL, got "' + $PostUrl + '"') 'ERROR'
  }
  if($PostUrl -notmatch '(?i)^https://'){
    Write-YcLog ('-PostUrl is PLAIN HTTP. This report contains BIOS serials, IP addressing and the installed software list, and it will cross the network in clear text. Use HTTPS.') 'WARN'
  }
}

$postToken = ''
if($PostTokenFile){
  if(-not (Test-Path -LiteralPath $PostTokenFile)){
    Exit-Yc 2 ('-PostTokenFile not found: ' + $PostTokenFile) 'ERROR'
  }
  $tokRaw = $null
  # Get-Content -Raw returns $null for an EMPTY file, and [string]$null is $null, not '' - so
  # calling .Trim() straight off the pipeline throws instead of reporting "the file is empty".
  try{ $tokRaw = Get-Content -LiteralPath $PostTokenFile -Raw -ErrorAction Stop }
  catch{ Exit-Yc 2 ('-PostTokenFile could not be read: ' + $_.Exception.Message) 'ERROR' }
  if($null -eq $tokRaw){ $tokRaw = '' }
  $postToken = ([string]$tokRaw).Trim()
  if(-not $postToken){ Exit-Yc 2 ('-PostTokenFile is empty: ' + $PostTokenFile) 'ERROR' }
  Write-YcLog ('collector bearer token read from ' + $PostTokenFile + ' (the value is not logged)')
}elseif($env:YC_INVENTORY_POST_TOKEN){
  $postToken = ([string]$env:YC_INVENTORY_POST_TOKEN).Trim()
  Write-YcLog 'collector bearer token taken from the YC_INVENTORY_POST_TOKEN environment variable (it is not on the command line - good)'
}

# ------------------------------------------------------------------------------------
# -Uninstall: remove the task, then PROVE it is gone.
# ------------------------------------------------------------------------------------
if($Uninstall){
  $existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction Ignore
  if(-not $existing){
    Exit-Yc 0 ('scheduled task ' + $TaskName + ' is not registered - nothing to remove') 'OK'
  }
  try{ Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction Stop }
  catch{ Exit-Yc 11 ('could not remove the scheduled task ' + $TaskName + ': ' + $_.Exception.Message) 'ERROR' }
  if(Get-ScheduledTask -TaskName $TaskName -ErrorAction Ignore){
    Exit-Yc 11 ('Unregister-ScheduledTask returned without error but ' + $TaskName + ' is STILL registered') 'ERROR'
  }
  Exit-Yc 0 ('scheduled task ' + $TaskName + ' removed and verified gone') 'OK'
}

# ------------------------------------------------------------------------------------
# Redaction. This report leaves the host, so it must not carry credentials.
# ------------------------------------------------------------------------------------
$YcDropKeyRx = '(?i)(password|passwd|admin_pass|adminpass|^pass$|secret|token|apikey|api_key|credential|private|_key$|^key$|keys$|psk|licensekey|productkey)'

function ConvertTo-YcSafeValue{
  param($Value,[int]$Depth = 0)
  if($null -eq $Value){ return $null }
  if($Depth -ge 8){ return '(redacted: nesting depth limit)' }
  if($Value -is [string]){ return (Protect-YcSecret ([string]$Value)) }
  if($Value -is [bool] -or $Value -is [int] -or $Value -is [long] -or $Value -is [double] -or $Value -is [decimal] -or $Value -is [datetime]){ return $Value }
  if($Value -is [System.Collections.IDictionary]){
    $o = [ordered]@{}
    foreach($k in @($Value.Keys)){
      $kn = [string]$k
      if($kn -match $YcDropKeyRx){ $o[$kn] = '(redacted by report-inventory: this key can carry a credential)'; continue }
      $o[$kn] = ConvertTo-YcSafeValue -Value $Value[$k] -Depth ($Depth + 1)
    }
    return $o
  }
  if($Value -is [System.Management.Automation.PSCustomObject]){
    $o = [ordered]@{}
    foreach($pr in @($Value.PSObject.Properties)){
      $kn = [string]$pr.Name
      if($kn -match $YcDropKeyRx){ $o[$kn] = '(redacted by report-inventory: this key can carry a credential)'; continue }
      $o[$kn] = ConvertTo-YcSafeValue -Value $pr.Value -Depth ($Depth + 1)
    }
    return $o
  }
  if($Value -is [System.Collections.IEnumerable]){
    $l = @()
    foreach($x in $Value){ $l += (ConvertTo-YcSafeValue -Value $x -Depth ($Depth + 1)) }
    return $l
  }
  return (Protect-YcSecret ([string]$Value))
}

# ------------------------------------------------------------------------------------
# Collectors. Each one reports what it could not read instead of returning silence.
# ------------------------------------------------------------------------------------
function Get-CSMeta {
  $m = [ordered]@{}
  $vols = @()
  try{ $vols = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=5 OR DriveType=2' -ErrorAction Stop) }
  catch{ Write-YcLog ('could not enumerate CD/removable drives for the ConfigDrive: ' + $_.Exception.Message) 'WARN' }
  $ordered = @($vols | Where-Object { $_.VolumeName -match 'config-2|cidata|config' }) +
             @($vols | Where-Object { $_.VolumeName -notmatch 'config-2|cidata|config' })
  foreach($v in $ordered){
    $d = $v.DeviceID
    if(-not $d){ continue }
    $osjson = Join-Path $d 'openstack\latest\meta_data.json'
    $ncmeta = Join-Path $d 'meta-data'
    if(Test-Path -LiteralPath $osjson){
      try{
        $j = Get-Content -LiteralPath $osjson -Raw -ErrorAction Stop | ConvertFrom-Json
        $m['instance-id'] = $j.uuid
        $m['vm-id'] = $j.uuid
        $m['local-hostname'] = $j.hostname
        $m['name'] = $j.name
        if($j.availability_zone){ $m['availability-zone'] = $j.availability_zone }
        # $j.meta is operator-supplied free-form metadata: scrub it, never copy it verbatim.
        if($j.meta){ $m['meta'] = ConvertTo-YcSafeValue -Value $j.meta }
        $m['configdrive-source'] = $osjson
        break
      }catch{ Write-YcLog ('could not read ' + $osjson + ': ' + $_.Exception.Message) 'WARN' }
    }
    elseif(Test-Path -LiteralPath $ncmeta){
      try{
        foreach($ln in (Get-Content -LiteralPath $ncmeta -ErrorAction Stop)){
          if($ln -match '^\s*instance-id\s*:\s*(.+)$'){ $m['instance-id'] = $Matches[1].Trim() }
          if($ln -match '^\s*local-hostname\s*:\s*(.+)$'){ $m['local-hostname'] = $Matches[1].Trim() }
        }
        if($m.Count){ $m['configdrive-source'] = $ncmeta; break }
      }catch{ Write-YcLog ('could not read ' + $ncmeta + ': ' + $_.Exception.Message) 'WARN' }
    }
  }
  $srv = @()
  try{
    $cfg = @(Get-CimInstance Win32_NetworkAdapterConfiguration -ErrorAction Stop | Where-Object { $_.IPEnabled -and $_.DHCPServer })
    foreach($c in $cfg){ if($c.DHCPServer){ $srv += $c.DHCPServer } }
  }catch{ Write-YcLog ('could not read the DHCP server list: ' + $_.Exception.Message) 'WARN' }
  $srv += 'data-server'
  $keys = 'service-offering','availability-zone','local-ipv4','local-hostname','public-ipv4','public-hostname','instance-id','vm-id','cloud-identifier'
  foreach($h in ($srv | Select-Object -Unique)){
    if(-not $h){ continue }
    $base = 'http://' + $h + '/latest/meta-data'
    try{ Invoke-WebRequest -Uri ($base + '/instance-id') -UseBasicParsing -TimeoutSec 3 -ErrorAction Stop | Out-Null }
    catch{ continue }
    foreach($k in $keys){
      try{
        $v = (Invoke-WebRequest -Uri ($base + '/' + $k) -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop).Content
        if($v){
          $val = ([string]$v).Trim()
          if(-not $m[$k]){ $m[$k] = $val }
        }
      }catch{}   # a metadata key the virtual router does not serve is normal, not an error
    }
    $m['vr-source'] = $base
    break
  }
  if($m.Count){
    $src = @()
    if($m['configdrive-source']){ $src += 'configdrive' }
    if($m['vr-source']){ $src += 'vr-http' }
    $m['metadata-source'] = ($src -join '+')
    return $m
  }
  return [ordered]@{ 'metadata-source' = 'unavailable (no ConfigDrive/NoCloud CD and no VR data-server)' }
}

function Get-Activation {
  # PartialProductKey is deliberately NOT emitted - an inventory needs the licence STATUS.
  $st = @{0='Unlicensed';1='Licensed';2='OOB-Grace';3='OOT-Grace';4='NonGenuine-Grace';5='Notification';6='Extended-Grace'}
  $out = @()
  try{
    Get-CimInstance SoftwareLicensingProduct -ErrorAction Stop |
      Where-Object { $_.ApplicationID -eq '55c92734-d682-4d71-983e-d6ec3f16059f' -and $_.PartialProductKey } |
      ForEach-Object { $out += [pscustomobject]@{ Name = $_.Name; Status = $st[[int]$_.LicenseStatus]; StatusCode = [int]$_.LicenseStatus; KeyPresent = $true } }
  }catch{ Write-YcLog ('could not read SoftwareLicensingProduct: ' + $_.Exception.Message) 'WARN' }
  $out
}

function Get-SqlServers {
  $out = @()
  foreach($root in 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Microsoft SQL Server'){
    $instKey = Join-Path $root 'Instance Names\SQL'
    if(-not (Test-Path -LiteralPath $instKey)){ continue }
    $inst = $null
    try{ $inst = Get-ItemProperty -LiteralPath $instKey -ErrorAction Stop }
    catch{ Write-YcLog ('could not read ' + $instKey + ': ' + $_.Exception.Message) 'WARN'; continue }
    foreach($p in ($inst.PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' })){
      $setup = Join-Path $root ([string]$p.Value + '\Setup')
      if(-not (Test-Path -LiteralPath $setup)){ continue }
      try{
        $s = Get-ItemProperty -LiteralPath $setup -ErrorAction Stop
        $out += [pscustomobject]@{ Instance = $p.Name; Edition = $s.Edition; Version = $s.Version; PatchLevel = $s.PatchLevel; IsEvaluation = ([string]$s.Edition -match 'Eval') }
      }catch{ Write-YcLog ('could not read ' + $setup + ': ' + $_.Exception.Message) 'WARN' }
    }
  }
  $out
}

function Get-AV {
  $out = @()
  # root\SecurityCenter2 does not exist on Server SKUs by design: this is a probe.
  try{
    Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop |
      ForEach-Object { $out += [pscustomobject]@{ Name = $_.displayName; ProductState = ('0x{0:X}' -f $_.productState) } }
  }catch{ Write-YcLog 'root\SecurityCenter2 is not present (normal on Server SKUs) - using the service list instead' }
  if(Get-Command Get-MpComputerStatus -ErrorAction Ignore){
    try{
      $d = Get-MpComputerStatus -ErrorAction Stop
      if($d){ $out += [pscustomobject]@{ Name = 'Windows Defender'; ProductState = ('RTP=' + $d.RealTimeProtectionEnabled + ';AV=' + $d.AntivirusEnabled + ';Signatures=' + $d.AntivirusSignatureVersion) } }
    }catch{ Write-YcLog ('Get-MpComputerStatus failed: ' + $_.Exception.Message) 'WARN' }
  }
  try{
    $svc = @(Get-CimInstance Win32_Service -ErrorAction Stop | Where-Object { $_.DisplayName -match 'bitdefender|kaspersky|sophos|mcafee|trend micro|eset|symantec|crowdstrike|sentinelone|carbon black|cylance|webroot' })
    foreach($v in $svc){ $out += [pscustomobject]@{ Name = $v.DisplayName; ProductState = ('service:' + $v.State) } }
  }catch{ Write-YcLog ('could not enumerate services for antivirus detection: ' + $_.Exception.Message) 'WARN' }
  $out
}

function Get-Backup {
  $pat = 'acronis|veeam|commvault|bacula|veritas|backup exec|cloudberry|msp360|arcserve|nakivo|datto|rubrik|duplicati|cobian'
  $out = @()
  try{
    Get-CimInstance Win32_Service -ErrorAction Stop | Where-Object { $_.DisplayName -match $pat } |
      ForEach-Object { $out += [pscustomobject]@{ Name = $_.DisplayName; State = $_.State; Kind = 'service' } }
  }catch{ Write-YcLog ('could not enumerate services for backup-agent detection: ' + $_.Exception.Message) 'WARN' }
  $out
}

function Get-Software {
  $out = @()
  foreach($k in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'){
    try{
      $out += @(Get-ItemProperty -Path $k -ErrorAction Stop | Where-Object { $_.DisplayName } |
        Select-Object @{n='Name';e={$_.DisplayName}},@{n='Version';e={$_.DisplayVersion}},@{n='Publisher';e={$_.Publisher}})
    }catch{ Write-YcLog ('could not enumerate ' + $k + ': ' + $_.Exception.Message) 'WARN' }
  }
  @($out | Sort-Object Name -Unique)
}

# ------------------------------------------------------------------------------------
# Collect.
# ------------------------------------------------------------------------------------
$os = $null; $cs = $null; $bios = $null
try{ $os   = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop }catch{ Write-YcLog ('Win32_OperatingSystem failed: ' + $_.Exception.Message) 'WARN' }
try{ $cs   = Get-CimInstance Win32_ComputerSystem  -ErrorAction Stop }catch{ Write-YcLog ('Win32_ComputerSystem failed: '  + $_.Exception.Message) 'WARN' }
try{ $bios = Get-CimInstance Win32_BIOS            -ErrorAction Stop }catch{ Write-YcLog ('Win32_BIOS failed: '            + $_.Exception.Message) 'WARN' }
if(-not $os -and -not $cs){
  Exit-Yc 1 'neither Win32_OperatingSystem nor Win32_ComputerSystem could be read - the CIM repository on this host is broken and no meaningful inventory can be produced' 'ERROR'
}

if(-not (Test-Path -LiteralPath $OutDir)){
  try{ New-Item -ItemType Directory -Path $OutDir -Force -ErrorAction Stop | Out-Null }
  catch{ Exit-Yc 1 ('could not create ' + $OutDir + ': ' + $_.Exception.Message) 'ERROR' }
}

$csmeta = ConvertTo-YcSafeValue -Value (Get-CSMeta)
$cache  = Join-Path $OutDir 'instance-cache.json'
if(([string]$csmeta['metadata-source']) -like 'unavailable*'){
  if(Test-Path -LiteralPath $cache){
    try{
      $csmeta = ConvertTo-YcSafeValue -Value (Get-Content -LiteralPath $cache -Raw -ErrorAction Stop | ConvertFrom-Json)
      Write-YcLog ('live metadata is unavailable - reusing the cached copy from ' + $cache) 'WARN'
    }catch{ Write-YcLog ('the metadata cache ' + $cache + ' could not be read: ' + $_.Exception.Message) 'WARN' }
  }else{
    Write-YcLog 'no ConfigDrive, no virtual-router metadata and no cache - the cloudstack section of this report will be empty' 'WARN'
  }
}else{
  try{ ($csmeta | ConvertTo-Json -Depth 5) | Set-Content -LiteralPath $cache -Encoding utf8 -ErrorAction Stop }
  catch{ Write-YcLog ('could not update the metadata cache ' + $cache + ': ' + $_.Exception.Message) 'WARN' }
}

$cpuNames = @()
try{ $cpuNames = @(Get-CimInstance Win32_Processor -ErrorAction Stop | ForEach-Object { $_.Name }) }
catch{ Write-YcLog ('Win32_Processor failed: ' + $_.Exception.Message) 'WARN' }
$disks = @()
try{ $disks = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction Stop | ForEach-Object { [pscustomobject]@{ drive = $_.DeviceID; size_gb = [math]::Round($_.Size/1GB,1); free_gb = [math]::Round($_.FreeSpace/1GB,1) } }) }
catch{ Write-YcLog ('the local disk list could not be read: ' + $_.Exception.Message) 'WARN' }
$nics = @()
try{ $nics = @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=TRUE' -ErrorAction Stop | ForEach-Object { [pscustomobject]@{ ip = $_.IPAddress; mac = $_.MACAddress; gateway = $_.DefaultIPGateway; dhcp_server = $_.DHCPServer } }) }
catch{ Write-YcLog ('the network configuration could not be read: ' + $_.Exception.Message) 'WARN' }

$report = [ordered]@{
  tag                = $Tag
  collected_utc      = (Get-Date).ToUniversalTime().ToString('s') + 'Z'
  hostname           = $env:COMPUTERNAME
  report_schema      = 'yallacloud-inventory-2'
  cloudstack         = $csmeta
  os                 = [ordered]@{ caption = $os.Caption; version = $os.Version; build = $os.BuildNumber; installdate = $os.InstallDate }
  activation         = @(Get-Activation)
  sql_servers        = @(Get-SqlServers)
  antivirus          = @(Get-AV)
  backup_agents      = @(Get-Backup)
  hardware           = [ordered]@{ manufacturer = $cs.Manufacturer; model = $cs.Model; cpu = $cpuNames; logical_cpus = $cs.NumberOfLogicalProcessors; ram_gb = $(if($cs){[math]::Round($cs.TotalPhysicalMemory/1GB,1)}else{0}); bios_serial = $bios.SerialNumber }
  disks              = $disks
  network            = $nics
  installed_software = @(Get-Software)
}

# ------------------------------------------------------------------------------------
# Write the report, then PROVE it.
# ------------------------------------------------------------------------------------
$json = ''
try{ $json = $report | ConvertTo-Json -Depth 6 -ErrorAction Stop }
catch{ Exit-Yc 1 ('the report could not be serialised to JSON: ' + $_.Exception.Message) 'ERROR' }

$file = Join-Path $OutDir ($env:COMPUTERNAME + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
try{ $json | Set-Content -LiteralPath $file -Encoding utf8 -ErrorAction Stop }
catch{ Exit-Yc 1 ('could not write ' + $file + ': ' + $_.Exception.Message) 'ERROR' }

if(-not (Assert-YcFile -Path $file -MinBytes 512 -Because 'inventory report' -Fatal)){
  Exit-Yc 4 ('the inventory report was not written: ' + $file) 'ERROR'
}
# A file of the right size is not a valid report: read it back and parse it.
$readback = $null
try{ $readback = Get-Content -LiteralPath $file -Raw -ErrorAction Stop | ConvertFrom-Json }
catch{ Exit-Yc 1 ('the report at ' + $file + ' does not parse as JSON after being written: ' + $_.Exception.Message) 'ERROR' }
if([string]$readback.hostname -ne [string]$env:COMPUTERNAME){
  Exit-Yc 1 ('the report at ' + $file + ' read back with hostname "' + $readback.hostname + '" instead of "' + $env:COMPUTERNAME + '" - it is not this host''s inventory') 'ERROR'
}
$swCount = 0
try{ $swCount = @($readback.installed_software).Count }catch{}
Write-YcLog ('inventory report VERIFIED: ' + $file + ' parses as JSON, hostname ' + $readback.hostname + ', ' + $swCount + ' installed packages') 'OK'

$latest = Join-Path $OutDir 'latest.json'
try{ Copy-Item -LiteralPath $file -Destination $latest -Force -ErrorAction Stop }
catch{ Exit-Yc 1 ('could not update ' + $latest + ': ' + $_.Exception.Message) 'ERROR' }
if(-not (Assert-YcFile -Path $latest -MinBytes 512 -Because 'latest.json')){
  Exit-Yc 1 ('latest.json was not updated: ' + $latest) 'ERROR'
}

# ------------------------------------------------------------------------------------
# POST - and a failure here is a FAILURE.
# ------------------------------------------------------------------------------------
if($PostUrl){
  $safeUrl = Protect-YcSecret $PostUrl
  $headers = @{}
  if($postToken){ $headers['Authorization'] = ('Bearer ' + $postToken) }
  $posted = $false
  $lastErr = 'no attempt was made'
  $delay = 3
  for($attempt = 1; $attempt -le 3; $attempt++){
    try{
      $ip = @{ Uri = $PostUrl; Method = 'Post'; Body = $json; ContentType = 'application/json'; TimeoutSec = 60; UseBasicParsing = $true; ErrorAction = 'Stop' }
      if($headers.Count -gt 0){ $ip['Headers'] = $headers }
      $resp = Invoke-WebRequest @ip
      $code = 0
      try{ $code = [int]$resp.StatusCode }catch{}
      if($code -ge 200 -and $code -lt 300){
        Write-YcLog ('inventory POSTed to ' + $safeUrl + ' - HTTP ' + $code) 'OK'
        $posted = $true
        break
      }
      $lastErr = 'HTTP ' + $code
    }catch{
      $lastErr = $_.Exception.Message
      try{ if($_.Exception.Response){ $lastErr = 'HTTP ' + [int]$_.Exception.Response.StatusCode } }catch{}
    }
    Write-YcLog ('POST attempt ' + $attempt + '/3 to ' + $safeUrl + ' failed: ' + $lastErr) 'WARN'
    if($attempt -lt 3){ Start-Sleep -Seconds $delay; $delay = $delay * 2 }
  }
  if(-not $posted){
    Exit-Yc 12 ('the inventory was collected and written to ' + $file + ' but the POST to ' + $safeUrl +
      ' FAILED after 3 attempts (' + $lastErr + '). The collector has NOT received this report.') 'ERROR'
  }
}

# ------------------------------------------------------------------------------------
# -Install: register the task ONLY NOW - after a report has been produced and proven.
# ------------------------------------------------------------------------------------
if($Install){
  $me = $PSCommandPath
  if(-not $me){ $me = 'C:\Scripts\Report-Inventory.ps1' }
  $arg = '-NoProfile -ExecutionPolicy Bypass -File "' + $me + '"'
  if($PostUrl){       $arg += ' -PostUrl "' + $PostUrl + '"' }
  if($Tag){           $arg += ' -Tag "' + $Tag + '"' }
  if($PostTokenFile){ $arg += ' -PostTokenFile "' + $PostTokenFile + '"' }
  if($OutDir){        $arg += ' -OutDir "' + $OutDir + '"' }
  try{
    $act = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arg -ErrorAction Stop
    $t1  = New-ScheduledTaskTrigger -AtStartup -ErrorAction Stop
    $t2  = New-ScheduledTaskTrigger -Daily -At $dailyAt -ErrorAction Stop
    $prn = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest -ErrorAction Stop
    $set = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ErrorAction Stop
    Register-ScheduledTask -TaskName $TaskName -Action $act -Trigger $t1,$t2 -Principal $prn -Settings $set -Force -ErrorAction Stop | Out-Null
  }catch{
    Exit-Yc 11 ('could not register the scheduled task ' + $TaskName + ': ' + $_.Exception.Message +
      '. The report at ' + $file + ' was still produced.') 'ERROR'
  }
  # PROOF: read the registration back. Register-ScheduledTask not throwing is not proof.
  $t = Get-ScheduledTask -TaskName $TaskName -ErrorAction Ignore
  if(-not $t){
    Exit-Yc 11 ('Register-ScheduledTask returned without error but ' + $TaskName + ' does not read back') 'ERROR'
  }
  $trigCount = 0
  try{ $trigCount = @($t.Triggers).Count }catch{}
  $execOk = $false
  try{ foreach($a in @($t.Actions)){ if([string]$a.Execute -match '(?i)powershell'){ $execOk = $true } } }catch{}
  if($trigCount -lt 2 -or -not $execOk){
    Exit-Yc 11 ('the scheduled task ' + $TaskName + ' read back with ' + $trigCount +
      ' trigger(s) and powershell action present=' + $execOk + ' - expected 2 triggers (at startup + daily) and a powershell.exe action') 'ERROR'
  }
  Write-YcLog ('scheduled task ' + $TaskName + ' registered and VERIFIED: SYSTEM / Highest, ' + $trigCount +
    ' triggers (at startup + daily at ' + $dailyAt.ToString('HH:mm') + '), state ' + $t.State) 'OK'
}

Exit-Yc 0 ('inventory written and verified: ' + $file + $(if($PostUrl){' (POSTed)'}else{''}) + $(if($Install){' (scheduled task YC-Inventory registered and verified)'}else{''})) 'OK'
