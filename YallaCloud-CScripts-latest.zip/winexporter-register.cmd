@echo off
setlocal
rem ================================================================================================
rem winexporter-register - install windows_exporter and PROVE /metrics answers before opening a
rem                        SCOPED firewall rule.  Wrapper for C:\Scripts\WinExporter-Register.ps1.
rem
rem WHAT CHANGED, AND WHY:
rem   - Added "exit /b %ERRORLEVEL%".
rem   - The default collector list no longer contains 'cs', which was REMOVED from windows_exporter:
rem     enabling a removed collector makes the exporter silently fail to start while msiexec still
rem     returns 0, so the old default broke the default invocation on every current release.
rem   - The inbound rule is now scoped (-RemoteAddress, default LocalSubnet; -FirewallProfile,
rem     default Domain,Private) and is created only AFTER /metrics has been proven. It used to be
rem     -Profile Any with no RemoteAddress on a 0.0.0.0 listener.
rem
rem USAGE:
rem   winexporter-register -RemoteAddress <cidr-or-ip[,ip]>
rem   winexporter-register -ListenAddr <mgmt-ip> -ListenPort 9182 -RemoteAddress <cidr>
rem   winexporter-register -Collectors "cpu,cpu_info,memory,logical_disk,net,os,service"
rem   winexporter-register -Help
rem
rem EXIT CODES: 0 verified | 1 failed | 2 usage | 5 not elevated | 6 no internet
rem Log: C:\Scripts\winexporter-register.log
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\WinExporter-Register.ps1" %*
exit /b %ERRORLEVEL%
