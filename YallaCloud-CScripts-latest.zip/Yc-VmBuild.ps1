param(
  [string]$ConfigPath = 'C:\ProgramData\YallaCloud\sqltemplate\yc-build.json',
  [switch]$Report,
  [switch]$SelfCheck,
  [switch]$Help
)
# =====================================================================================
# Yc-VmBuild.ps1 - the build state machine, from DOTNET to DONE.
# PowerShell 5.1 only. ASCII only.
#
# WHY THIS IS IN THE PAYLOAD AND NOT IN THE USERDATA
#   CloudStack caps user data at 32 KB base64 and the whole state machine was eating it -
#   31,688 of 32,768, three per cent left. Worse, a bug in any of it could only be fixed
#   by re-registering user data on every cloud and redeploying, because a VM's user data
#   is frozen the moment it boots. Here, a fix is a payload update.
#   What CANNOT move, and stays in the user data: the gateway repair, the wait for
#   internet, and the payload fetch. Those three are the ones that must work BEFORE a
#   payload exists to contain them.
#
# WHY IT IS COPIED TO ProgramData BEFORE IT RUNS
#   Update-YcScripts wipes C:\Scripts. A build that survives three reboots cannot have
#   its own worker deleted underneath it half way through, and it must not silently
#   change version mid-build either. The bootstrap copies this file once, and the copy is
#   what the scheduled task runs for the rest of the build.
#
# THE STATE MACHINE. Each step writes the NEXT state before it acts, so a reboot, a crash
# or a power cut resumes in the right place and never repeats a finished step.
#   DOTNET -> SQL -> SQLLIC -> SSMS -> LIC -> NOTIFY -> DONE
#   NAME+ done   NAME- failed   NAME~ skipped by profile
#
# GVLK TRAP: after an Evaluation -> Standard edition change Windows sits on Volume:GVLK
# with status Notification and LOOKS activated. LicenseStatus alone is not proof. LIC
# re-checks up to 3 passes and only reports success on Volume:MAK AND Licensed.
#
# EXIT CODES  0 finished or nothing to do   1 a step failed   2 usage   5 not elevated
# Log: the build log named in the config, plus Application event 1600, source YALLACLOUD.
# =====================================================================================
$ErrorActionPreference = 'Continue'

$HelpText = @"
yc-vmbuild - run the VM build state machine from DOTNET to DONE.

  yc-vmbuild                     resume the build described by yc-build.json
  yc-vmbuild -Report             print the config and the state. Changes nothing.
  yc-vmbuild -ConfigPath <file>  use a different config
  yc-vmbuild -SelfCheck          assertions only, no admin, changes nothing

You do not normally run this by hand. The user data bootstrap writes the config, copies
this script to C:\ProgramData\YallaCloud\sqltemplate and registers the scheduled task
that calls it. Running it again after a finished build is harmless - the state is DONE
and it exits immediately.
"@
if ($Help) { Write-Output $HelpText; exit 0 }

# -------------------------------------------------------------------------------------
# The pure decisions, so -SelfCheck can exercise them with no SQL, no network, no admin.
# -------------------------------------------------------------------------------------
function Get-YcNextState {
  <# The order is fixed; this only answers "what comes after X". Kept pure so the skip
     logic below can walk forward without duplicating the sequence in five places. #>
  param([string]$State)
  # UPDPRE and UPDPOST are in the order ALWAYS. Whether either runs is a profile question,
  # not a sequence question - a state that is sometimes absent from the list is a state
  # whose skip cannot be recorded.
  $order = @('UPDPRE','DOTNET','SQL','SQLLIC','SSMS','LIC','UPDPOST','NOTIFY','DONE')
  $i = [array]::IndexOf($order, $State)
  if ($i -lt 0 -or $i -ge ($order.Count - 1)) { return 'DONE' }
  return $order[$i + 1]
}

function Test-YcStateWanted {
  <# Does the profile want this state? The clamps live in the bootstrap, so by the time
     the config reaches here the flags are already coherent. #>
  param([string]$State, $Cfg)
  switch ($State) {
    'UPDPRE'  { return ([bool]$Cfg.InstallWindowsUpdates -and $Cfg.WindowsUpdateWhen -eq 'Before') }
    'UPDPOST' { return ([bool]$Cfg.InstallWindowsUpdates -and $Cfg.WindowsUpdateWhen -ne 'Before') }
    'DOTNET' { return [bool]$Cfg.InstallDotNet }
    'SQL'    { return [bool]$Cfg.InstallSql }
    'SQLLIC' { return ([bool]$Cfg.InstallSql -and [bool]$Cfg.LicenseSql) }
    'SSMS'   { return [bool]$Cfg.InstallSsms }
    'LIC'    { return [bool]$Cfg.LicenseWindows }
    default  { return $true }
  }
}

function Get-YcSqlArgs {
  <# The install-sql command line. Pure, because getting -Maintenance or the retention
     wrong is silent: you get a SQL Server with no backups and a green exit code. #>
  param($Cfg, [string]$PwFile)
  $a = 'C:\Scripts\install-sql.cmd -Version ' + $Cfg.SqlVersion +
       ' -InstanceName ' + $Cfg.InstanceName +
       ' -SaPasswordFile ' + $PwFile + ' -NoReboot' +
       ' -Maintenance ' + $(if ($Cfg.ConfigureSqlBackup) { 'on' } else { 'off' }) +
       ' -Patch ' + $(if ($Cfg.InstallSqlUpdates) { 'on' } else { 'off' })
  if ($Cfg.ConfigureSqlBackup) {
    $a += ' -BackupDir "' + $Cfg.BackupDir + '"' +
          ' -RetainFullDays ' + $Cfg.RetainFullDays +
          ' -RetainDiffDays ' + $Cfg.RetainDiffDays +
          ' -RetainLogDays '  + $Cfg.RetainLogDays +
          ' -MonthlyDir "' + $Cfg.MonthlyDir + '" -MonthlyKeep ' + $Cfg.MonthlyKeep
  }
  return $a
}

if ($SelfCheck) {
  $pass = 0; $fail = 0
  function T($n, $c) { if ($c) { Write-Output ('ok   ' + $n); $script:pass++ } else { Write-Output ('FAIL ' + $n); $script:fail++ } }

  T 'DOTNET -> SQL'      ((Get-YcNextState 'DOTNET') -eq 'SQL')
  T 'SQL -> SQLLIC'      ((Get-YcNextState 'SQL')    -eq 'SQLLIC')
  T 'SQLLIC -> SSMS'     ((Get-YcNextState 'SQLLIC') -eq 'SSMS')
  T 'SSMS -> LIC'        ((Get-YcNextState 'SSMS')   -eq 'LIC')
  T 'UPDPRE -> DOTNET'   ((Get-YcNextState 'UPDPRE')  -eq 'DOTNET')
  T 'LIC -> UPDPOST'     ((Get-YcNextState 'LIC')     -eq 'UPDPOST')
  T 'UPDPOST -> NOTIFY'  ((Get-YcNextState 'UPDPOST') -eq 'NOTIFY')
  T 'NOTIFY -> DONE'     ((Get-YcNextState 'NOTIFY') -eq 'DONE')
  T 'DONE stays DONE'    ((Get-YcNextState 'DONE')   -eq 'DONE')
  T 'nonsense -> DONE'   ((Get-YcNextState 'BANANA') -eq 'DONE')

  $updA = [pscustomobject]@{ InstallWindowsUpdates=$true;  WindowsUpdateWhen='After' }
  $updB = [pscustomobject]@{ InstallWindowsUpdates=$true;  WindowsUpdateWhen='Before' }
  $updN = [pscustomobject]@{ InstallWindowsUpdates=$false; WindowsUpdateWhen='After' }
  T 'updates OFF skips both'  ((-not (Test-YcStateWanted 'UPDPRE' $updN)) -and (-not (Test-YcStateWanted 'UPDPOST' $updN)))
  T 'After runs only UPDPOST' ((-not (Test-YcStateWanted 'UPDPRE' $updA)) -and (Test-YcStateWanted 'UPDPOST' $updA))
  T 'Before runs only UPDPRE' ((Test-YcStateWanted 'UPDPRE' $updB) -and (-not (Test-YcStateWanted 'UPDPOST' $updB)))

  $full = [pscustomobject]@{ InstallDotNet=$true; InstallSql=$true; LicenseSql=$true; InstallSsms=$true; LicenseWindows=$true }
  $win  = [pscustomobject]@{ InstallDotNet=$false; InstallSql=$false; LicenseSql=$false; InstallSsms=$false; LicenseWindows=$true }
  $eval = [pscustomobject]@{ InstallDotNet=$true; InstallSql=$true; LicenseSql=$false; InstallSsms=$true; LicenseWindows=$false }
  T 'SQL-FULL wants SQLLIC'      (Test-YcStateWanted 'SQLLIC' $full)
  T 'WIN-LIC skips SQL'          (-not (Test-YcStateWanted 'SQL' $win))
  T 'WIN-LIC skips DOTNET'       (-not (Test-YcStateWanted 'DOTNET' $win))
  T 'WIN-LIC still wants LIC'    (Test-YcStateWanted 'LIC' $win)
  T 'SQL-EVAL skips SQLLIC'      (-not (Test-YcStateWanted 'SQLLIC' $eval))
  T 'SQL-EVAL still installs SQL'(Test-YcStateWanted 'SQL' $eval)
  T 'SQL-EVAL skips windows lic' (-not (Test-YcStateWanted 'LIC' $eval))
  T 'NOTIFY is never skipped'    (Test-YcStateWanted 'NOTIFY' $win)

  $c = [pscustomobject]@{ SqlVersion='2019'; InstanceName='MSSQLSERVER'; ConfigureSqlBackup=$true
                          BackupDir='D:\bak'; RetainFullDays=35; RetainDiffDays=14; RetainLogDays=14
                          MonthlyDir='D:\mon'; MonthlyKeep=12 }
  $a = Get-YcSqlArgs -Cfg $c -PwFile 'C:\x.txt'
  T 'sql args: maintenance on'   ($a -match '-Maintenance on')
  T 'sql args: retention passed' ($a -match '-RetainFullDays 35' -and $a -match '-RetainLogDays 14')
  T 'sql args: monthly passed'   ($a -match '-MonthlyDir "D:\\mon" -MonthlyKeep 12')
  T 'sql args: instance passed'  ($a -match '-InstanceName MSSQLSERVER')
  T 'sql args: never -Edition'   ($a -notmatch '-Edition')
  $c3 = [pscustomobject]@{ SqlVersion='2019'; InstanceName='X'; ConfigureSqlBackup=$false; InstallSqlUpdates=$true }
  T 'sql args: -Patch on'        ((Get-YcSqlArgs -Cfg $c3 -PwFile 'C:\x') -match '-Patch on')
  $c4 = [pscustomobject]@{ SqlVersion='2019'; InstanceName='X'; ConfigureSqlBackup=$false; InstallSqlUpdates=$false }
  T 'sql args: -Patch off'       ((Get-YcSqlArgs -Cfg $c4 -PwFile 'C:\x') -match '-Patch off')
  $c2 = [pscustomobject]@{ SqlVersion='2019'; InstanceName='X'; ConfigureSqlBackup=$false }
  $a2 = Get-YcSqlArgs -Cfg $c2 -PwFile 'C:\x.txt'
  T 'backup off: maintenance off'($a2 -match '-Maintenance off')
  T 'backup off: no retention'   ($a2 -notmatch 'Retain')

  Write-Output ''
  Write-Output ('SelfCheck: ' + $pass + ' passed, ' + $fail + ' failed')
  if ($fail -gt 0) { exit 1 } else { exit 0 }
}

# -------------------------------------------------------------------------------------
if (-not (Test-Path -LiteralPath $ConfigPath)) { Write-Output ('no config at ' + $ConfigPath); exit 2 }
$Cfg   = (Get-Content -LiteralPath $ConfigPath -Raw) | ConvertFrom-Json
$Base  = Split-Path -Parent $ConfigPath
$Log   = Join-Path $Base 'yc-sqltemplate.log'
$State = Join-Path $Base 'yc-sqltemplate.state'
$Steps = Join-Path $Base 'yc-sqltemplate.steps'
$Task  = 'YC-SqlTemplate'

function L($m){
  Add-Content -Path $Log -Value ('[' + (Get-Date -f 'yyyy-MM-dd HH:mm:ss') + '] ' + $m) -Encoding ascii
  try { Write-EventLog -LogName Application -Source YALLACLOUD -EntryType Information -EventId 1600 -Message ('[yc-vmbuild] ' + $m) -EA SilentlyContinue } catch {}
}
function Get-State { if (Test-Path $State) { (Get-Content $State -TotalCount 1).Trim() } else { 'DOTNET' } }
function Add-Step($t){ Add-Content -Path $Steps -Value $t -Encoding ascii }
function Get-Steps { if (Test-Path $Steps) { ((Get-Content $Steps) -join ' ') } else { '' } }
function Set-State($s, $mark = '+'){
  $prev = Get-State
  if ($prev -ne $s) { Add-Step ($prev + $mark) }
  Set-Content -Path $State -Value $s -Encoding ascii; L ('state -> ' + $s)
}
function Restart-Now($next){ Set-State $next; L 'restarting'; shutdown /r /t 10 /c "yc-vmbuild"; exit 0 }

function Yc-Event($argline) {
  # Never fatal. A webhook that is down must not cost a build.
  if (-not (Test-Path 'C:\Scripts\yc-event.cmd')) { L 'yc-event not present, skipping'; return }
  try { & cmd /c ('C:\Scripts\yc-event.cmd ' + $argline) *>> $Log; L ('yc-event ' + $argline + ' rc=' + $LASTEXITCODE) }
  catch { L ('yc-event failed: ' + $_.Exception.Message) }
}
function Fail($step, $detail) {
  Add-Step ($step + '-')
  L ('FAILED at ' + $step + ': ' + $detail)
  Yc-Event ('-Type vm.deploy.failed -FailedStep ' + $step + ' -ErrorText "' + $detail + '" -Step "' + (Get-Steps) + '"')
  exit 1
}
function Get-WinLic {
  # Not reporting - this is the control flow of LIC. The GVLK trap is decided from it.
  $d = cscript //nologo C:\Windows\System32\slmgr.vbs /dlv 2>&1 | Out-String
  $ch=''; $pk=''; $st=''
  if ($d -match 'Product Key Channel:\s*(.+)') { $ch = $Matches[1].Trim() }
  if ($d -match 'Partial Product Key:\s*(.+)') { $pk = $Matches[1].Trim() }
  if ($d -match 'License Status:\s*(.+)')      { $st = $Matches[1].Trim() }
  return @{ channel=$ch; partial=$pk; status=$st }
}

$s = Get-State
if ($Report) {
  Write-Output ('state   : ' + $s)
  Write-Output ('steps   : ' + (Get-Steps))
  Write-Output ('profile : ' + $Cfg.Profile)
  foreach ($k in @('InstallDotNet','InstallSql','LicenseSql','InstallSsms','LicenseWindows','ConfigureSqlBackup')) {
    Write-Output ('  ' + $k.PadRight(20) + ' = ' + $Cfg.$k)
  }
  Write-Output ('sql     : ' + $Cfg.SqlVersion + ' ' + $Cfg.SqlEdition + ' instance ' + $Cfg.InstanceName)
  Write-Output ('backup  : ' + $Cfg.BackupDir + '  FULL ' + $Cfg.RetainFullDays + 'd DIFF ' + $Cfg.RetainDiffDays + 'd LOG ' + $Cfg.RetainLogDays + 'd  monthly x' + $Cfg.MonthlyKeep)
  exit 0
}

L ('=== yc-vmbuild resuming at ' + $s + ' ===')
L ('PROFILE ' + $Cfg.Profile + ' -> dotnet=' + $Cfg.InstallDotNet + ' sql=' + $Cfg.InstallSql +
   ' sqlLicence=' + $Cfg.LicenseSql + ' ssms=' + $Cfg.InstallSsms + ' windowsLicence=' + $Cfg.LicenseWindows +
   ' sqlBackup=' + $Cfg.ConfigureSqlBackup)

# Walk any leading states the profile does not want, recording each skip.
while ($s -ne 'NOTIFY' -and $s -ne 'DONE' -and -not (Test-YcStateWanted $s $Cfg)) {
  $next = Get-YcNextState $s
  if ($s -eq 'SQLLIC' -and $Cfg.InstallSql) { L 'SQL LEFT ON EVALUATION by profile. This box is NOT licensed for production.' }
  if ($s -eq 'LIC') { L 'WINDOWS LEFT ON ITS TRIAL CHANNEL by profile.' }
  L ($s + ' skipped by profile ' + $Cfg.Profile)
  Set-State $next '~'; $s = $next
}

function Invoke-YcWindowsUpdate($stateName) {
  # NO -Reboot passed to winupdate. It would restart the box itself, from a state that
  # has not been written yet, and the resume would land in the wrong place. The state
  # machine owns every reboot here - that is the only way a resume can be trusted.
  # Updates arrive in waves: a pass installs what it can, reboots, and then MORE become
  # applicable. Three passes, then move on and say so rather than looping forever.
  $pf = Join-Path $Base ('yc-build.' + $stateName + '.passes')
  $p = 0; if (Test-Path $pf) { $p = [int](Get-Content $pf -TotalCount 1) }
  if ($p -ge 3) { L ($stateName + ': 3 update passes done, moving on'); return $false }
  Set-Content -Path $pf -Value ([string]($p + 1)) -Encoding ascii
  L ($stateName + ': winupdate -Security -Install, pass ' + ($p + 1) + ' of 3')
  & cmd /c 'C:\Scripts\winupdate.cmd -Security -Install' *>> $Log
  L ('winupdate rc=' + $LASTEXITCODE)
  # Ask WINDOWS whether it wants a restart rather than inferring it from an exit code.
  $pending = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') -or
             (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')
  if ($pending) { L ($stateName + ': restart pending - taking it, then returning to this state'); return $true }
  return $false
}

if ($s -eq 'UPDPRE') {
  if (Invoke-YcWindowsUpdate 'UPDPRE') { Restart-Now 'UPDPRE' }
  Set-State 'DOTNET'; $s = 'DOTNET'
  while ($s -ne 'NOTIFY' -and -not (Test-YcStateWanted $s $Cfg)) { $n = Get-YcNextState $s; L ($s + ' skipped'); Set-State $n '~'; $s = $n }
}

if ($s -eq 'DOTNET') {
  L 'install-dotnet -UpgradeChocolatey'
  & cmd /c 'C:\Scripts\install-dotnet.cmd -UpgradeChocolatey' *>> $Log
  $rc = $LASTEXITCODE; L ('install-dotnet rc=' + $rc)
  if ($rc -eq 8) { Restart-Now 'DOTNET' }          # come back and re-check, then fall through
  if ($rc -ne 0) { Fail 'DOTNET' ('install-dotnet rc=' + $rc) }
  Set-State 'SQL'; $s = 'SQL'
  while ($s -ne 'NOTIFY' -and -not (Test-YcStateWanted $s $Cfg)) { $n = Get-YcNextState $s; L ($s + ' skipped'); Set-State $n '~'; $s = $n }
}

if ($s -eq 'SQL') {
  $pwf = Join-Path $Base '.sa-password'
  Set-Content -Path $pwf -Value $Cfg.SaPassword -Encoding ascii
  & icacls $pwf /inheritance:r /grant 'SYSTEM:F' 'Administrators:F' *>> $Log
  $bf = Join-Path $Base 'yc-sqltemplate.sqlreboots'
  $rb = 0; if (Test-Path $bf) { $rb = [int](Get-Content $bf -TotalCount 1) }
  $args = Get-YcSqlArgs -Cfg $Cfg -PwFile $pwf
  L $args
  & cmd /c $args *>> $Log
  $rc = $LASTEXITCODE; L ('install-sql rc=' + $rc)
  if (Test-Path 'C:\Scripts\install-sql.reboot-required') {
    Remove-Item 'C:\Scripts\install-sql.reboot-required' -Force -EA SilentlyContinue
    if ($rb -ge 4) { Fail 'SQL' 'install-sql asked for a 5th reboot - refusing, this is a loop' }
    Set-Content -Path $bf -Value ([string]($rb + 1)) -Encoding ascii
    L ('install-sql wants a reboot - restart ' + ($rb + 1) + ' of 4')
    Restart-Now 'SQL'
  }
  Remove-Item $pwf -Force -EA SilentlyContinue
  if ($rc -ne 0) { Fail 'SQL' ('install-sql rc=' + $rc) }
  Restart-Now 'SQLLIC'                              # unconditional: the licence needs it
}

if ($s -eq 'SQLLIC') {
  if ($Cfg.SqlKey) {
    L ('activate-sql -TargetEdition ' + $Cfg.SqlEdition)
    & cmd /c ('C:\Scripts\activate-sql.cmd -ProductKey ' + $Cfg.SqlKey + ' -TargetEdition ' + $Cfg.SqlEdition + ' -InstanceName ' + $Cfg.InstanceName) *>> $Log
    $rc = $LASTEXITCODE; L ('activate-sql rc=' + $rc)
    if ($rc -ne 0 -and $rc -ne 3010) { Fail 'SQLLIC' ('activate-sql rc=' + $rc) }
  } else { L 'no SQL key - leaving the instance on Evaluation' }
  Set-State 'SSMS'; $s = 'SSMS'
  while ($s -ne 'NOTIFY' -and -not (Test-YcStateWanted $s $Cfg)) { $n = Get-YcNextState $s; L ($s + ' skipped'); Set-State $n '~'; $s = $n }
}

if ($s -eq 'SSMS') {
  L 'install-ssms'
  & cmd /c 'C:\Scripts\install-ssms.cmd' *>> $Log
  $rc = $LASTEXITCODE; L ('install-ssms rc=' + $rc)
  if ($rc -eq 8) { Restart-Now 'SSMS' }
  Set-State 'LIC'; $s = 'LIC'
  while ($s -ne 'NOTIFY' -and -not (Test-YcStateWanted $s $Cfg)) { $n = Get-YcNextState $s; L ($s + ' skipped'); Set-State $n '~'; $s = $n }
}

if ($s -eq 'LIC') {
  if ($Cfg.WinKey) {
    $lf = Join-Path $Base 'yc-sqltemplate.licpasses'
    $lp = 0; if (Test-Path $lf) { $lp = [int](Get-Content $lf -TotalCount 1) }
    $w = Get-WinLic
    L ('windows now: status=' + $w.status + ' channel=' + $w.channel + ' key=' + $w.partial)
    # Volume:MAK AND Licensed. Either one alone is the GVLK trap.
    if ($w.channel -notmatch 'Volume:MAK' -or $w.status -notmatch 'Licensed') {
      if ($lp -ge 3) { L 'activate-windows has not reached Volume:MAK in 3 passes - reporting what is true' }
      else {
        Set-Content -Path $lf -Value ([string]($lp + 1)) -Encoding ascii
        L ('activate-windows, pass ' + ($lp + 1) + ' of 3')
        & cmd /c ('C:\Scripts\activate-windows.cmd -ProductKey ' + $Cfg.WinKey) *>> $Log
        $rc = $LASTEXITCODE; L ('activate-windows rc=' + $rc)
        if ($rc -eq 3) { Restart-Now 'LIC' }        # edition change staged, finishes after reboot
        for ($i = 1; $i -le 20; $i++) {
          $w = Get-WinLic
          if ($w.channel -match 'Volume:MAK' -and $w.status -match 'Licensed') { break }
          Start-Sleep -Seconds 30
        }
        L ('windows settled: status=' + $w.status + ' channel=' + $w.channel + ' key=' + $w.partial)
      }
    } else { L 'windows already Licensed on Volume:MAK' }
  } else { L 'no Windows key - leaving the trial channel' }
  Set-State 'UPDPOST'; $s = 'UPDPOST'
  while ($s -ne 'NOTIFY' -and -not (Test-YcStateWanted $s $Cfg)) { $n = Get-YcNextState $s; L ($s + ' skipped'); Set-State $n '~'; $s = $n }
}

if ($s -eq 'UPDPOST') {
  if (Invoke-YcWindowsUpdate 'UPDPOST') { Restart-Now 'UPDPOST' }
  Set-State 'NOTIFY'; $s = 'NOTIFY'
}

if ($s -eq 'NOTIFY') {
  $extra = 'profile=' + $Cfg.Profile +
           ' sql=' + $(if ($Cfg.InstallSql) { [string]$Cfg.SqlVersion + ' ' + [string]$Cfg.SqlEdition } else { 'none' }) +
           ' sqlLicensed=' + $Cfg.LicenseSql +
           ' ssms=' + $Cfg.InstallSsms +
           ' winLicensed=' + $Cfg.LicenseWindows +
           ' sqlBackup=' + $Cfg.ConfigureSqlBackup
  $k5 = ''
  if ($Cfg.SqlKey -and $Cfg.SqlKey.Length -ge 5) { $k5 = ' -SqlKeyLast5 ' + $Cfg.SqlKey.Substring($Cfg.SqlKey.Length - 5) }
  Yc-Event ('-Type vm.deploy.completed -Step "' + (Get-Steps) + '" -Extra "' + $extra + '"' + $k5)
  Set-State 'DONE'; $s = 'DONE'
}

if ($s -eq 'DONE') {
  # A durable "this finished" marker. The state file says DONE too, but a state file is
  # a cursor - it is written before every step and is meaningless out of context. This is
  # a record: what was asked for, what ran, when it ended, in one file anyone can read
  # without knowing the state machine.
  $done = Join-Path $Base 'yc-build.completed'
  if (-not (Test-Path $done)) {
    $started = ''
    try { $started = (Get-Content (Join-Path $Base 'yc-sqltemplate.started') -TotalCount 1).Trim() } catch {}
    $mins = ''
    try { if ($started) { $mins = [int]((Get-Date) - [datetime]$started).TotalMinutes } } catch {}
    ([ordered]@{
      profile   = $Cfg.Profile
      steps     = (Get-Steps)
      startedAt = $started
      finishedAt= (Get-Date -f s)
      elapsedMin= $mins
      installSql=$Cfg.InstallSql; licenseSql=$Cfg.LicenseSql; installSsms=$Cfg.InstallSsms
      licenseWindows=$Cfg.LicenseWindows; sqlBackup=$Cfg.ConfigureSqlBackup
      windowsUpdates=$Cfg.InstallWindowsUpdates; windowsUpdateWhen=$Cfg.WindowsUpdateWhen
      sqlUpdates=$Cfg.InstallSqlUpdates
      host      = $env:COMPUTERNAME
    } | ConvertTo-Json) | Set-Content -Path $done -Encoding ascii
    L ('checkpoint written: ' + $done)
  }
  L 'complete - removing the startup task'
  try { Unregister-ScheduledTask -TaskName $Task -Confirm:$false -EA SilentlyContinue } catch {}
}
L '=== yc-vmbuild run end ==='
exit 0
