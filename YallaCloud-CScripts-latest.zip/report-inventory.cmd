@echo off
rem report-inventory [-PostUrl <https://collector/api>] [-PostTokenFile <file>] [-Tag <t>]
rem                  [-OutDir <dir>] [-Install [-Time HH:mm]] [-Uninstall] [-Help]
rem
rem Collects CloudStack instance metadata + guest facts into JSON, proves the file was written
rem and that it parses, and only THEN registers the YC-Inventory SYSTEM scheduled task - the old
rem version registered the task first and reported success even when collection or the POST
rem failed. A failed POST is now exit 12 instead of a red line followed by exit 0.
rem
rem The report is scrubbed: free-form cloud metadata keys that look like credentials are
rem replaced, and the Windows PartialProductKey is no longer emitted. A collector bearer token
rem comes from -PostTokenFile or
rem   set YC_INVENTORY_POST_TOKEN=...
rem Outbound only; no inbound port is opened. Logs to C:\Scripts\report-inventory.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Report-Inventory.ps1" %*
exit /b %ERRORLEVEL%
