param(
  [string[]]$Path,                 # folders/files to exclude (default C:\Scripts)
  [switch]$Help,
  # ---- ADDED in this revision ----
  [string[]]$Process,              # process-image exclusions (Add-MpPreference -ExclusionProcess)
  [string[]]$Extension,            # extension exclusions   (Add-MpPreference -ExclusionExtension)
  [switch]$Remove,                 # remove the listed exclusions instead of adding them
  [switch]$AcceptPrivEscRisk,      # required to exclude a directory non-admins can write to
  [switch]$AllowAbsent             # Defender genuinely absent (3rd-party AV) => WARN + exit 0
)
# =====================================================================================
# Defender-Exclude.ps1 - add/remove Microsoft Defender exclusions, and PROVE they applied.
# PowerShell 5.1, ASCII only. Runs unattended (cloud-init / SYSTEM / RMM).
#
# Stamp: 2026-08-19 - removed the documented exit code 1 'generic failure'; it is unreachable.
#        No behaviour changed.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# 1. IT USED TO LIE. v1 was:
#        Add-MpPreference -ExclusionPath $p -EA SilentlyContinue
#        Write-Host ("Defender exclusion added: "+$p) -ForegroundColor Green
#    The green success line was printed on the SAME line, unconditionally, with the error
#    suppressed. Tamper Protection blocks Add-MpPreference by design (it is on by default on
#    Server 2019+ with MDE), and when a third-party AV such as Bitdefender is present Defender
#    is in passive mode - both cases print green and exit 0. Now: -ErrorAction Stop inside
#    try/catch, and every exclusion is READ BACK from Get-MpPreference afterwards. If it is
#    not in the list, this command fails with exit 13. No claim is made that is not verified.
# 2. DEFENDER ABSENT / DISABLED IS NO LONGER A SILENT NO-OP. v1 exited 1 with a bare
#    Write-Host if the cmdlets were missing, and Get-MpPreference at the end threw a red error
#    into the transcript on a host where the service is stopped, then still exited 0. This
#    version probes the WinDefend service, the Defender module and Get-MpComputerStatus,
#    reports AMRunningMode (Normal / Passive / EDR Block Mode) and IsTamperProtected, and
#    exits 12 when Defender cannot be configured - unless you pass -AllowAbsent, which
#    downgrades "no Defender here" to a WARN and exit 0 for hosts where a third-party AV has
#    legitimately replaced it.
# 3. IT NOW REFUSES TO CREATE A PRIVILEGE-ESCALATION PRIMITIVE BY DEFAULT.
#    ***  EXCLUDING C:\Scripts IS A SECURITY DECISION, NOT HOUSEKEEPING.  ***
#    C:\Scripts is on the SYSTEM PATH and every command in this toolkit is executed from it
#    with -ExecutionPolicy Bypass, much of it as SYSTEM. If that directory is also writable by
#    BUILTIN\Users AND excluded from AV, any local user can drop a payload there and have it
#    executed as SYSTEM with no AV inspection. That is a full local privilege escalation, and
#    the AV exclusion is what removes the last chance of catching it.
#    This script therefore checks the ACL of every path it is asked to exclude. If a
#    non-administrative group (Users / Authenticated Users / Everyone / Guests /
#    ANONYMOUS LOGON) has write access, it REFUSES unless -AcceptPrivEscRisk is passed, and
#    it names the exact ACEs. v2 of _yc-lib.ps1 hardens C:\Scripts on every Start-YcLog, so on
#    a current image the default path passes this check without any flag.
# 4. Idempotent and reconciling: already-present exclusions are skipped, -Remove takes them
#    away and verifies they are gone, and -Process / -Extension are supported so you can
#    exclude a specific binary instead of a whole PATH directory.
# 5. Every exit goes through Exit-Yc, so the transcript always ends with [END] exit=<n>.
#    v1 had three bare exits and never called Stop-YcLog.
#
# VENDOR VERIFICATION:
#   Add-MpPreference -ExclusionPath / -ExclusionProcess / -ExclusionExtension, and the note
#   that the cmdlet must be run elevated (module: Defender):
#   https://learn.microsoft.com/en-us/powershell/module/defender/add-mppreference
#   Get-MpComputerStatus (AMRunningMode, AMServiceEnabled, RealTimeProtectionEnabled,
#   IsTamperProtected): https://learn.microsoft.com/en-us/powershell/module/defender/get-mpcomputerstatus
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** No exclusion was changed. Re-deploy the C:\Scripts payload and re-run. ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'defender-exclude'

$Usage = @'
defender-exclude  -  add (or remove) Microsoft Defender exclusions and VERIFY they applied.

USAGE:
  defender-exclude [<path> ...]
  defender-exclude C:\Scripts D:\Data
  defender-exclude -Process 'C:\Program Files\App\app.exe' -Extension bak
  defender-exclude -Remove D:\Data
  defender-exclude -Help

PARAMETERS:
  -Path                One or more folders/files to exclude. Default C:\Scripts.
  -Process             Process-image exclusions (Defender -ExclusionProcess).
  -Extension           File-extension exclusions (Defender -ExclusionExtension), e.g. bak
  -Remove              Remove the listed exclusions instead of adding them, and verify removal.
  -AcceptPrivEscRisk   Required to exclude a directory that a non-administrative group can
                       WRITE to. See the security note below - this is not a formality.
  -AllowAbsent         If Defender is absent/replaced by another AV, log a WARN and exit 0
                       instead of failing with exit 12.
  -Help                Show this help and exit.

  *** SECURITY: EXCLUDING C:\Scripts IS A PRIVILEGE-ESCALATION DECISION ***
  C:\Scripts is on the system PATH and everything in it runs with -ExecutionPolicy Bypass,
  much of it as SYSTEM. A directory that is (a) writable by ordinary users, (b) on the PATH
  and (c) excluded from AV is a local-privilege-escalation primitive: any user drops a file,
  something runs it as SYSTEM, and AV never looks at it.
  This command therefore INSPECTS THE ACL of each path first and REFUSES if Users /
  Authenticated Users / Everyone / Guests can write there, unless -AcceptPrivEscRisk is
  passed. Harden the directory first (Start-YcLog in _yc-lib.ps1 v2 does this automatically:
  inheritance broken, SYSTEM + Administrators Full only) and the check passes on its own.
  Prefer excluding a specific PROCESS or FILE over a whole PATH directory.

NOTES:
  Success is the READBACK, not the cmdlet call: every exclusion is confirmed present in
  Get-MpPreference before this command reports success. Tamper Protection and passive mode
  are both detected and reported rather than being silently swallowed.

EXAMPLES:
  defender-exclude
  defender-exclude C:\Scripts D:\Data
  defender-exclude -Path C:\Scripts -AcceptPrivEscRisk
  defender-exclude -Remove C:\Temp\build
  defender-exclude -Help

EXIT CODES:
  0   every requested exclusion is present (or removed) and verified
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was changed)
  5   not running as Administrator
  11  refused: a requested path is writable by non-administrators (pass -AcceptPrivEscRisk)
  12  Microsoft Defender is absent or cannot be configured on this host (see -AllowAbsent)
  13  the exclusion was accepted by the cmdlet but is NOT present in Get-MpPreference

Log: C:\Scripts\defender-exclude.log   (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

if(-not $Path -and -not $Process -and -not $Extension){ $Path = @('C:\Scripts') }

# ------------------------------------------------------------------------------------
# Risk inspection: is this path writable by a non-administrative principal, and is it on
# the system PATH? Both true = privilege-escalation primitive once AV stops looking.
# ------------------------------------------------------------------------------------
function Get-YcPathRisk{
  param([string]$InputPath)
  $r = [pscustomobject]@{ Path = $InputPath; Target = ''; Exists = $false; Writable = $false; OnSystemPath = $false; Who = @(); AclError = ''; JudgedPath = '' }
  $p = ([string]$InputPath).Trim()
  $p = $p -replace '\*+$',''
  $p = $p.TrimEnd('\')
  $r.Target = $p
  if(-not $p){ return $r }
  if(Test-Path -LiteralPath $p){ $r.Exists = $true }

  try{
    $envKey = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment'
    $raw = [string](Get-Item -LiteralPath $envKey -ErrorAction Stop).GetValue('Path',$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    foreach($seg in ($raw -split ';')){
      $s = ''
      try{ $s = [Environment]::ExpandEnvironmentVariables($seg) }catch{ $s = $seg }
      $s = $s.Trim().TrimEnd('\')
      if($s -and ($s -eq $p)){ $r.OnSystemPath = $true }
    }
  }catch{}

  # A path that does not exist YET is not safe: the exclusion covers whatever gets created
  # underneath it. Judge the nearest EXISTING ancestor instead - if a non-administrator can
  # create the directory there, they end up owning an AV-excluded directory with full control.
  # BEFORE: this returned Writable=$false without reading a single ACL, so naming a path one
  # day early walked straight past the guard.
  $judge = $p
  if(-not $r.Exists){
    $anc = $p
    while($anc -and -not (Test-Path -LiteralPath $anc)){
      $up = Split-Path -Parent $anc
      if(-not $up -or $up -eq $anc){ $anc = ''; break }
      $anc = $up
    }
    if(-not $anc){
      $r.AclError = 'no existing ancestor of ' + $p + ' could be found, so its ACL could not be judged'
      return $r
    }
    $r.JudgedPath = $anc
    $judge = $anc
  }
  # Only directories can be "written into"; a file exclusion is judged by its parent.
  $target = $judge
  try{ if(-not (Get-Item -LiteralPath $judge -ErrorAction Stop).PSIsContainer){ $target = Split-Path -Parent $judge } }catch{}
  $riskySids = @('S-1-5-32-545','S-1-5-11','S-1-1-0','S-1-5-32-546','S-1-5-7')
  try{
    $acl = Get-Acl -LiteralPath $target -ErrorAction Stop
    foreach($ace in $acl.Access){
      if([string]$ace.AccessControlType -ne 'Allow'){ continue }
      $sid = ''
      try{ $sid = $ace.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value }catch{ $sid = [string]$ace.IdentityReference }
      if($riskySids -notcontains $sid){ continue }
      $writes = $false
      $rightsText = [string]$ace.FileSystemRights
      if($rightsText -match '(?i)write|modify|fullcontrol|createfiles|appenddata|changepermissions|takeownership|delete'){ $writes = $true }
      $val = 0
      try{ $val = [int]$ace.FileSystemRights }catch{ $val = 0 }
      # FILE_WRITE_DATA/FILE_APPEND_DATA/FILE_WRITE_EA/FILE_WRITE_ATTRIBUTES/DELETE/WRITE_DAC/WRITE_OWNER
      foreach($bit in @(0x2,0x4,0x10,0x100,0x10000,0x40000,0x80000)){
        if(($val -band $bit) -ne 0){ $writes = $true }
      }
      if($writes){
        $r.Writable = $true
        $r.Who += ([string]$ace.IdentityReference + ' -> ' + $rightsText)
      }
    }
  }catch{
    $r.AclError = $_.Exception.Message
  }
  return $r
}

$risky = @()
foreach($p in @($Path)){
  $risk = Get-YcPathRisk -InputPath $p
  if($risk.AclError){ Write-YcLog ('could not read the ACL of ' + $risk.Target + ': ' + $risk.AclError) 'WARN' }
  $judged = ''
  if($risk.JudgedPath){ $judged = ' (does not exist yet; judged its nearest existing ancestor ' + $risk.JudgedPath + ', which is where a non-administrator would create it)' }
  if(-not $risk.Exists){ Write-YcLog ('note: ' + $risk.Target + ' does not exist yet - Defender accepts the exclusion anyway, so the ACL of ' + $risk.JudgedPath + ' is what decides who ends up owning the excluded directory') 'WARN' }
  if($risk.Writable){
    $risky += $risk
    $msg = 'PRIVILEGE-ESCALATION RISK: ' + $risk.Target + ' is writable by non-administrators (' + ($risk.Who -join '; ') + ')' + $judged
    if($risk.OnSystemPath){ $msg += ' AND it is on the SYSTEM PATH, where this toolkit executes scripts as SYSTEM with -ExecutionPolicy Bypass' }
    Write-YcLog ($msg + '. Excluding it from AV removes the last control that would catch a planted payload.') 'ERROR'
  }elseif(-not $risk.AclError){
    Write-YcLog ('ACL check OK: ' + $risk.Target + ' is not writable by Users/Authenticated Users/Everyone/Guests' + $judged + $(if($risk.OnSystemPath){' (it IS on the system PATH, but only administrators can write to it)'}else{''})) 'OK'
  }
}
if($risky.Count -gt 0 -and -not $Remove){
  if($AcceptPrivEscRisk){
    Write-YcLog ('-AcceptPrivEscRisk was passed: proceeding to exclude ' + (($risky | ForEach-Object { $_.Target }) -join ', ') + ' despite the risk above. RECORD THIS AS AN ACCEPTED RISK.') 'WARN'
  }else{
    Exit-Yc 11 ('refusing to exclude a user-writable directory from AV. Harden it first (icacls <dir> /inheritance:r /grant "NT AUTHORITY\SYSTEM:(OI)(CI)F" "BUILTIN\Administrators:(OI)(CI)F"), exclude a specific process/file instead, or re-run with -AcceptPrivEscRisk. Nothing was changed.') 'ERROR'
  }
}

# ------------------------------------------------------------------------------------
# Is Defender actually here, and can it be configured?
# ------------------------------------------------------------------------------------
$absentReason = ''
if(-not (Get-Command Add-MpPreference -ErrorAction SilentlyContinue)){ $absentReason = 'the Defender PowerShell module is not present on this host' }
elseif(-not (Get-Service -Name WinDefend -ErrorAction SilentlyContinue)){ $absentReason = 'the WinDefend service does not exist on this host' }
if($absentReason){
  if($AllowAbsent){ Exit-Yc 0 ('Microsoft Defender cannot be configured: ' + $absentReason + '. -AllowAbsent was passed, so this is reported and treated as a no-op. NOTHING WAS EXCLUDED.') 'WARN' }
  Exit-Yc 12 ('Microsoft Defender cannot be configured: ' + $absentReason + '. No exclusion was set. Pass -AllowAbsent if that is expected on this host.') 'ERROR'
}
$wd = Get-Service -Name WinDefend -ErrorAction SilentlyContinue
Write-YcLog ('WinDefend service: ' + $wd.Status)
$mp = $null
try{ $mp = Get-MpComputerStatus -ErrorAction Stop }catch{ $mp = $null; Write-YcLog ('Get-MpComputerStatus failed: ' + $_.Exception.Message) 'WARN' }
if($mp){
  Write-YcLog ('Defender: AMRunningMode=' + $mp.AMRunningMode + ' AMServiceEnabled=' + $mp.AMServiceEnabled + ' RealTimeProtectionEnabled=' + $mp.RealTimeProtectionEnabled + ' IsTamperProtected=' + $mp.IsTamperProtected)
  if([string]$mp.AMRunningMode -ne 'Normal'){
    Write-YcLog ('Defender is running in "' + $mp.AMRunningMode + '" mode - it is not the active scanner on this host, so these exclusions may have no practical effect until it is.') 'WARN'
  }
  if($mp.IsTamperProtected){
    Write-YcLog 'Tamper Protection is ON. It is designed to block exclusion changes; if the readback below fails, that is why - change the exclusion from the MDE/Intune console instead.' 'WARN'
  }
}

# ------------------------------------------------------------------------------------
# Apply, then PROVE by reading back.
# ------------------------------------------------------------------------------------
function Get-YcMpLists{
  $o = [pscustomobject]@{ Paths = @(); Processes = @(); Extensions = @() }
  try{
    $pref = Get-MpPreference -ErrorAction Stop
    if($pref.ExclusionPath){      $o.Paths      = @($pref.ExclusionPath) }
    if($pref.ExclusionProcess){   $o.Processes  = @($pref.ExclusionProcess) }
    if($pref.ExclusionExtension){ $o.Extensions = @($pref.ExclusionExtension) }
  }catch{
    Write-YcLog ('Get-MpPreference failed: ' + $_.Exception.Message) 'ERROR'
    return $null
  }
  return $o
}
function Test-YcInList{
  param([string[]]$List,[string]$Value)
  $v = ([string]$Value).TrimEnd('\')
  foreach($x in @($List)){
    if(([string]$x).TrimEnd('\') -eq $v){ return $true }
    if(([string]$x).TrimEnd('\').ToLowerInvariant() -eq $v.ToLowerInvariant()){ return $true }
  }
  return $false
}

$before = Get-YcMpLists
if(-not $before){ Exit-Yc 12 'Defender preferences cannot be read on this host - refusing to claim an exclusion was applied.' 'ERROR' }

$work = @()
foreach($p in @($Path)){      if($p){ $work += (New-Object psobject -Property @{ Kind='Path';      Value=[string]$p; Current=$before.Paths }) } }
foreach($p in @($Process)){   if($p){ $work += (New-Object psobject -Property @{ Kind='Process';   Value=[string]$p; Current=$before.Processes }) } }
foreach($p in @($Extension)){ if($p){ $work += (New-Object psobject -Property @{ Kind='Extension'; Value=[string]$p; Current=$before.Extensions }) } }

$failed = @()
foreach($w in $work){
  $present = Test-YcInList -List $w.Current -Value $w.Value
  if($Remove){
    if(-not $present){ Write-YcLog ($w.Kind + ' exclusion not present, nothing to remove: ' + $w.Value); continue }
    try{
      switch($w.Kind){
        'Path'      { Remove-MpPreference -ExclusionPath      $w.Value -ErrorAction Stop }
        'Process'   { Remove-MpPreference -ExclusionProcess   $w.Value -ErrorAction Stop }
        'Extension' { Remove-MpPreference -ExclusionExtension $w.Value -ErrorAction Stop }
      }
      Write-YcLog ('Remove-MpPreference accepted ' + $w.Kind + ' ' + $w.Value + ' - verifying...')
    }catch{
      Write-YcLog ('Remove-MpPreference FAILED for ' + $w.Kind + ' ' + $w.Value + ': ' + $_.Exception.Message) 'ERROR'
      $failed += ($w.Kind + ' ' + $w.Value)
    }
  }else{
    if($present){ Write-YcLog ($w.Kind + ' exclusion already present: ' + $w.Value) 'OK'; continue }
    try{
      switch($w.Kind){
        'Path'      { Add-MpPreference -ExclusionPath      $w.Value -ErrorAction Stop }
        'Process'   { Add-MpPreference -ExclusionProcess   $w.Value -ErrorAction Stop }
        'Extension' { Add-MpPreference -ExclusionExtension $w.Value -ErrorAction Stop }
      }
      Write-YcLog ('Add-MpPreference accepted ' + $w.Kind + ' ' + $w.Value + ' - verifying...')
    }catch{
      Write-YcLog ('Add-MpPreference FAILED for ' + $w.Kind + ' ' + $w.Value + ': ' + $_.Exception.Message) 'ERROR'
      $failed += ($w.Kind + ' ' + $w.Value)
    }
  }
}

Start-Sleep -Seconds 2
$after = Get-YcMpLists
if(-not $after){ Exit-Yc 13 'the exclusions could not be read back - success is NOT being claimed.' 'ERROR' }

$bad = @()
foreach($w in $work){
  $list = @()
  switch($w.Kind){
    'Path'      { $list = $after.Paths }
    'Process'   { $list = $after.Processes }
    'Extension' { $list = $after.Extensions }
  }
  $now = Test-YcInList -List $list -Value $w.Value
  if($Remove){
    if($now){ $bad += ($w.Kind + ' ' + $w.Value + ' is STILL excluded') }
    else    { Write-YcLog ('verified removed: ' + $w.Kind + ' ' + $w.Value) 'OK' }
  }else{
    if($now){ Write-YcLog ('verified applied: ' + $w.Kind + ' ' + $w.Value) 'OK' }
    else    { $bad += ($w.Kind + ' ' + $w.Value + ' is NOT in Get-MpPreference') }
  }
}

Write-YcLog ('current Defender path exclusions: ' + (@($after.Paths) -join ' | '))
if($after.Processes.Count -gt 0){  Write-YcLog ('current Defender process exclusions: '   + (@($after.Processes) -join ' | ')) }
if($after.Extensions.Count -gt 0){ Write-YcLog ('current Defender extension exclusions: ' + (@($after.Extensions) -join ' | ')) }

if($bad.Count -gt 0){
  $hint = ''
  if($mp -and $mp.IsTamperProtected){ $hint = ' Tamper Protection is ON, which is the usual cause - change this from the MDE/Intune console.' }
  Exit-Yc 13 ('exclusion readback FAILED for: ' + ($bad -join '; ') + '.' + $hint) 'ERROR'
}
if($failed.Count -gt 0){
  Exit-Yc 13 ('the cmdlet reported an error for: ' + ($failed -join '; ') + ' - not claiming success.') 'ERROR'
}

$verb = 'applied'
if($Remove){ $verb = 'removed' }
Exit-Yc 0 ('all ' + $work.Count + ' requested Defender exclusion(s) ' + $verb + ' and verified by readback.') 'OK'
