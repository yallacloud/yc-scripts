param(
  [string]$ConfigUrl,
  [string]$ConfigFile,
  [string]$Environment,
  [string]$InstallerPath,
  [string]$DownloadUrl,
  [string]$Sha256,
  [string]$InstallDir,
  [string]$ConfigPath,
  [string]$ServiceName = 'Alloy',
  [int]$UiPort = 12345,
  [ValidateSet('generally-available','public-preview','experimental')]
  [string]$StabilityLevel = 'generally-available',
  [switch]$AllowUnhealthy,
  [switch]$Force,
  [switch]$Help
)
# =====================================================================================
# Alloy-Register.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
# Installs Grafana Alloy, puts the config WHERE THE SERVICE ACTUALLY READS IT, validates
# it with the vendor validator, and PROVES the agent is up before reporting success.
#
# WHAT CHANGED AND WHY
# --------------------
#  1. [P0-26d] THE CONFIG WENT WHERE NOTHING READS IT. The old script wrote
#     %ProgramData%\GrafanaLabs\Alloy\config.alloy and restarted the service. The Windows
#     service is created by the NSIS installer as
#         sc create "Alloy" ... binPath="$INSTDIR\alloy-windows-amd64.exe"
#     and its arguments live in the REG_MULTI_SZ value
#         HKLM\SOFTWARE\GrafanaLabs\Alloy  ->  Arguments
#     whose default contents are:  run | %PROGRAMFILES%\GrafanaLabs\Alloy\config.alloy |
#     --storage.path=%PROGRAMDATA%\GrafanaLabs\Alloy\data
#     So -ConfigUrl and -ConfigFile have NEVER done anything: Alloy kept running the stock
#     config the installer dropped, and the script logged OK. Now the script
#       a. runs the installer with /CONFIG="<path>" /FORCEREGISTRY=yes  (without
#          /FORCEREGISTRY the NSIS InitializeRegistry macro refuses to overwrite existing
#          registry values, so on any re-run or upgrade /CONFIG is silently ignored),
#       b. READS THE REGISTRY BACK and writes the config to the path Alloy will actually
#          load - it never assumes,
#       c. proves the loaded config is the one it wrote (/-/support is not needed: the
#          validate step plus the readiness/health probes below are the proof).
#  2. [P0-26 vendor validator] alloy validate IS RUN, BEFORE THE SERVICE IS TOUCHED.
#         "$InstallDir\alloy-windows-amd64.exe" validate --stability.level <lvl> "<cfg>"
#     A non-zero exit aborts the run, restores the previous config from the backup, and
#     leaves the running collector alone. A broken config can no longer take down a
#     working agent, and an invalid config can no longer be reported as success.
#  3. IT NO LONGER LIES. The old ending was Restart-Service -EA SilentlyContinue, then
#     printing $svc.Status, then an unconditional 'done ... OK' + exit 0. A Stopped
#     service exited 0. Proof is now, in order: validator exit 0; service Running, polled,
#     then RE-CHECKED after a settle window; GET http://127.0.0.1:12345/-/ready = 200;
#     GET /-/healthy = 200 ("All Alloy components are healthy"); GET /metrics contains
#     alloy_build_info. -ErrorAction SilentlyContinue is gone from every load-bearing call.
#  4. -Environment IS NO LONGER A DEAD PARAMETER THAT LIES IN THE HELP. It was documented
#     as "extra service arguments/flags" and was never referenced anywhere in the script.
#     It is now appended to the registry Arguments REG_MULTI_SZ (the documented mechanism)
#     and therefore actually reaches the service.
#  5. THE CONFIG IS TREATED AS A SECRET. An Alloy config normally carries basic_auth
#     passwords for remote_write / Loki push. The file is written with inheritance stripped
#     and an ACL of SYSTEM + Administrators only, and the ACL is VERIFIED afterwards.
#     A fetched -ConfigUrl is checked for being an HTML error page before it is used.
#  6. -ConfigUrl IS FETCHED SAFELY. Was Invoke-WebRequest with no timeout, no
#     -ErrorAction Stop and no content check: a captive-portal login page became the
#     "config". Now Get-YcFile (TLS 1.2+, retries, magic-byte/HTML detection, optional
#     -Sha256) and a syntax sanity check before anything is replaced.
#  7. IDEMPOTENT AND UPGRADE-SAFE. Unchanged config is left alone; a changed config is
#     backed up to config.alloy.bak-<timestamp> and can be rolled back automatically when
#     validation fails. The installer runs with /FORCEREGISTRY=yes so a second run with a
#     different config path is no longer a no-op.
#  8. The staged-installer lookup no longer does a lexical Sort-Object on a single literal
#     filename, and accepts either the .exe.zip or the bare .exe asset.
#
# PARAMETERS ADDED (none renamed, none removed): -InstallerPath, -DownloadUrl, -Sha256,
#     -InstallDir, -ConfigPath, -ServiceName, -UiPort, -StabilityLevel, -AllowUnhealthy,
#     -Force.  -Environment keeps its documented meaning and now works.
#
# VERIFIED AGAINST THE CURRENT RELEASE (docs, not memory):
#   installer flags /S /CONFIG= /DISABLEREPORTING= /DISABLEPROFILING= /FORCEREGISTRY=yes
#     https://grafana.com/docs/alloy/latest/set-up/install/windows/
#   registry HKLM\SOFTWARE\GrafanaLabs\Alloy -> Arguments (REG_MULTI_SZ)
#     https://grafana.com/docs/alloy/latest/configure/windows/
#   alloy validate [<FLAG> ...] <PATH_NAME>, zero exit = valid
#     https://grafana.com/docs/alloy/latest/reference/cli/validate/
#   HTTP UI default 127.0.0.1:12345, endpoints /-/ready and /-/healthy
#     https://grafana.com/docs/alloy/latest/reference/http/
#     https://grafana.com/docs/alloy/latest/reference/cli/run/
#
# Log: C:\Scripts\alloy-register.log
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'alloy-register'
$ErrorActionPreference = 'Stop'

$AlloyRegKey = 'HKLM:\SOFTWARE\GrafanaLabs\Alloy'

$HelpText = @"
alloy-register - SILENT install + configure Grafana Alloy (unified telemetry collector), write the
                 config WHERE THE SERVICE READS IT, validate it with 'alloy validate', and prove the
                 agent is ready and healthy before reporting success. Alloy pushes OUT: no inbound
                 rule is created. Its own UI binds 127.0.0.1:12345 (loopback only).

USAGE:
  alloy-register -ConfigUrl <http-url-to-config.alloy>
  alloy-register -ConfigFile <C:\path\config.alloy> [-Environment '<extra flags>']
  alloy-register -Help

PARAMETERS:
  -ConfigUrl       (required unless -ConfigFile) fetch config.alloy from this URL. Downloaded with
                   TLS 1.2+, retries and an HTML/error-page check; a login page can no longer become
                   your collector configuration.
  -ConfigFile      Use this local config.alloy instead.
  -Environment     Extra service arguments/flags for Alloy (advanced). These are APPENDED to the
                   registry Arguments REG_MULTI_SZ, which is what the service actually reads.
                   Separate several with ';'  e.g. -Environment '--server.http.listen-addr=127.0.0.1:12345'
                   (In the old script this parameter was documented but never used at all.)
  -ConfigPath      Where the config is stored. Default: the path already recorded in
                   HKLM\SOFTWARE\GrafanaLabs\Alloy -> Arguments, else <InstallDir>\config.alloy.
  -InstallDir      Alloy install folder. Default %ProgramFiles%\GrafanaLabs\Alloy.
  -InstallerPath   Explicit staged installer (.exe or .exe.zip). Default: newest
                   C:\Scripts\alloy-installer-windows-amd64.exe[.zip].
  -DownloadUrl     Download the installer instead of using a staged one (TLS 1.2+, retried).
  -Sha256          Expected SHA256 of the installer. Strongly recommended.
  -ServiceName     Windows service name. Default Alloy.
  -UiPort          Alloy HTTP UI port used for the readiness/health proof. Default 12345.
  -StabilityLevel  generally-available (default) | public-preview | experimental. Passed to
                   'alloy validate' so validation matches how the service runs.
  -AllowUnhealthy  Downgrade a failing /-/healthy probe from a hard failure to a WARN. Use only when
                   the remote endpoint is knowingly unavailable at deploy time.
  -Force           Rewrite the config file even if the content is unchanged.
  -Help            Show this help and exit 0.

EXAMPLES:
  alloy-register -ConfigFile C:\Scripts\config.alloy
  alloy-register -ConfigUrl http://10.0.0.9/alloy/win.alloy -Sha256 <hash>
  alloy-register -ConfigFile C:\Scripts\config.alloy -Environment '--server.http.listen-addr=127.0.0.1:12345'
  alloy-register -Help

PROOF PERFORMED (in this order - any failure is a non-zero exit):
  1. installer exit code decoded (not just printed) and alloy-windows-amd64.exe present
  2. the config path is READ BACK from the registry Arguments value, never assumed
  3. alloy validate --stability.level <lvl> "<config>"   -> exit 0, BEFORE the service is touched
  4. service Running, polled, then re-checked after a settle window
  5. GET http://127.0.0.1:<UiPort>/-/ready   -> 200
  6. GET http://127.0.0.1:<UiPort>/-/healthy -> 200 (all components healthy)
  7. GET http://127.0.0.1:<UiPort>/metrics   -> 200 and contains alloy_build_info

EXIT CODES:
  0  Verified: config in the path the service loads, validator passed, service Running, ready+healthy.
  1  Failure at any step (no installer, bad config, service not created/Running, not ready/healthy).
  2  Usage error (neither -ConfigUrl nor -ConfigFile).
  5  Not elevated (from _yc-lib Assert-YcPrereqs).
  6  No outbound internet when -DownloadUrl / -ConfigUrl was used.

SECURITY NOTE: an Alloy config normally contains basic_auth credentials for remote_write and Loki
  push. This command strips inheritance from the config file and grants SYSTEM + Administrators
  only, then VERIFIES that ACL. Never pass credentials on this command line - put them in the
  config file you hand to -ConfigFile.

Log: C:\Scripts\alloy-register.log
"@

if($Help){ Write-Host $HelpText -ForegroundColor Cyan; Exit-Yc 0 'help shown' 'OK' }
if(-not $ConfigUrl -and -not $ConfigFile){
  Write-Host $HelpText -ForegroundColor Cyan
  Exit-Yc 2 'One of -ConfigUrl or -ConfigFile is required.' 'ERROR'
}
if($ConfigUrl -and $ConfigFile){
  Write-Host $HelpText -ForegroundColor Cyan
  Exit-Yc 2 '-ConfigUrl and -ConfigFile are mutually exclusive - pick one.' 'ERROR'
}

# The InstallDir default is resolved AFTER -Help, so printing the help can never depend on the
# environment block (an RMM or cloud-init context that strips %ProgramFiles% used to throw here
# before a single line of help was shown).
if(-not $InstallDir){
  $pf = $env:ProgramFiles
  if(-not $pf){ $pf = 'C:\Program Files' }
  $InstallDir = $pf + '\GrafanaLabs\Alloy'
}

Assert-YcPrereqs -NeedAdmin
$script:YcExit = 1
$script:YcTemp = $null
$script:YcBackup = $null
$script:YcCfgPath = $null

# ------------------------------------------------------------------ helpers

function Write-YcAsciiFile{
  param([string]$Path,[string]$Content)
  $sw = New-Object System.IO.StreamWriter($Path,$false,(New-Object System.Text.ASCIIEncoding))
  try{ $sw.Write($Content) } finally{ $sw.Close() }
}

# Run a native exe, capture stdout+stderr and the real exit code, without
# $ErrorActionPreference='Stop' turning redirected stderr into a NativeCommandError throw.
function Invoke-YcNative{
  param([string]$File,[string[]]$Arguments)
  $ErrorActionPreference = 'Continue'
  $out = & $File @Arguments 2>&1
  $rc  = $LASTEXITCODE
  $txt = @()
  foreach($o in $out){ if($null -ne $o){ $txt += ([string]$o) } }
  return (New-Object psobject -Property @{ Output = $txt; ExitCode = $rc })
}

# https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/icacls
# SID form so this works on a non-English Windows too.
function Protect-YcFileAcl{
  param([string]$Path)
  $r1 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/inheritance:r')
  $r2 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/grant','*S-1-5-18:(F)','*S-1-5-32-544:(F)')
  if($r1.ExitCode -ne 0 -or $r2.ExitCode -ne 0){
    Write-YcLog ('icacls FAILED on ' + $Path + ' (inheritance rc=' + $r1.ExitCode + ', grant rc=' +
      $r2.ExitCode + '): ' + (($r1.Output + $r2.Output) -join ' ')) 'ERROR'
    return $false
  }
  $allowed = @('S-1-5-18','S-1-5-32-544')
  $acl = Get-Acl -LiteralPath $Path
  if(-not $acl.AreAccessRulesProtected){
    Write-YcLog ('VERIFICATION FAILED: inheritance is still enabled on ' + $Path) 'ERROR'
    return $false
  }
  $bad = @()
  foreach($ace in $acl.Access){
    $sid = $null
    try{ $sid = $ace.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch{ $sid = [string]$ace.IdentityReference }
    if($allowed -notcontains $sid){ $bad += ([string]$ace.IdentityReference + ' (' + $sid + ')') }
  }
  if($bad.Count -gt 0){
    Write-YcLog ('VERIFICATION FAILED: ' + $Path + ' is still accessible to: ' + ($bad -join ', ') +
      '. An Alloy config normally contains basic_auth credentials.') 'ERROR'
    return $false
  }
  Write-YcLog ('ACL verified on ' + $Path + ': inheritance removed, trustees are exactly SYSTEM ' +
    'and BUILTIN\Administrators.') 'OK'
  return $true
}

function Set-YcManagedFile{
  param([string]$Path,[string]$Content,[switch]$Always)
  if(Test-Path -LiteralPath $Path){
    $cur = Get-Content -LiteralPath $Path -Raw
    if($null -eq $cur){ $cur = '' }
    if($cur -eq $Content -and -not $Always){
      Write-YcLog ('Unchanged, left in place: ' + $Path)
      return $true
    }
    $bak = $Path + '.bak-' + (Get-Date).ToString('yyyyMMddHHmmss')
    Copy-Item -LiteralPath $Path -Destination $bak -Force
    $script:YcBackup = $bak
    Write-YcLog ('Content changed; previous config backed up to ' + $bak) 'WARN'
  }
  Write-YcAsciiFile -Path $Path -Content $Content
  Write-YcLog ('Wrote ' + $Path)
  return $true
}

function Restore-YcBackup{
  if($script:YcBackup -and $script:YcCfgPath -and (Test-Path -LiteralPath $script:YcBackup)){
    try{
      Copy-Item -LiteralPath $script:YcBackup -Destination $script:YcCfgPath -Force
      Write-YcLog ('Rolled the previous config back into ' + $script:YcCfgPath +
        ' - the running collector keeps the configuration it had.') 'WARN'
    }catch{
      Write-YcLog ('Could not roll the previous config back: ' + $_.Exception.Message) 'ERROR'
    }
  }
}

function Get-YcAlloyArguments{
  if(-not (Test-Path $AlloyRegKey)){ return @() }
  try{
    $p = Get-ItemProperty -Path $AlloyRegKey -ErrorAction Stop
    if($null -eq $p.Arguments){ return @() }
    return @($p.Arguments)
  }catch{ return @() }
}

# The config path is the first Arguments element that ends in .alloy (the installer writes
# run | <config> | --storage.path=...). Never guessed.
function Get-YcAlloyConfigPathFromRegistry{
  $args_ = Get-YcAlloyArguments
  foreach($a in $args_){
    $s = ([string]$a).Trim()
    if($s -and $s -notlike '--*' -and $s -ne 'run' -and $s.ToLowerInvariant().EndsWith('.alloy')){ return $s }
  }
  return $null
}

function Set-YcAlloyArguments{
  param([string[]]$Values)
  New-Item -Path $AlloyRegKey -Force | Out-Null
  New-ItemProperty -Path $AlloyRegKey -Name 'Arguments' -PropertyType MultiString -Value $Values -Force | Out-Null
  $back = Get-YcAlloyArguments
  if(($back -join '|') -ne ($Values -join '|')){
    Write-YcLog ('VERIFICATION FAILED: the Arguments registry value did not take. wanted [' +
      ($Values -join ' ') + '] got [' + ($back -join ' ') + ']') 'ERROR'
    return $false
  }
  Write-YcLog ('Service arguments (HKLM\SOFTWARE\GrafanaLabs\Alloy -> Arguments): ' + ($back -join ' ')) 'OK'
  return $true
}

function Test-YcAlloyConfigText{
  param([string]$Text,[string]$Origin)
  if($null -eq $Text){ $Text = '' }
  if($Text.Trim().Length -eq 0){
    Write-YcLog ('The configuration from ' + $Origin + ' is EMPTY. Refusing to install it.') 'ERROR'
    return $false
  }
  if($Text -match '(?i)<\s*(html|!doctype html|head|body)\b'){
    Write-YcLog ('The configuration from ' + $Origin + ' looks like an HTML page (proxy login, 404 ' +
      'page or portal), not an Alloy configuration. Refusing to install it.') 'ERROR'
    return $false
  }
  # Cheap structural check: Alloy config is made of blocks - name "label" { ... }
  if($Text -notmatch '(?m)\{'){
    Write-YcLog ('The configuration from ' + $Origin + ' contains no block at all - it is not an ' +
      'Alloy configuration.') 'ERROR'
    return $false
  }
  # P0-26a guard: a line carrying two or more attribute assignments outside a string cannot parse,
  # because every attribute definition must end with a newline terminator.
  $lineNo = 0
  foreach($line in ($Text -split "`n")){
    $lineNo++
    $l = $line
    $c = $l.IndexOf('//')
    if($c -ge 0){ $l = $l.Substring(0,$c) }
    $stripped = [regex]::Replace($l,'"[^"]*"','""')
    $eq = ([regex]::Matches($stripped,'(?<![=!<>])=(?!=)')).Count
    if($eq -ge 2){
      Write-YcLog ('Line ' + $lineNo + ' of the configuration from ' + $Origin + ' assigns ' + $eq +
        ' attributes on ONE line. Alloy requires a newline terminator after every attribute, so ' +
        'this file will not parse and Alloy will load NOTHING - no metrics and no logs. Put one ' +
        'attribute per line. Offending line: ' + $l.Trim()) 'ERROR'
      return $false
    }
  }
  return $true
}

# ------------------------------------------------------------------ main

function Invoke-Main{

  # --- 1. the configuration content, obtained safely BEFORE anything is changed -------
  $cfgText = $null
  if($ConfigUrl){
    Assert-YcPrereqs -NeedInternet
    $script:YcTemp = Join-Path $env:TEMP ('alloycfg_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
    $dl = Join-Path $script:YcTemp 'config.alloy'
    $got = Get-YcFile -Uri $ConfigUrl -OutFile $dl -MinBytes 8 -AllowText
    if(-not $got){
      Write-YcLog ('Could not fetch the configuration from ' + $ConfigUrl) 'ERROR'
      $script:YcExit = 1; return
    }
    $cfgText = Get-Content -LiteralPath $dl -Raw
    if(-not (Test-YcAlloyConfigText -Text $cfgText -Origin $ConfigUrl)){ $script:YcExit = 1; return }
  }else{
    if(-not (Test-Path -LiteralPath $ConfigFile)){
      Write-YcLog ('-ConfigFile not found: ' + $ConfigFile) 'ERROR'
      $script:YcExit = 1; return
    }
    $cfgText = Get-Content -LiteralPath $ConfigFile -Raw
    if(-not (Test-YcAlloyConfigText -Text $cfgText -Origin $ConfigFile)){ $script:YcExit = 1; return }
  }
  Write-YcLog ('Configuration accepted (' + $cfgText.Length + ' chars) - one attribute per line, ' +
    'no HTML, at least one block.') 'OK'

  # --- 2. the installer ---------------------------------------------------------------
  $inst = $null
  if($InstallerPath){
    if(-not (Test-Path -LiteralPath $InstallerPath)){
      Write-YcLog ('-InstallerPath not found: ' + $InstallerPath) 'ERROR'
      $script:YcExit = 1; return
    }
    $inst = Get-Item -LiteralPath $InstallerPath
  }elseif($DownloadUrl){
    Assert-YcPrereqs -NeedInternet
    if(-not $script:YcTemp){
      $script:YcTemp = Join-Path $env:TEMP ('alloycfg_' + [guid]::NewGuid().ToString('N'))
      New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
    }
    $leaf = 'alloy-installer-windows-amd64.exe'
    if($DownloadUrl -match '\.zip($|\?)'){ $leaf = $leaf + '.zip' }
    $dst = Join-Path $script:YcTemp $leaf
    $got = Get-YcFile -Uri $DownloadUrl -OutFile $dst -Sha256 $Sha256 -MinBytes 1048576
    if(-not $got){ Write-YcLog 'Installer download failed.' 'ERROR'; $script:YcExit = 1; return }
    $inst = Get-Item -LiteralPath $dst
  }else{
    $cand = @()
    foreach($p in @('C:\Scripts\alloy-installer-windows-amd64.exe.zip','C:\Scripts\alloy-installer-windows-amd64.exe')){
      if(Test-Path -LiteralPath $p){ $cand += (Get-Item -LiteralPath $p) }
    }
    if($cand.Count -gt 0){ $inst = $cand[0] }
  }
  if(-not $inst){
    Write-YcLog ('No Alloy installer. Stage C:\Scripts\alloy-installer-windows-amd64.exe.zip (or ' +
      '.exe), or pass -InstallerPath / -DownloadUrl.') 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcFile -Path $inst.FullName -MinBytes 1048576 -Because 'Alloy installer')){
    $script:YcExit = 1; return
  }
  if($Sha256 -and -not $DownloadUrl){
    $h = (Get-FileHash -LiteralPath $inst.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
    if($h -ne $Sha256.Trim().ToUpperInvariant()){
      Write-YcLog ('SHA256 MISMATCH on ' + $inst.Name + ': expected ' + $Sha256.Trim().ToUpperInvariant() +
        ', got ' + $h + '. Refusing to install.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('SHA256 verified: ' + $h) 'OK'
  }

  $setupExe = $inst.FullName
  if($inst.Extension -eq '.zip'){
    if(-not $script:YcTemp){
      $script:YcTemp = Join-Path $env:TEMP ('alloycfg_' + [guid]::NewGuid().ToString('N'))
      New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
    }
    $ex = Join-Path $script:YcTemp 'installer'
    New-Item -ItemType Directory -Path $ex -Force | Out-Null
    Expand-Archive -Path $inst.FullName -DestinationPath $ex -Force
    $found = Get-ChildItem -Path $ex -Recurse -Filter 'alloy-installer-windows-amd64.exe' -File |
             Select-Object -First 1
    if(-not $found){
      Write-YcLog ('alloy-installer-windows-amd64.exe not found inside ' + $inst.Name) 'ERROR'
      $script:YcExit = 1; return
    }
    $setupExe = $found.FullName
  }

  # --- 3. where will the config live? -------------------------------------------------
  $target = $ConfigPath
  if(-not $target){
    $target = Get-YcAlloyConfigPathFromRegistry
    if($target){ Write-YcLog ('Existing install: the service loads ' + $target + ' (read from the registry).') }
  }
  if(-not $target){ $target = Join-Path $InstallDir 'config.alloy' }
  $script:YcCfgPath = $target

  # --- 4. install (idempotent; /FORCEREGISTRY makes /CONFIG stick on re-runs) ----------
  # https://grafana.com/docs/alloy/latest/set-up/install/windows/
  # The value is pre-quoted because Start-Process -ArgumentList on PowerShell 5.1 joins the
  # array with spaces WITHOUT adding quotes, and the default config path contains a space
  # ("C:\Program Files\GrafanaLabs\Alloy"). Step 5 then writes the registry Arguments value
  # explicitly and reads it back, so the installer's own switch parsing is not load-bearing.
  $iargs = @('/S',('/CONFIG="' + $target + '"'),'/DISABLEREPORTING=yes','/DISABLEPROFILING=yes','/FORCEREGISTRY=yes')
  $res = Invoke-YcInstaller -FilePath $setupExe -ArgumentList $iargs -SuccessCodes @(0) -TimeoutSec 900
  if(-not $res.Success){
    Write-YcLog ('Alloy installer FAILED: exit ' + $res.ExitCode + ' - ' + $res.Meaning) 'ERROR'
    $script:YcExit = 1; return
  }
  $alloyExe = Join-Path $InstallDir 'alloy-windows-amd64.exe'
  if(-not (Assert-YcFile -Path $alloyExe -MinBytes 1048576 -Because 'installed Alloy binary')){
    Write-YcLog ('The installer returned success but ' + $alloyExe + ' does not exist. NSIS returns 0 ' +
      'even on a partial install, which is why this is checked rather than trusted.') 'ERROR'
    $script:YcExit = 1; return
  }

  # --- 5. the config goes exactly where the service reads it --------------------------
  # The service's command line lives in HKLM\SOFTWARE\GrafanaLabs\Alloy -> Arguments
  # (REG_MULTI_SZ: run | <config> | --storage.path=...). It is written EXPLICITLY here and
  # then READ BACK, so the config path is proven rather than assumed - the old script wrote
  # %ProgramData%\GrafanaLabs\Alloy\config.alloy, which nothing ever reads.
  $dataPath = Join-Path $env:ProgramData 'GrafanaLabs\Alloy\data'
  $wanted = @('run',$target,('--storage.path=' + $dataPath))
  if($Environment){
    foreach($e in ($Environment -split ';')){ if($e.Trim().Length -gt 0){ $wanted += $e.Trim() } }
  }
  if(-not (Set-YcAlloyArguments -Values $wanted)){ $script:YcExit = 1; return }
  $effective = Get-YcAlloyConfigPathFromRegistry
  if(-not $effective){
    Write-YcLog ('VERIFICATION FAILED: after writing them, the Arguments registry value still does ' +
      'not name a .alloy file.') 'ERROR'
    $script:YcExit = 1; return
  }
  if($effective -ne $target){
    Write-YcLog ('The service is configured to load ' + $effective + ', not ' + $target +
      '. Writing the configuration to the path the SERVICE reads.') 'WARN'
    $script:YcCfgPath = $effective
  }
  $cfgDir = Split-Path -Parent $script:YcCfgPath
  if($cfgDir -and -not (Test-Path -LiteralPath $cfgDir)){ New-Item -ItemType Directory -Path $cfgDir -Force | Out-Null }
  Set-YcManagedFile -Path $script:YcCfgPath -Content $cfgText -Always:$Force | Out-Null
  if(-not (Protect-YcFileAcl -Path $script:YcCfgPath)){ $script:YcExit = 1; return }

  # --- 6. extra service arguments (-Environment) --------------------------------------
  # Applied above, in the same REG_MULTI_SZ write that fixes the config path. In the old
  # script this parameter was documented in the help and referenced nowhere in the code.
  if($Environment){
    Write-YcLog ('-Environment applied as extra service arguments (see the Arguments value logged ' +
      'above).') 'OK'
  }

  # --- 7. PROOF: the VENDOR validator, before the service is touched ------------------
  # https://grafana.com/docs/alloy/latest/reference/cli/validate/
  Write-YcLog ('Validating with the vendor validator: "' + $alloyExe + '" validate --stability.level ' +
    $StabilityLevel + ' "' + $script:YcCfgPath + '"')
  $chk = Invoke-YcNative -File $alloyExe -Arguments @('validate','--stability.level',$StabilityLevel,$script:YcCfgPath)
  foreach($l in $chk.Output){ if($l.Trim().Length -gt 0){ Write-Host ('    ' + (Protect-YcSecret $l)) } }
  if($chk.ExitCode -ne 0){
    Write-YcLog ('VERIFICATION FAILED: alloy validate exited ' + $chk.ExitCode + '. The configuration ' +
      'is invalid; the service was NOT restarted.') 'ERROR'
    Restore-YcBackup
    $script:YcExit = 1; return
  }
  Write-YcLog 'Vendor config validation passed (alloy validate exit 0).' 'OK'

  # --- 8. PROOF: the service runs and STAYS running -----------------------------------
  $svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
  if(-not $svc){
    Write-YcLog ('VERIFICATION FAILED: the service "' + $ServiceName + '" does not exist after a ' +
      'successful installer run.') 'ERROR'
    $script:YcExit = 1; return
  }
  # Delayed auto-start: sysprep-safe, consistent with the rest of the toolkit.
  # https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sc-config
  $sc1 = Invoke-YcNative -File 'sc.exe' -Arguments @('config',$ServiceName,'start=','delayed-auto')
  if($sc1.ExitCode -ne 0){
    Write-YcLog ('sc.exe config ' + $ServiceName + ' start= delayed-auto returned ' + $sc1.ExitCode +
      ': ' + ($sc1.Output -join ' ')) 'WARN'
  }
  try{
    if($svc.Status -eq 'Running'){ Restart-Service -Name $ServiceName -Force -ErrorAction Stop }
    else{ Start-Service -Name $ServiceName -ErrorAction Stop }
  }catch{
    Write-YcLog ('Could not start ' + $ServiceName + ': ' + $_.Exception.Message) 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcService -Name $ServiceName -TimeoutSec 60 -StartIfStopped -Because 'Alloy collector')){
    $script:YcExit = 1; return
  }
  Start-Sleep -Seconds 15
  $svc2 = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
  if((-not $svc2) -or ($svc2.Status -ne 'Running')){
    $st = 'absent'; if($svc2){ $st = [string]$svc2.Status }
    Write-YcLog ('VERIFICATION FAILED: ' + $ServiceName + ' reached Running but is now "' + $st +
      '" 15s later - it crashed on the configuration it just loaded.') 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Service ' + $ServiceName + ' is Running and stayed Running.') 'OK'

  # --- 9. PROOF: ready, healthy, and serving its own metrics --------------------------
  # https://grafana.com/docs/alloy/latest/reference/http/
  $base = 'http://127.0.0.1:' + $UiPort
  if(-not (Assert-YcHttp -Uri ($base + '/-/ready') -ExpectStatus 200 -TimeoutSec 90 -MatchContent 'ready')){
    Write-YcLog ('VERIFICATION FAILED: ' + $base + '/-/ready never returned 200. Alloy is running but ' +
      'has not loaded a configuration.') 'ERROR'
    $script:YcExit = 1; return
  }
  $healthy = Assert-YcHttp -Uri ($base + '/-/healthy') -ExpectStatus 200 -TimeoutSec 60
  if(-not $healthy){
    if($AllowUnhealthy){
      Write-YcLog ($base + '/-/healthy is not 200: at least one component is unhealthy (typically ' +
        'remote_write or loki.write cannot reach its endpoint). -AllowUnhealthy was passed, so this ' +
        'is a WARN - but this host is NOT shipping telemetry yet.') 'WARN'
    }else{
      Write-YcLog ('VERIFICATION FAILED: ' + $base + '/-/healthy did not return 200. At least one ' +
        'component is unhealthy, which means Alloy is running but not shipping. Open ' + $base +
        ' to see which component, fix it, and re-run. Pass -AllowUnhealthy to downgrade this to a ' +
        'warning when the remote endpoint is knowingly down.') 'ERROR'
      $script:YcExit = 1; return
    }
  }
  if(-not (Assert-YcHttp -Uri ($base + '/metrics') -ExpectStatus 200 -TimeoutSec 60 -MatchContent 'alloy_build_info')){
    Write-YcLog ('VERIFICATION FAILED: ' + $base + '/metrics did not serve alloy_build_info.') 'ERROR'
    $script:YcExit = 1; return
  }

  # AGENT = push OUT: no inbound firewall rule is created. The UI is loopback-only by default
  # (--server.http.listen-addr defaults to 127.0.0.1:12345).
  Write-YcLog ('DONE. Alloy Running, config ' + $script:YcCfgPath + ' validated by "alloy validate" ' +
    'and loaded by the service, /-/ready 200' + $(if($healthy){', /-/healthy 200'}else{''}) +
    '. No inbound port opened.') 'OK'
  $script:YcExit = 0
}

try{
  Invoke-Main | Out-Null
}catch{
  Write-YcLog ('UNHANDLED EXCEPTION: ' + (Protect-YcSecret $_.Exception.Message)) 'ERROR'
  if($_.ScriptStackTrace){ Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}finally{
  if($script:YcTemp -and (Test-Path -LiteralPath $script:YcTemp)){
    try{ Remove-Item -LiteralPath $script:YcTemp -Recurse -Force }
    catch{ Write-YcLog ('Could not remove temp dir ' + $script:YcTemp + ': ' + $_.Exception.Message) 'WARN' }
  }
}

if($script:YcExit -eq 0){ Exit-Yc 0 'alloy-register verified' 'OK' }
Exit-Yc $script:YcExit 'alloy-register FAILED - see the lines above; nothing was reported as installed that is not proven' 'ERROR'
