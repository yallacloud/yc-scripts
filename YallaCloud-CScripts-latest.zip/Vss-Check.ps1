param(
  [switch]$Json,
  [switch]$Full,
  [int]$EventHours = 24,
  [switch]$SelfCheck,
  [switch]$Help
)
# ================================================================================================
# Vss-Check.ps1 - YALLACLOUD day-2 command: report the true state of Volume Shadow Copy, and
# detect the failures that turn an application-consistent backup into a crash-consistent one
# without anybody noticing.
# PowerShell 5.1 only, ASCII only, Windows Server 2016-2025. READ-ONLY: changes nothing.
#
# ------------------------------------------------------------------------------------------------
# WHY
# ------------------------------------------------------------------------------------------------
# This estate is backed up three different ways and every one of them ends at VSS:
#   - Acronis and other in-guest agents call VSS directly.
#   - PBS is AGENTLESS: it asks qemu-guest-agent (KVM) or VMware Tools (vCenter) to freeze the
#     guest, and THAT calls VSS inside the machine.
# When VSS breaks, none of them stop. The backup still completes - it is simply no longer
# application-consistent, so SQL Server and any other VSS-aware application are captured
# mid-write. The job is green and the restore is not. That is the failure this command exists to
# find, and it is why it reports on WRITERS rather than on whether a backup ran.
#
# A writer that is not in state 1 (Stable) with last error "No error" is the signal. The classic
# ones: "Timed out" under memory pressure or a long freeze, "Retryable error" after a previous
# snapshot was abandoned, and a writer that has vanished from the list entirely because its
# service is stopped.
#
# EXIT CODES: 0 healthy | 1 at least one WARN | 2 at least one CRITICAL | 5 not elevated
# Log: C:\Scripts\vss-check.log
# ================================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'vss-check'
$ErrorActionPreference = 'Continue'

if($Help){
@"
vss-check  -  is VSS actually healthy? Changes nothing, safe to run any time.

THE ONLY COMMAND MOST PEOPLE NEED:

  vss-check

That is it. It prints one block per problem, or says everything is healthy, and sets an exit
code your monitoring can act on.

WHY YOU WOULD RUN IT:
  A backup that says SUCCESS is not the same as a backup you can restore. Acronis, and PBS
  through qemu-guest-agent or VMware Tools, all rely on VSS to freeze the machine so databases
  and mail stores are captured cleanly. If VSS is broken the backup STILL SUCCEEDS - it just
  quietly stops being application-consistent, and you find out when a restore comes back
  corrupted. This command tells you before that happens.

OPTIONS:
  -Full           Also list every writer and provider, not just the problems.
  -EventHours N   How far back to read VSS errors from the event log. Default 24.
  -Json           One JSON object per finding, for Salt / an RMM / a monitor.
  -SelfCheck      Run the built-in assertions and exit. Needs no admin, changes nothing.
  -Help           This text.

WHAT IT CHECKS:
  1. Every VSS writer, its state and its last error.
  2. Every VSS provider - the Microsoft one, and the hypervisor one that PBS drives.
  3. Shadow storage: where it lives, and whether it has room. A full one fails snapshots.
  4. The services VSS needs, and whether they are disabled.
  5. qemu-guest-agent / VMware Tools presence, because on this estate they ARE the backup path.
  6. VSS, VolSnap and application errors in the event log.

EXIT CODES: 0 healthy, 1 one or more warnings, 2 one or more critical findings, 5 not elevated.
Log: C:\Scripts\vss-check.log
"@ | Write-Host -ForegroundColor Cyan
  Stop-YcLog 0; exit 0
}

# ---------------------------------------------------------------------------------------------
# Pure helpers - what -SelfCheck asserts.
# ---------------------------------------------------------------------------------------------

# vssadmin prints writers as a block per writer. Parse the state and the last error out of the
# text, because there is no supported API for this on Server without extra components.
function ConvertFrom-YcVssWriters{
  param([string[]]$Lines)
  $out = @()
  $cur = $null
  foreach($l in $Lines){
    if($l -match "^\s*Writer name:\s*'(.+)'\s*$"){
      if($cur){ $out += $cur }
      $cur = [pscustomobject]@{ Name = $Matches[1]; State = ''; LastError = ''; Id = '' }
      continue
    }
    if(-not $cur){ continue }
    if($l -match '^\s*Writer Id:\s*(\S+)')      { $cur.Id        = $Matches[1]; continue }
    if($l -match '^\s*State:\s*(.+?)\s*$')      { $cur.State     = $Matches[1]; continue }
    if($l -match '^\s*Last error:\s*(.+?)\s*$') { $cur.LastError = $Matches[1]; continue }
  }
  if($cur){ $out += $cur }
  return ,$out
}

# A writer is healthy when it is Stable AND its last error is "No error". Anything else means the
# next application-consistent snapshot is at risk, even though the backup will still "succeed".
function Test-YcWriterHealthy{
  param([string]$State,[string]$LastError)
  if("$State" -notmatch '(?i)stable'){ return $false }
  if("$LastError" -and "$LastError" -notmatch '(?i)^no error$'){ return $false }
  return $true
}

# A VSS error logged because the machine was shutting down is not a backup problem. Windows
# tears COM down before VSS, so every reboot leaves 0x8007045b behind. Reporting those makes the
# check cry wolf after every restart, and a monitor that cries wolf gets muted - which is how the
# real failure then gets missed. Seen live on 2026-09-01 after two deliberate reboots.
function Test-YcVssShutdownNoise{
  param([string]$Message)
  return ("$Message" -match '0x8007045b' -or "$Message" -match '(?i)system shutdown is in progress')
}

# What the well-known VSS event IDs actually mean, so the finding names the cause rather than
# telling the operator to go and read the event log they are already looking at.
function Get-YcVssEventRemedy{
  param([string]$Id,[string]$Message)
  if("$Message" -match '0x80070005' -or "$Message" -match '(?i)access is denied'){
    return 'Access denied calling a VSS interface. The backup ran as an account that is not a local Administrator or is missing the Backup Operators rights, or DCOM permissions were tightened by policy. Check which account Acronis / the guest agent runs as - this is a permissions problem, not a VSS fault.'
  }
  switch("$Id"){
    '8193'  { return 'VSS could not create a COM object it needs. If it is not shutdown noise, the usual cause is a corrupted VSS COM registration or a permissions change.' }
    '8194'  { return 'VSS could not query the writer callback interface. Almost always the account running the backup lacks rights.' }
    '12289' { return 'A volume-level VSS operation failed. Check the volume named in the event for space and for filter-driver conflicts with another backup agent.' }
    '13'    { return 'A COM server VSS depends on could not start. If it is not shutdown noise, restart the machine outside the backup window and re-check.' }
    default { return 'Correlate with the backup window. A VSS or VolSnap error at the time a backup ran means that backup was not application-consistent.' }
  }
}

# The documented remedy for the states we can actually name. Never a blind restart of everything.
function Get-YcVssRemedy{
  param([string]$State,[string]$LastError)
  $s = "$State"; $e = "$LastError"
  if($e -match '(?i)timed out'){
    return 'The writer did not finish freezing in time. Usually memory pressure or a very busy volume during the backup window. Re-run the backup off-peak; if it repeats, restart the service that owns this writer (see the writer name) and check for a long-running transaction.'
  }
  if($e -match '(?i)retryable'){
    return 'A previous snapshot was abandoned and left this writer unstable. It normally clears by itself; if it does not, restart the service that owns this writer. Do NOT restart all VSS services blindly on a production box.'
  }
  if($e -match '(?i)non-retryable|unexpected error'){
    return 'A hard failure. Read the application event log around the failure time for the owning service. This one does not clear on its own and the next backup of this application will NOT be consistent.'
  }
  if($s -match '(?i)failed'){
    return 'Writer is in a failed state. Restart the service that owns it, then re-run vss-check before trusting the next backup.'
  }
  if($s -match '(?i)waiting for completion'){
    return 'A snapshot is in progress or was never torn down. If no backup is running, a previous job left it behind - it usually clears within minutes.'
  }
  return 'No documented remedy for this state. Capture this output and the application event log before changing anything.'
}

if($SelfCheck){
  $script:n=0; $script:bad=0
  function T{ param([string]$What,[bool]$Ok)
    $script:n++
    if($Ok){ Write-Host ('  ok   ' + $What) -ForegroundColor Green } else { Write-Host ('  FAIL ' + $What) -ForegroundColor Red; $script:bad++ } }
  $sample = @(
    "Writer name: 'SqlServerWriter'",
    "   Writer Id: {a65faa63-5ea8-4ebc-9dbd-a0c4db26912a}",
    "   Writer Instance Id: {1111}",
    "   State: [1] Stable",
    "   Last error: No error",
    "Writer name: 'System Writer'",
    "   Writer Id: {e8132975-6f93-4464-a53e-1050253ae220}",
    "   State: [8] Failed",
    "   Last error: Timed out"
  )
  $w = ConvertFrom-YcVssWriters -Lines $sample
  T 'both writers are parsed out of the vssadmin block'  ($w.Count -eq 2)
  T 'the writer name is captured without quotes'         ($w[0].Name -eq 'SqlServerWriter')
  T 'the state is captured'                              ($w[1].State -match 'Failed')
  T 'the last error is captured'                         ($w[1].LastError -eq 'Timed out')
  T 'a stable writer with no error is healthy'           (Test-YcWriterHealthy -State '[1] Stable' -LastError 'No error')
  T 'a failed writer is not healthy'                     (-not (Test-YcWriterHealthy -State '[8] Failed' -LastError 'Timed out'))
  T 'stable but with an error is NOT healthy'            (-not (Test-YcWriterHealthy -State '[1] Stable' -LastError 'Retryable error'))
  T 'a timeout gets the timeout remedy'                  ((Get-YcVssRemedy -State '[8] Failed' -LastError 'Timed out') -match 'off-peak')
  T 'a retryable error gets its own remedy'              ((Get-YcVssRemedy -State '[5] Waiting' -LastError 'Retryable error') -match 'abandoned')
  T 'an unknown state does not invent a fix'             ((Get-YcVssRemedy -State 'Something' -LastError 'No error') -match 'No documented remedy')
  T 'a shutdown VSS error is recognised as noise'        (Test-YcVssShutdownNoise -Message 'hr = 0x8007045b, A system shutdown is in progress.')
  T 'a real VSS error is NOT treated as noise'           (-not (Test-YcVssShutdownNoise -Message 'hr = 0x80070005, Access is denied.'))
  T 'access denied names the permissions cause'          ((Get-YcVssEventRemedy -Id '8194' -Message 'hr = 0x80070005, Access is denied.') -match 'account')
  T 'a known event id has its own explanation'           ((Get-YcVssEventRemedy -Id '12289' -Message 'x') -match 'volume')
  Write-Host ''
  if($script:bad -eq 0){ Write-Host ('SELF-CHECK PASSED: ' + $script:n + ' assertions') -ForegroundColor Green; Stop-YcLog 0; exit 0 }
  Write-Host ('SELF-CHECK FAILED: ' + $script:bad + ' of ' + $script:n + ' assertions') -ForegroundColor Red
  Stop-YcLog 1; exit 1
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation -BoundParameters $PSBoundParameters

$script:Findings = New-Object System.Collections.Generic.List[object]
function Add-YcFinding{
  param([string]$Severity,[string]$Area,[string]$Subject,[string]$Detail,[string]$Remedy)
  $f = [pscustomobject]@{
    Severity = $Severity; Area = $Area; Subject = $Subject; Detail = $Detail; Remedy = $Remedy
    Host = $env:COMPUTERNAME; When = (Get-Date).ToString('yyyy-MM-ddTHH:mm:sszzz')
  }
  [void]$script:Findings.Add($f)
  Write-YcLog ('VSS ' + $Severity + ' area=' + $Area + ' subject="' + $Subject + '" detail="' + $Detail + '"') `
    $(if($Severity -eq 'CRITICAL'){'ERROR'} elseif($Severity -eq 'WARN'){'WARN'} else {'OK'})
  if($Remedy){ Write-YcLog ('    remedy: ' + $Remedy) }
}

# ---- 1. writers -------------------------------------------------------------------------------
Write-YcLog 'Reading VSS writers (vssadmin list writers)...'
$wLines = @()
try{ $wLines = @(& vssadmin.exe list writers 2>&1 | Out-String -Stream) }catch{}
$writers = ConvertFrom-YcVssWriters -Lines $wLines
if($writers.Count -eq 0){
  Add-YcFinding 'CRITICAL' 'writers' 'vssadmin list writers' `
    'No writers were returned at all. VSS itself is not answering, so NO application-consistent backup can be taken on this machine.' `
    'Check that the Volume Shadow Copy service can start, then re-run. If it cannot, this is the whole problem and every backup taken meanwhile is crash-consistent only.'
} else {
  Write-YcLog ($writers.Count.ToString() + ' writer(s) reported.')
  foreach($w in $writers){
    if(Test-YcWriterHealthy -State $w.State -LastError $w.LastError){
      if($Full){ Write-YcLog ('  OK  ' + $w.Name + '  ' + $w.State) 'OK' }
    } else {
      Add-YcFinding 'CRITICAL' 'writer' $w.Name `
        ('state=' + $w.State + ' lastError=' + $w.LastError + '. An application-consistent backup of whatever this writer protects will NOT be consistent, and the backup job will still report success.') `
        (Get-YcVssRemedy -State $w.State -LastError $w.LastError)
    }
  }
  # The SQL writer is the one that matters most here, and its absence is silent.
  if($writers.Count -gt 0 -and -not @($writers | Where-Object { $_.Name -match '(?i)sqlserverwriter' })){
    $sqlSvc = @(Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'MSSQLSERVER' -or $_.Name -like 'MSSQL$*' })
    if($sqlSvc.Count -gt 0){
      Add-YcFinding 'CRITICAL' 'writer' 'SqlServerWriter' `
        ('SQL Server is installed (' + (($sqlSvc | Select-Object -Expand Name) -join ', ') + ') but the SQL writer is NOT in the writer list. Every snapshot-based backup of this machine is capturing the databases mid-write.') `
        'Start the "SQL Server VSS Writer" service (SQLWriter) and set it to Automatic, then re-run vss-check.'
    }
  }
}

# ---- 2. providers -----------------------------------------------------------------------------
$pLines = @()
try{ $pLines = @(& vssadmin.exe list providers 2>&1 | Out-String -Stream) }catch{}
$provNames = @()
foreach($l in $pLines){ if($l -match "^\s*Provider name:\s*'(.+)'\s*$"){ $provNames += $Matches[1] } }
if($provNames.Count -eq 0){
  Add-YcFinding 'CRITICAL' 'providers' 'vssadmin list providers' 'No VSS provider is registered. Snapshots cannot be created at all.' `
    'Re-register the Microsoft Software Shadow Copy provider and confirm the VSS service starts.'
} else {
  Write-YcLog ('provider(s): ' + ($provNames -join ', '))
  if($Full){ foreach($p in $provNames){ Write-YcLog ('  provider: ' + $p) 'OK' } }
}

# ---- 3. shadow storage ------------------------------------------------------------------------
$sLines = @()
try{ $sLines = @(& vssadmin.exe list shadowstorage 2>&1 | Out-String -Stream) }catch{}
$anyStorage = @($sLines | Where-Object { $_ -match '(?i)shadow copy storage' }).Count
if($anyStorage -eq 0){
  Add-YcFinding 'INFO' 'shadowstorage' 'shadow storage' 'No shadow copy storage association is configured yet. Windows creates one on the first snapshot; this is normal on a machine that has not been backed up yet.' ''
} else {
  foreach($l in $sLines){ if($l -match '(?i)(used|allocated|maximum) shadow copy storage space'){ Write-YcLog ('  ' + $l.Trim()) } }
}
# A volume with very little free space cannot hold a snapshot, and that is a silent backup failure.
foreach($v in @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction SilentlyContinue)){
  if($v.Size -gt 0){
    $pct = [math]::Round(($v.FreeSpace / $v.Size) * 100, 1)
    if($pct -lt 10){
      Add-YcFinding 'WARN' 'shadowstorage' ($v.DeviceID) `
        ('only ' + $pct + '% free (' + [math]::Round($v.FreeSpace/1GB,1) + ' GB). VSS needs room on the volume to hold the shadow copy; below roughly 10% snapshots start failing or get deleted immediately, which silently downgrades the backup.') `
        'Free space on this volume, or point shadow storage at a different volume with vssadmin resize shadowstorage.'
    }
  }
}

# ---- 4. the services VSS needs ----------------------------------------------------------------
foreach($svc in 'VSS','swprv','SQLWriter'){
  $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
  if($null -eq $s){
    if($svc -eq 'SQLWriter'){
      $sqlSvc = @(Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'MSSQLSERVER' -or $_.Name -like 'MSSQL$*' })
      if($sqlSvc.Count -gt 0){
        Add-YcFinding 'CRITICAL' 'service' 'SQLWriter' 'SQL Server is installed but the SQL Server VSS Writer service is not present.' `
          'Install or repair the SQL Server VSS Writer component from SQL Server setup. Without it no snapshot backup of this machine is database-consistent.'
      }
    }
    continue
  }
  $wmi = Get-CimInstance Win32_Service -Filter ("Name='" + $svc + "'") -ErrorAction SilentlyContinue
  $start = if($wmi){ [string]$wmi.StartMode } else { '' }
  if($start -match '(?i)disabled'){
    Add-YcFinding 'CRITICAL' 'service' $svc ('start type is Disabled. VSS cannot function.') `
      ('Set ' + $svc + ' back to Manual (VSS and swprv are Manual by design and start on demand; SQLWriter should be Automatic).')
  } elseif($Full){
    Write-YcLog ('  service ' + $svc + ' status=' + $s.Status + ' start=' + $start) 'OK'
  }
}

# ---- 5. the agentless path: qemu-guest-agent / VMware Tools ------------------------------------
$qemu = Get-Service -Name 'QEMU-GA','qemu-ga' -ErrorAction SilentlyContinue | Select-Object -First 1
$vmt  = Get-Service -Name 'VMTools' -ErrorAction SilentlyContinue
if($null -eq $qemu -and $null -eq $vmt){
  Add-YcFinding 'WARN' 'agentless' 'guest agent' `
    'Neither qemu-guest-agent nor VMware Tools is installed. PBS backs this estate up AGENTLESSLY by asking one of them to freeze the guest - without it, a PBS snapshot of this machine is crash-consistent, not application-consistent.' `
    'Install qemu-guest-agent on KVM guests, or VMware Tools with the VSS component on vCenter guests, then re-run vss-check.'
} else {
  $agent = if($qemu){ $qemu } else { $vmt }
  if($agent.Status -ne 'Running'){
    Add-YcFinding 'CRITICAL' 'agentless' $agent.Name `
      ('the guest agent is installed but ' + $agent.Status + '. PBS cannot freeze this guest, so its snapshots are crash-consistent while still reporting success.') `
      ('Start the ' + $agent.Name + ' service and set it to Automatic.')
  } else {
    Write-YcLog ('guest agent ' + $agent.Name + ' is Running - the agentless freeze path is available.') 'OK'
  }
}

# ---- 6. what the event log says ---------------------------------------------------------------
$since = (Get-Date).AddHours(-1 * [math]::Abs($EventHours))
$evt = @()
try{
  $evt = @(Get-WinEvent -FilterHashtable @{ LogName='Application','System'; Level=1,2; StartTime=$since } -ErrorAction SilentlyContinue |
           Where-Object { $_.ProviderName -match '(?i)VSS|VolSnap|Volume Shadow' })
}catch{}
if($evt.Count -gt 0){
  $noise = @($evt | Where-Object { Test-YcVssShutdownNoise -Message $_.Message }).Count
  $real  = @($evt | Where-Object { -not (Test-YcVssShutdownNoise -Message $_.Message) })
  if($noise -gt 0){
    Write-YcLog ($noise.ToString() + ' VSS event(s) in the last ' + $EventHours + 'h were logged during a system shutdown (0x8007045b). Windows tears COM down before VSS, so every reboot leaves these behind - not a backup problem, not reported as a finding.') 'OK'
  }
  $grouped = $real | Group-Object Id | Sort-Object Count -Descending
  foreach($g in $grouped){
    $first = $g.Group[0]
    Add-YcFinding 'WARN' 'eventlog' ($first.ProviderName + ' event ' + $g.Name) `
      ($g.Count.ToString() + ' occurrence(s) in the last ' + $EventHours + 'h. Latest: ' + (($first.Message -split "`n")[0])) `
      (Get-YcVssEventRemedy -Id $g.Name -Message $first.Message)
  }
} else {
  Write-YcLog ('No VSS, VolSnap or Volume Shadow errors in the Application or System log in the last ' + $EventHours + ' hours.') 'OK'
}

# ---- report -----------------------------------------------------------------------------------
$crit = @($script:Findings | Where-Object { $_.Severity -eq 'CRITICAL' }).Count
$warn = @($script:Findings | Where-Object { $_.Severity -eq 'WARN' }).Count

if($Json){
  foreach($f in $script:Findings){ Write-Output (($f | ConvertTo-Json -Compress -Depth 3)) }
} else {
  Write-Host ''
  if($script:Findings.Count -eq 0){
    Write-Host '  VSS is healthy. Every writer is Stable with no error, a provider is registered, and no VSS errors were logged.' -ForegroundColor Green
  } else {
    foreach($f in $script:Findings){
      $col = switch($f.Severity){ 'CRITICAL' {'Red'} 'WARN' {'Yellow'} default {'Gray'} }
      Write-Host ('  [' + $f.Severity + '] ' + $f.Area + ' - ' + $f.Subject) -ForegroundColor $col
      Write-Host ('      ' + $f.Detail)
      if($f.Remedy){ Write-Host ('      FIX: ' + $f.Remedy) }
    }
  }
  Write-Host ''
}

Write-YcLog ('vss-check complete: ' + $crit + ' critical, ' + $warn + ' warning, ' + $script:Findings.Count + ' finding(s) total.') `
  $(if($crit -gt 0){'ERROR'} elseif($warn -gt 0){'WARN'} else {'OK'})
if($crit -gt 0){ Exit-Yc 2 'VSS has at least one CRITICAL finding - snapshot backups of this machine are not application-consistent.' 'ERROR' }
if($warn -gt 0){ Exit-Yc 1 'VSS has warnings - see the findings above.' 'WARN' }
Exit-Yc 0 'VSS is healthy.' 'OK'
