param(
  [string]$MyHost,
  [string]$MyUser = 'exporter',
  [string]$MyPassword,
  [int]$MyPort = 3306,
  [string]$DataSourceName,
  [int]$ListenPort = 9104,
  [string]$MyPasswordFile,
  [string]$ZipPath,
  [string]$DownloadUrl,
  [string]$Sha256,
  [string]$InstallDir = 'C:\Program Files\mysqld_exporter',
  [string]$ServiceName = 'mysqld_exporter',
  [string]$BindAddress = '',
  [string[]]$RemoteAddress = @('LocalSubnet'),
  [string[]]$FirewallProfile = @('Domain','Private'),
  [string]$WinSwPath,
  [string]$WinSwUrl,
  [string]$WinSwSha256,
  [switch]$AllowAnyRemote,
  [switch]$SkipFirewall,
  [switch]$Force,
  [switch]$Help
)
# =====================================================================================
# MysqldExporter-Register.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
# Installs mysqld_exporter UNDER A SERVICE WRAPPER (because it cannot be a Windows service
# on its own) and PROVES it is scraping MySQL before anything else happens.
#
# WHAT CHANGED AND WHY
# --------------------
#  1. [P0-25] THE EXPORTER WAS REGISTERED AS A WINDOWS SERVICE, WHICH IT CANNOT BE.
#     The old script did:
#         New-Service -Name mysqld_exporter -BinaryPathName $bin ... -EA SilentlyContinue
#         Start-Service $svcName -EA SilentlyContinue
#     mysqld_exporter is a plain Go binary with NO Windows service control handler. Verified
#     against the current release: its go.mod requires only kingpin, go-sql-driver/mysql,
#     client_golang, common, exporter-toolkit, ini.v1 and test libraries - there is no
#     github.com/kardianos/minwinsvc and no golang.org/x/sys/windows/svc. The SCM starts the
#     process, never receives StartServiceCtrlDispatcher, and kills it after 30 seconds with
#     ERROR 1053 (upstream issue #814). Both -EA SilentlyContinue calls hid that, and the
#     script then logged 'done - scrape at http://<host>:9104/metrics' and exited 0.
#     THIS EXPORTER HAS NEVER RUN ON ANY VM.
#     FIX: the exporter is now run under WinSW (github.com/winsw/winsw), a service wrapper
#     that DOES implement the dispatcher and supervises the child process.
#     WHY WinSW AND NOT NSSM: NSSM's last stable release is 2.24 and the newest build
#     published on nssm.cc is a 2017 pre-release, described by its own author as risky;
#     WinSW is actively maintained (v2.12.0 stable), ships as a single self-contained .exe
#     with no runtime to install on Server 2016-2025, takes a declarative XML file (so the
#     service definition is inspectable and idempotent), and supports <env> and
#     <onfailure action="restart"> natively. The wrapper is acquired from a staged file
#     (C:\Scripts\WinSW-x64.exe or WinSW.NET461.exe) or downloaded with -WinSwUrl +
#     -WinSwSha256; it is never silently skipped.
#  2. IT NO LONGER LIES. Proof is now, in order: the exporter binary reports its version;
#     the wrapper service exists and reaches Running; it is STILL Running after a settle
#     window; http://127.0.0.1:<port>/metrics returns 200 with Prometheus text; and the body
#     contains mysql_up 1. mysql_up 0 (exporter up, database unreachable or the grant is
#     missing) is a FAILURE, not a success - that is precisely the state the old script
#     reported as 'done'. No -ErrorAction SilentlyContinue remains on any load-bearing call.
#  3. THE PASSWORD LEAVES THE COMMAND LINE AND THE WORLD-READABLE FILE.
#     - Preferred input is -MyPasswordFile <path> or the environment variable
#       YC_MYSQLD_EXPORTER_PASSWORD. Neither appears in the process table, in a Windows 4688
#       ProcessCreation event, or in the PowerShell transcript header. -MyPassword still
#       works but logs a loud WARN naming the exposure.
#     - my.cnf is written with inheritance stripped and SYSTEM + Administrators only, and the
#       ACL is VERIFIED. It used to inherit from C:\Program Files, so BUILTIN\Users could
#       read the exporter's MySQL password.
#     - The credential never appears in the service ImagePath or in the wrapper XML.
#  4. THE DSN PARSER WAS WRONG. The old regex '^(.*?):(.*)@\((.*?):(\d+)\)' does NOT match
#     the canonical go-sql-driver form user:pass@tcp(host:3306)/ - it requires '@(' - so the
#     real-world DSN left $MyHost empty and wrote 'host=' into my.cnf, pointing the exporter
#     at nothing. Both forms are parsed now, the last '@' is used as the separator (so a
#     password containing '@' no longer splits wrongly), and a DSN that cannot be parsed is a
#     hard error instead of a silent empty host.
#  5. [cross-cutting] THE LISTENER IS NO LONGER WORLD-OPEN. -RemoteAddress defaults to
#     LocalSubnet, -FirewallProfile to Domain,Private, 'Any' is refused unless
#     -AllowAnyRemote is passed, and -BindAddress can pin the listener to the management IP.
#     mysqld_exporter /metrics leaks schema and table names, replication topology and query
#     counts. The rule is created ONLY after /metrics has been proven.
#  6. Version-aware staged-zip selection ([version] parse, not the old lexical sort), an
#     optional -Sha256 pin, service removal that POLLS instead of Start-Sleep 2, idempotent
#     managed files, unhandled-exception guard and temp cleanup.
#
# PARAMETERS ADDED (none renamed, none removed): -MyPasswordFile, -ZipPath, -DownloadUrl,
#     -Sha256, -InstallDir, -ServiceName, -BindAddress, -RemoteAddress, -FirewallProfile,
#     -WinSwPath, -WinSwUrl, -WinSwSha256, -AllowAnyRemote, -SkipFirewall, -Force.
#
# VERIFIED AGAINST THE CURRENT RELEASE (docs/source, not memory):
#   no Windows service dispatcher in mysqld_exporter
#     https://github.com/prometheus/mysqld_exporter/blob/main/go.mod
#     https://github.com/prometheus/mysqld_exporter/issues/814
#   --config.my-cnf, --mysqld.address, --mysqld.username, --web.listen-address, my.cnf
#   [client] format, mysql_up
#     https://github.com/prometheus/mysqld_exporter/blob/main/README.md
#   WinSW XML elements (id/executable/arguments/env/log/onfailure/startmode/delayedAutoStart)
#   and the rename-the-exe-next-to-the-xml discovery rule
#     https://github.com/winsw/winsw/blob/v2.12.0/doc/xmlConfigFile.md
#     https://github.com/winsw/winsw/blob/v2/doc/installation.md
#   NSSM status (last stable 2.24, newest build 2017)
#     https://nssm.cc/builds
#
# Log: C:\Scripts\mysqldexporter-register.log
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'mysqldexporter-register'
$ErrorActionPreference = 'Stop'

$HelpText = @"
mysqldexporter-register - SILENT install of mysqld_exporter (Prometheus MySQL/MariaDB metrics
                          exporter) UNDER THE WinSW SERVICE WRAPPER, with an actual /metrics proof
                          (mysql_up 1) before any firewall rule is created.

  mysqld_exporter is a plain Go binary with no Windows service dispatcher: registered directly with
  New-Service it is killed by the SCM after 30s with error 1053. It therefore runs under WinSW.
  Stage C:\Scripts\WinSW-x64.exe (or WinSW.NET461.exe), or pass -WinSwPath / -WinSwUrl+-WinSwSha256.

USAGE:
  mysqldexporter-register -MyHost <host> -MyUser <user> -MyPasswordFile <file> [-MyPort 3306]
                          [-ListenPort 9104] [-RemoteAddress 10.20.0.11]
  mysqldexporter-register -DataSourceName 'exporter:pw@tcp(10.0.0.6:3306)/'
  mysqldexporter-register -Help

PARAMETERS:
  -MyHost           (required unless -DataSourceName) MySQL/MariaDB host the exporter connects to.
  -MyUser           DB user with the exporter grants (PROCESS, REPLICATION CLIENT, SELECT). Default exporter.
  -MyPasswordFile   PREFERRED. File whose first line is the DB password. Never appears in the process
                    table, in a 4688 event, or in the transcript header.
  -MyPassword       DEPRECATED, kept for compatibility. Visible in Win32_Process.CommandLine, in
                    Windows Security event 4688, and in the transcript header. Use -MyPasswordFile or
                    the environment variable YC_MYSQLD_EXPORTER_PASSWORD instead.
  -MyPort           DB port (default 3306).
  -DataSourceName   Full go-sql-driver DSN instead of the -My* parts. Both 'user:pw@tcp(host:port)/'
                    and 'user:pw@(host:port)/' are accepted (the old parser silently mishandled the
                    first, which is the canonical one).
  -ListenPort       TCP port for /metrics. Default 9104.
  -BindAddress      Listen address. Default '' = all interfaces. Set the management IP to keep the
                    exporter off the tenant-facing NIC.
  -RemoteAddress    Sources allowed through the inbound rule. Default LocalSubnet. 'Any' is refused
                    unless -AllowAnyRemote is also passed.
  -FirewallProfile  Profiles the rule applies to. Default Domain,Private.
  -AllowAnyRemote   Explicitly allow a world-open rule. Logs a loud WARN.
  -SkipFirewall     Do not create an inbound rule at all.
  -ZipPath          Explicit staged exporter zip. Default: newest
                    C:\Scripts\mysqld_exporter-*.windows-amd64.zip by PARSED version.
  -DownloadUrl      Download the exporter zip instead of using a staged one.
  -Sha256           Expected SHA256 of the exporter zip. Strongly recommended.
  -WinSwPath        Explicit WinSW executable. Default: C:\Scripts\WinSW-x64.exe, WinSW.NET461.exe or
                    WinSW.exe.
  -WinSwUrl         Download WinSW from here when it is not staged. Requires -WinSwSha256.
  -WinSwSha256      Expected SHA256 of the WinSW executable.
  -InstallDir       Install folder. Default C:\Program Files\mysqld_exporter.
  -ServiceName      Windows service name. Default mysqld_exporter.
  -Force            Rewrite my.cnf and the wrapper XML even if unchanged.
  -Help             Show this help and exit 0.

EXAMPLES:
  set YC_MYSQLD_EXPORTER_PASSWORD=...
  mysqldexporter-register -MyHost 10.0.0.6 -MyUser exporter -RemoteAddress 10.20.0.11
  mysqldexporter-register -MyHost localhost -MyUser exporter -MyPasswordFile C:\Scripts\.mysql.pw
  mysqldexporter-register -DataSourceName 'exporter:pw@tcp(10.0.0.6:3306)/' -RemoteAddress 10.20.0.11
  mysqldexporter-register -Help

PROOF PERFORMED (in this order - any failure is a non-zero exit):
  1. mysqld_exporter.exe --version                     -> version recorded in the log
  2. my.cnf written, then its ACL VERIFIED (SYSTEM + Administrators only)
  3. WinSW wrapper installed; service Running, polled, then re-checked after a settle window
  4. GET http://127.0.0.1:<port>/metrics               -> 200, Prometheus text
  5. the body contains 'mysql_up 1'                    -> the exporter is really talking to MySQL

EXIT CODES:
  0  Verified: service Running and mysql_up 1 on /metrics.
  1  Failure at any step (no installer, no WinSW, service not Running, /metrics dead, mysql_up 0).
  2  Usage error (no host/DSN, no password, unparseable DSN, RemoteAddress Any without -AllowAnyRemote).
  5  Not elevated.
  6  No outbound internet when -DownloadUrl / -WinSwUrl was used.

Log: C:\Scripts\mysqldexporter-register.log   Wrapper log: <InstallDir>\logs\
"@

if($Help){ Write-Host $HelpText -ForegroundColor Cyan; Exit-Yc 0 'help shown' 'OK' }
if(-not $MyHost -and -not $DataSourceName){
  Write-Host $HelpText -ForegroundColor Cyan
  Exit-Yc 2 'One of -MyHost or -DataSourceName is required.' 'ERROR'
}

Assert-YcPrereqs -NeedAdmin

# A .cmd wrapper or a parent script passing '-RemoteAddress 10.0.0.1,10.0.0.2' through
# powershell.exe -File delivers ONE string, not two elements, so New-NetFirewallRule would
# receive a single meaningless address. Split it back apart here.
function Split-YcList{
  param([string[]]$Value)
  $out = @()
  foreach($v in $Value){
    foreach($p in ([string]$v -split ',')){
      if($p.Trim().Length -gt 0){ $out += $p.Trim() }
    }
  }
  return $out
}
$RemoteAddress   = Split-YcList $RemoteAddress
$FirewallProfile = Split-YcList $FirewallProfile
$script:YcExit   = 1
$script:YcTemp   = $null
$script:YcSecret = $null

# ------------------------------------------------------------------ helpers

function Write-YcAsciiFile{
  param([string]$Path,[string]$Content)
  $sw = New-Object System.IO.StreamWriter($Path,$false,(New-Object System.Text.ASCIIEncoding))
  try{ $sw.Write($Content) } finally{ $sw.Close() }
}

function Invoke-YcNative{
  param([string]$File,[string[]]$Arguments)
  $ErrorActionPreference = 'Continue'
  $out = & $File @Arguments 2>&1
  $rc  = $LASTEXITCODE
  $txt = @()
  foreach($o in $out){ if($null -ne $o){ $txt += ([string]$o) } }
  return (New-Object psobject -Property @{ Output = $txt; ExitCode = $rc })
}

function Get-YcRedacted([string]$Text){
  $t = $Text
  if($script:YcSecret){ $t = ($t -replace [regex]::Escape($script:YcSecret),'***REDACTED***') }
  return (Protect-YcSecret $t)
}

function Protect-YcFileAcl{
  param([string]$Path)
  $r1 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/inheritance:r')
  $r2 = Invoke-YcNative -File 'icacls.exe' -Arguments @($Path,'/grant','*S-1-5-18:(F)','*S-1-5-32-544:(F)')
  if($r1.ExitCode -ne 0 -or $r2.ExitCode -ne 0){
    Write-YcLog ('icacls FAILED on ' + $Path + ' (inheritance rc=' + $r1.ExitCode + ', grant rc=' +
      $r2.ExitCode + '): ' + (($r1.Output + $r2.Output) -join ' ')) 'ERROR'
    return $false
  }
  $allowed = @('S-1-5-18','S-1-5-32-544')
  $acl = Get-Acl -LiteralPath $Path
  if(-not $acl.AreAccessRulesProtected){
    Write-YcLog ('VERIFICATION FAILED: inheritance is still enabled on ' + $Path) 'ERROR'
    return $false
  }
  $bad = @()
  foreach($ace in $acl.Access){
    $sid = $null
    try{ $sid = $ace.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch{ $sid = [string]$ace.IdentityReference }
    if($allowed -notcontains $sid){ $bad += ([string]$ace.IdentityReference + ' (' + $sid + ')') }
  }
  if($bad.Count -gt 0){
    Write-YcLog ('VERIFICATION FAILED: ' + $Path + ' is still accessible to: ' + ($bad -join ', ') +
      '. It contains the MySQL password.') 'ERROR'
    return $false
  }
  Write-YcLog ('ACL verified on ' + $Path + ': inheritance removed, trustees are exactly SYSTEM ' +
    'and BUILTIN\Administrators.') 'OK'
  return $true
}

function Set-YcManagedFile{
  param([string]$Path,[string]$Content,[switch]$Always)
  if(Test-Path -LiteralPath $Path){
    $cur = Get-Content -LiteralPath $Path -Raw
    if($null -eq $cur){ $cur = '' }
    if($cur -eq $Content -and -not $Always){ Write-YcLog ('Unchanged, left in place: ' + $Path); return $true }
    $bak = $Path + '.bak-' + (Get-Date).ToString('yyyyMMddHHmmss')
    Copy-Item -LiteralPath $Path -Destination $bak -Force
    Write-YcLog ('Content changed; previous file backed up to ' + $bak) 'WARN'
  }
  Write-YcAsciiFile -Path $Path -Content $Content
  Write-YcLog ('Wrote ' + $Path)
  return $true
}

function ConvertTo-YcXmlText([string]$Text){
  $t = $Text
  $t = $t -replace '&','&amp;'
  $t = $t -replace '<','&lt;'
  $t = $t -replace '>','&gt;'
  $t = $t -replace '"','&quot;'
  return $t
}

function Get-YcServiceObject([string]$Name){
  return (Get-Service | Where-Object { $_.Name -eq $Name } | Select-Object -First 1)
}

function Get-YcExporterPassword{
  if($MyPasswordFile){
    if(-not (Test-Path -LiteralPath $MyPasswordFile)){
      Write-YcLog ('-MyPasswordFile not found: ' + $MyPasswordFile) 'ERROR'; return $null
    }
    foreach($l in (Get-Content -LiteralPath $MyPasswordFile)){
      if($null -ne $l -and $l.Trim().Length -gt 0){
        Write-YcLog ('Password read from ' + $MyPasswordFile + ' (never on a command line).')
        return $l.Trim()
      }
    }
    Write-YcLog ('-MyPasswordFile ' + $MyPasswordFile + ' is empty.') 'ERROR'
    return $null
  }
  if($env:YC_MYSQLD_EXPORTER_PASSWORD){
    Write-YcLog 'Password read from environment variable YC_MYSQLD_EXPORTER_PASSWORD.'
    return $env:YC_MYSQLD_EXPORTER_PASSWORD
  }
  if($MyPassword){
    Write-YcLog ('-MyPassword was passed on the command line. That value is visible in ' +
      'Win32_Process.CommandLine, in Windows Security event 4688 (this estate can enable ' +
      'ProcessCreationIncludeCmdLine and forward the Security channel off-box) and in the ' +
      'PowerShell transcript header. Use -MyPasswordFile or YC_MYSQLD_EXPORTER_PASSWORD instead. ' +
      'The value is scrubbed from this log when the run ends.') 'WARN'
    return $MyPassword
  }
  return $null
}

# user:pass@tcp(host:port)/db  and  user:pass@(host:port)/db . The LAST '@' separates the
# credential from the address, so a password containing '@' parses correctly.
function ConvertFrom-YcMysqlDsn{
  param([string]$Dsn)
  $at = $Dsn.LastIndexOf('@')
  if($at -lt 1){ return $null }
  $cred = $Dsn.Substring(0,$at)
  $rest = $Dsn.Substring($at+1)
  $colon = $cred.IndexOf(':')
  $u = $cred
  $p = ''
  if($colon -ge 0){ $u = $cred.Substring(0,$colon); $p = $cred.Substring($colon+1) }
  $m = [regex]::Match($rest,'^(?:tcp)?\(([^:)]+):(\d+)\)')
  if(-not $m.Success){ return $null }
  return (New-Object psobject -Property @{
    User = $u; Password = $p; Host_ = $m.Groups[1].Value; Port = [int]$m.Groups[2].Value })
}

function Get-YcWinSw{
  if($WinSwPath){
    if(-not (Test-Path -LiteralPath $WinSwPath)){ Write-YcLog ('-WinSwPath not found: ' + $WinSwPath) 'ERROR'; return $null }
    return (Get-Item -LiteralPath $WinSwPath)
  }
  foreach($n in @('WinSW-x64.exe','WinSW.NET461.exe','WinSW.NET4.exe','WinSW.exe','winsw.exe')){
    $p = Join-Path 'C:\Scripts' $n
    if(Test-Path -LiteralPath $p){ return (Get-Item -LiteralPath $p) }
  }
  if($WinSwUrl){
    if(-not $WinSwSha256){
      Write-YcLog ('-WinSwUrl requires -WinSwSha256. A service wrapper runs as LocalSystem and ' +
        'supervises a process that holds a database credential; it is not downloaded unpinned.') 'ERROR'
      return $null
    }
    Assert-YcPrereqs -NeedInternet
    if(-not $script:YcTemp){
      $script:YcTemp = Join-Path $env:TEMP ('myexp_' + [guid]::NewGuid().ToString('N'))
      New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
    }
    $dst = Join-Path $script:YcTemp 'WinSW.exe'
    $got = Get-YcFile -Uri $WinSwUrl -OutFile $dst -Sha256 $WinSwSha256 -MinBytes 65536
    if(-not $got){ return $null }
    return (Get-Item -LiteralPath $dst)
  }
  return $null
}

function Remove-YcWrapperService{
  param([string]$Name,[string]$WrapperExe,[int]$TimeoutSec = 60)
  $svc = Get-YcServiceObject $Name
  if(-not $svc){ return $true }
  if($svc.Status -ne 'Stopped'){
    try{ Stop-Service -Name $Name -Force -ErrorAction Stop }
    catch{ Write-YcLog ('Stop-Service ' + $Name + ' failed: ' + $_.Exception.Message) 'WARN' }
  }
  $removed = $false
  if($WrapperExe -and (Test-Path -LiteralPath $WrapperExe)){
    $u = Invoke-YcNative -File $WrapperExe -Arguments @('uninstall')
    if($u.ExitCode -eq 0){ $removed = $true }
    else{ Write-YcLog ('WinSW uninstall returned ' + $u.ExitCode + ': ' + ($u.Output -join ' ')) 'WARN' }
  }
  if(-not $removed){
    $d = Invoke-YcNative -File 'sc.exe' -Arguments @('delete',$Name)
    if($d.ExitCode -ne 0){
      Write-YcLog ('sc.exe delete ' + $Name + ' returned ' + $d.ExitCode + ': ' + ($d.Output -join ' ')) 'WARN'
    }
  }
  # sc.exe delete only MARKS for deletion. Poll until it is really gone.
  $deadline = (Get-Date).AddSeconds($TimeoutSec)
  while((Get-Date) -lt $deadline){
    if(-not (Get-YcServiceObject $Name)){ Write-YcLog ('Service ' + $Name + ' removed.'); return $true }
    Start-Sleep -Seconds 2
  }
  Write-YcLog ('Service ' + $Name + ' is still present ' + $TimeoutSec + 's after removal (deletion ' +
    'pending - something holds an open handle). Refusing to continue.') 'ERROR'
  return $false
}

# ------------------------------------------------------------------ main

function Invoke-Main{

  # --- 0. inputs ----------------------------------------------------------------------
  $u = $MyUser; $p = $null; $h = $MyHost; $prt = $MyPort
  if($DataSourceName){
    $parsed = ConvertFrom-YcMysqlDsn -Dsn $DataSourceName
    if(-not $parsed){
      Write-YcLog ('-DataSourceName could not be parsed. Expected user:pass@tcp(host:port)/ or ' +
        'user:pass@(host:port)/ . The old parser accepted only the second form and silently left ' +
        'the host EMPTY for the first (canonical) one, so the exporter connected to nothing while ' +
        'the script reported success.') 'ERROR'
      $script:YcExit = 2; return
    }
    $u = $parsed.User; $p = $parsed.Password; $h = $parsed.Host_; $prt = $parsed.Port
    Write-YcLog ('DSN parsed: user=' + $u + ' host=' + $h + ' port=' + $prt + ' (password redacted).')
  }else{
    $p = Get-YcExporterPassword
  }
  if(-not $h){
    Write-YcLog 'No MySQL host resolved. Pass -MyHost or a parseable -DataSourceName.' 'ERROR'
    $script:YcExit = 2; return
  }
  if(-not $p){
    Write-YcLog ('No password supplied for MySQL user "' + $u + '". Supply -MyPasswordFile <file>, ' +
      'set YC_MYSQLD_EXPORTER_PASSWORD, or (not recommended) pass -MyPassword. An empty password ' +
      'means every scrape fails authentication while the exporter still answers /metrics with ' +
      'mysql_up 0.') 'ERROR'
    $script:YcExit = 2; return
  }
  $script:YcSecret = $p
  if($ListenPort -lt 1 -or $ListenPort -gt 65535){
    Write-YcLog ('-ListenPort ' + $ListenPort + ' is out of range.') 'ERROR'; $script:YcExit = 2; return
  }
  # Test-YcWorldOpen (_yc-lib.ps1) tests EVERY element for Any / * / 0.0.0.0/0 / ::/0 / Internet.
  # The old test was ($RemoteAddress.Count -eq 1 -and $RemoteAddress[0] -eq 'Any'), which let
  # -RemoteAddress 0.0.0.0/0 through unexamined, and let ANY two-element list skip the gate.
  if((Test-YcWorldOpen -Scope $RemoteAddress) -and -not $SkipFirewall -and -not $AllowAnyRemote){
    Write-YcLog ('-RemoteAddress Any would expose /metrics - which leaks schema and table names, ' +
      'replication topology and query counts - to every network this VM is attached to, with no TLS ' +
      'and no authentication. Pass your Prometheus servers or the management CIDR, or -SkipFirewall, ' +
      'or -AllowAnyRemote if you really mean it.') 'ERROR'
    $script:YcExit = 2; return
  }

  # --- 1. the exporter binary ---------------------------------------------------------
  if(-not $script:YcTemp){
    $script:YcTemp = Join-Path $env:TEMP ('myexp_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $script:YcTemp -Force | Out-Null
  }
  $zip = $null
  if($ZipPath){
    if(-not (Test-Path -LiteralPath $ZipPath)){ Write-YcLog ('-ZipPath not found: ' + $ZipPath) 'ERROR'; $script:YcExit = 1; return }
    $zip = Get-Item -LiteralPath $ZipPath
  }elseif($DownloadUrl){
    Assert-YcPrereqs -NeedInternet
    $dst = Join-Path $script:YcTemp 'mysqld_exporter.zip'
    $got = Get-YcFile -Uri $DownloadUrl -OutFile $dst -Sha256 $Sha256 -MinBytes 1048576
    if(-not $got){ $script:YcExit = 1; return }
    $zip = Get-Item -LiteralPath $dst
  }else{
    $all = Get-ChildItem -Path 'C:\Scripts\mysqld_exporter-*.windows-amd64.zip' -File -ErrorAction Ignore
    if($all){
      $zip = $all | Sort-Object {
          $m = [regex]::Match($_.Name,'(\d+\.\d+\.\d+)')
          if($m.Success){ [version]$m.Groups[1].Value } else { [version]'0.0.0' }
        } -Descending | Select-Object -First 1
    }
  }
  if(-not $zip){
    Write-YcLog ('No mysqld_exporter installer. Stage C:\Scripts\mysqld_exporter-<ver>.windows-amd64.zip, ' +
      'or pass -ZipPath / -DownloadUrl.') 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcFile -Path $zip.FullName -MinBytes 524288 -Because 'mysqld_exporter zip')){ $script:YcExit = 1; return }
  $zh = (Get-FileHash -LiteralPath $zip.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
  if($Sha256 -and -not $DownloadUrl){
    if($zh -ne $Sha256.Trim().ToUpperInvariant()){
      Write-YcLog ('SHA256 MISMATCH on ' + $zip.Name + ': expected ' + $Sha256.Trim().ToUpperInvariant() +
        ', got ' + $zh + '. Refusing to install.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('SHA256 verified: ' + $zh) 'OK'
  }elseif(-not $DownloadUrl){
    Write-YcLog ('No -Sha256 pin supplied. Archive hash is ' + $zh + ' - pin it on the next run.') 'WARN'
  }

  # --- 2. the WinSW wrapper (mandatory - the exporter cannot be a service on its own) --
  $winsw = Get-YcWinSw
  if(-not $winsw){
    Write-YcLog ('No WinSW service wrapper found. mysqld_exporter has NO Windows service dispatcher ' +
      '(verified against its current go.mod: no kardianos/minwinsvc, no golang.org/x/sys/windows/svc), ' +
      'so registering it directly with New-Service produces a service the SCM kills after 30 seconds ' +
      'with error 1053 - which is why this exporter has never actually run here. Stage ' +
      'C:\Scripts\WinSW-x64.exe (or WinSW.NET461.exe), or pass -WinSwPath, or -WinSwUrl with ' +
      '-WinSwSha256. Refusing to install a service that cannot start.') 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcFile -Path $winsw.FullName -MinBytes 65536 -Because 'WinSW service wrapper')){ $script:YcExit = 1; return }
  if($WinSwSha256 -and -not $WinSwUrl){
    $wh = (Get-FileHash -LiteralPath $winsw.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
    if($wh -ne $WinSwSha256.Trim().ToUpperInvariant()){
      Write-YcLog ('SHA256 MISMATCH on ' + $winsw.Name + ': expected ' +
        $WinSwSha256.Trim().ToUpperInvariant() + ', got ' + $wh + '. Refusing to use it.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('WinSW SHA256 verified: ' + $wh) 'OK'
  }

  # --- 3. lay the files down ----------------------------------------------------------
  if(-not (Test-Path -LiteralPath $InstallDir)){ New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
  $logDir = Join-Path $InstallDir 'logs'
  if(-not (Test-Path -LiteralPath $logDir)){ New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
  $ex = Join-Path $script:YcTemp 'x'
  New-Item -ItemType Directory -Path $ex -Force | Out-Null
  Expand-Archive -Path $zip.FullName -DestinationPath $ex -Force
  $src = Get-ChildItem -Path $ex -Recurse -Filter 'mysqld_exporter.exe' -File | Select-Object -First 1
  if(-not $src){ Write-YcLog ('mysqld_exporter.exe not found inside ' + $zip.Name) 'ERROR'; $script:YcExit = 1; return }

  $exePath     = Join-Path $InstallDir 'mysqld_exporter.exe'
  $wrapperExe  = Join-Path $InstallDir ($ServiceName + '-service.exe')
  $wrapperXml  = Join-Path $InstallDir ($ServiceName + '-service.xml')
  $myCnf       = Join-Path $InstallDir 'my.cnf'

  $existing = Get-YcServiceObject $ServiceName
  if($existing -and $existing.Status -ne 'Stopped'){
    Write-YcLog ('Existing service ' + $ServiceName + ' is ' + $existing.Status + '; stopping it to ' +
      'replace the binaries (upgrade path).')
    try{ Stop-Service -Name $ServiceName -Force -ErrorAction Stop }catch{
      Write-YcLog ('Stop-Service failed: ' + $_.Exception.Message) 'WARN'
    }
    Start-Sleep -Seconds 3
  }
  Copy-Item -LiteralPath $src.FullName -Destination $exePath -Force
  Copy-Item -LiteralPath $winsw.FullName -Destination $wrapperExe -Force
  if(-not (Assert-YcFile -Path $exePath -MinBytes 524288 -Because 'installed exporter binary')){ $script:YcExit = 1; return }
  if(-not (Assert-YcFile -Path $wrapperExe -MinBytes 65536 -Because 'installed service wrapper')){ $script:YcExit = 1; return }

  # --- 4. PROOF: the exporter binary runs ---------------------------------------------
  $ver = Invoke-YcNative -File $exePath -Arguments @('--version')
  $verLine = ($ver.Output | Where-Object { $_.Trim().Length -gt 0 } | Select-Object -First 1)
  if($ver.ExitCode -ne 0 -and -not $verLine){
    Write-YcLog ('mysqld_exporter.exe --version failed (exit ' + $ver.ExitCode + '). The extracted ' +
      'binary is not runnable on this host.') 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Installed binary: ' + $exePath + ' -- ' + ([string]$verLine).Trim()) 'OK'

  # --- 5. credentials: my.cnf, ACL'd, never on a command line -------------------------
  # https://github.com/prometheus/mysqld_exporter/blob/main/README.md  ([client] section)
  $cnf = @(
    '# Managed by YallaCloud mysqldexporter-register. Contains the exporter password.',
    '# ACL: SYSTEM + Administrators only (verified by this script). Never passed on a command line.',
    '[client]',
    ('user=' + $u),
    ('password=' + $p),
    ('host=' + $h),
    ('port=' + $prt)
  )
  $cnfText = ($cnf -join "`r`n") + "`r`n"
  Set-YcManagedFile -Path $myCnf -Content $cnfText -Always:$Force | Out-Null
  if(-not (Protect-YcFileAcl -Path $myCnf)){ $script:YcExit = 1; return }

  # --- 6. the WinSW service definition ------------------------------------------------
  $listen = ':' + $ListenPort
  if($BindAddress){ $listen = $BindAddress + ':' + $ListenPort }
  $svcArgs = '--config.my-cnf="' + $myCnf + '" --web.listen-address=' + $listen
  $xml = @"
<service>
  <!-- Managed by YallaCloud mysqldexporter-register.
       mysqld_exporter has no Windows service dispatcher of its own (no kardianos/minwinsvc,
       no golang.org/x/sys/windows/svc in its go.mod), so the SCM would kill it after 30s
       with error 1053. WinSW implements the dispatcher and supervises the child.
       No credential appears here: the password lives in my.cnf, ACL'd to SYSTEM+Admins. -->
  <id>$(ConvertTo-YcXmlText $ServiceName)</id>
  <name>Prometheus mysqld_exporter (YallaCloud)</name>
  <description>Exports MySQL/MariaDB metrics for Prometheus. Managed by C:\Scripts\MysqldExporter-Register.ps1.</description>
  <executable>$(ConvertTo-YcXmlText $exePath)</executable>
  <arguments>$(ConvertTo-YcXmlText $svcArgs)</arguments>
  <workingdirectory>$(ConvertTo-YcXmlText $InstallDir)</workingdirectory>
  <startmode>Automatic</startmode>
  <delayedAutoStart/>
  <onfailure action="restart" delay="10 sec"/>
  <stoptimeout>15 sec</stoptimeout>
  <logpath>$(ConvertTo-YcXmlText $logDir)</logpath>
  <log mode="roll-by-size">
    <sizeThreshold>10240</sizeThreshold>
    <keepFiles>8</keepFiles>
  </log>
</service>
"@
  Set-YcManagedFile -Path $wrapperXml -Content $xml -Always:$Force | Out-Null

  # --- 7. install the wrapper service --------------------------------------------------
  $svc = Get-YcServiceObject $ServiceName
  $needInstall = $true
  if($svc){
    $curBin = ''
    $k = 'HKLM:\SYSTEM\CurrentControlSet\Services\' + $ServiceName
    if(Test-Path $k){ try{ $curBin = [string](Get-ItemProperty -Path $k).ImagePath }catch{} }
    if($curBin -like ('*' + $wrapperExe + '*')){
      Write-YcLog ('Service ' + $ServiceName + ' already runs under this wrapper - reusing it; the XML ' +
        'above is re-read at every start, so a config change lands on restart (idempotent).')
      $needInstall = $false
    }else{
      Write-YcLog ('Service ' + $ServiceName + ' exists but is NOT the wrapper (ImagePath: ' + $curBin +
        '). That is the broken registration this fix exists to replace - removing it.') 'WARN'
      if(-not (Remove-YcWrapperService -Name $ServiceName -WrapperExe $wrapperExe)){ $script:YcExit = 1; return }
    }
  }
  if($needInstall){
    $ins = Invoke-YcNative -File $wrapperExe -Arguments @('install')
    foreach($l in $ins.Output){ if($l.Trim().Length -gt 0){ Write-Host ('    ' + (Get-YcRedacted $l)) } }
    if($ins.ExitCode -ne 0){
      Write-YcLog ('WinSW install FAILED (exit ' + $ins.ExitCode + ').') 'ERROR'
      $script:YcExit = 1; return
    }
    if(-not (Get-YcServiceObject $ServiceName)){
      Write-YcLog ('VERIFICATION FAILED: service ' + $ServiceName + ' does not exist after WinSW ' +
        'install returned 0.') 'ERROR'
      $script:YcExit = 1; return
    }
    Write-YcLog ('Service ' + $ServiceName + ' created under the WinSW wrapper.') 'OK'
  }
  $sc1 = Invoke-YcNative -File 'sc.exe' -Arguments @('config',$ServiceName,'start=','delayed-auto')
  if($sc1.ExitCode -ne 0){
    Write-YcLog ('sc.exe config start= delayed-auto returned ' + $sc1.ExitCode + ': ' + ($sc1.Output -join ' ')) 'WARN'
  }

  # --- 8. PROOF: it runs and STAYS running --------------------------------------------
  $svc = Get-YcServiceObject $ServiceName
  try{
    if($svc.Status -eq 'Running'){ Restart-Service -Name $ServiceName -Force -ErrorAction Stop }
    else{ Start-Service -Name $ServiceName -ErrorAction Stop }
  }catch{
    Write-YcLog ('Start-Service ' + $ServiceName + ' FAILED: ' + $_.Exception.Message +
      '. Wrapper log: ' + $logDir) 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcService -Name $ServiceName -TimeoutSec 60 -Because 'mysqld_exporter under WinSW')){
    $script:YcExit = 1; return
  }
  # A Go binary with no dispatcher is killed by the SCM at ~30s with error 1053. That is the
  # exact failure this rewrite exists to remove, so it is re-checked past that window.
  Start-Sleep -Seconds 40
  $svc2 = Get-YcServiceObject $ServiceName
  if((-not $svc2) -or ($svc2.Status -ne 'Running')){
    $st = 'absent'; if($svc2){ $st = [string]$svc2.Status }
    Write-YcLog ('VERIFICATION FAILED: ' + $ServiceName + ' reached Running but is "' + $st + '" 40s ' +
      'later - the classic no-service-dispatcher / error 1053 pattern, or the exporter crashed on ' +
      'startup. Wrapper log: ' + $logDir) 'ERROR'
    $script:YcExit = 1; return
  }
  Write-YcLog ('Service ' + $ServiceName + ' is Running and stayed Running past the 30s SCM ' +
    'dispatcher deadline that used to kill this exporter.') 'OK'

  # --- 9. PROOF: /metrics answers AND the exporter is really talking to MySQL ---------
  $probeHost = '127.0.0.1'
  if($BindAddress){ $probeHost = $BindAddress }
  $url = 'http://' + $probeHost + ':' + $ListenPort + '/metrics'
  if(-not (Assert-YcHttp -Uri $url -ExpectStatus 200 -TimeoutSec 90 -MatchContent '# HELP')){
    Write-YcLog ('VERIFICATION FAILED: ' + $url + ' did not return Prometheus text. No firewall rule ' +
      'was created. Wrapper log: ' + $logDir) 'ERROR'
    $script:YcExit = 1; return
  }
  if(-not (Assert-YcHttp -Uri $url -ExpectStatus 200 -TimeoutSec 60 -MatchContent 'mysql_up 1')){
    Write-YcLog ('VERIFICATION FAILED: ' + $url + ' answered 200 but mysql_up is not 1. The exporter ' +
      'is running and is NOT collecting from MySQL - check the host/port, the ' + $u + ' login and its ' +
      'PROCESS, REPLICATION CLIENT and SELECT grants. This is exactly the state the old script ' +
      'reported as "done".') 'ERROR'
    $script:YcExit = 1; return
  }

  # --- 10. side effects ONLY after the thing they support is proven -------------------
  if($SkipFirewall){
    Write-YcLog '-SkipFirewall set: no inbound rule created.'
  }else{
    $rn = 'YallaCloud mysqld_exporter in ' + $ListenPort
    if(Get-NetFirewallRule -DisplayName $rn -ErrorAction Ignore){
      Write-YcLog ('Inbound firewall rule already present: ' + $rn)
    }else{
      if($AllowAnyRemote -and (Test-YcWorldOpen -Scope $RemoteAddress)){
        Write-YcLog ('Opening TCP ' + $ListenPort + ' to ANY remote address, as explicitly requested.') 'WARN'
      }
      try{
        New-NetFirewallRule -DisplayName $rn -Direction Inbound -Action Allow -Protocol TCP `
          -LocalPort $ListenPort -RemoteAddress $RemoteAddress -Profile $FirewallProfile `
          -Description 'Prometheus scrape of mysqld_exporter. Managed by YallaCloud.' `
          -ErrorAction Stop | Out-Null
      }catch{
        Write-YcLog ('Firewall rule creation FAILED: ' + $_.Exception.Message) 'ERROR'
        $script:YcExit = 1; return
      }
      if(-not (Get-NetFirewallRule -DisplayName $rn -ErrorAction Ignore)){
        Write-YcLog ('VERIFICATION FAILED: firewall rule "' + $rn + '" does not exist after ' +
          'New-NetFirewallRule returned.') 'ERROR'
        $script:YcExit = 1; return
      }
      Write-YcLog ('Inbound allow verified: TCP ' + $ListenPort + ' from ' + ($RemoteAddress -join ',') +
        ' on profile(s) ' + ($FirewallProfile -join ',')) 'OK'
    }
  }

  Write-YcLog ('DONE. ' + $ServiceName + ' Running under WinSW, ' + $url + ' returned 200 with ' +
    'mysql_up 1, credentials in an ACL-verified my.cnf.') 'OK'
  $script:YcExit = 0
}

try{
  Invoke-Main | Out-Null
}catch{
  Write-YcLog ('UNHANDLED EXCEPTION: ' + (Get-YcRedacted $_.Exception.Message)) 'ERROR'
  if($_.ScriptStackTrace){ Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}finally{
  if($script:YcTemp -and (Test-Path -LiteralPath $script:YcTemp)){
    try{ Remove-Item -LiteralPath $script:YcTemp -Recurse -Force }
    catch{ Write-YcLog ('Could not remove temp dir ' + $script:YcTemp + ': ' + $_.Exception.Message) 'WARN' }
  }
}

if($script:YcExit -eq 0){ Exit-Yc 0 'mysqldexporter-register verified' 'OK' }
Exit-Yc $script:YcExit 'mysqldexporter-register FAILED - nothing was reported as working that is not proven' 'ERROR'
