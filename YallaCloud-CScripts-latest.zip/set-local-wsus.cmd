@echo off
rem set-local-wsus [-Install | -Uninstall | -Status | -Test] [-Server <ip>] [-Port <n>] [-Force] [-Help]
rem
rem Point this machine at the YallaCloud local update server (ycwsus01, 93.177.125.166:8530)
rem instead of downloading the same gigabytes from Microsoft on every VM.
rem
rem   set-local-wsus -Status        what am I pointed at, and is it healthy
rem   set-local-wsus -Test          can I reach the local server (changes nothing)
rem   set-local-wsus -Install       use the local server
rem   set-local-wsus -Uninstall     go back to Microsoft Update   <-- THIS IS THE FALLBACK
rem
rem THERE IS NO AUTOMATIC FALLBACK. Windows does not try the local server and then Microsoft.
rem Once pointed at it, that server IS the source: if it is unreachable the scan FAILS and the
rem machine silently stops patching. That is why -Install refuses on a server it cannot reach,
rem why -Status exits 1 on "configured but unreachable", and why going back is one command.
rem
rem EXIT CODES: 0 ok | 1 -Status configured-but-unreachable, -Test unreachable | 2 refused
rem             3 partial failure | 5 not elevated.   Log: C:\Scripts\set-local-wsus.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Set-LocalWsus.ps1" %*
exit /b %ERRORLEVEL%
