param(
  # ---- SIMPLE (day-1 / L1) ----
  [string]$Master,                 # required: master host/IP (comma-separated for multi-master)
  [string]$MinionId,               # minion id (default: computer name)
  # ---- ADVANCED - installer ----
  [int]$MasterPort = 4506,         # minion return port on master (default 4506; pub is 4505)
  [switch]$StartDelayed,           # salt-minion service = delayed automatic start
  [switch]$NoStart,                # install but do NOT start the service (/start-minion=0)
  [string]$InstallDir,             # custom install dir (/install-dir=)
  [string]$CustomConfig,           # path to a full minion config file to use (/custom-config=)
  [switch]$Reinstall,              # uninstall any existing Salt first, then install
  # ---- ADVANCED - minion config drop-in (covers ANY salt minion option) ----
  [string[]]$Config,               # extra minion config lines, e.g. -Config 'log_level: info','environment: prod'
  [string]$Grains,                 # convenience: sets grains (raw YAML), e.g. -Grains 'roles: [web]'
  # ---- ADDED in this revision (see header) ----
  [string]$Setup,                  # explicit installer path (default: newest C:\Scripts\Salt-Minion-*-Setup.exe)
  [switch]$KeepConfig,             # do NOT pass /default-config - keep an existing minion config as-is
  [int]$KeyWaitSec = 120,          # how long to wait for proof the key reached the master
  [switch]$NoFirewall,             # do not touch the firewall at all
  [switch]$Help
)
# =====================================================================================
# Salt-Register.ps1 - SILENT install + configure the Salt Minion (Windows, EGRESS-ONLY).
# PowerShell 5.1, ASCII only. Runs unattended (cloud-init / SYSTEM / RMM).
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# 1. USES THE SHARED LIBRARY. v1 rolled its own Write-Log, had NO admin check in 133
#    lines, no [YALLACLOUD] tag, no event-log mirror and no [END] marker. Now: dot-source
#    _yc-lib.ps1, Start-YcLog 'salt-register', Assert-YcPrereqs -NeedAdmin, and EVERY exit
#    goes through Exit-Yc so the transcript always ends with [END] exit=<n>.
# 2. /default-config IS NOW PASSED (audit F5.3). Salt docs: "If any existing configuration
#    files are present, this option will overwrite the existing configuration and replace it
#    with the default Salt configuration file." Without it the installer REUSES the existing
#    config, so on ANY re-run -Master / -MinionId were silently ignored while this script
#    logged them as applied. -KeepConfig opts out; -CustomConfig suppresses it (the custom
#    file is the config in that case). The installer backs the old file up as *.bak.
# 3. exit $p.ExitCode IS GONE. v1 logged the installer exit code and then continued into the
#    config drop-in, the firewall rules and the PATH edit regardless, finally exiting the
#    installer's code no matter what its own checks found. Now Invoke-YcInstaller decodes the
#    code, a non-success stops the script immediately, and success is decided by PROOF.
# 4. PROOF OF REGISTRATION, not proof that an .exe ran. Ends only after ALL of:
#      a) salt-minion service exists and is Running (Assert-YcService),
#      b) the generated minion config actually contains the master(s) we asked for,
#      c) salt-call --local test.true returns True (the minion executes),
#      d) salt-call test.true against the master either returns True (key ACCEPTED) or the
#         master answers "has cached the public key" (key PRESENTED, awaiting salt-key -a).
#         A master that never sees the key is an ERROR, not a silent success.
# 5. FIREWALL RULES ARE CREATED ONLY AFTER (a)-(d) SUCCEED, and are scoped with
#    -RemoteAddress <master> instead of Any. v1 added them unconditionally right after the
#    installer - the Acronis pattern that left 14 hosts with holes and no agent.
# 6. PATH EDIT NO LONGER FLATTENS %SystemRoot% (audit F5.4). v1 read the EXPANDED machine
#    PATH and wrote it back as REG_SZ, permanently destroying every REG_EXPAND_SZ token -
#    baked into a golden image that corrupts PATH on every clone. Now the raw value is read
#    with DoNotExpandEnvironmentNames and written back with its original value kind.
# 7. Installer chosen by PARSED [version], not string sort (3006.10 > 3006.9), size- and
#    signature-checked, and -Setup accepts an explicit path. Multiple staged installers are
#    logged, not silently gambled on.
# 8. -Grains splits on CRLF as well as LF; -Reinstall waits for the uninstaller and verifies
#    the service is really gone before installing over the top.
#
# VENDOR VERIFICATION (Salt install guide, Windows, current):
#   /S /master= /minion-name= /start-minion= /start-minion-delayed /install-dir=
#   /custom-config= /default-config /move-config /?   - all documented at
#   https://docs.saltproject.io/salt/install-guide/en/latest/topics/install-by-operating-system/windows.html
#   Documented example: Salt-Minion-3008.2-Py3-AMD64-Setup.exe /S /master=yoursaltmaster /minion-name=yourminionname
#   /master= is documented to accept "a single master or a comma-separated list".
#   /S (silent) is the NSIS convention and is case sensitive: https://nsis.sourceforge.io/Docs/Chapter4.html
#   test.true / test.ping: https://docs.saltproject.io/en/latest/ref/modules/all/salt.modules.test.html
# NO undocumented switch is emitted by this script. That is the whole point.
#
# SECRETS: nothing secret is put on a child command line. -Master / -MinionId are not
#   secrets. Anything sensitive (e.g. master_finger, a pre-seeded key) belongs in the
#   drop-in via -Config or in a file via -CustomConfig - never as a command-line value.
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was installed. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'salt-register'

$Usage = @'
salt-register  -  SILENT install + configure the Salt Minion (Windows). EGRESS-ONLY automation agent.
                  Staged installer: C:\Scripts\Salt-Minion-*-Setup.exe   Log: C:\Scripts\salt-register.log

USAGE (simple):
  salt-register -Master <master-host-or-ip>
  salt-register -Master 10.20.0.10 -MinionId web01

USAGE (advanced):
  salt-register -Master <hosts> [-MinionId <name>] [-MasterPort 4506] [-StartDelayed | -NoStart]
                [-InstallDir <path>] [-CustomConfig <file>] [-Reinstall] [-Setup <exe>]
                [-Config 'key: value','key2: value2'] [-Grains '<yaml>']
                [-KeepConfig] [-KeyWaitSec 120] [-NoFirewall]

PARAMETERS:
  -Master        (required) Master host/IP the minion dials OUT to (TCP 4505 publish + 4506 return).
                 Multi-master: comma-separated, e.g. -Master '10.0.0.10,10.0.0.11'  (the Salt
                 installer documents /master= as accepting a comma-separated list).
  -MinionId      Minion id shown on the master. Default: computer name.
  -MasterPort    Return port on the master. Default 4506.
  -StartDelayed  Service start = delayed automatic (default: automatic).
  -NoStart       Install but leave the service stopped (/start-minion=0). Registration is NOT
                 verified in this mode - it cannot be - and the command says so and exits 0.
  -InstallDir    Custom install directory. NOTE: Salt documents this as IGNORED for an
                 existing installation.
  -CustomConfig  Use an existing full minion config file instead of generating one
                 (/custom-config=). Implies -KeepConfig.
  -Reinstall     Uninstall an existing Salt install first (uninst.exe /S), wait for the service
                 to disappear, then install fresh.
  -Setup         Explicit installer path. Default: the HIGHEST-VERSION C:\Scripts\Salt-Minion-*-Setup.exe.
  -Config        One or more raw minion config lines (any salt option), written to a drop-in conf.
                 Example: -Config 'log_level: info','ipc_mode: tcp','ping_interval: 5'
  -Grains        Raw YAML for the 'grains:' block. Example: -Grains 'roles: [web]'
  -KeepConfig    Do NOT pass /default-config. Keeps an existing minion config file untouched -
                 which also means -Master / -MinionId will NOT take effect on a re-run.
  -KeyWaitSec    Seconds to wait for proof the minion key reached the master. Default 120.
  -NoFirewall    Do not create the scoped outbound firewall rules.
  -Help          Show this help and exit.

NOTES:
  Run on the DEPLOYED VM. EGRESS-ONLY: dials OUT to master:4505/4506; opens NO inbound ports.
  The outbound allow rules are scoped to the master address(es) and are created ONLY after the
  minion is proven running - never before.
  Advanced -Config / -Grains are written to:
      %ProgramData%\Salt Project\Salt\conf\minion.d\99-yallacloud.conf
  By default this command passes /default-config so that -Master / -MinionId are applied even
  when Salt is already installed. Salt backs the previous config up next to it as *.bak.
  After install, accept the key on the MASTER:   salt-key -a <MinionId>
  Verify on the minion:   salt-call --version   /   salt-call --local test.true

EXAMPLES:
  salt-register -Master 10.20.0.10
  salt-register -Master salt.yallacloud.net -MinionId web01 -StartDelayed
  salt-register -Master '10.0.0.10,10.0.0.11' -MinionId db01 -Config 'log_level: info','environment: prod'
  salt-register -Master 10.20.0.10 -Grains 'roles: [web, edge]'
  salt-register -Reinstall -Master 10.20.0.10
  salt-register -Master 10.20.0.10 -KeepConfig      # leave an existing minion config alone
  salt-register -Help

EXIT CODES:
  0   minion installed, running and its key reached the master (accepted, or pending salt-key -a)
  1   generic failure
  2   usage error (-Master missing)
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4   staged installer missing / too small
  5   not running as Administrator
  7   salt-minion service not Running, or the minion never reached the master
  10  the installer did not exit within its timeout and was killed
  14  the installer ran but the minion config does NOT contain the requested master
  <n> any other value is the Salt installer's own exit code

Log: C:\Scripts\salt-register.log   (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}
if(-not $Master){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 '-Master is required. Nothing was installed.' 'ERROR'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

# ------------------------------------------------------------------------------------
# Paths (Salt 3004+ layout, per the Salt install guide)
# ------------------------------------------------------------------------------------
$SaltBin   = 'C:\Program Files\Salt Project\Salt'
if($InstallDir){ $SaltBin = $InstallDir }
$SaltRoot  = 'C:\ProgramData\Salt Project\Salt'
$ConfFile  = Join-Path $SaltRoot 'conf\minion'
$ConfDir   = Join-Path $SaltRoot 'conf\minion.d'
$PkiPub    = Join-Path $SaltRoot 'conf\pki\minion\minion.pub'
$MinionLog = Join-Path $SaltRoot 'var\log\salt\minion'
$SvcName   = 'salt-minion'

if(-not $MinionId){ $MinionId = $env:COMPUTERNAME }
$MasterList = @()
foreach($m in ($Master -split ',')){ $t = $m.Trim(); if($t){ $MasterList += $t } }
if($MasterList.Count -eq 0){ Exit-Yc 2 '-Master contained no usable host after parsing.' 'ERROR' }

# ------------------------------------------------------------------------------------
# Script-local helper: run a program, capture stdout/stderr, enforce a hard timeout.
# Invoke-YcInstaller is for installers (it does not capture output); this is for the
# verification commands, where the OUTPUT is the evidence.
# ------------------------------------------------------------------------------------
function Invoke-YcProcCapture{
  param([string]$FilePath,[string[]]$ArgumentList,[int]$TimeoutSec=120)
  $res = [pscustomobject]@{ ExitCode = -1; Text = ''; TimedOut = $false; Started = $false }
  $o = [IO.Path]::GetTempFileName()
  $e = [IO.Path]::GetTempFileName()
  $p = $null
  try{
    $sp = @{ FilePath = $FilePath; PassThru = $true; NoNewWindow = $true;
             RedirectStandardOutput = $o; RedirectStandardError = $e; ErrorAction = 'Stop' }
    if($ArgumentList -and $ArgumentList.Count -gt 0){ $sp['ArgumentList'] = $ArgumentList }
    $p = Start-Process @sp
    $res.Started = $true
  }catch{
    $res.Text = 'could not start ' + $FilePath + ': ' + $_.Exception.Message
    Remove-Item -LiteralPath $o,$e -Force -ErrorAction SilentlyContinue
    return $res
  }
  $exited = $false
  try{ $exited = $p.WaitForExit($TimeoutSec * 1000) }catch{ $exited = $false }
  if(-not $exited){
    $res.TimedOut = $true
    try{ Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }catch{}
    Start-Sleep -Seconds 1
  }else{
    try{ $res.ExitCode = [int]$p.ExitCode }catch{ $res.ExitCode = -1 }
  }
  $so = ''
  $se = ''
  try{ $so = [string](Get-Content -LiteralPath $o -Raw -ErrorAction SilentlyContinue) }catch{}
  try{ $se = [string](Get-Content -LiteralPath $e -Raw -ErrorAction SilentlyContinue) }catch{}
  $res.Text = ($so + "`n" + $se)
  Remove-Item -LiteralPath $o,$e -Force -ErrorAction SilentlyContinue
  return $res
}

# ------------------------------------------------------------------------------------
# 1. Pick the installer: highest PARSED version, not a string sort.
# ------------------------------------------------------------------------------------
$setupPath = ''
if($Setup){
  $setupPath = $Setup
}else{
  $cands = @(Get-ChildItem -Path 'C:\Scripts\Salt-Minion-*-Setup.exe' -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer })
  if($cands.Count -eq 0){
    Exit-Yc 4 'Salt installer (C:\Scripts\Salt-Minion-*-Setup.exe) not found. Stage it, or pass -Setup <path>. Nothing was installed.' 'ERROR'
  }
  $ranked = @()
  foreach($f in $cands){
    $v = [version]'0.0'
    if($f.Name -match 'Salt-Minion-(\d+(?:\.\d+){1,3})'){ try{ $v = [version]$Matches[1] }catch{ $v = [version]'0.0' } }
    $ranked += (New-Object psobject -Property @{ File = $f; Ver = $v })
  }
  $ranked = @($ranked | Sort-Object -Property Ver -Descending)
  if($ranked.Count -gt 1){
    Write-YcLog ('several staged Salt installers found: ' + (($ranked | ForEach-Object { $_.File.Name }) -join ', ') + ' - using the highest version') 'WARN'
  }
  $setupPath = $ranked[0].File.FullName
}
if(-not (Assert-YcFile -Path $setupPath -MinBytes 5MB -Because 'Salt minion installer')){
  Exit-Yc 4 ('unusable Salt installer: ' + $setupPath) 'ERROR'
}
$sig = 'Unavailable'
try{ $sig = [string](Get-AuthenticodeSignature -LiteralPath $setupPath -ErrorAction Stop).Status }catch{ $sig = 'Unavailable' }
if($sig -eq 'Valid'){ Write-YcLog ('installer Authenticode signature: Valid (' + (Split-Path -Leaf $setupPath) + ')') 'OK' }
else{ Write-YcLog ('installer Authenticode signature is ' + $sig + ' for ' + $setupPath + ' - continuing, but this package is not proven to be the vendor build') 'WARN' }

# ------------------------------------------------------------------------------------
# 2. Optional uninstall first, verified.
# ------------------------------------------------------------------------------------
if($Reinstall){
  $unin = Join-Path $SaltBin 'uninst.exe'
  if(Test-Path -LiteralPath $unin){
    Write-YcLog 'Reinstall: removing the existing Salt installation (uninst.exe /S)'
    $u = Invoke-YcInstaller -FilePath $unin -ArgumentList @('/S') -SuccessCodes @(0) -TimeoutSec 900
    if(-not $u.Success){ Write-YcLog ('the Salt uninstaller returned ' + $u.ExitCode + ' (' + $u.Meaning + ') - continuing, the install below will be checked on its own merits') 'WARN' }
    $gone = $false
    for($i=0; $i -lt 30; $i++){
      $s = Get-Service -Name $SvcName -ErrorAction SilentlyContinue
      if(-not $s){ $gone = $true; break }
      Start-Sleep -Seconds 2
    }
    if($gone){ Write-YcLog 'existing salt-minion service removed' 'OK' }
    else     { Write-YcLog 'the salt-minion service still exists after the uninstall - installing over the top' 'WARN' }
  }else{
    Write-YcLog ('-Reinstall requested but no uninstaller at ' + $unin + ' - nothing to remove') 'WARN'
  }
}

# ------------------------------------------------------------------------------------
# 3. Build the command line. Every switch below is vendor-documented (see header).
# ------------------------------------------------------------------------------------
$useDefaultConfig = $true
$whyDefault = 'so that -Master / -MinionId are actually applied even over an existing config'
if($CustomConfig){ $useDefaultConfig = $false; $whyDefault = '-CustomConfig supplies the whole config' }
if($KeepConfig)  { $useDefaultConfig = $false; $whyDefault = '-KeepConfig was passed' }

$argList = @('/S')
$argList += ('/master=' + $Master)
if($MinionId -match '\s'){ $argList += ('/minion-name="' + $MinionId + '"') }
else                     { $argList += ('/minion-name=' + $MinionId) }
if($NoStart){ $argList += '/start-minion=0' } else { $argList += '/start-minion=1' }
if($StartDelayed -and -not $NoStart){ $argList += '/start-minion-delayed' }
if($useDefaultConfig){ $argList += '/default-config' }
if($InstallDir){   $argList += ('/install-dir="'   + $InstallDir   + '"') }
if($CustomConfig){ $argList += ('/custom-config="' + $CustomConfig + '"') }

if($useDefaultConfig){ Write-YcLog ('passing /default-config ' + $whyDefault + '; Salt backs the previous config up as *.bak') }
else                 { Write-YcLog ('NOT passing /default-config (' + $whyDefault + ') - an existing minion config will be reused verbatim, so -Master / -MinionId may not take effect') 'WARN' }

Write-YcLog ('installing Salt Minion: ' + (Split-Path -Leaf $setupPath) + '  master=' + $Master + '  minion-id=' + $MinionId)
$inst = Invoke-YcInstaller -FilePath $setupPath -ArgumentList $argList -SuccessCodes @(0) -RebootCodes @(3010,1641) -TimeoutSec 1800 -MinSeconds 10
if($inst.TimedOut){ Exit-Yc 10 'the Salt installer had to be killed - the minion is in an unknown state' 'ERROR' }
if(-not $inst.Success){
  $code = $inst.ExitCode
  if($code -eq 0){ $code = 1 }
  Exit-Yc $code ('Salt installer FAILED: ' + $inst.Meaning + '. No firewall rule and no PATH change were made.') 'ERROR'
}
if($inst.RebootRequired){ Write-YcLog 'the installer reports a reboot is required to complete - verification below may be incomplete until then' 'WARN' }

# ------------------------------------------------------------------------------------
# 4. Minion config drop-in (master_port + -Config lines + grains).
# ------------------------------------------------------------------------------------
$needDropin = (($MasterPort -ne 4506) -or $Config -or $Grains)
if($needDropin){
  try{
    if(-not (Test-Path -LiteralPath $ConfDir)){ New-Item -ItemType Directory -Path $ConfDir -Force -ErrorAction Stop | Out-Null }
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('# written by salt-register (YallaCloud). Edits here survive a re-run only if')
    $lines.Add('# the same options are passed again - this file is rewritten each time.')
    if($MasterPort -ne 4506){ $lines.Add('master_port: ' + $MasterPort) }
    if($Config){ foreach($l in $Config){ $lines.Add([string]$l) } }
    if($Grains){
      $lines.Add('grains:')
      foreach($g in ($Grains -split "`r`n|`n|`r")){
        $gt = $g.Trim()
        if($gt){ $lines.Add('  ' + $gt) }
      }
    }
    $dropin = Join-Path $ConfDir '99-yallacloud.conf'
    ($lines -join "`r`n") | Out-File -FilePath $dropin -Encoding ascii -Force -ErrorAction Stop
    Write-YcLog ('wrote minion config drop-in: ' + $dropin) 'OK'
  }catch{
    Exit-Yc 1 ('could not write the minion config drop-in: ' + $_.Exception.Message) 'ERROR'
  }
  if(-not $NoStart){
    $svcNow = Get-Service -Name $SvcName -ErrorAction SilentlyContinue
    if($svcNow){
      try{ Restart-Service -Name $SvcName -Force -ErrorAction Stop; Write-YcLog 'salt-minion restarted to pick up the drop-in' 'OK' }
      catch{ Write-YcLog ('could not restart salt-minion after writing the drop-in: ' + $_.Exception.Message) 'ERROR' }
    }else{
      Write-YcLog 'the salt-minion service does not exist after the install - the drop-in will not be read' 'ERROR'
    }
  }
}

# ------------------------------------------------------------------------------------
# 5. PATH: add the Salt bin dir WITHOUT flattening REG_EXPAND_SZ tokens.
# ------------------------------------------------------------------------------------
if(Test-Path -LiteralPath $SaltBin){
  $envKey = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment'
  try{
    $regItem = Get-Item -LiteralPath $envKey -ErrorAction Stop
    $rawPath = [string]$regItem.GetValue('Path',$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    $kind    = [string]$regItem.GetValueKind('Path')
    $already = $false
    foreach($seg in ($rawPath -split ';')){ if($seg.Trim().TrimEnd('\') -eq $SaltBin.TrimEnd('\')){ $already = $true } }
    if($already){
      Write-YcLog 'Salt bin folder already on the machine PATH'
    }else{
      $newPath = $rawPath.TrimEnd(';') + ';' + $SaltBin
      $type = 'ExpandString'
      if($kind -ne 'ExpandString'){ $type = 'String' }
      Set-ItemProperty -LiteralPath $envKey -Name 'Path' -Value $newPath -Type $type -ErrorAction Stop
      Write-YcLog ('added ' + $SaltBin + ' to the machine PATH (value kind preserved: ' + $type + '; existing sessions need a restart to see it)') 'OK'
    }
  }catch{
    Write-YcLog ('could not update the machine PATH: ' + $_.Exception.Message + ' - salt-call is still usable by full path') 'WARN'
  }
}

# ------------------------------------------------------------------------------------
# 6. PROOF. Nothing below this point assumes the installer told the truth.
# ------------------------------------------------------------------------------------
if($NoStart){
  $svcOff = Get-Service -Name $SvcName -ErrorAction SilentlyContinue
  if(-not $svcOff){
    Exit-Yc 7 'the installer returned success but the salt-minion service DOES NOT EXIST. Nothing is registered.' 'ERROR'
  }
  Write-YcLog ('salt-minion service exists and is ' + $svcOff.Status + '. -NoStart was requested, so registration CANNOT be verified from here.') 'WARN'
  Write-YcLog ('start it later with:  Start-Service ' + $SvcName + '   then accept the key on the master:  salt-key -a ' + $MinionId)
  Exit-Yc 0 'Salt minion installed but not started (-NoStart) - registration unverified by design.' 'WARN'
}

if(-not (Assert-YcService -Name $SvcName -TimeoutSec 180 -StartIfStopped -Because 'the Salt minion must be running to register')){
  Exit-Yc 7 'salt-minion is not Running - the minion is NOT registered. No firewall rule was created.' 'ERROR'
}

# 6a. Did our configuration actually land? This is what /default-config exists to guarantee.
if(-not $CustomConfig){
  $confText = ''
  foreach($f in @($ConfFile, (Join-Path $ConfDir '99-yallacloud.conf'))){
    if(Test-Path -LiteralPath $f){
      try{ $confText += ([string](Get-Content -LiteralPath $f -Raw -ErrorAction SilentlyContinue)) + "`n" }catch{}
    }
  }
  if(-not $confText){
    Write-YcLog ('the minion config file ' + $ConfFile + ' could not be read - cannot confirm the master was applied') 'WARN'
  }else{
    $missing = @()
    foreach($m in $MasterList){ if($confText -notlike ('*' + $m + '*')){ $missing += $m } }
    if($missing.Count -gt 0){
      Write-YcLog ('the minion config does NOT contain: ' + ($missing -join ', ') + '. The installer reused an existing configuration, so this run did not change the master. Re-run without -KeepConfig / -CustomConfig.') 'ERROR'
      Exit-Yc 14 'requested master not present in the minion configuration' 'ERROR'
    }
    Write-YcLog ('minion config contains the requested master(s): ' + ($MasterList -join ', ')) 'OK'
    foreach($ln in ($confText -split "`r`n|`n")){
      if($ln -match '^\s*(master|id|master_port)\s*:'){ Write-YcLog ('  config: ' + $ln.Trim()) }
    }
  }
}

# 6b. The minion can execute at all.
$saltCall = Join-Path $SaltBin 'salt-call.exe'
if(-not (Test-Path -LiteralPath $saltCall)){
  Exit-Yc 7 ('salt-call.exe not found at ' + $saltCall + ' - the install is incomplete') 'ERROR'
}
$ver = Invoke-YcProcCapture -FilePath $saltCall -ArgumentList @('--version') -TimeoutSec 120
if($ver.Text){ Write-YcLog ('salt-call --version: ' + (($ver.Text -split "`r`n|`n" | Where-Object { $_.Trim() }) -join ' ')) }
$loc = Invoke-YcProcCapture -FilePath $saltCall -ArgumentList @('--local','test.true') -TimeoutSec 180
if($loc.TimedOut -or ($loc.Text -notmatch 'True')){
  Write-YcLog ('salt-call --local test.true did not return True (exit ' + $loc.ExitCode + ', timedout=' + $loc.TimedOut + '). Output: ' + (Protect-YcSecret ($loc.Text -replace '[\r\n]+',' '))) 'ERROR'
  Exit-Yc 7 'the minion cannot execute a local module - the install is broken' 'ERROR'
}
Write-YcLog 'salt-call --local test.true returned True - the minion executes' 'OK'

# 6c. Did the key actually reach the master?
foreach($m in $MasterList){
  foreach($port in @(4505,$MasterPort)){
    $reach = $false
    try{ $reach = [bool](Test-NetConnection -ComputerName $m -Port $port -WarningAction SilentlyContinue -InformationLevel Quiet) }catch{ $reach = $false }
    if($reach){ Write-YcLog ('TCP ' + $m + ':' + $port + ' reachable') 'OK' }
    else       { Write-YcLog ('TCP ' + $m + ':' + $port + ' NOT reachable from this host') 'WARN' }
  }
}
if(Test-Path -LiteralPath $PkiPub){ Write-YcLog ('minion public key present: ' + $PkiPub) 'OK' }
else{ Write-YcLog ('minion public key NOT found at ' + $PkiPub + ' - the minion has not generated/presented a key yet') 'WARN' }

$keyState = 'unknown'
$probe = Invoke-YcProcCapture -FilePath $saltCall -ArgumentList @('--timeout','15','test.true') -TimeoutSec $KeyWaitSec
$ptxt = [string]$probe.Text
if($ptxt -match 'True' -and -not ($ptxt -match 'cached the public key')){
  $keyState = 'accepted'
}elseif($ptxt -match 'cached the public key' -or $ptxt -match 'not been accepted' -or $ptxt -match 'key is pending'){
  $keyState = 'presented'
}elseif($ptxt -match "Authentication wasn't successful" -or $ptxt -match 'Waiting for minion key'){
  $keyState = 'presented'
}else{
  $keyState = 'nocontact'
}
$flat = (Protect-YcSecret ($ptxt -replace '[\r\n]+',' '))
if($flat.Length -gt 500){ $flat = $flat.Substring(0,500) + ' ...' }
Write-YcLog ('master round-trip probe (salt-call --timeout 15 test.true): exit=' + $probe.ExitCode + ' timedout=' + $probe.TimedOut + ' output: ' + $flat)

if(Test-Path -LiteralPath $MinionLog){
  try{
    $tail = @(Get-Content -LiteralPath $MinionLog -Tail 40 -ErrorAction SilentlyContinue)
    foreach($t in $tail){
      if($t -match 'cached the public key' -or $t -match 'ready to receive requests' -or $t -match 'Authentication with master'){
        Write-YcLog ('minion log: ' + $t.Trim())
        if($keyState -eq 'nocontact'){ $keyState = 'presented' }
      }
    }
  }catch{}
}

switch($keyState){
  'accepted'  { Write-YcLog ('the master answered - this minion key is ACCEPTED and ' + $MinionId + ' is fully registered') 'OK' }
  'presented' { Write-YcLog ('the minion key REACHED the master and is waiting to be accepted. On the master run:  salt-key -a ' + $MinionId) 'WARN' }
  default     {
    Write-YcLog ('the minion never got a reply from ' + $Master + '. The key was NOT presented: check egress to 4505/' + $MasterPort + ', the master address, and the master service.') 'ERROR'
    Exit-Yc 7 'the minion is running but never reached the master - registration FAILED' 'ERROR'
  }
}

# ------------------------------------------------------------------------------------
# 7. Firewall LAST, scoped to the master, only now that everything above passed.
# ------------------------------------------------------------------------------------
if($NoFirewall){
  Write-YcLog '-NoFirewall: skipping the outbound allow rules'
}else{
  $ports = @(4505)
  if($MasterPort -ne 4505){ $ports += $MasterPort }
  foreach($port in $ports){
    $rn = 'Salt out ' + $port
    try{
      $existing = Get-NetFirewallRule -DisplayName $rn -ErrorAction SilentlyContinue
      if($existing){ Remove-NetFirewallRule -DisplayName $rn -ErrorAction Stop }
      New-NetFirewallRule -DisplayName $rn -Direction Outbound -Action Allow -Protocol TCP `
                          -RemoteAddress $MasterList -RemotePort $port -Profile Any -ErrorAction Stop | Out-Null
      Write-YcLog ('outbound allow TCP ' + $port + ' scoped to ' + ($MasterList -join ',') + ' (rule "' + $rn + '")') 'OK'
    }catch{
      Write-YcLog ('could not create the outbound rule "' + $rn + '": ' + $_.Exception.Message) 'ERROR'
    }
  }
}

$final = 'Salt minion ' + $MinionId + ' installed, Running, and registered against ' + $Master + ' (4505/' + $MasterPort + ').'
if($keyState -eq 'presented'){ $final += '  ACTION REQUIRED on the master:  salt-key -a ' + $MinionId }
Exit-Yc 0 $final 'OK'
