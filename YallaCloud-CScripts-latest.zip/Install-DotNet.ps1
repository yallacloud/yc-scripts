param(
  [ValidateSet('4.8','4.8.1')]
  [string]$Target = '4.8',
  [int]$TimeoutMinutes = 45,
  [switch]$UpgradeChocolatey,
  [switch]$Force,
  [switch]$SelfCheck,
  [switch]$Help
)
# =====================================================================================
# Install-DotNet.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
#
# WHY THIS EXISTS
# ---------------
# Two separate things on this estate are blocked by the same missing prerequisite, and
# baking it into the templates would mean reopening and re-sealing every image. This
# closes the gap from the payload instead, at deploy time.
#
#   1. SSMS. Proven on the fleet 2026-09-02: the Chocolatey package downloads 472.88 MB,
#      checksums clean, and then SSMS-Setup-ENU.exe exits 1 with, in its own bundle log:
#          .NET Framework 4.7.2 (or greater) is not detected on this machine.
#          Error 0x81f40001: Bundle condition evaluated to false: NETFRAMEWORK45 >= "461808"
#   2. Chocolatey itself. Choco 2.x requires .NET 4.8. That is why the fleet runs the
#      end-of-life 1.4.0 on Server 2016 and 2019 while 2022 and 2025 run 2.7.3.
#
# WHAT SHIPS WHERE (measured, not assumed)
#   Server 2016  Release 394802  = .NET 4.6.2
#   Server 2019  Release 461814  = .NET 4.7.2
#   Server 2022  Release 528449  = .NET 4.8
#   Server 2025  Release 533509  = .NET 4.8.1
# So 2016 and 2019 need this; 2022 and 2025 are already above the bar and exit 0.
#
# A REBOOT IS NOT OPTIONAL
# -----------------------
# .NET 4.8 always requires a restart. Rather than pretend otherwise, a successful install
# ends at exit 8 - "installed, reboot and re-run whatever needed it". Nothing is chained
# across the reboot, because a half-applied framework is worse than an obvious stop.
#
# 4.8.1 is refused below Server 2022: Microsoft supports it on Windows Server 2022 and
# later only. Asking for it on 2016/2019 is a usage error, not something to work around.
#
# Exit codes: 0 already satisfied or nothing to do, 1 install failed, 2 usage,
#             3 Chocolatey missing, 5 not elevated, 6 no internet,
#             8 installed - reboot and re-run.
# Log: C:\Scripts\install-dotnet.log
# =====================================================================================

. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'install-dotnet'
$ErrorActionPreference = 'Stop'

$HelpText = @"
Install-DotNet.ps1 - bring .NET Framework up to 4.8 (or 4.8.1) and prove it.

  install-dotnet                        ensure .NET 4.8 (no-op on 2022/2025)
  install-dotnet -Target 4.8.1          Server 2022+ only
  install-dotnet -UpgradeChocolatey     after .NET is >= 4.8, upgrade choco 1.x to 2.x
  install-dotnet -Force                 install even if the Release value already passes
  install-dotnet -SelfCheck             run the built-in assertions, change nothing
  install-dotnet -Help

Why you would run this
  Server 2016 ships .NET 4.6.2 and Server 2019 ships 4.7.2. Both are below what SSMS
  and Chocolatey 2.x require, so install-ssms stops with exit 8 until this has run.
  Server 2022 (4.8) and Server 2025 (4.8.1) are already fine - this exits 0 there.

A reboot is required after a successful install. That is reported as exit 8, not hidden.

Exit codes: 0 already satisfied, 1 failed, 2 usage, 3 no Chocolatey, 5 not elevated,
            6 no internet, 8 installed - reboot and re-run.
Log: C:\Scripts\install-dotnet.log
"@

if ($Help) { Write-Host $HelpText; Stop-YcLog 0; exit 0 }

$script:YcExit = 0

# Microsoft's published "Release" values under NDP\v4\Full, and the Chocolatey package
# that delivers each. 4.8.1 is Server 2022+ (build 20348) only.
$DotNetSpec = @{
  '4.8'   = @{ Release = 528040; Package = 'netfx-4.8';   MinBuild = 0     }
  '4.8.1' = @{ Release = 533320; Package = 'netfx-4.8.1'; MinBuild = 20348 }
}

function Get-YcDotNetRelease {
  $v = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release -ErrorAction SilentlyContinue
  if ($v) { return [int]$v.Release }
  return 0
}

function Get-YcDotNetName {
  param([int]$Release)
  if ($Release -ge 533320) { return '4.8.1' }
  if ($Release -ge 528040) { return '4.8'   }
  if ($Release -ge 461808) { return '4.7.2' }
  if ($Release -ge 394802) { return '4.6.2' }
  if ($Release -gt 0)      { return 'older than 4.6.2' }
  return 'not installed'
}

function Invoke-YcSelfCheck {
  function T($name, $cond) {
    if ($cond) { Write-YcLog ("SELFCHECK OK   " + $name) 'OK' }
    else       { Write-YcLog ("SELFCHECK FAIL " + $name) 'ERROR'; $script:scFail++ }
  }
  $script:scFail = 0
  T '4.8 Release is 528040'                 ($DotNetSpec['4.8'].Release   -eq 528040)
  T '4.8.1 Release is 533320'               ($DotNetSpec['4.8.1'].Release -eq 533320)
  T '4.8 package is netfx-4.8'              ($DotNetSpec['4.8'].Package   -eq 'netfx-4.8')
  T '4.8.1 needs Server 2022 (20348)'       ($DotNetSpec['4.8.1'].MinBuild -eq 20348)
  T 'stock 2016 (394802) is below 4.8'      (394802 -lt $DotNetSpec['4.8'].Release)
  T 'stock 2019 (461814) is below 4.8'      (461814 -lt $DotNetSpec['4.8'].Release)
  T 'stock 2022 (528449) satisfies 4.8'     (528449 -ge $DotNetSpec['4.8'].Release)
  T 'stock 2025 (533509) satisfies 4.8.1'   (533509 -ge $DotNetSpec['4.8.1'].Release)
  T '394802 names 4.6.2'                    ((Get-YcDotNetName -Release 394802) -eq '4.6.2')
  T '461814 names 4.7.2'                    ((Get-YcDotNetName -Release 461814) -eq '4.7.2')
  T '528449 names 4.8'                      ((Get-YcDotNetName -Release 528449) -eq '4.8')
  T '533509 names 4.8.1'                    ((Get-YcDotNetName -Release 533509) -eq '4.8.1')
  T 'this host reports a Release value'     ((Get-YcDotNetRelease) -gt 0)
  T 'choco.exe resolvable'                  ([bool](Get-Command choco.exe -ErrorAction SilentlyContinue))
  Write-YcLog ("SELFCHECK: " + (14 - $script:scFail) + "/14 passed.") $(if ($script:scFail) { 'ERROR' } else { 'OK' })
  return $script:scFail
}

function Invoke-YcChoco {
  param([string]$ChocoExe, [string[]]$Arguments)
  Write-YcLog ('choco ' + ($Arguments -join ' '))
  $p = Start-Process -FilePath $ChocoExe -ArgumentList $Arguments -Wait -PassThru -NoNewWindow
  return [int]$p.ExitCode
}

function Invoke-Main {
  if ($SelfCheck) {
    $script:YcExit = if ((Invoke-YcSelfCheck) -eq 0) { 0 } else { 1 }
    return
  }

  Assert-YcPrereqs -NeedAdmin -NeedInternet -BoundParameters $PSBoundParameters

  $os    = Get-CimInstance Win32_OperatingSystem
  $build = [int]$os.BuildNumber
  $spec  = $DotNetSpec[$Target]
  $rel   = Get-YcDotNetRelease

  Write-YcLog ($os.Caption + ' (build ' + $build + '), .NET Release ' + $rel +
               ' = ' + (Get-YcDotNetName -Release $rel) + '. Target ' + $Target +
               ' needs Release >= ' + $spec.Release + '.')

  if ($build -lt $spec.MinBuild) {
    Write-YcLog ('.NET ' + $Target + ' is supported on Windows Server 2022 (build ' + $spec.MinBuild +
      ') and later only. This host is build ' + $build + '. Use -Target 4.8.') 'ERROR'
    $script:YcExit = 2; return
  }

  $needInstall = ($rel -lt $spec.Release) -or $Force

  $choco = Get-Command choco.exe -ErrorAction SilentlyContinue
  if ($needInstall -or $UpgradeChocolatey) {
    if (-not $choco) {
      Write-YcLog ('Chocolatey is not installed on this host, so there is no package source. ' +
        'It ships on the YallaCloud golden image - this box is not one, or ' +
        'C:\ProgramData\chocolatey was removed.') 'ERROR'
      $script:YcExit = 3; return
    }
    Write-YcLog ('Chocolatey: ' + $choco.Source + ' version ' +
                 (& choco.exe --version 2>&1 | Select-Object -First 1))
  }

  if (-not $needInstall) {
    Write-YcLog ('.NET ' + (Get-YcDotNetName -Release $rel) + ' already satisfies the ' + $Target +
      ' requirement - nothing to install.') 'OK'
  } else {
    $rc = Invoke-YcChoco -ChocoExe $choco.Source -Arguments @(
      'install', $spec.Package, '-y', '--no-progress', '--no-color',
      ('--execution-timeout=' + ($TimeoutMinutes * 60)))

    if ($rc -notin @(0, 3010, 1641)) {
      Write-YcLog ($spec.Package + ' install failed (choco exit ' + $rc + ').') 'ERROR'
      $script:YcExit = 1; return
    }

    # The Release value does not move until the restart completes, so a post-install
    # read that still shows the old number is EXPECTED, not a failure.
    $after = Get-YcDotNetRelease
    Write-YcLog ($spec.Package + ' installed (choco exit ' + $rc + '). Release now reads ' + $after +
      '; it updates on restart.')
    Write-YcLog ('REBOOT this host, then re-run whatever needed .NET ' + $Target +
      ' (for example: install-ssms).') 'WARN'
    $script:YcExit = 8; return
  }

  if ($UpgradeChocolatey) {
    $cv = (& choco.exe --version 2>&1 | Select-Object -First 1)
    if ("$cv" -match '^\s*1\.') {
      Write-YcLog ('Chocolatey ' + $cv + ' is 1.x and end of life. .NET is now high enough for 2.x - upgrading.')
      $rc2 = Invoke-YcChoco -ChocoExe $choco.Source -Arguments @('upgrade','chocolatey','-y','--no-progress','--no-color')
      $cv2 = (& choco.exe --version 2>&1 | Select-Object -First 1)
      if ($rc2 -in @(0, 3010, 1641) -and "$cv2" -notmatch '^\s*1\.') {
        Write-YcLog ('VERIFIED: Chocolatey is now ' + $cv2) 'OK'
      } else {
        Write-YcLog ('Chocolatey upgrade returned ' + $rc2 + ' and the version still reads ' + $cv2 + '.') 'ERROR'
        $script:YcExit = 1; return
      }
    } else {
      Write-YcLog ('Chocolatey ' + $cv + ' is already 2.x or later - nothing to upgrade.') 'OK'
    }
  }

  $script:YcExit = 0
}

try {
  Invoke-Main | Out-Null
} catch {
  Write-YcLog ('UNHANDLED EXCEPTION: ' + $_.Exception.Message) 'ERROR'
  if ($_.ScriptStackTrace) { Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}

Stop-YcLog $script:YcExit
exit $script:YcExit
