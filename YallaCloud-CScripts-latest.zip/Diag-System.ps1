param(
  # ---- name preserved from diag.cmd and the catalog ----
  [switch]$Help,
  # ---- ADDED in this revision ----
  [string]$OutFile,                # explicit report path (default C:\Scripts\diag-<stamp>.txt)
  [int]$MaxEvents = 30             # how many events per event-log section
)
# =====================================================================================
# Diag-System.ps1 - forensic / health report for one Windows host. Read-only.
# PowerShell 5.1, ASCII only, unattended.
#
# 2026-08-19: repaired. Added the library guard + Exit-Yc on every path (the -Help branch
#             had a bare 'exit 0' and the success path had no Stop-YcLog at all, so every
#             run left the transcript open with no [END] line and no exit code); each
#             section is now run through one helper that CATCHES and RECORDS its failure
#             instead of hiding it behind -ErrorAction SilentlyContinue; and the report
#             file itself is PROVEN to exist and be non-trivial before the command reports
#             success. Added -OutFile and -MaxEvents.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P1] "diagnostic report: C:\Scripts\diag-....txt" WAS PRINTED UNCONDITIONALLY.
#   Every collector carried -ErrorAction SilentlyContinue and every Out-File was fire and
#   forget. On a host where the Storage module is broken - exactly the host you run this on
#   - the report was an almost empty file and the command still said it had written one, in
#   green, and exited with whatever the last statement happened to leave behind.
#   NOW: every section reports OK or the exception text INTO the report and into the log,
#   the count of failed sections is reported, and Assert-YcFile proves the report exists
#   and is at least 512 bytes before exit 0.
#
# This command runs only in-box tooling: bcdedit, chkdsk (read-only, no /f), sfc
# /verifyonly, DISM /Online /Cleanup-Image /CheckHealth, Get-WinEvent, the Storage module
# and the root\wmi SMART failure-prediction class. smartctl is used only if smartmontools
# is already installed (diagtools-install stages it).
#   https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk
#   https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/repair-a-windows-image
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** No report was written. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'diag'

$Usage = @'
diag  -  forensic/health report (boot, disk + SMART, chkdsk/sfc/DISM, event errors, BSOD)
         written to C:\Scripts\diag-<yyyyMMdd-HHmmss>.txt. Read-only: nothing is repaired.

USAGE:
  diag
  diag -OutFile C:\Scripts\diag-before-patching.txt
  diag -MaxEvents 100
  diag -Help

PARAMETERS:
  -OutFile    Where to write the report. Default C:\Scripts\diag-<yyyyMMdd-HHmmss>.txt.
              The parent directory must already exist.
  -MaxEvents  Events per event-log section (System errors, Application errors). Default 30.
  -Help       Show this help and exit.

EXAMPLES:
  diag
  diag -OutFile C:\Scripts\diag-before-patching.txt
  diag -MaxEvents 100
  diag -Help

PROOF OF SUCCESS (nothing is assumed):
  every section records either its output or the exception that stopped it, the number of
  failed sections is reported, and the report file is proven to exist and to be at least
  512 bytes before this command reports success. It never announces a report it did not
  write.

EXIT CODES:
  0  the report was written and verified (check the log for any section that failed)
  1  the report file could not be created or appended to
  2  usage error (-MaxEvents below 1, or the -OutFile directory does not exist)
  3  C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4  the report file is missing or under 512 bytes after collection
  5  not running as Administrator

Log: C:\Scripts\diag.log   (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters

if($MaxEvents -lt 1){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 ('-MaxEvents must be at least 1, got ' + $MaxEvents) 'ERROR'
}
$out = $OutFile
if(-not $out){ $out = 'C:\Scripts\diag-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt' }
$parent = Split-Path -Parent $out
if($parent -and -not (Test-Path -LiteralPath $parent)){
  Exit-Yc 2 ('the -OutFile directory does not exist: ' + $parent) 'ERROR'
}

try{
  ('System Diagnostic Report  ' + (Get-Date) + '  ' + $env:COMPUTERNAME) | Out-File -FilePath $out -Encoding ascii -ErrorAction Stop
}catch{
  Exit-Yc 1 ('could not create the report ' + $out + ': ' + $_.Exception.Message) 'ERROR'
}

$script:DiagFailed = @()

# One section = one titled block whose failure is RECORDED, never swallowed. This replaces
# 11 separate -ErrorAction SilentlyContinue collectors that could each fail invisibly.
function Add-DiagSection{
  param([string]$Title,[scriptblock]$Body)
  try{
    ('', ('===== ' + $Title + ' =====')) | Out-File -FilePath $out -Append -Encoding ascii -ErrorAction Stop
  }catch{
    Write-YcLog ('could not append the "' + $Title + '" heading to ' + $out + ': ' + $_.Exception.Message) 'ERROR'
    $script:DiagFailed += $Title
    return
  }
  try{
    $text = & $Body 2>&1 | Out-String
    if($null -eq $text -or ([string]$text).Trim().Length -eq 0){ $text = '(no data returned)' }
    $text | Out-File -FilePath $out -Append -Encoding ascii -ErrorAction Stop
    Write-YcLog ($Title + ': collected')
  }catch{
    $msg = $_.Exception.Message
    ('*** THIS SECTION FAILED: ' + $msg) | Out-File -FilePath $out -Append -Encoding ascii
    Write-YcLog ($Title + ': FAILED - ' + $msg) 'WARN'
    $script:DiagFailed += $Title
  }
}

Add-DiagSection 'OS' { Get-CimInstance Win32_OperatingSystem -ErrorAction Stop | Format-List Caption,Version,BuildNumber,LastBootUpTime }
Add-DiagSection 'Boot config' { bcdedit /enum }
Add-DiagSection 'Physical disks + SMART health' {
  Get-PhysicalDisk -ErrorAction Stop | Format-Table FriendlyName,MediaType,HealthStatus,@{n='GB';e={[int]($_.Size/1GB)}} -AutoSize
}
Add-DiagSection 'SMART failure prediction' {
  Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_FailurePredictStatus -ErrorAction Stop |
    Format-Table InstanceName,PredictFailure -AutoSize
}
Add-DiagSection 'smartctl scan (only if smartmontools is installed)' {
  $sc = Get-Command smartctl -ErrorAction Ignore     # a tool-presence probe, not load-bearing
  if($sc){ & $sc.Source --scan } else { 'smartctl is not on PATH - run diagtools-install to add smartmontools' }
}
Add-DiagSection 'Volumes' {
  Get-Volume -ErrorAction Stop | Format-Table DriveLetter,FileSystem,HealthStatus,@{n='FreeGB';e={[int]($_.SizeRemaining/1GB)}},@{n='GB';e={[int]($_.Size/1GB)}} -AutoSize
}
Add-DiagSection 'chkdsk C: (read-only, no /f)' { cmd /c "chkdsk C:" }
Add-DiagSection 'SFC verifyonly'               { cmd /c "sfc /verifyonly" }
Add-DiagSection 'DISM CheckHealth'             { dism /Online /Cleanup-Image /CheckHealth }
Add-DiagSection ('Last ' + $MaxEvents + ' System errors') {
  Get-WinEvent -FilterHashtable @{LogName='System';Level=1,2} -MaxEvents $MaxEvents -ErrorAction Stop |
    Format-Table TimeCreated,Id,ProviderName -AutoSize
}
Add-DiagSection 'Unexpected shutdown / bugcheck (41,6008,1001)' {
  Get-WinEvent -FilterHashtable @{LogName='System';Id=41,6008,1001} -MaxEvents 15 -ErrorAction Stop |
    Format-Table TimeCreated,Id -AutoSize
}
Add-DiagSection ('Last ' + $MaxEvents + ' Application errors') {
  Get-WinEvent -FilterHashtable @{LogName='Application';Level=1,2} -MaxEvents $MaxEvents -ErrorAction Stop |
    Format-Table TimeCreated,Id,ProviderName -AutoSize
}

# PROOF: the report exists and is not a stub. Assert-YcFile -Fatal exits 4 if it is not.
if(-not (Assert-YcFile -Path $out -MinBytes 512 -Because 'diagnostic report' -Fatal)){
  Exit-Yc 4 ('the diagnostic report was not written: ' + $out) 'ERROR'
}

$note = 'every section collected'
if($script:DiagFailed.Count -gt 0){
  $note = ([string]$script:DiagFailed.Count + ' section(s) FAILED and say so in the report: ' + ($script:DiagFailed -join ', '))
  Write-YcLog $note 'WARN'
}
Exit-Yc 0 ('diagnostic report written and verified: ' + $out + ' - ' + $note) 'OK'
