@echo off
rem dbatools-install - install the dbatools PowerShell module and PROVE it imports.
rem
rem CHANGED: the wrapper now propagates the script exit code. dbatools-install used to
rem   exit 0 even when the module could not be imported, which is what left Install-Sql.ps1
rem   with no maintenance jobs and no backups.
rem
rem   dbatools-install                                    (staged package if present, else gallery)
rem   dbatools-install -Online -RequiredVersion 2.8.4
rem   dbatools-install -Offline -PackagePath C:\Scripts\dbatools-offline -Sha256 <hash>
rem   dbatools-install -Scope CurrentUser
rem   dbatools-install -Help
rem
rem Air-gapped: on a connected host run  Save-Module dbatools -Path C:\temp\offline
rem   (that also pulls dbatools.library, without which dbatools 2.x will not import),
rem   copy the folder over, then: dbatools-install -Offline -PackagePath C:\temp\offline
rem
rem Exit codes: 0 verified, 1 install/verify failed, 2 usage, 3 no source,
rem             5 not elevated, 6 no internet.
rem Log: C:\Scripts\dbatools-install.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Dbatools-Install.ps1" %*
exit /b %ERRORLEVEL%
