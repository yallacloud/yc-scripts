<#
  Setup-YallaCloudExtras.ps1  -  YallaCloud golden-image EXTRAS generator (full guide-parity command set)
  Version 1.2 | 2026-08-19 | PowerShell 5.1+ | Windows Server 2016/2019/2022/2025 | ASCII-only
  2026-08-19: Emit()'s anti-clobber guard was inert when this generator runs FROM C:\Scripts (source
              path == destination path), so it overwrote the hardened WebJEA-Install.ps1 and
              OliveTin-Install.ps1 with its own smaller generated bodies. The same-path case now
              LEAVES THE FILE ALONE (both the .ps1 and the .cmd branch). Also: dropped the
              '#Requires -Version 5.1' line from every generated body - #Requires aborts before
              Start-YcLog so the failure produced no log, and Yc-Compliance.ps1 flags it. Also:
              documented -NoStage, which existed in param() but in no usage block.

  Emits the guide (rev 1.7) commands that core GoldenImage.ps1 does NOT already generate, so the sealed
  golden's C:\Scripts matches the YallaCloud catalog exactly. Each = <Name>.ps1 (logic) + <name>.cmd
  (on-PATH wrapper), added to yallacloud. Offline-first (staged installer used if present; URL only for
  -Stage/online fallback). Shared contract: elevated, -Help, C:\Scripts\<cmd>.log tagged [YALLACLOUD][cmd],
  mirrored to Application event log (source 'YallaCloud').

  Generated here: salt-register, winexporter-register, telegraf-register,
  postgresexporter-register, mysqldexporter-register, sqlexporter-register, webjea-install,
  olivetin-install, pgbadger-install, percona-toolkit-install.
  (alloy/otelcol/dbatools/observability-register come from Setup-Observability.ps1.)

  Build-time: drop beside GoldenImage.ps1 (auto-copied + run at config), or run manually:
    powershell -ExecutionPolicy Bypass -File Setup-YallaCloudExtras.ps1 [-Stage] [-NoStage]

  PARAMETERS:
    -Stage    After generating the commands, download every offline installer payload into C:\Scripts
              so the generated *-register / *-install commands work with no internet at run time.
    -NoStage  Veto -Stage. Generate the commands but download nothing, even if -Stage was also passed
              (the staging block is guarded by 'if($Stage -and -not $NoStage)'). Use it when a caller
              or wrapper passes -Stage unconditionally and this particular build must stay offline.
              -NoStage on its own is a no-op, because staging is off by default.
#>
#Requires -Version 5.1
param([switch]$Stage,[switch]$NoStage)
$ErrorActionPreference='Continue'
$S='C:\Scripts'; New-Item -ItemType Directory -Force $S | Out-Null
function Info($m){ Write-Host "[extras] $m" -ForegroundColor Cyan }
try { if(-not [System.Diagnostics.EventLog]::SourceExists('YallaCloud')){ New-EventLog -LogName Application -Source 'YallaCloud' -EA SilentlyContinue } } catch {}

# ---- shared logging/util library dot-sourced by every command ----
# WHAT CHANGED AND WHY (P0-4): this block used to build a $lib here-string and Set-Content it over
# C:\Scripts\_yc-lib.ps1, replacing the real shared library (Start-YcLog / Write-YcLog / Stop-YcLog /
# Assert-YcPrereqs) with a private YC-* helper API that defines none of them. Every command that
# dot-sources the library then died on its third line, and Day2-Setup.ps1 only copies the good library
# when the file is ABSENT - so it kept the broken one and died itself. The library is now shipped from
# source control (the copy sitting beside this script) and its API is asserted before anything else is
# generated.
$libSrc = if($PSScriptRoot){ Join-Path $PSScriptRoot '_yc-lib.ps1' } else { $null }
$libDst = Join-Path $S '_yc-lib.ps1'
if(-not $libSrc -or -not (Test-Path $libSrc)){ throw "_yc-lib.ps1 not found beside Setup-YallaCloudExtras.ps1 - ship the source-control library alongside this script." }
if([IO.Path]::GetFullPath($libSrc) -ne [IO.Path]::GetFullPath($libDst)){
  Copy-Item $libSrc $libDst -Force
  Info 'copied _yc-lib.ps1 from source control'
} else {
  Info "_yc-lib.ps1 source and destination are the same file - not copying onto itself"
}
# P0-4 (second half): assert the WHOLE API the generated bodies below actually call, not just one
# function. A library that has Start-YcLog but not Exit-Yc or Get-YcFile still ships broken commands.
$libRaw = Get-Content $libDst -Raw
foreach($fn in @('Start-YcLog','Write-YcLog','Stop-YcLog','Exit-Yc','Assert-YcPrereqs','Assert-YcService',
                 'Assert-YcFile','Assert-YcHttp','Get-YcFile','Invoke-YcInstaller','Set-YcTls',
                 'Write-YcInvocation')){
  if($libRaw -notmatch ('function\s+' + [regex]::Escape($fn))){
    throw ("library API mismatch: _yc-lib.ps1 does not define " + $fn + " - every generated command calls it. Ship the current library.")
  }
}
Info 'verified _yc-lib.ps1 (full generated-command API present)'

# ---- helper block injected ONCE into every generated command body ----
# WHAT CHANGED AND WHY (P0-4): the generated bodies used to call a private YC-* helper API for
# unzip / firewall / staging that no shipped library defines. Those four helpers are now emitted
# INTO each command, on top of the real library, so a command is still one self-contained file and
# still uses the sanctioned Write-YcLog / Get-YcFile / Assert-Yc* API underneath.
# The firewall helper is deliberately NOT a straight port: the old one created -Profile Any rules
# with no -RemoteAddress, which put every exporter's /metrics on every attached network.
$YcHelpers = @'
# ---- helpers injected by Setup-YallaCloudExtras.ps1 (edit the generator, not this copy) ----
function Split-YcList{ param([string[]]$In)
  $out=@()
  foreach($i in $In){ if($null -eq $i){ continue }
    foreach($p in ([string]$i -split '[,;]')){ $p=$p.Trim(); if($p){ $out+=$p } } }
  return ,$out }
function Get-YcFailCode{ param($Result,[int]$Default=3)
  $c=$Default; try{ $c=[int]$Result.ExitCode }catch{}
  if($c -eq 0){ $c=$Default }
  return $c }
function Get-YcStaged{ param([string]$Uri,[string]$OutFile,[string]$Filter)
  if($OutFile -and (Test-Path -LiteralPath $OutFile)){ Write-YcLog ('using pre-staged payload: '+$OutFile); return $OutFile }
  if($Filter){
    $c = Get-ChildItem 'C:\Scripts' -Filter $Filter -ErrorAction SilentlyContinue | Select-Object -First 1
    if($c){ Write-YcLog ('using pre-staged payload: '+$c.FullName); return $c.FullName } }
  if(-not $Uri){ return $null }
  Write-YcLog ('payload not staged locally - downloading '+$Uri)
  return (Get-YcFile -Uri $Uri -OutFile $OutFile) }
function Expand-YcZip{ param([string]$Zip,[string]$Dest)
  if(-not (Assert-YcFile -Path $Zip -MinBytes 1024 -Because 'archive to expand')){ return $false }
  try{ New-Item -ItemType Directory -Force $Dest | Out-Null }catch{}
  try{ Expand-Archive -Path $Zip -DestinationPath $Dest -Force -ErrorAction Stop
       Write-YcLog ('expanded '+$Zip+' -> '+$Dest) 'OK'
       return $true }
  catch{ Write-YcLog ('Expand-Archive failed ('+$_.Exception.Message+') - retrying with System.IO.Compression') 'WARN' }
  $t = Join-Path $env:TEMP ('ycz_'+[Guid]::NewGuid().ToString('N'))
  try{ Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop
       [IO.Compression.ZipFile]::ExtractToDirectory($Zip,$t)
       Copy-Item (Join-Path $t '*') $Dest -Recurse -Force -ErrorAction Stop
       Write-YcLog ('expanded '+$Zip+' -> '+$Dest+' (fallback extractor)') 'OK'
       return $true }
  catch{ Write-YcLog ('could NOT expand '+$Zip+': '+$_.Exception.Message) 'ERROR'
         return $false }
  finally{ Remove-Item $t -Recurse -Force -ErrorAction SilentlyContinue } }
function New-YcFwRule{ param([string]$Name,[string]$Direction='Inbound',[int]$Port,[string]$Protocol='TCP',
                             [string[]]$RemoteAddress,[string[]]$FirewallProfile=@('Domain','Private'))
  $RemoteAddress   = Split-YcList $RemoteAddress
  $FirewallProfile = Split-YcList $FirewallProfile
  if($RemoteAddress.Count   -eq 0){ $RemoteAddress   = @('LocalSubnet') }
  if($FirewallProfile.Count -eq 0){ $FirewallProfile = @('Domain','Private') }
  if(($RemoteAddress -contains 'Any') -or ($RemoteAddress -contains '*')){
    Write-YcLog ("refusing to create firewall rule '"+$Name+"' with RemoteAddress Any - name the management CIDR or the collector IPs instead.") 'ERROR'
    return $false }
  # New-NetFirewallRule -RemoteAddress takes addresses, ranges, CIDRs and the built-in keywords -
  # NOT DNS names. A hostname here fails deep inside the cmdlet with an unhelpful message, so
  # resolve it first and say so.
  $ok=@()
  foreach($ra in $RemoteAddress){
    if($ra -match '^[0-9A-Fa-f:.]+(/[0-9]{1,3})?$' -or $ra -match '^[0-9.]+-[0-9.]+$' -or
       $ra -match '^(LocalSubnet|DNS|DHCP|WINS|DefaultGateway|Intranet|Internet|PlayToDevice)$'){ $ok+=$ra; continue }
    $r=@()
    try{ $r=@([Net.Dns]::GetHostAddresses($ra) | ForEach-Object { $_.IPAddressToString }) }catch{}
    if($r.Count -gt 0){ Write-YcLog ("resolved '"+$ra+"' to "+($r -join ',')+" for the firewall rule"); $ok+=$r }
    else{ Write-YcLog ("cannot use '"+$ra+"' in a firewall rule - it is not an address/CIDR and does not resolve.") 'WARN' } }
  if($ok.Count -eq 0){
    Write-YcLog ("refusing to create firewall rule '"+$Name+"': no usable remote address.") 'ERROR'
    return $false }
  $RemoteAddress = $ok
  try{
    if(Get-NetFirewallRule -DisplayName $Name -ErrorAction SilentlyContinue){
      Write-YcLog ('firewall rule already present: '+$Name)
      return $true }
    $p = @{ DisplayName=$Name; Direction=$Direction; Action='Allow'; Protocol=$Protocol;
            RemoteAddress=$RemoteAddress; Profile=$FirewallProfile; ErrorAction='Stop' }
    if($Direction -eq 'Outbound'){ $p['RemotePort']=$Port } else { $p['LocalPort']=$Port }
    New-NetFirewallRule @p | Out-Null
  }catch{ Write-YcLog ("could not create firewall rule '"+$Name+"': "+$_.Exception.Message) 'ERROR'
          return $false }
  if(-not (Get-NetFirewallRule -DisplayName $Name -ErrorAction SilentlyContinue)){
    Write-YcLog ("firewall rule '"+$Name+"' is NOT present after New-NetFirewallRule returned") 'ERROR'
    return $false }
  Write-YcLog ('firewall: '+$Direction+' '+$Protocol+'/'+$Port+' from '+($RemoteAddress -join ',')+' on profile '+($FirewallProfile -join ',')+' ('+$Name+')') 'OK'
  return $true }
function Reset-YcService{ param([string]$Name,[string]$BinPath,[string]$Start='auto')
  $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
  if($svc){
    Write-YcLog ("service '"+$Name+"' already exists - recreating it with the new command line")
    try{ Stop-Service -Name $Name -Force -ErrorAction SilentlyContinue }catch{}
    & sc.exe delete $Name | Out-Null
    Start-Sleep -Seconds 2 }
  & sc.exe create $Name binPath= $BinPath start= $Start | Out-Null
  if($LASTEXITCODE -ne 0){
    Write-YcLog ("sc.exe create "+$Name+" failed with "+$LASTEXITCODE) 'ERROR'
    return $false }
  return $true }
# ---- end injected helpers ----
'@

# WHAT CHANGED AND WHY (P0-4): Emit now (a) prefers a source-controlled, hardened copy of the command
# if one ships beside this generator - without that the generator silently overwrites the repaired
# standalone scripts with its own smaller generated body - and (b) substitutes the shared helper block
# into the generated body. .Replace() is a literal String.Replace, NOT -replace: the helper text
# contains $_ and $p, which a regex replacement would eat.
function Emit([string]$psName,[string]$cmdName,[string]$body){
  $psDst  = Join-Path $S $psName
  $cmdDst = Join-Path $S $cmdName
  $psSrc  = if($PSScriptRoot){ Join-Path $PSScriptRoot $psName }  else { $null }
  $cmdSrc = if($PSScriptRoot){ Join-Path $PSScriptRoot $cmdName } else { $null }
  # WHAT CHANGED AND WHY (2026-08-19, D2): the previous guard ANDed the "source is not the
  # destination" test INTO the same condition as "a source copy exists", so when this generator runs
  # FROM C:\Scripts - which is exactly where the payload installs it, and $S is 'C:\Scripts' - the
  # combined condition was FALSE and control fell through to the else branch, overwriting the
  # hardened on-disk script with the smaller generated body. WebJEA lost IUnderstandTheRisk /
  # CertificateThumbprint / MgmtCidr / ServiceAccount / ZipPath / SettingsFile / AllowSelfSignedCert /
  # NoFirewall (and the generated body bound plain HTTP via New-Website -Port $Port); OliveTin lost
  # ten parameters. The two tests are now NESTED: same-path means LEAVE THE FILE ALONE.
  if($psSrc -and (Test-Path $psSrc)){
    if([IO.Path]::GetFullPath($psSrc) -ne [IO.Path]::GetFullPath($psDst)){
      Copy-Item $psSrc $psDst -Force
      Info "copied $psName from source control (generated body NOT used)"
    } else {
      Info "$psName already present at the destination - LEFT UNTOUCHED (generated body NOT used)"
    }
  } else {
    Set-Content -Path $psDst -Value ($body.Replace('#YC_HELPERS#',$YcHelpers)) -Encoding ascii
    Info "wrote $psName"
  }
  if($cmdSrc -and (Test-Path $cmdSrc)){
    if([IO.Path]::GetFullPath($cmdSrc) -ne [IO.Path]::GetFullPath($cmdDst)){
      Copy-Item $cmdSrc $cmdDst -Force
      Info "copied $cmdName from source control"
    } else {
      Info "$cmdName already present at the destination - LEFT UNTOUCHED (generated wrapper NOT used)"
    }
  } else {
    Set-Content -Path $cmdDst -Value ("@echo off`r`npowershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0$psName`" %*`r`nexit /b %ERRORLEVEL%`r`n") -Encoding ascii
    Info "wrote $cmdName"
  }
}

# ===== salt-register (Salt Minion 3008.2 LTS) =====
Emit 'Salt-Register.ps1' 'salt-register.cmd' @'
param([string]$Master,[string]$MinionId=$env:COMPUTERNAME,[int]$MasterPort=4506,[int]$PublishPort=4505,[switch]$StartDelayed,[switch]$NoStart,[string]$InstallDir,[string]$CustomConfig,[switch]$Reinstall,[string[]]$Config,[string]$Grains,[string[]]$FirewallProfile=@('Domain','Private'),[switch]$SkipFirewall,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'salt-register'
#YC_HELPERS#
$Url='https://packages.broadcom.com/artifactory/saltproject-generic/windows/3008.2/Salt-Minion-3008.2-Py3-AMD64-Setup.exe'
if($Help -or -not $Master){
@"
salt-register - install + configure the Salt Minion (egress-only to the master, 4505/4506).
USAGE:
  salt-register -Master <host|ip>[,<host|ip>] [-MinionId <n>] [-MasterPort 4506] [-PublishPort 4505]
                [-StartDelayed|-NoStart] [-InstallDir <p>] [-CustomConfig <f>] [-Reinstall]
                [-Config '<opt>'] [-Grains '<yaml>'] [-FirewallProfile Domain,Private] [-SkipFirewall] [-Help]
PARAMETERS:
  -Master           master host/ip. Comma-separated for multi-master. REQUIRED.
  -MinionId         minion id (default: this computer name).
  -MasterPort       master return port (default 4506).
  -PublishPort      master publish port (default 4505).
  -StartDelayed     set the service to delayed-auto instead of auto.
  -NoStart          install and configure but do not start; no egress rules are created.
  -InstallDir       installer /install-dir.
  -CustomConfig     installer /custom-config file.
  -Reinstall        uninstall an existing minion first.
  -Config           extra minion.d lines.
  -Grains           extra grains YAML.
  -FirewallProfile  profiles for the egress rules (default Domain,Private).
  -SkipFirewall     do not create the egress rules.
  -Help             show this help and exit.
EXAMPLES:
  salt-register -Master 10.20.0.10 -MinionId web01
  salt-register -Master 10.20.0.10 -Config 'log_level: info'
  salt-register -Master 10.20.0.10,10.20.0.11 -StartDelayed
On the master:  salt-key -a <MinionId>      Verify locally:  salt-call --version
Exit codes: 0 ok, 2 usage, 3 payload/install failed, 5 not elevated, 7 service not Running.
Log: C:\Scripts\salt-register.log
"@ | Write-Host
  if($Help){ Exit-Yc 0 'help shown' 'OK' }
  Exit-Yc 2 'missing -Master' 'ERROR'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
$masters = Split-YcList $Master
$svc = Get-Service -Name 'salt-minion' -ErrorAction SilentlyContinue
if($svc -and $Reinstall){
  Write-YcLog '=== PHASE: reinstall - removing the existing salt-minion ==='
  try{ Stop-Service -Name 'salt-minion' -Force -ErrorAction SilentlyContinue }catch{}
  $u = Get-ChildItem 'C:\salt','C:\Program Files\Salt Project' -Recurse -Filter 'uninst.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
  if($u){ Invoke-YcInstaller -FilePath $u.FullName -ArgumentList @('/S') -TimeoutSec 900 | Out-Null }
  $svc = $null
}
if(-not $svc){
  Write-YcLog '=== PHASE: stage Salt Minion 3008.2 ==='
  $exe = Get-YcStaged $Url (Join-Path 'C:\Scripts' 'Salt-Minion-Setup.exe') 'Salt-Minion*Setup*.exe'
  if(-not $exe){ Exit-Yc 3 'Salt-Minion installer is not staged and could not be downloaded.' 'ERROR' }
  $a=@('/S',('/master='+$masters[0]),('/minion-name='+$MinionId))
  if($StartDelayed){ $a+='/start-service=1' }
  if($NoStart){ $a+='/start-service=0' }
  if($InstallDir){ $a+=('/install-dir='+$InstallDir) }
  if($CustomConfig){ $a+=('/custom-config='+$CustomConfig) }
  Write-YcLog '=== PHASE: install Salt Minion 3008.2 ==='
  $r = Invoke-YcInstaller -FilePath $exe -ArgumentList $a -TimeoutSec 1800 -MinSeconds 5
  if(-not $r.Success){ Exit-Yc (Get-YcFailCode $r 3) ('Salt Minion install FAILED ('+$r.Status+'): '+$r.Meaning) 'ERROR' }
} else {
  Write-YcLog 'salt-minion is already present - updating the configuration only (use -Reinstall to reinstall).'
}
Write-YcLog '=== PHASE: configure minion.d ==='
$root = if($InstallDir){ $InstallDir }
        elseif(Test-Path "$env:ProgramFiles\Salt Project\Salt\conf"){ "$env:ProgramFiles\Salt Project\Salt\conf" }
        else{ 'C:\salt\conf' }
$md = Join-Path $root 'minion.d'
New-Item -ItemType Directory -Force $md | Out-Null
$masterLines = ($masters | ForEach-Object { '  - '+$_ }) -join "`n"
$cfg = "id: $MinionId`nmaster:`n$masterLines`nmaster_port: $MasterPort`n"
if($Config){ $cfg += (($Config) -join "`n")+"`n" }
if($Grains){ $cfg += "grains:`n"+((($Grains -split "`n") | ForEach-Object { '  '+$_ }) -join "`n")+"`n" }
$conf = Join-Path $md '99-yallacloud.conf'
Set-Content -Path $conf -Value $cfg -Encoding ascii
if(-not (Assert-YcFile -Path $conf -MinBytes 10 -Because 'minion configuration')){ Exit-Yc 3 'failed to write minion.d\99-yallacloud.conf' 'ERROR' }
if($NoStart){
  Write-YcLog '-NoStart given: the minion is NOT started, so nothing can be proved and NO egress rules are created.' 'WARN'
  Exit-Yc 0 'salt-minion installed and configured but not started. Start it, then re-run without -NoStart to create the egress rules.' 'OK'
}
Write-YcLog '=== PHASE: start and prove ==='
try{
  if($StartDelayed){ & sc.exe config salt-minion start= delayed-auto | Out-Null }
  else{ Set-Service -Name 'salt-minion' -StartupType Automatic -ErrorAction SilentlyContinue }
  Restart-Service -Name 'salt-minion' -Force -ErrorAction SilentlyContinue
}catch{ Write-YcLog ('service start issue: '+$_.Exception.Message) 'WARN' }
if(-not (Assert-YcService -Name 'salt-minion' -TimeoutSec 120 -StartIfStopped -Because 'the minion must be Running before any egress rule is created')){
  Exit-Yc 7 'salt-minion did not reach Running - NOT creating the egress firewall rules.' 'ERROR'
}
if($SkipFirewall){ Write-YcLog '-SkipFirewall: no egress rules created.' }
else{
  New-YcFwRule -Name ('YallaCloud Salt out '+$PublishPort) -Direction Outbound -Port $PublishPort -RemoteAddress $masters -FirewallProfile $FirewallProfile | Out-Null
  New-YcFwRule -Name ('YallaCloud Salt out '+$MasterPort)  -Direction Outbound -Port $MasterPort  -RemoteAddress $masters -FirewallProfile $FirewallProfile | Out-Null
}
Exit-Yc 0 ('DONE. On the master run: salt-key -a '+$MinionId) 'OK'
'@

# ===== winexporter-register (windows_exporter 0.31.8) =====
Emit 'WinExporter-Register.ps1' 'winexporter-register.cmd' @'
param([int]$ListenPort=9182,[string]$ListenAddr='0.0.0.0',[string]$Collectors,[string]$TextfileDir,[string[]]$RemoteAddress=@('LocalSubnet'),[string[]]$FirewallProfile=@('Domain','Private'),[switch]$SkipFirewall,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'winexporter-register'
#YC_HELPERS#
$Url='https://github.com/prometheus-community/windows_exporter/releases/download/v0.31.8/windows_exporter-0.31.8-amd64.msi'
if($Help){
@"
winexporter-register - install windows_exporter 0.31.8 (Prometheus Windows metrics on /metrics).
USAGE:
  winexporter-register [-ListenPort 9182] [-ListenAddr 0.0.0.0] [-Collectors '<list>']
                       [-TextfileDir <p>] [-RemoteAddress 10.20.0.11] [-FirewallProfile Domain,Private]
                       [-SkipFirewall] [-Help]
PARAMETERS:
  -ListenPort       TCP port for /metrics (default 9182).
  -ListenAddr       bind address (default 0.0.0.0).
  -Collectors       ENABLED_COLLECTORS list, e.g. 'cpu,memory,logical_disk,net,os,service'.
  -TextfileDir      directory scraped by the textfile collector.
  -RemoteAddress    sources allowed through the inbound rule. Default LocalSubnet. Pass your
                    Prometheus servers or the management CIDR. 'Any' is refused.
  -FirewallProfile  profiles for the inbound rule (default Domain,Private).
  -SkipFirewall     install but open no port.
  -Help             show this help and exit.
EXAMPLES:
  winexporter-register -RemoteAddress 10.20.0.11
  winexporter-register -ListenPort 9182 -RemoteAddress 10.20.0.0/24
  winexporter-register -Collectors 'cpu,memory,logical_disk,net,os,service' -RemoteAddress 10.20.0.11
Exit codes: 0 ok, 3 payload/install failed, 5 not elevated, 7 service not Running, 8 /metrics not serving.
Log: C:\Scripts\winexporter-register.log
"@ | Write-Host
  Exit-Yc 0 'help shown' 'OK'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
Write-YcLog '=== PHASE: stage windows_exporter 0.31.8 ==='
$msi = Get-YcStaged $Url (Join-Path 'C:\Scripts' 'windows_exporter-0.31.8-amd64.msi') 'windows_exporter*.msi'
if(-not $msi){ Exit-Yc 3 'windows_exporter MSI is not staged and could not be downloaded.' 'ERROR' }
$props=@(('LISTEN_ADDR='+$ListenAddr),('LISTEN_PORT='+$ListenPort))
if($Collectors){ $props+=('ENABLED_COLLECTORS='+$Collectors) }
if($TextfileDir){ New-Item -ItemType Directory -Force $TextfileDir | Out-Null; $props+=('TEXTFILE_DIRS='+$TextfileDir) }
Write-YcLog ('=== PHASE: install windows_exporter on '+$ListenAddr+':'+$ListenPort+' ===')
$msiexec = Join-Path $env:SystemRoot 'System32\msiexec.exe'
$r = Invoke-YcInstaller -FilePath $msiexec -ArgumentList (@('/i',('"'+$msi+'"'),'/qn','/norestart')+$props) -TimeoutSec 1800
if(-not $r.Success){ Exit-Yc (Get-YcFailCode $r 3) ('windows_exporter install FAILED ('+$r.Status+'): '+$r.Meaning) 'ERROR' }
Write-YcLog '=== PHASE: prove the exporter is serving ==='
if(-not (Assert-YcService -Name 'windows_exporter' -TimeoutSec 120 -StartIfStopped -Because 'the exporter must be Running before the port is opened')){
  Exit-Yc 7 'windows_exporter did not reach Running - NOT creating the inbound rule.' 'ERROR'
}
$probe = $ListenAddr
if(-not $probe -or $probe -eq '0.0.0.0'){ $probe='127.0.0.1' }
if(-not (Assert-YcHttp -Uri ('http://'+$probe+':'+$ListenPort+'/metrics') -TimeoutSec 90 -MatchContent 'windows_exporter_build_info')){
  Exit-Yc 8 'windows_exporter is installed but /metrics is not serving - NOT creating the inbound rule.' 'ERROR'
}
if($SkipFirewall){ Write-YcLog '-SkipFirewall: no inbound rule created.' }
else{ New-YcFwRule -Name 'YallaCloud windows_exporter' -Direction Inbound -Port $ListenPort -RemoteAddress $RemoteAddress -FirewallProfile $FirewallProfile | Out-Null }
Exit-Yc 0 ('DONE. Verify: http://'+$probe+':'+$ListenPort+'/metrics') 'OK'
'@

# ===== telegraf-register (Telegraf 1.39.2 -> InfluxDB v2) =====
Emit 'Telegraf-Register.ps1' 'telegraf-register.cmd' @'
param([string]$InfluxUrl,[string]$Token,[string]$Org,[string]$Bucket='telegraf',[string]$ConfigUrl,[string]$ConfigFile,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'telegraf-register'
#YC_HELPERS#
$Url='https://dl.influxdata.com/telegraf/releases/telegraf-1.39.2_windows_amd64.zip'
if($Help -or (-not $InfluxUrl -and -not $ConfigUrl -and -not $ConfigFile)){
@"
telegraf-register - install Telegraf 1.39.2 as a service (metrics pushed OUT; no inbound port).
USAGE:
  telegraf-register -InfluxUrl <url> -Token <t> -Org <o> [-Bucket telegraf] [-Help]
  telegraf-register -ConfigUrl <url> | -ConfigFile <path>
PARAMETERS:
  -InfluxUrl   InfluxDB v2 write endpoint.
  -Token       InfluxDB API token. Never echoed - it is redacted in the log.
  -Org         InfluxDB organisation.
  -Bucket      target bucket (default telegraf).
  -ConfigUrl   download a complete telegraf.conf instead of generating one.
  -ConfigFile  copy a complete telegraf.conf instead of generating one.
  -Help        show this help and exit.
EXAMPLES:
  telegraf-register -InfluxUrl https://influx.example:8086 -Token <t> -Org yalla
  telegraf-register -ConfigFile C:\Scripts\telegraf.conf
Exit codes: 0 ok, 2 usage, 3 payload/install failed, 5 not elevated, 7 service not Running.
Log: C:\Scripts\telegraf-register.log
"@ | Write-Host
  if($Help){ Exit-Yc 0 'help shown' 'OK' }
  Exit-Yc 2 'need -InfluxUrl or -ConfigUrl/-ConfigFile' 'ERROR'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
Write-YcLog '=== PHASE: stage Telegraf 1.39.2 ==='
$zip = Get-YcStaged $Url (Join-Path 'C:\Scripts' 'telegraf-1.39.2_windows_amd64.zip') 'telegraf-*windows_amd64.zip'
if(-not $zip){ Exit-Yc 3 'Telegraf zip is not staged and could not be downloaded.' 'ERROR' }
$dir='C:\Program Files\telegraf'
if(-not (Expand-YcZip $zip $dir)){ Exit-Yc 3 'could not expand the Telegraf zip.' 'ERROR' }
$exe = Get-ChildItem $dir -Recurse -Filter 'telegraf.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
if(-not (Assert-YcFile -Path $exe -MinBytes 100000 -Because 'telegraf.exe')){ Exit-Yc 3 'telegraf.exe not found after expanding the zip.' 'ERROR' }
$conf = Join-Path (Split-Path $exe) 'telegraf.conf'
Write-YcLog '=== PHASE: configure ==='
if($ConfigFile){ Copy-Item $ConfigFile $conf -Force }
elseif($ConfigUrl){ if(-not (Get-YcFile -Uri $ConfigUrl -OutFile $conf -AllowText)){ Exit-Yc 3 'could not download -ConfigUrl.' 'ERROR' } }
else{ "[agent]`n  interval='10s'`n  hostname='$env:COMPUTERNAME'`n[[outputs.influxdb_v2]]`n  urls=['$InfluxUrl']`n  token='$Token'`n  organization='$Org'`n  bucket='$Bucket'`n[[inputs.cpu]]`n[[inputs.mem]]`n[[inputs.disk]]`n[[inputs.win_perf_counters]]" | Set-Content $conf -Encoding ascii }
if(-not (Assert-YcFile -Path $conf -MinBytes 10 -Because 'telegraf.conf')){ Exit-Yc 3 'telegraf.conf was not written.' 'ERROR' }
Write-YcLog '=== PHASE: install the service and prove ==='
try{ & $exe --service uninstall 2>$null | Out-Null }catch{}
& $exe --service install --config "$conf" 2>$null | Out-Null
try{
  Set-Service -Name 'telegraf' -StartupType Automatic -ErrorAction SilentlyContinue
  Restart-Service -Name 'telegraf' -Force -ErrorAction SilentlyContinue
}catch{ Write-YcLog ('service issue: '+$_.Exception.Message) 'WARN' }
if(-not (Assert-YcService -Name 'telegraf' -TimeoutSec 120 -StartIfStopped -Because 'Telegraf must be Running to push anything')){
  Exit-Yc 7 'telegraf did not reach Running.' 'ERROR'
}
Exit-Yc 0 'DONE (push-out; no inbound rule).' 'OK'
'@

# ===== postgresexporter-register (postgres_exporter 0.20.1) =====
Emit 'PostgresExporter-Register.ps1' 'postgresexporter-register.cmd' @'
param([string]$DataSourceName,[string]$PgHost,[string]$PgUser,[string]$PgPassword,[int]$PgPort=5432,[string]$PgDatabase='postgres',[string]$PgSslMode='disable',[int]$ListenPort=9187,[string[]]$RemoteAddress=@('LocalSubnet'),[string[]]$FirewallProfile=@('Domain','Private'),[switch]$SkipFirewall,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'postgresexporter-register'
#YC_HELPERS#
$Url='https://github.com/prometheus-community/postgres_exporter/releases/download/v0.20.1/postgres_exporter-0.20.1.windows-amd64.zip'
if($Help -or (-not $DataSourceName -and -not $PgHost)){
@"
postgresexporter-register - install postgres_exporter 0.20.1 (Prometheus PostgreSQL metrics).
USAGE:
  postgresexporter-register -DataSourceName <dsn> [-ListenPort 9187] [-RemoteAddress 10.20.0.11] [-Help]
  postgresexporter-register -PgHost <h> -PgUser <u> -PgPassword <p> [-PgPort 5432] [-PgDatabase postgres]
                            [-PgSslMode disable] [-ListenPort 9187] [-RemoteAddress 10.20.0.11]
                            [-FirewallProfile Domain,Private] [-SkipFirewall]
PARAMETERS:
  -DataSourceName   complete libpq DSN. Takes precedence over the -Pg* parameters.
  -PgHost/-PgUser/-PgPassword/-PgPort/-PgDatabase/-PgSslMode   used to build a DSN.
  -ListenPort       TCP port for /metrics (default 9187).
  -RemoteAddress    sources allowed inbound. Default LocalSubnet. 'Any' is refused.
  -FirewallProfile  profiles for the inbound rule (default Domain,Private).
  -SkipFirewall     install but open no port.
  -Help             show this help and exit.
EXAMPLES:
  postgresexporter-register -PgHost 10.0.0.5 -PgUser exporter -PgPassword <p> -RemoteAddress 10.20.0.11
  postgresexporter-register -DataSourceName 'postgresql://exporter@10.0.0.5:5432/postgres?sslmode=disable'
Exit codes: 0 ok, 2 usage, 3 payload/service failed, 5 not elevated, 7 service not Running, 8 /metrics not serving.
Log: C:\Scripts\postgresexporter-register.log
"@ | Write-Host
  if($Help){ Exit-Yc 0 'help shown' 'OK' }
  Exit-Yc 2 'need -DataSourceName or -PgHost' 'ERROR'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
if(-not $DataSourceName){ $DataSourceName="postgresql://${PgUser}:${PgPassword}@${PgHost}:${PgPort}/${PgDatabase}?sslmode=$PgSslMode" }
Write-YcLog '=== PHASE: stage postgres_exporter 0.20.1 ==='
$zip = Get-YcStaged $Url (Join-Path 'C:\Scripts' 'postgres_exporter-0.20.1.windows-amd64.zip') 'postgres_exporter-*windows-amd64.zip'
if(-not $zip){ Exit-Yc 3 'postgres_exporter zip is not staged and could not be downloaded.' 'ERROR' }
$dir='C:\Program Files\postgres_exporter'
if(-not (Expand-YcZip $zip $dir)){ Exit-Yc 3 'could not expand the postgres_exporter zip.' 'ERROR' }
$found = Get-ChildItem $dir -Recurse -Filter 'postgres_exporter.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
if($found){ Copy-Item $found (Join-Path $dir 'postgres_exporter.exe') -Force -ErrorAction SilentlyContinue }
$exe = Join-Path $dir 'postgres_exporter.exe'
if(-not (Assert-YcFile -Path $exe -MinBytes 100000 -Because 'postgres_exporter.exe')){ Exit-Yc 3 'postgres_exporter.exe not found after expanding the zip.' 'ERROR' }
Write-YcLog '=== PHASE: configure and install the service ==='
[Environment]::SetEnvironmentVariable('DATA_SOURCE_NAME',$DataSourceName,'Machine')
Write-YcLog 'DATA_SOURCE_NAME written to the machine environment (value redacted).'
if(-not (Reset-YcService 'postgres_exporter' ('"'+$exe+'" --web.listen-address=:'+$ListenPort))){ Exit-Yc 3 'could not create the postgres_exporter service.' 'ERROR' }
Write-YcLog '=== PHASE: prove the exporter is serving ==='
if(-not (Assert-YcService -Name 'postgres_exporter' -TimeoutSec 120 -StartIfStopped -Because 'the exporter must be Running before the port is opened')){
  Exit-Yc 7 'postgres_exporter did not reach Running - NOT creating the inbound rule.' 'ERROR'
}
if(-not (Assert-YcHttp -Uri ('http://127.0.0.1:'+$ListenPort+'/metrics') -TimeoutSec 90 -MatchContent 'pg_up')){
  Exit-Yc 8 'postgres_exporter is installed but /metrics is not serving - NOT creating the inbound rule.' 'ERROR'
}
if($SkipFirewall){ Write-YcLog '-SkipFirewall: no inbound rule created.' }
else{ New-YcFwRule -Name 'YallaCloud postgres_exporter' -Direction Inbound -Port $ListenPort -RemoteAddress $RemoteAddress -FirewallProfile $FirewallProfile | Out-Null }
Exit-Yc 0 ('DONE. Verify: http://127.0.0.1:'+$ListenPort+'/metrics') 'OK'
'@

# ===== mysqldexporter-register (mysqld_exporter 0.19.0) =====
Emit 'MysqldExporter-Register.ps1' 'mysqldexporter-register.cmd' @'
param([string]$MyHost,[string]$MyUser,[string]$MyPassword,[int]$MyPort=3306,[string]$DataSourceName,[int]$ListenPort=9104,[string[]]$RemoteAddress=@('LocalSubnet'),[string[]]$FirewallProfile=@('Domain','Private'),[switch]$SkipFirewall,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'mysqldexporter-register'
#YC_HELPERS#
$Url='https://github.com/prometheus/mysqld_exporter/releases/download/v0.19.0/mysqld_exporter-0.19.0.windows-amd64.zip'
if($Help -or (-not $MyHost -and -not $DataSourceName)){
@"
mysqldexporter-register - install mysqld_exporter 0.19.0 (Prometheus MySQL / MariaDB metrics).
USAGE:
  mysqldexporter-register -MyHost <h> -MyUser <u> -MyPassword <p> [-MyPort 3306] [-ListenPort 9104]
                          [-RemoteAddress 10.20.0.11] [-FirewallProfile Domain,Private] [-SkipFirewall] [-Help]
  mysqldexporter-register -DataSourceName <dsn>
PARAMETERS:
  -MyHost/-MyUser/-MyPassword/-MyPort   credentials written to my.cnf (mode 0600 equivalent ACL).
  -DataSourceName   complete DSN, used instead of my.cnf.
  -ListenPort       TCP port for /metrics (default 9104).
  -RemoteAddress    sources allowed inbound. Default LocalSubnet. 'Any' is refused.
  -FirewallProfile  profiles for the inbound rule (default Domain,Private).
  -SkipFirewall     install but open no port.
  -Help             show this help and exit.
EXAMPLES:
  mysqldexporter-register -MyHost 10.0.0.6 -MyUser exporter -MyPassword <p> -RemoteAddress 10.20.0.11
Exit codes: 0 ok, 2 usage, 3 payload/service failed, 5 not elevated, 7 service not Running, 8 /metrics not serving.
Log: C:\Scripts\mysqldexporter-register.log
"@ | Write-Host
  if($Help){ Exit-Yc 0 'help shown' 'OK' }
  Exit-Yc 2 'need -MyHost or -DataSourceName' 'ERROR'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
Write-YcLog '=== PHASE: stage mysqld_exporter 0.19.0 ==='
$zip = Get-YcStaged $Url (Join-Path 'C:\Scripts' 'mysqld_exporter-0.19.0.windows-amd64.zip') 'mysqld_exporter-*windows-amd64.zip'
if(-not $zip){ Exit-Yc 3 'mysqld_exporter zip is not staged and could not be downloaded.' 'ERROR' }
$dir='C:\Program Files\mysqld_exporter'
if(-not (Expand-YcZip $zip $dir)){ Exit-Yc 3 'could not expand the mysqld_exporter zip.' 'ERROR' }
$found = Get-ChildItem $dir -Recurse -Filter 'mysqld_exporter.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
if($found){ Copy-Item $found (Join-Path $dir 'mysqld_exporter.exe') -Force -ErrorAction SilentlyContinue }
$exe = Join-Path $dir 'mysqld_exporter.exe'
if(-not (Assert-YcFile -Path $exe -MinBytes 100000 -Because 'mysqld_exporter.exe')){ Exit-Yc 3 'mysqld_exporter.exe not found after expanding the zip.' 'ERROR' }
Write-YcLog '=== PHASE: configure and install the service ==='
$cnf = Join-Path $dir 'my.cnf'
"[client]`nuser=$MyUser`npassword=$MyPassword`nhost=$MyHost`nport=$MyPort" | Set-Content $cnf -Encoding ascii
try{ & icacls $cnf /inheritance:r /grant 'NT AUTHORITY\SYSTEM:(R)' /grant 'BUILTIN\Administrators:(F)' 2>&1 | Out-Null }catch{}
if(-not (Assert-YcFile -Path $cnf -MinBytes 10 -Because 'my.cnf holding the exporter credentials')){ Exit-Yc 3 'my.cnf was not written.' 'ERROR' }
$bin = '"'+$exe+'" --config.my-cnf="'+$cnf+'" --web.listen-address=:'+$ListenPort
if($DataSourceName){ $bin = '"'+$exe+'" --web.listen-address=:'+$ListenPort }
if(-not (Reset-YcService 'mysqld_exporter' $bin)){ Exit-Yc 3 'could not create the mysqld_exporter service.' 'ERROR' }
Write-YcLog '=== PHASE: prove the exporter is serving ==='
if(-not (Assert-YcService -Name 'mysqld_exporter' -TimeoutSec 120 -StartIfStopped -Because 'the exporter must be Running before the port is opened')){
  Exit-Yc 7 'mysqld_exporter did not reach Running - NOT creating the inbound rule.' 'ERROR'
}
if(-not (Assert-YcHttp -Uri ('http://127.0.0.1:'+$ListenPort+'/metrics') -TimeoutSec 90 -MatchContent 'mysql_up')){
  Exit-Yc 8 'mysqld_exporter is installed but /metrics is not serving - NOT creating the inbound rule.' 'ERROR'
}
if($SkipFirewall){ Write-YcLog '-SkipFirewall: no inbound rule created.' }
else{ New-YcFwRule -Name 'YallaCloud mysqld_exporter' -Direction Inbound -Port $ListenPort -RemoteAddress $RemoteAddress -FirewallProfile $FirewallProfile | Out-Null }
Exit-Yc 0 ('DONE. Verify: http://127.0.0.1:'+$ListenPort+'/metrics') 'OK'
'@

# ===== sqlexporter-register (sql_exporter 0.24.4 - MSSQL) =====
Emit 'SqlExporter-Register.ps1' 'sqlexporter-register.cmd' @'
param([string]$SqlUser,[string]$SqlPassword,[string]$SqlServer='localhost',[int]$SqlPort=1433,[string]$Database='master',[switch]$TrustedAuth,[string]$DSN,[int]$ListenPort=9399,[string]$ConfigFile,[string]$InstallDir='C:\Program Files\sql_exporter',[string[]]$RemoteAddress=@('LocalSubnet'),[string[]]$FirewallProfile=@('Domain','Private'),[switch]$SkipFirewall,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'sqlexporter-register'
#YC_HELPERS#
$Url='https://github.com/burningalchemist/sql_exporter/releases/download/0.24.4/sql_exporter-0.24.4.windows-amd64.zip'
if($Help -or (-not $SqlUser -and -not $DSN -and -not $TrustedAuth -and -not $ConfigFile)){
@"
sqlexporter-register - install sql_exporter 0.24.4 (Prometheus MSSQL / SQL Server metrics).
USAGE:
  sqlexporter-register -SqlUser <u> -SqlPassword <p> [-SqlServer localhost] [-SqlPort 1433]
                       [-Database master] [-ListenPort 9399] [-RemoteAddress 10.20.0.11]
                       [-FirewallProfile Domain,Private] [-SkipFirewall] [-Help]
  sqlexporter-register -DSN <dsn> | -TrustedAuth | -ConfigFile <f>
PARAMETERS:
  -SqlUser/-SqlPassword   SQL login used to scrape. Grant it VIEW SERVER STATE.
  -TrustedAuth      use the service account instead of a SQL login.
  -DSN              complete sqlserver:// DSN.
  -ConfigFile       a complete sql_exporter.yml to use as-is.
  -ListenPort       TCP port for /metrics (default 9399).
  -RemoteAddress    sources allowed inbound. Default LocalSubnet. 'Any' is refused.
  -FirewallProfile  profiles for the inbound rule (default Domain,Private).
  -SkipFirewall     install but open no port.
  -Help             show this help and exit.
EXAMPLES:
  sqlexporter-register -SqlUser exporter -SqlPassword <p> -RemoteAddress 10.20.0.11
  sqlexporter-register -TrustedAuth -RemoteAddress 10.20.0.0/24
Exit codes: 0 ok, 2 usage, 3 payload/service failed, 5 not elevated, 7 service not Running, 8 /metrics not serving.
Log: C:\Scripts\sqlexporter-register.log
"@ | Write-Host
  if($Help){ Exit-Yc 0 'help shown' 'OK' }
  Exit-Yc 2 'need -SqlUser / -DSN / -TrustedAuth / -ConfigFile' 'ERROR'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
if(-not $DSN){
  if($TrustedAuth){ $DSN="sqlserver://${SqlServer}:${SqlPort}?database=$Database&trusted_connection=true" }
  else{ $DSN="sqlserver://${SqlUser}:${SqlPassword}@${SqlServer}:${SqlPort}?database=$Database" }
}
Write-YcLog '=== PHASE: stage sql_exporter 0.24.4 ==='
$zip = Get-YcStaged $Url (Join-Path 'C:\Scripts' 'sql_exporter-0.24.4.windows-amd64.zip') 'sql_exporter-*windows-amd64.zip'
if(-not $zip){ Exit-Yc 3 'sql_exporter zip is not staged and could not be downloaded.' 'ERROR' }
if(-not (Expand-YcZip $zip $InstallDir)){ Exit-Yc 3 'could not expand the sql_exporter zip.' 'ERROR' }
$found = Get-ChildItem $InstallDir -Recurse -Filter 'sql_exporter.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
if($found){ Copy-Item $found (Join-Path $InstallDir 'sql_exporter.exe') -Force -ErrorAction SilentlyContinue }
$exe = Join-Path $InstallDir 'sql_exporter.exe'
if(-not (Assert-YcFile -Path $exe -MinBytes 100000 -Because 'sql_exporter.exe')){ Exit-Yc 3 'sql_exporter.exe not found after expanding the zip.' 'ERROR' }
Write-YcLog '=== PHASE: configure and install the service ==='
"collector_name: mssql_standard`nmetrics:`n  - metric_name: mssql_up`n    type: gauge`n    help: 'DB up'`n    values: [up]`n    query: `"SELECT 1 AS up`"`n  - metric_name: mssql_connections`n    type: gauge`n    help: 'User connections'`n    values: [connections]`n    query: `"SELECT COUNT(*) AS connections FROM sys.dm_exec_sessions WHERE is_user_process=1`"" | Set-Content (Join-Path $InstallDir 'mssql_standard.collector.yml') -Encoding ascii
$yml = Join-Path $InstallDir 'sql_exporter.yml'
if($ConfigFile){ Copy-Item $ConfigFile $yml -Force }
else{ "global:`n  scrape_timeout: 10s`ntarget:`n  data_source_name: '$DSN'`n  collectors: [mssql_standard]`ncollector_files:`n  - '*.collector.yml'" | Set-Content $yml -Encoding ascii }
try{ & icacls $yml /inheritance:r /grant 'NT AUTHORITY\SYSTEM:(R)' /grant 'BUILTIN\Administrators:(F)' 2>&1 | Out-Null }catch{}
if(-not (Assert-YcFile -Path $yml -MinBytes 10 -Because 'sql_exporter.yml holding the DSN')){ Exit-Yc 3 'sql_exporter.yml was not written.' 'ERROR' }
if(-not (Reset-YcService 'sql_exporter' ('"'+$exe+'" -config.file="'+$yml+'" -web.listen-address=:'+$ListenPort))){ Exit-Yc 3 'could not create the sql_exporter service.' 'ERROR' }
Write-YcLog '=== PHASE: prove the exporter is serving ==='
if(-not (Assert-YcService -Name 'sql_exporter' -TimeoutSec 120 -StartIfStopped -Because 'the exporter must be Running before the port is opened')){
  Exit-Yc 7 'sql_exporter did not reach Running - NOT creating the inbound rule.' 'ERROR'
}
if(-not (Assert-YcHttp -Uri ('http://127.0.0.1:'+$ListenPort+'/metrics') -TimeoutSec 90)){
  Exit-Yc 8 'sql_exporter is installed but /metrics is not serving - NOT creating the inbound rule.' 'ERROR'
}
if($SkipFirewall){ Write-YcLog '-SkipFirewall: no inbound rule created.' }
else{ New-YcFwRule -Name 'YallaCloud sql_exporter' -Direction Inbound -Port $ListenPort -RemoteAddress $RemoteAddress -FirewallProfile $FirewallProfile | Out-Null }
Exit-Yc 0 ('DONE. Verify: http://127.0.0.1:'+$ListenPort+'/metrics (the login needs VIEW SERVER STATE)') 'OK'
'@

# ===== webjea-install (WebJEA - IIS) =====
Emit 'WebJEA-Install.ps1' 'webjea-install.cmd' @'
param([string]$SiteName='WebJEA',[int]$Port=8443,[string]$InstallDir='C:\inetpub\WebJEA',[string]$ScriptsDir='C:\WebJEA\scripts',[string[]]$RemoteAddress=@('LocalSubnet'),[string[]]$FirewallProfile=@('Domain','Private'),[switch]$SkipFirewall,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'webjea-install'
#YC_HELPERS#
$Url='https://github.com/markdomansky/WebJEA/archive/refs/heads/master.zip'
if($Help){
@"
webjea-install - install the WebJEA IIS front-end that runs PowerShell from a browser.
SECURITY: WebJEA runs scripts as the application-pool identity. Restrict access before you expose it.
USAGE:
  webjea-install [-SiteName WebJEA] [-Port 8443] [-InstallDir C:\inetpub\WebJEA]
                 [-ScriptsDir C:\WebJEA\scripts] [-RemoteAddress 10.20.0.0/24]
                 [-FirewallProfile Domain,Private] [-SkipFirewall] [-Help]
PARAMETERS:
  -SiteName         IIS site and application-pool name (default WebJEA).
  -Port             site port (default 8443).
  -InstallDir       physical path of the site.
  -ScriptsDir       directory WebJEA is allowed to run scripts from.
  -RemoteAddress    sources allowed inbound. Default LocalSubnet. 'Any' is refused.
  -FirewallProfile  profiles for the inbound rule (default Domain,Private).
  -SkipFirewall     install but open no port.
  -Help             show this help and exit.
EXAMPLES:
  webjea-install -RemoteAddress 10.20.0.0/24
  webjea-install -Port 8443 -RemoteAddress 10.20.0.5
Exit codes: 0 ok, 3 payload/site failed, 5 not elevated, 7 W3SVC not Running.
Log: C:\Scripts\webjea-install.log
"@ | Write-Host
  Exit-Yc 0 'help shown' 'OK'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
Write-YcLog '=== PHASE: enable IIS + ASP.NET ==='
try{ Install-WindowsFeature Web-Server,Web-Asp-Net45,Web-Net-Ext45,Web-Mgmt-Console -ErrorAction SilentlyContinue | Out-Null }
catch{ Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole,IIS-ASPNET45 -All -NoRestart -ErrorAction SilentlyContinue | Out-Null }
Write-YcLog '=== PHASE: stage WebJEA ==='
$zip = Get-YcStaged $Url (Join-Path 'C:\Scripts' 'WebJEA.zip') 'WebJEA*.zip'
if(-not $zip){ Exit-Yc 3 'WebJEA payload is not staged and could not be downloaded.' 'ERROR' }
$tmp = Join-Path $env:TEMP 'webjea'
if(-not (Expand-YcZip $zip $tmp)){ Exit-Yc 3 'could not expand the WebJEA zip.' 'ERROR' }
$site = Get-ChildItem $tmp -Recurse -Directory -Filter 'website' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
New-Item -ItemType Directory -Force $InstallDir,$ScriptsDir | Out-Null
if($site){ Copy-Item (Join-Path $site '*') $InstallDir -Recurse -Force }
if(-not (Assert-YcFile -Path (Join-Path $InstallDir 'web.config') -MinBytes 10 -Because 'WebJEA site content')){
  Exit-Yc 3 'WebJEA site content is missing after the copy - not creating the site.' 'ERROR'
}
Write-YcLog '=== PHASE: create the IIS site ==='
Import-Module WebAdministration -ErrorAction SilentlyContinue
if(-not (Get-Website -Name $SiteName -ErrorAction SilentlyContinue)){
  New-WebAppPool -Name $SiteName -ErrorAction SilentlyContinue | Out-Null
  New-Website -Name $SiteName -Port $Port -PhysicalPath $InstallDir -ApplicationPool $SiteName -Force -ErrorAction SilentlyContinue | Out-Null
}
Write-YcLog '=== PHASE: prove the site is up ==='
if(-not (Assert-YcService -Name 'W3SVC' -TimeoutSec 90 -StartIfStopped -Because 'IIS must be Running before the port is opened')){
  Exit-Yc 7 'W3SVC is not Running - NOT creating the inbound rule.' 'ERROR'
}
$w = Get-Website -Name $SiteName -ErrorAction SilentlyContinue
if(-not $w){ Exit-Yc 3 ("IIS site '"+$SiteName+"' does not exist - NOT creating the inbound rule.") 'ERROR' }
if([string]$w.State -ne 'Started'){
  try{ Start-Website -Name $SiteName -ErrorAction SilentlyContinue }catch{}
  $w = Get-Website -Name $SiteName -ErrorAction SilentlyContinue
}
if([string]$w.State -ne 'Started'){ Exit-Yc 3 ("IIS site '"+$SiteName+"' is "+$w.State+" - NOT creating the inbound rule.") 'ERROR' }
Write-YcLog ("IIS site '"+$SiteName+"' is Started on port "+$Port) 'OK'
if($SkipFirewall){ Write-YcLog '-SkipFirewall: no inbound rule created.' }
else{ New-YcFwRule -Name 'YallaCloud WebJEA' -Direction Inbound -Port $Port -RemoteAddress $RemoteAddress -FirewallProfile $FirewallProfile | Out-Null }
Exit-Yc 0 ("DONE. Site '"+$SiteName+"' :"+$Port+" -> "+$InstallDir+". REVIEW Web.config and restrict access before exposing it.") 'OK'
'@

# ===== olivetin-install (stage-only) =====
Emit 'OliveTin-Install.ps1' 'olivetin-install.cmd' @'
param([string]$InstallDir='C:\Tools\OliveTin',[int]$Port=1337,[string[]]$RemoteAddress=@('LocalSubnet'),[string[]]$FirewallProfile=@('Domain','Private'),[switch]$SkipFirewall,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'olivetin-install'
#YC_HELPERS#
if($Help){
@"
olivetin-install - stage OliveTin (web UI that runs pre-defined actions).
There is no native Windows build. If a native zip has been staged it is expanded; otherwise this
command writes RUN.txt documenting the container / WSL2 command line.
USAGE:
  olivetin-install [-InstallDir C:\Tools\OliveTin] [-Port 1337] [-RemoteAddress 10.20.0.0/24]
                   [-FirewallProfile Domain,Private] [-SkipFirewall] [-Help]
PARAMETERS:
  -InstallDir       where to stage OliveTin (default C:\Tools\OliveTin).
  -Port             port OliveTin listens on (default 1337).
  -RemoteAddress    sources allowed inbound, only if a native binary was actually staged.
  -FirewallProfile  profiles for the inbound rule (default Domain,Private).
  -SkipFirewall     stage but open no port.
  -Help             show this help and exit.
EXAMPLES:
  olivetin-install
  olivetin-install -Port 1337 -RemoteAddress 10.20.0.0/24
Exit codes: 0 ok, 5 not elevated.
Log: C:\Scripts\olivetin-install.log
"@ | Write-Host
  Exit-Yc 0 'help shown' 'OK'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
New-Item -ItemType Directory -Force $InstallDir | Out-Null
Write-YcLog '=== PHASE: stage OliveTin ==='
$win = Get-ChildItem 'C:\Scripts' -Filter 'OliveTin*windows*.zip' -ErrorAction SilentlyContinue | Select-Object -First 1
if($win -and (Expand-YcZip $win.FullName $InstallDir)){
  $exe = Get-ChildItem $InstallDir -Recurse -Filter 'OliveTin*.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
  if(-not (Assert-YcFile -Path $exe -MinBytes 100000 -Because 'the native OliveTin binary')){
    Exit-Yc 0 ('OliveTin zip expanded to '+$InstallDir+' but no OliveTin executable was found - NOT opening a port.') 'WARN'
  }
  if($SkipFirewall){ Write-YcLog '-SkipFirewall: no inbound rule created.' }
  else{ New-YcFwRule -Name 'YallaCloud OliveTin' -Direction Inbound -Port $Port -RemoteAddress $RemoteAddress -FirewallProfile $FirewallProfile | Out-Null }
  Exit-Yc 0 ('DONE. Native OliveTin staged to '+$InstallDir+' on port '+$Port+'. Start it yourself as a service or a task.') 'OK'
}
$run = Join-Path $InstallDir 'RUN.txt'
("# OliveTin has no native Windows build. Container run:`ndocker run -d -p "+$Port+":1337 -v "+$InstallDir+"\config.yaml:/config/config.yaml jamesread/olivetin") | Set-Content $run -Encoding ascii
Write-YcLog ('no native build staged - wrote '+$run+' (docker / WSL2 instructions). No port opened.') 'WARN'
Exit-Yc 0 'DONE (documented only - nothing is listening, so no firewall rule was created).' 'OK'
'@

# ===== pgbadger-install (stage-only) =====
Emit 'PgBadger-Install.ps1' 'pgbadger-install.cmd' @'
param([string]$InstallDir='C:\Tools\pgbadger',[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'pgbadger-install'
#YC_HELPERS#
$Url='https://github.com/darold/pgbadger/archive/refs/tags/v13.2.zip'
if($Help){
@"
pgbadger-install - stage pgBadger 13.2 (PostgreSQL log analyzer). pgBadger is Perl; it needs
Strawberry Perl to run. If perl.exe is on PATH this command also writes C:\Scripts\pgbadger.cmd.
USAGE:
  pgbadger-install [-InstallDir C:\Tools\pgbadger] [-Help]
PARAMETERS:
  -InstallDir  where to stage pgBadger (default C:\Tools\pgbadger).
  -Help        show this help and exit.
EXAMPLES:
  pgbadger-install
  pgbadger-install -InstallDir D:\Tools\pgbadger
Then: pgbadger <postgresql.log> -o report.html
Exit codes: 0 ok, 3 payload missing, 5 not elevated.
Log: C:\Scripts\pgbadger-install.log
"@ | Write-Host
  Exit-Yc 0 'help shown' 'OK'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
New-Item -ItemType Directory -Force $InstallDir | Out-Null
Write-YcLog '=== PHASE: stage pgBadger 13.2 ==='
$zip = Get-YcStaged $Url (Join-Path 'C:\Scripts' 'pgbadger-13.2.zip') 'pgbadger*.zip'
if(-not $zip){ Exit-Yc 3 'pgBadger zip is not staged and could not be downloaded.' 'ERROR' }
if(-not (Expand-YcZip $zip $InstallDir)){ Exit-Yc 3 'could not expand the pgBadger zip.' 'ERROR' }
$pl = Get-ChildItem $InstallDir -Recurse -Filter 'pgbadger' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
if(-not (Assert-YcFile -Path $pl -MinBytes 1024 -Because 'the pgbadger Perl script')){ Exit-Yc 3 'pgbadger was not found after expanding the zip.' 'ERROR' }
$perl = (Get-Command perl.exe -ErrorAction SilentlyContinue).Source
if($perl){
  ("@echo off`r`nperl `""+$pl+"`" %*`r`nexit /b %ERRORLEVEL%") | Set-Content 'C:\Scripts\pgbadger.cmd' -Encoding ascii
  Write-YcLog 'perl.exe found - wrote C:\Scripts\pgbadger.cmd' 'OK'
  Exit-Yc 0 'DONE. Run: pgbadger <postgresql.log> -o report.html' 'OK'
}
Write-YcLog 'perl.exe is NOT on PATH - pgBadger is staged but cannot run yet. Install Strawberry Perl, then re-run this command.' 'WARN'
Exit-Yc 0 ('DONE (staged to '+$InstallDir+'; Strawberry Perl still required).') 'OK'
'@

# ===== percona-toolkit-install (stage-only) =====
Emit 'Percona-Toolkit-Install.ps1' 'percona-toolkit-install.cmd' @'
param([string]$InstallDir='C:\Tools\percona-toolkit',[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'percona-toolkit-install'
#YC_HELPERS#
$Url='https://github.com/percona/percona-toolkit/archive/refs/tags/v3.7.0.zip'
if($Help){
@"
percona-toolkit-install - stage Percona Toolkit 3.7.0 (MySQL / MariaDB CLI tools).
The pt-* tools are Perl and are NOT native Windows. Run them from Linux, WSL2 or a container
against your database; this command only stages the source and writes RUN.txt.
USAGE:
  percona-toolkit-install [-InstallDir C:\Tools\percona-toolkit] [-Help]
PARAMETERS:
  -InstallDir  where to stage the toolkit (default C:\Tools\percona-toolkit).
  -Help        show this help and exit.
EXAMPLES:
  percona-toolkit-install
  percona-toolkit-install -InstallDir D:\Tools\percona-toolkit
Exit codes: 0 ok, 3 payload missing, 5 not elevated.
Log: C:\Scripts\percona-toolkit-install.log
"@ | Write-Host
  Exit-Yc 0 'help shown' 'OK'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
New-Item -ItemType Directory -Force $InstallDir | Out-Null
Write-YcLog '=== PHASE: stage Percona Toolkit 3.7.0 ==='
$zip = Get-YcStaged $Url (Join-Path 'C:\Scripts' 'percona-toolkit-3.7.0.zip') 'percona-toolkit*.zip'
if(-not $zip){ Exit-Yc 3 'Percona Toolkit zip is not staged and could not be downloaded.' 'ERROR' }
if(-not (Expand-YcZip $zip $InstallDir)){ Exit-Yc 3 'could not expand the Percona Toolkit zip.' 'ERROR' }
$run = Join-Path $InstallDir 'RUN.txt'
'# Percona Toolkit is Perl/Linux. Run pt-* from Linux, WSL2 or a container against your DB.' | Set-Content $run -Encoding ascii
if(-not (Assert-YcFile -Path $run -MinBytes 10 -Because 'RUN.txt')){ Exit-Yc 3 'could not write RUN.txt.' 'ERROR' }
Exit-Yc 0 ('DONE. Percona Toolkit 3.7.0 staged to '+$InstallDir+' (Perl/Linux - not runnable natively here).') 'OK'
'@

# ===== alloy-register (Grafana Alloy 1.18.0) =====
Emit 'Alloy-Register.ps1' 'alloy-register.cmd' @'
param([string]$ConfigUrl,[string]$ConfigFile,[string]$Environment,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'alloy-register'
#YC_HELPERS#
$Url='https://github.com/grafana/alloy/releases/download/v1.18.0/alloy-installer-windows-amd64.exe.zip'
if($Help -or (-not $ConfigUrl -and -not $ConfigFile)){
@"
alloy-register - install Grafana Alloy 1.18.0, the unified telemetry agent (push-out; no inbound port).
Alloy replaces Promtail, which is end-of-life.
USAGE:
  alloy-register -ConfigUrl <url> | -ConfigFile <path> [-Environment '<flags>'] [-Help]
PARAMETERS:
  -ConfigUrl    download config.alloy from this URL.
  -ConfigFile   copy this local config.alloy.
  -Environment  extra service environment flags.
  -Help         show this help and exit.
EXAMPLES:
  alloy-register -ConfigFile C:\Scripts\config.alloy
  alloy-register -ConfigUrl https://cfg.example/config.alloy
Exit codes: 0 ok, 2 usage, 3 payload/install failed, 5 not elevated, 7 service not Running.
Log: C:\Scripts\alloy-register.log
"@ | Write-Host
  if($Help){ Exit-Yc 0 'help shown' 'OK' }
  Exit-Yc 2 'need -ConfigUrl or -ConfigFile' 'ERROR'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
Write-YcLog '=== PHASE: stage Grafana Alloy 1.18.0 ==='
$zip = Get-YcStaged $Url (Join-Path 'C:\Scripts' 'alloy-installer-windows-amd64.exe.zip') 'alloy-installer*windows*.zip'
if(-not $zip){ Exit-Yc 3 'Alloy installer is not staged and could not be downloaded.' 'ERROR' }
$tmp = Join-Path $env:TEMP 'alloy'
if(-not (Expand-YcZip $zip $tmp)){ Exit-Yc 3 'could not expand the Alloy zip.' 'ERROR' }
$inst = Get-ChildItem $tmp -Recurse -Filter 'alloy-installer*.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
if(-not (Assert-YcFile -Path $inst -MinBytes 100000 -Because 'the Alloy installer')){ Exit-Yc 3 'the Alloy installer was not found after expanding the zip.' 'ERROR' }
Write-YcLog '=== PHASE: install Alloy ==='
$r = Invoke-YcInstaller -FilePath $inst -ArgumentList @('/S') -TimeoutSec 1200 -MinSeconds 3
if(-not $r.Success){ Exit-Yc (Get-YcFailCode $r 3) ('Alloy install FAILED ('+$r.Status+'): '+$r.Meaning) 'ERROR' }
Write-YcLog '=== PHASE: configure ==='
$cfg='C:\Program Files\GrafanaLabs\Alloy\config.alloy'
if($ConfigFile){ Copy-Item $ConfigFile $cfg -Force }
elseif($ConfigUrl){ if(-not (Get-YcFile -Uri $ConfigUrl -OutFile $cfg -AllowText)){ Exit-Yc 3 'could not download -ConfigUrl.' 'ERROR' } }
if(-not (Assert-YcFile -Path $cfg -MinBytes 10 -Because 'config.alloy')){ Exit-Yc 3 'config.alloy is missing.' 'ERROR' }
Write-YcLog '=== PHASE: start and prove ==='
try{
  Set-Service -Name 'Alloy' -StartupType Automatic -ErrorAction SilentlyContinue
  Restart-Service -Name 'Alloy' -Force -ErrorAction SilentlyContinue
}catch{ Write-YcLog ('service issue: '+$_.Exception.Message) 'WARN' }
if(-not (Assert-YcService -Name 'Alloy' -TimeoutSec 120 -StartIfStopped -Because 'Alloy must be Running to ship anything')){
  Exit-Yc 7 'the Alloy service did not reach Running.' 'ERROR'
}
Exit-Yc 0 'DONE (push-out; no inbound rule).' 'OK'
'@

# ===== otelcol-register (OpenTelemetry Collector contrib 0.157.0) =====
Emit 'Otelcol-Register.ps1' 'otelcol-register.cmd' @'
param([string]$ConfigUrl,[string]$ConfigFile,[string]$InstallDir='C:\Program Files\otelcol-contrib',[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'otelcol-register'
#YC_HELPERS#
$Url='https://github.com/open-telemetry/opentelemetry-collector-releases/releases/download/v0.157.0/otelcol-contrib_0.157.0_windows_amd64.tar.gz'
if($Help -or (-not $ConfigUrl -and -not $ConfigFile)){
@"
otelcol-register - install the OpenTelemetry Collector contrib 0.157.0 as a service.
Egress only: this command opens NO inbound port. If your config defines an OTLP receiver
(4317/4318) you must open that port yourself, scoped to the senders.
USAGE:
  otelcol-register -ConfigUrl <url> | -ConfigFile <path> [-InstallDir <p>] [-Help]
PARAMETERS:
  -ConfigUrl    download config.yaml from this URL.
  -ConfigFile   copy this local config.yaml.
  -InstallDir   install directory (default C:\Program Files\otelcol-contrib).
  -Help         show this help and exit.
EXAMPLES:
  otelcol-register -ConfigFile C:\Scripts\otelcol.yaml
  otelcol-register -ConfigUrl https://cfg.example/otelcol.yaml
NOTE: unpacking a .tar.gz needs tar.exe, which ships with Windows Server 2019 and later.
      On Server 2016 stage an already-unpacked otelcol-contrib.exe into -InstallDir instead.
Exit codes: 0 ok, 2 usage, 3 payload/service failed, 4 tar.exe missing, 5 not elevated, 7 service not Running.
Log: C:\Scripts\otelcol-register.log
"@ | Write-Host
  if($Help){ Exit-Yc 0 'help shown' 'OK' }
  Exit-Yc 2 'need -ConfigUrl or -ConfigFile' 'ERROR'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
New-Item -ItemType Directory -Force $InstallDir | Out-Null
$exe = Join-Path $InstallDir 'otelcol-contrib.exe'
if(-not (Test-Path -LiteralPath $exe)){
  Write-YcLog '=== PHASE: stage otelcol-contrib 0.157.0 ==='
  $tgz = Get-YcStaged $Url (Join-Path 'C:\Scripts' 'otelcol-contrib_0.157.0_windows_amd64.tar.gz') 'otelcol-contrib*windows_amd64.tar.gz'
  if(-not $tgz){ Exit-Yc 3 'otelcol-contrib is not staged and could not be downloaded.' 'ERROR' }
  if(-not (Get-Command tar.exe -ErrorAction SilentlyContinue)){
    Exit-Yc 4 'tar.exe is not present (Windows Server 2019+ only). Stage an unpacked otelcol-contrib.exe into -InstallDir and re-run.' 'ERROR'
  }
  & tar.exe -xzf "$tgz" -C "$InstallDir"
  $found = Get-ChildItem $InstallDir -Recurse -Filter 'otelcol-contrib.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
  if($found -and ($found -ne $exe)){ Copy-Item $found $exe -Force -ErrorAction SilentlyContinue }
}
if(-not (Assert-YcFile -Path $exe -MinBytes 1000000 -Because 'otelcol-contrib.exe')){ Exit-Yc 3 'otelcol-contrib.exe not found after unpacking.' 'ERROR' }
Write-YcLog '=== PHASE: configure ==='
$cfg = Join-Path $InstallDir 'config.yaml'
if($ConfigFile){ Copy-Item $ConfigFile $cfg -Force }
elseif($ConfigUrl){ if(-not (Get-YcFile -Uri $ConfigUrl -OutFile $cfg -AllowText)){ Exit-Yc 3 'could not download -ConfigUrl.' 'ERROR' } }
if(-not (Assert-YcFile -Path $cfg -MinBytes 10 -Because 'the collector config')){ Exit-Yc 3 'config.yaml is missing.' 'ERROR' }
Write-YcLog '=== PHASE: install the service and prove ==='
if(-not (Reset-YcService 'otelcol-contrib' ('"'+$exe+'" --config="'+$cfg+'"'))){ Exit-Yc 3 'could not create the otelcol-contrib service.' 'ERROR' }
if(-not (Assert-YcService -Name 'otelcol-contrib' -TimeoutSec 120 -StartIfStopped -Because 'the collector must be Running to export anything')){
  Exit-Yc 7 'otelcol-contrib did not reach Running.' 'ERROR'
}
Exit-Yc 0 'DONE (egress; open any inbound OTLP port yourself, scoped to your senders).' 'OK'
'@

# ===== dbatools-install (dbatools 2.8.4 PowerShell module) =====
Emit 'Dbatools-Install.ps1' 'dbatools-install.cmd' @'
param([switch]$Online,[string]$Scope='AllUsers',[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'dbatools-install'
#YC_HELPERS#
if($Help){
@"
dbatools-install - install the dbatools PowerShell module for SQL Server management.
Default is OFFLINE from a staged C:\Scripts\dbatools*.nupkg; -Online installs from the PSGallery.
USAGE:
  dbatools-install [-Online] [-Scope AllUsers|CurrentUser] [-Help]
PARAMETERS:
  -Online  install from the PSGallery instead of the staged nupkg (needs egress).
  -Scope   AllUsers (default) or CurrentUser.
  -Help    show this help and exit.
EXAMPLES:
  dbatools-install
  dbatools-install -Online
Exit codes: 0 ok, 3 install failed, 5 not elevated.
Log: C:\Scripts\dbatools-install.log
"@ | Write-Host
  Exit-Yc 0 'help shown' 'OK'
}
Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
$nupkg = Get-ChildItem 'C:\Scripts' -Filter 'dbatools*.nupkg' -ErrorAction SilentlyContinue | Select-Object -First 1
if(-not $Online -and $nupkg){
  Write-YcLog ('=== PHASE: offline install from '+$nupkg.Name+' ===')
  $dst = "$env:ProgramFiles\WindowsPowerShell\Modules\dbatools"
  New-Item -ItemType Directory -Force $dst | Out-Null
  $tmp = Join-Path $env:TEMP 'dbatools_pkg'
  if(-not (Expand-YcZip $nupkg.FullName $tmp)){ Exit-Yc 3 'could not expand the dbatools nupkg.' 'ERROR' }
  Copy-Item (Join-Path $tmp '*') $dst -Recurse -Force -ErrorAction SilentlyContinue
}else{
  Write-YcLog '=== PHASE: online install from the PSGallery ==='
  try{
    Set-YcTls
    Install-PackageProvider -Name NuGet -Force -Scope $Scope -ErrorAction SilentlyContinue | Out-Null
    Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -ErrorAction SilentlyContinue
    Install-Module dbatools -Force -Scope $Scope -AllowClobber -ErrorAction Stop
  }catch{ Exit-Yc 3 ('dbatools install failed: '+$_.Exception.Message) 'ERROR' }
}
Write-YcLog '=== PHASE: prove the module imports ==='
$ver = $null
try{ Import-Module dbatools -ErrorAction Stop; $ver = (Get-Module dbatools).Version }catch{ $ver = $null }
if(-not $ver){ Exit-Yc 3 'dbatools was placed on disk but does not import - the install did not work.' 'ERROR' }
Exit-Yc 0 ('DONE. dbatools '+$ver+' imported.') 'OK'
'@

# ---- optionally stage offline payloads now ----
# WHAT CHANGED AND WHY (P0-4): this block used the private YC-* staging helper. It now uses the real
# library: Start-YcLog / Set-YcTls / Get-YcFile / Write-YcLog, and it REPORTS which payloads failed
# instead of silently piping every result to Out-Null.
if($Stage -and -not $NoStage){
  . (Join-Path $S '_yc-lib.ps1')
  Start-YcLog 'extras-stage'
  Set-YcTls
  $dl=@{ 'Salt-Minion-Setup.exe'='https://packages.broadcom.com/artifactory/saltproject-generic/windows/3008.2/Salt-Minion-3008.2-Py3-AMD64-Setup.exe';
    'windows_exporter-0.31.8-amd64.msi'='https://github.com/prometheus-community/windows_exporter/releases/download/v0.31.8/windows_exporter-0.31.8-amd64.msi';
    'telegraf-1.39.2_windows_amd64.zip'='https://dl.influxdata.com/telegraf/releases/telegraf-1.39.2_windows_amd64.zip';
    'postgres_exporter-0.20.1.windows-amd64.zip'='https://github.com/prometheus-community/postgres_exporter/releases/download/v0.20.1/postgres_exporter-0.20.1.windows-amd64.zip';
    'mysqld_exporter-0.19.0.windows-amd64.zip'='https://github.com/prometheus/mysqld_exporter/releases/download/v0.19.0/mysqld_exporter-0.19.0.windows-amd64.zip';
    'sql_exporter-0.24.4.windows-amd64.zip'='https://github.com/burningalchemist/sql_exporter/releases/download/0.24.4/sql_exporter-0.24.4.windows-amd64.zip';
    'WebJEA.zip'='https://github.com/markdomansky/WebJEA/archive/refs/heads/master.zip';
    'pgbadger-13.2.zip'='https://github.com/darold/pgbadger/archive/refs/tags/v13.2.zip';
    'percona-toolkit-3.7.0.zip'='https://github.com/percona/percona-toolkit/archive/refs/tags/v3.7.0.zip';
    'alloy-installer-windows-amd64.exe.zip'='https://github.com/grafana/alloy/releases/download/v1.18.0/alloy-installer-windows-amd64.exe.zip';
    'otelcol-contrib_0.157.0_windows_amd64.tar.gz'='https://github.com/open-telemetry/opentelemetry-collector-releases/releases/download/v0.157.0/otelcol-contrib_0.157.0_windows_amd64.tar.gz' }
  $ok=0; $bad=@()
  foreach($k in ($dl.Keys | Sort-Object)){
    $out = Join-Path $S $k
    if(Test-Path -LiteralPath $out){ Write-YcLog ('already staged: '+$k); $ok++; continue }
    if(Get-YcFile -Uri $dl[$k] -OutFile $out){ $ok++ } else { $bad += $k }
  }
  if($bad.Count -gt 0){ Write-YcLog ('staged '+$ok+' payload(s); FAILED: '+($bad -join ', ')+' - those commands will fall back to downloading at run time.') 'WARN' }
  else{ Write-YcLog ('staged all '+$ok+' offline payloads into '+$S) 'OK' }
  Stop-YcLog 0
  Info 'staged offline installer payloads into C:\Scripts'
}

# ---- append to yallacloud catalog (idempotent) ----
# The reconciled Yallacloud.ps1 already lists every command below, so this block is a no-op on a
# current payload. It stays for older images whose catalog predates the extras.
$yc=Join-Path $S 'Yallacloud.ps1'
if(Test-Path $yc){ $raw=Get-Content $yc -Raw
  if($raw -notmatch 'salt-register'){
    $add="`n# --- YallaCloud EXTRAS (guide-parity) ---`nWrite-Host ''`nWrite-Host 'Observability / automation / DB (extras):' -ForegroundColor Yellow`n'  salt-register              Salt Minion 3008.2 (egress 4505/4506)',`n'  winexporter-register       windows_exporter 0.31.8 (:9182)',`n'  telegraf-register          Telegraf 1.39.2 -> InfluxDB v2 (push)',`n'  postgresexporter-register  postgres_exporter 0.20.1 (:9187)',`n'  mysqldexporter-register    mysqld_exporter 0.19.0 (:9104)',`n'  sqlexporter-register       sql_exporter 0.24.4 MSSQL (:9399)',`n'  webjea-install             WebJEA IIS front-end (:8443)',`n'  olivetin-install           OliveTin (stage/WSL2)',`n'  pgbadger-install           pgBadger 13.2 (Perl)',`n'  percona-toolkit-install    Percona Toolkit 3.7.0 (Perl/Linux)',`n'  alloy-register             Grafana Alloy 1.18.0 (push)',`n'  otelcol-register           OpenTelemetry Collector 0.157.0 (egress)',`n'  dbatools-install           dbatools 2.8.4 (SQL PowerShell module)' | ForEach-Object { Write-Host `$_ }`n"
    Add-Content -Path $yc -Value $add -Encoding ascii; Info 'appended extras to Yallacloud.ps1'
  } else { Info 'yallacloud already lists extras' }
} else { Info 'Yallacloud.ps1 not present yet (build generates it; rerun extras after build to append)' }
Info 'Setup-YallaCloudExtras.ps1 complete.'
