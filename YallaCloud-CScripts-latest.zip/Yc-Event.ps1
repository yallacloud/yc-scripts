param(
  [string]$Type       = '',
  [string]$Step       = '',
  [string]$FailedStep = '',
  [string]$ErrorText  = '',
  [string]$Extra      = '',
  [string]$SetUrl     = '',
  [string]$SetSecret  = '',
  [string]$SetToken   = '',
  [string]$SetExtraUrl    = '',
  [string]$SetExtraSecret = '',
  [string]$SetNtfy    = '',
  # ntfy presentation. All optional: left empty, a message looks exactly as it always did.
  # A phone shows the TITLE and the first line, so a caller that knows whether it succeeded
  # should say so there rather than making somebody open the notification to find out.
  [string]$NtfyTitle    = '',
  [ValidateSet('','1','2','3','4','5')][string]$NtfyPriority = '',
  [string]$NtfyTags     = '',
  [string[]]$NtfyLine   = @(),
  [string]$SqlKeyLast5 = '',
  [ValidateSet('','on','off')][string]$SetNtfyEnabled = '',
  [string]$SaPassword = '',
  [string]$VmPassword = '',
  # The extensibility hook. -Field name=value, repeatable, lands in a "fields" object in
  # the payload. Anything new to report goes HERE first; a field only earns a top-level
  # place once it is proven and permanent. The receiver never waits on a payload release
  # to start collecting something.
  [string[]]$Field = @(),
  [switch]$Report,
  [switch]$Test,
  [switch]$Drain,
  [switch]$NoQueue,
  [switch]$SelfCheck,
  [switch]$Help
)
# =====================================================================================
# Yc-Event.ps1 - work out what this VM actually is, and tell the outside world about it.
# PowerShell 5.1 only. ASCII only.
#
# WHY THIS EXISTS
#   A VM that finishes building is useless to a fleet if nothing outside it knows. ntfy
#   tells a human; it does not tell a system. This posts a structured event to the
#   YallaCloud webhook AND the ntfy line, from one place, so every caller - the SQL
#   template userdata, a day-2 script, a person at a console - reports the same shape.
#
# THE HARD PART IS NOT THE POST, IT IS KNOWING WHO YOU ARE
#   CloudStack tells a guest who it is through two different doors, and neither is open
#   all the time:
#     * the VIRTUAL ROUTER metadata service, at http://<DHCP server>/latest/meta-data/.
#       Open only while the VM is on that network and the router is up.
#     * the CONFIG DRIVE, a small ISO or vfat volume carrying \openstack\ or \cloudstack\.
#       Present at FIRST BOOT and then ejected. Measured on dxb01 2026-09-07: on a VM
#       built 3 days earlier there is no config-2 volume left at all, only an empty D:.
#   cloudbase-init reads whichever answers first and keeps NO log of it (there is no
#   logdir in the shipped conf), so it cannot be asked afterwards.
#
#   Therefore this script does not "fetch" identity when it needs it. It ACCUMULATES it:
#   every run reads every door that happens to be open and merges what it finds into
#   vm-facts.json, and a value once known is never overwritten by a blank. The config
#   drive gets read on the one boot where it exists and its answer survives forever.
#
#   Underneath both doors is one that is always open: the SMBIOS UUID. Measured on
#   dxb01 2026-09-07 it is EXACTLY the CloudStack VM UUID -
#     SMBIOS D4BBD2F9-76AD-4C27-8DDF-D4AD308C53A3
#     cmk    d4bbd2f9-76ad-4c27-8ddf-d4ad308c53a3
#   No network, no disc, no router. That is the identity of last resort and it is enough
#   to join to CloudStack, because the backend can resolve everything else from the id.
#
# WHAT THE BACKEND STILL HAS TO DO
#   Domain, account, project and template name are NOT visible from inside a guest. They
#   exist only in the CloudStack database. This sends vmId; the receiver resolves the rest
#   with listVirtualMachines id=<uuid>. Copying them into the guest would produce a record
#   that is wrong the first time a VM is migrated or moved between accounts.
#
# WHEN DELIVERY FAILS
#   A webhook cannot report its own silence. So:
#     1. a failed POST is retried, then written to yc-event-queue.jsonl
#     2. every later run drains the queue before sending anything new
#     3. every payload carries a "delivery" block - how many are queued, how old the
#        oldest is, what the last error was - so the FIRST post that gets through tells
#        the backend exactly what it missed and why
#     4. if the webhook is unreachable the ntfy line still goes, and both failing still
#        writes the event to disk and to the Application event log
#   Nothing here is ever fatal. A dead endpoint must not cost you a VM.
#
# CONFIG - set once, used forever
#   C:\ProgramData\YallaCloud\yc-event.json   { url, secret, token, ntfy }
#   NOT C:\Scripts: the payload update wipes that folder, and it would take the queue and
#   the accumulated facts with it.
#   Auth is whichever field is filled - no mode to get wrong:
#     token  -> Authorization: Bearer <token>
#     secret -> X-Webhook-Secret: <secret>
#     both   -> both headers are sent
#     neither-> webhook is off, ntfy still fires, and it says so
#
# EXIT CODES
#   0 delivered (or nothing to do)      1 queued, not delivered
#   2 usage                             5 not elevated
#
# Log: C:\Scripts\yc-event.log, plus the Application event log, source YALLACLOUD.
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'yc-event'
$ErrorActionPreference = 'Stop'

$YcDir   = 'C:\ProgramData\YallaCloud'
$CfgFile = Join-Path $YcDir 'yc-event.json'
$FactFile= Join-Path $YcDir 'vm-facts.json'
$QueueFile=Join-Path $YcDir 'yc-event-queue.jsonl'
$QueueMax= 200

$HelpText = @"
yc-event - report what this VM is, and what just happened to it.

USAGE
  yc-event -Report                       what this VM knows about itself. Sends NOTHING.
  yc-event -Test                         post type=webhook.test, print the HTTP code
  yc-event -Type vm.deploy.started
  yc-event -Type vm.deploy.step      -Step "NET+ SYNC+"
  yc-event -Type vm.deploy.completed -Step "NET+ SYNC+ DOTNET+ SQL+ ..."
  yc-event -Type vm.deploy.failed    -FailedStep SQL -ErrorText "install-sql rc=1"
  yc-event -Type vm.error            -ErrorText "ssms install returned 1603"
  yc-event -Drain                        retry everything that never got through
  yc-event -SelfCheck                    assertions only, no admin, changes nothing

CONFIGURE ONCE (stored in C:\ProgramData\YallaCloud\yc-event.json)
  yc-event -SetUrl https://api.yallacloud.net/api/v1/webhooks/cloudstack
  yc-event -SetSecret <the webhook secret>
  yc-event -SetToken  <a JWT, if you use bearer auth instead>
  yc-event -SetExtraUrl <url> -SetExtraSecret <s>   optional SECOND webhook: same event, passwords removed
  yc-event -SetNtfy   https://ntfy.sh/9890122212
  yc-event -SetNtfyEnabled on|off        ntfy is OFF by default - a URL is not consent
  Set a value to '-' to clear it.

WHY -Test IS THE ONE TO REACH FOR AT 2AM
  It separates the three things that look identical from a ticket: a wrong URL, a wrong
  token, and no egress. It prints the status code, or the transport error, and changes
  nothing.

IDENTITY
  Accumulated, not fetched. The config drive exists only at first boot and the virtual
  router only while networked, so every run merges whatever door is open into
  vm-facts.json and never overwrites a known value with a blank. The SMBIOS UUID is the
  CloudStack VM UUID and always works.
"@
if ($Help) { Write-Output $HelpText; Exit-Yc 0 }

# -------------------------------------------------------------------------------------
# small helpers. NOTE: no function here may be named MD, H, SC or similar - those are
# built-in aliases (mkdir, Get-History, Set-Content) and the collision costs a whole run
# before you see it.
# -------------------------------------------------------------------------------------
function ConvertTo-YcText {
  <# Invoke-WebRequest -UseBasicParsing hands back .Content as a byte[] for text/plain on
     PowerShell 5.1. Enumerate it and you get a column of character codes instead of the
     string - which is exactly what happened the first time this was written. #>
  param($Content)
  if ($null -eq $Content) { return '' }
  if ($Content -is [byte[]]) { return [Text.Encoding]::ASCII.GetString($Content) }
  return [string]$Content
}

function Get-YcDubaiTime {
  <#
    Dubai local time, converted EXPLICITLY rather than read off the box.
    A guest's local clock is whatever someone set it to - these happen to be +04:00, but
    a template cloned into another region, or a machine that lost its timezone during
    sysprep, would silently report the wrong wall-clock and nobody would question a
    timestamp. Asia/Dubai is UTC+4 with no daylight saving, so the conversion is exact
    all year. 'Arabian Standard Time' is the Windows id for it.
    utc stays in the payload alongside this - a local time without its UTC twin is a
    timestamp you cannot compare across a fleet.
  #>
  param([datetime]$Utc = (Get-Date).ToUniversalTime())
  try {
    $tz = [TimeZoneInfo]::FindSystemTimeZoneById('Arabian Standard Time')
    $d  = [TimeZoneInfo]::ConvertTimeFromUtc($Utc, $tz)
  } catch {
    $d = $Utc.AddHours(4)   # Dubai has no DST, so the fixed offset is not a guess
  }
  return ($d.ToString('yyyy-MM-dd HH:mm:ss') + ' +04 Dubai')
}

function ConvertTo-YcAscii {
  # ntfy takes one line. Anything else - a stack trace, a quote, a newline - turns a
  # readable alert into noise on a phone.
  #
  # -KeepLines is the deliberate exception, for a caller that has composed a short, aligned
  # summary on purpose. Each line is still flattened and stripped the same way; only the
  # breaks BETWEEN lines survive. A stack trace cannot get in this way because the caller
  # passes an array of lines it wrote, not whatever it caught.
  param([string]$Text,[switch]$KeepLines)
  if (-not $Text) { return '' }
  if ($KeepLines) {
    # A caller-composed block keeps its padding and its backslashes. The narrow whitelist below
    # exists to flatten text we did NOT write - a stack trace, a quoted error - and applying it
    # here destroyed the thing it was asked to preserve: "phases   : 17 of 17" collapsed to
    # "phases : 17 of 17", and C:\Scripts\adopt-migrated-vm.log came out as "C: Scripts
    # adopt-migrated-vm.log", which cannot be pasted anywhere. Printable ASCII only, control
    # characters still go, and the alignment survives because the alignment IS the formatting.
    $out = @()
    foreach ($l in ($Text -split "`r?`n")) { $out += (($l -replace '[^\x20-\x7E]', ' ')).TrimEnd() }
    return (($out -join "`n").Trim())
  }
  return ((($Text -replace '[^A-Za-z0-9 .:+/=_-]', ' ') -replace '\s+', ' ')).Trim()
}

function Merge-YcFacts {
  <# The whole reliability story in six lines: a value that is known is never replaced by
     a blank. So the config drive read at first boot survives its own ejection, and a
     later run with no network cannot erase the zone. New non-empty values DO win, which
     is how volatile fields (ip, free disk) stay current without a second rule. #>
  param([hashtable]$Into, [hashtable]$From)
  if (-not $From) { return $Into }
  foreach ($k in $From.Keys) {
    $v = $From[$k]
    if ($null -eq $v) { continue }
    if ($v -is [string] -and $v.Trim() -eq '') { continue }
    $Into[$k] = $v
  }
  return $Into
}

# Keys that ONLY the CloudStack virtual router supplies. If its record turns out to be another
# machine's, these are the fields that were poisoned by it and there is no second source to
# correct them from, so they are dropped and re-learned rather than reported forever.
# hostname and ip are deliberately NOT here: Get-YcLocalFacts supplies both from this machine
# and merges after the router, so they repair themselves on the next run.
$script:YcRouterOnlyKeys = @('cloud', 'zone', 'offering', 'publicIp')

function Resolve-YcIdentity {
  <# WHY THIS EXISTS (ERP receiver log, yallacloud01, 2026-10-19)

     The virtual router answers metadata BY SOURCE IP, and it has returned another VM's record.
     Two different machines, JOBANESTATE12-V and JOBANTENANT-VM, both reported
     vmId 5add6c3f-1f25-4202-8990-371a53db064e on their vm.deploy.completed event. The ERP
     matches on cloudstack.vmId and nothing else, so it completed INST-0085 twice - once with
     each machine's licensing state, last write winning - and never completed INST-0115 or
     INST-0118 at all. Their vm.deploy.started events had been correct, because at that point
     the router had answered about the right machine.

     The router's value won for one reason only: it was merged AFTER the SMBIOS one, and
     Merge-YcFacts lets any newer non-empty value win. Then the merge-never-lose cache kept it.

     SMBIOS is the hypervisor's own answer about THIS machine and cannot be about another, so it
     decides. And when the two disagree the ENTIRE router record is another machine's - not just
     its vmId - so none of it is merged: its offering, zone, publicIp and hostname are that other
     machine's too, which is exactly what the log shows (offering changed between started and
     completed on both VMs).

     NOTE FOR NON-KVM: on CloudStack with KVM the SMBIOS UUID *is* the CloudStack VM uuid. On
     VMware it is the VMware BIOS UUID and CloudStack keeps its own, so there the router's
     instance-id is the CloudStack id. That is why routerVmId is reported rather than discarded -
     no identity is lost either way, and the receiver can match on smbiosUuid first and vmId
     second. Pure function, so -SelfCheck can prove all of this without a VM.  #>
  param([hashtable]$Cache, [hashtable]$Smbios, [hashtable]$Router)
  if (-not $Cache)  { $Cache  = @{} }
  if (-not $Smbios) { $Smbios = @{} }
  if (-not $Router) { $Router = @{} }

  $out = @{ facts = $Cache; mismatch = $false; routerVmId = ''; purged = @() }
  $smId = [string]$Smbios['vmId']

  # A cache already holding a foreign vmId is a machine damaged by an earlier run. The router-only
  # fields in it came from that same foreign record, and nothing else can correct them, so they go.
  if ($smId -and ([string]$Cache['vmId']) -and ([string]$Cache['vmId']) -ne $smId) {
    foreach ($k in $script:YcRouterOnlyKeys) {
      if ($Cache.ContainsKey($k)) { $Cache.Remove($k); $out.purged += $k }
    }
  }

  $out.facts = Merge-YcFacts -Into $Cache -From $Smbios

  $rtId = [string]$Router['vmId']
  if ($smId -and $rtId -and $rtId -ne $smId) {
    $out.mismatch   = $true
    $out.routerVmId = $rtId
    # Keep the provenance, drop the facts. metadataHost says WHICH router answered, which is what
    # anyone investigating needs, and it is about the network rather than about the other VM.
    $keep = @{}
    if ($Router['metadataHost']) { $keep['metadataHost'] = $Router['metadataHost'] }
    $out.facts = Merge-YcFacts -Into $out.facts -From $keep
  } else {
    $out.facts = Merge-YcFacts -Into $out.facts -From $Router
  }

  # Belt and braces. Whatever else merged above, SMBIOS decides this one field.
  if ($smId) { $out.facts['vmId'] = $smId }
  $out.facts['vmIdMismatch'] = $out.mismatch
  if ($out.routerVmId) { $out.facts['routerVmId'] = $out.routerVmId }
  return $out
}

function Get-YcSqlKeyForBody {
  <# sqlKeyLast5 is passed in once by whoever knew the key and then persists in the cache, which
     is right - SQL may not be installed yet when the userdata runs. What was wrong is REPORTING
     it before SQL exists. The ERP log shows the fragment on two machines with no SQL at all
     (sqlVersion "", sqlEdition "", sqlLicensed false, extra saying sql=none) and EMPTY on the one
     machine genuinely running SQL 2019 Standard. A key fragment for software that is not
     installed is both a false fact and a small disclosure, so it is held back until SQL answers.
     The cached value is untouched and ships the moment SQL is really there. #>
  param([hashtable]$Facts)
  if (-not $Facts) { return '' }
  if (-not ([string]$Facts['sqlVersion']) -and -not ([string]$Facts['sqlEdition'])) { return '' }
  return [string]$Facts['sqlKeyLast5']
}

function Get-YcTrialDaysForBody {
  <# A day count outlives the trial it was counting. The ERP log has a machine at
     winTrial=false, winLicensed=true, winStatus="Licensed" still reporting
     winTrialDaysLeft=10 - the number the cache remembered from before it was activated.
     Read on its own, as a billing system reads it, that says a licensed machine expires in
     ten days. There is no trial, so the honest answer is null, not a stale number and not 0,
     which would read as "expires today". #>
  param($InTrial, $Days)
  if ($InTrial -ne $true) { return $null }
  return $Days
}

function Get-YcAuthHeaders {
  # Emptiness is the switch. A -AuthMode parameter would be a third thing to get wrong.
  param([string]$Secret, [string]$Token)
  $h = @{}
  if ($Token)  { $h['Authorization']    = 'Bearer ' + $Token }
  if ($Secret) { $h['X-Webhook-Secret'] = $Secret }
  return $h
}

function Select-YcQueueKeep {
  # An unbounded queue on a box that cannot reach its endpoint for a month is a disk-full
  # outage wearing a helpful hat. Keep the NEWEST $Max - the oldest failure is the least
  # useful one, and the delivery block reports how many were dropped.
  param([string[]]$Lines, [int]$Max)
  $l = @($Lines | Where-Object { $_ -and $_.Trim() })
  if ($l.Count -le $Max) { return $l }
  return @($l[($l.Count - $Max)..($l.Count - 1)])
}

function Get-YcExtraBody {
  # The optional SECOND webhook (-SetExtraUrl) gets the same event with every secret-looking
  # value blanked: saPassword / vmPassword travel to the ERP on purpose, never to a second door.
  # Pure, so -SelfCheck proves it. One level of nesting (fields) is all the body has.
  param([System.Collections.IDictionary]$Body)
  $rx = '(?i)pass|pwd|secret|token|^uri|dsn'
  $out = [ordered]@{}
  foreach ($k in @($Body.Keys)) {
    $v = $Body[$k]
    if ($v -is [System.Collections.IDictionary]) {
      $sub = [ordered]@{}
      foreach ($k2 in @($v.Keys)) { $v2 = $v[$k2]; $sub[$k2] = $(if ($k2 -match $rx -and $v2 -is [string] -and $v2) { 'REDACTED' } else { $v2 }) }
      $out[$k] = $sub
    } elseif ($k -match $rx -and $v -is [string] -and $v) { $out[$k] = 'REDACTED' }
    else { $out[$k] = $v }
  }
  return $out
}

# -------------------------------------------------------------------------------------
# -SelfCheck. Runs anywhere, needs nothing, changes nothing.
# -------------------------------------------------------------------------------------
if ($SelfCheck) {
  $pass = 0; $fail = 0
  function T($name, $cond) {
    if ($cond) { Write-Output ('ok   ' + $name); $script:pass++ }
    else       { Write-Output ('FAIL ' + $name); $script:fail++ }
  }

  # the byte[] trap that cost a run
  T 'decodes a byte array'      ((ConvertTo-YcText ([Text.Encoding]::ASCII.GetBytes('d4bbd2f9-76ad'))) -eq 'd4bbd2f9-76ad')
  T 'passes a string through'   ((ConvertTo-YcText 'plain') -eq 'plain')
  T 'null is empty, not null'   ((ConvertTo-YcText $null) -eq '')

  # merge: the rule the whole design rests on
  $c = @{ zone = 'YCDXB01'; vmId = 'abc' }
  $c = Merge-YcFacts -Into $c -From @{ zone = ''; ip = '10.0.0.5' }
  T 'blank never erases'        ($c['zone'] -eq 'YCDXB01')
  T 'new key is added'          ($c['ip'] -eq '10.0.0.5')
  $c = Merge-YcFacts -Into $c -From @{ ip = '10.0.0.9' }
  T 'newer value wins'          ($c['ip'] -eq '10.0.0.9')
  $c = Merge-YcFacts -Into $c -From @{ ip = '   ' }
  T 'whitespace never erases'   ($c['ip'] -eq '10.0.0.9')
  $c = Merge-YcFacts -Into $c -From $null
  T 'null source is harmless'   ($c['vmId'] -eq 'abc')

  # auth: emptiness is the switch
  $h = Get-YcAuthHeaders -Secret 'S' -Token ''
  T 'secret only'               ($h.Count -eq 1 -and $h['X-Webhook-Secret'] -eq 'S')
  $h = Get-YcAuthHeaders -Secret '' -Token 'J'
  T 'token only is bearer'      ($h.Count -eq 1 -and $h['Authorization'] -eq 'Bearer J')
  $h = Get-YcAuthHeaders -Secret 'S' -Token 'J'
  T 'both sends both'           ($h.Count -eq 2)
  $h = Get-YcAuthHeaders -Secret '' -Token ''
  T 'neither sends nothing'     ($h.Count -eq 0)

  # ntfy line stays one line
  T 'newlines flattened'        ((ConvertTo-YcAscii "a`r`nb") -eq 'a b')
  T 'quotes stripped'           ((ConvertTo-YcAscii 'say "hi"') -eq 'say hi')
  T 'uuid survives'             ((ConvertTo-YcAscii 'd4bbd2f9-76ad-4c27') -eq 'd4bbd2f9-76ad-4c27')

  # Dubai time: a fixed +4 with no DST, checked at both ends of the year so a future
  # change to the helper cannot quietly reintroduce a summer-time bug.
  T 'dubai is utc+4 in winter'  ((Get-YcDubaiTime -Utc ([datetime]::SpecifyKind([datetime]'2026-01-15T06:00:00', 'Utc'))) -like '2026-01-15 10:00:00 +04 Dubai*')
  T 'dubai is utc+4 in summer'  ((Get-YcDubaiTime -Utc ([datetime]::SpecifyKind([datetime]'2026-07-15T06:00:00', 'Utc'))) -like '2026-07-15 10:00:00 +04 Dubai*')
  T 'dubai rolls the date over' ((Get-YcDubaiTime -Utc ([datetime]::SpecifyKind([datetime]'2026-09-08T21:30:00', 'Utc'))) -like '2026-09-09 01:30:00 +04 Dubai*')

  # -Field parsing: a value may itself contain '=' and must survive intact.
  function ParseField($a) {
    $o = [ordered]@{}
    foreach ($kv in $a) { $i = $kv.IndexOf('='); if ($i -gt 0) { $o[$kv.Substring(0,$i)] = $kv.Substring($i+1) } }
    return $o
  }
  $pf = ParseField @('a=1','b=hello world','c=x=y','bad')
  T 'field parses pairs'      ($pf['a'] -eq '1' -and $pf['b'] -eq 'hello world')
  T 'field keeps = in value'  ($pf['c'] -eq 'x=y')
  T 'field drops junk'        ($pf.Count -eq 3)

  # queue cap keeps the NEWEST
  $q = 1..250 | ForEach-Object { 'e' + $_ }
  $k = Select-YcQueueKeep -Lines $q -Max 200
  T 'queue trimmed to cap'      ($k.Count -eq 200)
  T 'keeps the newest'          ($k[-1] -eq 'e250')
  T 'drops the oldest'          ($k[0] -eq 'e51')
  T 'under cap is untouched'    ((Select-YcQueueKeep -Lines @('a','b') -Max 200).Count -eq 2)
  T 'blank lines dropped'       ((Select-YcQueueKeep -Lines @('a','','b') -Max 200).Count -eq 2)

  # ---------------------------------------------------------------------------------
  # identity: the router answering about ANOTHER VM. Every assertion here is a line from
  # the ERP receiver log of 2026-10-19, turned into something that cannot regress.
  # ---------------------------------------------------------------------------------
  $SM  = @{ vmId = '625da4f9-a9cc-44f4-8ab7-17442bfb623a'; smbiosUuid = '625da4f9-a9cc-44f4-8ab7-17442bfb623a' }
  $FOREIGN = '5add6c3f-1f25-4202-8990-371a53db064e'

  # the exact failure: the router claims another VM's id and brings its whole record with it
  $r = Resolve-YcIdentity -Cache @{} -Smbios $SM `
         -Router @{ vmId = $FOREIGN; offering = 'Core Flex GC Base Plan'; zone = 'YCDXB01'
                    publicIp = '93.177.125.223'; hostname = 'SOMEONE-ELSE'
                    metadataHost = '93.177.125.228'; identitySource = 'virtual-router' }
  T 'smbios wins the vmId'            ($r.facts['vmId'] -eq $SM['vmId'])
  T 'the router claim is kept aside'  ($r.facts['routerVmId'] -eq $FOREIGN)
  T 'the mismatch is reported'        ($r.facts['vmIdMismatch'] -eq $true)
  T 'and flagged on the result'       ($r.mismatch -eq $true)
  T 'no foreign offering leaks in'    (-not $r.facts['offering'])
  T 'no foreign publicIp leaks in'    (-not $r.facts['publicIp'])
  T 'no foreign hostname leaks in'    ($r.facts['hostname'] -ne 'SOMEONE-ELSE')
  T 'no foreign zone leaks in'        (-not $r.facts['zone'])
  T 'which router answered is kept'   ($r.facts['metadataHost'] -eq '93.177.125.228')

  # the agreeing case must stay fully functional - this is the normal path
  $r = Resolve-YcIdentity -Cache @{} -Smbios $SM `
         -Router @{ vmId = $SM['vmId']; offering = 'Core Flex GC Base Plan'; zone = 'YCDXB01'
                    publicIp = '93.177.125.223'; identitySource = 'virtual-router' }
  T 'agreement keeps the offering'    ($r.facts['offering'] -eq 'Core Flex GC Base Plan')
  T 'agreement keeps the publicIp'    ($r.facts['publicIp'] -eq '93.177.125.223')
  T 'agreement reports no mismatch'   ($r.facts['vmIdMismatch'] -eq $false)
  T 'agreement adds no routerVmId'    (-not $r.facts['routerVmId'])

  # a cache poisoned by an earlier bad run is repaired, not reported forever
  $r = Resolve-YcIdentity -Cache @{ vmId = $FOREIGN; offering = 'WRONG PLAN'; publicIp = '1.2.3.4'
                                    zone = 'WRONGZONE'; cloud = 'WRONGCLOUD'; freeGb = 80.8 } `
         -Smbios $SM -Router @{}
  T 'poisoned cache vmId is corrected' ($r.facts['vmId'] -eq $SM['vmId'])
  T 'poisoned offering is dropped'     (-not $r.facts['offering'])
  T 'poisoned publicIp is dropped'     (-not $r.facts['publicIp'])
  T 'poisoned zone is dropped'         (-not $r.facts['zone'])
  T 'the purge is reported'            (@($r.purged).Count -eq 4)
  T 'non-router facts are untouched'   ($r.facts['freeGb'] -eq 80.8)

  # no router at all (VMware with no VR, or a network change) must not invent a mismatch
  $r = Resolve-YcIdentity -Cache @{} -Smbios $SM -Router @{}
  T 'no router is not a mismatch'     ($r.facts['vmIdMismatch'] -eq $false -and $r.facts['vmId'] -eq $SM['vmId'])
  # and no SMBIOS either (it is the one source that should always answer, but prove the shape)
  $r = Resolve-YcIdentity -Cache @{} -Smbios @{} -Router @{ vmId = $FOREIGN; zone = 'YCDXB01' }
  T 'without smbios the router is used' ($r.facts['vmId'] -eq $FOREIGN -and $r.facts['zone'] -eq 'YCDXB01')
  T 'and that is not called a mismatch' ($r.facts['vmIdMismatch'] -eq $false)
  T 'null arguments are harmless'       ((Resolve-YcIdentity -Cache $null -Smbios $null -Router $null).mismatch -eq $false)

  # ---------------------------------------------------------------------------------
  # sqlKeyLast5: reported only once SQL actually exists
  # ---------------------------------------------------------------------------------
  T 'no sql, no key'            ((Get-YcSqlKeyForBody -Facts @{ sqlKeyLast5 = 'ABCDE'; sqlVersion = ''; sqlEdition = '' }) -eq '')
  T 'sql by version, key goes'  ((Get-YcSqlKeyForBody -Facts @{ sqlKeyLast5 = 'ABCDE'; sqlVersion = '15.0.2000.5' }) -eq 'ABCDE')
  T 'sql by edition, key goes'  ((Get-YcSqlKeyForBody -Facts @{ sqlKeyLast5 = 'ABCDE'; sqlEdition = 'Standard Edition' }) -eq 'ABCDE')
  T 'sql but no key is empty'   ((Get-YcSqlKeyForBody -Facts @{ sqlVersion = '15.0.2000.5' }) -eq '')
  T 'no facts is empty'         ((Get-YcSqlKeyForBody -Facts $null) -eq '')

  # ---------------------------------------------------------------------------------
  # trial day counts: a number must not outlive the trial it was counting
  # ---------------------------------------------------------------------------------
  T 'licensed clears the count'  ($null -eq (Get-YcTrialDaysForBody -InTrial $false -Days 10))
  T 'in trial keeps the count'   ((Get-YcTrialDaysForBody -InTrial $true -Days 180) -eq 180)
  T 'unknown trial is null'      ($null -eq (Get-YcTrialDaysForBody -InTrial $null -Days 10))
  T 'in trial with no count'     ($null -eq (Get-YcTrialDaysForBody -InTrial $true -Days $null))
  T 'zero days survives a trial' ((Get-YcTrialDaysForBody -InTrial $true -Days 0) -eq 0)

  # ---------------------------------------------------------------------------------
  # the optional second webhook never receives a password
  # ---------------------------------------------------------------------------------
  $xb = Get-YcExtraBody -Body ([ordered]@{ type = 'vm.deploy.completed'; saPassword = 'Sa#1'; vmPassword = 'Vm#2'; winKeyLast5 = 'ABCDE'
                                          fields = [ordered]@{ acronisToken = 'T#3'; area = 'build'; adminPassword = '' } })
  T 'extra: saPassword blanked'     ($xb['saPassword'] -eq 'REDACTED')
  T 'extra: vmPassword blanked'     ($xb['vmPassword'] -eq 'REDACTED')
  T 'extra: nested token blanked'   ($xb['fields']['acronisToken'] -eq 'REDACTED')
  T 'extra: plain fields untouched' ($xb['type'] -eq 'vm.deploy.completed' -and $xb['winKeyLast5'] -eq 'ABCDE' -and $xb['fields']['area'] -eq 'build')
  T 'extra: empty stays empty'      ($xb['fields']['adminPassword'] -eq '')

  Write-Output ''
  Write-Output ('SelfCheck: ' + $pass + ' passed, ' + $fail + ' failed')
  if ($fail -gt 0) { Exit-Yc 1 'SelfCheck FAILED' } else { Exit-Yc 0 'SelfCheck: all checks passed' }
}

Write-YcInvocation
if (-not (Test-Path -LiteralPath $YcDir)) { New-Item -ItemType Directory -Path $YcDir -Force | Out-Null }

# -------------------------------------------------------------------------------------
# config
# -------------------------------------------------------------------------------------
function Get-YcEventConfig {
  # ntfyEnabled defaults to OFF. A ntfy URL being present is not consent to post to it -
  # a whole fleet reporting every build into one topic is noise nobody reads by week two,
  # and the webhook is the system of record. ntfy is the exception, for the boxes you
  # actually want to be paged about.
  $c = @{ url = ''; secret = ''; token = ''; ntfy = ''; ntfyEnabled = $false; extraUrl = ''; extraSecret = '' }
  if (Test-Path -LiteralPath $CfgFile) {
    try {
      $raw = (Get-Content -LiteralPath $CfgFile -Raw)
      if ($raw -and $raw.Trim()) {
        $j = $raw | ConvertFrom-Json
        foreach ($k in @('url','secret','token','ntfy','extraUrl','extraSecret')) { if ($j.$k) { $c[$k] = [string]$j.$k } }
        if ($null -ne $j.ntfyEnabled) { $c['ntfyEnabled'] = [bool]$j.ntfyEnabled }
      }
    } catch { Write-YcLog ('yc-event.json is unreadable (' + $_.Exception.Message + '); treating the config as empty.') 'WARN' }
  }
  return $c
}

function Save-YcEventConfig {
  param([hashtable]$Cfg)
  ([pscustomobject]$Cfg) | ConvertTo-Json | Set-Content -LiteralPath $CfgFile -Encoding ascii
  # The secret lives here. Take inheritance off so a later Users grant on ProgramData
  # cannot quietly widen it.
  & icacls.exe $CfgFile '/inheritance:r' '/grant' 'SYSTEM:F' 'Administrators:F' *>$null
}

$cfg = Get-YcEventConfig
$changed = $false
foreach ($p in @(@('url',$SetUrl), @('secret',$SetSecret), @('token',$SetToken), @('ntfy',$SetNtfy), @('extraUrl',$SetExtraUrl), @('extraSecret',$SetExtraSecret))) {
  if ($p[1]) { $cfg[$p[0]] = $(if ($p[1] -eq '-') { '' } else { $p[1] }); $changed = $true }
}
if ($SetNtfyEnabled) { $cfg['ntfyEnabled'] = ($SetNtfyEnabled -eq 'on'); $changed = $true }
if ($changed) {
  Save-YcEventConfig -Cfg $cfg
  Write-YcLog ('config saved: url=' + $(if ($cfg.url) { $cfg.url } else { '<none>' }) +
               ' auth=' + $(if ($cfg.token) { 'bearer token' } elseif ($cfg.secret) { 'X-Webhook-Secret' } else { 'NONE - webhook is off' }) +
               ' ntfy=' + $(if ($cfg.ntfy) { $cfg.ntfy } else { '<none>' }) +
               ' ntfyEnabled=' + $(if ($cfg.ntfyEnabled) { 'ON' } else { 'OFF (default)' }) +
               ' extra=' + $(if ($cfg.extraUrl -and $cfg.extraSecret) { $cfg.extraUrl } else { 'off' })) 'OK'
  if (-not $Type -and -not $Test -and -not $Report -and -not $Drain) { Exit-Yc 0 'config updated' }
}

# -------------------------------------------------------------------------------------
# identity, accumulated from every door that happens to be open
# -------------------------------------------------------------------------------------
function Get-YcFactsCache {
  $h = @{}
  if (Test-Path -LiteralPath $FactFile) {
    try {
      $raw = (Get-Content -LiteralPath $FactFile -Raw)
      if ($raw -and $raw.Trim()) {
        ($raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $h[$_.Name] = $_.Value }
      }
    } catch { Write-YcLog ('vm-facts.json is unreadable (' + $_.Exception.Message + '); starting a fresh cache.') 'WARN' }
  }
  return $h
}

function Get-YcSmbiosFacts {
  # Always available. No network, no disc, no router. On CloudStack/KVM this IS the VM UUID.
  $h = @{}
  try {
    $p = Get-CimInstance Win32_ComputerSystemProduct -ErrorAction Stop
    if ($p.UUID -and $p.UUID -notmatch '^0{8}-' -and $p.UUID -notmatch 'FFFFFFFF') {
      $h['smbiosUuid'] = ([string]$p.UUID).ToLower()
      $h['vmId']       = ([string]$p.UUID).ToLower()
    }
    if ($p.Vendor) { $h['hypervisor'] = [string]$p.Vendor }
  } catch {}
  return $h
}

function Get-YcRouterFacts {
  <# The CloudStack virtual router answers on the DHCP server address. Present while the VM
     is on that network - which is most of the time, but not during a network change, and
     not at all on a VMware deployment with no VR. #>
  $h = @{}
  $dhcp = $null
  try {
    $dhcp = @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' -ErrorAction Stop |
              ForEach-Object { $_.DHCPServer } | Where-Object { $_ -and $_ -ne '255.255.255.255' } | Select-Object -First 1)
  } catch {}
  if (-not $dhcp) { return $h }
  $dhcp = [string]$dhcp
  $map = @{
    'instance-id'      = 'vmId'
    'availability-zone'= 'zone'
    'service-offering' = 'offering'
    'local-hostname'   = 'hostname'
    'local-ipv4'       = 'ip'
    'public-ipv4'      = 'publicIp'
    'cloud-identifier' = 'cloud'
  }
  foreach ($k in $map.Keys) {
    try {
      $r = Invoke-WebRequest -Uri ('http://' + $dhcp + '/latest/meta-data/' + $k) -UseBasicParsing -TimeoutSec 6
      $v = (ConvertTo-YcText $r.Content).Trim()
      if ($v) { $h[$map[$k]] = $v }
    } catch {}
  }
  if ($h.Count) { $h['identitySource'] = 'virtual-router'; $h['metadataHost'] = $dhcp }
  return $h
}

function Get-YcConfigDriveFacts {
  <# Present at FIRST BOOT and then ejected, so this usually finds nothing - and that is
     fine, because whatever it found the one time it ran is already in the cache. Two
     layouts: OpenStack (\openstack\latest\meta_data.json) and CloudStack
     (\cloudstack\metadata\*.txt). cloudbase-init is configured for vfat and iso, on hdd,
     partition and cdrom, so look at every volume that has a letter. #>
  $h = @{}
  $roots = @()
  try {
    $roots = @(Get-CimInstance Win32_LogicalDisk -ErrorAction Stop |
               Where-Object { $_.DeviceID } | ForEach-Object { $_.DeviceID + '\' })
  } catch { return $h }

  foreach ($root in $roots) {
    $os = Join-Path $root 'openstack\latest\meta_data.json'
    if (Test-Path -LiteralPath $os) {
      try {
        $j = (Get-Content -LiteralPath $os -Raw) | ConvertFrom-Json
        if ($j.uuid)              { $h['vmId']     = ([string]$j.uuid).ToLower() }
        if ($j.name)              { $h['hostname'] = [string]$j.name }
        if ($j.availability_zone) { $h['zone']     = [string]$j.availability_zone }
        if ($j.meta) { $j.meta.PSObject.Properties | ForEach-Object { $h['meta_' + $_.Name] = [string]$_.Value } }
        $h['identitySource'] = 'config-drive-openstack'
        $h['configDrive']    = $root
      } catch {}
    }
    $cs = Join-Path $root 'cloudstack\metadata'
    if (Test-Path -LiteralPath $cs) {
      $map = @{
        'instance-id'      = 'vmId'
        'vm-id'            = 'vmId'
        'availability-zone'= 'zone'
        'service-offering' = 'offering'
        'local-hostname'   = 'hostname'
        'local-ipv4'       = 'ip'
        'public-ipv4'      = 'publicIp'
        'cloud-identifier' = 'cloud'
      }
      foreach ($k in $map.Keys) {
        $f = Join-Path $cs ($k + '.txt')
        if (Test-Path -LiteralPath $f) {
          try {
            $v = ((Get-Content -LiteralPath $f -TotalCount 1) | Out-String).Trim()
            if ($v) { $h[$map[$k]] = $v }
          } catch {}
        }
      }
      if (-not $h['identitySource']) { $h['identitySource'] = 'config-drive-cloudstack' }
      $h['configDrive'] = $root
    }
  }
  return $h
}

function Get-YcWinLicence {
  # The discriminator is the CHANNEL plus the STATUS. "Licensed" on its own is true of a
  # GVLK box sitting in Notification, which is the trap this fleet has hit six times.
  $h = @{}
  try {
    $d = cscript //nologo C:\Windows\System32\slmgr.vbs /dlv 2>&1 | Out-String
    if ($d -match 'Product Key Channel:\s*(.+)') { $h['winChannel'] = $Matches[1].Trim() }
    if ($d -match 'License Status:\s*(.+)')      { $h['winStatus']  = $Matches[1].Trim() }
    if ($d -match 'Partial Product Key:\s*(.+)') { $h['winKeyLast5']= $Matches[1].Trim() }
  } catch {}
  $h['winLicensed'] = [bool](($h['winChannel'] -match 'MAK|KMS|ADBA') -and ($h['winStatus'] -match 'Licensed'))
  return $h
}

function Get-YcTrialFacts {
  # How long is left on whatever is NOT licensed. Reported only when it is real - a fully
  # licensed box has no trial, and a zero here would read as "expires today".
  $h = @{}
  try {
    $p = Get-CimInstance SoftwareLicensingProduct -ErrorAction Stop |
         Where-Object { $_.PartialProductKey -and $_.ApplicationID -eq '55c92734-d682-4d71-983e-d6ec3f16059f' } |
         Select-Object -First 1
    if ($p -and $p.GracePeriodRemaining -gt 0) {
      $h['winTrialDaysLeft'] = [int][math]::Round($p.GracePeriodRemaining / 1440)
      $h['winTrial'] = $true
    } elseif ($p) { $h['winTrial'] = $false }
  } catch {}
  return $h
}

function Get-YcSqlFacts {
  $h = @{}
  try {
    $cn = New-Object System.Data.SqlClient.SqlConnection 'Server=.;Database=master;Integrated Security=True;Connect Timeout=10'
    $cn.Open()
    try {
      $cm = $cn.CreateCommand()
      # ProductLevel is RTM/SP1/SP2/SP3. ProductUpdateLevel is CU15 and friends, and
      # ProductUpdateReference is the KB. SERVICE PACKS ONLY EXIST UP TO SQL 2016 -
      # Microsoft dropped them for 2017 and later, where CU is the only servicing unit.
      # So on 2019 ProductLevel is RTM forever and the number that actually tells you
      # how patched a box is, is ProductUpdateLevel. Reporting only the first would make
      # every modern instance look unpatched, or worse, look fine.
      # The two Update columns are NULL on old builds, hence the ISNULL.
      $cm.CommandText = "SELECT CAST(SERVERPROPERTY('Edition') AS varchar(100)) e, " +
                        "CAST(SERVERPROPERTY('ProductVersion') AS varchar(50)) v, " +
                        "CAST(SERVERPROPERTY('ProductLevel') AS varchar(20)) l, " +
                        "ISNULL(CAST(SERVERPROPERTY('ProductUpdateLevel') AS varchar(20)),'') u, " +
                        "ISNULL(CAST(SERVERPROPERTY('ProductUpdateReference') AS varchar(20)),'') k"
      $rd = $cm.ExecuteReader()
      if ($rd.Read()) {
        $h['sqlEdition'] = ([string]$rd['e']) -replace ' \(64-bit\)',''
        $h['sqlVersion'] = [string]$rd['v']
        $h['sqlPatch']   = [string]$rd['l']
        if ([string]$rd['u']) { $h['sqlUpdateLevel'] = [string]$rd['u'] }
        if ([string]$rd['k']) { $h['sqlUpdateKb']    = [string]$rd['k'] }
        # One field a human can read without knowing the servicing model: "RTM" alone is
        # alarming on 2019 until you know there are no SPs; "RTM, no CU applied" is not
        # ambiguous, and "RTM CU15" says exactly where you stand.
        $h['sqlServicing'] = ($h['sqlPatch'] + $(if ($h['sqlUpdateLevel']) { ' ' + $h['sqlUpdateLevel'] } else { ', no CU applied' }))
        $h['sqlLicensed']= ($h['sqlEdition'] -notmatch 'Evaluation')
        # SQL Evaluation is 180 days from INSTALL, and SQL exposes no expiry property at
        # all. msdb is created by setup, so its create_date IS the install date - the
        # standard way to work this out, and the only one not built on a registry guess.
        if (-not $h['sqlLicensed']) {
          try {
            $cm2 = $cn.CreateCommand()
            $cm2.CommandText = "SELECT DATEDIFF(day, GETDATE(), DATEADD(day, 180, create_date)) d FROM sys.databases WHERE database_id = 4"
            $left = $cm2.ExecuteScalar()
            if ($null -ne $left) { $h['sqlTrialDaysLeft'] = [int]$left; $h['sqlTrial'] = $true }
          } catch {}
        } else { $h['sqlTrial'] = $false }
      }
      $rd.Close()
    } finally { $cn.Close() }
  } catch {}
  return $h
}

function Get-YcLocalFacts {
  $h = @{}
  $h['hostname'] = $env:COMPUTERNAME
  try {
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
    $h['os']        = ($os.Caption -replace 'Microsoft Windows Server ','').Trim()
    $h['osVersion'] = [string]$os.Version
  } catch {}
  try {
    $ip = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
            Select-Object -First 1)
    if ($ip) { $h['ip'] = [string]$ip[0].IPAddress }
  } catch {}
  try {
    $v = Get-Volume -DriveLetter C -ErrorAction Stop
    $h['freeGb'] = [math]::Round($v.SizeRemaining / 1GB, 1)
  } catch {}
  try {
    if (Test-Path 'C:\Scripts\Yallacloud.ps1') {
      $m = Select-String -Path 'C:\Scripts\Yallacloud.ps1' -Pattern "^\`$YcCatalogVersion\s*=\s*'([^']+)'" | Select-Object -First 1
      if ($m) { $h['catalogue'] = $m.Matches[0].Groups[1].Value }
    }
    if (Test-Path 'C:\Scripts\yc-payload-version.txt') {
      $m = Select-String -Path 'C:\Scripts\yc-payload-version.txt' -Pattern '^payload_version\s*=\s*(\S+)' | Select-Object -First 1
      if ($m) { $h['payload'] = $m.Matches[0].Groups[1].Value }
    }
  } catch {}
  foreach ($p in @('C:\Program Files (x86)\Microsoft SQL Server Management Studio*\Common7\IDE\Ssms.exe',
                   'C:\Program Files\Microsoft SQL Server Management Studio*\Release\Common7\IDE\Ssms.exe',
                   'C:\Program Files\Microsoft SQL Server Management Studio*\Common7\IDE\Ssms.exe')) {
    $f = Get-Item $p -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($f) { $h['ssms'] = ($f.VersionInfo.FileVersion -split '\s+')[0]; break }
  }
  return $h
}

function Get-YcFacts {
  # Windows hands us its partial key for free via slmgr. SQL Server does NOT expose its
  # product key at all - the DigitalProductID blob is obfuscated and version-specific, and
  # decoding it would be real work for no benefit. So the last 5 are passed in ONCE by
  # whoever knew the key (the userdata that used it) and then persist through the
  # merge-never-lose cache, which is exactly what that cache is for.
  # Five characters cannot reconstruct a key - this is the same partial Microsoft prints.
  # Cache first so a known value is the floor, then every door in order of durability.
  $f = Get-YcFactsCache
  # SMBIOS and the router are resolved TOGETHER rather than merged in sequence, because the
  # router has been seen answering with another VM's record and a plain merge lets it win on
  # order alone. Resolve-YcIdentity carries the whole reason.
  $id = Resolve-YcIdentity -Cache $f -Smbios (Get-YcSmbiosFacts) -Router (Get-YcRouterFacts)
  $f  = $id.facts
  if ($id.mismatch) {
    Write-YcLog ('the virtual router reported vmId ' + $id.routerVmId + ' but SMBIOS says ' +
                 [string]$f['vmId'] + ' - the router answered about a DIFFERENT VM, so none of ' +
                 'its metadata was used this run. Reporting vmIdMismatch=true.') 'WARN'
  }
  if (@($id.purged).Count) {
    Write-YcLog ('dropped cached router values that came from another VM''s record (' +
                 (@($id.purged) -join ', ') + '); they will be re-learned when the router ' +
                 'answers about this VM.') 'WARN'
  }
  $f = Merge-YcFacts -Into $f -From (Get-YcConfigDriveFacts)
  $f = Merge-YcFacts -Into $f -From (Get-YcLocalFacts)
  $f = Merge-YcFacts -Into $f -From (Get-YcWinLicence)
  $f = Merge-YcFacts -Into $f -From (Get-YcSqlFacts)
  $f = Merge-YcFacts -Into $f -From (Get-YcTrialFacts)
  # Merge-YcFacts cannot clear a value - that is its whole point - so a day count left over from
  # before activation has to be removed here, or the cache reports it forever. Removing rather
  # than zeroing: 0 reads as "expires today".
  if ($f.ContainsKey('winTrial') -and $f['winTrial'] -ne $true) { [void]$f.Remove('winTrialDaysLeft') }
  if ($f.ContainsKey('sqlTrial') -and $f['sqlTrial'] -ne $true) { [void]$f.Remove('sqlTrialDaysLeft') }
  if ($SqlKeyLast5) { $f = Merge-YcFacts -Into $f -From @{ sqlKeyLast5 = $SqlKeyLast5.Trim().ToUpper() } }
  # Passwords are remembered like any other fact, so a later -Report or a replayed event
  # still carries them. THEY GO OUT IN CLEARTEXT, at Bilal's explicit instruction
  # (2026-09-08, option C) - the receiving API logs the whole payload, so these land in
  # application logs. A deliberate, informed choice, not an oversight.
  if ($SaPassword) { $f = Merge-YcFacts -Into $f -From @{ saPassword = $SaPassword } }
  if ($VmPassword) { $f = Merge-YcFacts -Into $f -From @{ vmPassword = $VmPassword } }
  if (-not $f['identitySource']) { $f['identitySource'] = 'smbios' }
  $now = (Get-Date).ToUniversalTime()
  $f['factsUtc']    = $now.ToString('s') + 'Z'
  $f['lastUpdated'] = Get-YcDubaiTime -Utc $now
  try { ([pscustomobject]$f) | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $FactFile -Encoding ascii }
  catch { Write-YcLog ('could not write ' + $FactFile + ': ' + $_.Exception.Message) 'WARN' }
  return $f
}

# -------------------------------------------------------------------------------------
# the queue - what makes this a record rather than a notification
# -------------------------------------------------------------------------------------
function Get-YcQueue {
  if (-not (Test-Path -LiteralPath $QueueFile)) { return @() }
  try { return @(Get-Content -LiteralPath $QueueFile | Where-Object { $_ -and $_.Trim() }) } catch { return @() }
}

function Set-YcQueue {
  param([string[]]$Lines)
  $keep = Select-YcQueueKeep -Lines $Lines -Max $QueueMax
  if ($keep.Count -eq 0) { Remove-Item -LiteralPath $QueueFile -Force -ErrorAction SilentlyContinue; return 0 }
  Set-Content -LiteralPath $QueueFile -Value $keep -Encoding ascii
  return $keep.Count
}

function Get-YcDeliveryBlock {
  # Rides on every payload. A webhook cannot report its own silence, so the first message
  # that DOES get through has to carry the shape of the gap it is closing.
  $q = Get-YcQueue
  $b = [ordered]@{ queued = $q.Count }
  if ($q.Count) {
    try {
      $first = $q[0] | ConvertFrom-Json
      if ($first.utc) { $b['oldestQueuedUtc'] = [string]$first.utc }
    } catch {}
    $b['droppedOverCap'] = ($q.Count -ge $QueueMax)
  }
  if ($script:LastSendError) { $b['lastError'] = $script:LastSendError }
  return $b
}

# -------------------------------------------------------------------------------------
# shipping
# -------------------------------------------------------------------------------------
$script:LastSendError = ''

function Send-YcWebhook {
  <# Returns $true only on a 2xx. Retries a few times because the common failure here is a
     virtual router that is still coming up, not a wrong URL. #>
  param([string]$Json, [int]$Attempts = 3)
  if (-not $cfg.url) { $script:LastSendError = 'no webhook url configured'; return $false }
  $headers = Get-YcAuthHeaders -Secret $cfg.secret -Token $cfg.token
  if ($headers.Count -eq 0) { $script:LastSendError = 'no secret and no token configured'; return $false }
  $headers['Content-Type'] = 'application/json'
  for ($i = 1; $i -le $Attempts; $i++) {
    try {
      [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
      $r = Invoke-WebRequest -Uri $cfg.url -Method Post -Body $Json -Headers $headers -UseBasicParsing -TimeoutSec 30
      if ($r.StatusCode -ge 200 -and $r.StatusCode -lt 300) {
        $script:LastSendError = ''
        Write-YcLog ('webhook ' + $r.StatusCode + ' ' + $cfg.url) 'OK'
        return $true
      }
      $bd = ''
      try { $bd = (ConvertTo-YcText $r.Content); $bd = ($bd -replace '\s+',' ').Trim() } catch {}
      $script:LastSendError = ('HTTP ' + $r.StatusCode + ' ' + $bd).Trim()
    } catch {
      $code = ''; $body = ''
      try { if ($_.Exception.Response) { $code = 'HTTP ' + [int]$_.Exception.Response.StatusCode + ' ' } } catch {}
      # READ THE BODY. The server almost always says exactly what is wrong - "Invalid secret",
      # "missing type" - and the first version of this threw that away and reported a bare
      # "HTTP 401". That cost a real misdiagnosis: a stale secret was read as a broken endpoint
      # and reported to the customer as their fault. The answer was in the response all along.
      # $_.ErrorDetails.Message FIRST. PowerShell 5.1 has already read and disposed the
      # response stream by the time the ErrorRecord reaches us, so GetResponseStream()
      # returns nothing - which is why the first attempt at this fix changed nothing at all.
      # PowerShell keeps the body here instead. The stream read stays as a fallback for the
      # cases where it is still readable.
      try { if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $body = ($_.ErrorDetails.Message -replace '\s+',' ').Trim() } } catch {}
      if (-not $body) {
        try {
          $rs = $_.Exception.Response
          if ($rs) {
            $st = $rs.GetResponseStream()
            if ($st -and $st.CanRead) {
              if ($st.CanSeek) { [void]$st.Seek(0, 'Begin') }
              $rd = New-Object IO.StreamReader($st)
              $body = ($rd.ReadToEnd() -replace '\s+',' ').Trim()
              $rd.Close()
            }
          }
        } catch {}
      }
      $script:LastSendError = ($code + $(if ($body) { $body } else { ($_.Exception.Message -replace '\s+',' ') })).Trim()
    }
    if ($i -lt $Attempts) { Start-Sleep -Seconds 5 }
  }
  Write-YcLog ('webhook FAILED after ' + $Attempts + ' attempts: ' + $script:LastSendError) 'WARN'
  return $false
}

function Send-YcNtfy {
  # The alarm channel. It is deliberately NOT the same transport as the webhook, so the
  # one that is up can tell you the other one is down.
  param([string]$Line,[string]$Title = '',[string]$Priority = '',[string]$Tags = '',[switch]$KeepLines)
  # Off by default: a configured URL is not permission to post.
  if (-not $cfg.ntfy) { return $false }
  if (-not $cfg.ntfyEnabled) { return $false }
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    # Headers, not body markup: ntfy reads Title, Priority and Tags as headers, and a phone
    # uses all three before anybody opens the message. Priority 5 is what gets past Do Not
    # Disturb, so it is reserved for a run that did not complete.
    $h = @{ Title = $(if ($Title) { ConvertTo-YcAscii $Title } else { 'YC ' + $env:COMPUTERNAME }) }
    if ($Priority) { $h['Priority'] = $Priority }
    if ($Tags)     { $h['Tags']     = (ConvertTo-YcAscii $Tags) }
    $body = $(if ($KeepLines) { ConvertTo-YcAscii -Text $Line -KeepLines } else { ConvertTo-YcAscii $Line })
    Invoke-RestMethod -Uri $cfg.ntfy -Method Post -Body $body -ContentType 'text/plain' `
      -Headers $h -TimeoutSec 30 | Out-Null
    return $true
  } catch {
    Write-YcLog ('ntfy post failed: ' + ($_.Exception.Message -replace '\s+',' ')) 'WARN'
    return $false
  }
}

function Send-YcExtra {
  <# Optional second webhook. Best effort: one try, no queue, never changes the result of the
     ERP delivery, and the event it posts has no passwords (Get-YcExtraBody). #>
  param([System.Collections.IDictionary]$Body)
  if (-not ($cfg.extraUrl -and $cfg.extraSecret)) { return }
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $j = ([pscustomobject](Get-YcExtraBody -Body $Body)) | ConvertTo-Json -Depth 5 -Compress
    $r = Invoke-WebRequest -Uri $cfg.extraUrl -Method Post -Body $j -UseBasicParsing -TimeoutSec 15 `
           -Headers @{ 'X-Webhook-Secret' = $cfg.extraSecret; 'Content-Type' = 'application/json' }
    Write-YcLog ('extra webhook ' + $r.StatusCode + ' ' + $cfg.extraUrl) 'OK'
  } catch { Write-YcLog ('extra webhook failed (ignored): ' + $_.Exception.Message) 'WARN' }
}

function Publish-YcEvent {
  <# One event, both channels, and a queue entry if the webhook did not take it. #>
  param([hashtable]$Body, [string]$NtfyLine, [string]$NtfyTitle = '', [string]$NtfyPriority = '', [string]$NtfyTags = '', [switch]$NtfyKeepLines)
  $Body['delivery'] = Get-YcDeliveryBlock
  $json = ([pscustomobject]$Body) | ConvertTo-Json -Depth 5 -Compress
  $okWeb = Send-YcWebhook -Json $json
  Send-YcExtra -Body $Body
  if (-not $okWeb -and -not $NoQueue) {
    try {
      Add-Content -LiteralPath $QueueFile -Value $json -Encoding ascii
      [void](Set-YcQueue -Lines (Get-YcQueue))
      Write-YcLog ('event queued for retry (' + (Get-YcQueue).Count + ' waiting) in ' + $QueueFile) 'WARN'
    } catch { Write-YcLog ('could not queue the event: ' + $_.Exception.Message) 'ERROR' }
  }
  $okNtfy = $false
  if ($NtfyLine) {
    $line = $NtfyLine
    if (-not $okWeb) { $line = $line + ' WEBHOOK-FAILED ' + $script:LastSendError }
    $okNtfy = Send-YcNtfy -Line $line -Title $NtfyTitle -Priority $NtfyPriority -Tags $NtfyTags -KeepLines:$NtfyKeepLines
  }
  if (-not $okWeb -and -not $okNtfy) {
    # Both doors shut. Say it somewhere that survives, so the box is not silent about
    # being silent.
    Write-YcLog ('BOTH CHANNELS FAILED. The event is on disk only: ' + $QueueFile + '. Last error: ' + $script:LastSendError) 'ERROR'
    try { Write-EventLog -LogName Application -Source YALLACLOUD -EntryType Warning -EventId 1602 -Message ('[yc-event] undelivered: ' + $json) -ErrorAction SilentlyContinue } catch {}
  }
  return $okWeb
}

function Invoke-YcDrain {
  $q = Get-YcQueue
  if ($q.Count -eq 0) { Write-YcLog 'queue is empty, nothing to drain.' 'INFO'; return $true }
  Write-YcLog ('draining ' + $q.Count + ' queued event(s)...') 'INFO'
  $left = @(); $sent = 0
  foreach ($line in $q) {
    if (Send-YcWebhook -Json $line -Attempts 1) { $sent++ } else { $left += $line }
  }
  [void](Set-YcQueue -Lines $left)
  Write-YcLog ('drained ' + $sent + ', still queued ' + $left.Count) $(if ($left.Count) { 'WARN' } else { 'OK' })
  return ($left.Count -eq 0)
}

# -------------------------------------------------------------------------------------
# what the caller asked for
# -------------------------------------------------------------------------------------
$facts = Get-YcFacts

if ($Report) {
  Write-YcLog ('--- what this VM knows about itself --- last updated ' + (Get-YcDubaiTime) + ' ---') 'INFO'
  foreach ($k in ($facts.Keys | Sort-Object)) { Write-YcLog ('  ' + $k.PadRight(16) + ' = ' + $facts[$k]) 'INFO' }
  Write-YcLog ('  webhook          = ' + $(if ($cfg.url) { $cfg.url } else { 'NOT CONFIGURED' })) 'INFO'
  Write-YcLog ('  auth             = ' + $(if ($cfg.token) { 'bearer token' } elseif ($cfg.secret) { 'X-Webhook-Secret' } else { 'NONE - webhook is off' })) 'INFO'
  Write-YcLog ('  ntfy             = ' + $(if ($cfg.ntfy) { $cfg.ntfy } else { 'NOT CONFIGURED' }) +
               '   ' + $(if ($cfg.ntfyEnabled) { 'ENABLED' } else { 'DISABLED (default)' })) 'INFO'
  Write-YcLog ('  extra webhook    = ' + $(if ($cfg.extraUrl -and $cfg.extraSecret) { $cfg.extraUrl + '  (X-Webhook-Secret set, no passwords sent)' } else { 'off' })) 'INFO'
  Write-YcLog ('  queued           = ' + (Get-YcQueue).Count) 'INFO'
  Write-YcLog 'nothing was sent.' 'INFO'
  Exit-Yc 0 ('vmId ' + $facts['vmId'] + ' via ' + $facts['identitySource'])
}

if ($Drain -and -not $Type -and -not $Test) {
  if (Invoke-YcDrain) { Exit-Yc 0 'queue drained' } else { Exit-Yc 1 ('queue not fully drained: ' + $script:LastSendError) 'WARN' }
}

if ($Test) { $Type = 'webhook.test' }
if (-not $Type) { Write-Output $HelpText; Exit-Yc 2 'nothing to do: pass -Type, -Test, -Report, -Drain or a -Set option.' 'ERROR' }

# Drain first so events arrive in the order they happened, not the order they succeeded.
if ((Get-YcQueue).Count -gt 0) { [void](Invoke-YcDrain) }

$body = [ordered]@{
  type       = $Type
  vmId       = [string]$facts['vmId']
  smbiosUuid = [string]$facts['smbiosUuid']
  # vmIdMismatch true means the virtual router answered about a different VM on this run, so
  # every router-supplied field here (offering, zone, publicIp, cloud) is suspect and routerVmId
  # is what it claimed. On a non-KVM hypervisor routerVmId may be the real CloudStack id - see
  # Resolve-YcIdentity. Receivers should match on smbiosUuid first and vmId second.
  vmIdMismatch = [bool]$facts['vmIdMismatch']
  routerVmId   = [string]$facts['routerVmId']
  cloud      = [string]$facts['cloud']
  zone       = [string]$facts['zone']
  hostname   = [string]$facts['hostname']
  ip         = [string]$facts['ip']
  publicIp   = [string]$facts['publicIp']
  offering   = [string]$facts['offering']
  identitySource = [string]$facts['identitySource']
  os         = [string]$facts['os']
  osVersion  = [string]$facts['osVersion']
  winStatus  = [string]$facts['winStatus']
  winChannel = [string]$facts['winChannel']
  winLicensed= [bool]$facts['winLicensed']
  sqlEdition = [string]$facts['sqlEdition']
  sqlVersion = [string]$facts['sqlVersion']
  sqlPatch      = [string]$facts['sqlPatch']         # RTM / SP1 / SP2 / SP3
  sqlUpdateLevel= [string]$facts['sqlUpdateLevel']   # CU15 etc - the only unit on 2017+
  sqlUpdateKb   = [string]$facts['sqlUpdateKb']
  sqlServicing  = [string]$facts['sqlServicing']     # the human-readable one
  sqlLicensed= [bool]$facts['sqlLicensed']
  sqlKeyLast5 = (Get-YcSqlKeyForBody -Facts $facts)  # held back until SQL actually exists
  winKeyLast5 = [string]$facts['winKeyLast5']        # slmgr Partial Product Key
  winTrial         = $facts['winTrial']
  winTrialDaysLeft = (Get-YcTrialDaysForBody -InTrial $facts['winTrial'] -Days $facts['winTrialDaysLeft'])
  sqlTrial         = $facts['sqlTrial']
  sqlTrialDaysLeft = (Get-YcTrialDaysForBody -InTrial $facts['sqlTrial'] -Days $facts['sqlTrialDaysLeft'])  # Evaluation is 180 days from install
  saPassword  = [string]$facts['saPassword']
  vmPassword  = [string]$facts['vmPassword']
  ssms       = [string]$facts['ssms']
  payload    = [string]$facts['payload']
  catalogue  = [string]$facts['catalogue']
  freeGb     = $facts['freeGb']
  utc         = (Get-Date).ToUniversalTime().ToString('s') + 'Z'
  lastUpdated = Get-YcDubaiTime          # same moment, Dubai wall-clock, for humans
}
if ($Step)       { $body['steps']      = $Step }
if ($FailedStep) { $body['failedStep'] = $FailedStep }
if ($ErrorText)  { $body['error']      = $ErrorText }
if ($Extra)      { $body['extra']      = $Extra }
# -Field name=value, repeatable. New things to report need no schema change on either side.
if ($Field.Count) {
  $fo = [ordered]@{}
  foreach ($kv in $Field) {
    $i = $kv.IndexOf('=')
    if ($i -gt 0) { $fo[$kv.Substring(0, $i)] = $kv.Substring($i + 1) }
    else { Write-YcLog ('ignoring -Field "' + $kv + '" - no = in it') 'WARN' }
  }
  if ($fo.Count) { $body['fields'] = $fo }
}

$ntfy = ('YC ' + $Type + ' ' + $facts['hostname'] + ' ' + $facts['ip'] +
         $(if ($facts['sqlEdition']) { ' SQL ' + $facts['sqlEdition'] } else { '' }) +
         $(if ($facts['winStatus'])  { ' WIN ' + $facts['winStatus'] + ' ' + $facts['winChannel'] } else { '' }) +
         $(if ($FailedStep) { ' FAILED-AT ' + $FailedStep } else { '' }) +
         $(if ($ErrorText)  { ' ERR ' + $ErrorText } else { '' }) +
         $(if ($Step)       { ' STEPS ' + $Step } else { '' }))

# A caller that passed -NtfyLine has composed its own summary and knows how it went; use it,
# with its title, priority and tags. Everything else keeps the single generic line it always had.
if ($NtfyLine.Count) { $ntfy = ($NtfyLine -join "`n") }
$ok = Publish-YcEvent -Body $body -NtfyLine $ntfy `
        -NtfyTitle $NtfyTitle -NtfyPriority $NtfyPriority -NtfyTags $NtfyTags `
        -NtfyKeepLines:([bool]$NtfyLine.Count)

if ($Test) {
  Write-YcLog ('-Test result: ' + $(if ($ok) { 'DELIVERED' } else { 'NOT DELIVERED - ' + $script:LastSendError })) $(if ($ok) { 'OK' } else { 'ERROR' })
}
if ($ok) { Exit-Yc 0 ($Type + ' delivered for vmId ' + $facts['vmId']) }
Exit-Yc 1 ($Type + ' NOT delivered (' + $script:LastSendError + '); queued in ' + $QueueFile + ' and it will be retried on the next yc-event run.') 'WARN'
