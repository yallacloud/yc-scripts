@echo off
rem Stamp 2026-08-19: rewritten - -ExtraTcp/-ExtraUdp were renamed to -ExtraTcpIn/-ExtraUdpIn and the
rem                  behaviour is now safe-by-default, not "the YALLACLOUD standard rule set".
rem set-firewall [-MgmtCidr <cidr,..>] [-RemoteAddress <cidr,..>] [-NoRdp] [-NoIcmp] [-NoSharing]
rem              [-Web] [-Monitoring] [-Database] [-Winrm] [-AllowPlaintextWinrm] [-EnableSharing]
rem              [-ExtraTcpIn p,p] [-ExtraUdpIn p,p] [-IncludePublicProfile] [-OpenOutbound]
rem              [-SkipBootRuleHardening] [-WhatIf] [-Force] [-Help]
rem
rem SAFE BY DEFAULT - this is NOT the old 'YALLACLOUD standard firewall rule set'.
rem With NO arguments it opens ONLY: RDP TCP 3389, SSH TCP 3222 and ICMPv4 echo, on the Domain and
rem Private profiles ONLY, scoped to -MgmtCidr (default LocalSubnet). Nothing else is opened.
rem
rem Everything else is OPT-IN, and most of it REFUSES to run until you pass an explicit -MgmtCidr
rem ('LocalSubnet' does not count as explicit): -Database (1433,1443,1521,3306,5432), -Monitoring
rem (exporter/agent ports + SNMP), -EnableSharing (SMB 445,137-139) and -AllowPlaintextWinrm all
rem require a real CIDR. -Winrm opens 5986 (HTTPS) scoped to -MgmtCidr. -Web opens 80,443,8080,8443
rem scoped to -RemoteAddress, which defaults to Any because web ports are usually meant to be public.
rem A world-open database port is refused outright and -Force does NOT override that.
rem
rem RENAMED: -ExtraTcp / -ExtraUdp are now -ExtraTcpIn / -ExtraUdpIn. The old names throw a
rem positional-parameter error before any logging starts, so there is no log and no event.
rem
rem LOCKOUT GUARD: if any connected interface is on the Public profile and -IncludePublicProfile was
rem not passed, nothing is changed and the exit code is 2.
rem
rem EXIT CODES: 0 ok, 2 refused (unsafe/missing arguments, lockout guard), 3 one or more rules failed,
rem             5 not elevated.  Logs to C:\Scripts\set-firewall.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Set-Firewall.ps1" %*
exit /b %ERRORLEVEL%
