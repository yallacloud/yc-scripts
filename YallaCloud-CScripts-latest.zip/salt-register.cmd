@echo off
rem salt-register -Master <ip|host> [-MinionId <name>] [-MasterPort 4506] [-StartDelayed|-NoStart]
rem               [-InstallDir <d>] [-CustomConfig <f>] [-Reinstall] [-Setup <exe>] [-KeepConfig]
rem               [-Config 'k: v',..] [-Grains '<yaml>'] [-KeyWaitSec 120] [-NoFirewall] [-Help]
rem Silent install + configure the Salt Minion (egress-only). Proves the minion is Running and
rem that its key reached the master before reporting success. Logs to C:\Scripts\salt-register.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Salt-Register.ps1" %*
exit /b %ERRORLEVEL%
