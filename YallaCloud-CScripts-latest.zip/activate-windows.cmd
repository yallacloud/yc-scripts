@echo off
rem Stamp 2026-08-29: v2.3 - -Edition defaults to ServerStandard, GLPI off by default.
rem activate-windows -ProductKey <GVLK-or-MAK> [-Edition ServerStandard|ServerDatacenter]
rem                  [-KMS <host[:port]>] [-GlpiUpdate] [-Help]
rem
rem DEFAULTS: -Edition defaults to ServerStandard (ServerDatacenter on a Datacenter evaluation
rem image, where forcing Standard would make dism fail). GLPI is OFF unless -GlpiUpdate is given.
rem So this is enough:   activate-windows -ProductKey XXXXX-XXXXX-XXXXX-XXXXX-XXXXX
rem
rem Windows Server 2012R2-2025. Prints the FULL current licence state (OS, edition, Evaluation vs
rem full, activated or not, channel: Volume/KMS/MAK/Retail/OEM), activates, then prints the full
rem state AGAIN and VERIFIES the licence actually took - it does not claim success from an exit code.
rem
rem -ProductKey must be 5 groups of 5 A-Z/0-9 separated by hyphens. -ProductKey, -Edition and -KMS
rem are strictly validated: values containing shell metacharacters are REJECTED, not executed, and
rem only the last 5 characters of the key are ever logged.
rem -GlpiUpdate pushes a GLPI inventory. GLPI is off by default and is never prompted for, so an
rem unattended first-boot run cannot block on it. -NoGlpi still works but is now redundant.
rem
rem If the OS is EVALUATION this is a ONE-WAY edition change that needs a REBOOT. The edition change
rem uses the PUBLISHED GVLK for this build - dism /Set-Edition refuses a MAK or retail key with
rem 0x8a010101 - and -ProductKey is installed for real afterwards. A startup scheduled task running as
rem SYSTEM re-runs the script after that reboot, so a headless VM finishes on its own; this run exits 3.
rem
rem 0xC004D302 means the trusted licensing store was rearmed, NOT that the key or the network is bad.
rem The script rebuilds the store (tokens.dat/cache.dat MOVED to a .bak, never deleted) and retries once.
rem
rem EXIT CODES: 0 Licensed, 1 bad or missing -ProductKey/-KMS/-Edition (or help), 2 activation was
rem             attempted but the status is still not Licensed, 3 Evaluation edition change staged -
rem             REBOOT required, 4 0xC004D302 licensing store rearmed and survived a rebuild,
rem             5 not elevated, 6 REFUSED - the requested edition is not one this image can be
rem             changed to (an edition change only ever goes UP; Datacenter can never become
rem             Standard). Nothing is changed and the key is not used.
rem             Logs to C:\Scripts\activate-windows.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Activate-Windows.ps1" %*
exit /b %ERRORLEVEL%
