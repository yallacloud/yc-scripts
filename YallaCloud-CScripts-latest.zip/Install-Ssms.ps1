param(
  [ValidateSet('auto','22','21','20')]
  [string]$SsmsVersion = 'auto',
  [string]$PackageId   = 'sql-server-management-studio',
  [int]$TimeoutMinutes = 45,
  [switch]$NoDotNet,
  [switch]$Force,
  [switch]$SelfCheck,
  [switch]$Help
)
# =====================================================================================
# Install-Ssms.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
#
# WHY THIS EXISTS
# ---------------
# SSMS was only reachable through Install-Sql.ps1 PHASE 7, which means "give me a
# management studio on this box" forced a full SQL Server install. This is the same
# capability behind its own entry point. It does NOT re-implement the download: the
# Chocolatey feed already carries the current package, verified live on the fleet:
#     sql-server-management-studio|22.9.2   (SSMS 22, current)
#     sql-server-management-studio|21.6.17  (SSMS 21)
#     sql-server-management-studio|20.2.37  (SSMS 20, last standalone installer)
#
# THE ONE RULE THAT MATTERS
# -------------------------
# SSMS 21 and 22 document support for Windows Server 2025 / 2022 / 2019 ONLY. Windows
# Server 2016 is NOT on that list and the installer refuses with exit 8010. So -auto
# picks SSMS 22 on build >= 17763 (2019+) and pins SSMS 20 on anything older. This is
# the same gate Install-Sql.ps1 applies; it is repeated here so the two cannot drift
# into disagreeing about the same machine.
#
# SUCCESS IS PROVEN, NOT ASSUMED
# ------------------------------
# The Chocolatey package wraps a Visual Studio Installer bundle (21/22) or an MSI-style
# bootstrapper (20). Both have been observed returning 0 while installing nothing, so
# the exit code is recorded but is NOT the verdict: the run only reports success when
# Ssms.exe is actually found on disk afterwards.
#
# THE PREREQUISITE THAT ACTUALLY BITES
# ------------------------------------
# Proven on the fleet 2026-09-02, not guessed. On Server 2016 the Chocolatey package
# downloads and checksums fine (472.88 MB, hashes match) and then SSMS-Setup-ENU.exe
# exits 1 with, in its own bundle log:
#     .NET Framework 4.7.2 (or greater) is not detected on this machine.
#     Error 0x81f40001: Bundle condition evaluated to false: NETFRAMEWORK45 >= "461808"
# Stock Server 2016 ships .NET 4.6.2 (Release 394802) and Server 2019 ships 4.7.2
# (461814), so:
#     SSMS 20      needs Release >= 461808 (.NET 4.7.2)  -> 2016 fails
#     SSMS 21 / 22 need Release >= 528040 (.NET 4.8)     -> 2016 AND 2019 fail
# This script therefore checks the .NET release BEFORE spending 472 MB on a download that
# cannot succeed, hands the install to Install-DotNet.ps1 (one owner for the Release table
# and the netfx package name), and stops with exit 8 so the host can be rebooted - .NET 4.8
# always requires one - then re-run.
#
# Exit codes: 0 verified, 1 install or verify failed, 2 usage, 3 Chocolatey missing,
#             4 .NET too old and -NoDotNet was passed, 5 not elevated, 6 no internet,
#             7 installer said OK but Ssms.exe is absent, 8 .NET 4.8 installed - reboot
#             and re-run.
# Log: C:\Scripts\install-ssms.log
# =====================================================================================

. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'install-ssms'
$ErrorActionPreference = 'Stop'

$HelpText = @"
Install-Ssms.ps1 - install SQL Server Management Studio and prove Ssms.exe exists.

  install-ssms                          auto: SSMS 22 on 2019+, SSMS 20 on 2016
  install-ssms -SsmsVersion 20          force SSMS 20 (last standalone installer)
  install-ssms -SsmsVersion 22
  install-ssms -Force                   reinstall even if SSMS is already present
  install-ssms -NoDotNet                refuse instead of calling install-dotnet first
  install-ssms -SelfCheck               run the built-in assertions, change nothing
  install-ssms -Help

Notes
  Chocolatey supplies the package. It is already on the golden image; if it is
  missing this exits 3 rather than bootstrapping a package manager behind your back.
  Windows Server 2016 cannot run SSMS 21 or 22 - the installer returns 8010.
  A reboot is sometimes required (installer exit 3010/1641); this is reported, not hidden.
  .NET: SSMS 20 needs 4.7.2 (Release 461808), SSMS 21/22 need 4.8 (Release 528040).
  Stock 2016 has 4.6.2 and stock 2019 has 4.7.2, so both need .NET 4.8 for SSMS 22.
  Too low? this calls install-dotnet and exits 8; reboot, then run install-ssms again.

Exit codes: 0 verified, 1 failed, 2 usage, 3 no Chocolatey, 4 .NET too old (-NoDotNet),
            5 not elevated, 6 no internet, 7 installed but Ssms.exe not found,
            8 .NET 4.8 installed - reboot and re-run.
Log: C:\Scripts\install-ssms.log
"@

if ($Help) { Write-Host $HelpText; Stop-YcLog 0; exit 0 }

$script:YcExit = 0

# Version floors for the two pinned fallbacks. SSMS 22 floats to whatever the feed
# calls current; 21 and 20 are pinned because they are end-of-line and a "latest"
# on those lines is not a moving target we want.
$PinnedVersion = @{ '21' = '21.6.17'; '20' = '20.2.37' }

# Minimum "Release" value under NDP\v4\Full that each SSMS line refuses below.
# 461808 = .NET 4.7.2, 528040 = .NET 4.8. These are Microsoft's published Release keys.
$DotNetMin = @{ '22' = 528040; '21' = 528040; '20' = 461808 }

function Get-YcSsmsPath {
  foreach ($p in @(
    'C:\Program Files\Microsoft SQL Server Management Studio*\Release\Common7\IDE\Ssms.exe',
    'C:\Program Files (x86)\Microsoft SQL Server Management Studio*\Common7\IDE\Ssms.exe',
    'C:\Program Files\Microsoft SQL Server Management Studio*\Common7\IDE\Ssms.exe')) {
    $hit = Get-Item $p -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($hit) { return $hit.FullName }
  }
  return $null
}

function Get-YcDotNetRelease {
  $v = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release -ErrorAction SilentlyContinue
  if ($v) { return [int]$v.Release }
  return 0
}

function Get-YcSsmsTarget {
  param([int]$Build)
  # 17763 = Windows Server 2019. Anything below it is 2016 or older.
  if ($Build -ge 17763) { return '22' }
  return '20'
}

function Invoke-YcSelfCheck {
  $fail = 0
  function T($name, $cond) {
    if ($cond) { Write-YcLog ("SELFCHECK OK   " + $name) 'OK' }
    else       { Write-YcLog ("SELFCHECK FAIL " + $name) 'ERROR'; $script:scFail++ }
  }
  $script:scFail = 0
  T 'Server 2016 (14393) selects SSMS 20'   ((Get-YcSsmsTarget -Build 14393) -eq '20')
  T 'Server 2019 (17763) selects SSMS 22'   ((Get-YcSsmsTarget -Build 17763) -eq '22')
  T 'Server 2022 (20348) selects SSMS 22'   ((Get-YcSsmsTarget -Build 20348) -eq '22')
  T 'Server 2025 (26100) selects SSMS 22'   ((Get-YcSsmsTarget -Build 26100) -eq '22')
  T 'SSMS 21 is pinned'                     ($PinnedVersion['21'] -eq '21.6.17')
  T 'SSMS 20 is pinned'                     ($PinnedVersion['20'] -eq '20.2.37')
  T 'SSMS 22 is not pinned (floats)'        (-not $PinnedVersion.ContainsKey('22'))
  T 'Get-YcSsmsPath returns null or a path' ($true)
  T 'choco.exe resolvable'                  ([bool](Get-Command choco.exe -ErrorAction SilentlyContinue))
  T 'SSMS 20 requires .NET 4.7.2 (461808)'  ($DotNetMin['20'] -eq 461808)
  T 'SSMS 22 requires .NET 4.8 (528040)'    ($DotNetMin['22'] -eq 528040)
  T 'stock 2016 .NET 4.6.2 fails SSMS 20'   (394802 -lt $DotNetMin['20'])
  T 'stock 2019 .NET 4.7.2 fails SSMS 22'   (461814 -lt $DotNetMin['22'])
  T '2022 .NET 4.8 passes SSMS 22'          (528449 -ge $DotNetMin['22'])
  T 'this host reports a .NET release'      ((Get-YcDotNetRelease) -gt 0)
  Write-YcLog ("SELFCHECK: " + (15 - $script:scFail) + "/15 passed.") $(if ($script:scFail) { 'ERROR' } else { 'OK' })
  return $script:scFail
}

function Invoke-Main {
  if ($SelfCheck) {
    $script:YcExit = if ((Invoke-YcSelfCheck) -eq 0) { 0 } else { 1 }
    return
  }

  Assert-YcPrereqs -NeedAdmin -NeedInternet -BoundParameters $PSBoundParameters

  $os       = Get-CimInstance Win32_OperatingSystem
  $build    = [int]$os.BuildNumber
  $existing = Get-YcSsmsPath

  if ($existing -and -not $Force) {
    Write-YcLog ('SSMS is already installed: ' + $existing + ' - nothing to do. Use -Force to reinstall.') 'OK'
    $script:YcExit = 0; return
  }

  $want = $SsmsVersion
  if ($want -eq 'auto') {
    $want = Get-YcSsmsTarget -Build $build
    Write-YcLog ('SSMS version auto-selected for ' + $os.Caption + ' (build ' + $build + '): SSMS ' + $want + '.')
  }

  if ($want -in @('21','22') -and $build -lt 17763) {
    Write-YcLog ('SSMS ' + $want + ' does not support ' + $os.Caption + '. The installer returns 8010 on ' +
      'this build. Re-run with -SsmsVersion 20.') 'ERROR'
    $script:YcExit = 2; return
  }

  $choco = Get-Command choco.exe -ErrorAction SilentlyContinue
  if (-not $choco) {
    Write-YcLog ('Chocolatey is not installed on this host, so there is no package source for SSMS. ' +
      'It ships on the YallaCloud golden image - this box is not one, or C:\ProgramData\chocolatey ' +
      'was removed. Install Chocolatey first, then re-run.') 'ERROR'
    $script:YcExit = 3; return
  }
  Write-YcLog ('Chocolatey: ' + $choco.Source + ' version ' + (& choco.exe --version 2>&1 | Select-Object -First 1))

  # --- .NET prerequisite. Checked BEFORE the 472 MB download, because the SSMS
  # bootstrapper only discovers this after downloading and then exits 1.
  $rel  = Get-YcDotNetRelease
  $need = $DotNetMin[$want]
  Write-YcLog ('.NET Framework Release on this host: ' + $rel + ' (SSMS ' + $want + ' needs >= ' + $need + ').')
  if ($rel -lt $need) {
    if ($NoDotNet) {
      Write-YcLog ('.NET Release ' + $rel + ' is below the ' + $need + ' that SSMS ' + $want +
        ' requires, and -NoDotNet was passed. Install netfx-4.8, reboot, then re-run.') 'ERROR'
      $script:YcExit = 4; return
    }
    # Delegated to Install-DotNet.ps1 so the Release table and the netfx package name live
    # in exactly one place. That script also owns the "a reboot is mandatory" contract.
    $dnScript = Join-Path $PSScriptRoot 'Install-DotNet.ps1'
    if (-not (Test-Path -LiteralPath $dnScript)) {
      Write-YcLog ('.NET Release ' + $rel + ' is below the ' + $need + ' SSMS ' + $want +
        ' requires, and Install-DotNet.ps1 is not beside this script (' + $dnScript + '). ' +
        'Ship the full payload, or install netfx-4.8 by hand and reboot.') 'ERROR'
      $script:YcExit = 4; return
    }
    Write-YcLog ('.NET Release ' + $rel + ' is too old. Handing off to install-dotnet - .NET 4.8 ' +
      'ALWAYS needs a reboot, so SSMS is not attempted in the same run.') 'WARN'
    $dn  = Start-Process -FilePath 'powershell.exe' -Wait -PassThru -NoNewWindow -ArgumentList @(
             '-NoProfile','-ExecutionPolicy','Bypass','-File', ('"' + $dnScript + '"'))
    $dnc = [int]$dn.ExitCode
    if ($dnc -in @(0, 8)) {
      Write-YcLog ('install-dotnet finished with ' + $dnc + '. REBOOT this host, then run ' +
        'install-ssms again.') 'WARN'
      $script:YcExit = 8; return
    }
    Write-YcLog ('install-dotnet failed with exit ' + $dnc + '. SSMS cannot proceed.') 'ERROR'
    $script:YcExit = 1; return
  }

  $cargs = @('install', $PackageId, '-y', '--no-progress', '--no-color',
            ('--execution-timeout=' + ($TimeoutMinutes * 60)))
  if ($PinnedVersion.ContainsKey($want)) { $cargs += ('--version=' + $PinnedVersion[$want]) }
  if ($Force) { $cargs += '--force' }

  Write-YcLog ('Installing SSMS ' + $want + ': choco ' + ($cargs -join ' '))
  $p  = Start-Process -FilePath $choco.Source -ArgumentList $cargs -Wait -PassThru -NoNewWindow
  $rc = [int]$p.ExitCode

  switch ($rc) {
    0     { Write-YcLog 'Chocolatey returned 0.' 'OK' }
    3010  { Write-YcLog 'Chocolatey returned 3010 - installed, a reboot is required.' 'WARN' }
    1641  { Write-YcLog 'Chocolatey returned 1641 - installed, a reboot was initiated.' 'WARN' }
    8010  { Write-YcLog ('SSMS ' + $want + ' refused to install: operating system not supported ' +
                         '(8010). Re-run with -SsmsVersion 20.') 'ERROR' }
    default { Write-YcLog ('Chocolatey returned ' + $rc + '.') 'ERROR' }
  }

  # THE VERDICT. Not the exit code - the file.
  $found = Get-YcSsmsPath
  if ($found) {
    $ver = (Get-Item $found).VersionInfo.FileVersion
    Write-YcLog ('VERIFIED: SSMS ' + $ver + ' at ' + $found) 'OK'
    $script:YcExit = if ($rc -in @(0, 3010, 1641)) { 0 } else { 0 }
    if ($rc -in @(3010, 1641)) { Write-YcLog 'Reboot this host before using SSMS.' 'WARN' }
    return
  }

  if ($rc -in @(0, 3010, 1641)) {
    Write-YcLog ('Chocolatey reported success (' + $rc + ') but Ssms.exe is not on disk. ' +
      'The package wraps a Visual Studio Installer bundle that can exit 0 without installing. ' +
      'Check C:\ProgramData\chocolatey\logs\chocolatey.log.') 'ERROR'
    $script:YcExit = 7; return
  }
  Write-YcLog 'SSMS was not installed.' 'ERROR'
  $script:YcExit = 1
}

try {
  Invoke-Main | Out-Null
} catch {
  Write-YcLog ('UNHANDLED EXCEPTION: ' + $_.Exception.Message) 'ERROR'
  if ($_.ScriptStackTrace) { Write-YcLog ('at: ' + $_.ScriptStackTrace) 'ERROR' }
  $script:YcExit = 1
}

Stop-YcLog $script:YcExit
exit $script:YcExit
