@echo off
rem activate-sql - edition-upgrade a SQL Server instance and PROVE the edition changed.
rem
rem CHANGED: the old rem line omitted -GlpiUpdate / -NoGlpi, and the wrapper swallowed the
rem   script's exit code. It now propagates it, which matters because activate-sql can
rem   return 3010 (success, reboot required) as well as 0 / 1 / 2 / 5.
rem
rem   activate-sql -ProductKey <XXXXX-XXXXX-XXXXX-XXXXX-XXXXX> [-InstanceName MSSQLSERVER]
rem                [-SetupPath <setup.exe>] [-TargetEdition Standard] [-TimeoutMinutes 30]
rem                [-NoSkipRules] [-Force] [-GlpiUpdate | -NoGlpi]
rem   activate-sql -Help
rem
rem NOTE: /PID=<key> is visible in Win32_Process.CommandLine and event 4688 while setup.exe
rem   runs. There is no answer-file form of editionupgrade. Run this with no untrusted
rem   local users logged on.
rem
rem Exit codes: 0 verified, 1 failed, 2 bad key format, 5 not elevated,
rem             3010 verified but reboot required.
rem Log: C:\Scripts\activate-sql.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Activate-Sql.ps1" %*
exit /b %ERRORLEVEL%
