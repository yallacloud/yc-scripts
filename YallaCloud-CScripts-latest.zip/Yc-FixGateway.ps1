param(
  [switch]$Report,
  [switch]$Force,
  [switch]$SelfCheck,
  [switch]$Help
)
# =====================================================================================
# Yc-FixGateway.ps1 - CloudStack sometimes hands a guest x.x.x.254 as its default
# gateway when the router is actually x.x.x.1. This finds that, proves the real gateway
# answers, and moves the default route. PowerShell 5.1 only. ASCII only.
#
# WHY THIS IS DANGEROUS, AND WHAT STOPS IT BEING DANGEROUS
#   Changing a default route on a remote machine is the fastest way to lose it forever.
#   So this refuses far more than it acts:
#     1. PRIVATE IPv4 ONLY - RFC1918 (10/8, 172.16-31/12, 192.168/16). A public address
#        is never touched, on any interface, for any reason. Public gateways are not
#        subject to this bug and a wrong guess there takes a customer offline.
#     2. Only when the gateway's last octet is EXACTLY 254. Not "not 1" - exactly 254.
#     3. The candidate must ANSWER FIRST. x.x.x.1 is on the same subnet, so a ping to it
#        is direct ARP + ICMP and needs no working gateway at all. If it does not reply,
#        this changes nothing and says so. Pointing the default route at an address that
#        is not there is how you brick a VM you cannot console into.
#     4. AUTOMATIC ROLLBACK. After the swap it re-tests off-subnet reachability; if that
#        is worse than before, the original route is restored and the run reports failed.
#
# WHY IT IS NOT A "RESTART THE NETWORKING" SCRIPT
#   Restart-NetAdapter drops every connection on the box - including the SSH session
#   running this - for several seconds, and it is not needed: a route change takes effect
#   immediately. So the route is replaced in place and nothing is bounced. The adapter is
#   only reset with -Force, for the case where the stack is genuinely wedged.
#
# THE DHCP CAVEAT, STATED PLAINLY
#   If the NIC takes its address from DHCP, the DHCP server will hand out .254 again at
#   the next lease renewal and undo this. That is why the fix is idempotent and cheap to
#   re-run, and why the userdata runs it at every boot. THE REAL FIX IS IN CLOUDSTACK -
#   this is a workaround for a bug, not a configuration choice.
#
# EXIT CODES
#   0 nothing needed, or fixed and verified      1 a fix failed and was rolled back
#   2 usage                                      5 not elevated
#
# Log: C:\Scripts\yc-fixgateway.log, plus the Application event log, source YALLACLOUD.
# =====================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'yc-fixgateway'
$ErrorActionPreference = 'Stop'

$HelpText = @"
yc-fixgateway - move a private default gateway off the CloudStack .254 bug onto .1.

USAGE
  fix-gateway -Report     what it WOULD do. Changes nothing. Safe on production.
  fix-gateway             detect and rectify
  fix-gateway -Force      also reset the adapter afterwards (drops connections briefly)
  fix-gateway -SelfCheck  assertions only, no admin, changes nothing
  fix-gateway -Help

WHAT IT WILL NOT DO
  Touch a PUBLIC address. Ever. Only RFC1918 private ranges are considered.
  Act on a gateway that is not exactly .254.
  Move the route to an address that does not answer - it pings the candidate first.
  Leave you stranded - if off-subnet reachability is worse after the change, the
  original route is restored automatically.

DHCP: a DHCP renewal will re-apply the bad gateway. This is idempotent, so re-running it
is free, and the userdata runs it at every boot. The permanent fix belongs in CloudStack.
"@
if ($Help) { Write-Output $HelpText; Exit-Yc 0 }

# -------------------------------------------------------------------------------------
# The pure decisions. These are the ones that can take a machine off the network, so they
# are separated from anything that touches the box and are what -SelfCheck exercises.
# -------------------------------------------------------------------------------------
function Test-YcPrivateIPv4 {
  # RFC1918 only. Not link-local, not loopback, not CGNAT, not public.
  param([string]$Ip)
  if ($Ip -notmatch '^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$') { return $false }
  $o = @([int]$Matches[1], [int]$Matches[2], [int]$Matches[3], [int]$Matches[4])
  foreach ($n in $o) { if ($n -gt 255) { return $false } }
  if ($o[0] -eq 10) { return $true }
  if ($o[0] -eq 172 -and $o[1] -ge 16 -and $o[1] -le 31) { return $true }
  if ($o[0] -eq 192 -and $o[1] -eq 168) { return $true }
  return $false
}

function Get-YcGatewayFix {
  <#
    Given an interface's IP and its current gateway, return the address to move to, or
    '' for "leave it alone". Every refusal is deliberate:
      - public address anywhere in the pair -> not our bug, not our business
      - gateway not exactly .254            -> nothing to fix
      - gateway not on the host's /24       -> a routed setup we do not understand
  #>
  param([string]$Ip, [string]$Gateway)
  if (-not (Test-YcPrivateIPv4 $Ip))      { return '' }
  if (-not (Test-YcPrivateIPv4 $Gateway)) { return '' }
  if ($Gateway -notmatch '^(\d+\.\d+\.\d+)\.254$') { return '' }
  $prefix = $Matches[1]
  if ($Ip -notlike ($prefix + '.*')) { return '' }
  return ($prefix + '.1')
}

# -------------------------------------------------------------------------------------
# -SelfCheck
# -------------------------------------------------------------------------------------
if ($SelfCheck) {
  $pass = 0; $fail = 0
  function T($n, $c) { if ($c) { Write-Output ('ok   ' + $n); $script:pass++ } else { Write-Output ('FAIL ' + $n); $script:fail++ } }

  T 'private 10.x'              (Test-YcPrivateIPv4 '10.10.100.50')
  T 'private 172.16'            (Test-YcPrivateIPv4 '172.16.10.3')
  T 'private 172.31'            (Test-YcPrivateIPv4 '172.31.255.254')
  T 'PUBLIC 172.15 is not'      (-not (Test-YcPrivateIPv4 '172.15.0.1'))
  T 'PUBLIC 172.32 is not'      (-not (Test-YcPrivateIPv4 '172.32.0.1'))
  T 'private 192.168'           (Test-YcPrivateIPv4 '192.168.1.10')
  T 'PUBLIC 93.177 is not'      (-not (Test-YcPrivateIPv4 '93.177.125.221'))
  T 'PUBLIC 151.248 is not'     (-not (Test-YcPrivateIPv4 '151.248.103.140'))
  T 'link-local is not private' (-not (Test-YcPrivateIPv4 '169.254.1.1'))
  T 'loopback is not private'   (-not (Test-YcPrivateIPv4 '127.0.0.1'))
  T 'garbage is not private'    (-not (Test-YcPrivateIPv4 'not-an-ip'))
  T 'out of range octet'        (-not (Test-YcPrivateIPv4 '10.300.1.1'))

  T 'the bug is fixed'          ((Get-YcGatewayFix '10.10.100.50' '10.10.100.254') -eq '10.10.100.1')
  T '192.168 bug is fixed'      ((Get-YcGatewayFix '192.168.5.20' '192.168.5.254')  -eq '192.168.5.1')
  T 'already .1 is left alone'  ((Get-YcGatewayFix '10.10.100.50' '10.10.100.1')    -eq '')
  T '.253 is NOT touched'       ((Get-YcGatewayFix '10.10.100.50' '10.10.100.253')  -eq '')
  T '.25 is NOT touched'        ((Get-YcGatewayFix '10.10.100.50' '10.10.100.25')   -eq '')
  # the one that matters most
  T 'PUBLIC ip is never touched'   ((Get-YcGatewayFix '93.177.125.221' '93.177.125.254') -eq '')
  T 'PUBLIC gw is never touched'   ((Get-YcGatewayFix '10.10.100.50'   '151.248.103.254') -eq '')
  T 'off-subnet gw is left alone'  ((Get-YcGatewayFix '10.10.100.50'   '10.10.99.254')   -eq '')
  T 'empty input is safe'          ((Get-YcGatewayFix '' '') -eq '')

  Write-Output ''
  Write-Output ('SelfCheck: ' + $pass + ' passed, ' + $fail + ' failed')
  if ($fail -gt 0) { Exit-Yc 1 'SelfCheck FAILED' } else { Exit-Yc 0 'SelfCheck: all checks passed' }
}

Write-YcInvocation
if (-not $Report -and -not (Test-YcAdmin)) { Exit-Yc 5 'Administrator is required to change a route.' 'ERROR' }

# -------------------------------------------------------------------------------------
# look at what is actually configured
# -------------------------------------------------------------------------------------
function Test-YcOffSubnet {
  # Can this box reach anything through its gateway? Two targets so one dead resolver
  # does not read as a broken route.
  foreach ($t in @('8.8.8.8', '1.1.1.1')) {
    try { if (Test-Connection -ComputerName $t -Count 1 -Quiet -ErrorAction Stop) { return $true } } catch {}
  }
  return $false
}

$acted = 0; $failed = 0; $looked = 0
$beforeOk = Test-YcOffSubnet
Write-YcLog ('off-subnet reachability before: ' + $(if ($beforeOk) { 'OK' } else { 'DOWN' })) 'INFO'

foreach ($cfg in @(Get-NetIPConfiguration -ErrorAction SilentlyContinue)) {
  $gw = $null
  try { $gw = ($cfg.IPv4DefaultGateway | Select-Object -First 1).NextHop } catch {}
  $ip = $null
  try { $ip = ($cfg.IPv4Address | Select-Object -First 1).IPAddress } catch {}
  if (-not $gw -or -not $ip) { continue }
  $looked++
  $name = $cfg.InterfaceAlias
  $want = Get-YcGatewayFix -Ip $ip -Gateway $gw

  if (-not $want) {
    $why = if (-not (Test-YcPrivateIPv4 $ip)) { 'public address - never touched' }
           elseif ($gw -notmatch '\.254$')    { 'gateway is not .254 - nothing to fix' }
           else                               { 'gateway is not on this host subnet' }
    Write-YcLog ($name + ': ' + $ip + ' via ' + $gw + ' - leaving alone (' + $why + ').') 'INFO'
    continue
  }

  Write-YcLog ($name + ': ' + $ip + ' via ' + $gw + ' - this is the CloudStack .254 bug, candidate ' + $want + '.') 'WARN'

  # The candidate is on our own subnet, so this is ARP + ICMP and needs no working
  # gateway. If it does not answer, we do NOT know it is a router, and we stop.
  $alive = $false
  try { $alive = Test-Connection -ComputerName $want -Count 2 -Quiet -ErrorAction Stop } catch { $alive = $false }
  if (-not $alive) {
    Write-YcLog ($name + ': ' + $want + ' does not answer. NOT changing the route - a default gateway that is not there is worse than a wrong one.') 'ERROR'
    $failed++
    continue
  }
  Write-YcLog ($name + ': ' + $want + ' answers. It is a live host on this subnet.') 'OK'

  if ($Report) { Write-YcLog ($name + ': WOULD move the default route ' + $gw + ' -> ' + $want + '.') 'INFO'; $acted++; continue }

  try {
    Remove-NetRoute -DestinationPrefix '0.0.0.0/0' -InterfaceIndex $cfg.InterfaceIndex -NextHop $gw -Confirm:$false -ErrorAction Stop
    New-NetRoute    -DestinationPrefix '0.0.0.0/0' -InterfaceIndex $cfg.InterfaceIndex -NextHop $want -ErrorAction Stop | Out-Null
    Start-Sleep -Seconds 3
    $afterOk = Test-YcOffSubnet
    if ($beforeOk -and -not $afterOk) {
      # It was working and now it is not. Put it back and say so - do not "wait and see".
      Remove-NetRoute -DestinationPrefix '0.0.0.0/0' -InterfaceIndex $cfg.InterfaceIndex -NextHop $want -Confirm:$false -ErrorAction SilentlyContinue
      New-NetRoute    -DestinationPrefix '0.0.0.0/0' -InterfaceIndex $cfg.InterfaceIndex -NextHop $gw   -ErrorAction SilentlyContinue | Out-Null
      Write-YcLog ($name + ': reachability was OK before and BROKEN after. Original gateway ' + $gw + ' restored.') 'ERROR'
      $failed++
      continue
    }
    Write-YcLog ($name + ': default route moved ' + $gw + ' -> ' + $want + '. Off-subnet ' + $(if ($afterOk) { 'OK' } else { 'still down (it was down before too)' }) + '.') 'OK'
    $acted++
  } catch {
    Write-YcLog ($name + ': could not change the route - ' + ($_.Exception.Message -replace '\s+',' ')) 'ERROR'
    $failed++
  }
}

if ($Force -and $acted -gt 0 -and -not $Report) {
  Write-YcLog 'resetting adapters because -Force was given. Every connection on this box drops for a few seconds.' 'WARN'
  foreach ($a in @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })) {
    try { Restart-NetAdapter -Name $a.Name -Confirm:$false -ErrorAction Stop; Write-YcLog ('reset ' + $a.Name) 'OK' }
    catch { Write-YcLog ('could not reset ' + $a.Name + ': ' + $_.Exception.Message) 'WARN' }
  }
  Start-Sleep -Seconds 8
}

$msg = ('interfaces with a gateway ' + $looked + ', ' + $(if ($Report) { 'would change ' } else { 'changed ' }) + $acted + ', refused/failed ' + $failed)
if ($failed -gt 0) { Exit-Yc 1 $msg 'ERROR' }
if ($acted -gt 0 -and -not $Report) {
  Write-YcLog 'REMINDER: a DHCP renewal will re-apply the bad gateway. This is idempotent - run it again, or let the boot task do it. The permanent fix is in CloudStack.' 'WARN'
}
Exit-Yc 0 $msg
