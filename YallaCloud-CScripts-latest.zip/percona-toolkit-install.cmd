@echo off
rem percona-toolkit-install [-InstallDir <path>] [-Help]
rem Stage Percona Toolkit (MySQL/MariaDB, Perl/Linux - NOT native Windows). Logs to C:\Scripts\percona-toolkit-install.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Percona-Toolkit-Install.ps1" %*
