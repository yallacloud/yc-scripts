# yc-keyguard.ps1 - THE ONLY ENFORCED THING ON THE IMAGE.
#
# Ports may be closed, services stopped, accounts disabled - all of that is the
# administrator's call and nothing here undoes it. But the sshd public key must
# survive, because it is the last way back in when everything else is shut.
#
# Guarantees: C:\ProgramData\ssh\administrators_authorized_keys
#   - exists and is NOT empty (restored from the backup baked ON THIS CLONE if wiped)
#   - is ACL'd to Administrators + SYSTEM ONLY. OpenSSH refuses a key file that
#     other principals can write; v259 shipped it with Authenticated Users:(RX),
#     which sshd tolerated but is not the documented requirement.
#
# WHAT CHANGED (2026-08-16 audit P0-2) AND WHY
#   The bake used to be "if there is no backup, make one" - and the first machine that
#   ever ran was the BUILD VM, so the builder's own public key was copied to the hidden
#   C:\Scripts\.authorized_keys.baked, doseal deleted neither file, and every clone
#   shipped with the builder authorized. Worse, this script restored that key within the
#   hour whenever the tenant deleted it: the customer could not revoke SSH access to
#   their own VM. Now the bake is gated three ways:
#     1. never on the build VM (C:\Scripts\.goldenimage present),
#     2. only after a non-empty DEPLOY-TIME key has been seen on this clone, which is
#        what writes C:\Scripts\.provisioned,
#     3. the marker is keyed to this machine's SID, so a .provisioned/.baked pair that
#        somehow survived sealing is recognised as another machine's and discarded
#        instead of being restored (belt and braces behind doseal's deletes).
#   Restores therefore only ever replay a key that belonged to THIS clone.
#
# WHAT CHANGED (2026-08-19) AND WHY
#   Added the EXIT CODES section (0, 1) that this script never had, derived from the four
#   Stop-YcLog 0 / exit 0 paths and the single Stop-YcLog 1 / exit 1 path below.
#
# Runs as SYSTEM from the YC-KeyGuard task at boot and hourly: no prompts, no admin
# check, idempotent, re-entrant. PowerShell 5.1 only, ASCII only.
# Key material is NEVER passed to Write-YcLog (the library mirrors it into the
# Application event log) - only file sizes and line counts are logged.
param([switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'yc-keyguard'
if($Help){
@"
yc-keyguard  -  keep sshd administrators_authorized_keys present, non-empty and correctly ACL'd.
USAGE:
  yc-keyguard
  yc-keyguard -Help
PARAMETERS:
  -Help  Show this help and exit.
EXAMPLES:
  yc-keyguard
  yc-keyguard -Help
EXIT CODES:
  0   Nothing needed enforcing, or it was enforced. Covers all four green paths: this is the
      build VM and the bake artefacts were cleared; a non-empty key exists and its ACL is
      Administrators + SYSTEM only; the key was restored from this clone's baked backup and
      re-ACL'd; or the key is missing/empty with no backup baked on this clone, so there is
      nothing to enforce (logged WARN).
  1   authorized_keys was still missing or empty after the restore attempt - the last way back
      in is NOT in place. ERROR logged.
Log: C:\Scripts\yc-keyguard.log
"@ | Write-Host -ForegroundColor Cyan; Stop-YcLog 0; exit 0
}

$ErrorActionPreference = 'SilentlyContinue'
$ak = 'C:\ProgramData\ssh\administrators_authorized_keys'
$bk = 'C:\Scripts\.authorized_keys.baked'
$pm = 'C:\Scripts\.provisioned'
$gi = 'C:\Scripts\.goldenimage'

# Machine identity that sysprep /generalize is guaranteed to change: the local account
# domain SID. Not secret, and only used for equality tests - never logged in full.
function Get-YcMachineId{
    try{
        $u = Get-CimInstance Win32_UserAccount -Filter "LocalAccount=true" -ErrorAction Stop | Select-Object -First 1
        if($u -and $u.SID){
            $s = New-Object System.Security.Principal.SecurityIdentifier($u.SID)
            if($s.AccountDomainSid){ return $s.AccountDomainSid.Value }
            return [string]$u.SID
        }
    }catch{}
    try{
        $g = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name 'MachineGuid' -ErrorAction Stop).MachineGuid
        if($g){ return ('GUID-' + $g) }
    }catch{}
    return ('HOST-' + $env:COMPUTERNAME)
}

function Set-YcKeyAcl([string]$Path){
    # ACL: Administrators + SYSTEM only, inheritance off.
    $acl  = Get-Acl $Path
    if(-not $acl){ return }
    $need = $acl.Access | Where-Object { $_.IdentityReference -notmatch 'BUILTIN\\Administrators|NT AUTHORITY\\SYSTEM' }
    if($need -or -not $acl.AreAccessRulesProtected){
        & icacls $Path /inheritance:r 2>&1 | Out-Null
        & icacls $Path /grant 'BUILTIN\Administrators:F' 'NT AUTHORITY\SYSTEM:F' 2>&1 | Out-Null
        foreach($p in 'NT AUTHORITY\Authenticated Users','BUILTIN\Users','Everyone'){ & icacls $Path /remove $p 2>&1 | Out-Null }
        Write-YcLog 'ACL tightened to Administrators + SYSTEM' 'OK'
    }
}

$id     = Get-YcMachineId
$keyOk  = (Test-Path $ak) -and ((Get-Item $ak).Length -gt 0)

# ---- build VM: never bake anything, and leave nothing behind to seal ---------
if(Test-Path $gi){
    Write-YcLog 'build VM (.goldenimage present) - backup/restore disabled so the builder key cannot ship' 'WARN'
    foreach($f in @($bk,$pm)){
        if(Test-Path $f){
            & attrib -h -s -r $f 2>&1 | Out-Null
            Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue
            Write-YcLog ('removed build-VM artefact ' + (Split-Path $f -Leaf)) 'OK'
        }
    }
    if($keyOk){ Set-YcKeyAcl $ak }
    Stop-YcLog 0
    exit 0
}

# ---- discard a provisioning marker that came from another machine ------------
if(Test-Path $pm){
    $pmId = (('' + (Get-Content -Path $pm -TotalCount 1 -ErrorAction SilentlyContinue))).Trim()
    if($pmId -ne $id){
        Write-YcLog 'provisioning marker was written on another machine (image leftover) - discarding it and the baked backup' 'WARN'
        foreach($f in @($pm,$bk)){
            if(Test-Path $f){
                & attrib -h -s -r $f 2>&1 | Out-Null
                Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue
            }
        }
    }
}

if($keyOk){
    # A non-empty key exists on this clone: this is the deploy-time key, so record it.
    if(-not (Test-Path $pm)){
        Set-Content -Path $pm -Value $id -Encoding ascii -Force
        Write-YcLog 'deploy-time authorized_keys seen - provisioning marker written' 'OK'
    }
    # Bake only behind that marker, so the builder key can never become the backup.
    if((Test-Path $pm) -and -not (Test-Path $bk)){
        Copy-Item $ak $bk -Force
        (Get-Item $bk).Attributes = 'Hidden'
        $n = @(Get-Content -Path $ak -ErrorAction SilentlyContinue | Where-Object { $_.Trim() -ne '' }).Count
        Write-YcLog ('baked backup created for this clone (' + $n + ' key line(s), ' + (Get-Item $bk).Length + ' bytes)') 'OK'
    }
}elseif((Test-Path $bk) -and (Test-Path $pm)){
    New-Item -ItemType Directory -Force 'C:\ProgramData\ssh' | Out-Null
    Copy-Item $bk $ak -Force
    Write-YcLog 'authorized_keys was MISSING/EMPTY - restored from this clone baked backup' 'WARN'
    $keyOk = (Test-Path $ak) -and ((Get-Item $ak).Length -gt 0)
}else{
    Write-YcLog 'authorized_keys missing/empty and no backup baked on this clone - nothing to enforce' 'WARN'
    Stop-YcLog 0
    exit 0
}

if($keyOk){
    Set-YcKeyAcl $ak
}else{
    Write-YcLog 'authorized_keys still missing/empty after restore attempt' 'ERROR'
    Stop-YcLog 1
    exit 1
}

Stop-YcLog 0
exit 0
