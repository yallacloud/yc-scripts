@echo off
rem salt-join [-Report] [-Status] [-Help]
rem Join this guest to the YallaCloud Salt master - zero input (STACK4-54 s17). Starts the
rem one-line join in the background; result via salt-join -Status. Logs to C:\Scripts\salt-join.log
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Salt-Join.ps1" %*
exit /b %ERRORLEVEL%
