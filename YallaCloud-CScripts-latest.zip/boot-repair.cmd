@echo off
rem Stamp 2026-08-19: rewritten against the real param block; adds -DryRun/-UpdateNvram/-EspLetter.
rem boot-repair [-Boot] [-FileSystem] [-Full] [-ScheduleChkdsk] [-Reboot] [-DryRun]
rem             [-FixMbr] [-UpdateNvram] [-EspLetter <L>] [-Force] [-Help]
rem
rem With NO arguments this is READ-ONLY: it scans and reports the disk layout, the BCD entries and
rem chkdsk /scan. Nothing is written. -DryRun is the safest first run: layout report only.
rem
rem -Boot           repair the boot loader on the SYSTEM disk only (auto-detects UEFI vs BIOS).
rem                 The BCD is exported to C:\Scripts\bcd-backup-<ts> and the ESP boot directory to
rem                 C:\Scripts\esp-backup-<ts> FIRST; the restore commands are printed and logged.
rem -FileSystem     chkdsk /scan + sfc /scannow + DISM /RestoreHealth. Implies -ScheduleChkdsk.
rem -Full           -Boot plus -FileSystem.
rem -ScheduleChkdsk schedule 'chkdsk /f /r' on the system volume for the next reboot.
rem -Reboot         reboot 15s after the work finishes (needed for a scheduled chkdsk to run).
rem -UpdateNvram    UEFI only: also (re)create the firmware NVRAM boot entry. Off by default.
rem -EspLetter <L>  preferred free letter to temporarily mount the ESP on. S: is never assumed.
rem -Force          proceed with -Boot even if the bcdedit /export backup could not be taken.
rem -FixMbr         requests MBR / boot-sector repair. This CANNOT be done from a booted Windows
rem                 Server - bootrec.exe exists only in WinRE/WinPE. The command reports the exact
rem                 error and the recovery-ISO steps instead of pretending it worked.
rem
rem EXIT CODES: 0 success, 1 failure (nothing was left half-written), 5 not elevated.
rem Logs to C:\Scripts\boot-repair.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Boot-Repair.ps1" %*
exit /b %ERRORLEVEL%
