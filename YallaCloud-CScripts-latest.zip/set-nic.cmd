@echo off
rem Stamp 2026-08-19: rewritten against the real param block; documents the -Commit requirement.
rem set-nic [-List] [-Rescan] [-CleanGhosts] [-Name <name|MAC|auto>] [-DHCP]
rem         [-IP <a.b.c.d>] [-Prefix <1-32>] [-Gateway <a.b.c.d>] [-DNS s1,s2]
rem         [-Commit] [-Rollback] [-RollbackMinutes <1-1440>] [-NoRollbackGuard]
rem         [-WhatIf] [-Force] [-Help]
rem
rem DEAD-MAN'S SWITCH - READ THIS. An address change (static OR -DHCP) arms a scheduled task that
rem SELF-REVERTS the NIC to the snapshot taken before the change after -RollbackMinutes minutes
rem (DEFAULT 5). The change is only permanent once you reconnect on the NEW address and confirm it:
rem
rem     set-nic -Commit
rem
rem -Commit cancels the pending YC-SetNic-Rollback task. Without it, the change disappears and the
rem old configuration comes back - that is deliberate, it is what stops you locking yourself out.
rem Use -RollbackMinutes to widen the window, -Rollback to revert immediately, and -NoRollbackGuard
rem (console/local sessions ONLY) to skip arming the task at all.
rem
rem -Gateway must be inside IP/Prefix - that is checked with real bitmask arithmetic.
rem -WhatIf prints the current config, the intended config and every step, and changes nothing.
rem
rem EXIT CODES: 0 ok, 1 the change failed and was rolled back, 2 refused (invalid or unsafe
rem             arguments), 5 not elevated.  Logs to C:\Scripts\set-nic.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Set-Nic.ps1" %*
exit /b %ERRORLEVEL%
