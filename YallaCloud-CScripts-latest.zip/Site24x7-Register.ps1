param(
  # ---- names preserved from site24x7-register.cmd and the catalog ----
  [string]$DeviceKey,
  [string]$Name,
  [switch]$Help,
  # ---- ADDED in this revision ----
  [string]$DeviceKeyFile,       # read the device key from a FILE instead of the command line
  [string]$MsiPath,             # explicit Site24x7 agent MSI
  [int]$VerifySec = 300,        # how long to wait for registration evidence on disk
  [switch]$Force                # re-run the MSI even if the agent service already exists
)
# =====================================================================================
# Site24x7-Register.ps1 - SILENT install + registration of the Site24x7 Windows agent.
# OUTBOUND 443 ONLY. PowerShell 5.1, ASCII only, unattended (cloud-init / SYSTEM / RMM).
#
# 2026-08-19: repaired. Added the library guard + Exit-Yc on every path (three bare exits, no
#             Stop-YcLog); msiexec now runs through Invoke-YcInstaller so its exit code is
#             captured, decoded, timed and rejected when it returns too fast to have done
#             anything; the agent service must EXIST and reach Running; the agent's own
#             configuration directory and registry hive are read back as registration
#             evidence; and the Site24x7 collector endpoint is proven reachable. Added
#             -DeviceKeyFile, -MsiPath, -VerifySec and -Force.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P0] IT EXITED WITH THE INSTALLER'S CODE AND VERIFIED NOTHING.
#   Old lines 31-33:
#     $p = Start-Process msiexec.exe -ArgumentList $a -Wait -PassThru
#     Write-Host ("Site24x7 msiexec exit: " + $p.ExitCode)
#     exit $p.ExitCode
#   $p.ExitCode was captured and never compared. No service was checked, the device key was
#   never validated, and a package that exited 0 after rejecting the property list produced
#   exactly the same output as a successful registration. This agent is the thing that is
#   supposed to TELL you the VM is down; a silent failure here means nobody is watching.
#   NOW: Invoke-YcInstaller decodes the exit code (including 1638 "already installed" and
#   1639 "the installer rejected a switch"), enforces a timeout AND a 10-second minimum
#   plausible duration - this MSI registers with the Site24x7 cloud during install, so a
#   4-second success is the Acronis signature and is reported as a failure. Then the agent
#   service must reach Running, its configuration directory must be populated, its registry
#   hive must exist, and plus.site24x7.com:443 must be reachable.
#
# [P1] THE DEVICE KEY.
#   The device key is the credential that binds this host to your Site24x7 account. It is now
#   read from -DeviceKeyFile or the YC_SITE24X7_DEVICE_KEY environment variable in preference
#   to the command line, it is never passed to Write-YcLog (only a masked form is logged), and
#   the transcript is scrubbed by the library.
#   RESIDUAL RISK, DISCLOSED: Site24x7 offers NO file-based or environment-based alternative
#   to the EDITA1 MSI property, so the key MUST appear on the msiexec command line for the
#   duration of the install. That window is unavoidable with this vendor; it is visible in the
#   process table and in 4688 command-line audit events. Rotate the device key if the host is
#   shared. This script does not make it worse: it never writes the key to the log or the
#   event log, and it does not leave it in a file of its own.
#
# [P1] AUTOMATION=TRUE IS DELIBERATELY NOT PASSED.
#   The documented AUTOMATION=TRUE property enables Site24x7 IT Automation, which lets the
#   Site24x7 console execute commands on this host. A golden-image command should not silently
#   grant remote execution; enable it from the console if you want it.
#
# [P1] NO FIREWALL RULE IS CREATED.
#   The agent is outbound 443 only (plus.site24x7.com and its DR peers, plus dms.zoho.com for
#   the device messaging service). Nothing listens, so there is no inbound rule to make.
#
# VENDOR VERIFICATION - every property below is documented:
#   Command-line install, EDITA1 (device key), ENABLESILENT=YES, REBOOT=ReallySuppress,
#   DN (display name), AUTOMATION, TP/RP/NP/GN/RULE, and /qn:
#     https://www.site24x7.com/help/admin/adding-a-monitor/command-line-installation.html
#   Bulk/silent install variant and the proxy properties:
#     https://www.site24x7.com/help/admin/adding-a-monitor/bulk-installation-for-windows.html
#   Service names ("Site24x7 Windows Agent", "Site24x7 Agent Helper", "Site24x7 APP
#   Monitoring Agent", "Site24x7 Plugin Agent"), the install directory
#   C:\Program Files (x86)\Site24x7\WinAgent, the <install dir>\monitoring\conf location where
#   the device key and performance data are stored, the registry hive
#   HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\ManageEngine, and outbound port 443 to
#   plus.site24x7.com / plus2 / plus3 / logu.site24x7.com / dms.zoho.com:
#     https://www.site24x7.com/help/admin/server-monitor/server-agent-documentation.html
#   Windows Installer standard options (/i, /qn, /l*v, REBOOT=ReallySuppress):
#     https://learn.microsoft.com/en-us/windows/win32/msi/standard-installer-command-line-options
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was installed. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'site24x7-register'

$MsiLog      = 'C:\Scripts\site24x7-msi.log'
$SvcDisplay  = 'Site24x7 Windows Agent'
$OtherSvcs   = @('Site24x7 Agent Helper','Site24x7 APP Monitoring Agent','Site24x7 Plugin Agent')
$InstallDirs = @('C:\Program Files (x86)\Site24x7\WinAgent','C:\Program Files\Site24x7\WinAgent')
$RegHive     = 'HKLM:\SOFTWARE\WOW6432Node\ManageEngine'
$Collector   = 'plus.site24x7.com'

$Usage = @'
site24x7-register  -  SILENT install + registration of the Site24x7 Windows monitoring agent.
                      OUTBOUND 443 ONLY: nothing listens and no firewall rule is created.
                      Staged installer: C:\Scripts\Site24x7*Agent*.msi

GET THE KEY: Site24x7 console > Server > (+) add a Windows server monitor; copy the Device Key.

USAGE:
  site24x7-register -DeviceKeyFile C:\Scripts\site24x7.key [-Name <display-name>]
  site24x7-register -DeviceKey <YOUR_DEVICE_KEY> [-Name <display-name>]
  site24x7-register -DeviceKeyFile <file> [-MsiPath <msi>] [-VerifySec 300] [-Force]
  site24x7-register -Help

PARAMETERS:
  -DeviceKey      Site24x7 device key (MSI property EDITA1). PREFER -DeviceKeyFile or the
                  YC_SITE24X7_DEVICE_KEY environment variable.
  -DeviceKeyFile  File containing the device key. The file is read and the key is passed to
                  msiexec; it is never written to the log or the event log.
  -Name           Display name for the monitor (MSI property DN). Defaults to the vendor's own
                  default, which is the host name.
  -MsiPath        Explicit MSI. Default: the newest C:\Scripts\Site24x7*Agent*.msi.
  -VerifySec      How long to wait for registration evidence on disk (default 300). The agent
                  contacts the Site24x7 cloud during and after install.
  -Force          Re-run the MSI even if the agent service already exists. Required to
                  re-point an installed agent at a different device key.
  -Help           Show this help and exit.

SECURITY - READ THIS ABOUT THE DEVICE KEY:
  Site24x7 provides no file-based or environment-based alternative to the EDITA1 property, so
  the key is unavoidably on the msiexec command line while the install runs, where it is
  visible in the process table and in 4688 audit events. -DeviceKeyFile at least keeps it off
  THIS command's line and out of the shell history. Only a masked form of the key is ever
  logged. AUTOMATION=TRUE (remote command execution from the Site24x7 console) is deliberately
  NOT enabled by this command.

PROOF OF SUCCESS (nothing below is assumed):
  msiexec exit code captured and decoded, with a 10-second minimum plausible duration
  + the "Site24x7 Windows Agent" service EXISTS and reaches Running
  + the install directory and its monitoring\conf directory are present AND populated - that
    is where the vendor stores the device key and the collected performance data
  + the HKLM\SOFTWARE\WOW6432Node\ManageEngine registry hive exists
  + plus.site24x7.com:443 is reachable, so the agent can report in.
  LIMITATION, STATED PLAINLY: confirming the monitor server-side needs a Site24x7 API OAuth
  credential, which this command deliberately does not take. Everything provable without one
  is proved here; finish by confirming the monitor appears in the console.

EXAMPLES:
  site24x7-register -DeviceKeyFile C:\Scripts\site24x7.key
  site24x7-register -DeviceKeyFile C:\Scripts\site24x7.key -Name web01
  $env:YC_SITE24X7_DEVICE_KEY='us_...'; site24x7-register -Name web01
  site24x7-register -DeviceKey us_0123456789abcdef -Force
  site24x7-register -Help

EXIT CODES:
  0   the agent is installed, its service is Running and registration evidence is present
  1   generic failure
  2   usage error (no device key, unreadable -DeviceKeyFile, bad -VerifySec)
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4   the Site24x7 MSI is missing or too small, or the install directory is absent afterwards
  5   not running as Administrator
  7   the Site24x7 Windows Agent service does not exist or did not reach Running
  8   registration could not be proven (no configuration written, or the collector is
      unreachable)
  10  msiexec did not exit within its timeout and was killed
  <n> any other value is msiexec's own exit code

Log: C:\Scripts\site24x7-register.log   MSI log: C:\Scripts\site24x7-msi.log
     (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

# ------------------------------------------------------------------------------------
# Resolve the device key without ever printing it.
# ------------------------------------------------------------------------------------
$key = ''
if($DeviceKeyFile){
  if(-not (Test-Path -LiteralPath $DeviceKeyFile)){
    Write-Host $Usage -ForegroundColor Cyan
    Exit-Yc 2 ('-DeviceKeyFile not found: ' + $DeviceKeyFile + '. Nothing was installed.') 'ERROR'
  }
  $keyRaw = $null
  # Get-Content -Raw returns $null for an EMPTY file, and [string]$null is $null, not '' - so
  # calling .Trim() straight off the pipeline throws instead of reporting "the file is empty".
  try{ $keyRaw = Get-Content -LiteralPath $DeviceKeyFile -Raw -ErrorAction Stop }
  catch{ Exit-Yc 2 ('-DeviceKeyFile could not be read: ' + $_.Exception.Message) 'ERROR' }
  if($null -eq $keyRaw){ $keyRaw = '' }
  $key = ([string]$keyRaw).Trim()
  if(-not $key){ Exit-Yc 2 ('-DeviceKeyFile is empty: ' + $DeviceKeyFile) 'ERROR' }
  Write-YcLog ('device key read from ' + $DeviceKeyFile)
}elseif($DeviceKey){
  $key = $DeviceKey.Trim()
  Write-YcLog 'the device key was passed on the command line, so it is in this host''s process table and 4688 audit trail. Prefer -DeviceKeyFile or YC_SITE24X7_DEVICE_KEY.' 'WARN'
}elseif($env:YC_SITE24X7_DEVICE_KEY){
  $key = ([string]$env:YC_SITE24X7_DEVICE_KEY).Trim()
  Write-YcLog 'device key taken from the YC_SITE24X7_DEVICE_KEY environment variable (it is not on this command line - good)'
}

if(-not $key){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 'a device key is required. Pass -DeviceKeyFile, -DeviceKey, or set YC_SITE24X7_DEVICE_KEY. Nothing was installed.' 'ERROR'
}
if($key -match '\s'){
  Exit-Yc 2 'the device key contains whitespace - it was probably read from a file with extra content. A Site24x7 device key is a single token.' 'ERROR'
}
$keyMask = Protect-YcSecret $key -Whole -Keep 4
if($VerifySec -lt 1){ Exit-Yc 2 ('-VerifySec must be at least 1, got ' + $VerifySec) 'ERROR' }

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
Write-YcLog ('registering with device key ' + $keyMask + ' (masked), monitor display name "' +
  $(if($Name){$Name}else{$env:COMPUTERNAME + ' (vendor default)'}) + '"')

function Test-YcTcpPort{
  param([string]$ComputerName,[int]$Port,[int]$TimeoutMs = 5000)
  $c = $null
  try{
    $c = New-Object System.Net.Sockets.TcpClient
    $iar = $c.BeginConnect($ComputerName,$Port,$null,$null)
    if(-not $iar.AsyncWaitHandle.WaitOne($TimeoutMs,$false)){ return $false }
    $c.EndConnect($iar)
    return $true
  }catch{
    return $false
  }finally{
    if($c){ try{ $c.Close() }catch{} }
  }
}

function Get-YcS247Service{
  $s = Get-Service -DisplayName $SvcDisplay -ErrorAction Ignore
  if($s){ return @($s)[0] }
  $all = @()
  try{ $all = @(Get-Service -ErrorAction Stop | Where-Object { $_.DisplayName -like 'Site24x7*Agent*' -and $_.DisplayName -notlike '*Helper*' -and $_.DisplayName -notlike '*Plugin*' }) }catch{}
  if($all.Count -gt 0){ return $all[0] }
  return $null
}

function Get-YcS247Dir{
  foreach($d in $InstallDirs){ if(Test-Path -LiteralPath $d){ return $d } }
  return ''
}

# ------------------------------------------------------------------------------------
# 1. Install (or deliberately skip) the MSI - with an exit code this time.
# ------------------------------------------------------------------------------------
$existingSvc = Get-YcS247Service
if($existingSvc -and -not $Force){
  Write-YcLog ('the Site24x7 agent service "' + $existingSvc.Name + '" already exists - NOT re-running the MSI. Pass -Force to reinstall or to re-point it at a different device key. Registration is still verified below.') 'WARN'
}else{
  $msi = ''
  if($MsiPath){
    $msi = $MsiPath
  }else{
    $cands = @(Get-ChildItem -Path 'C:\Scripts\Site24x7*Agent*.msi' -File -ErrorAction Ignore | Sort-Object LastWriteTime -Descending)
    if($cands.Count -gt 0){
      if($cands.Count -gt 1){ Write-YcLog ('several staged Site24x7 MSIs found - using the newest: ' + $cands[0].Name) 'WARN' }
      $msi = $cands[0].FullName
    }
  }
  if(-not $msi){
    Exit-Yc 4 'the Site24x7 agent MSI was not found (C:\Scripts\Site24x7*Agent*.msi, e.g. Site24x7WindowsAgent.msi). Stage it or pass -MsiPath. Nothing was installed.' 'ERROR'
  }
  if(-not (Assert-YcFile -Path $msi -MinBytes 1MB -Because 'Site24x7 agent MSI')){
    Exit-Yc 4 ('unusable Site24x7 agent MSI: ' + $msi) 'ERROR'
  }
  $sig = 'Unavailable'
  try{ $sig = [string](Get-AuthenticodeSignature -LiteralPath $msi -ErrorAction Stop).Status }catch{ $sig = 'Unavailable' }
  if($sig -eq 'Valid'){ Write-YcLog ('MSI Authenticode signature: Valid (' + (Split-Path -Leaf $msi) + ')') 'OK' }
  else{ Write-YcLog ('MSI Authenticode signature is ' + $sig + ' for ' + $msi + ' - continuing, but this package is not proven to be the Site24x7 build') 'WARN' }

  # The documented property order and spelling. AUTOMATION is deliberately absent.
  $a = @('/i', ('"' + $msi + '"'), ('EDITA1=' + $key), 'ENABLESILENT=YES', 'REBOOT=ReallySuppress')
  if($Name){ $a += ('DN="' + $Name + '"') }
  $a += @('/l*v', ('"' + $MsiLog + '"'), '/qn')

  # -MinSeconds 10: this MSI registers with the Site24x7 cloud while it installs. A "success"
  # that returns in four seconds installed nothing - that is precisely the Acronis signature.
  $inst = Invoke-YcInstaller -FilePath 'msiexec.exe' -ArgumentList $a -SuccessCodes @(0) -RebootCodes @(3010,1641) -TimeoutSec 1800 -MinSeconds 10
  if($inst.TimedOut){
    Exit-Yc 10 ('msiexec did not finish within its timeout and was killed - see ' + $MsiLog + '. The agent may be half-installed.') 'ERROR'
  }
  if($inst.ExitCode -eq 1638){
    Write-YcLog 'msiexec returned 1638 (another version of this product is already installed) - continuing to verify the EXISTING agent' 'WARN'
  }elseif(-not $inst.Success){
    $code = $inst.ExitCode
    if($code -eq 0){ $code = 1 }
    Exit-Yc $code ('the Site24x7 agent MSI FAILED: ' + $inst.Meaning + '. See ' + $MsiLog +
      '. This host is NOT being monitored.') 'ERROR'
  }
}

# ------------------------------------------------------------------------------------
# 2. The service must EXIST and be Running.
# ------------------------------------------------------------------------------------
$svc = Get-YcS247Service
if(-not $svc){
  Exit-Yc 7 ('the installer reported success but no "' + $SvcDisplay + '" service exists on this host. The agent is NOT installed and this VM is NOT monitored. See ' + $MsiLog + '.') 'ERROR'
}
Write-YcLog ('agent service discovered: "' + $svc.Name + '" (' + $svc.DisplayName + ')')
if(-not (Assert-YcService -Name $svc.Name -TimeoutSec 180 -State 'Running' -StartIfStopped -Because 'the Site24x7 Windows agent' -Fatal)){
  Exit-Yc 7 ('the Site24x7 agent service "' + $svc.Name + '" is not Running - no metrics are being sent.') 'ERROR'
}
foreach($d in $OtherSvcs){
  $o = Get-Service -DisplayName $d -ErrorAction Ignore
  if($o){ Write-YcLog ('companion service "' + $d + '" is ' + (@($o)[0]).Status) }
  else{ Write-YcLog ('companion service "' + $d + '" is not installed (normal for the Infra-only agent flavour)') }
}

# ------------------------------------------------------------------------------------
# 3. Registration evidence on disk. The device key and the collected data live under
#    <install dir>\monitoring\conf, so a populated conf directory is the local receipt.
# ------------------------------------------------------------------------------------
$dir = Get-YcS247Dir
if(-not $dir){
  Exit-Yc 4 ('the agent service exists but neither ' + ($InstallDirs -join ' nor ') +
    ' is present. The package did not lay its files down - see ' + $MsiLog + '.') 'ERROR'
}
Write-YcLog ('install directory: ' + $dir)

$confDir  = Join-Path $dir 'monitoring\conf'
$confCount = 0
$sw = [Diagnostics.Stopwatch]::StartNew()
while($sw.Elapsed.TotalSeconds -lt $VerifySec){
  if(Test-Path -LiteralPath $confDir){
    try{ $confCount = @(Get-ChildItem -LiteralPath $confDir -File -ErrorAction Stop).Count }catch{ $confCount = 0 }
    if($confCount -gt 0){ break }
  }
  Start-Sleep -Seconds 5
}
$reach = Test-YcTcpPort -ComputerName $Collector -Port 443
if($confCount -le 0){
  $extra = 'and ' + $Collector + ':443 IS reachable, so the agent has been started but has not written its configuration - check the device key'
  if(-not $reach){ $extra = 'and ' + $Collector + ':443 is NOT reachable from this host, so the agent could not complete registration - open outbound 443 to plus.site24x7.com, plus2.site24x7.com, plus3.site24x7.com and dms.zoho.com' }
  Exit-Yc 8 ('the agent service "' + $svc.Name + '" is Running but ' + $confDir +
    ' is empty after ' + $VerifySec + 's ' + $extra + '. Registration is NOT proven; do not assume this VM is monitored.') 'ERROR'
}
# The count only - never the contents: these files hold the device key.
Write-YcLog ('registration evidence: ' + $confDir + ' contains ' + $confCount + ' configuration file(s) (contents deliberately not read or logged)') 'OK'

if(Test-Path -LiteralPath $RegHive){
  Write-YcLog ('registry hive ' + $RegHive + ' is present, as the vendor documents for a registered agent') 'OK'
}else{
  Write-YcLog ('registry hive ' + $RegHive + ' is absent. The configuration directory is populated, so registration probably succeeded, but confirm the monitor in the Site24x7 console.') 'WARN'
}

if($reach){
  Write-YcLog ($Collector + ':443 is reachable - the agent can report in') 'OK'
}else{
  Exit-Yc 8 ('the agent is installed, "' + $svc.Name + '" is Running and its configuration is written, but ' +
    $Collector + ':443 is NOT reachable from this host. No metric will ever arrive. Open outbound 443 to plus.site24x7.com, plus2.site24x7.com, plus3.site24x7.com and dms.zoho.com.') 'ERROR'
}

Exit-Yc 0 ('Site24x7 agent installed, service "' + $svc.Name + '" Running, configuration written under ' + $dir +
  ' and ' + $Collector + ' reachable (device key ' + $keyMask + ' masked). Confirm the monitor in the Site24x7 console; server-side confirmation needs an API credential this command does not take. Outbound 443 only: no inbound port was opened.') 'OK'
