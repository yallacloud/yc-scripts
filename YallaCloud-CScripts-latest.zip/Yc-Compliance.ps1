param(
  [string]$Path,
  [string]$OutDir,
  [switch]$Fix,
  [switch]$Json,
  [switch]$Quiet,
  [switch]$PartialPayload,
  [switch]$Help
)
# Yc-Compliance.ps1 - YALLACLOUD build gate. PowerShell 5.1, ASCII only.
# Stamp: 2026-08-19 - CATALOG completeness findings now emit FAIL in full-payload mode (they were
#        hard-coded WARN, which contradicted the mode banner and let 15 advertised-but-missing
#        commands ship with exit 0). -PartialPayload still downgrades them to INFO.
#
# ======================= WHAT CHANGED AND WHY =======================
# This REPLACES _COMPLIANCE.txt, which was a stored text artifact, not a check.
#
# _COMPLIANCE.txt asked six questions per script: does the file contain the string
# Start-YcLog, does it contain Assert-YcPrereqs, does it contain USAGE / PARAMETERS /
# EXAMPLES / "Log:", are there zero bytes above 0x7F, and do the here-string openers and
# closers balance. Register-Acronis.ps1 answers YES to all six and has a 100% failure rate:
# it passes --log= to a bootstrapper that rejects the whole command line, captures the exit
# code into $p.ExitCode and never compares it, creates four firewall rules unconditionally
# on the failed path so the failure cosmetically resembles a success, prints the exit code
# in Cyan, and exits with whatever the installer returned. Not one of the six questions is
# about whether the installer ran. The report was also stale - it claimed 34 scripts when
# the payload has 51, and still certified Promtail-Register.ps1 and Zabbix-Register.ps1,
# neither of which exists.
#
# This gate keeps all six cheap checks (they cost nothing) but GENERATES them live, and adds
# the checks that would have failed Register-Acronis.ps1 on day one:
#   PARSE            every .ps1 tokenises with zero errors (PSParser::Tokenize)
#   EXIT DISCIPLINE  every 'exit' is preceded by Stop-YcLog or Exit-Yc
#   LOG LEVELS       no Write-YcLog call passes a numeric level (the 1002-as-INFO bug)
#   VERIFICATION     a script that runs an external installer must also prove it worked,
#                    AFTER the install: Assert-YcService / Get-Service / Assert-YcHttp /
#                    Assert-YcFile / a version query.   <-- this is the Acronis check
#   SIDE-EFFECT      New-NetFirewallRule / Register-ScheduledTask must be guarded by a
#                    preceding success check, not fired unconditionally
#   SECRETS          a secret-named parameter must not reach Write-YcLog / Write-Host, and
#                    is flagged when interpolated into a Start-Process argument list
#   WRAPPER          every .cmd resolves to a .ps1 that exists; orphans and unwrapped
#                    scripts are reported both ways
#   CATALOG          Yallacloud.ps1's advertised command list vs what is actually on disk
#   COMPAT           PowerShell 7-only syntax, and wmic (off by default on Server 2025)
#   TLS              a download not preceded by a TLS 1.2 assignment
#
# Files named _*.ps1 are treated as LIBRARIES: they are still checked for parse, ASCII,
# here-strings, log levels, exit discipline, secrets, TLS and compat, but they are exempt
# from the command-shaped checks (USAGE block, Start-YcLog, installer verification,
# side-effect ordering), because a library is not a command.
#
# PRECISION NOTES (added after the first full-corpus run produced five classes of false
# positive; a gate that cries wolf is a gate that gets ignored):
#   SECRET      a parameter whose name ends in File / Path / Dir / Name / Length holds a
#               LOCATION or a LENGTH, not a secret. $SqlPasswordFile / $SaPasswordFile are the
#               file hand-off this programme introduced so the value never reaches a command
#               line; logging the path is the recommended behaviour. A bare truthiness test
#               (if ($SaPassword)) and a length read ($Token.Length) are not disclosures
#               either, and a statement bracketed by Stop-Transcript / Start-Transcript shows
#               the value on the console only - that is reported as INFO, not FAIL.
#   EXITDISC    every repaired script opens with a guard that exits when _yc-lib.ps1 is
#               MISSING. That exit cannot go through Exit-Yc, because Exit-Yc is defined by
#               the file that is missing. Any bare exit ABOVE the dot-source line is that
#               guard and is not flagged; nor is a bare exit inside a function that is itself
#               the script's exit wrapper (a re-entrancy guard).
#   VERIFY      judged by "is there proof, and does some proof run after some install", not by
#               "is the single highest-numbered check below the single highest-numbered
#               install". The old ordering test broke on every multi-phase script.
#   SIDEEFFECT  only applies to a file that ALSO runs an installer. A file whose entire job is
#               creating firewall rules (set-firewall) has no install to gate on.
#   WRAPPER     %~dp0<Script>.ps1 is the relocatable form this gate itself recommends, so it
#               is resolved to its leaf rather than reported as a missing target.
#   -PartialPayload downgrades the WRAPPER / CATALOG COMPLETENESS findings to INFO, because a
#               scan of one repair wave cannot know that glpi-register.cmd exists elsewhere.
#               It does NOT weaken the default full-payload mode: there, a wrapper pointing at
#               a missing script stays a FAIL. That is how the missing Zabbix-Register.ps1 was
#               found.
#
# Exit code: 0 when there is no FAIL, 1 when there is at least one FAIL (so it gates a
# build), 2 on a usage error. Output: console summary + yc-compliance.txt + yc-compliance.json.
# ====================================================================

$ErrorActionPreference = 'Continue'

# --- bootstrap: use the shared library when it is next to us, otherwise stand alone -------
$YcLibLoaded = $false
$YcLibCandidates = @()
if($PSScriptRoot){ $YcLibCandidates += (Join-Path $PSScriptRoot '_yc-lib.ps1') }
$YcLibCandidates += 'C:\Scripts\_yc-lib.ps1'
foreach($c in $YcLibCandidates){
  if(-not $YcLibLoaded -and (Test-Path -LiteralPath $c)){
    try{ . $c; $YcLibLoaded = $true }catch{ $YcLibLoaded = $false }
  }
}
if(-not $YcLibLoaded){
  # Minimal stand-ins so the gate can run inside a build container with no payload installed.
  function Start-YcLog{ param([string]$Name,[string]$Dir,[int]$MaxLogMB,[switch]$SkipAclHarden) $script:YcTag=$Name }
  function Write-YcLog{ param([string]$Message,[string]$Level='INFO') Write-Host ("{0}  [YALLACLOUD][{1}] [{2}] {3}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'),$script:YcTag,$Level,$Message) }
  function Stop-YcLog{ param([int]$Code=0,[switch]$Unclean) Write-Host ("[YALLACLOUD][{0}] [END] exit={1}" -f $script:YcTag,$Code) }
  function Assert-YcPrereqs{ param([switch]$NeedAdmin,[switch]$SelfElevate,[switch]$NeedInternet,[string]$InternetUrl,[hashtable]$BoundParameters) }
  function Exit-Yc{ param([int]$Code=0,[string]$Message,[string]$Level) if($Message){ Write-YcLog $Message $Level }
                    Stop-YcLog $Code
                    exit $Code }
}

if(-not $Path){
  if($PSScriptRoot){ $Path = $PSScriptRoot } else { $Path = 'C:\Scripts' }
}
if(-not $OutDir){ $OutDir = $Path }

Start-YcLog 'yc-compliance'

if($Help){
@"
yc-compliance  -  YALLACLOUD build gate. Scans a folder of .ps1 / .cmd command scripts and
                  FAILS the build on the defects that let a broken command ship green.
                  Replaces the hand-maintained _COMPLIANCE.txt, which certified
                  Register-Acronis.ps1 as PASS while it installed nothing.

USAGE:
  yc-compliance [-Path <folder>] [-OutDir <folder>] [-Fix] [-Json] [-Quiet] [-PartialPayload]
  yc-compliance -Help

PARAMETERS:
  -Path    Folder of .ps1 / .cmd files to scan. Default: this script's own folder,
           falling back to C:\Scripts.
  -OutDir  Where to write yc-compliance.txt and yc-compliance.json. Default: -Path.
  -Fix     Report ONLY which findings are mechanically auto-fixable, and what the fix is.
           This switch never modifies a file; auto-fixing is deliberately not implemented,
           because every finding here is a behaviour bug, not a formatting bug.
  -Json    Also print the machine-readable JSON to stdout (it is always written to a file).
  -Quiet   Suppress the per-file table; print only the summary and the findings.
  -PartialPayload
           The scan folder holds only PART of the command payload (one repair wave, say).
           WRAPPER and CATALOG findings that depend on the payload being COMPLETE are
           reported as INFO instead of blocking, and the report says so in its header.
           Everything else is checked exactly as normal. Do NOT use this for a release
           build: a wrapper pointing at a script that is not in the payload is a P0, and
           the default mode is what catches it.
  -Help    Show this help and exit.

CHECKS (severity in brackets):
  PARSE       [FAIL] every .ps1 tokenises with zero errors
  ASCII       [FAIL] zero bytes above 0x7F
  HERESTRING  [FAIL] here-string openers and closers balance
  EXITDISC    [FAIL] every 'exit' is preceded by Stop-YcLog or Exit-Yc
  LOGLEVEL    [FAIL] no Write-YcLog call passes a numeric level (an event id is not a level)
  VERIFY      [FAIL] a script that runs an installer proves it worked, after the install
  SIDEEFFECT  [FAIL] firewall rules / scheduled tasks are guarded by a preceding success check
  SECRET      [FAIL] no secret-named parameter is written to a log or the console
  WRAPPER     [FAIL] every .cmd resolves to a .ps1 that exists
  COMPAT      [FAIL] no PowerShell 7-only syntax   [WARN] no wmic (off by default on 2025)
  TLS         [WARN] a download is preceded by a TLS 1.2 assignment
  CATALOG     [WARN] Yallacloud.ps1's command list matches what is on disk
  DOC         [WARN] USAGE / PARAMETERS / EXAMPLES / Log: present in a command script
  LOGGING     [WARN] a command script calls Start-YcLog
  PREREQ      [INFO] Assert-YcPrereqs present, and with which flags

EXIT CODES:
  0  no FAIL
  1  at least one FAIL - do not ship this payload
  2  usage error (the -Path folder does not exist)

EXAMPLES:
  yc-compliance
  yc-compliance -Path C:\build\payload -OutDir C:\build\artifacts
  yc-compliance -Path C:\build\wave3 -PartialPayload
  yc-compliance -Path C:\Scripts -Json
  yc-compliance -Fix
  yc-compliance -Help

Log: C:\Scripts\yc-compliance.log   Report: <OutDir>\yc-compliance.txt + yc-compliance.json
"@ | Write-Host -ForegroundColor Cyan
  Exit-Yc 0 'help shown' 'INFO'
}

Assert-YcPrereqs

if(-not (Test-Path -LiteralPath $Path)){
  Exit-Yc 2 ("scan folder does not exist: " + $Path) 'ERROR'
}
if(-not (Test-Path -LiteralPath $OutDir)){
  try{ New-Item -ItemType Directory -Path $OutDir -Force | Out-Null }catch{ Exit-Yc 2 ("cannot create -OutDir: " + $OutDir) 'ERROR' }
}

# ---------------------------------------------------------------------------------------
# Check tables
# ---------------------------------------------------------------------------------------
$InstallerCommands = @('start-process','invoke-ycinstaller','msiexec','msiexec.exe','msdeploy.exe','dism.exe','pkgmgr.exe')
$VerifyCommands    = @('assert-ycservice','test-ycservice','assert-ychttp','assert-ycfile','get-service','wait-ycservice','get-package')
# The Assert-Yc* / Test-Yc* / Confirm-Yc* / Wait-Yc* families are this payload's post-condition
# vocabulary, whether they come from _yc-lib.ps1 or are declared locally (Test-YcActivated,
# Assert-YcDbatoolsUsable, Assert-YcSql, Test-YcDownloadedFile). Test-Path is deliberately NOT
# in here: it is a pre-condition, not proof that an install worked.
$VerifyCmdRx       = '(?i)^((assert|test|confirm|verify|wait)-yc[a-z0-9]*|get-service|get-package|get-website|get-scheduledtask)$'
# ...but Assert-YcPrereqs / Test-YcAdmin / Test-YcInternet are PRE-conditions (am I admin, is
# there internet). They prove nothing about an install that happens afterwards, and letting
# them count would have silenced the SIDEEFFECT finding on the original Register-Acronis.ps1,
# whose Assert-YcPrereqs sits one line above the unconditional firewall rules.
$VerifyCmdExcludeRx = '(?i)^(assert-ycprereqs|test-ycadmin|test-ycinternet)$'
$VerifyTextRx      = '(?i)(--version|/version\b|-Version\b|\.ProductVersion|\.FileVersion|Get-ItemProperty[^\r\n]*DisplayVersion)'
$SideEffectCmds    = @('new-netfirewallrule','register-scheduledtask','new-scheduledtask')
$ExitCodeProofRx   = '(?i)(ExitCode\s*-(eq|ne|gt|lt|ge|le|in|notin)|-(eq|ne|gt|lt|ge|le)\s*[0-9]+\s*\)?\s*\{[^\r\n]*ExitCode|\.Success\b|\.Status\s*-eq|Invoke-YcInstaller)'
$DownloadCommands  = @('invoke-webrequest','invoke-restmethod','start-bitstransfer','get-ycfile','wget','curl')
$DownloadTextRx    = '(?i)(System\.Net\.WebClient|\.DownloadFile\(|\.DownloadString\()'
$TlsTextRx         = '(?i)(SecurityProtocol|Set-YcTls|Get-YcFile)'
$LogSinkCommands   = @('write-host','write-yclog','write-output','write-information','write-warning','write-error','out-host','echo')
$SecretNameExcludeRx = '(?i)(file|path|dir|name|length)$'
$SecretNameRx      = '(?i)(token|password|passwd|^pass$|secret|apikey|api_key|psk|community|enrollsecret|devicekey|productkey|credential|privatekey|accesskey|secretkey|oopass|ooauth|sapass|mypass|pgpass|sqlpass|^dsn$|datasourcename|licensekey|connectionstring)'

# PowerShell 7-only syntax and cmdlets that do not exist on Windows PowerShell 5.1.
$Ps7Patterns = @(
  @{ n='null-coalescing operator (??)';            rx='\?\?' },
  @{ n='null-conditional member access (?.)';      rx='\$\w+\?\.' },
  @{ n='null-conditional index (?[)';              rx='\$\w+\?\[' },
  @{ n='pipeline chain operator (&&)';             rx='(?<![&])&&(?![&])' },
  @{ n='pipeline chain operator (||)';             rx='(?<![|])\|\|(?![|])' },
  @{ n='ForEach-Object -Parallel';                 rx='(?i)ForEach-Object[^\r\n]*-Parallel' },
  @{ n='ConvertFrom-Json -AsHashtable';            rx='(?i)-AsHashtable' },
  @{ n='Invoke-WebRequest -SkipCertificateCheck';  rx='(?i)-SkipCertificateCheck' },
  @{ n='Invoke-WebRequest -SkipHttpErrorCheck';    rx='(?i)-SkipHttpErrorCheck' },
  @{ n='Get-Error (PS7 only)';                     rx='(?i)\bGet-Error\b' },
  @{ n='Join-String (PS7 only)';                   rx='(?i)\bJoin-String\b' },
  @{ n='Get-Uptime (PS7 only)';                    rx='(?i)\bGet-Uptime\b' },
  @{ n='Remove-Alias (PS7 only)';                  rx='(?i)\bRemove-Alias\b' },
  @{ n='Test-Json (PS7 only)';                     rx='(?i)\bTest-Json\b' },
  @{ n='pwsh.exe (PS7 host, not on the image)';    rx='(?i)\bpwsh(\.exe)?\b' }
)

# ---------------------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------------------
$Findings = New-Object System.Collections.ArrayList
$FileRows = New-Object System.Collections.ArrayList
$FindingKeys = @{}

function Add-Finding{
  param([string]$File,[string]$Check,[string]$Severity,[int]$Line,[string]$Message,[string]$Fix,[switch]$PayloadScoped)
  # -PayloadScoped marks a finding that is only meaningful when the WHOLE payload is on disk.
  # Under -PartialPayload those are reported as INFO so a partial scan does not manufacture a
  # blocking defect out of a file that simply was not in this wave. Nothing else is downgraded,
  # and in the default full-payload mode nothing is downgraded at all.
  if($PayloadScoped -and $PartialPayload){
    if($Severity -eq 'FAIL' -or $Severity -eq 'WARN'){
      $Severity = 'INFO'
      $Message  = $Message + '  [-PartialPayload: downgraded to INFO because only part of the payload was scanned. Re-run WITHOUT -PartialPayload over the complete payload before shipping - this is a FAIL there.]'
    }
  }
  # Deduplicate on file + check + line. Two 'exit' keywords on one line used to produce two
  # identical EXITDISC entries (Register-Acronis.ps1:25). File-scoped findings (line 0) are
  # keyed by their message instead, so the four separate DOC headings stay four findings.
  $key = ''
  if($Line -gt 0){ $key = $File + '|' + $Check + '|' + $Line }
  else           { $key = $File + '|' + $Check + '|0|' + $Message }
  if($FindingKeys.ContainsKey($key)){ return }
  $FindingKeys[$key] = $true
  $null = $Findings.Add([pscustomobject]@{
    File     = $File
    Check    = $Check
    Severity = $Severity
    Line     = $Line
    Message  = $Message
    Fixable  = [bool]$Fix
    Fix      = $Fix
  })
}

# Blanks out comment and (optionally) string tokens so a regex cannot match help text or a
# lookup table. Newlines are preserved so line numbers stay correct.
# -KeepStrings is used by the SECRETS check only: a secret is almost always interpolated
# INTO an expandable string ("--reg-token=$Token"), so blanking strings would hide exactly
# the construct that check exists to find.
# PSParser reports a whole "...$( ... )..." as ONE String token, so executable code inside a
# subexpression was blanked along with the surrounding literal text and became invisible to
# every rule in this gate. Return the character spans of the CONTENTS of each $( ... ) inside
# an EXPANDABLE string token (single-quoted and @'...'@ strings cannot contain one), so those
# spans can be kept instead of blanked, and re-tokenised for the command rules.
function Get-YcSubExprSpans{
  param([string]$Raw,$Tokens)
  $spans = New-Object System.Collections.ArrayList
  foreach($t in $Tokens){
    if($t.Type -ne 'String'){ continue }
    $s = [int]$t.Start
    $l = [int]$t.Length
    if($s -lt 0 -or $l -le 0 -or ($s + $l) -gt $Raw.Length){ continue }
    $txt = $Raw.Substring($s,$l)
    if($txt.StartsWith("'") -or $txt.StartsWith("@'")){ continue }
    $i = 0
    while($i -lt ($txt.Length - 1)){
      if($txt[$i] -eq '$' -and $txt[$i+1] -eq '(' -and ($i -eq 0 -or $txt[$i-1] -ne '`')){
        $depth = 1
        $j = $i + 2
        while($j -lt $txt.Length -and $depth -gt 0){
          if($txt[$j] -eq '('){ $depth++ }
          elseif($txt[$j] -eq ')'){ $depth-- }
          $j++
        }
        $inner = $i + 2
        $len   = ($j - 1) - $inner
        if($depth -eq 0 -and $len -gt 0){ $null = $spans.Add(@{ Start = ($s + $inner); Length = $len }) }
        $i = $j
      }else{
        $i++
      }
    }
  }
  return $spans.ToArray()
}

function Get-CodeText{
  param([string]$Raw,$Tokens,[switch]$KeepStrings)
  $sb = New-Object System.Text.StringBuilder
  $null = $sb.Append($Raw)
  # Blank the LITERAL segments of a string only. Anything inside $( ... ) is real code and is
  # left in place, otherwise the gate cannot see it.
  $keep = @(Get-YcSubExprSpans -Raw $Raw -Tokens $Tokens)
  foreach($t in $Tokens){
    if($t.Type -eq 'Comment' -or ($t.Type -eq 'String' -and -not $KeepStrings)){
      $s = [int]$t.Start
      $l = [int]$t.Length
      if($s -ge 0 -and ($s + $l) -le $sb.Length){
        for($i=$s; $i -lt ($s+$l); $i++){
          if($t.Type -eq 'String' -and $keep.Count -gt 0){
            $inKeep = $false
            foreach($k in $keep){
              if($i -ge [int]$k.Start -and $i -lt ([int]$k.Start + [int]$k.Length)){ $inKeep = $true; break }
            }
            if($inKeep){ continue }
          }
          $ch = $sb[$i]
          if($ch -ne "`r" -and $ch -ne "`n"){ $null = $sb.Replace($ch,' ',$i,1) }
        }
      }
    }
  }
  return $sb.ToString()
}

function Get-LineNumber{
  param([string]$Text,[int]$Offset)
  if($Offset -le 0){ return 1 }
  $n = 1
  $max = [Math]::Min($Offset,$Text.Length)
  for($i=0;$i -lt $max;$i++){ if($Text[$i] -eq "`n"){ $n++ } }
  return $n
}

# Top-level param() block variables only: the SCRIPT's own parameters, not a function's.
function Get-TopLevelParams{
  param($Tokens)
  $names = @()
  $depth = 0
  $inParam = $false
  $pdepth = 0
  foreach($t in $Tokens){
    if($t.Type -eq 'GroupStart'){
      if(([string]$t.Content).EndsWith('{')){ $depth++ }
      if($inParam){ $pdepth++ }
    }
    elseif($t.Type -eq 'GroupEnd'){
      if([string]$t.Content -eq '}'){ $depth-- }
      if($inParam){ $pdepth--; if($pdepth -le 0){ $inParam = $false } }
    }
    elseif($t.Type -eq 'Keyword'){
      $c = ([string]$t.Content).ToLowerInvariant()
      if($c -eq 'function' -and $depth -eq 0 -and -not $inParam){ break }   # past the script header
      if($c -eq 'param' -and $depth -eq 0 -and -not $inParam){ $inParam = $true; $pdepth = 0 }
    }
    elseif($t.Type -eq 'Variable' -and $inParam){
      $n = [string]$t.Content
      if($names -notcontains $n){ $names += $n }
    }
  }
  return $names
}

# ---------------------------------------------------------------------------------------
# Enumerate the payload
# ---------------------------------------------------------------------------------------
$ps1Files = @(Get-ChildItem -LiteralPath $Path -Filter '*.ps1' -File -ErrorAction SilentlyContinue | Sort-Object Name)
$cmdFiles = @(Get-ChildItem -LiteralPath $Path -Filter '*.cmd' -File -ErrorAction SilentlyContinue | Sort-Object Name)
Write-YcLog ("scanning " + $Path + ": " + $ps1Files.Count + " .ps1, " + $cmdFiles.Count + " .cmd")
if($ps1Files.Count -eq 0 -and $cmdFiles.Count -eq 0){
  Exit-Yc 2 ("no .ps1 or .cmd files found under " + $Path) 'ERROR'
}

$payloadVersion = 'unknown'
$manifestSha    = 'unknown'
$pv = Join-Path $Path 'yc-payload-version.txt'
if(Test-Path -LiteralPath $pv){
  try{
    foreach($l in (Get-Content -LiteralPath $pv)){
      if($l -match '^\s*payload_version\s*=\s*(\S+)'){ $payloadVersion = $Matches[1] }
      if($l -match '^\s*manifest_sha256\s*=\s*(\S+)'){ $manifestSha    = $Matches[1] }
    }
  }catch{}
}

# ---------------------------------------------------------------------------------------
# Per-.ps1 checks
# ---------------------------------------------------------------------------------------
foreach($f in $ps1Files){
  $name    = $f.Name
  $isLib   = $name.StartsWith('_')
  $bytes   = [System.IO.File]::ReadAllBytes($f.FullName)
  $nonAscii = 0
  foreach($b in $bytes){ if($b -gt 127){ $nonAscii++ } }
  $raw = [System.Text.Encoding]::ASCII.GetString($bytes)

  $row = [ordered]@{
    File        = $name
    Kind        = $(if($isLib){'library'}else{'command'})
    Bytes       = $bytes.Length
    NonAscii    = $nonAscii
    Parse       = 'ok'
    HereOpen    = 0
    HereClose   = 0
    StartYcLog  = $false
    StopOrExit  = $false
    Prereqs     = ''
    Usage       = $false
    Params      = $false
    Examples    = $false
    LogLine     = $false
    Installer   = $false
    Verified    = $false
    Result      = 'PASS'
  }

  if($nonAscii -gt 0){
    Add-Finding $name 'ASCII' 'FAIL' 0 ("$nonAscii byte(s) above 0x7F - the payload contract is pure ASCII") 'Re-save the file as ASCII; replace smart quotes and dashes with their ASCII equivalents.'
  }

  # --- PARSE ---------------------------------------------------------------------------
  $perr = $null
  $toks = $null
  try{ $toks = [System.Management.Automation.PSParser]::Tokenize($raw,[ref]$perr) }catch{ $perr = $null }
  if($null -eq $toks){
    $row.Parse = 'THREW'
    Add-Finding $name 'PARSE' 'FAIL' 0 'the tokeniser could not process this file at all' ''
  }elseif($perr -and $perr.Count -gt 0){
    $row.Parse = ("" + $perr.Count + " error(s)")
    foreach($e in $perr){
      $ln = 0
      try{ $ln = [int]$e.Token.StartLine }catch{}
      Add-Finding $name 'PARSE' 'FAIL' $ln ("syntax error: " + $e.Message) ''
    }
  }

  # --- here-strings --------------------------------------------------------------------
  # The old report counted '@"' openers against '"@' closers with a regex. That heuristic is
  # wrong in both directions on this corpus: Install-Sql.ps1 has 12 loose "openers" of which
  # 1 is a real here-string, and Day2-Setup.ps1 has 21 lines starting with '"@' against 20
  # here-strings. The tokeniser knows the truth, so count real here-string tokens; an
  # unbalanced here-string can only ever show up as a PARSE error, which is already a FAIL.
  if($null -eq $toks){
    $row.HereOpen  = ([regex]::Matches($raw,'@["'']\s*\r?\n')).Count
    $row.HereClose = ([regex]::Matches($raw,'(?m)^["'']@')).Count
    if($row.HereOpen -ne $row.HereClose){
      Add-Finding $name 'HERESTRING' 'FAIL' 0 ("here-string openers (" + $row.HereOpen + ") do not match closers (" + $row.HereClose + ") in a file that does not tokenise") 'A here-string terminator must be at column 1 of its own line.'
    }
    $row.Result = 'FAIL'
    $null = $FileRows.Add([pscustomobject]$row)
    continue
  }
  $hereCount = 0
  foreach($t in $toks){
    if($t.Type -eq 'String'){
      $s = [int]$t.Start
      if($s -ge 0 -and ($s+1) -lt $raw.Length -and $raw[$s] -eq '@'){ $hereCount++ }
    }
  }
  $row.HereOpen  = $hereCount
  $row.HereClose = $hereCount

  $code  = Get-CodeText -Raw $raw -Tokens $toks
  $codeS = Get-CodeText -Raw $raw -Tokens $toks -KeepStrings
  # Same blind spot on the command side: PSParser emits no Command token for the Remove-Item
  # in "$(Remove-Item C:\ -Recurse -Force)". Re-tokenise each subexpression and fold the result
  # into the token list so Has-Cmd / First-Line see it too.
  $subToks = New-Object System.Collections.ArrayList
  foreach($k in @(Get-YcSubExprSpans -Raw $raw -Tokens $toks)){
    $inner = $raw.Substring([int]$k.Start,[int]$k.Length)
    $serr  = $null
    $itoks = $null
    try{ $itoks = [System.Management.Automation.PSParser]::Tokenize($inner,[ref]$serr) }catch{ $itoks = $null }
    if($null -eq $itoks){ continue }
    if($serr -and $serr.Count -gt 0){ continue }
    $baseLine = Get-LineNumber -Text $raw -Offset ([int]$k.Start)
    foreach($x in $itoks){
      if($null -eq $x){ continue }
      $null = $subToks.Add([pscustomobject]@{
        Type      = $x.Type
        Content   = $x.Content
        Start     = ([int]$k.Start + [int]$x.Start)
        Length    = [int]$x.Length
        StartLine = ($baseLine + [int]$x.StartLine - 1)
      })
    }
  }
  $cmds = @(@($toks) + @($subToks.ToArray()) | Where-Object { $_.Type -eq 'Command' })
  $cmdLower = @{}
  foreach($c in $cmds){
    $k = ([string]$c.Content).ToLowerInvariant()
    if(-not $cmdLower.ContainsKey($k)){ $cmdLower[$k] = @() }
    $cmdLower[$k] += [int]$c.StartLine
  }
  function Has-Cmd{ param([string]$n) return $cmdLower.ContainsKey($n.ToLowerInvariant()) }
  function First-Line{ param([string]$n) $k=$n.ToLowerInvariant(); if($cmdLower.ContainsKey($k)){ return ($cmdLower[$k] | Sort-Object)[0] } return 0 }

  $row.StartYcLog = (Has-Cmd 'Start-YcLog')
  $row.StopOrExit = ((Has-Cmd 'Stop-YcLog') -or (Has-Cmd 'Exit-Yc'))
  $row.Usage      = ($raw -match 'USAGE')
  $row.Params     = ($raw -match 'PARAMETERS')
  $row.Examples   = ($raw -match 'EXAMPLES')
  $row.LogLine    = ($raw -match '(?m)^\s*Log:')
  if(Has-Cmd 'Assert-YcPrereqs'){
    $ln = First-Line 'Assert-YcPrereqs'
    $txt = ''
    try{ $txt = ((($raw -split "`n")[$ln-1]).Trim()) }catch{}
    if($txt -match 'Assert-YcPrereqs(.*)$'){ $row.Prereqs = ($Matches[1] -split '[;#}]')[0].Trim() }
    if(-not $row.Prereqs){ $row.Prereqs = '(no flags)' }
  }

  # --- command-shaped checks (libraries are exempt) ------------------------------------
  if(-not $isLib){
    if(-not $row.StartYcLog){
      Add-Finding $name 'LOGGING' 'WARN' 0 'no Start-YcLog: this command produces no transcript and no [YALLACLOUD] event' 'Add: . ''C:\Scripts\_yc-lib.ps1'' then Start-YcLog ''<command-name>'' after the param() block.'
    }
    if($row.StartYcLog -and -not $row.StopOrExit){
      Add-Finding $name 'LOGGING' 'FAIL' 0 'calls Start-YcLog but never Stop-YcLog or Exit-Yc: the transcript has no [END] line and no EventId 1099, so start/end pairing health checks produce a permanent false positive' 'End every path with Exit-Yc <code> ''<message>'' ''<level>''.'
    }
    if(-not (Has-Cmd 'Assert-YcPrereqs')){
      Add-Finding $name 'PREREQ' 'INFO' 0 'no Assert-YcPrereqs call' 'Add Assert-YcPrereqs -NeedAdmin (and -NeedInternet if it downloads).'
    }
    foreach($d in @(@('USAGE',$row.Usage),@('PARAMETERS',$row.Params),@('EXAMPLES',$row.Examples),@('Log:',$row.LogLine))){
      if(-not $d[1]){ Add-Finding $name 'DOC' 'WARN' 0 ("the -Help block has no " + $d[0] + " section") 'Add the missing heading to the help here-string.' }
    }
    if($raw -match '(?im)^\s*#Requires'){
      Add-Finding $name 'DOC' 'WARN' 0 '#Requires is evaluated by the parser BEFORE the first statement, so it aborts the script before Start-YcLog runs - the failure produces no log at all' 'Delete #Requires and rely on Assert-YcPrereqs -NeedAdmin, which fails with a logged message and exit 5.'
    }
  }

  # --- EXIT DISCIPLINE -----------------------------------------------------------------
  # Line on which _yc-lib.ps1 is dot-sourced. Everything above it runs BEFORE Exit-Yc exists.
  $rawLines = $raw -split "`r?`n"
  $libLine  = 0
  $libVars  = @()
  for($li=0;$li -lt $rawLines.Count;$li++){
    $RL = $rawLines[$li]
    if($RL -match '(?i)^\s*\$(\w+)\s*=\s*[^\r\n]*_yc-lib\.ps1'){
      if($libVars -notcontains $Matches[1]){ $libVars += $Matches[1] }
    }
    if($libLine -eq 0){
      if($RL -match '(?i)^\s*\.\s+[^\r\n]*_yc-lib\.ps1'){ $libLine = $li + 1 }
      else{
        foreach($lv in $libVars){
          if($RL -match ('(?i)^\s*\.\s+\$' + [regex]::Escape($lv) + '\b')){ $libLine = $li + 1; break }
        }
      }
    }
  }

  if($row.StartYcLog){
    # Map every function body and record whether that body contains Stop-YcLog / Exit-Yc.
    # A bare exit inside such a body is inside the script's own exit wrapper (Install-Sql's
    # Invoke-YcExit re-entrancy guard), not an exit that skips the transcript close.
    $fnStack  = New-Object System.Collections.ArrayList
    $fnRanges = New-Object System.Collections.ArrayList
    $pendingFn = $false
    $bd = 0
    for($i=0;$i -lt $toks.Count;$i++){
      $t = $toks[$i]
      if($t.Type -eq 'Keyword' -and ([string]$t.Content).ToLowerInvariant() -eq 'function'){ $pendingFn = $true; continue }
      if($t.Type -eq 'GroupStart' -and ([string]$t.Content).EndsWith('{')){
        if($pendingFn){ $null = $fnStack.Add(@($bd,$i)); $pendingFn = $false }
        $bd++
        continue
      }
      if($t.Type -eq 'GroupEnd' -and ([string]$t.Content) -eq '}'){
        $bd--
        if($fnStack.Count -gt 0){
          $top = $fnStack[$fnStack.Count-1]
          if([int]$top[0] -eq $bd){
            $null = $fnRanges.Add(@([int]$top[1],$i))
            $fnStack.RemoveAt($fnStack.Count-1)
          }
        }
        continue
      }
    }
    $fnGuard = @()
    foreach($fr in $fnRanges){
      $g = $false
      for($i=[int]$fr[0]; $i -le [int]$fr[1]; $i++){
        $t = $toks[$i]
        if($t.Type -eq 'Command'){
          $c = ([string]$t.Content).ToLowerInvariant()
          if($c -eq 'stop-yclog' -or $c -eq 'exit-yc'){ $g = $true; break }
        }
      }
      $fnGuard += $g
    }

    # A Stop-YcLog / Exit-Yc guards a later exit only while the block it ran in is still open.
    $guardAt = @{}
    $bd = 0
    for($i=0;$i -lt $toks.Count;$i++){
      $t = $toks[$i]
      if($t.Type -eq 'GroupStart' -and ([string]$t.Content).EndsWith('{')){ $bd++; continue }
      if($t.Type -eq 'GroupEnd' -and ([string]$t.Content) -eq '}'){
        if($guardAt.ContainsKey($bd)){ $guardAt.Remove($bd) }
        $bd--
        continue
      }
      if($t.Type -eq 'Command'){
        $c = ([string]$t.Content).ToLowerInvariant()
        if($c -eq 'stop-yclog' -or $c -eq 'exit-yc'){ $guardAt[$bd] = [int]$t.StartLine }
        continue
      }
      if($t.Type -eq 'Keyword' -and ([string]$t.Content).ToLowerInvariant() -eq 'exit'){
        $ln = [int]$t.StartLine
        # 1. the pre-dot-source library guard: Exit-Yc does not exist yet on this path.
        if($libLine -gt 0 -and $ln -lt $libLine){ continue }
        # 2. inside a function that is itself an exit wrapper.
        $inWrapper = $false
        for($k=0;$k -lt $fnRanges.Count;$k++){
          if($i -ge [int]$fnRanges[$k][0] -and $i -le [int]$fnRanges[$k][1] -and $fnGuard[$k]){ $inWrapper = $true; break }
        }
        if($inWrapper){ continue }
        # 3. a Stop-YcLog / Exit-Yc already ran in this block or an enclosing one.
        $guarded = $false
        foreach($d in $guardAt.Keys){ if([int]$d -le $bd){ $guarded = $true; break } }
        if(-not $guarded){
          Add-Finding $name 'EXITDISC' 'FAIL' $ln "bare 'exit' with no Stop-YcLog or Exit-Yc before it on this path: the transcript is left open with no [END] line and the exit code is never recorded" 'Replace with: Exit-Yc <code> ''<message>'' ''<level>''.'
        }
      }
    }
  }

  # --- LOG LEVELS ----------------------------------------------------------------------
  for($i=0;$i -lt $toks.Count;$i++){
    $t = $toks[$i]
    if($t.Type -ne 'Command'){ continue }
    if(([string]$t.Content).ToLowerInvariant() -ne 'write-yclog'){ continue }
    $depth = 0
    for($j=$i+1;$j -lt $toks.Count;$j++){
      $u = $toks[$j]
      if($u.Type -eq 'GroupStart'){ $depth++; continue }
      if($u.Type -eq 'GroupEnd'){ $depth--; if($depth -lt 0){ break }; continue }
      if($depth -eq 0 -and ($u.Type -eq 'NewLine' -or $u.Type -eq 'StatementSeparator')){ break }
      if($depth -eq 0 -and $u.Type -eq 'Number'){
        Add-Finding $name 'LOGLEVEL' 'FAIL' ([int]$u.StartLine) ("Write-YcLog is passed the numeric level " + $u.Content + ". A level is INFO/OK/WARN/ERROR; " + $u.Content + " is an EVENT ID. Under the v1 library this silently filed the message as INFO / EventId 1001, so an alert rule on EntryType=Warning never saw it.") ("Replace " + $u.Content + " with the matching level string, e.g. 1002 -> 'WARN', 1003 -> 'ERROR'.")
        break
      }
    }
  }

  # --- VERIFICATION - the Acronis check ------------------------------------------------
  $installLines = @()
  foreach($ic in $InstallerCommands){ if($cmdLower.ContainsKey($ic)){ $installLines += $cmdLower[$ic] } }
  # call operator on something that looks like an executable: & $exePath / & $installer
  for($i=0;$i -lt $toks.Count;$i++){
    $t = $toks[$i]
    if($t.Type -eq 'Operator' -and ([string]$t.Content) -eq '&' -and ($i+1) -lt $toks.Count){
      $nx = $toks[$i+1]
      $nc = [string]$nx.Content
      if(($nx.Type -eq 'Variable' -and $nc -match '(?i)(exe|installer|setup|bootstrap|msi|bin)') -or ($nx.Type -eq 'CommandArgument' -and $nc -match '(?i)\.exe$')){
        $installLines += [int]$t.StartLine
      }
    }
  }
  $installLines = @($installLines | Sort-Object -Unique)
  if($installLines.Count -gt 0 -and -not $isLib){
    $row.Installer = $true
    $firstInstall = $installLines[0]
    # Proof is judged by PRESENCE and by "does some proof run after some install", not by
    # comparing the highest-numbered check to the highest-numbered install. Install-Sql.ps1
    # runs fifteen phases with checks and installs interleaved; the ordering test called that
    # unverified while it was in fact re-querying the live instance.
    $proofLines = @()
    foreach($vk in $cmdLower.Keys){ if(($vk -match $VerifyCmdRx) -and ($vk -notmatch $VerifyCmdExcludeRx)){ $proofLines += $cmdLower[$vk] } }
    foreach($m in [regex]::Matches($code,$VerifyTextRx)){ $proofLines += (Get-LineNumber -Text $code -Offset $m.Index) }
    $exitProofLines = @()
    foreach($m in [regex]::Matches($code,$ExitCodeProofRx)){ $exitProofLines += (Get-LineNumber -Text $code -Offset $m.Index) }
    $hasExitProof = ($exitProofLines.Count -gt 0)
    $allProof   = @(@($proofLines + $exitProofLines) | Sort-Object -Unique)
    $proofAfter = @($allProof | Where-Object { $_ -gt $firstInstall })
    if($allProof.Count -gt 0 -and $proofAfter.Count -gt 0){ $row.Verified = $true }
    if(-not $row.Verified){
      $why = "runs an external installer at line $firstInstall and NEVER proves it worked on any path."
      if($allProof.Count -gt 0){
        $why += " Every service/file/version/exit-code check in this file is at or above line " + ($allProof[$allProof.Count-1]) + ", which is not after any install call, so none of them proves anything about it."
      }
      if(-not $hasExitProof){
        $why += " The installer's exit code is never compared to anything either, so an installer that prints usage and exits 0, or exits with a vendor rejection code, is reported to cloud-init as SUCCESS."
      }
      Add-Finding $name 'VERIFY' 'FAIL' $firstInstall $why 'Use Invoke-YcInstaller (decodes 0/1641/3010 and known vendor failure codes, enforces a timeout and a minimum plausible duration) and then Assert-YcService / Assert-YcHttp / Assert-YcFile as a post-condition before declaring success.'
    }
    if($row.Verified -and -not $hasExitProof){
      Add-Finding $name 'VERIFY' 'WARN' $firstInstall 'the installer exit code is captured but never compared: 3010/1641 (success, reboot required) are reported as failures and a usage-printed-and-quit 0 is reported as success' 'Use Invoke-YcInstaller and test the returned .Success / .Status.'
    }
  }

  # --- SIDE-EFFECT ORDER ---------------------------------------------------------------
  # This rule is about committing the artefacts of a working agent BEFORE the agent is proven
  # to exist. A file that runs no installer has nothing to commit prematurely: set-firewall's
  # entire job is creating firewall rules, and there is no install for them to be premature to.
  if((-not $isLib) -and $installLines.Count -gt 0){
    $sideLines = @()
    foreach($sc in $SideEffectCmds){ if($cmdLower.ContainsKey($sc)){ $sideLines += $cmdLower[$sc] } }
    if($sideLines.Count -gt 0){
      $guardLines = @()
      foreach($vk in $cmdLower.Keys){ if(($vk -match $VerifyCmdRx) -and ($vk -notmatch $VerifyCmdExcludeRx)){ $guardLines += $cmdLower[$vk] } }
      foreach($m in [regex]::Matches($code,$ExitCodeProofRx)){ $guardLines += (Get-LineNumber -Text $code -Offset $m.Index) }
      foreach($sl in ($sideLines | Sort-Object -Unique)){
        $before = @($guardLines | Where-Object { $_ -lt $sl })
        if($before.Count -eq 0){
          Add-Finding $name 'SIDEEFFECT' 'FAIL' $sl 'a firewall rule / scheduled task is created with no success check before it. On a failed install this leaves the host carrying the artefacts of a working agent with no agent, which is exactly what makes the failure look like a success during a spot check.' 'Move the New-NetFirewallRule / Register-ScheduledTask block below an Assert-YcService (or Assert-YcHttp) that returned $true.'
        }
      }
    }
  }

  # --- SECRETS -------------------------------------------------------------------------
  $pnames = Get-TopLevelParams -Tokens $toks
  $secretVars = @()
  # A parameter whose name ends in File / Path / Dir / Name / Length names a LOCATION or a
  # LENGTH, not a secret. -SqlPasswordFile / -SaPasswordFile / -TokenFile are the file-based
  # hand-off this programme introduced precisely so the value never appears on a command line;
  # logging which file was read is the recommended behaviour, not a leak. The bare secret
  # itself ($AdminPassword, $SaPassword, $Token) is still flagged.
  foreach($p in $pnames){ if(($p -match $SecretNameRx) -and ($p -notmatch $SecretNameExcludeRx)){ $secretVars += $p } }
  if($secretVars.Count -gt 0){
    $lines = $codeS -split "`r?`n"
    # direct: a secret variable on the same statement as a log/console sink
    for($li=0;$li -lt $lines.Count;$li++){
      $L = $lines[$li]
      $sink = $false
      foreach($s in $LogSinkCommands){ if($L -match ('(?i)(^|[;|{(\s])' + [regex]::Escape($s) + '[\s(]')){ $sink = $true; break } }
      if(-not $sink){ continue }
      foreach($sv in $secretVars){
        # A bare truthiness test (if ($SaPassword) { 'SQL (mixed)' } else { ... }) discloses
        # whether a secret was supplied; a length read ($Token.Length) discloses how long it
        # is. Neither discloses the value, and both are the documented pattern here, so strip
        # them and only flag what is left.
        $probe = $L
        $probe = [regex]::Replace($probe,'(?i)\$' + [regex]::Escape($sv) + '\s*\.\s*(Length|Count)\b','')
        $probe = [regex]::Replace($probe,'(?i)\bif\s*\(\s*(-not\s+)?\$' + [regex]::Escape($sv) + '\s*\)','')
        if($probe -notmatch ('(?i)\$' + [regex]::Escape($sv) + '\b')){ continue }
        # Stop-Transcript / Start-Transcript bracket: the value is shown to a human operator on
        # the console with the transcript stopped, then the transcript is restarted, so the
        # value never reaches the log file. That is the intended one-time-display design.
        $b0 = [Math]::Max(0,$li-3)
        $b1 = [Math]::Min($lines.Count-1,$li+3)
        $pre = ''
        for($bk=$b0;$bk -lt $li;$bk++){ $pre = $pre + $lines[$bk] + ' ' }
        $post = ''
        for($bk=$li+1;$bk -le $b1;$bk++){ $post = $post + $lines[$bk] + ' ' }
        $bracketed = (($pre -match '(?i)Stop-Transcript') -and ($post -match '(?i)Start-Transcript'))
        if($bracketed){
          Add-Finding $name 'SECRET' 'INFO' ($li+1) ("the secret parameter `$" + $sv + " reaches a console sink, but the statement is bracketed by Stop-Transcript immediately before and Start-Transcript immediately after, so the value is shown once to the operator on the console and does NOT reach C:\Scripts\<name>.log, the Application event log or the RMM. Verified as mitigated, not a leak.") 'No change required. Keep the Stop-Transcript / Start-Transcript bracket tight around this single statement, and never pass the value to Write-YcLog.'
        }else{
          Add-Finding $name 'SECRET' 'FAIL' ($li+1) ("the secret parameter `$" + $sv + " is written to a log/console sink. It lands in C:\Scripts\<name>.log, in the Application event log, and in whatever the RMM collects.") ("Wrap it: (Protect-YcSecret `$" + $sv + " -Whole), or do not log it at all.")
        }
      }
    }
    # taint: $x = "...$Secret..."  then  Start-Process ... $x
    $tainted = @()
    foreach($sv in $secretVars){
      foreach($m in [regex]::Matches($codeS,'(?im)^\s*\$(\w+)\s*(\+)?=\s*[^\r\n]*\$' + [regex]::Escape($sv) + '\b')){
        $tv = $m.Groups[1].Value
        if($tainted -notcontains $tv){ $tainted += $tv }
      }
    }
    $carriers = @($secretVars + $tainted)
    for($li=0;$li -lt $lines.Count;$li++){
      $L = $lines[$li]
      if($L -notmatch '(?i)(Start-Process|Invoke-YcInstaller|ArgumentList)'){ continue }
      foreach($cv in $carriers){
        if($L -match ('(?i)\$' + [regex]::Escape($cv) + '\b')){
          Add-Finding $name 'SECRET' 'WARN' ($li+1) ("a secret is interpolated into an external process argument list via `$" + $cv + ". The value is visible in the process table, in 4688 command-line auditing, and in the transcript header.") 'Pass the secret through a file or an environment variable, and log the argument list only through Protect-YcSecret.'
          break
        }
      }
    }
  }

  # --- TLS -----------------------------------------------------------------------------
  $dlLines = @()
  foreach($dc in $DownloadCommands){ if($cmdLower.ContainsKey($dc)){ $dlLines += $cmdLower[$dc] } }
  foreach($m in [regex]::Matches($code,$DownloadTextRx)){ $dlLines += (Get-LineNumber -Text $code -Offset $m.Index) }
  if($dlLines.Count -gt 0){
    $tlsLines = @()
    foreach($m in [regex]::Matches($code,$TlsTextRx)){ $tlsLines += (Get-LineNumber -Text $code -Offset $m.Index) }
    foreach($dl in ($dlLines | Sort-Object -Unique)){
      $before = @($tlsLines | Where-Object { $_ -le $dl })
      if($before.Count -eq 0){
        Add-Finding $name 'TLS' 'WARN' $dl 'a download with no TLS 1.2 assignment before it. Windows PowerShell 5.1 defaults to SSL3/TLS1.0, so this fails against any modern endpoint with an unhelpful "request was aborted" error.' 'Call Set-YcTls (or use Get-YcFile, which does it) before the download.'
      }
    }
  }

  # --- COMPAT --------------------------------------------------------------------------
  foreach($p in $Ps7Patterns){
    foreach($m in [regex]::Matches($code,$p.rx)){
      Add-Finding $name 'COMPAT' 'FAIL' (Get-LineNumber -Text $code -Offset $m.Index) ("PowerShell 7-only construct: " + $p.n + " - this does not parse or does not exist on Windows PowerShell 5.1 / Server 2016") 'Rewrite using 5.1 syntax.'
      break
    }
  }
  if($cmdLower.ContainsKey('wmic') -or ($code -match '(?i)(^|[\s;|(])wmic([\s.]|$)')){
    $wl = 0
    if($cmdLower.ContainsKey('wmic')){ $wl = ($cmdLower['wmic'] | Sort-Object)[0] }
    Add-Finding $name 'COMPAT' 'WARN' $wl 'uses wmic, which is deprecated and disabled by default on Windows Server 2025' 'Replace with Get-CimInstance.'
  }

  $fails = @($Findings | Where-Object { $_.File -eq $name -and $_.Severity -eq 'FAIL' })
  $warns = @($Findings | Where-Object { $_.File -eq $name -and $_.Severity -eq 'WARN' })
  if($fails.Count -gt 0){ $row.Result = 'FAIL' } elseif($warns.Count -gt 0){ $row.Result = 'WARN' } else { $row.Result = 'PASS' }
  $null = $FileRows.Add([pscustomobject]$row)
}

# ---------------------------------------------------------------------------------------
# Per-.cmd checks + wrapper integrity
# ---------------------------------------------------------------------------------------
$ps1Names   = @($ps1Files | ForEach-Object { $_.Name.ToLowerInvariant() })
$wrapperMap = @{}
foreach($c in $cmdFiles){
  $name  = $c.Name
  $bytes = [System.IO.File]::ReadAllBytes($c.FullName)
  $na = 0
  foreach($b in $bytes){ if($b -gt 127){ $na++ } }
  if($na -gt 0){ Add-Finding $name 'ASCII' 'FAIL' 0 ("$na byte(s) above 0x7F") 'Re-save as ASCII.' }
  $raw = [System.Text.Encoding]::ASCII.GetString($bytes)

  $target = ''
  $m = [regex]::Match($raw,'(?i)-File\s+"?([^"\r\n]+?\.ps1)"?')
  if($m.Success){ $target = $m.Groups[1].Value.Trim() }
  if($target){
    # %~dp0<Script>.ps1 is the RELOCATABLE form this gate recommends three findings below, so
    # resolve it rather than reporting every correct wrapper as pointing at a missing script.
    $t2 = $target -replace '(?i)%~d0%~p0',''
    $t2 = $t2 -replace '(?i)%~dp0',''
    $t2 = $t2 -replace '^\s*\.[\\/]',''
    $parts = @($t2 -split '[\\/]')
    $leaf = ($parts[$parts.Count-1]).Trim().ToLowerInvariant()
    $wrapperMap[$leaf] = $name
    if($ps1Names -notcontains $leaf){
      Add-Finding $name 'WRAPPER' 'FAIL' 0 ("dispatches to " + $target + ", which is NOT in the payload. powershell.exe -File fails during argument binding, so Start-YcLog never runs: no log file is created, no event is written, and the exit code is a non-standard negative value rather than 1.") ("Ship " + $leaf + ", or delete this wrapper and its entry in Yallacloud.ps1.") -PayloadScoped
    }
  }else{
    if($raw -match '(?i)-Command'){
      Add-Finding $name 'WRAPPER' 'WARN' 0 'uses powershell -Command with an inline script instead of -File. Anything forwarded from %* is re-parsed as PowerShell source, which is a code-injection sink.' 'Move the body into a .ps1 and dispatch with -File; pass the message through an environment variable.'
    }else{
      Add-Finding $name 'WRAPPER' 'INFO' 0 'no -File <script>.ps1 target (inline batch wrapper)' ''
    }
  }
  if($raw -match '(?i)-File\s+"?[A-Za-z]:\\'){
    Add-Finding $name 'WRAPPER' 'WARN' 0 'the -File target is an absolute path. Relocating the payload breaks this wrapper silently: no log, no event, non-standard exit code.' 'Use "%~dp0<Script>.ps1" so the wrapper and its script stay co-located.'
  }
  $execLines = @($raw -split "`r?`n" | Where-Object { $_.Trim() -ne '' -and $_.Trim() -notmatch '^(@echo off|rem\b|::)' })
  if($execLines.Count -gt 0){
    $last = $execLines[$execLines.Count-1].Trim()
    if($last -notmatch '(?i)^(powershell|exit /b)'){
      Add-Finding $name 'WRAPPER' 'WARN' 0 ("the last executable line is '" + $last + "', not the powershell call or 'exit /b %ERRORLEVEL%'. Anything after the payload command overwrites ERRORLEVEL, so a failure is reported as success.") 'End the wrapper with: exit /b %ERRORLEVEL%'
    }
  }
}
foreach($p in $ps1Files){
  $ln = $p.Name.ToLowerInvariant()
  if($ln.StartsWith('_')){ continue }
  if(-not $wrapperMap.ContainsKey($ln)){
    Add-Finding $p.Name 'WRAPPER' 'INFO' 0 'no .cmd wrapper points at this script, so it is not reachable as a PATH command' 'Add a three-line wrapper, or confirm it is only ever called by another script.' -PayloadScoped
  }
}

# ---------------------------------------------------------------------------------------
# CATALOG cross-check against Yallacloud.ps1
# ---------------------------------------------------------------------------------------
$catalogFile = Join-Path $Path 'Yallacloud.ps1'
$advertised  = @()
if(Test-Path -LiteralPath $catalogFile){
  foreach($l in (Get-Content -LiteralPath $catalogFile)){
    if($l -match '(?i)^\s*YcHdr\s' -and $l -match '(?i)SCHEDULED TASKS'){ break }
    $mm = [regex]::Match($l,"^\s*(YcCmd|YcKey)\s+'\s*\*?\s*([a-z][a-z0-9-]{2,})\s")
    if($mm.Success){
      $n = $mm.Groups[2].Value.ToLowerInvariant()
      if($advertised -notcontains $n){ $advertised += $n }
    }
  }
  $wrapperNames = @($cmdFiles | ForEach-Object { $_.BaseName.ToLowerInvariant() })
  foreach($a in $advertised){
    if($wrapperNames -notcontains $a){
      # 2026-08-19 (D4): this was hard-coded 'WARN', so 17 CATALOG completeness findings could coexist
      # with exit 0 while 15 advertised commands had no wrapper - and the full-mode banner claimed
      # CATALOG completeness BLOCKS the build. It is now FAIL, which -PayloadScoped downgrades to INFO
      # under -PartialPayload exactly as it does for WRAPPER. The banner is now true.
      Add-Finding 'Yallacloud.ps1' 'CATALOG' 'FAIL' 0 ("the catalog advertises '" + $a + "' but there is no " + $a + ".cmd in the payload. Every operator who runs yallacloud is told this command exists; typing it gets 'not recognized'.") ("Ship " + $a + ".cmd, or remove the line from Yallacloud.ps1.") -PayloadScoped
    }
  }
  foreach($w in $wrapperNames){
    if($advertised -notcontains $w){
      Add-Finding 'Yallacloud.ps1' 'CATALOG' 'INFO' 0 ("the wrapper " + $w + ".cmd exists but is not advertised in the catalog") ("Add a YcCmd line for " + $w + ".") -PayloadScoped
    }
  }
}else{
  # 2026-08-19 (D4): raised WARN -> FAIL with the same reasoning. In full-payload mode the catalog
  # MUST be present; if it is absent, catalog completeness was not checked at all and the run cannot
  # certify the payload. -PayloadScoped still downgrades this to INFO under -PartialPayload.
  Add-Finding 'Yallacloud.ps1' 'CATALOG' 'FAIL' 0 'Yallacloud.ps1 is not in the scan folder, so the advertised command list could not be cross-checked' 'Scan the complete payload, or pass -PartialPayload to acknowledge that this run does not certify it.' -PayloadScoped
}

# ---------------------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------------------
$failCount = @($Findings | Where-Object { $_.Severity -eq 'FAIL' }).Count
$warnCount = @($Findings | Where-Object { $_.Severity -eq 'WARN' }).Count
$infoCount = @($Findings | Where-Object { $_.Severity -eq 'INFO' }).Count
$failFiles = @($FileRows | Where-Object { $_.Result -eq 'FAIL' })
$stamp     = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')

$txt = New-Object System.Collections.ArrayList
$null = $txt.Add('YALLACLOUD COMMAND PAYLOAD - COMPLIANCE GATE (generated, never hand-maintained)')
$null = $txt.Add(('Generated       : ' + $stamp + '   host ' + $env:COMPUTERNAME))
$null = $txt.Add(('Scanned         : ' + $Path))
$null = $txt.Add(('Payload version : ' + $payloadVersion + '   manifest_sha256 ' + $manifestSha))
$modeText = 'FULL PAYLOAD - WRAPPER and CATALOG completeness findings BLOCK the build (a wrapper pointing at a missing script is a P0).'
if($PartialPayload){ $modeText = 'PARTIAL PAYLOAD (-PartialPayload) - only a SUBSET of the command payload was scanned, so WRAPPER and CATALOG completeness findings are reported as INFO and DO NOT block. This run does NOT certify the payload; re-run without -PartialPayload over the complete payload before shipping.' }
$null = $txt.Add(('Mode            : ' + $modeText))
$null = $txt.Add(('Files           : ' + $ps1Files.Count + ' .ps1, ' + $cmdFiles.Count + ' .cmd'))
$null = $txt.Add(('Findings        : ' + $failCount + ' FAIL, ' + $warnCount + ' WARN, ' + $infoCount + ' INFO'))
$null = $txt.Add('')
$null = $txt.Add('COMMAND.ps1                    kind     nonASCII here o/c parse   Start-YcLog Stop/Exit-Yc USAGE PARAMS EXAM Log  installer verified RESULT')
$null = $txt.Add('----------------------------------------------------------------------------------------------------------------------------------------------')
function YN{ param($b) if($b){ return 'Y' } return '-' }
foreach($r in $FileRows){
  $null = $txt.Add(('{0,-30} {1,-8} {2,-8} {3,-8} {4,-7} {5,-11} {6,-12} {7,-5} {8,-6} {9,-4} {10,-4} {11,-9} {12,-8} {13}' -f `
    $r.File,$r.Kind,$r.NonAscii,("" + $r.HereOpen + '/' + $r.HereClose),$r.Parse,(YN $r.StartYcLog),(YN $r.StopOrExit),(YN $r.Usage),(YN $r.Params),(YN $r.Examples),(YN $r.LogLine),(YN $r.Installer),(YN $r.Verified),$r.Result))
}
$null = $txt.Add('')
$null = $txt.Add('FINDINGS (most severe first)')
$null = $txt.Add('----------------------------------------------------------------------------------------------------')
foreach($sev in @('FAIL','WARN','INFO')){
  foreach($fd in @($Findings | Where-Object { $_.Severity -eq $sev } | Sort-Object File,Line)){
    $loc = $fd.File
    if($fd.Line -gt 0){ $loc = $loc + ':' + $fd.Line }
    $null = $txt.Add(('[{0}] {1,-10} {2}' -f $fd.Severity,$fd.Check,$loc))
    $null = $txt.Add(('           ' + $fd.Message))
    if($fd.Fix){ $null = $txt.Add(('           FIX: ' + $fd.Fix)) }
  }
}
$null = $txt.Add('')
if($failCount -gt 0){
  $null = $txt.Add(('RESULT: FAIL - ' + $failFiles.Count + ' file(s) carry a blocking defect. Do not ship this payload.'))
}else{
  if($PartialPayload){
    $null = $txt.Add('RESULT: PASS - no blocking defect found in the subset that was scanned. This is NOT a release certification: -PartialPayload was set, so wrapper and catalog completeness were not enforced.')
  }else{
    $null = $txt.Add('RESULT: PASS - no blocking defect found.')
  }
}

$txtPath  = Join-Path $OutDir 'yc-compliance.txt'
$jsonPath = Join-Path $OutDir 'yc-compliance.json'
try{ ($txt -join "`r`n") | Out-File -FilePath $txtPath -Encoding ascii -Force }catch{ Write-YcLog ('could not write ' + $txtPath + ': ' + $_.Exception.Message) 'WARN' }

$doc = [pscustomobject]@{
  generated       = $stamp
  host            = $env:COMPUTERNAME
  scanned         = $Path
  mode            = $(if($PartialPayload){'partial-payload'}else{'full-payload'})
  partialPayload  = [bool]$PartialPayload
  payloadVersion  = $payloadVersion
  manifestSha256  = $manifestSha
  ps1Count        = $ps1Files.Count
  cmdCount        = $cmdFiles.Count
  failCount       = $failCount
  warnCount       = $warnCount
  infoCount       = $infoCount
  result          = $(if($failCount -gt 0){'FAIL'}else{'PASS'})
  files           = @($FileRows)
  findings        = @($Findings)
}
try{ ($doc | ConvertTo-Json -Depth 6) | Out-File -FilePath $jsonPath -Encoding ascii -Force }catch{ Write-YcLog ('could not write ' + $jsonPath + ': ' + $_.Exception.Message) 'WARN' }

if(-not $Quiet){
  foreach($l in $txt){ Write-Host $l }
}else{
  foreach($fd in @($Findings | Where-Object { $_.Severity -eq 'FAIL' } | Sort-Object File,Line)){
    Write-Host ('[FAIL] ' + $fd.Check + ' ' + $fd.File + ':' + $fd.Line + '  ' + $fd.Message) -ForegroundColor Red
  }
}

if($Fix){
  $fixable = @($Findings | Where-Object { $_.Fixable })
  Write-Host ''
  Write-Host ('-Fix report: ' + $fixable.Count + ' of ' + $Findings.Count + ' findings carry a mechanical remediation. NOTHING WAS MODIFIED.') -ForegroundColor Yellow
  Write-Host 'Auto-fixing is deliberately not implemented: every FAIL here is a behaviour bug, and a gate that silently rewrites behaviour is how the original problem shipped.' -ForegroundColor Yellow
  foreach($fd in ($fixable | Sort-Object Severity,File,Line)){
    Write-Host ('  [' + $fd.Severity + '] ' + $fd.File + ':' + $fd.Line + ' (' + $fd.Check + ') -> ' + $fd.Fix)
  }
}

if($Json){
  Write-Host ''
  Write-Host ($doc | ConvertTo-Json -Depth 6)
}

Write-YcLog ('report written: ' + $txtPath + ' and ' + $jsonPath) 'INFO'

$totalFiles = $ps1Files.Count + $cmdFiles.Count
if($failCount -gt 0){
  Exit-Yc 1 ('{0} FAIL / {1} WARN across {2} files - payload REJECTED' -f $failCount,$warnCount,$totalFiles) 'ERROR'
}
Exit-Yc 0 ('no FAIL ({0} WARN, {1} INFO) across {2} files - payload accepted' -f $warnCount,$infoCount,$totalFiles) 'OK'
