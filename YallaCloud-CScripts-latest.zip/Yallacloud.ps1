param([switch]$Help,[switch]$Version)
# Yallacloud.ps1 - YALLACLOUD command catalog for L1 Day-2 operations. PS 5.1, ASCII only.
# CATALOG VERSION - bump this whenever the command list changes.
$YcCatalogVersion = '2.36.1'
$YcCatalogDate    = '2026-10-23 IST'
# ---------------------------------------------------------------------------------------------
# WHAT CHANGED IN 2.8.0 AND WHY (2026-08-19 correction pass)
#   1. FIVE WRAPPERS WERE REWRITTEN AND ARE NOW SHIPPED FROM SOURCE CONTROL:
#        set-firewall.cmd  set-nic.cmd  rotate-password.cmd  activate-windows.cmd  boot-repair.cmd
#      Every one of the five now carries an accurate rem usage block derived from the repaired
#      script's real param block, and every one ends with 'exit /b %ERRORLEVEL%'.
#   2. set-firewall.cmd was documenting -ExtraTcp / -ExtraUdp. The repaired script takes
#      -ExtraTcpIn / -ExtraUdpIn, so '-ExtraTcp 445' threw a positional-parameter error BEFORE
#      Start-YcLog ran: no log, no event, nothing to diagnose from. The old rem block also still
#      called it "the YALLACLOUD standard firewall rule set", which is the opposite of the truth.
#      set-firewall is now SAFE BY DEFAULT: with no arguments it opens ONLY RDP 3389, SSH 3222 and
#      ICMPv4 echo, on Domain and Private only, scoped to -MgmtCidr (default LocalSubnet).
#      Databases, WinRM, SMB, web and the exporter ports are all opt-in, and most of them refuse
#      to run until an explicit -MgmtCidr is passed. The catalog line below says so.
#   3. set-nic now needs CONFIRMING. An address change (static or -DHCP) arms a dead-man's-switch
#      that SELF-REVERTS after -RollbackMinutes (default 5) unless you reconnect on the new address
#      and run 'set-nic -Commit'. The catalog line below says so - operators were losing changes
#      and reporting it as a bug.
#   4. yc-compliance: CATALOG completeness findings now BLOCK the build. They were hard-coded WARN
#      while the full-mode banner claimed they blocked, so 17 CATALOG WARNs coexisted with exit 0
#      and 15 advertised commands had no wrapper. They are FAIL in full-payload mode now and INFO
#      under -PartialPayload, consistent with WRAPPER. If yallacloud advertises a command whose
#      .cmd is not in the payload, the gate FAILS. Keep this catalog honest.
#   Also: added the EXIT CODES section this script never had (0 only).
# ---------------------------------------------------------------------------------------------
# WHAT CHANGED IN 2.7.0 AND WHY (catalog reconciliation)
#   Every command advertised here now resolves to a file that exists in the payload, and every
#   operator-facing script in the payload is advertised. 2.6.2 advertised five commands that did
#   not exist - an operator who typed one got 'is not recognized' and a support ticket.
#     zabbix-register      Zabbix-Register.ps1 was missing. It now exists. KEPT.
#     promtail-register    no script, no wrapper, and Promtail is END OF LIFE. REMOVED and
#                          redirected to alloy-register, which this estate actually runs.
#     evtx-hunt            no script; hayabusa is not installed by anything in this tree. REMOVED.
#     logview              no script; klogg is not installed by anything in this tree. REMOVED.
#     set-admin-console    no script anywhere. REMOVED. The answer file's two references to
#                          set-admin-console.cmd were removed with it - a RunSynchronousCommand
#                          pointing at a missing path returns non-zero and fails the specialize
#                          pass on every clone. The supported way to set the built-in
#                          Administrator password is the user-data in userdata-set-admin.yaml.
#     TOOLS line           claimed IISCrypto(Cli), hayabusa, klogg and photorec-as-a-separate-tool.
#                          Nothing installs IISCrypto, hayabusa or klogg. Corrected to what is
#                          actually staged on the golden image versus what Day2-Setup -Tools adds.
#   ADDED (they exist in the payload and were never advertised):
#     yc-compliance, collect-logs, set-s3config, transfer-s3, backup-sql, set-bytebaseclient,
#     install-sql, vmware-tools.
# ---------------------------------------------------------------------------------------------
# Payload version is authoritative for WHAT is on disk; read it if present.
$YcPayload = 'unknown'
try { $pv = 'C:\Scripts\yc-payload-version.txt'
      if(Test-Path $pv){ $m = (Select-String -Path $pv -Pattern '^payload_version\s*=\s*(\S+)').Matches
                         if($m.Count){ $YcPayload = $m[0].Groups[1].Value } } } catch {}
$YcBanner = "  YALLACLOUD catalog v$YcCatalogVersion ($YcCatalogDate)   payload: $YcPayload   host: $env:COMPUTERNAME"

# -Version: print the banner and nothing else. Previously this fell through and
# dumped the whole catalog, which is why `yallacloud -version` looked broken.
if($Version){
  Write-Host ''
  Write-Host $YcBanner -ForegroundColor Green
  Write-Host ("  catalog file : " + $PSCommandPath + "  (" + (Get-Item $PSCommandPath).Length + " bytes)") -ForegroundColor DarkGray
  Write-Host ''
  exit 0
}
if($Help){
  Write-Host ''
  Write-Host $YcBanner -ForegroundColor Green
  Write-Host '  USAGE:      yallacloud [-Version] [-Help]'
  Write-Host '  PARAMETERS: -Version  print catalog + payload version and exit'
  Write-Host '              -Help     this text'
  Write-Host '  EXAMPLES:   yallacloud            list every day-2 command'
  Write-Host '              yallacloud -Version   what catalog/payload is on this box'
  Write-Host '  EXIT CODES: 0  the catalog, the banner or this help was printed. This command only'
  Write-Host '                 writes to the console - it reads no state, changes nothing, opens no'
  Write-Host '                 transcript, and has no other exit path. It cannot fail.'
  Write-Host ''
  exit 0
}
# NOTE: helper function names are prefixed (YcHdr/YcCmd/YcKey/YcDim) to avoid clashing with built-in
#       PowerShell aliases (e.g. 'h' = Get-History). Do NOT rename them to single letters.
function YcHdr([string]$t){ Write-Host $t -ForegroundColor Yellow }
function YcCmd([string]$t){ Write-Host $t }
function YcKey([string]$t){ Write-Host $t -ForegroundColor Green }   # '*' = recommended / priority
function YcDim([string]$t){ Write-Host $t -ForegroundColor DarkGray }

Write-Host ''
Write-Host $YcBanner -ForegroundColor Green
Write-Host '  YALLACLOUD  -  Day-2 command catalog' -ForegroundColor White
Write-Host '  C:\Scripts is on PATH. Add -Help to ANY command for usage, parameters and examples.' -ForegroundColor Gray
Write-Host '  Every command AND scheduled task logs (output + errors, timestamped, TAGGED [YALLACLOUD][<cmd>])' -ForegroundColor Gray
Write-Host '  to  C:\Scripts\<name>.log   (the C:\Scripts folder is auto-created if missing).' -ForegroundColor Gray
Write-Host '  Legend:   * = recommended / priority tool' -ForegroundColor Gray
Write-Host ''

YcHdr '  START HERE:'
YcDim  '    Not sure what you need? Add -Help to ANY command below for usage, parameters and examples.'
YcCmd '    yallacloud              this catalog'
YcKey '  * migration-check         BEFORE the migration, ON THE SOURCE VM: can this VM be moved?'
YcDim  '                            READ-ONLY. Changes nothing - no install, no task, no repair. Run it DAYS'
YcDim  '                            before the window, while the VM is still serving users, so the answer is'
YcDim  '                            known before anyone agrees a downtime.'
YcDim  '                            Source VMs have no C:\Scripts, so it is one pasted line in an ELEVATED'
YcDim  '                            PowerShell - that IS the whole thing:'
YcCmd  '                              [Net.ServicePointManager]::SecurityProtocol=''Tls12''; iex (irm https://raw.githubusercontent.com/yallacloud/yc-scripts/main/Test-MigrationReadiness.ps1)'
YcDim  '                            Answers GO (0) | GO WITH RISK (1) | DO NOT MIGRATE (2); 5 = not elevated,'
YcDim  '                            nothing checked. Every drive chkdsk /scan + dirty bit, SQL damaged pages WITH'
YcDim  '                            DATES, VSS writers, whether a backup actually restores, virtio and VMware'
YcDim  '                            Tools VERSIONS vs the pin, the QEMU guest agent, Windows/Office/SQL edition'
YcDim  '                            and licence state - and the report is dated EVIDENCE from before the move.'
YcDim  '                            Writes migration-check-<HOST>-<date>.txt and .json to -OutDir (default TEMP).'
YcKey '  * migrated-vm             MIGRATED VM? Run this ONCE. -Report | -Run | -Status'
YcDim  '                            On a FRESH migrated box there is no C:\Scripts and no commands yet, so the'
YcDim  '                            first step is a line you paste into an ELEVATED PowerShell - that IS the'
YcDim  '                            deployment, there is no step two:'
YcCmd  '                              [Net.ServicePointManager]::SecurityProtocol=''Tls12''; iex (irm https://raw.githubusercontent.com/yallacloud/yc-scripts/main/adopt.ps1)'
YcDim  '                            Survey -> prerequisites (incl. pending reboot) -> pull C:\Scripts -> PATH so'
YcDim  '                            yallacloud works -> report SQL edition/version/licence -> FIRST FULL backup of'
YcDim  '                            every database, then daily DIFF + weekly FULL -> YC-AutoUpdate and YC-Inventory'
YcDim  '                            -> mark the VM as ours -> prove nothing else changed.'
YcDim  '                            NEVER installs SQL, never activates Windows, never removes what it cannot'
YcDim  '                            identify, and REFUSES the backup phase if another backup scheme is already live.'
YcKey '  * diag                    quick system diagnostic - run this first when something is wrong'
YcKey '  * collect-logs            ONE redacted support .zip: logs + events + system facts  [-Days 14] [-S3]'
YcCmd '    report-inventory        what is on this machine, as a report'
YcCmd '    licence-report          read-only Windows + SQL licensing report (no key is ever printed)'
YcCmd '    yc-compliance           audit C:\Scripts against the house contract    [-Path <d>] [-OutDir <d>] [-Json] [-Fix]'
Write-Host ''
YcHdr '  LICENSING & ACTIVATION:   turning Evaluation into a licensed machine'
YcCmd '    licence-report          what is licensed right now. Changes nothing. START HERE'
YcCmd '    convert-edition         Evaluation -> full edition using the PUBLISHED GVLK   [-List] [-Edition ..]'
YcDim  '                            -List asks the image itself via DISM /Get-TargetEditions. The conversion is'
YcDim  '                            ONE WAY and needs a reboot. NEVER rearm afterwards - it destroys the store.'
YcCmd '    activate-windows        Windows Server 2012R2-2025: show state -> activate -> show state (+opt GLPI)   -ProductKey <k>'
YcCmd '    activate-sql            SQL Server 2012-2026: show state -> edition-upgrade -> show state (+opt GLPI)  -ProductKey <k>'
Write-Host ''
YcHdr '  SQL SERVER - INSTALL:   building a database server'
YcKey '  * install-sql             SQL Server 2016-2025 unattended install + config  [-Version 2022] [-SaPassword <p>]'
YcCmd '                            install-sql -Version 2019 -Edition Express -InstanceName YCEXPRESS   (free, no key)'
YcCmd '                            install-sql -InstanceName YCEXPRESS -Uninstall   (removes it, proves it is gone)'
YcDim  '                            NEVER run this on a MIGRATED SQL box - it is destructive there. Adopt instead.'
YcKey '  * install-ssms            SQL Server Management Studio, PROVEN by finding Ssms.exe  [-SsmsVersion 20|22]'
YcCmd '                            install-ssms                      (auto: SSMS 22 on 2019+, SSMS 20 on 2016)'
YcKey '  * install-dotnet          .NET Framework 4.8 - what SSMS and Chocolatey 2.x both need  [-Target 4.8.1]'
YcCmd '                            install-dotnet -UpgradeChocolatey (2016/2019 ship 4.6.2/4.7.2; reboot, exit 8)'
YcKey '  * dbatools-install        dbatools PowerShell module (SQL Server mgmt)     [-Online] [-Scope AllUsers]'
YcCmd '    activate-sql            licence it once it is installed        (also in LICENSING)'
YcCmd '    set-bytebaseclient      point this host at the Bytebase schema-change server  -Url <u>'
Write-Host ''
YcHdr '  SQL SERVER - BACKUP & RESTORE:   protecting the data that is already there'
YcKey '  * backup-sql              verified SQL backup (CHECKSUM + VERIFYONLY, opt S3) [-Database <db>] [-Type Full] [-AllInstances]'
YcKey '  * restore-sql             RESTORE a database: full + diff + log chain, or a point in time'
YcCmd '                            restore-sql -List                  see every backup you have'
YcCmd '                            restore-sql -Database <db>         restore the latest'
YcCmd '                            restore-sql -Database <db> -AsName <copy>   restore BESIDE the live one'
YcCmd '                            restore-sql -Database <db> -StopAt "2026-09-01 01:04:23"'
YcKey '  * sql-backup-path         MOVE the backup location, and change retention, on a live machine'
YcCmd '                            sql-backup-path -Report           (where they go now, and how long kept. Changes nothing)'
YcCmd '                            sql-backup-path -Path D:\dbbackupdaily          (C: filling up? move it. -Move takes the files too)'
YcCmd '                            sql-backup-path -RetainFullDays 60              (retention only - FULL 35d / DIFF 14d / LOG 14d by default)'
YcDim  '                            Rewrites @Directory AND @CleanupTime in the three backup tasks, the monthly archive'
YcDim  '                            and the instance default, together - Ola only ever cleans the folder it is pointed at,'
YcDim  '                            so a location moved without its retention leaves one folder growing and one orphaned.'
YcDim  '                            It makes SQL Server write a real test backup to the new path FIRST; if that fails,'
YcDim  '                            nothing changes. restore-sql needs no telling - it reads the root out of the tasks.'
YcKey '  * sql-archive             keep ONE full per calendar month, kept OUTSIDE the rolling window  [-KeepMonths 12]'
YcCmd '                            sql-archive -Report               (what exists, what would happen. Changes nothing)'
YcCmd '                            sql-archive                       (runs daily as YC-SqlBackupMonthly-<inst>, idempotent)'
YcKey '  * vss-check               is VSS healthy? snapshots are application-consistent only if it is. Read-only. [-Full] [-Json]'
Write-Host ''
YcHdr '  NETWORK:   addresses, gateways, and getting back in if it goes wrong'
YcCmd '    set-nic                 configure a NIC (static / DHCP)      -Name <n> [-DHCP | -IP ..]'
YcDim  '                            SELF-REVERTS in -RollbackMinutes (default 5) unless you reconnect on the new'
YcDim  '                            address and confirm with   set-nic -Commit'
YcKey '  * fix-gateway             CloudStack sometimes hands a private NIC a .254 gateway. This puts it back.'
YcCmd '                            fix-gateway -Report               (what the gateway is, what it should be. Changes nothing)'
YcCmd '                            fix-gateway                       (private RFC1918 NICs only - public addresses are never touched)'
YcDim  '                            It only acts on a gateway that is EXACTLY .254 on a private subnet, and only after'
YcDim  '                            the candidate .1 answers a ping. If the new gateway does not work, it rolls back.'
YcDim  '                            The NIC is not bounced unless -Force is given.'
Write-Host ''
YcHdr '  FIREWALL & ACCESS:   who can reach this machine'
YcCmd '    set-firewall            SAFE BY DEFAULT: no args = RDP 3389 + SSH 3222 + ICMPv4 only, Domain/Private,'
YcDim  '                            scoped to -MgmtCidr (default LocalSubnet). Databases/WinRM/SMB/web/exporters'
YcDim  '                            are OPT-IN and most refuse without an explicit -MgmtCidr. -ExtraTcp/-ExtraUdp'
YcDim  '                            were RENAMED to -ExtraTcpIn/-ExtraUdpIn.'
YcCmd '    rotate-password         rotate the local admin password'
YcCmd '    passgen                 the house password rule, in one place'
YcCmd '                            passgen                           (one 16-char password)'
YcCmd '                            passgen -Length 12 -Count 10      (ten of them)'
YcCmd '                            passgen -SelfCheck                (proves the generator against the rule)'
YcDim  '                            Rule: 8-16 chars, first char A-Z, last char a-z, at least two #, at least one digit,'
YcDim  '                            # is the ONLY symbol, and O/0/I/l are excluded so nobody mistypes one over the phone.'
YcDim  '                            This is what the userdata uses for the SQL sa password and the Administrator password.'
YcCmd '    defender-exclude        Microsoft Defender exclusions        <path> [..]'
YcCmd '    bitdefender-exclude     Bitdefender exclusions               <path> [..]'
Write-Host ''
YcHdr '  WINDOWS UPDATES:   patching, and where the patches come from'
YcCmd '    set-local-wsus          use the LOCAL update server (ycwsus01) instead of Microsoft   -Install | -Uninstall'
YcDim  '                            -Status / -Test first. NO AUTOMATIC FALLBACK: once pointed at it, that server IS'
YcDim  '                            the source - if it is unreachable the scan FAILS and the machine silently stops'
YcDim  '                            patching. -Install refuses on a server it cannot reach; -Uninstall is the fallback.'
YcCmd '    winupdate               Windows Update - choosable scope, unattended   [-Security|-Critical|-All|-Drivers] [-Reboot]'
YcCmd '    yc-autoupdate           keep C:\Scripts current from the public repo   [-Install] [-Force]'
YcDim  '                            Checks a 97-byte sidecar with a stored ETag, so an unchanged payload costs'
YcDim  '                            nothing. Runs at startup, when a network appears, and daily at 00:01.'
YcDim  '                            Disable entirely: create C:\Scripts\.no-auto-update'
Write-Host ''
YcHdr '  APPS & TOOLS:   install on demand'
YcKey '  * install-office          Office Standard / Excel unattended, edition PROVEN  -Product <sku> [-ProductKey <k>]'
YcCmd '                            install-office -Product Office2019Standard   (2019/2021 need no media)'
YcCmd '                            install-office -Product Office2016Standard -MediaPath D:\   (2016 is MSI, VLSC ISO)'
YcCmd '    install-ssms            SQL Server Management Studio           (also in SQL SERVER - INSTALL)'
YcCmd '    install-dotnet          .NET Framework 4.8                     (also in SQL SERVER - INSTALL)'
YcCmd '    dbatools-install        dbatools PowerShell module             (also in SQL SERVER - INSTALL)'
YcCmd '    diagtools-install       install the STAGED smartmontools + Log Parser 2.2 on this clone'
YcCmd '    vmware-tools            install VMware Tools unattended (VMware hosts only)   [-Drivers]'
YcCmd '    webjea-install          WebJEA IIS web UI to run PowerShell (inbound)     [-Port 8443]'
YcCmd '    olivetin-install        OliveTin action web UI (WSL2 / container)'
Write-Host ''
YcHdr '  MONITORING & SECURITY AGENTS:   register one per deployment'
YcCmd '    salt-register           Salt Minion - automation, egress-only         -Master <ip> [-MinionId ..]'
YcCmd '    zabbix-register         Zabbix Agent 2 - monitoring                   -Server <ip> [-TlsPskFile <f>]'
YcCmd '    wazuh-register          Wazuh agent - security / SIEM                 -Manager <ip>'
YcCmd '    site24x7-register       Site24x7 monitoring agent                     -DeviceKey <key>'
YcCmd '    snmp-register           SNMP service + community / traps              -Community <c>'
YcCmd '    osquery-register        osquery endpoint visibility                   -FleetUrl <h> -EnrollSecret <s>'
YcCmd '    glpi-register           GLPI inventory agent                          -Server <url>'
YcCmd '    acronis-register        Acronis Cyber Protect agent                   -Token <t> -Url <u>'
YcCmd '    bitdefender-register    Bitdefender endpoint agent  (advisory: install Acronis FIRST)'
YcCmd '    observability-register  installs the exporters below as one bundle'
Write-Host ''
YcHdr '  METRICS EXPORTERS:   Prometheus scrape, or push out'
YcKey '  * winexporter-register    windows_exporter - Prometheus Windows metrics    [-ListenPort 9182]'
YcKey '  * alloy-register          Grafana Alloy telemetry agent (push out)         -ConfigUrl|-ConfigFile <cfg>'
YcKey '  * otelcol-register        OpenTelemetry Collector contrib (push out)       -ConfigUrl|-ConfigFile <cfg>'
YcCmd '    telegraf-register       Telegraf metrics agent (push out)                -InfluxUrl <u> -Token <t> -Org <o>'
YcKey '  * sqlexporter-register    sql_exporter - Prometheus MSSQL / SQL Server     -SqlUser <u> -SqlPassword <p> [-ListenPort 9399]'
YcKey '  * postgresexporter-register  postgres_exporter - Prometheus PostgreSQL     -DataSourceName <dsn> [-ListenPort 9187]'
YcKey '  * mysqldexporter-register    mysqld_exporter - Prometheus MySQL / MariaDB  -MyHost <h> -MyUser <u> -MyPassword <p>'
YcDim  '                            (promtail-register is GONE - Promtail is end-of-life and was never shipped in this'
YcDim  '                             payload. Use  alloy-register  for Loki log shipping; the Alloy config replaces promtail.yaml.)'
Write-Host ''
YcHdr '  DIAGNOSTICS & REPAIR:   when something is already broken'
YcCmd '    diag                    quick system diagnostic (health / forensic report)'
YcCmd '    rootcause               root-cause analysis of the last crash / bugcheck'
YcKey '  * yc-integrity            is this machine''s data still intact - and say so EITHER WAY'
YcCmd '                            yc-integrity -Sql Fast        CHECKDB PHYSICAL_ONLY (the daily pass)'
YcCmd '                            yc-integrity -Sql Full        the whole logical CHECKDB (weekly)'
YcCmd '                            yc-integrity -Disk            chkdsk /scan read-only, every NTFS volume'
YcCmd '                            yc-integrity -RestoreVerify   RESTORE VERIFYONLY over the newest full'
YcCmd '                            yc-integrity -SuspectPages    msdb damaged-page record. Instant, free.'
YcDim  '                            GATES on free space first (CHECKDB snapshots onto the data volume),'
YcDim  '                            RE-RUNS any failure before anyone is told (one transient alert trains'
YcDim  '                            people to ignore alerts), and reports the PASS as well as the FAIL -'
YcDim  '                            silence and success look identical from outside. It DETECTS, never'
YcDim  '                            repairs: REPAIR_ALLOW_DATA_LOSS does what its name says.'
YcDim  '                            PHYSICAL_ONLY verifies page CHECKSUMS - a database that ran with'
YcDim  '                            PAGE_VERIFY NONE has pages with none, so Full is the one to trust on'
YcDim  '                            a newly migrated box.'
YcKey '  * collect-logs            ONE redacted support .zip: logs + events + system facts  [-Days 14] [-S3]'
YcCmd '    boot-repair             UEFI/BIOS boot + MFT/filesystem repair (bcdboot/bootrec/chkdsk/sfc/dism)  [-Boot|-FileSystem|-Full]'
YcCmd '    fix-deploy              apply the DEPLOYMENT-TIME fixes (idempotent)   [-Report] [-Only ..]'
YcDim  '                            lockout threshold 0 + unlock Administrator, isolated-network gateway,'
YcDim  '                            permanent TLS 1.2 registry values, console logon account, and the'
YcDim  '                            missing cloudbase-init NetworkConfigPlugin. Run by the'
YcDim  '                            cloud-init user data on first boot; safe to re-run by hand.'
YcCmd '    grow-disk               extend C: to fill the disk'
YcCmd '    yc-compliance           audit C:\Scripts against the house contract    [-Path <d>] [-OutDir <d>] [-Json] [-Fix]'
YcDim  '                            CATALOG and WRAPPER completeness FAIL (block) in full-payload mode: a'
YcDim  '                            command advertised here with no .cmd in the payload fails the gate.'
YcDim  '                            (evtx-hunt and logview are GONE - nothing in this image installs'
YcDim  '                             hayabusa or klogg, so both commands only ever printed an error.'
YcDim  '                             For event-log work use  Get-WinEvent  /  wevtutil qe <log> /c:50 /rd:true /f:text,'
YcDim  '                             or run  diagtools-install  and use the staged Log Parser 2.2.)'
Write-Host ''
YcHdr '  STORAGE & FILE TRANSFER:'
YcCmd '    set-s3config            store + PROVE an S3-compatible endpoint (DPAPI-sealed secret)  -Endpoint <u> -Bucket <b>'
YcCmd '    transfer-s3             upload/download against that endpoint, every transfer verified  -Path <p> [-Direction Upload]'
YcCmd '    grow-disk               extend C: to fill the disk             (also in DIAGNOSTICS & REPAIR)'
Write-Host ''
YcHdr '  FLEET REPORTING:   telling the outside world about this VM'
YcCmd '    report-inventory        local inventory report'
YcKey '  * yc-event                tell the outside world what this VM is, and what just happened to it'
YcCmd '                            yc-event -Report                  (identity + licence + SQL, sends NOTHING)'
YcCmd '                            yc-event -Test                    (is it the URL, the token, or egress?)'
YcCmd '                            yc-event -Type vm.deploy.completed -Step "NET+ SYNC+ ..."'
YcCmd '                            yc-event -Drain                   (retry everything that never got through)'
YcCmd '                            yc-event -SetUrl <u> -SetSecret <s> | -SetToken <jwt> -SetNtfy <u>'
YcDim  '                            Knowing WHO YOU ARE is the hard part: the config drive exists only at first boot,'
YcDim  '                            the virtual router only while networked, and cloudbase-init keeps no log. So it'
YcDim  '                            ACCUMULATES identity into vm-facts.json and never overwrites a known value with a'
YcDim  '                            blank. Underneath both is the SMBIOS UUID, which IS the CloudStack VM UUID.'
YcDim  '                            Domain and account are not visible from inside a guest - the receiver resolves'
YcDim  '                            them from vmId. Undelivered events queue to disk and every payload carries a'
YcDim  '                            delivery block, so the first message that gets through says what was missed.'
YcCmd '    licence-report          licensing report                       (also in LICENSING & ACTIVATION)'
YcDim  '                            (yc-vmbuild is the build state machine the userdata drives - DOTNET/SQL/SSMS/LIC/'
YcDim  '                             UPDPRE/UPDPOST/NOTIFY/DONE, reboot-resumable, and it writes yc-build.completed when'
YcDim  '                             it finishes. It is not meant to be run by hand.)'
YcDim  '                            (set-admin-console is GONE - the script never existed and the answer'
YcDim  '                             file no longer calls it. To set the built-in Administrator password on'
YcDim  '                             a clone, paste userdata-set-admin.yaml as instance User Data.)'
Write-Host ''
YcHdr '  WHERE THE LOGS ARE:'
YcCmd '      Every command logs to  C:\Scripts\<command>.log  - install-sql.log, backup-sql.log,'
YcCmd '      restore-sql.log, activate-sql.log, activate-windows.log, fix-deploy.log,'
YcCmd '      install-office.log, vss-check.log, yc-sqlarchive.log, yc-sqlbackuppath.log,'
YcCmd '      yc-event.log,'
YcCmd '      licence-report.log. Same name as the command, every time.'
YcCmd '      Every line is also written to the Application event log, source YALLACLOUD.'
YcCmd '      Machine-readable extras for automation:'
YcCmd '        C:\Scripts\backup-sql-results.jsonl   one JSON object per database per backup'
YcCmd '        C:\Scripts\yc-sqlarchive.json         what the monthly archive did last run'
YcCmd '        C:\Scripts\yc-sqlbackuppath.json      the backup root and retention now in force'
YcCmd '        C:\ProgramData\YallaCloud\vm-facts.json         who this VM is, accumulated'
YcCmd '        C:\ProgramData\YallaCloud\yc-event-queue.jsonl  events that never got through'
YcCmd '        vss-check -Json / restore-sql -List -Json / licence-report -Format Csv|Html'
YcCmd '      Log line format (the same on every host, for central logging):'
YcCmd '        <ISO8601+offset>  <HOSTNAME>  [YALLACLOUD][<command>] [<LEVEL>] <message>'
YcCmd '      NOT ours, do not ingest as ours: C:\Scripts\*.msi.log are Windows Installer files.'
Write-Host ''
Write-Host ''
YcHdr '  SCHEDULED TASKS & SERVICES we create (golden image + tools):'
YcDim  '    Recurring / boot tasks baked in the golden (each logs to C:\Scripts):'
YcCmd  '      YC-Boot               at boot          grow disk, clean ghost NICs, create access rules ONCE (yc-boot.ps1)'
YcCmd  '      YC-Health             boot + 03:30     chkdsk guard, root-cause snapshot, log rotation (yc-health.ps1)'
YcCmd  '      YC-KeyGuard           boot + hourly    sshd authorized_keys + ACL - the ONLY enforced item (yc-keyguard.ps1)'
YcDim  '      (these three replaced the old nine: GIGrowDisk GIDiskGuard GINetwork GIWatchdog'
YcDim  '       YCDEPLOY YCGUARD YCGUARD5 YCNET YCNET5. If you still see any of those, the'
YcDim  '       image was sealed WITHOUT Fix-PreSeal - report it.)'
YcDim  '    First-boot tasks (run ONCE at first boot then self-delete):'
YcCmd  '      YCFIRSTBOOT           first-boot provisioning (yc-firstboot.ps1)            -> yc-firstboot.log'
YcCmd  '      GISSHInit             regenerate per-clone SSH host keys                    -> ssh-firstboot.log'
YcDim  '    Baked services (always present in the golden image):'
YcCmd  '      cloudbase-init  (first-boot provisioning: hostname/password/userdata; delayed-auto on 2016/2019)'
YcCmd  '      sshd / OpenSSH  (remote administration & diagnostics)'
YcCmd  '      VMTools / vmvss  or  qemu-ga   (guest agent, per hypervisor)'
YcDim  '    Day-2 services created by the *-register commands (only after you run them):'
YcCmd  '      salt-minion, windows_exporter, telegraf, alloy, otelcol, postgres_exporter,'
YcCmd  '      mysqld_exporter, sql_exporter, Zabbix Agent 2, Wazuh, osquery, glpi-agent,'
YcCmd  '      Site24x7, Acronis, SNMP, Bitdefender, WebJEA (IIS)'
Write-Host ''

YcDim '  TOOLS on PATH (staged in the golden image under C:\Scripts\DiagTools):  testdisk  photorec  iperf3'
YcDim '                 (photorec ships inside the testdisk distribution - it is not a separate download)'
YcDim '                 salt-call / salt-minion  appear after  salt-register'
YcDim '                 STAGED BUT NOT INSTALLED: smartctl (smartmontools) and Log Parser 2.2 -> run  diagtools-install'
YcDim '                 Day2-Setup -Tools additionally installs, on an EXISTING VM only (choco/scoop):'
YcDim '                 Sysinternals\*  crystaldiskinfo  snmpb  choco  scoop  ntfy'
YcDim '                 NOT on this image, despite older catalogs claiming otherwise: IISCrypto(Cli),'
YcDim '                 hayabusa, klogg, nmap. Nothing in the payload installs them.'
YcDim '  Logs & files in C:\Scripts:  <command>.log, golden-image-build.log, winupdate.log, disk-guard.log,'
YcDim '                 boot-repair.log, rootcause-latest.txt, yc-compliance.txt/.json, logs\<host>-<ts>.zip'
YcDim '                 (Windows event log source: YallaCloud)'
Write-Host ''
Write-Host '  Example:  activate-windows -ProductKey XXXXX-...    boot-repair -FileSystem    winupdate -Security -Reboot' -ForegroundColor Cyan
Write-Host '            collect-logs -Days 7        yc-compliance -Json        backup-sql -Database MYDB -Type Full' -ForegroundColor Cyan
Write-Host '            restore-sql -List           vss-check                  backup-sql -AllInstances -Type Full' -ForegroundColor Cyan
Write-Host '            sql-backup-path -Report     sql-archive -Report        sql-backup-path -Path D:\dbbackupdaily -Move' -ForegroundColor Cyan
Write-Host '            yc-event -Report            yc-event -Test             yc-event -Drain' -ForegroundColor Cyan
Write-Host ''
Write-Host $YcBanner -ForegroundColor Green
Write-Host ''
exit 0
