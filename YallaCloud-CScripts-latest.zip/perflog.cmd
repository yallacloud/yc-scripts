@echo off
rem perflog [seconds]  ->  C:\Scripts\perflog-<n>.csv   (CPU, memory, disk, network via typeperf)
set SECS=%1
if "%SECS%"=="" set SECS=60
set OUT=C:\Scripts\perflog-%RANDOM%.csv
echo Logging performance for %SECS%s to %OUT% ...
typeperf "\Processor(_Total)\%% Processor Time" "\Memory\Available MBytes" "\PhysicalDisk(_Total)\%% Disk Time" "\PhysicalDisk(_Total)\Avg. Disk Queue Length" "\Network Interface(*)\Bytes Total/sec" -si 1 -sc %SECS% -f CSV -o "%OUT%"
echo Done: %OUT%
