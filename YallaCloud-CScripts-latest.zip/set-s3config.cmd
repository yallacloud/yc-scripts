@echo off
rem set-s3config [-Endpoint <url>] [-Region <r>] [-Bucket <b>] [-AccessKey <id>] [-SecretKeyFile <path>]
rem              [-SecretKey <k>] [-Prefix <p>] [-UsePathStyle] [-VirtualHostStyle] [-NoSsl]
rem              [-Profile <name>] [-Test] [-List] [-Remove] [-WhatIf] [-Help]
rem Store and PROVE an S3-compatible endpoint config for this host. The secret key is encrypted with
rem DPAPI (LocalMachine) in C:\Scripts\s3\<profile>.json so a SYSTEM scheduled task can read it.
rem Prefer -SecretKeyFile: a secret passed as an argument is visible in the process table and in 4688.
rem Logs to C:\Scripts\set-s3config.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Set-S3Config.ps1" %*
exit /b %ERRORLEVEL%
