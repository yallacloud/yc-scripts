@echo off
rem diagtools-install [-ToolsDir <dir>] [-Force] [-TimeoutSec 900] [-Help]
rem
rem Installs the STAGED smartmontools and Log Parser 2.2 on THIS deployed VM and PROVES each
rem one afterwards: smartctl is run with --version, LogParser.exe has its FileVersion read back,
rem and the portable tools (testdisk, photorec, iperf3) are located under -ToolsDir. Both
rem installers now run through Invoke-YcInstaller, so their exit codes are captured, decoded
rem and timed - the old version used Start-Process without -PassThru, so there was no exit code
rem to check even in principle, and it printed "diagtools-install done." regardless.
rem A tool that is already present is not reinstalled unless -Force is given.
rem Logs to C:\Scripts\diagtools-install.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\DiagTools-Install.ps1" %*
exit /b %ERRORLEVEL%
