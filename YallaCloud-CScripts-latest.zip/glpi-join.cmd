@echo off
rem glpi-join [-Tenant <domain or infra.role>] [-Report] [-Status] [-Help]
rem Put this server in GLPI (https://glpi.oasisstack.io) with the estate GLPI kit. The agent
rem password comes from the environment: set GLPI_AGENT_PASSWORD=... on the line before.
rem Logs to C:\Scripts\glpi-join.log
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Glpi-Join.ps1" %*
exit /b %ERRORLEVEL%
