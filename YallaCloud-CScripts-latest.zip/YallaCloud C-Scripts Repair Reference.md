# YallaCloud C:\Scripts - Repair Programme Reference

Stamp: 2026-08-19 IST | payload v264 | catalog 2.8.0 | Session YC-ACR-REPAIR (20260815-1405) | ASCII-only

Scope: the golden-image command toolkit shipped as `C:\Scripts` on every YallaCloud
Windows VM (payload v263, sealed 2026-08-12 on WIN2016EFI). Audited, repaired and
extended over four waves. This document is the reference for what was wrong, what
changed, where it lives, and what still has to happen.

---

## 1. The one-paragraph verdict

The toolkit's problem was never syntax. All 51 original `.ps1` files parse cleanly under
Windows PowerShell 5.1 and are pure ASCII. The problem was that **nothing verified
anything**: scripts fired a vendor installer, printed the exit code as ordinary text, and
exited 0 regardless. A script that had never once worked was indistinguishable from one
that worked. The proof case is `Register-Acronis.ps1`, which passed an undocumented
`--log=` switch to the Acronis web installer; the installer rejected the entire command
line and exited in about four seconds having installed nothing, fourteen times over two
days, undetected. The project's own `_COMPLIANCE.txt` certified that script as PASS,
because it only checked for the presence of section headings and balanced here-strings.

---

## 2. Status scoreboard

| Class | Found | Closed | Open |
|---|---|---|---|
| P0 - cannot work, data loss, or security hole | 28 | 28 | 0 |
| P1 - wrong in a common case, or reports success when it failed | 32 | 28 | 4 |
| P2 - missing prerequisite, verification, or idempotency | 33 | 24 | 9 |

The remaining P1/P2 items are cosmetic or documentation-level and are listed in the
consolidated audit. Every defect that can compromise a fleet, brick a VM, lose data, or
silently do nothing is closed.

**Nothing is deployed.** Every repaired file is in the session folder only. The master
copies in AI-YALLACLOUD, `C:\Scripts` on live VMs, and the v263 payload are untouched.
See section 9.

---

## 3. Location

Everything produced by this programme is here:

```
C:\Users\BilalInamdarCloudHos\Documents\AI-YALLACLOUD\_sessions\20260815-1405_YC-ACR-REPAIR\
```

| Path | Contents |
|---|---|
| final-payload\ | the COMPLETE corrected payload, ready to promote: 58 .ps1, 48 .cmd, 5 answer-file templates, both unattend files, the changelog |
| YallaCloud-CScripts-final-payload.zip | the same thing as one archive |
| repaired-scripts\ | the repaired and new files only, without the untouched originals |
| repaired-scripts\sql-templates\ | five per-version SQL answer files and their notes |
| attachments\ | the original Acronis log, the wrapper, and the reported console screenshot |
| request-log.md | every request in this session, verbatim, with the action taken |

Reference documents live in the AI-YALLACLOUD root and are registered in the Master Index:

- `YallaCloud C-Scripts Audit.md` / `.html` - the full 93-finding audit
- `Acronis Agent - 0x627556 Install Failure Analysis.md` / `.html` - the proof case
- `YallaCloud C-Scripts Repair Reference.md` / `.html` - this document

---

## 4. The eight systemic patterns, and how each was closed

### 1. Fires an external command and never verifies the result
Closed by `Invoke-YcInstaller` in the shared library, which captures and decodes the exit
code, enforces a timeout, and flags a "success" that finished implausibly fast - the exact
signature of a rejected command line. Every install now ends in a post-condition:
`Assert-YcService`, `Assert-YcHttp`, or `Assert-YcFile`.

### 2. Unverified vendor command lines
Every external command line in the toolkit was re-checked against current vendor
documentation, and the doc URL recorded. Several were wrong: Acronis `--log=` (does not
exist), VMware Tools `/v "..."` with a space (the payload never reaches the embedded MSI),
`dism /featurename:SNMP` (not a real feature name), the windows_exporter `cs` collector
(removed upstream), the otelcol `processes` scraper (Linux only), and SQL Server
`FEATURES=...,CONN,BC,SDK` (removed after 2019).

### 3. Failure is unrepresentable
About twenty of the fifty-one scripts never called `Stop-YcLog`, so the transcript had no
`[END]` line and no exit code was recorded. Every exit path now closes the transcript and
records the code, either through `Exit-Yc` or through the equivalent `Stop-YcLog <n>; exit <n>`
pair that thirteen of the scripts use - the compliance gate accepts both and FAILs a bare
`exit`. The library also registers a `PowerShell.Exiting` engine handler so an unhandled
termination still closes the transcript. `Write-YcLog` now normalises a numeric level instead of silently filing an
error as INFO, and names the offending file and line once so it gets fixed.

### 4. Side effects committed before the thing they support exists
Firewall rules and scheduled tasks were created whether or not the install worked, which is
precisely what made a failed install look like a success during a spot check. Every side
effect is now gated behind a proven post-condition.

### 5. Secrets ride the command line into five readable places
The transcript header, the Application event log, 4688 process-creation events, generated
batch files, and machine environment variables. The library now hardens the `C:\Scripts`
ACL, redacts the transcript header in place, and provides `Protect-YcSecret`. Every script
that takes a credential gained a `-...File` parameter or an environment-variable path, and
no secret reaches a child process command line.

### 6. Build-VM state baked into the image and inherited by every clone
SSH host private keys, the builder's authorised key, the rearm marker, and a blank
Administrator password all survived sysprep. `doseal.cmd` now deletes them, and the
first-boot scripts key their markers to the machine SID so an image-baked marker can never
match a clone.

### 7. Three implementations, one library, no single source of truth
`Setup-YallaCloudExtras.ps1` overwrote the shared library with a dead API, and generated
command bodies calling functions that do not exist. The clobber is gone, the generated
bodies are ported to the real API, and duplicated SQL maintenance was deleted rather than
fixed twice - `Install-Sql.ps1` owns it.

### 8. The compliance report checks cosmetics, not behaviour
`_COMPLIANCE.txt` is replaced by `Yc-Compliance.ps1`, which generates its report live and
checks behaviour. Run against the v263 payload it exits 1 with 81 FAIL / 127 WARN / 31 INFO
across 93 files (51 .ps1, 42 .cmd), 24 of them blocking, and it catches the Acronis defect on
the exact line: VERIFY Register-Acronis.ps1:32 and SIDEEFFECT Register-Acronis.ps1:33.
(An earlier draft of this document said 107 FAIL across 94 files. That was wrong; the figure
above was re-measured. The WARN count was correct.)

---

## 5. What changed, wave by wave

### Wave 1 - fleet-compromise and brick risks

| File | Defect closed |
|---|---|
| doseal.cmd | seal no longer runnable on a production VM; verifies the answer file and sysprep before deleting anything; wipes key material; checks the sysprep exit code |
| SSH-FirstBoot.ps1 | host keys regenerated per clone, keyed to the machine SID |
| yc-keyguard.ps1 | builder key no longer baked or restored; refuses to bake on a build VM |
| Activate-Windows.ps1 | command injection removed; activation verified against licence status |
| A-Z-Deploy.ps1 | sshd config validated before restart; password proven; password out of the log |
| Rotate-Password.ps1 | same password handling and verification |
| Set-Firewall.ps1 | default reduced from about a thousand ports to RDP and SSH on the local subnet |
| Set-Nic.ps1 | validate before destroying; snapshot; dead-man rollback |
| Boot-Repair.ps1 | ESP constrained to the system disk; BCD backup; bootrec guarded |
| Setup-YallaCloudExtras.ps1 | single-hunk removal of the library clobber |

### Wave 2 - the library and the SQL chain

| File | Defect closed |
|---|---|
| _yc-lib.ps1 v2 | log-dir ACL, transcript redaction, numeric log levels, broken self-elevation, and eight missing helpers |
| Yc-Compliance.ps1 | replaces the fossil compliance report with a behaviour gate |
| Install-Sql.ps1 | version-correct FEATURES, real prerequisites, SSMS and client tools after, and a hard gate on backups |
| sql-templates (5) | five genuinely different per-version answer files |
| Activate-Sql.ps1 | edition change verified via SERVERPROPERTY |
| Dbatools-Install.ps1 | Server 2016 gallery bootstrap; result proven by import |
| SqlExporter-Register.ps1 | config validated, service proven, metrics endpoint proven |

### Wave 3 - the named focus list

| File | Defect closed |
|---|---|
| Register-Acronis.ps1 v3 | three documented argument forms with auto-retry; the accepted form is cached |
| Salt-Register.ps1 | missing `/default-config` added; registration proven against the master |
| Zabbix-Register.ps1 | created - it never existed, though the wrapper and catalog both advertised it |
| Bitdefender-Register.ps1 | command line completed so the kit cannot reboot mid-provision; check-in proven |
| Bitdefender-Exclude.ps1 / Defender-Exclude.ps1 | exclusions read back; refuse to exclude a user-writable directory on PATH |
| Collect-Logs.ps1 | created - thirteen collection groups, redacted, archive verified |
| Set-S3Config.ps1 / Transfer-S3.ps1 | created - DPAPI secret at rest, SigV4, every upload proven by a HEAD |
| Backup-Sql.ps1 | created - always checksummed, always verified, proven against msdb |
| deploy-bytebase.sh / Set-BytebaseClient.ps1 | created - see section 8 |

### Wave 4 - everything remaining

| File | Defect closed |
|---|---|
| yc-firstboot.ps1 | the task can now retire; dead YCNET dependency removed; rearm proven; blank-password alarm |
| Unattend-Seal.xml | SkipRearm cleared on the final seal; blank Administrator password removed |
| Unattend-Seal-Iterative.xml | created - the intermediate seal, clearly labelled |
| userdata-set-admin.yaml / userdata-deploy-example.txt | no secrets in guest-readable metadata |
| Setup-Observability.ps1 | Alloy config parses; duplicated SQL maintenance deleted; audit forwarding opt-in |
| Alloy / Otelcol / Telegraf / WinExporter | vendor validators run before any service is touched |
| MysqldExporter / PostgresExporter | wrapped in WinSW because neither binary can be a service; DSN out of the machine environment |
| Install-VMwareTools.ps1 | silent switch fixed; gated on actually running on VMware |
| Snmp-Register.ps1 | managers mandatory, default community refused, scoped rule |
| Osquery-Register.ps1 | enrolment proven; enroll.secret locked and the ACL read back |
| Root-Cause.ps1 | debugger behind a switch, bounded by a timeout, single-instance |
| WebJEA-Install.ps1 / OliveTin-Install.ps1 | see section 8 |
| Setup-YallaCloudExtras.ps1 | generated command bodies ported to the real library API |
| Yallacloud.ps1 | catalog reconciled - every advertised command now resolves |
| _COMPLIANCE.txt | replaced by a deprecation stub pointing at yc-compliance |

---

## 6. New commands added

| Command | What it does |
|---|---|
| yc-compliance | behaviour gate over the payload; non-zero exit blocks a build |
| collect-logs | one portable, redacted diagnostic archive for support |
| set-s3config | stores and live-tests an S3-compatible endpoint; secret at rest under DPAPI |
| transfer-s3 | upload and download with multipart, retries, and proof by HEAD |
| backup-sql | verified SQL backups with optional S3 offload |
| zabbix-register | the command the catalog always advertised but never shipped |
| set-bytebaseclient | configures Windows access to a Bytebase server |

---

## 7. The shared library, `_yc-lib.ps1` v2

A backward-compatible superset - twenty-four functions, dot-sources with no output. The
existing corpus calls seven of them (`Start-YcLog`, `Write-YcLog`, `Stop-YcLog`,
`Assert-YcPrereqs`, `Write-YcEvent`, `Test-YcInternet`, `Test-YcAdmin`); all seven are
preserved with compatible signatures, so no existing caller breaks.

| Function | Contract |
|---|---|
| Start-YcLog | opens the transcript, hardens the log directory ACL, redacts the header |
| Write-YcLog | logs at INFO, OK, WARN or ERROR; normalises a numeric level and names the caller |
| Stop-YcLog | writes the END line and closes the transcript; idempotent |
| Exit-Yc | the single exit path - log, close, exit |
| Assert-YcPrereqs | admin and internet preconditions; self-elevation now propagates the child exit code |
| Assert-YcService | a service exists and reaches Running within a timeout |
| Invoke-YcInstaller | runs an installer, decodes the exit code, redacts the arguments, flags a fast success |
| Get-YcFile | download with TLS, retry, optional hash, and a magic-byte check |
| Assert-YcHttp | an endpoint answers with the expected status within a timeout |
| Assert-YcFile | a file exists, is big enough, and optionally is validly signed |
| Protect-YcSecret | redacts secrets from a string before it is logged |
| Test-YcWorldOpen | true when a remote-address list is world-open (Any, *, 0.0.0.0/0, ::/0, Internet) |
| Write-YcInvocation | logs the command line with secrets redacted; called by 16 commands |
| Set-YcTls | forces TLS 1.2+ before any download; called by 8 commands |
| Test-YcInternet | non-fatal outbound reachability probe |
| Test-YcAdmin | non-fatal elevation probe |
| Test-YcService | non-fatal service-state probe |
| Write-YcEvent | writes to the Application log, source YallaCloud |
| Write-YcRedacted | rewrites a log file in place with secrets masked at identical byte length |
| Protect-YcLogDir | hardens the log directory ACL to SYSTEM + Administrators, and verifies it |
| Get-YcExitMeaning | decodes an installer exit code to a human meaning |
| Get-YcFileKind | magic-byte identification of a downloaded file |
| Initialize-YcEvent | registers the event-log source once per process |
| ConvertTo-YcLevel | normalises a numeric or unrecognised log level |

Fixing this file once fixes fifty callers. That is why it was the first thing built in
Wave 2.

---

## 8. Decisions taken, and why

**WebJEA is not safe to ship enabled.** Its access-control model requires Active Directory,
and a stock tenant VM is workgroup. The command now refuses to run without an explicit
acknowledgement switch, a certificate thumbprint, and a management CIDR; it creates no HTTP
binding, and it fails if an anonymous request is not rejected. It must never run during an
unattended image build.

**OliveTin has no TLS at all**, and its documented default policy permits an
unauthenticated guest to execute every action. The old script combined that with LocalSystem
and an unscoped firewall rule - unauthenticated remote code execution as SYSTEM. It now
binds loopback, creates no firewall rule, runs as LocalService, and refuses remote exposure
unless the config actually authenticates someone.

**Bytebase has no Windows deployment.** The published image manifests are linux/amd64 and
linux/arm64 only, so the deliverable is a Linux Docker deployment script plus a Windows
client-configuration command. Bytebase is also dual-licensed: the Enterprise licence covers
any code controlling feature, permission, role and plan enablement, so production use and
redistribution need a subscription, and the Community edition has neither SSO nor an audit
log. The recommended pattern is one instance per tenant on the tenant's own licence.

**set-admin-console was deleted, not written.** Nothing but the answer file and the catalog
ever referenced it. A missing RunSynchronousCommand target fails the specialize pass on
every clone, so the reference was removed rather than a security-relevant script invented to
satisfy it. The supported path already ships as the userdata example.

**Microsoft no longer publishes a SQL Server 2016 parameter reference.** SQL 2016 left
extended support on 2026-07-14 and the documentation now redirects. The 2016 template is
verified against surviving per-parameter annotations, and the caveat is recorded in the
template notes.

---

## 9. What still has to happen

Nothing here is live. The repaired files sit in the session folder by explicit instruction.
This matters more than any single fix, because the Acronis case was exactly this: a correct
fix existed from 2026-08-03 and the VM still failed fourteen times, because the fix never
reached the machine.

Suggested order:

1. Diff each repaired file against its master before promoting anything.
2. Promote the shared library first. Everything else depends on it, and it is the one file
   whose absence or API mismatch breaks every command.
3. Run the compliance gate and require a zero exit. Against a staging folder holding only
   part of the payload, add `-PartialPayload`, or wrapper and catalog completeness findings
   fire for files that are simply not in that folder yet:

```
powershell -NoProfile -ExecutionPolicy Bypass -File C:\Scripts\Yc-Compliance.ps1 -Path C:\build\staging -PartialPayload
```

   Against the complete payload, drop the switch - that is the run that certifies:

```
powershell -NoProfile -ExecutionPolicy Bypass -File C:\Scripts\Yc-Compliance.ps1 -Path C:\Scripts
```

4. Push to `C:\Scripts` on live VMs, then bake into the golden image. A fix that reaches
   only one of those two places will regress on the next deploy.
5. Two behaviour changes will be visible immediately and should be communicated:
   `set-firewall` with no arguments now opens far less than before, and a `set-nic` address
   change self-reverts within five minutes unless confirmed with a commit.
6. Rotate the Acronis registration token. It is in clear text in the W16E transcript header,
   which PowerShell writes itself and no script can mask.

---

## 10. Verification evidence

Every claim below was executed, not asserted.

- All original scripts and all repaired scripts were parsed with the real Windows PowerShell
  5.1 tokenizer on the workstation, not PowerShell 7. Version observed: 5.1.26100.9168.
- Every delivered file was byte-scanned; zero bytes above 0x7F in all of them.
- The v2 library was dot-sourced under 5.1: twenty-three functions defined, zero output
  objects, every v1 name present.
- The compliance gate was run against the v263 scripts folder: exit 1, 81 FAIL, 127 WARN and
  31 INFO across 93 files, 24 files blocking, and it flags the original Register-Acronis.ps1
  at line 32 for running an installer without proving it worked and at line 33 for creating
  firewall rules with no preceding success check. Re-run against the corrected payload it
  reports 28 FAIL, all of them in seven scripts that no repair wave touched (see section 12).
- Vendor command lines were verified against vendor documentation, with the URL recorded in
  each script header.

---

## 11. Document register

| Document | Purpose |
|---|---|
| YallaCloud C-Scripts Audit | the full 93-finding audit with line numbers |
| Acronis Agent - 0x627556 Install Failure Analysis | the proof case that started the programme |
| YallaCloud C-Scripts Repair Reference | this document |
| repaired-scripts\sql-templates\TEMPLATE-NOTES.md | per-version SQL parameter decisions |
| repaired-scripts\BYTEBASE-NOTES.md | Bytebase deployment, licensing and upgrade notes |

---

## 12. Residual defects, stated plainly

**The corrected payload now passes its own gate: exit 0, no blocking defect**, verified under
genuine Windows PowerShell 5.1.26100.9168 in full-payload mode (not `-PartialPayload`).

It did not start that way. The first full run showed **28 FAIL** across seven scripts that no
repair wave had touched - `Wazuh-Register.ps1` (6), `GLPI-Register.ps1` (5),
`Site24x7-Register.ps1` (5), `DiagTools-Install.ps1` (4), `Report-Inventory.ps1` (4),
`Diag-System.ps1` (2), `Grow-Disk.ps1` (2) - all of the same class as the original Acronis
defect: `Start-YcLog` with no `Stop-YcLog`, a bare `exit`, and an installer run with no
verification. All seven were then closed, and every vendor command line in the three agent
registrations was verified against current vendor documentation with the URL recorded in the
file header.

Three limits are disclosed rather than hidden:

- **Site24x7's device key cannot be kept off the installer command line.** The vendor provides
  no file or environment alternative to the `EDITA1` property. `-DeviceKeyFile` keeps it out of
  shell history and out of the log, but it remains visible in the process table and in 4688
  events for the life of the install. Stated in the script header and the wrapper.
- **Site24x7 and Wazuh server-side confirmation is not performed**, because it needs vendor API
  credentials these commands deliberately do not take. Everything provable locally is proved.
  For Wazuh that includes `client.keys`, which the manager grants - real evidence, not a local
  assumption.
- **The GLPI service name is discovered, not asserted**, because the vendor documents it as
  configurable and does not publish the default. Hard-coding it would have been exactly the kind
  of guess that caused the Acronis incident.

Two defects worth remembering, both found only because the payload was re-reviewed after it was
declared finished:

- `Day2-Setup.ps1` regenerated nineteen files into `C:\Scripts` with an unconditional
  `Set-Content`, twelve of them repaired scripts, and the Acronis body it wrote still carried the
  `--log=` switch. Running it on a repaired VM restored the original defect byte for byte. It now
  refuses to overwrite an existing file without `-Regenerate`, the switch is gone, and the Day2
  README opens with that warning.
- `Setup-YallaCloudExtras.ps1` carried an anti-clobber guard that was inert in the only case that
  mattered: run from `C:\Scripts`, source and destination were the same path, the guard evaluated
  false, and it overwrote the hardened script with a smaller generated body - for WebJEA that
  meant a plain HTTP binding on a console that executes PowerShell. Fixed.

### A note on the verification harness itself

An earlier `-Help` execution test in this programme reported "all 41 returned 0". It had not:
`Start-Process -PassThru` plus `WaitForExit(milliseconds)` leaves `ExitCode` unpopulated, so the
harness collected nulls and compared them against `'0'`. Nothing was proven by that run. It is
recorded here because a verification harness that reports success without measuring anything is
the identical failure mode this whole programme exists to eliminate - and it happened inside the
programme.

---

## 13. Correction pass, 2026-08-19

- Catalog `Yallacloud.ps1` bumped to **2.8.0**, payload to **v264**.
- Five wrappers that were never shipped now exist: `set-firewall.cmd`, `set-nic.cmd`,
  `rotate-password.cmd`, `activate-windows.cmd`, `boot-repair.cmd`. The first documented
  `-ExtraTcp` / `-ExtraUdp`, which the repaired script renamed to `-ExtraTcpIn` / `-ExtraUdpIn` -
  the old names throw before `Start-YcLog` runs, so there was no log to diagnose from.
- Catalog completeness now **blocks** in the gate's full mode. It previously printed a banner
  claiming it blocked while hard-coding those findings to WARN.
- `SSH-FirstBoot.ps1` now verifies its scheduled task was actually removed. It previously
  printed success unconditionally; a failed removal regenerates the SSH host keys at every
  boot, so every client sees a changed host key while the log says the task is gone.
- Six unreachable exit codes removed from help blocks, one undocumented code added, and three
  scripts that had no EXIT CODES section gained one.
- `CHANGELOG-repair.txt` added - one section per wave, one line per file, naming the defect
  each change closed.
- Wave 6 closed the last seven never-repaired scripts, taking the gate to exit 0.
- A live library-level bug fixed in six places: `[string]$null` evaluates to `$null`, not `''`,
  so the corpus idiom `([string](Get-Content -Raw <file>)).Trim()` THREW on an empty file instead
  of reporting that the file was empty. Affected the enroll-secret and marker-file readers in
  `Osquery-Register.ps1`, `Register-Acronis.ps1`, `SSH-FirstBoot.ps1`, `yc-firstboot.ps1` (twice)
  and `yc-keyguard.ps1`.
