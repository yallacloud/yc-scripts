@echo off
setlocal
rem ================================================================================================
rem install-sql - unattended SQL Server EVALUATION install + patch + client tooling + configuration
rem               + VERIFIED Ola Hallengren backups.  Wrapper for C:\Scripts\Install-Sql.ps1.
rem
rem WHAT CHANGED, AND WHY:
rem   - The usage comment now lists every parameter, including the ones the old wrapper omitted
rem     (-ChadminPassword, -Edition) and the many new ones.
rem   - It no longer advertises -SaPassword as the normal way to set the sa password. Anything on
rem     this command line is readable by any local user through the process table, and in the
rem     cloud-init path it also sits in CloudStack user-data. Use -SaPasswordFile instead.
rem   - Explicit "exit /b %ERRORLEVEL%" so the real exit code reaches cloud-init / the RMM instead
rem     of relying on cmd's implicit propagation.
rem
rem THE ONLY COMMAND MOST PEOPLE NEED:
rem
rem   install-sql -Version 2019
rem
rem That is the whole thing. Engine, patching, ODBC/OLE DB/sqlcmd, SSMS, firewall, tuning, verified
rem Ola Hallengren backups and their scheduled tasks. It reboots if it has to and carries on by
rem itself afterwards. It exits non-zero if any of that could not be PROVED.
rem
rem Second command, for a change window where YOU want to do the restart:
rem
rem   install-sql -Version 2019 -NoReboot
rem
rem Everything below is an override for a case where the defaults are wrong. If you do not know
rem that you need one, you do not need one.
rem
rem USAGE:
rem   install-sql -Version <2016|2017|2019|2022|2025> [options]
rem   install-sql -Help
rem
rem CORE OPTIONS:
rem   -Version <2016|2017|2019|2022|2025>   -Edition Evaluation      -InstanceName <name>
rem   -Features <comma list>                -DataDir <path>          -BackupDir <path>
rem   -IsoPath <path>                       -WorkDir <path>          -Collation <name>
rem   -SysadminAccounts <a,b>               -Maintenance on|off      -Help
rem   -Unattended is accepted but no longer needed: supplying any parameter already suppresses the
rem   prompts. -AllowReboot is accepted but no longer needed: rebooting is the default.
rem
rem SECRETS (prefer the file form - a command line is world-readable on this machine):
rem   -SaPasswordFile <path>    file whose first line is the sa password    (PREFERRED)
rem   -SaPassword <pwd>         accepted for compatibility, but visible in the process table
rem   -ChadminPassword <pwd>    only needed when S4U batch logon is blocked by policy on the image
rem
rem AFTER-THE-ENGINE OPTIONS (the "requires ssms after" half):
rem   -ClientTools on|off   ODBC Driver 18 + OLE DB Driver 19 + sqlcmd/bcp + SqlServer PS module
rem   -Ssms on|off          -SsmsVersion auto|22|21|20
rem   -Patch on|off         -CuPath <staged CU exe>
rem
rem INSTANCE / NETWORK OPTIONS:
rem   -Port <n>             -ManagementCidr <cidr[,cidr]>   -Firewall on|off
rem   -MaxDop <n>           -MaxServerMemoryMB <n>          -CostThreshold <n>
rem   -TempDbFileCount <n>  -TempDbFileSizeMB <n>
rem   -InstantFileInit on|off   -LockPagesInMemory on|off   -PowerPlan on|off
rem   -OlaZipPath <zip>     -LogBackupMinutes <n>
rem   -NoReboot (= -ManualReboot)           -KeepMedia               -Force
rem     REBOOTING IS THE DEFAULT. When a reboot is genuinely required the run restarts the machine
rem     and RESUMES ITSELF afterwards via a SYSTEM startup task, so a first-boot install finishes on
rem     its own. -NoReboot turns that off: the run stops instead and records the reason in
rem     C:\Scripts\install-sql.reboot-required, for a change window where you restart by hand.
rem     The automatic resume is skipped, with a WARN, if -SaPassword or -ChadminPassword was passed
rem     in plaintext, because the task definition would persist it - use -SaPasswordFile instead.
rem
rem EXIT CODES: 0 ok | 1 generic | 2 preflight refused | 3 media | 4 setup | 5 not admin |
rem             6 no internet | 7 sqlcmd missing | 8 engine verification | 9 backups not installed |
rem             10 final verification | 99 unhandled
rem
rem Logs to C:\Scripts\install-sql.log (and the Application event log, source YallaCloud).
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Install-Sql.ps1" %*
exit /b %ERRORLEVEL%
