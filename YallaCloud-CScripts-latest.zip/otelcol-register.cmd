@echo off
setlocal
rem ================================================================================================
rem otelcol-register - install otelcol-contrib as a Windows service, validate the config with
rem                    'otelcol-contrib validate --config=', and prove the collector serves its own
rem                    telemetry.  Wrapper for C:\Scripts\Otelcol-Register.ps1.
rem
rem WHAT CHANGED, AND WHY:
rem   - Added "exit /b %ERRORLEVEL%": the old wrapper swallowed the exit code.
rem   - The script now refuses a config containing the hostmetrics "processes" scraper, which is
rem     Linux/Mac/FreeBSD/OpenBSD only and makes the collector fail at startup on Windows.
rem   - One service name only (otelcol-contrib). Setup-Observability no longer creates a second
rem     collector called YC-OtelCollector from the same binary.
rem   - An OTLP Authorization header belongs INSIDE the config file, never on this command line.
rem
rem USAGE:
rem   otelcol-register -ConfigFile <C:\path\config.yaml>
rem   otelcol-register -ConfigUrl <http-url-to-config.yaml> [-Sha256 <hash>]
rem   otelcol-register -Help
rem
rem NOTE: no inbound port is opened. If your config defines OTLP receivers that must accept traffic,
rem       add a SCOPED inbound rule yourself.
rem
rem EXIT CODES: 0 verified | 1 failed | 2 usage | 5 not elevated | 6 no internet
rem Log: C:\Scripts\otelcol-register.log
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Otelcol-Register.ps1" %*
exit /b %ERRORLEVEL%
