param(
  [ValidateRange(8,16)][int]$Length = 16,
  [ValidateRange(1,100)][int]$Count = 1,
  [switch]$SelfCheck,
  [switch]$Help
)
# =====================================================================================
# PassGen.ps1 - generate a password to the YallaCloud rule. PowerShell 5.1. ASCII only.
#
# THE RULE, stated by Bilal 2026-09-08. These are requirements, not preferences:
#   length 8 to 16
#   FIRST character is always A-Z            (uppercase)
#   LAST character is always a-z             (lowercase)
#   at least TWO '#'                         ('#' is the ONLY symbol used)
#   at least one digit
#   uppercase and lowercase both present     (the first and last already guarantee this)
#
# WHY '#' AND NOTHING ELSE
#   A password here crosses PowerShell single quotes in CloudStack user data, JSON, a
#   cmd.exe command line to install-sql, sqlcmd, and finally a human reading it off a
#   handover sheet. '#' is the one punctuation mark that means nothing to any of them.
#   Every other symbol is special somewhere: ' " ` $ \ % & | < > ^ ! / and space each
#   break one of those layers, and a password that breaks quoting fails LATE - the VM
#   builds for forty minutes and then cannot log in, with an error that blames SQL.
#
# FIRST UPPER AND LAST LOWER ARE NOT DECORATION
#   They make the password unambiguous to read back over a phone, and they satisfy
#   Windows complexity and SQL Server's three-of-four policy by construction rather than
#   by luck, so a generated password can never be rejected at the moment it is used.
#
# ALSO EXCLUDED: O 0 o I l 1. Not part of the stated rule - added because these are read
#   aloud and typed by hand off a handover sheet, and O/0 and I/l/1 are the pair everyone
#   gets wrong. Say the word and they go back in; nothing else depends on it.
#
# RANDOMNESS: RNGCryptoServiceProvider with rejection sampling, NOT Get-Random.
#   Get-Random is a clock-seeded Mersenne Twister - two VMs built in the same second can
#   produce the SAME password, and this is used by unattended fleet builds.
#
# EXIT CODES  0 generated   1 selfcheck failed   2 usage
# =====================================================================================
$ErrorActionPreference = 'Stop'

$HelpText = @"
passgen - generate a password to the YallaCloud rule.

  passgen                 one 16-character password
  passgen -Length 12      any length from 8 to 16
  passgen -Count 10       ten of them, one per line
  passgen -SelfCheck      assertions only, changes nothing
  passgen -Help

THE RULE
  8 to 16 characters
  first character A-Z, last character a-z
  at least two '#'  ('#' is the only symbol - every other one is special to PowerShell,
                     cmd, JSON or sqlcmd somewhere along the way)
  at least one digit
  O 0 o I l 1 are left out so it can be read aloud without being misheard
"@
if ($Help) { Write-Output $HelpText; exit 0 }

$YcUpper = 'ABCDEFGHJKLMNPQRSTUVWXYZ'      # no O, no I
$YcLower = 'abcdefghijkmnpqrstuvwxyz'      # no o, no l
$YcDigit = '23456789'                      # no 0, no 1
$YcHash  = '#'
$YcFill  = $YcUpper + $YcLower + $YcDigit + $YcHash

function Get-YcRandomInt {
  # Unbiased below $Max. A random byte modulo Max is skewed toward the low values
  # whenever 256 is not a multiple of Max, which for a 24-letter alphabet means the
  # early letters turn up measurably more often.
  param([int]$Max)
  $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
  try {
    $b = New-Object byte[] 4
    $limit = [uint32]([math]::Floor([uint32]::MaxValue / $Max) * $Max)
    while ($true) {
      $rng.GetBytes($b)
      $v = [BitConverter]::ToUInt32($b, 0)
      if ($v -lt $limit) { return [int]($v % $Max) }
    }
  } finally { $rng.Dispose() }
}

function Get-YcPassword {
  param([int]$Length = 16)
  if ($Length -lt 8 -or $Length -gt 16) { throw 'length must be 8 to 16' }

  # The two ends are fixed by the rule, so only the middle is free. At length 8 that
  # leaves 6 free slots for 2 '#' and 1 digit - comfortable, but the arithmetic is worth
  # stating because a shorter minimum would silently make the rule unsatisfiable.
  $mid = New-Object 'string[]' ($Length - 2)
  $free = 0..($Length - 3)

  # place the two required '#' first, at distinct positions
  for ($n = 0; $n -lt 2; $n++) {
    $pick = $free[(Get-YcRandomInt $free.Count)]
    $mid[$pick] = $YcHash
    $free = @($free | Where-Object { $_ -ne $pick })
  }
  # then the required digit
  $pick = $free[(Get-YcRandomInt $free.Count)]
  $mid[$pick] = $YcDigit[(Get-YcRandomInt $YcDigit.Length)]
  $free = @($free | Where-Object { $_ -ne $pick })
  # then everything else
  foreach ($i in $free) { $mid[$i] = $YcFill[(Get-YcRandomInt $YcFill.Length)] }

  return ($YcUpper[(Get-YcRandomInt $YcUpper.Length)] + (-join $mid) + $YcLower[(Get-YcRandomInt $YcLower.Length)])
}

function Test-YcPasswordRule {
  # The rule, in one place, so the generator and the check cannot drift apart.
  # -cmatch everywhere: PowerShell's -match is CASE-INSENSITIVE, and every clause here
  # is about case. Using -match would make 'first char is A-Z' pass for a lowercase one.
  param([string]$P)
  if ($P.Length -lt 8 -or $P.Length -gt 16)            { return $false }
  if ($P[0] -cnotmatch '[A-Z]')                        { return $false }
  if ($P[$P.Length - 1] -cnotmatch '[a-z]')            { return $false }
  if (([regex]::Matches($P, '#')).Count -lt 2)         { return $false }
  if ($P -cnotmatch '[0-9]')                           { return $false }
  if ($P -cnotmatch '[a-z]' -or $P -cnotmatch '[A-Z]') { return $false }
  if ($P -cmatch '[^A-Za-z0-9#]')                      { return $false }
  return $true
}

function Test-YcLengthRefused {
  # try/catch is a STATEMENT, not an expression, so it cannot sit inside a condition.
  param([int]$Length)
  try { [void](Get-YcPassword -Length $Length); return $false } catch { return $true }
}

if ($SelfCheck) {
  $pass = 0; $fail = 0
  function T($n, $c) { if ($c) { Write-Output ('ok   ' + $n); $script:pass++ } else { Write-Output ('FAIL ' + $n); $script:fail++ } }

  $many = 1..400 | ForEach-Object { Get-YcPassword -Length 16 }
  T '400 obey the whole rule'    (@($many | Where-Object { -not (Test-YcPasswordRule $_) }).Count -eq 0)
  T '400 start uppercase'        (@($many | Where-Object { $_[0] -cnotmatch '[A-Z]' }).Count -eq 0)
  T '400 end lowercase'          (@($many | Where-Object { $_[$_.Length-1] -cnotmatch '[a-z]' }).Count -eq 0)
  T '400 have 2+ hashes'         (@($many | Where-Object { ([regex]::Matches($_, '#')).Count -lt 2 }).Count -eq 0)
  T '400 have a digit'           (@($many | Where-Object { $_ -cnotmatch '[0-9]' }).Count -eq 0)
  T '400 use ONLY A-Za-z0-9#'    (@($many | Where-Object { $_ -cmatch '[^A-Za-z0-9#]' }).Count -eq 0)
  T '400 avoid O 0 o I l 1'      (@($many | Where-Object { $_ -cmatch '[O0oIl1]' }).Count -eq 0)
  T '400 are all different'      ((($many | Sort-Object -Unique).Count) -eq 400)

  # every length must still satisfy a rule that needs 5 of the characters
  foreach ($n in 8, 9, 10, 12, 14, 16) {
    $set = 1..60 | ForEach-Object { Get-YcPassword -Length $n }
    T ('length ' + $n + ' honoured and legal') (@($set | Where-Object { $_.Length -ne $n -or -not (Test-YcPasswordRule $_) }).Count -eq 0)
  }
  T 'length 7 is refused'        (Test-YcLengthRefused 7)
  T 'length 17 is refused'       (Test-YcLengthRefused 17)

  # the hashes must not always land in the same place
  $hashPos = @{}
  foreach ($p in $many) { for ($i = 0; $i -lt $p.Length; $i++) { if ($p[$i] -eq '#') { $hashPos[$i] = 1 + $hashPos[$i] } } }
  T 'hash positions vary'        ($hashPos.Keys.Count -ge 10)
  T 'hash never first or last'   (-not $hashPos.ContainsKey(0)) 

  # the checker must actually reject things, or the 400 tests above prove nothing
  T 'rejects lowercase start'    (-not (Test-YcPasswordRule 'aBcd#e#2x'))
  T 'rejects uppercase end'      (-not (Test-YcPasswordRule 'Abcd#e#2X'))
  T 'rejects one hash'           (-not (Test-YcPasswordRule 'Abcd#ef2x'))
  T 'rejects no digit'           (-not (Test-YcPasswordRule 'Abcd#e#fx'))
  T 'rejects a foreign symbol'   (-not (Test-YcPasswordRule 'Abcd#e#2!x'))
  T 'rejects too short'          (-not (Test-YcPasswordRule 'Ab#c#2x'))
  T 'accepts a valid one'        (Test-YcPasswordRule 'Abcd#e#2x')

  Write-Output ''
  Write-Output ('SelfCheck: ' + $pass + ' passed, ' + $fail + ' failed')
  if ($fail -gt 0) { exit 1 } else { exit 0 }
}

for ($i = 1; $i -le $Count; $i++) { Write-Output (Get-YcPassword -Length $Length) }
exit 0
