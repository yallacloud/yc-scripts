@echo off
rem install-office - install Office Standard or standalone Excel unattended, and PROVE which
rem   edition landed. Licensing is optional and separate.
rem
rem   install-office -Product Office2019Standard          Office Standard 2019
rem   install-office -Product Office2021Standard          Office LTSC Standard 2021
rem   install-office -Product Excel2019Standard           Excel 2019 volume
rem   install-office -Product Excel2021Standard           Excel LTSC 2021 volume
rem   install-office -Product Office2016Standard -MediaPath D:\    Office Standard 2016
rem   install-office -Product Excel2016Standard  -MediaPath D:\    Excel 2016
rem
rem   -ProductKey XXXXX-XXXXX-XXXXX-XXXXX-XXXXX   license it too (ospp.vbs), key masked in logs
rem   -Architecture 64^|32   -Language en-us   -DownloadOnly   -Uninstall   -Force
rem   -SelfCheck            built-in assertions, changes nothing
rem   -Help
rem
rem WHY 2016 NEEDS -MediaPath AND 2019/2021 DO NOT: Office Standard 2016 and Excel 2016 volume
rem   are Windows Installer products. There is no Click-to-Run volume build of either, so the
rem   Office Deployment Tool has no Product ID for them and cannot download them - the ISO
rem   comes from VLSC / CSP / SPLA. Office 2019 and 2021 volume ARE Click-to-Run (channels
rem   PerpetualVL2019 / PerpetualVL2021) and stream from Microsoft's CDN.
rem
rem EXIT CODES: 0 verified, 1 install/verify failed, 2 usage or no media for a 2016 SKU,
rem   3 media download failed, 4 required file missing, 5 not elevated, 6 no internet,
rem   7 installed and verified but activation did not report ---LICENSED---.
rem Log: C:\Scripts\install-office.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Install-Office.ps1" %*
exit /b %ERRORLEVEL%
