# =============================================================
# Rotate-Password.ps1  v2.0  (2026-08-16)
# YALLACLOUD - set/rotate a local account password (optionally the built-in
# Administrator) on a golden-image clone. Unattended-safe (cloud-init/SYSTEM/RMM).
#
# WHAT CHANGED IN v2.0 (and WHY)
#   1. P0-12 SECRET LEAK: the cleartext password was printed with Write-Host
#      ("NEWPASSWORD=...") while Start-Transcript was live, so every password
#      ever rotated on this VM was appended permanently to
#      C:\Scripts\rotate-password.log. Anything passed to Write-YcLog is also
#      mirrored into the Windows Application event log under source 'YallaCloud'
#      (readable by the Event Log Readers group and shipped to the tenant SIEM).
#      The password is now NEVER passed to Write-YcLog, and the single Write-Host
#      that emits it is wrapped in Stop-Transcript / Start-Transcript so it goes
#      to the console/RMM stdout only and never lands on disk.
#   2. P0-14 A PASSWORD THAT IS NOT THE ACCOUNT'S PASSWORD: New-StrongPw used
#      Get-Random (not a CSPRNG) over one flat alphabet with no guaranteed class
#      coverage, so a generated value could contain no digit or no symbol and be
#      rejected by the Windows complexity policy. Set-LocalUser ran without
#      -ErrorAction Stop and PasswordNeverExpires used -EA SilentlyContinue, so
#      failures were swallowed and the script still printed "OK: password
#      rotated" plus a password that did not work. Now: a CSPRNG generator that
#      guarantees one upper + one lower + one digit + one cmd-safe symbol,
#      Set-LocalUser -ErrorAction Stop, and the result is PROVEN with
#      PrincipalContext.ValidateCredentials before anything is reported as OK.
#   3. The password never reaches the command line of a child process (visible in
#      the process table and in Windows 4688 audit events). net.exe /active:yes
#      is replaced by Enable-LocalUser; Set-LocalUser takes a SecureString.
#   4. Every exit path now calls Stop-YcLog <code> before "exit <code>" - the
#      help block and the two early error paths previously exited with the
#      transcript still running and no [END] record.
#   5. The built-in Administrator is resolved by well-known RID -500, so a
#      renamed Administrator account is still targeted correctly.
#
# PowerShell 5.1 only. ASCII only. Windows Server 2016-2025. Idempotent.
# =============================================================
param([string]$User,[string]$Password,[switch]$Administrator,[switch]$Random,[int]$Length=20,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'rotate-password'
$ErrorActionPreference='Continue'

if($Help -or (-not $User -and -not $Administrator)){
@'
rotate-password  -  set/rotate a local account password (optionally the built-in Administrator).
USAGE:
  rotate-password -User <name> -Password "P@ss#1$x"
  rotate-password -Administrator -Password "P@ss#1$x"
  rotate-password -Administrator -Random
  rotate-password -Help
PARAMETERS:
  -User           Local user account to update.
  -Password       New password (double-quote; @ # ! $ are literal).
  -Administrator  Target the built-in Administrator account (and enable it).
  -Random         Generate a strong random password.
  -Length         Length for -Random (default 20, minimum 14).
  -Help           Show this help and exit.
EXAMPLES:
  rotate-password -User admin -Password "P@ss#1x"
  rotate-password -Administrator -Random
  rotate-password -Help
OUTPUT:
  On success the new password is written to STDOUT once as   NEWPASSWORD=<value>
  It is deliberately NOT written to the log file and NOT written to the Windows
  event log. Capture it from the console / RMM output.
EXIT CODES:
  0 rotated and verified   1 usage error   2 user not found
  3 password could not be set or failed verification   5 not elevated
Log: C:\Scripts\rotate-password.log   (the password is NOT in this file)
'@ | Write-Host -ForegroundColor Cyan
  if($Help){ Stop-YcLog 0; exit 0 } else { Stop-YcLog 1; exit 1 }
}

Assert-YcPrereqs -NeedAdmin

$YcLogPath = $script:YcLogFile
if(-not $YcLogPath){ $YcLogPath = 'C:\Scripts\rotate-password.log' }

# Unbiased index in [0,$Count) from a CSPRNG. Get-Random is not
# cryptographically secure and "(Get-Random) % n" is modulo-biased.
function Get-YcRandomIndex{
  param($Rng,[int]$Count)
  $bytes = New-Object 'byte[]' 2
  $max = 65536 - (65536 % $Count)
  do{
    $Rng.GetBytes($bytes)
    $v = ([int]$bytes[0] * 256) + [int]$bytes[1]
  } while($v -ge $max)
  return ($v % $Count)
}

# Strong password that is GUARANTEED to satisfy the Windows complexity policy
# (3 of 4 categories required; we always supply all 4) and that avoids every
# character that breaks cmd/batch quoting or PowerShell expansion:
#   excluded: " ' ` $ % & | < > ^ ( ) ! , ; = [ ] { } \ and space
# Look-alike characters (0 O o 1 l I) are excluded so an operator can retype it.
function New-YcStrongPassword{
  param([int]$Length = 20)
  if($Length -lt 14){ $Length = 14 }
  if($Length -gt 120){ $Length = 120 }
  $upper  = 'ABCDEFGHJKLMNPQRSTUVWXYZ'
  $lower  = 'abcdefghijkmnpqrstuvwxyz'
  $digit  = '23456789'
  $symbol = '#*-._+?@~'
  $all    = $upper + $lower + $digit + $symbol
  $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
  try{
    $chars = New-Object 'System.Collections.Generic.List[char]'
    foreach($set in @($upper,$lower,$digit,$symbol)){
      $chars.Add($set[(Get-YcRandomIndex $rng $set.Length)])
    }
    while($chars.Count -lt $Length){
      $chars.Add($all[(Get-YcRandomIndex $rng $all.Length)])
    }
    for($i = $chars.Count - 1; $i -gt 0; $i--){
      $j = Get-YcRandomIndex $rng ($i + 1)
      $t = $chars[$i]; $chars[$i] = $chars[$j]; $chars[$j] = $t
    }
    # Keep a letter first so the value is never mistaken for a switch by a
    # wrapper that forwards it unquoted.
    if("$($chars[0])" -notmatch '[A-Za-z]'){
      for($i = 1; $i -lt $chars.Count; $i++){
        if("$($chars[$i])" -match '[A-Za-z]'){
          $t = $chars[0]; $chars[0] = $chars[$i]; $chars[$i] = $t
          break
        }
      }
    }
    return (-join $chars)
  } finally { $rng.Dispose() }
}

# Resolve the built-in Administrator by well-known RID -500 so a renamed
# account is still found; fall back to the literal name.
function Get-YcAdminAccount{
  $a = Get-LocalUser -ErrorAction SilentlyContinue | Where-Object { $_.SID.Value -match '-500$' } | Select-Object -First 1
  if(-not $a){ $a = Get-LocalUser -Name 'Administrator' -ErrorAction SilentlyContinue }
  return $a
}

# ---------- resolve target account ----------
if($Administrator){
  $acct = Get-YcAdminAccount
  if(-not $acct){
    Write-YcLog 'Built-in Administrator account (RID 500) not found.' 'ERROR'
    Stop-YcLog 2; exit 2
  }
  $target = $acct.Name
} else {
  $target = $User
  $acct = Get-LocalUser -Name $target -ErrorAction SilentlyContinue
  if(-not $acct){
    Write-YcLog ('user not found: ' + $target) 'ERROR'
    Stop-YcLog 2; exit 2
  }
}

# ---------- resolve the new password ----------
$pwGenerated = $false
if($Random){
  $Password = New-YcStrongPassword $Length
  $pwGenerated = $true
}
if(-not $Password){
  Write-YcLog 'No password supplied. Use -Password "yourPass" (double-quoted) or -Random.' 'ERROR'
  Stop-YcLog 1; exit 1
}

# ---------- enable the built-in Administrator if asked ----------
if($Administrator -and -not $acct.Enabled){
  try{
    Enable-LocalUser -Name $target -ErrorAction Stop
    Write-YcLog ($target + ' account enabled.')
  }catch{ Write-YcLog ('could not enable ' + $target + ': ' + $_.Exception.Message) 'WARN' }
}

# ---------- set the password ----------
# NOTE: the value is never logged and never placed on a child process command
# line - Set-LocalUser consumes a SecureString in-process.
Write-YcLog ('Rotating password for local account: ' + $target)
$pwOk = $false
$attempts = 1
if($pwGenerated){ $attempts = 3 }   # a stricter local policy may reject a candidate

for($try = 1; $try -le $attempts -and -not $pwOk; $try++){
  if($pwGenerated -and $try -gt 1){ $Password = New-YcStrongPassword $Length }
  try{
    $sec = ConvertTo-SecureString $Password -AsPlainText -Force
    Set-LocalUser -Name $target -Password $sec -ErrorAction Stop
    Set-LocalUser -Name $target -PasswordNeverExpires $true -ErrorAction Stop
    $pwOk = $true
  }catch{
    # The exception text never contains the password itself.
    Write-YcLog ('Set-LocalUser attempt ' + $try + ' failed: ' + $_.Exception.Message) 'WARN'
  }
}

if(-not $pwOk){
  Write-YcLog ('Could not set the password for ' + $target + ' (complexity/length policy?). The account password is UNCHANGED.') 'ERROR'
  Stop-YcLog 3; exit 3
}

# ---------- PROVE it works before reporting success ----------
# A disabled account always fails ValidateCredentials, so only assert when enabled.
$acct = Get-LocalUser -Name $target -ErrorAction SilentlyContinue
if($acct -and $acct.Enabled){
  $verified = $false
  try{
    Add-Type -AssemblyName System.DirectoryServices.AccountManagement -ErrorAction Stop
    $ctx = New-Object DirectoryServices.AccountManagement.PrincipalContext 'Machine'
    try{ $verified = $ctx.ValidateCredentials($target, $Password) } finally { $ctx.Dispose() }
  }catch{
    Write-YcLog ('Password verification could not run: ' + $_.Exception.Message) 'WARN'
  }
  if(-not $verified){
    Write-YcLog ('Password for ' + $target + ' was accepted but FAILED verification - do not rely on it.') 'ERROR'
    Stop-YcLog 3; exit 3
  }
  Write-YcLog ('Password rotated and VERIFIED for ' + $target + ' (PasswordNeverExpires=true).') 'OK'
} else {
  Write-YcLog ('Password rotated for ' + $target + ' (PasswordNeverExpires=true). Account is DISABLED so the credential could not be verified.') 'WARN'
}

Write-Host ("OK: password rotated for " + $target) -ForegroundColor Green

# --- transcript OFF: this single line must not reach rotate-password.log ---
try { Stop-Transcript | Out-Null } catch {}
Write-Host ("NEWPASSWORD=" + $Password)
try { Start-Transcript -Path $YcLogPath -Append | Out-Null } catch {}
# --- transcript ON ---

Stop-YcLog 0
exit 0
