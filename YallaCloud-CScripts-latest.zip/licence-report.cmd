@echo off
rem licence-report - READ-ONLY Windows + SQL Server licensing report for this machine or many.
rem
rem   Answers, in one command: which Windows edition, is it an Evaluation image, is it
rem   activated, by which licensed method (KMS / ADBA / MAK / AVMA / retail / OEM), which KMS
rem   host, days to renewal, rearms left, and - when it is not activated - the
rem   Microsoft-documented reason and the fix. Then every SQL Server instance, its edition,
rem   whether it is Evaluation, base build vs patch level, and its support lifecycle state.
rem
rem   licence-report
rem   licence-report -Format Html -Path C:\Scripts\licensing.html
rem   licence-report -ComputerName srv01,srv02 -Format Csv -Path C:\Scripts\licensing.csv
rem   licence-report -SelfCheck
rem
rem CHANGES NOTHING. Safe to run any time, including on a production box.
rem
rem SQL data is read from the REGISTRY, not over T-SQL, so an expired Evaluation instance
rem   that will not start still appears on the report - which is the case you need it for.
rem
rem NO PRODUCT KEY IS EVER PRINTED. Get-DbaProductKey decodes the real key out of
rem   DigitalProductID and a PowerShell transcript would capture it, so this never calls it.
rem   The only key material shown is Windows' own PartialProductKey (the last five
rem   characters, which Microsoft publishes as a normal property).
rem
rem Exit codes: 0 nothing critical, 1 at least one machine is CRITICAL (not activated).
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Licence-Report.ps1" %*
exit /b %ERRORLEVEL%
