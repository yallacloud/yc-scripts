param(
  [string]$SqlInstance = '.',
  [string[]]$Database,
  [ValidateSet('Full','Diff','Log')]
  [string]$Type = 'Full',
  [string]$Directory,
  [switch]$Compress,
  [switch]$Checksum,
  [switch]$Verify,
  [switch]$CopyOnly,
  [int]$RetentionHours = 0,
  [string]$S3Profile,
  [string]$S3Prefix,
  [switch]$DeleteLocalAfterUpload,
  [string]$SqlLogin,
  [string]$SqlPasswordFile,
  [switch]$WhatIf,
  [switch]$Help
)
# ================================================================================================
# Backup-Sql.ps1 - YALLACLOUD day-2 command: on-demand and scheduled SQL Server backups that are
# VERIFIED, and can be offloaded to S3-compatible object storage through transfer-s3.
# PowerShell 5.1 only, ASCII only, Windows Server 2016-2025, SQL Server 2016-2025.
# Stamp: 2026-08-19 - removed the documented exit code 1 'Generic failure'; it is unreachable
#        (the unhandled-error path is 99). No behaviour changed.
#
# ------------------------------------------------------------------------------------------------
# HOW THIS FITS WITH install-sql, AND WHY IT DOES NOT FIGHT IT
# ------------------------------------------------------------------------------------------------
# install-sql PHASE 11 deploys Ola Hallengren's maintenance solution into the DBA database and
# PHASE 12 registers scheduled tasks (YC-SqlBackupFull / Diff / Log / Integrity / IndexOpt) that call
# EXEC dbo.DatabaseBackup with @CleanupTime = 168 and @LogToTable = 'Y'. Those jobs own retention and
# own the CommandLog history on this instance.
#   * THEREFORE: when dbo.DatabaseBackup exists, this command USES IT. The backup files land in the
#     same place, with the same naming convention, and are recorded in the same dbo.CommandLog, so a
#     DBA reading CommandLog sees one coherent history rather than two tools disagreeing.
#   * THEREFORE: this command does NOT pass @CleanupTime unless you explicitly ask for retention with
#     -RetentionHours. Creating a second retention policy is how a scheduled job and an ad-hoc
#     command end up deleting each other's chain. Without -RetentionHours, retention stays exactly
#     where install-sql put it: in the scheduled tasks.
#   * Native T-SQL BACKUP is the FALLBACK, used only when dbo.DatabaseBackup genuinely does not
#     exist (an instance this toolkit did not build). The command says which path it took, every run.
#   * Ad-hoc backups default to a normal (non copy-only) backup. Use -CopyOnly when you are taking a
#     one-off backup that must not disturb the differential base of the scheduled jobs. That is the
#     single most common way an ad-hoc full backup silently breaks a nightly DIFF chain.
#
# ------------------------------------------------------------------------------------------------
# WHY EVERY BACKUP IS CHECKSUMMED AND RESTORE VERIFYONLY'D
# ------------------------------------------------------------------------------------------------
# BACKUP ... WITH CHECKSUM makes the engine verify each page's existing checksum as it reads it and
# write a checksum over the whole backup stream. RESTORE VERIFYONLY then re-reads the media and, per
# the documentation, "verifies that the backup set is complete and that all volumes are readable",
# checks page header fields such as the page id, and validates the checksums IF THEY ARE PRESENT ON
# THE MEDIA. Those two are only useful together: VERIFYONLY on a backup taken without CHECKSUM has
# almost nothing to check. Both are therefore ALWAYS applied and cannot be switched off; -Checksum
# and -Verify exist so a caller can state the intent explicitly, and are accepted as no-ops.
# What VERIFYONLY does NOT do is verify the structure of the data itself - that is DBCC CHECKDB's
# job, which install-sql already schedules weekly. A backup that has not been verified is not a
# backup; a verified backup is still not a tested restore.
#
# ------------------------------------------------------------------------------------------------
# WHY System.Data.SqlClient AND NOT sqlcmd
# ------------------------------------------------------------------------------------------------
# On SQL Server 2022 and 2025 setup no longer installs sqlcmd at all - it moved to the standalone
# "Microsoft command line utilities" package - so a backup command that shells out to sqlcmd is
# broken by construction on a default 2022/2025 install. System.Data.SqlClient ships inside the .NET
# Framework on every Windows Server 2016 and later, needs no install, returns typed results and real
# exceptions instead of parsed console text, and lets a SQL authentication password be placed in a
# connection string in this process only - never on a command line and never in the transcript.
# Note it is the .NET FRAMEWORK System.Data.SqlClient, whose Encrypt default is false; the newer
# Microsoft.Data.SqlClient defaults to Encrypt=Mandatory with certificate validation and would fail
# against a default local instance with a self-signed certificate.
# sqlcmd is still located and reported, purely so the log says whether it exists on this host.
#
# ------------------------------------------------------------------------------------------------
# WHAT "PROVED" MEANS HERE
# ------------------------------------------------------------------------------------------------
# For every database, all four of these must hold or the run exits non-zero:
#   1. the BACKUP statement completed without raising an error,
#   2. msdb.dbo.backupset has a NEW row for that database, of the right type, finished after this run
#      started (so a stale backup from yesterday cannot be mistaken for today's),
#   3. the physical file named in msdb.dbo.backupmediafamily exists on disk with a plausible size,
#   4. RESTORE VERIFYONLY FROM DISK = <that file> WITH CHECKSUM succeeded.
# With -S3Profile, a fifth: transfer-s3 exited 0 AND printed its [YC-S3-PROOF] line for that key,
# which it only does after HEADing the object and matching its byte count. The local file is deleted
# only after that, never before.
# ================================================================================================
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'backup-sql'
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$script:Cn         = $null
$script:RunStart   = (Get-Date)
$script:Results    = New-Object System.Collections.Generic.List[object]
$script:OlaDb      = $null
$script:TransferPs = 'C:\Scripts\Transfer-S3.ps1'

trap {
  Write-YcLog ('UNHANDLED ERROR at line ' + $_.InvocationInfo.ScriptLineNumber + ': ' + $_.Exception.Message) 'ERROR'
  if ($_.ScriptStackTrace) { Write-YcLog ('Stack: ' + ($_.ScriptStackTrace -replace "`r?`n", ' | ')) 'ERROR' }
  if ($script:Cn) { try { $script:Cn.Close() } catch { } }
  Exit-Yc 99 'backup-sql aborted on an unhandled error.' 'ERROR'
}

if ($Help) {
@"
backup-sql  -  verified SQL Server backups, on demand or from a scheduled task, with optional
               offload to S3-compatible storage. Uses Ola Hallengren's dbo.DatabaseBackup when
               install-sql has deployed it, and native T-SQL BACKUP when it has not.

USAGE:
  backup-sql [-Type Full|Diff|Log] [-Database <db>[,<db>]] [-SqlInstance <inst>] [-Directory <path>]
  backup-sql -Type Full -S3Profile default -S3Prefix sql/PRODSQL01 -DeleteLocalAfterUpload
  backup-sql -Help

PARAMETERS:
  -SqlInstance            Instance to back up. Default '.' (the local default instance). Use
                          '.\SQL2022' or 'HOST\INSTANCE' for a named instance.
  -Database               One or more database names. Omitted, or 'USER', means every ONLINE user
                          database. 'ALL' adds master, model and msdb. tempdb is never backed up and
                          database snapshots are always skipped.
  -Type                   Full (default) | Diff | Log.
  -Directory              Backup destination. Omitted: Ola's configured directory in the Ola path, or
                          the instance's own default backup directory in the native path.
  -Compress               Force backup compression. Default is compression ON wherever the edition
                          supports it (Enterprise / Standard / Developer; NOT Express or Web). If you
                          pass -Compress on an edition that cannot compress, the run fails rather
                          than quietly writing an uncompressed backup.
  -Checksum               Accepted for explicitness. WITH CHECKSUM is ALWAYS applied and cannot be
                          switched off.
  -Verify                 Accepted for explicitness. RESTORE VERIFYONLY is ALWAYS run and cannot be
                          switched off.
  -CopyOnly               Take a COPY_ONLY backup, which does not reset the differential base and does
                          not truncate the log. Use for ad-hoc backups on an instance whose scheduled
                          jobs own the chain. Not valid with -Type Diff.
  -RetentionHours         Delete backups older than this many hours. OMITTED BY DESIGN: when Ola is
                          present, retention belongs to the install-sql scheduled tasks
                          (@CleanupTime = 168) and this command does not create a second, competing
                          policy. Supplying it passes @CleanupTime in the Ola path, and deletes this
                          command's own older files in the native path.
  -S3Profile              set-s3config profile. Each VERIFIED backup file is handed to transfer-s3.
  -S3Prefix               Key prefix for the uploads. Default <profile prefix>/<instance>/<database>.
  -DeleteLocalAfterUpload Delete the local backup file, but only after transfer-s3 has PROVED the
                          remote object by HEADing it and matching the byte count. Never before.
  -SqlLogin               SQL authentication login. Prefer Windows integrated authentication; this
                          exists only for instances where it is genuinely unavailable.
  -SqlPasswordFile        File whose first non-empty line is the -SqlLogin password. There is
                          deliberately no -SqlPassword parameter: a password passed as an argument is
                          visible in the process table and recorded in Security event 4688.
  -WhatIf                 Show every statement that would run, and run none of them.
  -Help                   Show this help and exit.

BEHAVIOUR:
  - A LOG backup of a SIMPLE-recovery database is REFUSED with a plain message. In 'every user
    database' mode those databases are skipped with a warning and the rest proceed; if you named the
    database explicitly, the run fails, because you asked for something impossible.
  - A DIFF or LOG backup of a database that has never had a full backup is refused the same way,
    instead of failing later with error 3035 or 4214.
  - Every file is proved: it exists on disk, msdb.dbo.backupset has a new row for it, and RESTORE
    VERIFYONLY WITH CHECKSUM succeeds. Any of those failing makes the run exit non-zero.
  - Every database's outcome is printed in a summary table at the end.
  - Idempotent: running it twice simply produces two backups. Nothing is ever overwritten in place -
    every backup goes to its own timestamped file.

EXAMPLES:
  backup-sql
  backup-sql -Type Full -Database SALES,CRM -Directory D:\dbbackupdaily
  backup-sql -Type Log -Database SALES
  backup-sql -Type Full -CopyOnly -Database SALES -S3Profile default -DeleteLocalAfterUpload
  backup-sql -Type Full -Database ALL -S3Profile default -S3Prefix sql/PRODSQL01
  backup-sql -SqlInstance .\SQL2022 -Type Diff -WhatIf

EXIT CODES:
   0  Success - every selected database was backed up, verified, and (when asked) uploaded and proved.
   2  Invalid arguments (for example -CopyOnly with -Type Diff, or -SqlLogin without -SqlPasswordFile).
   3  Cannot connect to the SQL Server instance.
   4  No database matched the selection.
   5  Not running as Administrator (from _yc-lib.ps1).
   6  Refused: a LOG or DIFF backup was explicitly requested for a database that cannot take one
      (SIMPLE recovery, or no full backup exists yet).
   7  One or more BACKUP statements FAILED.
   8  VERIFICATION FAILED: a backup file is missing, has no msdb.dbo.backupset row, or RESTORE
      VERIFYONLY did not succeed. Nothing was uploaded or deleted for that database.
   9  The S3 upload, or its proof, FAILED. The local backup files were NOT deleted.
  99  Unhandled terminating error.

Log: C:\Scripts\backup-sql.log   (mirrored to the Application event log, source YallaCloud)
"@ | Write-Host -ForegroundColor Cyan
  Exit-Yc 0
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation -BoundParameters $PSBoundParameters

if ($Checksum) { Write-YcLog '-Checksum accepted: WITH CHECKSUM is always applied by this command.' }
if ($Verify)   { Write-YcLog '-Verify accepted: RESTORE VERIFYONLY is always run by this command.' }
if ($CopyOnly -and $Type -eq 'Diff') {
  Exit-Yc 2 '-CopyOnly is not valid with -Type Diff. A copy-only differential is not a thing in SQL Server - COPY_ONLY only has meaning for FULL and LOG backups.' 'ERROR'
}
if ($SqlLogin -and -not $SqlPasswordFile) {
  Exit-Yc 2 '-SqlLogin requires -SqlPasswordFile. There is no -SqlPassword parameter on purpose: an argument is visible in the process table and in Security event 4688.' 'ERROR'
}
if ($DeleteLocalAfterUpload -and -not $S3Profile) {
  Exit-Yc 2 '-DeleteLocalAfterUpload without -S3Profile would delete a backup that was never copied anywhere. Refusing.' 'ERROR'
}

# ------------------------------------------------------------------------------------------------
# Connection
# ------------------------------------------------------------------------------------------------
$sqlcmdExe = $null
foreach ($r in @(
  'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\*\Tools\Binn\SQLCMD.EXE',
  'C:\Program Files (x86)\Microsoft SQL Server\Client SDK\ODBC\*\Tools\Binn\SQLCMD.EXE',
  'C:\Program Files\Microsoft SQL Server\*\Tools\Binn\SQLCMD.EXE',
  'C:\Program Files\sqlcmd\sqlcmd.exe')) {
  $f = $null
  try { $f = Get-ChildItem -Path $r | Sort-Object FullName -Descending | Select-Object -First 1 } catch { $f = $null }
  if ($f) { $sqlcmdExe = $f.FullName; break }
}
if (-not $sqlcmdExe) {
  try { $c = Get-Command -Name 'sqlcmd.exe' -CommandType Application | Select-Object -First 1; if ($c) { $sqlcmdExe = $c.Source } } catch { }
}
if ($sqlcmdExe) { Write-YcLog ('sqlcmd is present at ' + $sqlcmdExe + ' (informational - this command does not use it).') }
else { Write-YcLog 'sqlcmd is NOT installed on this host. That is expected on SQL Server 2022/2025, where setup no longer ships it. This command uses System.Data.SqlClient and does not need it.' }

try { $null = [System.Data.SqlClient.SqlConnection] } catch {
  $hint = 'and sqlcmd is not installed either'
  if ($sqlcmdExe) { $hint = 'but sqlcmd is present at ' + $sqlcmdExe }
  Exit-Yc 3 ('System.Data.SqlClient could not be loaded on this host (' + $hint + '). Install or repair the .NET Framework 4.7.2 or later, then re-run.') 'ERROR'
}

$csb = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
$csb['Data Source']      = $SqlInstance
$csb['Initial Catalog']  = 'master'
$csb['Application Name'] = 'YallaCloud backup-sql'
$csb['Connect Timeout']  = 30
if ($SqlLogin) {
  if (-not (Test-Path -LiteralPath $SqlPasswordFile -PathType Leaf)) {
    Exit-Yc 2 ('-SqlPasswordFile does not exist: ' + $SqlPasswordFile) 'ERROR'
  }
  $pl = @(Get-Content -LiteralPath $SqlPasswordFile | Where-Object { $_.Trim().Length -gt 0 })
  if ($pl.Count -eq 0) { Exit-Yc 2 ('-SqlPasswordFile ' + $SqlPasswordFile + ' is empty.') 'ERROR' }
  $csb['Integrated Security'] = $false
  $csb['User ID']  = $SqlLogin
  $csb['Password'] = $pl[0]
  Write-YcLog ('Connecting to ' + $SqlInstance + ' as SQL login ' + $SqlLogin + ' (password read from ' + $SqlPasswordFile + '; it is never placed on a command line and never written to this log).') 'WARN'
} else {
  $csb['Integrated Security'] = $true
  Write-YcLog ('Connecting to ' + $SqlInstance + ' with Windows integrated authentication as ' + $env:USERDOMAIN + '\' + $env:USERNAME + '.')
}

$script:Cn = New-Object System.Data.SqlClient.SqlConnection
$script:Cn.ConnectionString = $csb.ConnectionString
try {
  $script:Cn.Open()
} catch {
  $csb['Password'] = ''
  Exit-Yc 3 ('Could not connect to SQL Server instance "' + $SqlInstance + '": ' + $_.Exception.Message +
             '. Check that the instance is running, that the name is right (use HOST\INSTANCE for a named instance), and that this account has rights on it.') 'ERROR'
}
$csb['Password'] = ''

# A renamed machine is the one condition that silently changes where THIS command writes: Ola
# Hallengren's @Directory layout is <root>\<hostname>\..., so after a rename the backups move to
# a new folder and @CleanupTime never prunes the old one again. The nightly tasks are the only
# thing guaranteed to keep running on a renamed box, so this is where an operator will actually
# see it. Detect and say so - never repair here: the repair restarts SQL Server, which a backup
# must never do.
[void](Write-YcSqlNameDriftWarning -Drift (Get-YcSqlNameDrift -Target $SqlInstance))

# ------------------------------------------------------------------------------------------------
# SQL helpers
# ------------------------------------------------------------------------------------------------
function New-YcCmd {
  param([string]$Sql,[int]$TimeoutSec = 30,[hashtable]$Parameters)
  $c = $script:Cn.CreateCommand()
  $c.CommandText    = $Sql
  $c.CommandTimeout = $TimeoutSec
  if ($Parameters) {
    foreach ($k in $Parameters.Keys) {
      $v = $Parameters[$k]
      if ($null -eq $v) { $v = [DBNull]::Value }
      [void]$c.Parameters.AddWithValue($k, $v)
    }
  }
  return $c
}

function Invoke-YcScalar {
  param([string]$Sql,[int]$TimeoutSec = 30,[hashtable]$Parameters)
  $c = New-YcCmd -Sql $Sql -TimeoutSec $TimeoutSec -Parameters $Parameters
  try {
    $v = $c.ExecuteScalar()
    if ($v -is [DBNull]) { return $null }
    return $v
  } finally { $c.Dispose() }
}

function Invoke-YcRows {
  param([string]$Sql,[int]$TimeoutSec = 30,[hashtable]$Parameters)
  $c = New-YcCmd -Sql $Sql -TimeoutSec $TimeoutSec -Parameters $Parameters
  $rows = New-Object System.Collections.Generic.List[object]
  try {
    $rdr = $c.ExecuteReader()
    try {
      while ($rdr.Read()) {
        $o = @{}
        for ($i = 0; $i -lt $rdr.FieldCount; $i++) {
          $val = $rdr.GetValue($i)
          if ($val -is [DBNull]) { $val = $null }
          $o[$rdr.GetName($i)] = $val
        }
        [void]$rows.Add([pscustomobject]$o)
      }
    } finally { $rdr.Close() }
  } finally { $c.Dispose() }
  # The leading comma is load-bearing: without it PowerShell unrolls the list into the pipeline and
  # a single-row result arrives at the caller as a bare object, whose .Count then lies.
  return ,($rows.ToArray())
}

# Runs a statement that produces no result set. Returns $null on success or the error text.
function Invoke-YcExec {
  param([string]$Sql,[int]$TimeoutSec = 0,[hashtable]$Parameters)
  $c = New-YcCmd -Sql $Sql -TimeoutSec $TimeoutSec -Parameters $Parameters
  try {
    [void]$c.ExecuteNonQuery()
    return $null
  } catch [System.Data.SqlClient.SqlException] {
    return (($_.Exception.Message) -replace '[\r\n]+', ' ')
  } catch {
    return (($_.Exception.Message) -replace '[\r\n]+', ' ')
  } finally { $c.Dispose() }
}

function ConvertTo-YcIdent { param([string]$Name) return ('[' + ($Name -replace '\]', ']]') + ']') }

# ------------------------------------------------------------------------------------------------
# Instance facts
# ------------------------------------------------------------------------------------------------
$srv = (Invoke-YcRows -Sql @"
SELECT
  CONVERT(nvarchar(200), SERVERPROPERTY('ServerName'))         AS ServerName,
  CONVERT(nvarchar(200), SERVERPROPERTY('Edition'))            AS Edition,
  CONVERT(int,           SERVERPROPERTY('EngineEdition'))      AS EngineEdition,
  CONVERT(nvarchar(50),  SERVERPROPERTY('ProductVersion'))     AS ProductVersion,
  CONVERT(nvarchar(50),  SERVERPROPERTY('ProductLevel'))       AS ProductLevel,
  CONVERT(nvarchar(512), SERVERPROPERTY('InstanceDefaultBackupPath')) AS DefaultBackupPath,
  IS_SRVROLEMEMBER('sysadmin')                                 AS IsSysadmin
"@)[0]
Write-YcLog ('Connected to ' + $srv.ServerName + ' - ' + $srv.Edition + ' ' + $srv.ProductVersion + ' ' + $srv.ProductLevel + '.') 'OK'
if ([int]$srv.IsSysadmin -ne 1) {
  Write-YcLog 'This login is NOT a member of sysadmin. BACKUP needs db_backupoperator at minimum, and reading msdb.dbo.backupset needs access to msdb. If anything below fails with permission errors, that is why.' 'WARN'
}

$compressSupported = $true
if ([int]$srv.EngineEdition -eq 4) { $compressSupported = $false }                       # Express
if ([string]$srv.Edition -match '(?i)express|web') { $compressSupported = $false }        # Express / Web
if ($Compress -and -not $compressSupported) {
  Exit-Yc 2 ('-Compress was requested but this edition (' + $srv.Edition + ') cannot CREATE compressed backups - only Enterprise, Standard and Developer can. Drop -Compress, or the backup would silently be uncompressed.') 'ERROR'
}
$useCompression = $compressSupported
if (-not $compressSupported) {
  Write-YcLog ('Backup compression is not available on ' + $srv.Edition + ' - backups will be uncompressed. Every edition can RESTORE a compressed backup; only Enterprise / Standard / Developer can create one.') 'WARN'
}

# ------------------------------------------------------------------------------------------------
# Which engine: Ola Hallengren's dbo.DatabaseBackup, or native BACKUP
# ------------------------------------------------------------------------------------------------
# The state filter and the OBJECT_ID calls MUST NOT live in the same WHERE clause. SQL Server
# does not promise to evaluate predicates in written order, so "d.state = 0 AND OBJECT_ID(...)"
# happily calls OBJECT_ID against a database that is RESTORING and throws
#     Database '<name>' cannot be opened. It is in the middle of a restore.
# which arrived here as an UNHANDLED ERROR and aborted the whole run with exit 99 - so ONE
# database left in RESTORING (an interrupted restore, a log-shipping secondary, a warm standby)
# meant NOTHING on the instance got backed up that night. Measured live on 2026-09-01.
# Materialising the eligible names first makes the order guaranteed rather than lucky.
$olaRows = Invoke-YcRows -Sql @"
DECLARE @candidates TABLE (name sysname);
INSERT INTO @candidates (name)
SELECT d.name FROM sys.databases d WHERE d.state = 0 AND d.database_id <> 2;
SELECT TOP 1 c.name AS DbName
FROM @candidates c
WHERE OBJECT_ID(QUOTENAME(c.name) + N'.[dbo].[DatabaseBackup]', 'P')  IS NOT NULL
  AND OBJECT_ID(QUOTENAME(c.name) + N'.[dbo].[CommandExecute]', 'P')  IS NOT NULL
ORDER BY CASE WHEN c.name = N'DBA' THEN 0 WHEN c.name = N'master' THEN 1 ELSE 2 END, c.name;
"@
if ($olaRows.Count -gt 0) {
  $script:OlaDb = [string]$olaRows[0].DbName
  Write-YcLog ('PATH: Ola Hallengren. dbo.DatabaseBackup and dbo.CommandExecute were found in [' + $script:OlaDb + '], so this command will use them - the same procedures the install-sql scheduled tasks call, so retention, naming and the dbo.CommandLog history stay consistent.') 'OK'
} else {
  Write-YcLog 'PATH: native T-SQL. dbo.DatabaseBackup was not found in any online database on this instance, so this command will issue BACKUP DATABASE / BACKUP LOG directly. Run install-sql -Maintenance on to deploy the Ola Hallengren solution.' 'WARN'
}

if ($RetentionHours -gt 0) {
  Write-YcLog ('-RetentionHours ' + $RetentionHours + ': old backups will be deleted by this run. Make sure this does not contradict the install-sql scheduled tasks, which use @CleanupTime = 168 hours.') 'WARN'
} elseif ($script:OlaDb) {
  Write-YcLog 'No -RetentionHours: no retention is applied by this run. Deleting old backups remains the job of the install-sql scheduled tasks, so there is exactly one retention policy on this instance.'
}

# ------------------------------------------------------------------------------------------------
# Backup directory
# ------------------------------------------------------------------------------------------------
$backupDir = $Directory
if (-not $backupDir) {
  if ($srv.DefaultBackupPath) {
    $backupDir = ([string]$srv.DefaultBackupPath).TrimEnd('\')
  } else {
    $reg = $null
    try {
      $reg = Invoke-YcScalar -Sql @"
DECLARE @p nvarchar(512);
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory', @p OUTPUT;
SELECT @p;
"@
    } catch { $reg = $null }
    if ($reg) { $backupDir = ([string]$reg).TrimEnd('\') }
  }
}
if (-not $backupDir) {
  Exit-Yc 2 'The instance default backup directory could not be determined and -Directory was not supplied. Pass -Directory <path>.' 'ERROR'
}
Write-YcLog ('Backup directory: ' + $backupDir + ' (this is a path on the SQL Server host, written by the Database Engine service account - not by this script).')

# Ola's dbo.DatabaseBackup runs with @DirectoryCheck='Y' and creates only the SUB-folders
# (<host>\<db>\<TYPE>) via xp_create_subdir. The ROOT must already exist or the whole call
# fails with "The directory <path> does not exist" and the operator gets Ola's 40-line command
# echo instead of a sentence. Measured on a Server 2022 lab VM on 2026-08-31: `backup-sql -Directory
# C:\yc-custom-backups` exited 7 with zero backups; creating that one folder by hand and
# re-running the IDENTICAL command exited 0. Somebody passing -Directory means "put backups
# here", so make the root when it is a local path we can make.
if ($backupDir -notmatch '^\\\\' -and -not (Test-Path -LiteralPath $backupDir)) {
  try {
    New-Item -ItemType Directory -Path $backupDir -Force -ErrorAction Stop | Out-Null
    Write-YcLog ('Created the backup root ' + $backupDir + ' - it did not exist and Ola''s @DirectoryCheck would have refused the whole run.') 'OK'
  } catch {
    Exit-Yc 2 ('-Directory ' + $backupDir + ' does not exist and could not be created: ' +
      $_.Exception.Message + '. Create it on the SQL Server host, make sure the Database Engine ' +
      'service account can write to it, then re-run.') 'ERROR'
  }
}

# ------------------------------------------------------------------------------------------------
# Database selection
# ------------------------------------------------------------------------------------------------
$wantAll  = $false
$explicit = $false
$names    = @()
if (-not $Database -or $Database.Count -eq 0) { $wantAll = $false }
elseif ($Database.Count -eq 1 -and $Database[0] -match '(?i)^(ALL|ALL_DATABASES)$') { $wantAll = $true }
elseif ($Database.Count -eq 1 -and $Database[0] -match '(?i)^(USER|USER_DATABASES)$') { }
else { $explicit = $true; $names = $Database }

$allDbs = Invoke-YcRows -Sql @"
SELECT d.name AS DbName, d.database_id AS DbId, d.recovery_model_desc AS RecoveryModel,
       d.state_desc AS StateDesc, d.is_read_only AS IsReadOnly, d.source_database_id AS SnapshotOf,
       d.is_in_standby AS InStandby
FROM sys.databases d
ORDER BY d.name
"@

$selected = @()
foreach ($d in $allDbs) {
  $n = [string]$d.DbName
  if ($n -eq 'tempdb') { continue }
  if ($null -ne $d.SnapshotOf) {
    if ($explicit -and ($names -contains $n)) { Write-YcLog ('Skipping ' + $n + ': it is a database SNAPSHOT, and snapshots cannot be backed up.') 'WARN' }
    continue
  }
  $isSystem = ([int]$d.DbId -le 4)
  $take = $false
  if ($explicit) { $take = ($names -contains $n) }
  elseif ($wantAll) { $take = $true }
  else { $take = (-not $isSystem) }
  if (-not $take) { continue }
  if ([string]$d.StateDesc -ne 'ONLINE') {
    Write-YcLog ('Skipping ' + $n + ': the database is ' + $d.StateDesc + ', not ONLINE.') 'WARN'
    continue
  }
  if ([int]$d.InStandby -eq 1) {
    Write-YcLog ('Skipping ' + $n + ': it is in standby (log shipping secondary) and cannot be backed up here.') 'WARN'
    continue
  }
  $selected += $d
}
if ($explicit) {
  foreach ($n in $names) {
    $hit = @($allDbs | Where-Object { [string]$_.DbName -eq $n })
    if ($hit.Count -eq 0) { Write-YcLog ('Database "' + $n + '" does not exist on ' + $srv.ServerName + '.') 'ERROR' }
  }
}
if ($selected.Count -eq 0) {
  Exit-Yc 4 ('No database matched the selection on ' + $srv.ServerName + '. Nothing to back up.') 'ERROR'
}
Write-YcLog ($selected.Count.ToString() + ' database(s) selected for a ' + $Type.ToUpperInvariant() + ' backup: ' + (($selected | ForEach-Object { $_.DbName }) -join ', '))

# ------------------------------------------------------------------------------------------------
# Per-database eligibility
# ------------------------------------------------------------------------------------------------
function Test-YcEligible {
  param($Db)
  $n = [string]$Db.DbName
  $rm = [string]$Db.RecoveryModel
  if ($Type -eq 'Log' -and $rm -eq 'SIMPLE') {
    return [pscustomobject]@{ Ok = $false; Reason = ('a LOG backup is impossible on ' + $n + ' because it is in SIMPLE recovery - SQL Server does not keep the log records to back up. Switch it to FULL or BULK_LOGGED recovery, take a FULL backup first, and then log backups will work.') }
  }
  if ($Type -eq 'Log' -and $n -eq 'master') {
    return [pscustomobject]@{ Ok = $false; Reason = 'master is always in SIMPLE recovery and cannot have a log backup.' }
  }
  if ($Type -ne 'Full') {
    # is_copy_only = 0 matters: a COPY_ONLY full backup deliberately does NOT reset the
    # differential base, so counting it here let 'backup-sql -Type Full -CopyOnly' nightly
    # satisfy this guard and then fail at run time with the very error 3035 named below.
    $baseCount = Invoke-YcScalar -Sql "SELECT COUNT(*) FROM msdb.dbo.backupset WHERE database_name = @db AND type = 'D' AND is_copy_only = 0" -Parameters @{ '@db' = $n }
    if ([int]$baseCount -eq 0) {
      return [pscustomobject]@{ Ok = $false; Reason = ($n + ' has no FULL backup recorded in msdb, so a ' + $Type.ToUpperInvariant() + ' backup cannot be taken (SQL Server would raise error ' + $(if ($Type -eq 'Diff') { '3035' } else { '4214' }) + '). Run: backup-sql -Type Full -Database ' + $n) }
    }
  }
  return [pscustomobject]@{ Ok = $true; Reason = '' }
}

# ------------------------------------------------------------------------------------------------
# Backup execution
# ------------------------------------------------------------------------------------------------
function Invoke-YcOlaBackup {
  param([string]$DbName)
  $olaType = switch ($Type) { 'Full' { 'FULL' } 'Diff' { 'DIFF' } 'Log' { 'LOG' } }
  $sql = 'EXEC ' + (ConvertTo-YcIdent $script:OlaDb) + '.[dbo].[DatabaseBackup] ' +
         '@Databases = @dbs, @Directory = @dir, @BackupType = @btype, ' +
         '@CheckSum = ''Y'', @Verify = ''N'', @LogToTable = ''Y'', @Compress = @comp, @CopyOnly = @copy'
  $p = @{
    '@dbs'   = $DbName
    '@dir'   = $backupDir
    '@btype' = $olaType
    '@comp'  = $(if ($useCompression) { 'Y' } else { 'N' })
    '@copy'  = $(if ($CopyOnly) { 'Y' } else { 'N' })
  }
  if ($RetentionHours -gt 0) {
    $sql = $sql + ', @CleanupTime = @cleanup'
    $p['@cleanup'] = $RetentionHours
  }
  # @Verify = 'N' on purpose: this command runs its own RESTORE VERIFYONLY immediately afterwards and
  # REPORTS the result. Asking Ola to verify as well would read every byte of a multi-gigabyte backup
  # a second time for no extra evidence - and a parameter we passed is not evidence, an observed
  # verification is.
  if ($WhatIf) {
    Write-YcLog ('-WhatIf: would run   ' + $sql + '   with @dbs=' + $DbName + ', @dir=' + $backupDir + ', @btype=' + $olaType + ', @comp=' + $p['@comp'] + ', @copy=' + $p['@copy'] + $(if ($RetentionHours -gt 0) { ', @CleanupTime=' + $RetentionHours } else { '' })) 'WARN'
    return $null
  }
  return (Invoke-YcExec -Sql $sql -TimeoutSec 0 -Parameters $p)
}

function Invoke-YcNativeBackup {
  param([string]$DbName)
  $ext = '.bak'
  if ($Type -eq 'Log') { $ext = '.trn' }
  $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
  $inst  = ([string]$srv.ServerName) -replace '[\\/:*?"<>| ]', '_'
  $safe  = $DbName -replace '[\\/:*?"<>| ]', '_'
  $file  = Join-Path $backupDir ($inst + '_' + $safe + '_' + $Type.ToUpperInvariant() + '_' + $stamp + $ext)

  $verb = 'BACKUP DATABASE'
  if ($Type -eq 'Log') { $verb = 'BACKUP LOG' }
  $with = @('CHECKSUM','STATS = 10','FORMAT','INIT')
  if ($useCompression) { $with += 'COMPRESSION' } else { $with += 'NO_COMPRESSION' }
  if ($Type -eq 'Diff') { $with += 'DIFFERENTIAL' }
  if ($CopyOnly) { $with += 'COPY_ONLY' }
  $with += ("NAME = N'YallaCloud " + $Type.ToUpperInvariant() + " backup'")
  $sql = $verb + ' ' + (ConvertTo-YcIdent $DbName) + ' TO DISK = @path WITH ' + ($with -join ', ')

  if ($WhatIf) {
    Write-YcLog ('-WhatIf: would run   ' + $sql + '   with @path=' + $file) 'WARN'
    return [pscustomobject]@{ Error = $null; File = $file }
  }
  $err = Invoke-YcExec -Sql $sql -TimeoutSec 0 -Parameters @{ '@path' = $file }
  return [pscustomobject]@{ Error = $err; File = $file }
}

# ------------------------------------------------------------------------------------------------
# Proof
# ------------------------------------------------------------------------------------------------
function Get-YcNewBackupset {
  param([string]$DbName)
  $t = switch ($Type) { 'Full' { 'D' } 'Diff' { 'I' } 'Log' { 'L' } }
  $rows = Invoke-YcRows -Sql @"
SELECT TOP 1
  bs.backup_set_id       AS BackupSetId,
  bs.backup_size         AS BackupSize,
  bs.compressed_backup_size AS CompressedSize,
  bs.backup_start_date   AS StartDate,
  bs.backup_finish_date  AS FinishDate,
  bs.is_copy_only        AS IsCopyOnly,
  bs.has_backup_checksums AS HasChecksums,
  mf.physical_device_name AS DeviceName
FROM msdb.dbo.backupset bs
JOIN msdb.dbo.backupmediafamily mf ON mf.media_set_id = bs.media_set_id
WHERE bs.database_name = @db AND bs.type = @t AND bs.backup_start_date >= @since
ORDER BY bs.backup_finish_date DESC, bs.backup_set_id DESC
"@ -Parameters @{ '@db' = $DbName; '@t' = $t; '@since' = $script:RunStart.AddMinutes(-2) }
  if ($rows.Count -eq 0) { return $null }
  return $rows[0]
}

function Test-YcVerifyOnly {
  param([string]$FilePath)
  $err = Invoke-YcExec -Sql 'RESTORE VERIFYONLY FROM DISK = @path WITH CHECKSUM' -TimeoutSec 0 -Parameters @{ '@path' = $FilePath }
  return $err
}

# ------------------------------------------------------------------------------------------------
# S3 handoff - the local file is deleted only when transfer-s3 has PROVED the remote object.
# ------------------------------------------------------------------------------------------------
function Send-YcBackupToS3 {
  param([string]$FilePath,[string]$DbName)
  if (-not (Test-Path -LiteralPath $script:TransferPs)) {
    Write-YcLog ('-S3Profile was given but ' + $script:TransferPs + ' does not exist. Deploy transfer-s3 alongside this command.') 'ERROR'
    return [pscustomobject]@{ Ok = $false; Detail = 'transfer-s3 missing' }
  }
  $prefix = $S3Prefix
  if (-not $prefix) {
    $inst = ([string]$srv.ServerName) -replace '[\\/:*?"<>| ]', '_'
    $prefix = $inst + '/' + ($DbName -replace '[\\/:*?"<>| ]', '_')
  }
  $key = $prefix.Trim('/') + '/' + (Split-Path -Leaf $FilePath)
  if ($WhatIf) {
    Write-YcLog ('-WhatIf: would upload ' + $FilePath + ' to profile "' + $S3Profile + '" as key ' + $key) 'WARN'
    return [pscustomobject]@{ Ok = $true; Detail = 'whatif' }
  }
  $a = @('-NoProfile','-ExecutionPolicy','Bypass','-File', $script:TransferPs,
         '-Profile', $S3Profile, '-Path', $FilePath, '-Key', $key, '-Direction', 'Upload')
  Write-YcLog ('Handing ' + (Split-Path -Leaf $FilePath) + ' to transfer-s3 (profile "' + $S3Profile + '", key ' + $key + '). No secret is passed on this command line - transfer-s3 reads the DPAPI blob itself.')
  $out = & powershell.exe @a 2>&1
  $rc  = $LASTEXITCODE
  $txt = (($out | ForEach-Object { [string]$_ }) -join "`n")
  # String.Contains, NOT -like: the proof marker contains [ and ], which -like would treat as a
  # wildcard character class and never match.
  $needle = '[YC-S3-PROOF] key=' + $key + ' '
  $proof = ''
  foreach ($line in ($txt -split "`n")) {
    if ($line.Contains($needle)) { $proof = $line.Trim() }
  }
  if ($rc -ne 0) {
    Write-YcLog ('transfer-s3 exited ' + $rc + ' for ' + $key + ' - the upload FAILED. The local backup file has NOT been deleted. See C:\Scripts\transfer-s3.log.') 'ERROR'
    return [pscustomobject]@{ Ok = $false; Detail = ('transfer-s3 exit ' + $rc) }
  }
  if (-not $proof) {
    Write-YcLog ('transfer-s3 exited 0 for ' + $key + ' but printed no [YC-S3-PROOF] line for that key. An exit code is not proof, so this upload is treated as FAILED and the local file is kept.') 'ERROR'
    return [pscustomobject]@{ Ok = $false; Detail = 'no proof line' }
  }
  Write-YcLog ('Upload PROVED by transfer-s3: ' + $proof) 'OK'
  if ($DeleteLocalAfterUpload) {
    Remove-Item -LiteralPath $FilePath -Force
    if (Test-Path -LiteralPath $FilePath) {
      Write-YcLog ('The remote copy is proved but the local file ' + $FilePath + ' could not be deleted.') 'WARN'
    } else {
      Write-YcLog ('Deleted the local file ' + $FilePath + ' AFTER the remote object was proved. Note that the local restore chain for this database now depends on the object store.') 'OK'
    }
  }
  return [pscustomobject]@{ Ok = $true; Detail = 'uploaded and proved' }
}

# ------------------------------------------------------------------------------------------------
# Native-path retention (only when -RetentionHours was explicitly asked for)
# ------------------------------------------------------------------------------------------------
function Invoke-YcNativeRetention {
  if ($RetentionHours -le 0) { return }
  if ($script:OlaDb) { return }   # Ola's own @CleanupTime already did it
  $cut = (Get-Date).AddHours(-1 * $RetentionHours)
  $pattern = '*_' + $Type.ToUpperInvariant() + '_*'
  $ext = '.bak'
  if ($Type -eq 'Log') { $ext = '.trn' }
  $old = @()
  try {
    $old = @(Get-ChildItem -LiteralPath $backupDir -File -Filter ($pattern + $ext) | Where-Object { $_.LastWriteTime -lt $cut })
  } catch {
    Write-YcLog ('Retention could not enumerate ' + $backupDir + ': ' + $_.Exception.Message) 'WARN'
    return
  }
  if ($old.Count -eq 0) {
    Write-YcLog ('Retention: no ' + $Type.ToUpperInvariant() + ' backup file in ' + $backupDir + ' is older than ' + $RetentionHours + ' hours.')
    return
  }
  foreach ($f in $old) {
    if ($WhatIf) {
      Write-YcLog ('-WhatIf: would delete ' + $f.FullName + ' (' + $f.LastWriteTime.ToString('s') + ', ' + [int]($f.Length / 1MB) + ' MB).') 'WARN'
    } else {
      Remove-Item -LiteralPath $f.FullName -Force
      Write-YcLog ('Retention: deleted ' + $f.FullName + ' (older than ' + $RetentionHours + ' hours).')
    }
  }
}

# ------------------------------------------------------------------------------------------------
# Main loop
# ------------------------------------------------------------------------------------------------
$failBackup = 0
$failVerify = 0
$failUpload = 0
$refused    = 0

foreach ($d in $selected) {
  $dbName = [string]$d.DbName
  $rec    = [string]$d.RecoveryModel
  $row = [ordered]@{
    Database = $dbName; Recovery = $rec; Type = $Type.ToUpperInvariant()
    Backup = 'skipped'; SizeMB = ''; Verify = 'n/a'; Msdb = 'n/a'; S3 = 'n/a'; File = ''
  }

  $el = Test-YcEligible -Db $d
  if (-not $el.Ok) {
    if ($explicit) {
      Write-YcLog ('REFUSED for ' + $dbName + ': ' + $el.Reason) 'ERROR'
      $refused++
      $row['Backup'] = 'REFUSED'
    } else {
      Write-YcLog ('Skipping ' + $dbName + ': ' + $el.Reason) 'WARN'
      $row['Backup'] = 'skipped'
    }
    [void]$script:Results.Add([pscustomobject]$row)
    continue
  }

  Write-YcLog ('--- ' + $dbName + ' (' + $rec + ' recovery) : ' + $Type.ToUpperInvariant() + ' backup ---')
  $file = ''
  $err  = $null
  $sw = [Diagnostics.Stopwatch]::StartNew()
  if ($script:OlaDb) {
    $err = Invoke-YcOlaBackup -DbName $dbName
  } else {
    $nr = Invoke-YcNativeBackup -DbName $dbName
    $err  = $nr.Error
    $file = $nr.File
  }
  $sw.Stop()

  if ($WhatIf) {
    $row['Backup'] = 'WHATIF'
    [void]$script:Results.Add([pscustomobject]$row)
    continue
  }
  if ($err) {
    Write-YcLog ('BACKUP FAILED for ' + $dbName + ': ' + $err) 'ERROR'
    $failBackup++
    $row['Backup'] = 'FAILED'
    [void]$script:Results.Add([pscustomobject]$row)
    continue
  }
  Write-YcLog ('BACKUP statement completed for ' + $dbName + ' in ' + [int]$sw.Elapsed.TotalSeconds + 's. That is not yet proof - checking msdb, the file and RESTORE VERIFYONLY.')
  $row['Backup'] = 'ok'

  # ---- proof 1: msdb has a NEW row ----
  $bset = Get-YcNewBackupset -DbName $dbName
  if (-not $bset) {
    Write-YcLog ('VERIFICATION FAILED for ' + $dbName + ': the BACKUP statement returned no error but msdb.dbo.backupset has NO new ' + $Type.ToUpperInvariant() + ' row for this database since this run started. Nothing was actually backed up.') 'ERROR'
    $failVerify++
    $row['Msdb'] = 'MISSING'
    [void]$script:Results.Add([pscustomobject]$row)
    continue
  }
  $row['Msdb'] = 'set ' + $bset.BackupSetId
  $file = [string]$bset.DeviceName
  $row['File'] = $file
  $sizeBytes = 0
  if ($bset.CompressedSize) { $sizeBytes = [long]$bset.CompressedSize } elseif ($bset.BackupSize) { $sizeBytes = [long]$bset.BackupSize }
  Write-YcLog ('msdb: backup_set_id ' + $bset.BackupSetId + ', finished ' + ([datetime]$bset.FinishDate).ToString('s') +
               ', ' + [Math]::Round($sizeBytes / 1MB, 2) + ' MB, checksums=' + $(if ([int]$bset.HasChecksums -eq 1) { 'yes' } else { 'NO' }) +
               ', copy_only=' + $(if ([int]$bset.IsCopyOnly -eq 1) { 'yes' } else { 'no' }) + ', device ' + $file) 'OK'
  if ([int]$bset.HasChecksums -ne 1) {
    Write-YcLog ('msdb reports has_backup_checksums = 0 for ' + $dbName + '. The backup was taken WITHOUT a checksum, so RESTORE VERIFYONLY has almost nothing to verify.') 'ERROR'
    $failVerify++
    $row['Verify'] = 'NO CHECKSUM'
    [void]$script:Results.Add([pscustomobject]$row)
    continue
  }

  # ---- proof 2: the file exists on disk with a plausible size ----
  $minBytes = 65536
  if ($Type -eq 'Log') { $minBytes = 1024 }
  if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
    Write-YcLog ('VERIFICATION FAILED for ' + $dbName + ': msdb names the backup device ' + $file + ' but that file does not exist from this host. If the backup went to a UNC path this host may simply not be able to see it - check from the SQL Server host itself.') 'ERROR'
    $failVerify++
    $row['Verify'] = 'FILE MISSING'
    [void]$script:Results.Add([pscustomobject]$row)
    continue
  }
  $onDisk = (Get-Item -LiteralPath $file).Length
  $row['SizeMB'] = [string][Math]::Round($onDisk / 1MB, 2)
  if ($onDisk -lt $minBytes) {
    Write-YcLog ('VERIFICATION FAILED for ' + $dbName + ': ' + $file + ' is only ' + $onDisk + ' bytes, which is not a plausible ' + $Type.ToUpperInvariant() + ' backup.') 'ERROR'
    $failVerify++
    $row['Verify'] = 'TOO SMALL'
    [void]$script:Results.Add([pscustomobject]$row)
    continue
  }
  Write-YcLog ('File on disk: ' + $file + ' (' + $onDisk + ' bytes).') 'OK'

  # ---- proof 3: RESTORE VERIFYONLY ----
  Write-YcLog ('Running RESTORE VERIFYONLY FROM DISK WITH CHECKSUM on ' + (Split-Path -Leaf $file) + '...')
  $vsw = [Diagnostics.Stopwatch]::StartNew()
  $verr = Test-YcVerifyOnly -FilePath $file
  $vsw.Stop()
  if ($verr) {
    Write-YcLog ('RESTORE VERIFYONLY FAILED for ' + $dbName + ' on ' + $file + ': ' + $verr + '. This backup is NOT usable. It has not been uploaded and nothing has been deleted.') 'ERROR'
    $failVerify++
    $row['Verify'] = 'FAILED'
    [void]$script:Results.Add([pscustomobject]$row)
    continue
  }
  Write-YcLog ('PROVED: RESTORE VERIFYONLY succeeded for ' + $dbName + ' in ' + [int]$vsw.Elapsed.TotalSeconds + 's - the media is complete, readable, and its checksums are intact.') 'OK'
  $row['Verify'] = 'ok'

  # ---- optional: offload ----
  if ($S3Profile) {
    $up = Send-YcBackupToS3 -FilePath $file -DbName $dbName
    if ($up.Ok) { $row['S3'] = 'proved' } else { $row['S3'] = 'FAILED'; $failUpload++ }
  }

  [void]$script:Results.Add([pscustomobject]$row)
}

Invoke-YcNativeRetention

try { $script:Cn.Close() } catch { }

# ------------------------------------------------------------------------------------------------
# Summary
# ------------------------------------------------------------------------------------------------
Write-Host ''
Write-Host ('  {0,-24} {1,-14} {2,-5} {3,-8} {4,10} {5,-12} {6,-12} {7}' -f 'DATABASE','RECOVERY','TYPE','BACKUP','SIZE MB','VERIFY','MSDB','S3')
Write-Host ('  ' + ('-' * 120))
foreach ($r in $script:Results) {
  Write-Host ('  {0,-24} {1,-14} {2,-5} {3,-8} {4,10} {5,-12} {6,-12} {7}' -f `
    $r.Database, $r.Recovery, $r.Type, $r.Backup, $r.SizeMB, $r.Verify, $r.Msdb, $r.S3)
}
Write-Host ('  ' + ('-' * 120))
Write-Host ''

$okCount = @($script:Results | Where-Object { $_.Verify -eq 'ok' }).Count
Write-YcLog ($okCount.ToString() + ' of ' + $script:Results.Count + ' database(s) backed up and VERIFIED on ' + $srv.ServerName +
             ' using the ' + $(if ($script:OlaDb) { 'Ola Hallengren dbo.DatabaseBackup path (in [' + $script:OlaDb + '])' } else { 'native T-SQL BACKUP path' }) + '.')

if ($WhatIf) {
  Exit-Yc 0 '-WhatIf: nothing was backed up, verified, uploaded or deleted.' 'WARN'
}
if ($refused -gt 0) {
  Exit-Yc 6 ($refused.ToString() + ' explicitly named database(s) cannot take a ' + $Type.ToUpperInvariant() + ' backup - see the REFUSED lines above.') 'ERROR'
}
if ($failBackup -gt 0) {
  Exit-Yc 7 ($failBackup.ToString() + ' BACKUP statement(s) FAILED.') 'ERROR'
}
if ($failVerify -gt 0) {
  Exit-Yc 8 ($failVerify.ToString() + ' backup(s) could NOT be verified. A backup that has not been verified is not a backup.') 'ERROR'
}
if ($failUpload -gt 0) {
  Exit-Yc 9 ($failUpload.ToString() + ' upload(s) to S3 profile "' + $S3Profile + '" FAILED or could not be proved. The local backup files were kept.') 'ERROR'
}
if ($okCount -eq 0) {
  Exit-Yc 4 'No database was actually backed up - every candidate was skipped. Check the warnings above.' 'ERROR'
}
Exit-Yc 0 ('backup-sql complete: ' + $okCount + ' verified ' + $Type.ToUpperInvariant() + ' backup(s)' + $(if ($S3Profile) { ', all uploaded and proved on S3 profile "' + $S3Profile + '"' } else { '' }) + '.') 'OK'
