@echo off
setlocal
rem ================================================================================================
rem sql-archive - keep ONE full backup per calendar month, for KeepMonths months (default 12).
rem              Wrapper for C:\Scripts\Yc-SqlArchive.ps1.
rem
rem WHY IT EXISTS: Ola's @CleanupTime gives a rolling window and nothing else. A one-month window
rem cannot answer "restore the state at the end of March"; a one-year window keeps 365 daily fulls
rem and fills the disk. This is the second half of grandfather-father-son - the retained monthly.
rem
rem RUN IT DAILY, not monthly. It asks "does the CURRENT month already have a copy?", so a missed
rem 1st-of-the-month is harmless and a second run in the same month does nothing.
rem
rem   sql-archive                        archive this month if needed, then prune
rem   sql-archive -Report                show what exists and what would happen. Changes nothing.
rem   sql-archive -KeepMonths 24         keep two years
rem   sql-archive -MonthlyDir D:\monthly archive to a data volume instead of C:
rem   sql-archive -InstanceName YCWEB    a named instance
rem   sql-archive -SelfCheck             assertions only, no admin needed, changes nothing
rem   sql-archive -Help
rem
rem Layout: <MonthlyDir>\<host>\<instance>\<database>\<database>_MONTHLY_<yyyy-MM>.bak
rem
rem It PROVES the archive before recording the month as done: the source named in msdb still
rem exists, the copy matches byte length, and RESTORE VERIFYONLY reads it back.
rem
rem It will NOT shrink retention when the disk fills - deleting backups to free space is how you
rem find out too late that the month you needed is gone. Low disk is yc-guard's alert, not this
rem script's decision.
rem
rem EXIT CODES: 0 ok or nothing to do | 1 one or more databases failed | 2 usage |
rem             3 SQL unreachable | 5 not elevated
rem
rem Logs to C:\Scripts\yc-sqlarchive.log and C:\Scripts\yc-sqlarchive.json (machine-readable).
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Yc-SqlArchive.ps1" %*
exit /b %ERRORLEVEL%
