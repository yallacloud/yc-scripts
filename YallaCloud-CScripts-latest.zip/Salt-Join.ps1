param(
  [switch]$Report,   # say what would happen, change nothing
  [switch]$Status,   # show this machine's Salt state and the last join result
  [switch]$Help
)
# =====================================================================================
# Salt-Join.ps1 - join this Windows guest to the YallaCloud Salt master, ZERO INPUT (STACK4-54 s17).
# PowerShell 5.1, ASCII only. Called by fix-deploy (fix 'salt') on every new deployment.
#
# It does not install anything itself. It starts the one fixed join line in the background
#     irm https://repo.oasisstack.io/salt/join.ps1 | iex
# as the scheduled task "YallaCloud Salt Join" (SYSTEM, now + every 15 min). join.ps1 installs
# Salt 3008 when missing, joins as <cloudstack-domain>-<vm-name> with no token, prints
# JOINED / WAITING / FAILED and removes the task after the first JOINED. So a deployment is
# never held up by Salt, and a VM without egress yet simply joins later by itself.
#
# Skips: already joined (salt-minion running, yc_vmid grain = this VM's UUID), or opted out with the file
#     C:\ProgramData\YallaCloud\salt\no-join      (e.g. a golden-image build VM)
# =====================================================================================
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){ Write-Host 'FATAL: C:\Scripts\_yc-lib.ps1 missing - payload incomplete' -ForegroundColor Red; exit 3 }
. $YcLib
Start-YcLog 'salt-join'

if($Help){
@"
salt-join  -  join this guest to the YallaCloud Salt master. No token, no names to type.

USAGE:
  salt-join             start the join in the background (scheduled task "YallaCloud Salt Join")
  salt-join -Report     say what would happen, change nothing
  salt-join -Status     this machine's Salt state and the last join result

PARAMETERS:
  -Report   dry run: checks the opt-out file, the current minion and repo.oasisstack.io
  -Status   prints minion id, service state and the last JOINED / WAITING / FAILED line
  -Help     this text

EXAMPLES:
  salt-join
  salt-join -Status
  fix-deploy -Only salt          the same, through the deployment fixes

NOTES:
  Result lines (in the join log):  JOINED <tenant>-<vm>  |  WAITING: VM unknown to CloudStack -
  add its uuid to inventory/manual.yaml in Forgejo ycadmin/salt  |  FAILED: <reason>.
  The task retries every 15 minutes until JOINED, then deletes itself. Safe to run again.
  Opt out:  New-Item C:\ProgramData\YallaCloud\salt\no-join
Log: C:\Scripts\salt-join.log   Join logs: C:\ProgramData\YallaCloud\salt\logs\join-auto-*.log
"@ | Write-Host
  Exit-Yc 0
}

Assert-YcPrereqs -NeedAdmin

$Task    = 'YallaCloud Salt Join'
$Url     = 'https://repo.oasisstack.io/salt/join.ps1'
$Work    = Join-Path $env:ProgramData 'YallaCloud\salt'
$OptOut  = Join-Path $Work 'no-join'
$Conf    = 'C:\ProgramData\Salt Project\Salt\conf'

function Get-YcSaltState {
  $svc = Get-Service -Name 'salt-minion' -ErrorAction SilentlyContinue
  $id = ''; $vmid = $false
  $m10 = Join-Path $Conf 'minion.d\10-master.conf'
  if(Test-Path -LiteralPath $m10){
    $hit = Select-String -LiteralPath $m10 -Pattern '^id:\s*(\S+)' | Select-Object -First 1
    if($hit){ $id = $hit.Matches[0].Groups[1].Value }
  }
  $gr = Join-Path $Conf 'grains'
  # joined = the yc_vmid grain is THIS VM (KVM: SMBIOS UUID = CloudStack id). A clone of a joined image, or a
  # VMware VM (UUID differs), runs the join again - join.ps1 is safe to rerun and gives a clone its own key.
  $me = ([string](Get-CimInstance Win32_ComputerSystemProduct).UUID).ToLower()
  if(Test-Path -LiteralPath $gr){ $vmid = [bool](Select-String -LiteralPath $gr -Pattern ('^yc_vmid: ' + [regex]::Escape($me) + '$') -Quiet) }
  $last = ''
  $logs = Join-Path $Work 'logs'
  if(Test-Path -LiteralPath $logs){
    $f = Get-ChildItem -LiteralPath $logs -Filter 'join-auto-*.log' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if($f){ $last = (Select-String -LiteralPath $f.FullName -Pattern '^(JOINED|CONFIGURED|WAITING:|FAILED:)' | Select-Object -Last 1).Line }
  }
  [pscustomobject]@{
    Service = $(if($svc){ [string]$svc.Status } else { 'not installed' })
    Id      = $id
    Joined  = ($svc -and $svc.Status -eq 'Running' -and $vmid)
    Task    = [bool](Get-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue)
    Last    = $last
  }
}

$st = Get-YcSaltState

if($Status){
  Write-YcLog ('salt-minion service: ' + $st.Service + '   minion id: ' + $(if($st.Id){ $st.Id } else { '-' }))
  Write-YcLog ('joined (zero-input): ' + $st.Joined + '   retry task present: ' + $st.Task)
  Write-YcLog ('last join result: ' + $(if($st.Last){ $st.Last } else { 'none yet' }))
  Exit-Yc 0
}

if(Test-Path -LiteralPath $OptOut){ Exit-Yc 0 ('opted out (' + $OptOut + ' exists) - not joining Salt') 'WARN' }
if($st.Joined){ Exit-Yc 0 ('already joined as ' + $st.Id + ' - nothing to do') }

if($Report){
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $reach = $false
  try { $null = Invoke-WebRequest -UseBasicParsing -Method Head -Uri $Url -TimeoutSec 15; $reach = $true } catch { $reach = $false }
  Write-YcLog ('WOULD start scheduled task "' + $Task + '" (SYSTEM): join-retry.ps1 - downloads ' + $Url + ' to a file, checks it, runs it') 'WARN'
  Write-YcLog ('repo.oasisstack.io reachable now: ' + $reach + $(if($reach){ '' } else { ' - the task would retry every 15 min until it is' }))
  Exit-Yc 0
}

New-Item -ItemType Directory -Force -Path (Join-Path $Work 'logs') | Out-Null
# The task runs a FILE: Defender blocks a SYSTEM task whose command line is 'irm .. | iex'
# (Trojan:Win32/Commando.A!ml, task result 0x80070005). Always re-registered so an old task is replaced.
$Retry = Join-Path $Work 'join-retry.ps1'
# P3 (2.47.6): DOWNLOAD TO A FILE FIRST, then run it. 'irm | iex' cannot tell a 403 page or a half
# download from the script, and a status must never rest on that. A failed or tiny download ends
# the run with exit 3 (the task retries in 15 min); otherwise join.ps1's own exit code is kept.
$rs = @(
  "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12",
  ("`$f = '" + (Join-Path $Work 'join.ps1') + "'"),
  ("try { Invoke-WebRequest -UseBasicParsing -Uri '" + $Url + "' -OutFile `$f -TimeoutSec 120 -ErrorAction Stop } catch { exit 3 }"),
  "if (-not (Test-Path -LiteralPath `$f) -or (Get-Item -LiteralPath `$f).Length -lt 500 -or -not (Select-String -LiteralPath `$f -Pattern 'JOINED' -Quiet)) { exit 3 }",
  "& powershell.exe -NoProfile -ExecutionPolicy Bypass -File `$f",
  "exit `$LASTEXITCODE")
[IO.File]::WriteAllText($Retry, (($rs -join "`r`n") + "`r`n"))
$a = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -ExecutionPolicy Bypass -File "' + $Retry + '"')
# RepetitionDuration is explicit: Server 2016 rejects a repeating -Once trigger without one
$t = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(30) -RepetitionInterval (New-TimeSpan -Minutes 15) -RepetitionDuration (New-TimeSpan -Days 365)
try {
  Register-ScheduledTask -TaskName $Task -Action $a -Trigger $t -User 'SYSTEM' -RunLevel Highest -Force -ErrorAction Stop | Out-Null
} catch { Exit-Yc 1 ('could not create the scheduled task "' + $Task + '": ' + $_.Exception.Message) }
if(-not (Get-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue)){ Exit-Yc 1 ('scheduled task "' + $Task + '" is not there after creating it') }
try { Start-ScheduledTask -TaskName $Task -ErrorAction Stop } catch { Write-YcLog ('could not start the task now (' + $_.Exception.Message + ') - it starts by its own trigger') 'WARN' }
Exit-Yc 0 ('Salt join started in the background (task "' + $Task + '"). Result: salt-join -Status, or ' + (Join-Path $Work 'logs'))
