@echo off
setlocal
rem ================================================================================================
rem telegraf-register - install Telegraf as a Windows service, validate the config with
rem                     'telegraf --config <f> --test', and prove the agent runs.
rem                     Wrapper for C:\Scripts\Telegraf-Register.ps1.
rem
rem WHAT CHANGED, AND WHY:
rem   - Added "exit /b %ERRORLEVEL%".
rem   - The old example put the InfluxDB API token on this command line. That token is a bearer
rem     credential for the whole organization, and anything here is visible in the process table,
rem     in Windows event 4688 (when command-line auditing is on) and in the transcript header.
rem     Use -TokenFile <file>, or set YC_TELEGRAF_TOKEN before calling.
rem   - The token is no longer written into telegraf.conf either: the config references
rem     ${INFLUX_TOKEN} and the value lives in the service's own Environment registry value.
rem
rem PREFERRED:
rem   set YC_TELEGRAF_TOKEN=...
rem   telegraf-register -InfluxUrl http://10.0.0.7:8086 -Org yc -Bucket win
rem   telegraf-register -InfluxUrl http://10.0.0.7:8086 -Org yc -TokenFile C:\Scripts\.influx.token
rem   telegraf-register -ConfigFile C:\Scripts\telegraf.conf
rem   telegraf-register -Help
rem
rem EXIT CODES: 0 verified | 1 failed | 2 usage | 5 not elevated | 6 no internet
rem Log: C:\Scripts\telegraf-register.log
rem ================================================================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\Telegraf-Register.ps1" %*
exit /b %ERRORLEVEL%
