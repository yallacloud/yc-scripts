param(
  # ---- names preserved from glpi-register.cmd and the catalog ----
  [string]$Server,
  [string]$Tag,
  [switch]$Help,
  # ---- ADDED in this revision ----
  [string]$ServerFile,          # read the GLPI URL from a FILE instead of the command line
  [string]$MsiPath,             # explicit GLPI-Agent MSI
  [string]$CaCertFile,          # CA_CERT_FILE - PEM bundle for a private GLPI CA
  [int]$VerifySec = 180,        # how long to wait for the agent's first run to show up
  [switch]$Force                # re-run the MSI even if the agent service already exists
)
# =====================================================================================
# GLPI-Register.ps1 - SILENT install of the GLPI inventory agent. OUTBOUND ONLY.
# PowerShell 5.1, ASCII only, unattended (cloud-init / SYSTEM / RMM).
#
# 2026-08-19: repaired. Added the library guard + Exit-Yc on every path (three bare exits, no
#             Stop-YcLog); msiexec now runs through Invoke-YcInstaller so its exit code is
#             captured, decoded and timed; the agent SERVICE must exist and reach Running and
#             the configuration is READ BACK out of the registry and compared with what was
#             requested; the GLPI server is proven reachable; and a URL carrying embedded
#             credentials is stripped before it reaches any log. Added -ServerFile,
#             -MsiPath, -CaCertFile, -VerifySec and -Force.
#
# ------------------------------- WHAT CHANGED, AND WHY -------------------------------
# [P0] IT PRINTED THE MSIEXEC EXIT CODE AND EXITED WITH IT, PROVING NOTHING.
#   Old lines 31-33:
#     $p = Start-Process msiexec.exe -ArgumentList $a -Wait -PassThru
#     Write-Host ("GLPI Agent msiexec exit: " + $p.ExitCode)
#     exit $p.ExitCode
#   The exit code was captured and never compared, no service was checked, and the SERVER
#   property was never read back - so a typo in the URL, a rejected package or a service that
#   failed to start all produced the same "GLPI Agent msiexec exit: 0" and a green deployment.
#   The old help even claimed 'runs as service glpi-agent' without ever looking.
#   NOW: Invoke-YcInstaller decodes the exit code (including 1638 "already installed") with a
#   timeout and a minimum plausible duration; the agent service is discovered, must exist and
#   must reach Running; HKLM\SOFTWARE\GLPI-Agent is read back and its 'server' value must
#   match the URL we asked for; the GLPI host is proven reachable over TCP; and the agent log
#   is scanned for errors.
#
# [P1] THE SERVER URL WENT STRAIGHT INTO THE LOG.
#   A GLPI native-inventory URL can carry HTTP basic credentials
#   (https://user:password@glpi.example.com/front/inventory.php). The old script echoed
#   whatever it was given. NOW the userinfo component is stripped before anything is logged,
#   the presence of embedded credentials is reported as a WARNING, and -ServerFile / the
#   YC_GLPI_SERVER environment variable exist so the URL never has to appear on a command
#   line at all.
#
# [P1] NO FIREWALL RULE IS CREATED, AND THAT IS DELIBERATE.
#   The GLPI agent is outbound-only. Its embedded web server (httpd-port 62354) is bound with
#   httpd-trust defaulting to the control servers only, so this command does NOT pass
#   ADD_FIREWALL_EXCEPTION and does not open an inbound port.
#
# VENDOR VERIFICATION - every property below is documented:
#   Windows MSI properties SERVER, TAG, RUNNOW, EXECMODE (1 = Service), CA_CERT_FILE,
#   INSTALLDIR (default C:\Program Files\GLPI-Agent), and the example
#   'msiexec /i GLPI-Agent-1.7-x64.msi /quiet SERVER=<URL>':
#     https://glpi-agent.readthedocs.io/en/latest/installation/windows-command-line.html
#   Windows configuration lives in the registry key HKEY_LOCAL_MACHINE\SOFTWARE\GLPI-Agent
#   (Wow6432Node for a 32-bit agent on a 64-bit host), keyed by option name (server, tag),
#   and the embedded web server's default port 62354:
#     https://github.com/glpi-project/doc-agent/blob/1.6.1/source/configuration.rst
#   The Windows service is registered by glpi-win32-service; its system name is discovered at
#   runtime rather than assumed, because the vendor documents it as configurable (-n/--name):
#     https://github.com/glpi-project/doc-agent/blob/1.6.1/source/man/glpi-win32-service.rst
#   Windows Installer standard options (/i, /quiet, /l*v, REBOOT=ReallySuppress):
#     https://learn.microsoft.com/en-us/windows/win32/msi/standard-installer-command-line-options
# =====================================================================================

$ErrorActionPreference = 'Continue'

# The ONLY exit that cannot go through Exit-Yc: the library that defines Exit-Yc is missing.
$YcLib = 'C:\Scripts\_yc-lib.ps1'
if(-not (Test-Path -LiteralPath $YcLib)){
  Write-Host ''
  Write-Host '*** FATAL: C:\Scripts\_yc-lib.ps1 is missing - this payload is incomplete. ***' -ForegroundColor Red
  Write-Host '*** Nothing was installed. Re-deploy the C:\Scripts payload and re-run.    ***' -ForegroundColor Red
  Write-Host ''
  exit 3
}
. $YcLib
Start-YcLog 'glpi-register'

$MsiLog   = 'C:\Scripts\glpi-agent-msi.log'
$RegRoots = @('HKLM:\SOFTWARE\GLPI-Agent','HKLM:\SOFTWARE\Wow6432Node\GLPI-Agent')

$Usage = @'
glpi-register  -  SILENT install of the GLPI inventory agent. OUTBOUND ONLY to your GLPI
                  server; no inbound port is opened. Staged installer: C:\Scripts\GLPI-Agent-*.msi

USAGE:
  glpi-register -Server https://glpi.example.com/front/inventory.php
  glpi-register -Server <url> -Tag <customer-id>
  glpi-register -ServerFile C:\Scripts\glpi-server.txt [-Tag <t>] [-CaCertFile <pem>]
  glpi-register -Server <url> [-MsiPath <msi>] [-VerifySec 180] [-Force]
  glpi-register -Help

PARAMETERS:
  -Server      Your GLPI native-inventory URL, e.g.
               https://glpi.example.com/front/inventory.php  (required unless -ServerFile or
               the YC_GLPI_SERVER environment variable is used). It becomes the MSI SERVER
               property. If it carries embedded HTTP basic credentials
               (https://user:pass@host/...) the credentials are stripped before logging and
               reported as a warning - use -ServerFile so they never reach a command line.
  -ServerFile  File containing the GLPI URL. Preferred when the URL embeds credentials.
  -Tag         MSI TAG property: the customer/entity id that maps this asset in GLPI for
               per-tenant reporting and billing. Also readable from YC_GLPI_TAG.
  -CaCertFile  MSI CA_CERT_FILE property: a PEM bundle for a GLPI server behind a private CA.
               Emitted only if the file exists. This exists so that nobody has to reach for
               NO_SSL_CHECK=1, which this command never sets.
  -MsiPath     Explicit MSI. Default: the highest-version C:\Scripts\GLPI-Agent-*.msi.
  -VerifySec   How long to wait for the agent's first run to appear in its log (default 180).
  -Force       Re-run the MSI even if the agent service already exists. Required to CHANGE the
               server or tag of an already-installed agent.
  -Help        Show this help and exit.

PROOF OF SUCCESS (nothing below is assumed):
  msiexec exit code captured and decoded (the old script captured it and never compared it)
  + the GLPI agent Windows service DISCOVERED, present, and Running
  + HKLM\SOFTWARE\GLPI-Agent read back, with its 'server' value equal to the URL requested
    and its 'tag' value equal to -Tag - this is the vendor's own configuration store
  + the GLPI host proven reachable over TCP on the URL's port
  + the agent log scanned for errors.
  If the configuration does not read back, the command FAILS. It never prints an exit code
  and calls that a registration.

EXAMPLES:
  glpi-register -Server https://glpi.example.com/front/inventory.php
  glpi-register -Server https://glpi.example.com/front/inventory.php -Tag ACME
  glpi-register -ServerFile C:\Scripts\glpi-server.txt -Tag ACME
  glpi-register -Server https://glpi.example.com/front/inventory.php -Force
  glpi-register -Help

EXIT CODES:
  0   the agent is installed, its service is Running and its configuration reads back
  1   generic failure
  2   usage error (no -Server, not a URL, unreadable -ServerFile, bad -VerifySec)
  3   C:\Scripts\_yc-lib.ps1 missing (nothing was attempted)
  4   the GLPI-Agent MSI is missing or too small
  5   not running as Administrator
  7   no GLPI agent service exists, or it did not reach Running
  8   the GLPI server is not reachable from this host, so no inventory can be delivered
  10  msiexec did not exit within its timeout and was killed
  14  HKLM\SOFTWARE\GLPI-Agent does not read back the requested SERVER
  <n> any other value is msiexec's own exit code

Log: C:\Scripts\glpi-register.log   MSI log: C:\Scripts\glpi-agent-msi.log
     Agent log: <install dir>\logs\glpi-agent.log   (Application event log source: YallaCloud)
'@

if($Help){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 0 'help displayed' 'OK'
}

# ------------------------------------------------------------------------------------
# Resolve the target URL. -ServerFile and YC_GLPI_SERVER keep it off the command line.
# ------------------------------------------------------------------------------------
$url = ''
if($ServerFile){
  if(-not (Test-Path -LiteralPath $ServerFile)){
    Write-Host $Usage -ForegroundColor Cyan
    Exit-Yc 2 ('-ServerFile not found: ' + $ServerFile + '. Nothing was installed.') 'ERROR'
  }
  $urlRaw = $null
  # Get-Content -Raw returns $null for an EMPTY file, and [string]$null is $null, not '' - so
  # calling .Trim() straight off the pipeline throws instead of reporting "the file is empty".
  try{ $urlRaw = Get-Content -LiteralPath $ServerFile -Raw -ErrorAction Stop }
  catch{ Exit-Yc 2 ('-ServerFile could not be read: ' + $_.Exception.Message) 'ERROR' }
  if($null -eq $urlRaw){ $urlRaw = '' }
  $url = ([string]$urlRaw).Trim()
  if(-not $url){ Exit-Yc 2 ('-ServerFile is empty: ' + $ServerFile) 'ERROR' }
}elseif($Server){
  $url = $Server.Trim()
}elseif($env:YC_GLPI_SERVER){
  $url = ([string]$env:YC_GLPI_SERVER).Trim()
  Write-YcLog 'GLPI URL taken from the YC_GLPI_SERVER environment variable (it is not on the command line - good)'
}
$tagValue = $Tag
if(-not $tagValue -and $env:YC_GLPI_TAG){ $tagValue = ([string]$env:YC_GLPI_TAG).Trim() }

if(-not $url){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 'a GLPI URL is required. Pass -Server, -ServerFile, or set YC_GLPI_SERVER. Nothing was installed.' 'ERROR'
}
$uri = $null
try{ $uri = [System.Uri]$url }catch{ $uri = $null }
if(-not $uri -or ($uri.Scheme -ne 'http' -and $uri.Scheme -ne 'https')){
  Write-Host $Usage -ForegroundColor Cyan
  Exit-Yc 2 ('the GLPI URL must be an http(s) URL, e.g. https://glpi.example.com/front/inventory.php') 'ERROR'
}
# Strip any embedded basic credentials before this URL reaches a log line.
$safeUrl = ($uri.Scheme + '://' + $uri.Host + ':' + $uri.Port + $uri.PathAndQuery)
if($uri.UserInfo){
  Write-YcLog 'the GLPI URL carries embedded HTTP basic credentials. They are stripped from every log line here, but they were on this command line and are therefore in the process table and in 4688 events. Use -ServerFile instead.' 'WARN'
}
if($uri.Scheme -eq 'http'){
  Write-YcLog ('the GLPI URL is PLAIN HTTP (' + $safeUrl + '): the inventory, which lists installed software and serial numbers, will cross the network in clear text.') 'WARN'
}
if($VerifySec -lt 1){ Exit-Yc 2 ('-VerifySec must be at least 1, got ' + $VerifySec) 'ERROR' }
if($CaCertFile -and -not (Test-Path -LiteralPath $CaCertFile)){
  Exit-Yc 2 ('-CaCertFile not found: ' + $CaCertFile) 'ERROR'
}

Assert-YcPrereqs -NeedAdmin
Write-YcInvocation $PSBoundParameters
Write-YcLog ('GLPI target: ' + $safeUrl + ' tag "' + $tagValue + '"')

function Test-YcTcpPort{
  param([string]$ComputerName,[int]$Port,[int]$TimeoutMs = 5000)
  $c = $null
  try{
    $c = New-Object System.Net.Sockets.TcpClient
    $iar = $c.BeginConnect($ComputerName,$Port,$null,$null)
    if(-not $iar.AsyncWaitHandle.WaitOne($TimeoutMs,$false)){ return $false }
    $c.EndConnect($iar)
    return $true
  }catch{
    return $false
  }finally{
    if($c){ try{ $c.Close() }catch{} }
  }
}

# The vendor documents the service NAME as configurable, so discover it instead of guessing.
function Get-YcGlpiService{
  $s = Get-Service -Name 'glpi-agent' -ErrorAction Ignore
  if($s){ return $s }
  $all = @()
  try{ $all = @(Get-Service -ErrorAction Stop | Where-Object { $_.Name -like '*glpi*' -or $_.DisplayName -like '*GLPI*' }) }catch{}
  if($all.Count -gt 0){ return $all[0] }
  return $null
}

# ------------------------------------------------------------------------------------
# 1. Install (or deliberately skip) the MSI - with an exit code this time.
# ------------------------------------------------------------------------------------
$existingSvc = Get-YcGlpiService
if($existingSvc -and -not $Force){
  Write-YcLog ('the GLPI agent service "' + $existingSvc.Name + '" already exists - NOT re-running the MSI. Pass -Force to reinstall or to change the server/tag. The configuration is still verified below.') 'WARN'
}else{
  $msi = ''
  if($MsiPath){
    $msi = $MsiPath
  }else{
    $cands = @(Get-ChildItem -Path 'C:\Scripts\GLPI-Agent-*.msi' -File -ErrorAction Ignore)
    if($cands.Count -gt 0){
      $ranked = @()
      foreach($f in $cands){
        $v = [version]'0.0'
        if($f.Name -match 'GLPI-Agent-(\d+(?:\.\d+){1,3})'){ try{ $v = [version]$Matches[1] }catch{ $v = [version]'0.0' } }
        $ranked += (New-Object psobject -Property @{ File = $f; Ver = $v })
      }
      $ranked = @($ranked | Sort-Object -Property Ver -Descending)
      if($ranked.Count -gt 1){ Write-YcLog ('several staged GLPI-Agent MSIs found - using the highest version: ' + $ranked[0].File.Name) 'WARN' }
      $msi = $ranked[0].File.FullName
    }
  }
  if(-not $msi){
    Exit-Yc 4 'the GLPI Agent MSI was not found (C:\Scripts\GLPI-Agent-*.msi). Stage it or pass -MsiPath. Nothing was installed.' 'ERROR'
  }
  if(-not (Assert-YcFile -Path $msi -MinBytes 1MB -Because 'GLPI Agent MSI')){
    Exit-Yc 4 ('unusable GLPI Agent MSI: ' + $msi) 'ERROR'
  }
  $sig = 'Unavailable'
  try{ $sig = [string](Get-AuthenticodeSignature -LiteralPath $msi -ErrorAction Stop).Status }catch{ $sig = 'Unavailable' }
  if($sig -eq 'Valid'){ Write-YcLog ('MSI Authenticode signature: Valid (' + (Split-Path -Leaf $msi) + ')') 'OK' }
  else{ Write-YcLog ('MSI Authenticode signature is ' + $sig + ' for ' + $msi + ' - continuing, but this package is not proven to be the GLPI build') 'WARN' }

  # EXECMODE=1 is the documented "run as a Windows Service" mode; RUNNOW=1 makes the agent
  # perform its first inventory immediately, which is what gives us something to verify.
  $a = @('/i', ('"' + $msi + '"'), '/quiet', 'REBOOT=ReallySuppress', '/l*v', ('"' + $MsiLog + '"'),
         'RUNNOW=1', 'EXECMODE=1', ('SERVER="' + $url + '"'))
  if($tagValue){   $a += ('TAG="' + $tagValue + '"') }
  if($CaCertFile){ $a += ('CA_CERT_FILE="' + $CaCertFile + '"') }

  $inst = Invoke-YcInstaller -FilePath 'msiexec.exe' -ArgumentList $a -SuccessCodes @(0) -RebootCodes @(3010,1641) -TimeoutSec 1800 -MinSeconds 4
  if($inst.TimedOut){
    Exit-Yc 10 ('msiexec did not finish within its timeout and was killed - see ' + $MsiLog + '. The agent may be half-installed.') 'ERROR'
  }
  if($inst.ExitCode -eq 1638){
    Write-YcLog 'msiexec returned 1638 (another version of this product is already installed) - continuing to verify the EXISTING agent' 'WARN'
  }elseif(-not $inst.Success){
    $code = $inst.ExitCode
    if($code -eq 0){ $code = 1 }
    Exit-Yc $code ('the GLPI Agent MSI FAILED: ' + $inst.Meaning + '. See ' + $MsiLog + '. Nothing is registered.') 'ERROR'
  }
}

# ------------------------------------------------------------------------------------
# 2. The service must EXIST and be Running.
# ------------------------------------------------------------------------------------
$svc = Get-YcGlpiService
if(-not $svc){
  Exit-Yc 7 ('the installer reported success but no GLPI agent service exists on this host (looked for "glpi-agent" and any service whose name or display name contains GLPI). The agent is NOT installed as a service - check EXECMODE in ' + $MsiLog + '.') 'ERROR'
}
Write-YcLog ('GLPI agent service discovered: "' + $svc.Name + '" (' + $svc.DisplayName + ')')
if(-not (Assert-YcService -Name $svc.Name -TimeoutSec 120 -State 'Running' -StartIfStopped -Because 'the GLPI inventory agent' -Fatal)){
  Exit-Yc 7 ('the GLPI agent service "' + $svc.Name + '" is not Running - no inventory will ever be sent.') 'ERROR'
}

# Locate the install directory from the service binary rather than assuming a path.
$installDir = ''
try{
  $pathName = [string](Get-CimInstance Win32_Service -Filter ("Name='" + $svc.Name + "'") -ErrorAction Stop).PathName
  if($pathName){
    $exe = $pathName.Trim()
    if($exe.StartsWith('"')){ $exe = ($exe -split '"')[1] }
    else{ $exe = ($exe -split '\s+')[0] }
    $d = Split-Path -Parent $exe
    # The service binary lives in <install dir>\perl\bin, so walk up until logs\ appears.
    for($i = 0; $i -lt 4 -and $d; $i++){
      if(Test-Path -LiteralPath (Join-Path $d 'logs')){ $installDir = $d; break }
      $d = Split-Path -Parent $d
    }
  }
}catch{ Write-YcLog ('could not read the service binary path: ' + $_.Exception.Message) 'WARN' }
if(-not $installDir){
  foreach($d in @('C:\Program Files\GLPI-Agent','C:\Program Files (x86)\GLPI-Agent')){
    if(Test-Path -LiteralPath $d){ $installDir = $d; break }
  }
}
if($installDir){ Write-YcLog ('agent install directory: ' + $installDir) }
else{ Write-YcLog 'the agent install directory could not be located, so the agent log cannot be scanned' 'WARN' }

# ------------------------------------------------------------------------------------
# 3. CONFIG READBACK - the vendor's own configuration store, not our own hopes.
# ------------------------------------------------------------------------------------
$regRoot = ''
$regServer = ''
$regTag = ''
foreach($r in $RegRoots){
  if(-not (Test-Path -LiteralPath $r)){ continue }
  $props = $null
  try{ $props = Get-ItemProperty -LiteralPath $r -ErrorAction Stop }catch{ continue }
  foreach($p in @($props.PSObject.Properties)){
    if($p.Name -like 'PS*'){ continue }
    if($p.Name -match '(?i)^server$'){ $regServer = [string]$p.Value; $regRoot = $r }
    if($p.Name -match '(?i)^tag$'){    $regTag    = [string]$p.Value }
  }
  if($regServer){ break }
}
if(-not $regRoot){
  Exit-Yc 14 ('neither ' + ($RegRoots -join ' nor ') + ' contains a "server" value, so the agent has no execution target. The MSI SERVER property did not take effect - see ' + $MsiLog + '.') 'ERROR'
}
if($regServer.Trim() -ne $url){
  Exit-Yc 14 ('the agent configuration in ' + $regRoot + ' reads back server="' +
    (($regServer -replace '(?i)^([a-z]+://)[^/@]*@','$1')) + '" but this run asked for ' + $safeUrl +
    '. The agent is pointed at a DIFFERENT GLPI server. Pass -Force to overwrite it.') 'ERROR'
}
Write-YcLog ('configuration READ BACK from ' + $regRoot + ': server matches ' + $safeUrl) 'OK'
if($tagValue){
  if($regTag.Trim() -eq $tagValue.Trim()){ Write-YcLog ('configuration READ BACK: tag="' + $regTag + '" as requested') 'OK' }
  else{ Write-YcLog ('the agent configuration reads back tag="' + $regTag + '" but -Tag asked for "' + $tagValue + '". Per-tenant reporting in GLPI will be wrong. Pass -Force to overwrite it.') 'WARN' }
}

# ------------------------------------------------------------------------------------
# 4. Functional check: can this host actually deliver an inventory?
# ------------------------------------------------------------------------------------
$port = $uri.Port
if(-not (Test-YcTcpPort -ComputerName $uri.Host -Port $port)){
  Exit-Yc 8 ('the GLPI agent is installed, its service "' + $svc.Name + '" is Running and its configuration points at ' +
    $safeUrl + ', but ' + $uri.Host + ':' + $port + ' is NOT reachable from this host. No inventory can be delivered. Check egress, DNS and the GLPI listener.') 'ERROR'
}
Write-YcLog ($uri.Host + ':' + $port + ' is reachable - the agent can deliver an inventory') 'OK'

$agentLog = ''
if($installDir){ $agentLog = Join-Path $installDir 'logs\glpi-agent.log' }
$logErrors = @()
if($agentLog){
  $sw = [Diagnostics.Stopwatch]::StartNew()
  while($sw.Elapsed.TotalSeconds -lt $VerifySec){
    if(Test-Path -LiteralPath $agentLog){ break }
    Start-Sleep -Seconds 5
  }
  if(Test-Path -LiteralPath $agentLog){
    try{
      $tail = @(Get-Content -LiteralPath $agentLog -Tail 200 -ErrorAction Stop)
      $logErrors = @($tail | Where-Object { $_ -match '(?i)\[error\]' })
      Write-YcLog ('agent log present: ' + $agentLog + ' (' + $tail.Count + ' recent lines read)')
    }catch{ Write-YcLog ('could not read ' + $agentLog + ': ' + $_.Exception.Message) 'WARN' }
  }else{
    Write-YcLog ('the agent has not written ' + $agentLog + ' within ' + $VerifySec + 's. The service is Running and configured; check the log after the next scheduled run.') 'WARN'
  }
}
if($logErrors.Count -gt 0){
  Write-YcLog ('the agent log reports ' + $logErrors.Count + ' error line(s); the most recent is: ' +
    ((($logErrors[$logErrors.Count-1]) -replace '(?i)([a-z]+://)[^/@\s]*@','$1').Trim()) +
    '. The service is Running, the configuration reads back and the server is reachable, so this is reported rather than fatal - but check it in GLPI.') 'WARN'
}

Exit-Yc 0 ('GLPI agent installed, service "' + $svc.Name + '" Running, configuration read back from ' + $regRoot +
  ' pointing at ' + $safeUrl + ' with tag "' + $regTag + '", and the server is reachable. Outbound only: no inbound port was opened.') 'OK'
