==============================================================================
 STOP - READ THIS BEFORE YOU RUN Day2-Setup.ps1
==============================================================================
 Day2-Setup.ps1 GENERATES a set of day-2 commands into C:\Scripts. Until
 2026-08-19 it wrote every one of them with an unconditional Set-Content: no
 existence check, no prompt, no log entry. On a VM that already carries the
 repaired GoldenImage payload that silently REVERTED twelve hardened scripts
 back to small, unhardened generated bodies. One of those generated bodies
 re-introduced the undocumented Acronis "--log=" switch that caused fourteen
 silent no-op installs.

 DO NOT RUN Day2-Setup.ps1 ON A VM CARRYING THE REPAIRED PAYLOAD UNLESS YOU
 UNDERSTAND THE -Regenerate SWITCH.

 As of Day2-Setup.ps1 version 1.2 (2026-08-19) the generator refuses to
 overwrite a file that already exists. It keeps the on-disk copy and logs a
 WARN line naming the file. A file that does not exist is still written as
 before. -Regenerate, and only -Regenerate, restores the old clobbering
 behaviour - it throws the repaired copies away.

------------------------------------------------------------------------------
 THE TWELVE FILES AT RISK
------------------------------------------------------------------------------
 These twelve have hardened, repaired replacements in the GoldenImage payload
 and are the ones Day2-Setup.ps1 used to overwrite:

   Register-Acronis.ps1        Activate-Windows.ps1
   Bitdefender-Register.ps1    Activate-Sql.ps1
   Osquery-Register.ps1        Defender-Exclude.ps1
   Zabbix-Register.ps1         Bitdefender-Exclude.ps1
   Snmp-Register.ps1           Set-Nic.ps1
   Root-Cause.ps1              Yallacloud.ps1

 If you pass -Regenerate on a repaired VM you lose all twelve, plus their
 .cmd wrappers. Re-deploy the payload afterwards if you do this by accident.

------------------------------------------------------------------------------
 WHAT Day2-Setup.ps1 DOES
------------------------------------------------------------------------------
 It does ONLY day-2 things. No sysprep, no drivers, no cloudbase-init, no
 account / RDP / firewall changes, no self-resuming build.

   1. Creates C:\Scripts if it is absent.
   2. Adds C:\Scripts AND EVERY SUBFOLDER OF IT to the machine (SYSTEM) PATH.
      Read that again: subfolders too. Anything executable dropped into a
      subfolder of C:\Scripts becomes callable by bare name for every user
      on the box. Keep the ACL tight (see below).
   3. Adds a Microsoft Defender exclusion for C:\Scripts.
   4. Generates 19 day-2 commands and their .cmd wrappers (see above).
   5. -Agents (the default) downloads the agent installers so the *-register
      commands work. -NoAgents skips the downloads.
   6. -Tools additionally installs the free diagnostic tools (choco / scoop)
      and the ntfy CLI. nmap is deliberately NOT installed.

 Usage (run ELEVATED):
   powershell -ExecutionPolicy Bypass -File Day2-Setup.ps1 [-Tools] [-NoAgents]
                                                           [-Regenerate] [-Help]

 Then open a NEW shell (so the new PATH is picked up) and run:
   yallacloud            lists every command in the catalog

------------------------------------------------------------------------------
 THE DEFENDER EXCLUSION - PREFER defender-exclude
------------------------------------------------------------------------------
 Day2-Setup.ps1 adds the exclusion like this:

   Add-MpPreference -ExclusionPath 'C:\Scripts' -ErrorAction SilentlyContinue

 -ErrorAction SilentlyContinue means a failure is invisible, and there is no
 readback, so the script cannot tell you whether the exclusion actually
 exists afterwards. It also does not look at who can WRITE to C:\Scripts. An
 antivirus exclusion on a directory that non-administrators can write to, on
 the system PATH, is a privilege-escalation primitive: a low-privileged user
 drops an executable there and it is both trusted by Defender and resolvable
 by name for everyone.

 PREFER the payload command instead:

   defender-exclude -Path C:\Scripts

 It PROVES the ACL first - it refuses a directory non-administrators can
 write to unless you pass -AcceptPrivEscRisk - and it READS THE EXCLUSION
 BACK out of Get-MpPreference to confirm it was really applied. It logs to
 C:\Scripts\defender-exclude.log.

------------------------------------------------------------------------------
 WHY THE EXCLUSION IS DEFENSIBLE ON A REPAIRED VM AND NOT ON AN UNREPAIRED ONE
------------------------------------------------------------------------------
 The repaired _yc-lib.ps1 hardens the C:\Scripts ACL on EVERY Start-YcLog
 call: it breaks inheritance and grants Full Control to NT AUTHORITY\SYSTEM
 and BUILTIN\Administrators only, removing everything else, and it logs what
 it removed. Because every payload command calls Start-YcLog, the directory
 is re-hardened continuously.

 So on a REPAIRED VM the exclusion covers a directory only SYSTEM and
 Administrators can write to. That is defensible.

 On an UNREPAIRED VM - a plain Day2-Setup.ps1 run with no repaired payload -
 nothing hardens the ACL. C:\Scripts inherits from C:\, BUILTIN\Users can
 typically create files there, the directory and its subfolders are on the
 SYSTEM PATH, and Defender has been told to ignore all of it. Do not leave a
 VM in that state. Either deploy the repaired payload or remove the
 exclusion with:

   defender-exclude -Path C:\Scripts -Remove

------------------------------------------------------------------------------
 Yallacloud.ps1 IS REWRITTEN WITH A REDUCED CATALOG
------------------------------------------------------------------------------
 One of the nineteen generated files is Yallacloud.ps1, the operator catalog.
 The body Day2-Setup.ps1 generates lists only the commands Day2-Setup itself
 creates - a REDUCED catalog. It is not the full payload catalog. If you
 regenerate it, operators lose the menu entries for everything the payload
 ships that Day2-Setup does not generate (SQL, backup, S3, observability,
 WebJEA, OliveTin, compliance and the rest). As of 2026-08-19 the payload
 catalog is Yallacloud.ps1 version 2.8.0; if "yallacloud" prints anything
 else on a VM you expected to be repaired, the catalog was regenerated.

==============================================================================
