@echo off
rem webjea-install -IUnderstandTheRisk -CertificateThumbprint <thumb> -MgmtCidr <cidr[,cidr]>
rem                [-ServiceAccount DOMAIN\gmsa$] [-SiteName WebJEA] [-Port 8443]
rem                [-InstallDir <path>] [-ScriptsDir <path>] [-ZipPath <zip>]
rem                [-SettingsFile <settings.jsonc>] [-AllowSelfSignedCert] [-NoFirewall] [-Help]
rem
rem *** DO NOT RUN THIS FROM AN UNATTENDED IMAGE BUILD. ***
rem WebJEA publishes PowerShell script execution as web forms, running as the IIS app pool
rem identity. Upstream supports Windows Integrated Auth ONLY and expects a DOMAIN JOINED
rem server with a gMSA. The previous version served it over PLAIN HTTP with NO authentication
rem and opened the port on every firewall profile.
rem
rem The first three parameters are mandatory. There is no HTTP binding, Anonymous auth is
rem disabled and verified, an anonymous GET must be REJECTED before success is reported, and
rem the inbound rule is scoped to -MgmtCidr on Domain+Private only.
rem Logs to C:\Scripts\webjea-install.log
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Scripts\WebJEA-Install.ps1" %*
exit /b %ERRORLEVEL%
