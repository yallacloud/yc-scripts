# yc-boot.ps1 - one boot task replacing GIGrowDisk + GINetwork + YCDEPLOY + YCGUARD.
# Creates access rules ONCE if absent. Never re-enables anything an admin turned off.
$ErrorActionPreference='SilentlyContinue'
$log='C:\Scripts\yc-boot.log'
function L($m){ Add-Content $log ("[{0}] {1}" -f (Get-Date -f 'yyyy-MM-dd HH:mm:ss'), $m) -Encoding ascii }
L '--- yc-boot start ---'

# 1. grow C: into unallocated space (portal disk resize lands live)
try { & powershell -NoProfile -ExecutionPolicy Bypass -File C:\Scripts\Grow-Disk.ps1 | Out-Null; L 'grow-disk ran' } catch { L "grow-disk: $($_.Exception.Message)" }

# 2. remove ghost NICs left behind when CloudStack hands the clone a new MAC
try { & powershell -NoProfile -ExecutionPolicy Bypass -File C:\Scripts\Set-Nic.ps1 -CleanGhosts | Out-Null; L 'set-nic -CleanGhosts ran' } catch { L "set-nic: $($_.Exception.Message)" }

# 3. access rules - CREATE ONLY IF ABSENT. -Profile Any so the Private/Public
#    classification never decides reachability. An admin who disables a rule
#    keeps it disabled; we only ever add a rule that does not exist at all.
$want = @(
  @{ n='YC-SSH-3222';  p='TCP';    port='3222' },
  @{ n='YC-RDP-3389';  p='TCP';    port='3389' },
  @{ n='YC-WinRM-5985';p='TCP';    port='5985' },
  @{ n='YC-WinRM-5986';p='TCP';    port='5986' }
)
foreach($r in $want){
  if(-not (Get-NetFirewallRule -DisplayName $r.n -EA SilentlyContinue)){
    New-NetFirewallRule -DisplayName $r.n -Direction Inbound -Action Allow -Protocol $r.p -LocalPort $r.port -Profile Any | Out-Null
    L ("created firewall rule " + $r.n)
  }
}
if(-not (Get-NetFirewallRule -DisplayName 'YC-ICMPv4' -EA SilentlyContinue)){
  New-NetFirewallRule -DisplayName 'YC-ICMPv4' -Direction Inbound -Protocol ICMPv4 -IcmpType 8 -Action Allow -Profile Any | Out-Null
  L 'created firewall rule YC-ICMPv4'
}

# 4. CloudinitAdmin: hidden always; DISABLED once first boot finished so it
#    cannot keep re-issuing the Administrator password on later boots.
#    chadmin is deliberately NOT touched - if an admin disabled it, it stays so.
$ul='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList'
if(-not (Test-Path $ul)){ New-Item -Path $ul -Force | Out-Null }
New-ItemProperty -Path $ul -Name 'CloudinitAdmin' -PropertyType DWord -Value 0 -Force | Out-Null
Remove-ItemProperty -Path $ul -Name 'chadmin' -EA 0
$fb='C:\Scripts\yc-firstboot.log'
  # 2026-08-30: this matched 'yc-firstboot end', a string _yc-lib.ps1 NEVER writes - its end
  # line is "[YALLACLOUD][yc-firstboot] [END] exit=<n>". The gate could not fire, so
  # CloudinitAdmin stayed ENABLED for the life of every clone. Match what is actually logged.
if((Test-Path $fb) -and ((Get-Content $fb -Raw -EA 0) -match '\[yc-firstboot\] \[END\] exit=')){
  $c = Get-CimInstance Win32_UserAccount -Filter "LocalAccount=true and Name='CloudinitAdmin'" -EA 0
  if($c -and -not $c.Disabled){ & net user CloudinitAdmin /active:no 2>&1 | Out-Null; L 'CloudinitAdmin disabled (first boot complete)' }

  # 4b. The cloudbase-init SERVICE, for the same reason. Disabling the account it uses was
  #     only half the job: the service is left StartupType=Automatic by the image, so it
  #     starts on EVERY reboot and re-runs its whole plugin list - including
  #     SetUserPasswordPlugin, which re-issues the Administrator password. Nothing in the
  #     estate disabled it; this is that step.
  #     Two conditions, both required:
  #       - yc-firstboot has ended (the gate above), and
  #       - the service has already STOPPED BY ITSELF, which is how it signals it finished.
  #     A running service is never killed - interrupting a first run half way through is
  #     worse than an extra reboot's worth of re-run.
  $cbiSvc = Get-CimInstance Win32_Service -Filter "Name='cloudbase-init'" -EA 0
  if($cbiSvc){
    if($cbiSvc.State -ne 'Stopped'){
      L ('cloudbase-init is ' + $cbiSvc.State + ' - still working, leaving it alone this boot')
    } elseif($cbiSvc.StartMode -match '^(Disabled)$'){
      # already done, say nothing
    } else {
      $r = $cbiSvc | Invoke-CimMethod -MethodName ChangeStartMode -Arguments @{ StartMode = 'Disabled' } -EA 0
      $now = (Get-CimInstance Win32_Service -Filter "Name='cloudbase-init'" -EA 0).StartMode
      if($now -eq 'Disabled'){
        L 'cloudbase-init DISABLED (first boot complete) - it must not re-run and re-issue the Administrator password on every reboot'
      } else {
        L ('FAILED to disable cloudbase-init - StartMode is still ' + $now + ' (ChangeStartMode returned ' + $(if($r){$r.ReturnValue}else{'no result'}) + '). It WILL re-run at the next reboot.')
      }
    }
  }
}

# 4c. ADMINISTRATOR LOCKOUT THRESHOLD - every boot, because a locked Administrator is
#     indistinguishable from a broken image and costs an hour every time.
#     A public IP takes roughly 3000 brute-force logons an hour. The stock threshold is 10,
#     so the account locks within seconds of the VM being reachable and SSH, WinRM and RDP
#     all start refusing a password that is perfectly correct. Measured on the v264 clone
#     vc2019test 2026-09-08: threshold was still 10, straight out of the sealed image.
#     Idempotent and silent when it is already 0 - it only writes when it has to.
#     'net accounts' prints a DISABLED threshold as the word Never, not as 0. Stripping the
#     non-digits from that line returns an empty string, so this block used to re-run net
#     accounts on every boot of a machine that was already correct and then log
#     "FAILED to clear the lockout threshold - it still reads" with nothing after it.
#     Seen on VC2022SQLTEST 2026-09-09. Same normaliser as yc-preseal's gate.
function Get-YcLockout{
  $l = @(& net accounts) | Where-Object { $_ -match 'Lockout threshold' } | Select-Object -First 1
  if(-not $l){ return '?' }
  $v = ($l -split ':')[-1].Trim()
  if($v -match '^(Never|Nunca|Jamais|Nie)$'){ return '0' }
  $d = $v -replace '[^0-9]',''
  if($d -eq ''){ return '?' }
  return $d
}
try{
  $lt = Get-YcLockout
  if($lt -ne '0'){
    & net accounts /lockoutthreshold:0 2>&1 | Out-Null
    $now = Get-YcLockout
    if($now -eq '0'){ L ('lockout threshold ' + $lt + ' -> 0') }
    else { L ('FAILED to clear the lockout threshold - it still reads ' + $now) }
  }
}catch{ L ("lockout threshold: $($_.Exception.Message)") }

# 4e. CONSOLE LOGON FOCUS - every boot, for the same reason as the lockout threshold:
#     anything that runs once does not hold. yc-firstboot sets SelectedUserSID correctly on
#     the clone, and then the FIRST person who clicks the chadmin tile on the console makes
#     Windows overwrite it, permanently. Measured on VC2022SQLTEST 2026-09-09: the value was
#     ...-500 (Administrator) at 11:05:50 and 11:15:41, a console click put it back to
#     ...-1000 (chadmin), and it was still chadmin after the next reboot while
#     LastLoggedOnSAMUser still read .\Administrator.
#     SelectedUserSID is machine-specific, so it is resolved here from the local -500
#     account and never baked into the image. Silent when it is already right.
try{
  $adm = Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=true' -EA SilentlyContinue |
         Where-Object { $_.SID -like '*-500' } | Select-Object -First 1
  if($adm){
    $lu = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI'
    $cur = (Get-ItemProperty $lu -Name 'SelectedUserSID' -EA SilentlyContinue).SelectedUserSID
    if($cur -ne $adm.SID){
      Set-ItemProperty $lu -Name 'LastLoggedOnUser'        -Value ('.\' + $adm.Name) -EA SilentlyContinue
      Set-ItemProperty $lu -Name 'LastLoggedOnSAMUser'     -Value ('.\' + $adm.Name) -EA SilentlyContinue
      Set-ItemProperty $lu -Name 'LastLoggedOnDisplayName' -Value $adm.Name           -EA SilentlyContinue
      Set-ItemProperty $lu -Name 'SelectedUserSID'         -Value $adm.SID            -EA SilentlyContinue
      L ('console logon focus ' + $cur + ' -> ' + $adm.Name + ' ' + $adm.SID)
    }
  }
}catch{ L ("console logon focus: $($_.Exception.Message)") }

# 4d. GATEWAY - deliberately NOT here.
#     -AtStartup on a clone routinely fires BEFORE DHCP has handed out an address, and a
#     gateway check with no gateway yet is a no-op that looks exactly like a pass. The
#     repair belongs to the YC-NetFix task, which triggers on NetworkProfile event 10000
#     ("network connected") - raised after the address is assigned, and again whenever an
#     interface comes back up. Install-YcTasks registers it; Seal-Manual gates it.

# 5. deploy audit line
$os=(Get-CimInstance Win32_OperatingSystem).Caption
$ip=(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' } | Select-Object -First 1).IPAddress
$xpr=(& cscript //nologo C:\Windows\System32\slmgr.vbs /xpr 2>&1) -join ' '
L ("host=$env:COMPUTERNAME ip=$ip os=$os lic=$xpr")
L '--- yc-boot end ---'
