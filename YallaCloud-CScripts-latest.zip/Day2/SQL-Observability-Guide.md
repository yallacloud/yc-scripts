# SQL Server + Windows Observability & Maintenance Guide

**For the YallaCloud golden image** * Windows Server 2016-2025 * SQL Server 2016-2025 (Express / Standard / Enterprise / Developer) * open-source only (OpenTelemetry + Prometheus + OpenObserve).

Everything here is installed and configured by **`Setup-Observability.ps1`** (in this bundle). Run it **elevated on a deployed VM** (endpoints/tokens are per-deployment), or drop it in `C:\Scripts` before sealing to bake it into the template. It has retry + failsafe on every download (GitHub "latest" API first, then a pinned fallback, then BITS/HTTP x4 in a timeout-bounded job).

```powershell
Setup-Observability.ps1 -OOEndpoint https://oo.example.com -OOOrg default -OOAuth "Basic BASE64EMAILPASS" `
                        [-OOStream default] [-SqlInstance localhost] [-SqlUser sa -SqlPass ***] `
                        [-PromPort 9182] [-SqlExporterPort 9399]
```

---

## 1. SQL Server monitoring & telemetry strategy

### Key health metrics (and where this stack gets them)

| Metric | Why it matters | Source in this stack |
|---|---|---|
| **Buffer Cache Hit Ratio** | % of pages served from memory; low = memory pressure | `sql_exporter` -> `sys.dm_os_performance_counters` |
| **Page Life Expectancy (PLE)** | seconds a page stays in cache; low/volatile = memory pressure | `sql_exporter` (perf counter) |
| **Batch Requests/sec** | workload throughput | `sql_exporter` |
| **SQL Compilations/sec** | high vs batch = plan-cache/param-sniffing issues | `sql_exporter` |
| **Deadlocks** | contention | `sql_exporter` (`Number of Deadlocks/sec`) |
| **Disk latency per DB file** | storage bottlenecks per data/log file | `sql_exporter` -> `sys.dm_io_virtual_file_stats` (io_stall) |
| **Database state** | ONLINE / SUSPECT / RECOVERING | `sql_exporter` -> `sys.databases` |
| Host CPU / RAM / disk / net | OS-level correlation | `windows_exporter` (Prometheus) **and** OTel `hostmetrics` |
| SQL instance metrics | connections, locks, memory | OTel **`sqlserver`** receiver (perf-counter based, no query needed) |

### Logs

- **SQL Server ERRORLOG** -> OTel **`filelog`** receiver tailing `C:\Program Files\Microsoft SQL Server\MSSQL*\MSSQL\Log\ERRORLOG` -> OpenObserve.
- **SQL Server Agent log / SQL events in the Windows Application log** (source `MSSQLSERVER` / `SQLSERVERAGENT`) -> OTel **`windowseventlog`** receiver (Application channel) -> OpenObserve.
- **Windows Security/System/Application** -> OTel `windowseventlog` (three channels). The golden image expands each log to 256 MB and enables Logon/Logoff, Account Management, and Process Creation (with command line) auditing.

### Collector options (pick with `-Collector`; default = **alloy**)

- **`alloy` (default, recommended) - Grafana Alloy.** Grafana Agent reached **EOL on 2025-11-01**; Alloy is its successor. Alloy has **built-in `prometheus.exporter.windows` and `prometheus.exporter.mssql`** plus `loki.source.windowsevent`, so **one agent** collects Windows + SQL metrics + event logs and pushes to OpenObserve via **Prometheus remote_write** (`/api/<org>/prometheus/api/v1/write`) and **Loki push** (`/api/<org>/loki/api/v1/push`). Silent install (`alloy-installer-windows-amd64.exe /S /CONFIG=...`), runs as the `Alloy` service. Pass `-OOUser`/`-OOPass` for its basic auth.
- **`otel` - OpenTelemetry Collector Contrib -> OpenObserve (OTLP/HTTP).** Logs + host + SQL metrics + SQL ERRORLOG, batched, pushed to `https://<host>/api/<org>` with an `Authorization` header and `stream-name`. Best when you want OTLP/traces.
- **`prometheus` - standalone exporters (pull).** `windows_exporter` (:9182) + `sql_exporter` (:9399) with the ready `mssql_health` collector. Point Prometheus/VictoriaMetrics at `http://<vm>:9182/metrics` and `:9399/metrics`.
- **`all`** installs every collector (watch for port overlap; use for testing only).

With `alloy` (default) you do **not** also install the standalone windows_exporter/sql_exporter - Alloy embeds them.

### All editions - including Express

- **Express / Web** have **no SQL Server Agent**. So **all scheduled maintenance is driven by Windows Task Scheduler** calling `sqlcmd` - `Setup-Observability.ps1` creates the tasks `YC-SQL-IndexOptimize` (weekly) and `YC-SQL-IntegrityCheck` (weekly) for exactly this reason. Standard/Enterprise can use these too, or convert them to SQL Agent jobs.
- **Express memory/CPU caps** (1 socket/4 cores, ~1.4 GB buffer pool, 10 GB/DB): watch PLE and Buffer Cache Hit Ratio closely - they move fast on the small cap. `sql_exporter` + `windows_exporter` both run fine against Express (they only read DMVs/perf counters).
- `sql_exporter` uses **Windows (trusted) auth by default**; pass `-SqlUser/-SqlPass` for SQL auth. Grant the service account `VIEW SERVER STATE` (+ `CONNECT`) - that's all the DMV queries need.

---

## 2. Open-source maintenance bundles (links + usage)

All three are downloaded/installed by `Setup-Observability.ps1` into `C:\SQL_Maintenance` (Ola + Brent Ozar) and the PowerShell gallery (dbatools). First run: `C:\SQL_Maintenance\Run-Maintenance.cmd deploy`.

### a) Ola Hallengren - SQL Server Maintenance Solution
- **Link:** https://ola.hallengren.com/scripts/MaintenanceSolution.sql
- Index/stats optimization, integrity checks (DBCC), smart backups. Deploy once, then call the procs:
```sql
EXEC dbo.IndexOptimize @Databases='USER_DATABASES', @UpdateStatistics='ALL';
EXEC dbo.DatabaseIntegrityCheck @Databases='USER_DATABASES';
EXEC dbo.DatabaseBackup @Databases='USER_DATABASES', @Directory='D:\Backup', @BackupType='FULL';
```
On Express these run via the Windows scheduled tasks (`Run-Maintenance.cmd index|integrity`).

### b) Brent Ozar - First Responder Kit
- **Link:** https://github.com/BrentOzarULTD/SQL-Server-First-Responder-Kit (deploy `Install-All-Scripts.sql`)
- Diagnostics: `EXEC sp_Blitz` (health), `sp_BlitzFirst` (what's happening now), `sp_BlitzCache` (worst queries), `sp_BlitzWho` (live sessions).

### c) dbatools - PowerShell for SQL Server
- **Install:** `Install-Module dbatools` (PowerShell Gallery). Docs: https://dbatools.io
- Automation/migration/checks, e.g. `Get-DbaLastBackup`, `Test-DbaLastBackup`, `Invoke-DbaQuery`, `Export-DbaInstance`.

---

## 3. What the golden-image automation does (`Setup-Observability.ps1`)

- **Windows OS auditing & log sizing:** expands Security/Application/System event logs to 256 MB; enables Logon/Logoff, Account Management, Process Creation (with command line) audit policies.
- **OpenTelemetry Collector Contrib:** downloads the latest contrib build, writes `config.yaml` (windowseventlog x3 + hostmetrics + `sqlserver` + `filelog` for ERRORLOG; `otlphttp` exporter -> OpenObserve; `batch` + `resourcedetection` processors), and runs it as the **`YC-OtelCollector`** service (Automatic-Delayed).
- **Prometheus:** `windows_exporter` (MSI, :9182) and **`sql_exporter`** (:9399) with a ready `mssql_health` collector (the metrics in Sec.1). Firewall rules opened per port.
- **Maintenance (Express-friendly):** `C:\SQL_Maintenance` with Ola + First Responder Kit + a `Run-Maintenance.cmd` sqlcmd wrapper + Windows scheduled tasks (the SQL-Agent replacement). dbatools installed.
- **Operational best practices:** all monitoring services set to **Automatic (Delayed Start)** so they behave on sysprepped clones and don't slow boot; nothing depends on inbound access except the two Prometheus scrape ports you open.

---

## 4. Operational best practices

- **Automatic (Delayed Start)** for `YC-OtelCollector`, `YC-SqlExporter`, `windows_exporter` - sysprep-safe, avoids boot contention. (Set automatically.)
- **Least privilege:** the exporter service account needs only `VIEW SERVER STATE`; the OTel `sqlserver` receiver uses perf counters (local, no SQL login).
- **Bake vs. per-deploy:** the *binaries/config* can be baked into the template, but set the **OpenObserve endpoint/token and SQL creds per deployment** (they differ per customer) - so run `Setup-Observability.ps1` (or `observability-register`) on the clone, or pass them via cloud-init user-data.
- **Verify after install:** `http://<vm>:9182/metrics`, `http://<vm>:9399/metrics`, and in OpenObserve the `default` stream for logs/metrics. The setup log is `C:\Scripts\Observability\observability-setup.log`.

Sources: [OpenTelemetry Collector releases](https://github.com/open-telemetry/opentelemetry-collector-releases/releases), [OpenObserve OTLP ingestion](https://openobserve.ai/docs/ingestion/logs/otlp/), [prometheus-community/windows_exporter](https://github.com/prometheus-community/windows_exporter/releases), [burningalchemist/sql_exporter](https://github.com/burningalchemist/sql_exporter), [Ola Hallengren](https://ola.hallengren.com/), [Brent Ozar First Responder Kit](https://github.com/BrentOzarULTD/SQL-Server-First-Responder-Kit), [dbatools](https://dbatools.io/).
