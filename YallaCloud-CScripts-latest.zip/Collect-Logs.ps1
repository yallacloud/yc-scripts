param(
  [int]$Days = 7,
  [string]$OutDir = 'C:\Scripts\logs',
  [switch]$Perf,
  [int]$PerfSeconds = 60,
  [switch]$NoRedact,
  [switch]$IncludeSecurityLog,
  [int]$MaxSizeMB = 512,
  [switch]$S3,
  [switch]$KeepStaging,
  [switch]$Help
)
# =====================================================================================
# Collect-Logs.ps1 - YallaCloud golden image. PowerShell 5.1 only. ASCII only.
# ONE command that gathers everything needed to diagnose a VM into ONE portable archive.
#
# ============================ WHAT THIS IS, AND WHY ============================
# NEW COMMAND. Nothing in the toolkit produced a single artifact you could attach to a
# support ticket. Today an operator has to RDP in, run diag, run rootcause, run
# report-inventory, then hunt through C:\Scripts\*.log, %ProgramData%\Acronis and Event
# Viewer by hand, and every one of those steps needs a session on the box.
#
# DESIGN DECISIONS, AND THE REASONS:
#
#  1. EVERY STEP FAILS INDEPENDENTLY. Each collector runs inside Invoke-Step, which catches
#     everything, records OK / FAILED / SKIPPED with the reason in 00-summary\manifest.csv,
#     and lets the run continue. A missing SQL Server, a locked Zabbix log or a permission
#     error on the Security channel must not cost you the other 40 collectors. The manifest
#     is the first thing in the archive, so support can see what was NOT collected and why.
#
#  2. IT NEVER TOUCHES A SOURCE LOG. Everything is COPIED into a staging folder first, and
#     redaction only ever rewrites the STAGED COPY. No source file is modified, moved,
#     truncated or deleted, ever - including on the failure paths. Files that are open and
#     locked are read through a shared-read FileStream rather than skipped.
#
#  3. IT DOES NOT DUPLICATE THE COMMANDS THAT ALREADY EXIST. Diag-System.ps1 owns chkdsk /
#     sfc / DISM, Root-Cause.ps1 owns the bugcheck analysis (and runs cdb with no symbol
#     path and no timeout at every boot - this command deliberately does NOT invoke cdb, so
#     collecting logs can never hang on a debugger), and Report-Inventory.ps1 owns the
#     installed-software and CloudStack-metadata inventory. Collect-Logs COLLECTS the output
#     of those three (diag-*.txt, rootcause-*.txt, inventory-report\latest.json) instead of
#     re-running them, and only generates its own installed-programs.csv when there is no
#     inventory JSON, or the newest one is older than -Days.
#
#  4. REDACTION IS ON BY DEFAULT AND IS HONEST ABOUT ITS LIMITS. Every staged TEXT file goes
#     through the library's Protect-YcSecret / Write-YcRedacted pass before the archive is
#     built, so tokens and passwords sitting in old C:\Scripts transcripts are not shipped to
#     a third party. WHAT IS REDACTED: values that follow a secret-shaped name
#     (token=, password=, --reg-token, -SaPassword, apikey:, connectionstring=, ...) inside
#     .log .txt .csv .json .xml .ini .conf .cfg .yml .yaml .out files. WHAT IS NOT REDACTED:
#     .evtx event log binaries (they are shipped as-is, so that Event Viewer can open them -
#     the CSV twin of each channel IS redacted), anything a secret-shaped name does not
#     precede (a bare credential on a line of its own), certificate and key FILES (none are
#     collected on purpose), and customer data inside application logs. -NoRedact turns the
#     pass off and logs a WARN saying so.
#
#  5. IT IS BOUNDED. Event logs are limited to the last -Days days; each collector has a
#     per-file and per-folder cap; and before the archive is built the staging folder is
#     measured against -MaxSizeMB and trimmed in a documented priority order (.evtx first,
#     then the perf capture, then the oldest vendor logs) so this command can never fill the
#     disk of a VM that is already sick because its disk is full.
#
#  6. THE ARCHIVE IS PROVED, NOT ASSUMED. Compress-Archive ships in Microsoft.PowerShell.Archive
#     with PowerShell 5.0+, so it is present on Server 2016 with no extra install; the script
#     still checks Get-Command for it and fails cleanly if it is missing. After compressing,
#     the zip is proved to exist, to be non-zero, and to OPEN: it is read back with
#     System.IO.Compression.ZipFile and the entry count is reported.
#
#  7. EVERY Out-String CARRIES -Width 500 ON PURPOSE. DO NOT "TIDY" IT AWAY. In a host with
#     no console - which is every way this command actually runs: cloud-init, a SYSTEM
#     scheduled task, an RMM job - Out-String's default width collapses to nothing and
#     'Format-Table ... | Out-String' returns an EMPTY STRING. Verified: the same pipeline
#     that prints a table interactively wrote a 2-character file non-interactively. Without
#     -Width, network.txt, firewall-rules.txt, acronis-services.txt and the STEPS table in
#     summary.txt would all ship blank, and nobody would notice until a support case needed
#     them. The .csv collectors use Export-Csv and are not affected.
#
# Every exit is through Exit-Yc. No -ErrorAction SilentlyContinue on a load-bearing step.
# =====================================================================================

. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'collect-logs'

if($Help){
@"
collect-logs  -  gather every log and system fact needed to diagnose this VM into ONE
                 portable, redacted .zip for support.

USAGE:
  collect-logs
  collect-logs -Days 14
  collect-logs -Days 3 -IncludeSecurityLog -Perf
  collect-logs -OutDir D:\support -MaxSizeMB 256
  collect-logs -S3
  collect-logs -Help

PARAMETERS:
  -Days                How far back to bound the event logs and the time-filtered file
                       collectors. Default 7.
  -OutDir              Where the archive is written. Default C:\Scripts\logs
  -Perf                Also take a short Performance Monitor capture (see -PerfSeconds).
                       Counter names are locale-dependent; if the capture is not available
                       on this build the step is recorded as FAILED and the run continues.
  -PerfSeconds         Length of the -Perf capture in seconds. Default 60.
  -NoRedact            Do NOT run the redaction pass. The archive may then contain tokens
                       and passwords from old transcripts. Logged as a WARN.
  -IncludeSecurityLog  Also export the Security event log. Off by default: it is large, it
                       contains 4688 process command lines (which is where secrets passed on
                       a command line end up), and most support cases do not need it.
  -MaxSizeMB           Budget for the collected data before compression. Default 512.
                       Over budget, content is dropped in this order, with each drop logged:
                         1. .evtx binaries (their CSV twins are kept and are readable)
                         2. the -Perf capture
                         3. the oldest vendor log files
  -S3                  If C:\Scripts\Transfer-S3.ps1 exists, hand the finished archive to it.
                       If it does not exist this is a WARN, not a failure - the archive is
                       still produced and its path reported.
  -KeepStaging         Keep the uncompressed staging folder next to the archive.
  -Help                Show this help and exit.

WHAT IS COLLECTED (one subfolder each; a failing step never aborts the run):
  00-summary          run summary + manifest.csv (what was collected, skipped, or failed)
  01-yallacloud       C:\Scripts\*.log and *.log.1, the newest yc-compliance.txt/.json,
                      the newest diag-*.txt / rootcause-*.txt, inventory-report\latest.json
  02-eventlogs        System, Application, Setup (+ Security with -IncludeSecurityLog) as
                      .evtx AND as .csv, plus a YallaCloud-source event extract
  03-acronis          %ProgramData%\Acronis\InstallationLogs (recursive) + agent logs +
                      C:\Scripts\acronis-install.log
  04-bitdefender      Bitdefender / GravityZone endpoint logs
  05-zabbix           Zabbix agent log and zabbix_agentd/agent2 conf
  06-salt             Salt minion log and minion conf
  07-osquery          osquery results/status logs and osquery.conf
  08-wazuh            Wazuh / ossec-agent ossec.log and ossec.conf
  09-glpi             GLPI agent logs
  10-sqlserver        SQL Server ERRORLOG*, SQLAGENT.OUT*, setup bootstrap Summary.txt
  11-iis              IIS W3SVC logs within -Days, site list (applicationHost.config is
                      deliberately NOT collected - it can carry app pool credentials)
  12-systemstate      OS version/build, uptime, hotfixes, services, scheduled tasks,
                      disks/volumes/free space, network config + routes + DNS, firewall
                      rules, installed programs (only if no fresh inventory JSON exists),
                      pending reboot, time sync (w32tm), and the last boot events
  13-perf             optional -Perf capture + process snapshots

REDACTION:
  ON by default. Applies to staged COPIES only - no source log is ever modified.
  REDACTED     : values following a secret-shaped name (token, password, apikey, secret,
                 psk, connectionstring, --reg-token, -SaPassword, ...) inside
                 .log .txt .csv .json .xml .ini .conf .cfg .yml .yaml .out files.
  NOT REDACTED : .evtx event log BINARIES - they are shipped as-is so Event Viewer can open
                 them. The CSV twin of every channel IS redacted, so if you need a redacted
                 view of the events, read the .csv. Also not redacted: a bare secret with no
                 name in front of it, and customer data inside application logs.

EXIT CODES:
  0  archive created, non-zero, and verified to open
  1  the archive could not be created or could not be opened after creation
  2  usage error (-Days or -MaxSizeMB out of range, -OutDir not creatable)
  5  not running as Administrator

EXAMPLES:
  collect-logs
  collect-logs -Days 14 -IncludeSecurityLog
  collect-logs -Perf -PerfSeconds 120
  collect-logs -OutDir D:\support -MaxSizeMB 256 -KeepStaging
  collect-logs -S3
  collect-logs -Help

Log: C:\Scripts\collect-logs.log   Archive: <OutDir>\<hostname>-<timestamp>.zip
"@ | Write-Host -ForegroundColor Cyan
  Exit-Yc 0 'help shown' 'INFO'
}

Assert-YcPrereqs -NeedAdmin

# ------------------------------------------------------------------------------------
# Validate arguments and prepare the output / staging folders
# ------------------------------------------------------------------------------------

if($Days -lt 1 -or $Days -gt 365){
  Exit-Yc 2 ('-Days must be between 1 and 365 (got ' + $Days + ').') 'ERROR'
}
if($MaxSizeMB -lt 16 -or $MaxSizeMB -gt 8192){
  Exit-Yc 2 ('-MaxSizeMB must be between 16 and 8192 (got ' + $MaxSizeMB + ').') 'ERROR'
}
if($PerfSeconds -lt 5 -or $PerfSeconds -gt 900){
  Exit-Yc 2 ('-PerfSeconds must be between 5 and 900 (got ' + $PerfSeconds + ').') 'ERROR'
}
if(-not (Get-Command Compress-Archive -ErrorAction SilentlyContinue)){
  Exit-Yc 1 'Compress-Archive is not available in this PowerShell. It ships in Microsoft.PowerShell.Archive with PowerShell 5.0 and later; this host needs WMF 5.1.' 'ERROR'
}

try{
  if(-not (Test-Path -LiteralPath $OutDir)){ New-Item -ItemType Directory -Path $OutDir -Force | Out-Null }
}catch{
  Exit-Yc 2 ('-OutDir could not be created: ' + $OutDir + ' - ' + $_.Exception.Message) 'ERROR'
}

$Stamp   = Get-Date -Format 'yyyyMMdd-HHmmss'
$BaseName= $env:COMPUTERNAME + '-' + $Stamp
$Stage   = Join-Path $OutDir ('_staging-' + $BaseName)
$ZipPath = Join-Path $OutDir ($BaseName + '.zip')
$Since   = (Get-Date).AddDays(-1 * $Days)
$SinceMs = [int64]$Days * 86400000

New-Item -ItemType Directory -Path $Stage -Force | Out-Null
Write-YcLog ('collecting into ' + $Stage + ' - window: last ' + $Days + ' day(s), since ' + $Since.ToString('yyyy-MM-dd HH:mm:ss')) 'INFO'
if($NoRedact){ Write-YcLog '-NoRedact given: the archive will NOT be scrubbed. It may contain registration tokens and passwords from old C:\Scripts transcripts. Do not send it to a third party.' 'WARN' }

# Per-collector caps. These exist so one runaway log cannot eat the whole budget.
$MaxFileMB   = 32
$MaxFolderMB = 64
$MaxFilesPer = 300
$MaxMsgChars = 2000
$MaxCsvEvents= 20000

$script:StepRows = New-Object System.Collections.ArrayList

# ------------------------------------------------------------------------------------
# Hardened redaction pattern - _yc-lib v2's $YcSecretRxParam has no left-hand anchor, so
# it matches the '-token' inside the literal 'by-token' and then consumes the NEXT word as
# the value. On a collected Acronis transcript that means:
#   '--registration by-token --reg-token ABC12-SECRET'
#     -> '--registration by-token **** ABC12-SECRET'    (the switch name masked, the TOKEN
#                                                        left in the clear)
# Write-YcRedacted uses the same pattern, so the library pass alone would ship a working
# registration token to support. This second pass anchors the flag to a whitespace / quote /
# line boundary and refuses to treat a following '-switch' as a value. It runs on STAGED
# COPIES only. The library file is not modified.
# ------------------------------------------------------------------------------------
$FlagSecretNames = @('reg-token','reg-password','anti-tamper-password','agent-account-password') + $script:YcSecretParams
$RxFlagSecret = '(?i)(?<=^|[\s"''])(-{1,2}[\w.]*(?:' +
    ((($FlagSecretNames | Sort-Object { $_.Length } -Descending) | Select-Object -Unique) -join '|') +
    ')[\w.-]*)([:=]|\s+)(?![-/])("[^"]*"|''[^'']*''|[^\s;,&|]+)'

# Rewrites a STAGED file with the anchored pattern applied. Returns the number of values
# masked. Never called on a source log - only on a copy already inside the staging folder.
#
# ORDER MATTERS, AND IT IS THE OPPOSITE OF THE OBVIOUS ONE. This pass must run BEFORE the
# library's Write-YcRedacted, not after. The library's unanchored pattern masks the SWITCH
# NAME ('--reg-token' -> '***********') and leaves the value; once that has happened the
# anchored pattern can no longer recognise the flag, and the token survives into the
# archive. Verified against _yc-lib v2.0.0. Masking is length-preserving, matching the
# library's convention so log columns stay aligned.
function Invoke-YcHardRedact{
  param([string]$Path)
  if(-not (Test-Path -LiteralPath $Path)){ return 0 }
  $txt = ''
  try{ $txt = [System.IO.File]::ReadAllText($Path) }catch{ return 0 }
  if(-not $txt){ return 0 }
  $new = ''
  try{
    $new = [regex]::Replace($txt,$RxFlagSecret,{ param($m)
              $v = $m.Groups[3].Value
              $q = ''
              if($v.Length -ge 2 -and ($v[0] -eq '"' -or $v[0] -eq "'")){ $q = [string]$v[0] }
              $inner = $v
              if($q -ne ''){ $inner = $v.Substring(1,$v.Length-2) }
              $m.Groups[1].Value + $m.Groups[2].Value + $q + ('*' * $inner.Length) + $q })
  }catch{ return 0 }
  if($new -eq $txt){ return 0 }
  $hits = 0
  try{
    $hits = [regex]::Matches($txt,$RxFlagSecret).Count
    [System.IO.File]::WriteAllText($Path,$new)
  }catch{ return 0 }
  return $hits
}

# ------------------------------------------------------------------------------------
# Primitives
# ------------------------------------------------------------------------------------

# Copies one file, falling back to a shared-read stream copy when the source is open and
# locked by its owner (Zabbix, SQL Server and the Acronis agent all hold their logs open).
# NEVER modifies the source.
function Copy-YcLocked{
  param([string]$Path,[string]$Destination)
  try{
    Copy-Item -LiteralPath $Path -Destination $Destination -Force -ErrorAction Stop
    return $true
  }catch{
    $in = $null; $out = $null
    try{
      $in  = New-Object System.IO.FileStream($Path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
      $out = New-Object System.IO.FileStream($Destination,[System.IO.FileMode]::Create,[System.IO.FileAccess]::Write,[System.IO.FileShare]::None)
      $in.CopyTo($out)
      return $true
    }catch{
      return $false
    }finally{
      if($out){ try{ $out.Close() }catch{} }
      if($in){ try{ $in.Close() }catch{} }
    }
  }
}

# Copies files matching -Include from -Source (optionally recursive, optionally newer than
# -Newer) into -Dest, flattening the relative path into the file name so that a deep vendor
# log tree cannot blow past MAX_PATH. Returns "n file(s), m KB" or a reason string.
function Copy-YcTree{
  param(
    [string]$Source,
    [string]$Dest,
    [string[]]$Include = @('*.log','*.txt'),
    [switch]$Recurse,
    [datetime]$Newer,
    [int]$MaxFiles = 300,
    [int]$FileCapMB = 32,
    [int]$FolderCapMB = 64
  )
  if(-not $Source -or -not (Test-Path -LiteralPath $Source)){ return ('not present: ' + $Source) }
  $items = @()
  try{
    if($Recurse){ $items = @(Get-ChildItem -LiteralPath $Source -Include $Include -File -Recurse -ErrorAction SilentlyContinue) }
    else        { $items = @(Get-ChildItem -Path (Join-Path $Source '*') -Include $Include -File -ErrorAction SilentlyContinue) }
  }catch{
    return ('could not list ' + $Source + ': ' + $_.Exception.Message)
  }
  if($Newer){ $items = @($items | Where-Object { $_.LastWriteTime -ge $Newer }) }
  if($items.Count -eq 0){ return ('no matching files in ' + $Source) }
  $items = @($items | Sort-Object LastWriteTime -Descending)

  $copied = 0; $skippedBig = 0; $failed = 0; $bytes = 0L
  $srcLen = $Source.TrimEnd('\').Length
  foreach($f in $items){
    if($copied -ge $MaxFiles){ break }
    if($bytes -ge ($FolderCapMB * 1MB)){ break }
    if($f.Length -gt ($FileCapMB * 1MB)){ $skippedBig++; continue }
    $rel = $f.FullName
    if($rel.Length -gt $srcLen){ $rel = $rel.Substring($srcLen).TrimStart('\','/') }
    else { $rel = $f.Name }
    $flat = ($rel -replace '[\\/:]','_')
    $target = Join-Path $Dest $flat
    if(Copy-YcLocked -Path $f.FullName -Destination $target){ $copied++; $bytes += $f.Length }
    else{ $failed++ }
  }
  $msg = ('' + $copied + ' file(s), ' + [int]($bytes/1KB) + ' KB from ' + $Source)
  if($skippedBig -gt 0){ $msg += ('; ' + $skippedBig + ' skipped over ' + $FileCapMB + ' MB') }
  if($failed -gt 0){ $msg += ('; ' + $failed + ' unreadable') }
  return $msg
}

function Copy-YcNewest{
  param([string]$Source,[string]$Filter,[string]$Dest,[int]$Count = 3)
  if(-not (Test-Path -LiteralPath $Source)){ return ('not present: ' + $Source) }
  $f = @()
  try{ $f = @(Get-ChildItem -Path (Join-Path $Source $Filter) -File -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending | Select-Object -First $Count) }catch{}
  if($f.Count -eq 0){ return ('no ' + $Filter + ' in ' + $Source) }
  $n = 0
  foreach($x in $f){ if(Copy-YcLocked -Path $x.FullName -Destination (Join-Path $Dest $x.Name)){ $n++ } }
  return ('' + $n + ' newest ' + $Filter)
}

function Out-YcText{
  param([string]$Dest,[string]$Name,$Content)
  $p = Join-Path $Dest $Name
  try{
    $Content | Out-File -FilePath $p -Encoding ascii -Width 500 -ErrorAction Stop
    return $true
  }catch{
    try{ ('collection error: ' + $_.Exception.Message) | Out-File -FilePath $p -Encoding ascii }catch{}
    return $false
  }
}

function Out-YcCsv{
  param([string]$Dest,[string]$Name,$Rows)
  $p = Join-Path $Dest $Name
  try{
    $Rows | Export-Csv -Path $p -NoTypeInformation -Encoding ASCII -ErrorAction Stop
    return $true
  }catch{
    try{ ('collection error: ' + $_.Exception.Message) | Out-File -FilePath $p -Encoding ascii }catch{}
    return $false
  }
}

# The unit of collection. Anything a step throws is recorded and the run continues.
function Invoke-Step{
  param([string]$Name,[string]$Folder,[scriptblock]$Body)
  $sw = [Diagnostics.Stopwatch]::StartNew()
  $status = 'OK'
  $detail = ''
  $dest = Join-Path $Stage $Folder
  try{
    if(-not (Test-Path -LiteralPath $dest)){ New-Item -ItemType Directory -Path $dest -Force | Out-Null }
    $r = & $Body $dest
    if($null -ne $r){ $detail = (@($r) -join '; ') }
  }catch{
    $status = 'FAILED'
    $detail = (([string]$_.Exception.Message) -replace '[\r\n]+',' ')
  }
  $sw.Stop()
  $files = 0; $bytes = 0L
  try{
    $inv = @(Get-ChildItem -LiteralPath $dest -Recurse -File -ErrorAction SilentlyContinue)
    $files = $inv.Count
    foreach($i in $inv){ $bytes += $i.Length }
  }catch{}
  if($status -eq 'OK' -and $files -eq 0){ $status = 'EMPTY' }
  [void]$script:StepRows.Add([pscustomobject]@{
    Step    = $Name
    Folder  = $Folder
    Status  = $status
    Files   = $files
    KB      = [int]($bytes/1KB)
    Seconds = [math]::Round($sw.Elapsed.TotalSeconds,1)
    Detail  = (Protect-YcSecret $detail)
  })
  $lvl = 'OK'
  if($status -eq 'FAILED'){ $lvl = 'WARN' }
  elseif($status -eq 'EMPTY'){ $lvl = 'INFO' }
  Write-YcLog ('[' + $status + '] ' + $Name + ' -> ' + $Folder + ' (' + $files + ' file(s), ' + [int]($bytes/1KB) + ' KB) ' + $detail) $lvl
}

# ------------------------------------------------------------------------------------
# 01 - YallaCloud command transcripts and reports
# ------------------------------------------------------------------------------------

Invoke-Step 'YallaCloud transcripts + reports' '01-yallacloud' {
  param($dest)
  $notes = @()
  $notes += (Copy-YcTree -Source 'C:\Scripts' -Dest $dest -Include @('*.log','*.log.1') -MaxFiles $MaxFilesPer -FileCapMB $MaxFileMB -FolderCapMB $MaxFolderMB)

  # newest compliance report, wherever the gate wrote it
  $comp = @()
  foreach($root in @('C:\Scripts','C:\build\artifacts')){
    if(Test-Path -LiteralPath $root){
      try{ $comp += @(Get-ChildItem -LiteralPath $root -Recurse -File -Include 'yc-compliance.txt','yc-compliance.json' -ErrorAction SilentlyContinue) }catch{}
    }
  }
  if($comp.Count -gt 0){
    $n = 0
    foreach($grp in ($comp | Group-Object Extension)){
      $newest = $grp.Group | Sort-Object LastWriteTime -Descending | Select-Object -First 1
      if(Copy-YcLocked -Path $newest.FullName -Destination (Join-Path $dest ('yc-compliance-' + $newest.LastWriteTime.ToString('yyyyMMdd-HHmmss') + $newest.Extension))){ $n++ }
    }
    $notes += ('' + $n + ' compliance report(s)')
  }else{
    $notes += 'no yc-compliance report on this host'
  }

  # output of the sibling commands - collected, NOT re-run
  $notes += (Copy-YcNewest -Source 'C:\Scripts' -Filter 'diag-*.txt' -Dest $dest -Count 3)
  $notes += (Copy-YcNewest -Source 'C:\Scripts' -Filter 'rootcause-*.txt' -Dest $dest -Count 3)
  $notes += (Copy-YcNewest -Source 'C:\Scripts' -Filter 'rootcause-latest.txt' -Dest $dest -Count 1)
  $inv = 'C:\Scripts\inventory-report\latest.json'
  if(Test-Path -LiteralPath $inv){
    if(Copy-YcLocked -Path $inv -Destination (Join-Path $dest 'inventory-latest.json')){ $notes += 'inventory latest.json' }
  }else{
    $notes += 'no inventory-report\latest.json'
  }
  return $notes
}

# ------------------------------------------------------------------------------------
# 02 - Windows event logs, bounded, as .evtx AND as .csv
# ------------------------------------------------------------------------------------

Invoke-Step 'Windows event logs' '02-eventlogs' {
  param($dest)
  $notes = @()
  $channels = @('System','Application','Setup')
  if($IncludeSecurityLog){ $channels += 'Security' }
  else { $notes += 'Security channel NOT collected (use -IncludeSecurityLog)' }

  $query = '*[System[TimeCreated[timediff(@SystemTime) <= ' + $SinceMs + ']]]'
  foreach($ch in $channels){
    $evtx = Join-Path $dest ($ch + '.evtx')
    $out = ''
    try{
      $out = (& wevtutil.exe epl $ch $evtx ('/q:' + $query) '/ow:true' 2>&1 | Out-String -Width 500).Trim()
    }catch{
      $out = $_.Exception.Message
    }
    if(Test-Path -LiteralPath $evtx){
      $kb = 0
      try{ $kb = [int]((Get-Item -LiteralPath $evtx).Length / 1KB) }catch{}
      $notes += ($ch + '.evtx ' + $kb + ' KB')
    }else{
      $notes += ($ch + '.evtx FAILED: ' + $out)
    }

    # The readable twin. This one IS redacted; the .evtx binary is not.
    $rows = @()
    try{
      $rows = @(Get-WinEvent -FilterHashtable @{LogName=$ch;StartTime=$Since} -MaxEvents $MaxCsvEvents -ErrorAction Stop |
                  Select-Object @{n='TimeCreated';e={$_.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss')}},
                                @{n='Level';e={$_.LevelDisplayName}},
                                Id,
                                @{n='Provider';e={$_.ProviderName}},
                                @{n='Message';e={ $m = [string]$_.Message
                                                  if($m.Length -gt $MaxMsgChars){ $m = $m.Substring(0,$MaxMsgChars) + '...[truncated]' }
                                                  ($m -replace '[\r\n]+',' ') }})
    }catch{
      $rows = @()
      $notes += ($ch + '.csv: ' + (([string]$_.Exception.Message) -replace '[\r\n]+',' '))
    }
    if($rows.Count -gt 0){
      [void](Out-YcCsv -Dest $dest -Name ($ch + '.csv') -Rows $rows)
      $notes += ($ch + '.csv ' + $rows.Count + ' event(s)')
    }
  }

  # YallaCloud's own structured events (source 'YallaCloud', ids 1000/1001/1002/1003/1099)
  $yc = @()
  try{
    $yc = @(Get-WinEvent -FilterHashtable @{LogName='Application';ProviderName='YallaCloud';StartTime=$Since} -ErrorAction Stop |
              Select-Object @{n='TimeCreated';e={$_.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss')}},
                            @{n='Level';e={$_.LevelDisplayName}},Id,
                            @{n='Message';e={ ([string]$_.Message -replace '[\r\n]+',' ') }})
  }catch{ $yc = @() }
  if($yc.Count -gt 0){
    [void](Out-YcCsv -Dest $dest -Name 'yallacloud-events.csv' -Rows $yc)
    $notes += ('yallacloud-events.csv ' + $yc.Count + ' event(s)')
  }else{
    $notes += 'no YallaCloud-source events in the window'
  }
  return $notes
}

# ------------------------------------------------------------------------------------
# 03..09 - vendor agents, each only when present
# ------------------------------------------------------------------------------------

Invoke-Step 'Acronis agent logs' '03-acronis' {
  param($dest)
  $notes = @()
  $pd = $env:ProgramData
  $notes += (Copy-YcTree -Source (Join-Path $pd 'Acronis\InstallationLogs') -Dest $dest -Include @('*.log','*.txt') -Recurse -MaxFiles 100 -FileCapMB $MaxFileMB -FolderCapMB $MaxFolderMB)
  foreach($sub in @('Acronis\BackupAndRecovery\MMS\Logs','Acronis\BackupAndRecovery\Logs','Acronis\Agent\var\log','Acronis\CyberProtectHomeOffice\Logs')){
    $p = Join-Path $pd $sub
    if(Test-Path -LiteralPath $p){
      $notes += (Copy-YcTree -Source $p -Dest $dest -Include @('*.log','*.txt','*.0','*.1') -Recurse -Newer $Since -MaxFiles 100 -FileCapMB $MaxFileMB -FolderCapMB $MaxFolderMB)
    }
  }
  foreach($f in @('C:\Scripts\acronis-install.log','C:\Scripts\acronis-cmdline-variant.txt')){
    if(Test-Path -LiteralPath $f){
      if(Copy-YcLocked -Path $f -Destination (Join-Path $dest (Split-Path -Leaf $f))){ $notes += (Split-Path -Leaf $f) }
    }
  }
  $svc = $null
  try{ $svc = Get-Service -ErrorAction Stop | Where-Object { $_.DisplayName -like '*Acronis*' -or $_.Name -eq 'MMS' } }catch{}
  if($svc){ [void](Out-YcText -Dest $dest -Name 'acronis-services.txt' -Content ($svc | Format-Table Name,Status,StartType,DisplayName -AutoSize | Out-String -Width 500)) }
  else{ $notes += 'no Acronis service on this host' }
  return $notes
}

Invoke-Step 'Bitdefender / GravityZone logs' '04-bitdefender' {
  param($dest)
  $notes = @()
  $roots = @(
    (Join-Path $env:ProgramData 'Bitdefender\Endpoint Security\Logs'),
    (Join-Path $env:ProgramData 'Bitdefender\Desktop\Profiles\Logs'),
    (Join-Path $env:ProgramFiles 'Bitdefender\Endpoint Security\Logs'),
    (Join-Path ${env:ProgramFiles(x86)} 'Bitdefender\Endpoint Security\Logs'),
    (Join-Path $env:ProgramData 'Bitdefender\GravityZone')
  )
  $any = $false
  foreach($r in $roots){
    if($r -and (Test-Path -LiteralPath $r)){
      $any = $true
      $notes += (Copy-YcTree -Source $r -Dest $dest -Include @('*.log','*.txt','*.xml') -Recurse -Newer $Since -MaxFiles 100 -FileCapMB $MaxFileMB -FolderCapMB $MaxFolderMB)
    }
  }
  if(-not $any){ $notes += 'Bitdefender not installed' }
  return $notes
}

Invoke-Step 'Zabbix agent logs' '05-zabbix' {
  param($dest)
  $notes = @()
  $roots = @('C:\zabbix','C:\Zabbix Agent',(Join-Path $env:ProgramFiles 'Zabbix Agent'),(Join-Path $env:ProgramFiles 'Zabbix Agent 2'),(Join-Path $env:ProgramData 'zabbix'))
  $any = $false
  foreach($r in $roots){
    if($r -and (Test-Path -LiteralPath $r)){
      $any = $true
      $notes += (Copy-YcTree -Source $r -Dest $dest -Include @('*.log','*.conf') -Recurse -MaxFiles 40 -FileCapMB $MaxFileMB -FolderCapMB $MaxFolderMB)
    }
  }
  if(-not $any){ $notes += 'Zabbix agent not installed' }
  return $notes
}

Invoke-Step 'Salt minion logs' '06-salt' {
  param($dest)
  $notes = @()
  $roots = @('C:\salt\var\log\salt','C:\salt\conf',(Join-Path $env:ProgramData 'Salt Project\Salt\var\log\salt'),(Join-Path $env:ProgramData 'Salt Project\Salt\conf'))
  $any = $false
  foreach($r in $roots){
    if($r -and (Test-Path -LiteralPath $r)){
      $any = $true
      $notes += (Copy-YcTree -Source $r -Dest $dest -Include @('*','*.log','*.conf','minion') -Recurse -MaxFiles 40 -FileCapMB $MaxFileMB -FolderCapMB $MaxFolderMB)
    }
  }
  if(-not $any){ $notes += 'Salt minion not installed' }
  return $notes
}

Invoke-Step 'osquery logs' '07-osquery' {
  param($dest)
  $notes = @()
  $roots = @((Join-Path $env:ProgramFiles 'osquery\log'),(Join-Path $env:ProgramData 'osquery\log'),(Join-Path $env:ProgramData 'osquery'),(Join-Path $env:ProgramFiles 'osquery'))
  $any = $false
  foreach($r in $roots){
    if($r -and (Test-Path -LiteralPath $r)){
      $any = $true
      $notes += (Copy-YcTree -Source $r -Dest $dest -Include @('*.log','*.conf','*.json') -Recurse -Newer $Since -MaxFiles 40 -FileCapMB $MaxFileMB -FolderCapMB $MaxFolderMB)
    }
  }
  if(-not $any){ $notes += 'osquery not installed' }
  return $notes
}

Invoke-Step 'Wazuh / ossec-agent logs' '08-wazuh' {
  param($dest)
  $notes = @()
  $roots = @((Join-Path ${env:ProgramFiles(x86)} 'ossec-agent'),(Join-Path $env:ProgramFiles 'ossec-agent'),(Join-Path ${env:ProgramFiles(x86)} 'ossec-agent\logs'),(Join-Path $env:ProgramData 'wazuh'))
  $any = $false
  foreach($r in $roots){
    if($r -and (Test-Path -LiteralPath $r)){
      $any = $true
      $notes += (Copy-YcTree -Source $r -Dest $dest -Include @('ossec.log','ossec.conf','*.log') -Recurse -MaxFiles 40 -FileCapMB $MaxFileMB -FolderCapMB $MaxFolderMB)
    }
  }
  if(-not $any){ $notes += 'Wazuh / ossec-agent not installed' }
  return $notes
}

Invoke-Step 'GLPI agent logs' '09-glpi' {
  param($dest)
  $notes = @()
  $roots = @((Join-Path $env:ProgramFiles 'GLPI-Agent\logs'),(Join-Path $env:ProgramFiles 'GLPI-Agent\var'),(Join-Path $env:ProgramData 'GLPI-Agent'),(Join-Path ${env:ProgramFiles(x86)} 'GLPI-Agent\logs'))
  $any = $false
  foreach($r in $roots){
    if($r -and (Test-Path -LiteralPath $r)){
      $any = $true
      $notes += (Copy-YcTree -Source $r -Dest $dest -Include @('*.log','*.txt','*.cfg') -Recurse -MaxFiles 40 -FileCapMB $MaxFileMB -FolderCapMB $MaxFolderMB)
    }
  }
  if(-not $any){ $notes += 'GLPI agent not installed' }
  return $notes
}

# ------------------------------------------------------------------------------------
# 10 - SQL Server
# ------------------------------------------------------------------------------------

Invoke-Step 'SQL Server ERRORLOG / Agent log' '10-sqlserver' {
  param($dest)
  $notes = @()
  $instances = @()
  foreach($root in @('HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Microsoft SQL Server')){
    $names = $null
    try{ $names = Get-ItemProperty -Path (Join-Path $root 'Instance Names\SQL') -ErrorAction SilentlyContinue }catch{}
    if($names){
      foreach($p in ($names.PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' })){
        $setup = $null
        try{ $setup = Get-ItemProperty -Path (Join-Path $root ([string]$p.Value + '\Setup')) -ErrorAction SilentlyContinue }catch{}
        if($setup -and $setup.SQLPath){
          $instances += [pscustomobject]@{ Instance=$p.Name; SQLPath=[string]$setup.SQLPath; Edition=[string]$setup.Edition; Version=[string]$setup.Version }
        }
      }
    }
  }
  if($instances.Count -eq 0){ return 'SQL Server not installed' }
  [void](Out-YcCsv -Dest $dest -Name 'sql-instances.csv' -Rows $instances)
  foreach($i in $instances){
    $logDir = Join-Path $i.SQLPath 'Log'
    $sub = Join-Path $dest ('instance-' + ($i.Instance -replace '[\\/:*?"<>|]','_'))
    if(-not (Test-Path -LiteralPath $sub)){ New-Item -ItemType Directory -Path $sub -Force | Out-Null }
    $notes += ($i.Instance + ': ' + (Copy-YcTree -Source $logDir -Dest $sub -Include @('ERRORLOG','ERRORLOG.*','SQLAGENT.OUT','SQLAGENT.*') -MaxFiles 20 -FileCapMB $MaxFileMB -FolderCapMB $MaxFolderMB))
  }
  # setup bootstrap summary - the file that explains a failed SQL install
  foreach($pf in @($env:ProgramFiles,${env:ProgramFiles(x86)})){
    if(-not $pf){ continue }
    $bs = Join-Path $pf 'Microsoft SQL Server'
    if(-not (Test-Path -LiteralPath $bs)){ continue }
    $sums = @()
    try{ $sums = @(Get-ChildItem -LiteralPath $bs -Recurse -File -Filter 'Summary.txt' -ErrorAction SilentlyContinue |
                     Sort-Object LastWriteTime -Descending | Select-Object -First 3) }catch{}
    $n = 0
    foreach($s in $sums){
      if(Copy-YcLocked -Path $s.FullName -Destination (Join-Path $dest ('setup-summary-' + $s.LastWriteTime.ToString('yyyyMMdd-HHmmss') + '.txt'))){ $n++ }
    }
    if($n -gt 0){ $notes += ('' + $n + ' setup Summary.txt') }
  }
  return $notes
}

# ------------------------------------------------------------------------------------
# 11 - IIS
# ------------------------------------------------------------------------------------

Invoke-Step 'IIS logs and site list' '11-iis' {
  param($dest)
  $appcmd = Join-Path $env:SystemRoot 'System32\inetsrv\appcmd.exe'
  $w3svc = $null
  try{ $w3svc = Get-Service -Name 'W3SVC' -ErrorAction SilentlyContinue }catch{}
  if(-not (Test-Path -LiteralPath $appcmd) -and -not $w3svc){ return 'IIS not installed' }
  $notes = @()
  if(Test-Path -LiteralPath $appcmd){
    try{ [void](Out-YcText -Dest $dest -Name 'iis-sites.txt' -Content ((& $appcmd list sites 2>&1 | Out-String -Width 500) + "`r`n" + (& $appcmd list apppools 2>&1 | Out-String -Width 500))) ; $notes += 'site + app pool list' }catch{ $notes += ('appcmd failed: ' + $_.Exception.Message) }
  }
  $notes += (Copy-YcTree -Source 'C:\inetpub\logs\LogFiles' -Dest $dest -Include @('*.log') -Recurse -Newer $Since -MaxFiles 60 -FileCapMB $MaxFileMB -FolderCapMB $MaxFolderMB)
  $notes += 'applicationHost.config deliberately NOT collected (can carry app pool credentials)'
  return $notes
}

# ------------------------------------------------------------------------------------
# 12 - system state
# ------------------------------------------------------------------------------------

Invoke-Step 'System state' '12-systemstate' {
  param($dest)
  $notes = @()

  $os = $null; $cs = $null
  try{ $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop }catch{}
  try{ $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop }catch{}
  $lines = @()
  $lines += ('Collected      : ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss zzz'))
  $lines += ('Hostname       : ' + $env:COMPUTERNAME)
  if($os){
    $lines += ('OS             : ' + $os.Caption)
    $lines += ('Version/Build  : ' + $os.Version + ' / ' + $os.BuildNumber)
    $lines += ('Install date   : ' + $os.InstallDate)
    $lines += ('Last boot      : ' + $os.LastBootUpTime)
    try{ $lines += ('Uptime         : ' + ([string]((Get-Date) - $os.LastBootUpTime))) }catch{}
    $lines += ('Free RAM MB    : ' + [int]($os.FreePhysicalMemory/1KB))
  }
  if($cs){
    $lines += ('Manufacturer   : ' + $cs.Manufacturer)
    $lines += ('Model          : ' + $cs.Model)
    $lines += ('Logical CPUs   : ' + $cs.NumberOfLogicalProcessors)
    $lines += ('RAM GB         : ' + [math]::Round($cs.TotalPhysicalMemory/1GB,1))
    $lines += ('Domain         : ' + $cs.Domain)
  }
  try{
    $ub = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
    $lines += ('ReleaseId/UBR  : ' + [string]$ub.DisplayVersion + ' ' + [string]$ub.ReleaseId + ' UBR ' + [string]$ub.UBR)
  }catch{}
  $lines += ('PowerShell     : ' + $PSVersionTable.PSVersion)
  [void](Out-YcText -Dest $dest -Name 'os.txt' -Content ($lines -join "`r`n"))
  $notes += 'os.txt'

  try{ [void](Out-YcCsv -Dest $dest -Name 'hotfixes.csv' -Rows (Get-HotFix -ErrorAction Stop | Select-Object HotFixID,Description,InstalledOn,InstalledBy)) ; $notes += 'hotfixes' }catch{ $notes += ('hotfixes: ' + $_.Exception.Message) }

  try{
    [void](Out-YcCsv -Dest $dest -Name 'services.csv' -Rows (Get-CimInstance Win32_Service -ErrorAction Stop |
      Select-Object Name,DisplayName,State,StartMode,StartName,PathName,ProcessId))
    $notes += 'services'
  }catch{ $notes += ('services: ' + $_.Exception.Message) }

  try{
    $tasks = Get-ScheduledTask -ErrorAction Stop | ForEach-Object {
      $inf = $null
      try{ $inf = $_ | Get-ScheduledTaskInfo -ErrorAction Stop }catch{}
      [pscustomobject]@{
        TaskPath=$_.TaskPath; TaskName=$_.TaskName; State=$_.State
        Author=$_.Author
        RunAs=$(if($_.Principal){ $_.Principal.UserId } else { '' })
        Actions=(($_.Actions | ForEach-Object { [string]$_.Execute + ' ' + [string]$_.Arguments }) -join ' | ')
        LastRunTime=$(if($inf){ $inf.LastRunTime } else { '' })
        LastResult=$(if($inf){ $inf.LastTaskResult } else { '' })
        NextRunTime=$(if($inf){ $inf.NextRunTime } else { '' })
      }
    }
    [void](Out-YcCsv -Dest $dest -Name 'scheduled-tasks.csv' -Rows $tasks)
    $notes += 'scheduled tasks'
  }catch{ $notes += ('scheduled tasks: ' + $_.Exception.Message) }

  try{
    [void](Out-YcCsv -Dest $dest -Name 'volumes.csv' -Rows (Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction Stop |
      Select-Object DeviceID,VolumeName,FileSystem,
                    @{n='SizeGB';e={[math]::Round($_.Size/1GB,1)}},
                    @{n='FreeGB';e={[math]::Round($_.FreeSpace/1GB,1)}},
                    @{n='FreePct';e={ if($_.Size -gt 0){ [math]::Round(100*$_.FreeSpace/$_.Size,1) } else { 0 } }}))
    $notes += 'volumes'
  }catch{ $notes += ('volumes: ' + $_.Exception.Message) }

  try{
    $disk = Get-Disk -ErrorAction Stop | Select-Object Number,FriendlyName,SerialNumber,PartitionStyle,OperationalStatus,HealthStatus,@{n='SizeGB';e={[math]::Round($_.Size/1GB,1)}}
    [void](Out-YcCsv -Dest $dest -Name 'disks.csv' -Rows $disk)
    [void](Out-YcCsv -Dest $dest -Name 'partitions.csv' -Rows (Get-Partition -ErrorAction Stop | Select-Object DiskNumber,PartitionNumber,DriveLetter,Type,IsBoot,IsSystem,@{n='SizeGB';e={[math]::Round($_.Size/1GB,1)}}))
    $notes += 'disks + partitions'
  }catch{ $notes += ('disks: ' + $_.Exception.Message) }

  $net = @()
  try{ $net += (& ipconfig.exe /all 2>&1 | Out-String -Width 500) }catch{ $net += ('ipconfig failed: ' + $_.Exception.Message) }
  try{ $net += ('=== Get-NetIPAddress ===' + "`r`n" + (Get-NetIPAddress -ErrorAction Stop | Format-Table InterfaceAlias,IPAddress,PrefixLength,AddressFamily,PrefixOrigin -AutoSize | Out-String -Width 500)) }catch{}
  try{ $net += ('=== Get-NetAdapter ===' + "`r`n" + (Get-NetAdapter -ErrorAction Stop | Format-Table Name,Status,LinkSpeed,MacAddress,InterfaceDescription -AutoSize | Out-String -Width 500)) }catch{}
  try{ $net += ('=== DNS servers ===' + "`r`n" + (Get-DnsClientServerAddress -ErrorAction Stop | Format-Table InterfaceAlias,AddressFamily,ServerAddresses -AutoSize | Out-String -Width 500)) }catch{}
  try{ $net += ('=== netstat -ano ===' + "`r`n" + (& netstat.exe -ano 2>&1 | Out-String -Width 500)) }catch{}
  [void](Out-YcText -Dest $dest -Name 'network.txt' -Content ($net -join "`r`n"))
  $notes += 'network.txt'

  try{ [void](Out-YcCsv -Dest $dest -Name 'routes.csv' -Rows (Get-NetRoute -ErrorAction Stop | Select-Object InterfaceAlias,DestinationPrefix,NextHop,RouteMetric,InterfaceMetric,Protocol)) ; $notes += 'routes' }catch{ $notes += ('routes: ' + $_.Exception.Message) }

  try{
    [void](Out-YcText -Dest $dest -Name 'firewall-rules.txt' -Content ((& netsh.exe advfirewall show allprofiles 2>&1 | Out-String -Width 500) + "`r`n" + (& netsh.exe advfirewall firewall show rule name=all 2>&1 | Out-String -Width 500)))
    $notes += 'firewall rules'
  }catch{ $notes += ('firewall: ' + $_.Exception.Message) }

  # installed programs - only when Report-Inventory has not already produced a fresh one
  $invJson = 'C:\Scripts\inventory-report\latest.json'
  $fresh = $false
  if(Test-Path -LiteralPath $invJson){
    try{ $fresh = ((Get-Item -LiteralPath $invJson).LastWriteTime -ge $Since) }catch{ $fresh = $false }
  }
  if($fresh){
    $notes += 'installed programs: skipped, a fresh inventory-report\latest.json is already in 01-yallacloud'
  }else{
    try{
      $keys = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
      $apps = Get-ItemProperty -Path $keys -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName } |
                Select-Object @{n='Name';e={$_.DisplayName}},@{n='Version';e={$_.DisplayVersion}},@{n='Publisher';e={$_.Publisher}},@{n='InstallDate';e={$_.InstallDate}} |
                Sort-Object Name -Unique
      [void](Out-YcCsv -Dest $dest -Name 'installed-programs.csv' -Rows $apps)
      $notes += ('installed programs (' + @($apps).Count + ')')
    }catch{ $notes += ('installed programs: ' + $_.Exception.Message) }
  }

  # pending reboot
  $pend = @()
  $checks = @(
    @{ N='CBS RebootPending';         P='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending' },
    @{ N='WindowsUpdate RebootRequired'; P='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired' },
    @{ N='Netlogon JoinDomain';       P='HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\JoinDomain' }
  )
  foreach($c in $checks){ $pend += ($c.N + ' : ' + (Test-Path -LiteralPath $c.P)) }
  try{
    $sm = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
    $pend += ('PendingFileRenameOperations : ' + [string]($null -ne $sm))
  }catch{ $pend += 'PendingFileRenameOperations : unreadable' }
  try{
    $a = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName' -ErrorAction Stop).ComputerName
    $b = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName' -ErrorAction Stop).ComputerName
    $pend += ('Rename pending (Active "' + $a + '" vs "' + $b + '") : ' + [string]($a -ne $b))
  }catch{}
  [void](Out-YcText -Dest $dest -Name 'pending-reboot.txt' -Content ($pend -join "`r`n"))
  $notes += 'pending reboot'

  # time sync
  $tm = @()
  foreach($a in @(@('/query','/status'),@('/query','/source'),@('/query','/configuration'),@('/query','/peers'))){
    try{ $tm += ('=== w32tm ' + ($a -join ' ') + ' ===' + "`r`n" + (& w32tm.exe @a 2>&1 | Out-String -Width 500)) }catch{ $tm += ('w32tm ' + ($a -join ' ') + ' failed: ' + $_.Exception.Message) }
  }
  [void](Out-YcText -Dest $dest -Name 'timesync.txt' -Content ($tm -join "`r`n"))
  $notes += 'time sync'

  # boot / shutdown events
  try{
    $boot = @(Get-WinEvent -FilterHashtable @{LogName='System';Id=6005,6006,6008,6009,41,1074,1076;StartTime=$Since} -MaxEvents 200 -ErrorAction Stop |
      Select-Object @{n='TimeCreated';e={$_.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss')}},Id,
                    @{n='Provider';e={$_.ProviderName}},
                    @{n='Message';e={ $m=[string]$_.Message; if($m.Length -gt 500){ $m=$m.Substring(0,500) }; ($m -replace '[\r\n]+',' ') }})
    if($boot.Count -gt 0){ [void](Out-YcCsv -Dest $dest -Name 'boot-events.csv' -Rows $boot) }
    $notes += ('boot events (' + $boot.Count + ')')
  }catch{ $notes += ('boot events: ' + $_.Exception.Message) }

  return $notes
}

# ------------------------------------------------------------------------------------
# 13 - optional performance capture
# ------------------------------------------------------------------------------------

if($Perf){
  Invoke-Step ('Performance capture (' + $PerfSeconds + 's)') '13-perf' {
    param($dest)
    $notes = @()
    # Process snapshots always work and are locale-independent.
    for($i=0;$i -lt 3;$i++){
      try{
        $snap = Get-Process -ErrorAction Stop | Sort-Object CPU -Descending | Select-Object -First 25 Name,Id,CPU,
                   @{n='WS_MB';e={[math]::Round($_.WorkingSet64/1MB,1)}},
                   @{n='Handles';e={$_.HandleCount}},
                   @{n='Threads';e={$_.Threads.Count}}
        [void](Out-YcCsv -Dest $dest -Name ('processes-' + $i + '.csv') -Rows $snap)
      }catch{}
      if($i -lt 2){ Start-Sleep -Seconds ([int][math]::Max(1,$PerfSeconds/3)) }
    }
    $notes += '3 process snapshots'
    # Counter capture. Counter PATHS are localized on non-English builds, so this is
    # best-effort by design and its failure is recorded, not fatal.
    $counters = @('\Processor(_Total)\% Processor Time',
                  '\Memory\Available MBytes',
                  '\System\Processor Queue Length',
                  '\PhysicalDisk(_Total)\Avg. Disk sec/Read',
                  '\PhysicalDisk(_Total)\Avg. Disk sec/Write',
                  '\PhysicalDisk(_Total)\Current Disk Queue Length')
    try{
      $samples = Get-Counter -Counter $counters -SampleInterval 1 -MaxSamples $PerfSeconds -ErrorAction Stop
      $rows = @()
      foreach($s in $samples){
        foreach($v in $s.CounterSamples){
          $rows += [pscustomobject]@{ Time=$s.Timestamp.ToString('yyyy-MM-dd HH:mm:ss'); Counter=$v.Path; Value=[math]::Round($v.CookedValue,4) }
        }
      }
      [void](Out-YcCsv -Dest $dest -Name 'perfmon.csv' -Rows $rows)
      $notes += ('perfmon.csv ' + $rows.Count + ' sample(s)')
    }catch{
      $notes += ('Get-Counter unavailable on this build (counter names are localized): ' + (([string]$_.Exception.Message) -replace '[\r\n]+',' '))
    }
    return $notes
  }
}

# ------------------------------------------------------------------------------------
# Redaction pass - staged COPIES only, never a source log
# ------------------------------------------------------------------------------------

$redactedFiles = 0
$redactedChars = 0
$redactSkipped = 0
$hardHits      = 0
if($NoRedact){
  Write-YcLog 'redaction pass SKIPPED (-NoRedact). The archive is NOT safe to hand to a third party.' 'WARN'
}else{
  $textExt = @('.log','.txt','.csv','.json','.xml','.ini','.conf','.cfg','.yml','.yaml','.out','.1')
  $all = @()
  try{ $all = @(Get-ChildItem -LiteralPath $Stage -Recurse -File -ErrorAction Stop) }catch{ $all = @() }
  foreach($f in $all){
    $ext = ''
    try{ $ext = $f.Extension.ToLowerInvariant() }catch{}
    if($textExt -notcontains $ext){ $redactSkipped++; continue }
    # ANCHORED pass FIRST - see Invoke-YcHardRedact. Running it after the library pass
    # would be useless, because the library masks the switch name and leaves the value.
    $h = 0
    try{ $h = Invoke-YcHardRedact -Path $f.FullName }catch{ $h = 0 }
    if($h -gt 0){ $hardHits += $h }
    # then the library pass, for the assignment forms (name=value / name: value)
    $n = -1
    try{ $n = Write-YcRedacted -Path $f.FullName -Quiet }catch{ $n = -1 }
    if($n -gt 0){ $redactedChars += $n }
    if($h -gt 0 -or $n -gt 0){ $redactedFiles++ }
  }
  Write-YcLog ('redaction: masked ' + $redactedChars + ' character(s) via the library pattern and ' + $hardHits + ' additional value(s) via the anchored pattern, across ' + $redactedFiles + ' staged file(s); ' + $redactSkipped + ' non-text file(s) (including every .evtx) were left as-is by design.') 'OK'
}

# ------------------------------------------------------------------------------------
# Size budget - trim in a documented order before compressing
# ------------------------------------------------------------------------------------

function Get-YcStageBytes{
  $b = 0L
  try{ foreach($i in (Get-ChildItem -LiteralPath $Stage -Recurse -File -ErrorAction Stop)){ $b += $i.Length } }catch{}
  return $b
}

$budget = [int64]$MaxSizeMB * 1MB
$size = Get-YcStageBytes
$trimNotes = @()
if($size -gt $budget){
  Write-YcLog ('staged data is ' + [int]($size/1MB) + ' MB, over the ' + $MaxSizeMB + ' MB budget - trimming.') 'WARN'
  # 1. .evtx binaries (the readable .csv twin of every channel stays)
  foreach($f in @(Get-ChildItem -LiteralPath $Stage -Recurse -File -Filter '*.evtx' -ErrorAction SilentlyContinue | Sort-Object Length -Descending)){
    if((Get-YcStageBytes) -le $budget){ break }
    try{ Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop; $trimNotes += ('dropped ' + $f.Name + ' (' + [int]($f.Length/1MB) + ' MB) - its .csv twin is still in the archive') }catch{}
  }
  # 2. the perf capture
  $perfDir = Join-Path $Stage '13-perf'
  if((Get-YcStageBytes) -gt $budget -and (Test-Path -LiteralPath $perfDir)){
    try{ Remove-Item -LiteralPath $perfDir -Recurse -Force -ErrorAction Stop; $trimNotes += 'dropped the -Perf capture' }catch{}
  }
  # 3. oldest vendor logs
  $vendorDirs = @('03-acronis','04-bitdefender','05-zabbix','06-salt','07-osquery','08-wazuh','09-glpi','10-sqlserver','11-iis')
  foreach($d in $vendorDirs){
    if((Get-YcStageBytes) -le $budget){ break }
    $p = Join-Path $Stage $d
    if(-not (Test-Path -LiteralPath $p)){ continue }
    foreach($f in @(Get-ChildItem -LiteralPath $p -Recurse -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime)){
      if((Get-YcStageBytes) -le $budget){ break }
      try{ Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop; $trimNotes += ('dropped ' + $d + '\' + $f.Name) }catch{}
    }
  }
  foreach($t in $trimNotes){ Write-YcLog ('trim: ' + $t) 'WARN' }
  $size = Get-YcStageBytes
  if($size -gt $budget){
    Write-YcLog ('still ' + [int]($size/1MB) + ' MB after trimming - the archive will exceed -MaxSizeMB. Re-run with a smaller -Days.') 'WARN'
  }
}

# ------------------------------------------------------------------------------------
# 00 - summary and manifest (written last, so it describes the whole run)
# ------------------------------------------------------------------------------------

$sumDir = Join-Path $Stage '00-summary'
if(-not (Test-Path -LiteralPath $sumDir)){ New-Item -ItemType Directory -Path $sumDir -Force | Out-Null }
[void](Out-YcCsv -Dest $sumDir -Name 'manifest.csv' -Rows $script:StepRows)

$okCount   = @($script:StepRows | Where-Object { $_.Status -eq 'OK' }).Count
$failCount = @($script:StepRows | Where-Object { $_.Status -eq 'FAILED' }).Count
$emptyCount= @($script:StepRows | Where-Object { $_.Status -eq 'EMPTY' }).Count

$sum = @()
$sum += 'YallaCloud collect-logs summary'
$sum += '==============================='
$sum += ('Host          : ' + $env:COMPUTERNAME)
$sum += ('Collected     : ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss zzz'))
$sum += ('Window        : last ' + $Days + ' day(s), since ' + $Since.ToString('yyyy-MM-dd HH:mm:ss'))
$sum += ('Steps         : ' + $okCount + ' OK, ' + $emptyCount + ' empty (component not installed), ' + $failCount + ' failed')
$sum += ('Security log  : ' + $(if($IncludeSecurityLog){'included'}else{'NOT included (-IncludeSecurityLog)'}))
$sum += ('Perf capture  : ' + $(if($Perf){[string]$PerfSeconds + 's'}else{'not requested'}))
$sum += ('Redaction     : ' + $(if($NoRedact){'OFF (-NoRedact) - THIS ARCHIVE MAY CONTAIN SECRETS'}else{'ON - ' + $redactedChars + ' char(s) masked (library pattern) + ' + $hardHits + ' value(s) masked (anchored pattern) in ' + $redactedFiles + ' staged file(s)'}))
$sum += ''
$sum += 'REDACTION SCOPE'
$sum += '  Redacted     : values following a secret-shaped name (token, password, apikey,'
$sum += '                 secret, psk, connectionstring, --reg-token, -SaPassword, ...) in'
$sum += '                 .log .txt .csv .json .xml .ini .conf .cfg .yml .yaml .out files.'
$sum += '  NOT redacted : .evtx event log BINARIES - shipped as-is so Event Viewer can open'
$sum += '                 them. The .csv twin of each channel IS redacted. Also not redacted:'
$sum += '                 a bare secret with no name in front of it, and customer data inside'
$sum += '                 application logs. Review before sending to a third party.'
$sum += ''
$sum += 'NOT COLLECTED BY DESIGN'
$sum += '  chkdsk / sfc / DISM        -> run "diag"      (Diag-System.ps1)'
$sum += '  bugcheck / cdb !analyze    -> run "rootcause" (Root-Cause.ps1)'
$sum += '  CloudStack metadata + full software inventory -> run "report-inventory"'
$sum += '  IIS applicationHost.config -> can carry app pool credentials'
$sum += ''
if($trimNotes.Count -gt 0){
  $sum += ('TRIMMED TO FIT -MaxSizeMB ' + $MaxSizeMB)
  foreach($t in $trimNotes){ $sum += ('  ' + $t) }
  $sum += ''
}
$sum += 'STEPS'
$sum += ($script:StepRows | Format-Table Status,Folder,Files,KB,Seconds,Step -AutoSize | Out-String -Width 500)
[void](Out-YcText -Dest $sumDir -Name 'summary.txt' -Content ($sum -join "`r`n"))
if(-not $NoRedact){ [void](Write-YcRedacted -Path (Join-Path $sumDir 'summary.txt') -Quiet) }

# ------------------------------------------------------------------------------------
# Compress and PROVE the archive
# ------------------------------------------------------------------------------------

if(Test-Path -LiteralPath $ZipPath){ Remove-Item -LiteralPath $ZipPath -Force -ErrorAction SilentlyContinue }
try{
  Compress-Archive -Path (Join-Path $Stage '*') -DestinationPath $ZipPath -CompressionLevel Optimal -Force -ErrorAction Stop
}catch{
  Write-YcLog ('the staging folder was left in place for inspection: ' + $Stage) 'WARN'
  Exit-Yc 1 ('Compress-Archive failed: ' + $_.Exception.Message) 'ERROR'
}

if(-not (Test-Path -LiteralPath $ZipPath)){
  Write-YcLog ('the staging folder was left in place for inspection: ' + $Stage) 'WARN'
  Exit-Yc 1 ('Compress-Archive reported success but ' + $ZipPath + ' does not exist.') 'ERROR'
}
$zipLen = 0L
try{ $zipLen = (Get-Item -LiteralPath $ZipPath).Length }catch{ $zipLen = 0 }
if($zipLen -le 0){
  Write-YcLog ('the staging folder was left in place for inspection: ' + $Stage) 'WARN'
  Exit-Yc 1 ($ZipPath + ' was created but is zero bytes.') 'ERROR'
}

$entries = -1
try{
  Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop
  $zf = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
  try{ $entries = $zf.Entries.Count }finally{ $zf.Dispose() }
}catch{
  Write-YcLog ('the staging folder was left in place for inspection: ' + $Stage) 'WARN'
  Exit-Yc 1 ($ZipPath + ' exists (' + [int]($zipLen/1KB) + ' KB) but could NOT be opened: ' + $_.Exception.Message) 'ERROR'
}
if($entries -le 0){
  Write-YcLog ('the staging folder was left in place for inspection: ' + $Stage) 'WARN'
  Exit-Yc 1 ($ZipPath + ' opened but contains zero entries.') 'ERROR'
}
Write-YcLog ('archive VERIFIED: ' + $ZipPath + ' - ' + [math]::Round($zipLen/1MB,2) + ' MB, ' + $entries + ' entries, opened and read back.') 'OK'

if($KeepStaging){
  Write-YcLog ('staging folder kept at ' + $Stage + ' (-KeepStaging).') 'INFO'
}else{
  try{ Remove-Item -LiteralPath $Stage -Recurse -Force -ErrorAction Stop }
  catch{ Write-YcLog ('could not remove the staging folder ' + $Stage + ': ' + $_.Exception.Message) 'WARN' }
}

# ------------------------------------------------------------------------------------
# Optional S3 handoff - a soft dependency, never a hard one
# ------------------------------------------------------------------------------------

$s3Script = 'C:\Scripts\Transfer-S3.ps1'
if($S3){
  if(Test-Path -LiteralPath $s3Script){
    # Soft dependency: discover which parameter that script uses for the local file rather
    # than assuming one, so a rename over there cannot silently break the handoff here.
    $paramName = ''
    try{
      $cmd = Get-Command -Name $s3Script -ErrorAction Stop
      foreach($cand in @('Path','File','LocalPath','Source','InFile','Upload')){
        if($cmd.Parameters.ContainsKey($cand)){ $paramName = $cand; break }
      }
    }catch{ $paramName = '' }
    if(-not $paramName){
      Write-YcLog ($s3Script + ' exposes no Path/File/LocalPath/Source parameter - not guessing. Upload ' + $ZipPath + ' manually.') 'WARN'
    }else{
      Write-YcLog ('handing the archive to ' + $s3Script + ' -' + $paramName) 'INFO'
      try{
        $global:LASTEXITCODE = 0
        $splat = @{ }
        $splat[$paramName] = $ZipPath
        & $s3Script @splat
        $rc = $LASTEXITCODE
        if($null -eq $rc){ $rc = 0 }
        if($rc -eq 0){ Write-YcLog 'S3 handoff reported success.' 'OK' }
        else{ Write-YcLog ('S3 handoff exited ' + $rc + '. The archive is still on disk at ' + $ZipPath + '.') 'WARN' }
      }catch{
        Write-YcLog ('S3 handoff threw: ' + $_.Exception.Message + '. The archive is still on disk at ' + $ZipPath + '.') 'WARN'
      }
    }
  }else{
    Write-YcLog ('-S3 was requested but ' + $s3Script + ' does not exist on this host. The archive is on disk at ' + $ZipPath + ' - upload it manually.') 'WARN'
  }
}elseif(Test-Path -LiteralPath $s3Script){
  Write-YcLog ('tip: ' + $s3Script + ' is present - re-run with -S3 to upload the archive automatically.') 'INFO'
}

$tail = ''
if($failCount -gt 0){ $tail = ' ' + $failCount + ' collector(s) failed - see 00-summary\manifest.csv inside the archive.' }
Exit-Yc 0 ('collect-logs complete: ' + $ZipPath + ' (' + [math]::Round($zipLen/1MB,2) + ' MB, ' + $entries + ' entries).' + $tail) 'OK'
