<#
  Boot-Repair.ps1  -  YallaCloud boot / filesystem rescue command.
  Version 2.0.1 | 2026-08-19 | PowerShell 5.1+ | Windows Server 2016/2019/2022/2025 | ASCII-only | C:\Scripts
  2026-08-19: removed the documented exit code 6 'no internet' - unreachable, there is no -NeedInternet call.

  WHAT CHANGED AND WHY (full rewrite of v1.x):

  P0-9  v1 selected the EFI System Partition with "Get-Partition | Where GptType -eq ... | Select -First 1"
        across EVERY attached disk, with nothing tying it to the system disk. It then assigned $letter='S'
        unconditionally inside a try whose -EA SilentlyContinue guaranteed the catch could never fire, so S:
        was used whether or not Set-Partition had succeeded. If S: already existed as something else, or if
        the first ESP found belonged to a data disk, bcdboot wrote EFI\Microsoft\Boot onto the wrong volume
        and the next reboot handed the firmware a loader that is not there. There was no BCD backup anywhere
        in the file.
        NOW: the ESP is looked up ONLY on the disk that carries %SystemDrive%. The drive letter is chosen
        dynamically from the letters that are genuinely free (never hard-coded S:). After mounting, the
        partition behind that letter is re-read and the run is aborted unless it is the exact ESP that was
        selected (same disk number AND same partition number). "bcdedit /export C:\Scripts\bcd-backup-<ts>"
        plus a file copy of <ESP>\EFI\Microsoft\Boot are taken BEFORE any write, and the exact restore
        commands are printed so a human can undo the change. bcdboot's exit code is checked and the BCD is
        re-read afterwards to confirm the boot manager entry points at the ESP that was just written.

  P0-10 v1 ran "bootrec /fixmbr", "/fixboot" and "/rebuildbcd" through cmd /c on a booted Windows Server.
        bootrec.exe ships only inside WinRE/WinPE (boot.wim / winre.wim); it is NOT in C:\Windows\System32
        on a running Windows Server. All three printed "not recognized", cmd /c swallowed it, no exit code
        was checked, and the script then logged "Boot loader repair attempted." at OK - the one command whose
        whole purpose is to fix an unbootable machine did nothing and reported success. bootsect.exe is
        likewise absent on Server SKUs (it ships in the ADK and on the installation media, under \boot).
        NOW: the BIOS/MBR path performs only what a booted Windows can actually do - bcdboot /f BIOS onto the
        active system partition, plus bcdedit inspection - verifies the result, and states plainly which
        repairs (MBR boot code, volume boot record, /rebuildbcd rescan) require booting the recovery ISO.
        -FixMbr exists purely to raise that explicit error instead of performing a silent no-op.

  Also new: -DryRun reports the detected layout (firmware, system disk, ESP, current BCD entries) and changes
  nothing - it is the safest thing to run first. Every exit path calls Stop-YcLog. No -ErrorAction
  SilentlyContinue is used around anything load-bearing.

  Shared contract: elevated, -Help, C:\Scripts\boot-repair.log tagged [YALLACLOUD][boot-repair], mirrored to
  the Application event log (source 'YallaCloud').
#>
#Requires -Version 5.1
param([switch]$Boot,[switch]$FileSystem,[switch]$Full,[switch]$ScheduleChkdsk,[switch]$Reboot,[switch]$DryRun,[switch]$FixMbr,[switch]$UpdateNvram,[switch]$Force,[string]$EspLetter,[switch]$Help)
. 'C:\Scripts\_yc-lib.ps1'
Start-YcLog 'boot-repair'
$ErrorActionPreference='Continue'

if($Help){
@"
boot-repair  -  UEFI/BIOS boot-loader repair + MFT/filesystem repair, Microsoft built-ins only.

USAGE:
  boot-repair                      SAFE default: read-only scan + report (layout, BCD, chkdsk /scan)
  boot-repair -DryRun              SAFEST first run: report the detected layout only, change NOTHING
  boot-repair -Boot                repair the boot loader / BCD on the SYSTEM disk (auto UEFI vs BIOS)
  boot-repair -FileSystem          chkdsk /scan + sfc /scannow + DISM /RestoreHealth
  boot-repair -Full                -Boot + -FileSystem
  boot-repair -ScheduleChkdsk      schedule 'chkdsk /f /r' on the system volume for the next reboot
  boot-repair -Reboot              reboot when done (needed for a scheduled chkdsk to run)
  boot-repair -Help

PARAMETERS:
  -Boot            Repair the boot loader. UEFI: bcdboot onto the ESP of the SYSTEM disk only.
                   BIOS: bcdboot /f BIOS onto the active system partition of the SYSTEM disk only.
  -FileSystem      chkdsk /scan (online, safe), sfc /scannow, DISM /Online /Cleanup-Image /RestoreHealth.
                   Implies -ScheduleChkdsk.
  -Full            Shorthand for -Boot -FileSystem.
  -ScheduleChkdsk  Schedule 'chkdsk /f /r' on the system volume for the next reboot (MFT/index repair).
  -Reboot          Reboot 15s after the work finishes. Ignored under -DryRun.
  -DryRun          Report firmware type, system disk, ESP / active system partition, planned commands and
                   the current BCD entries. Writes nothing, mounts nothing, reboots nothing.
  -FixMbr          Request MBR / boot-sector repair. This CANNOT be done from a booted Windows Server; the
                   command reports the exact error and the recovery-ISO steps instead of pretending.
  -UpdateNvram     UEFI only. Additionally run bcdboot WITHOUT /s so a firmware (NVRAM) boot entry for this
                   Windows Boot Manager is (re)created. Off by default because it edits UEFI NVRAM.
  -EspLetter <L>   Preferred free drive letter to temporarily mount the ESP on. Default: first free letter.
                   The letter is rejected if it is already in use - S: is never assumed.
  -Force           Continue with -Boot even if the "bcdedit /export" backup could not be taken. Only use
                   this when the BCD is already destroyed and there is nothing left to back up.
  -Help            Show this text.

WHAT WORKS FROM A BOOTED WINDOWS, AND WHAT DOES NOT:
  WORKS  : bcdboot <sys>\Windows /s <ESP>: /f UEFI     (rebuild EFI boot files + BCD on the ESP)
           bcdboot <sys>\Windows /s <SYSPART>: /f BIOS (rebuild bootmgr + \Boot\BCD on the system partition)
           bcdedit /export, /import, /enum, /store     (back up, restore and inspect the BCD)
           chkdsk /scan, sfc /scannow, DISM /RestoreHealth, chkdsk /f /r scheduled for next boot
  DOES NOT WORK: bootrec /fixmbr, bootrec /fixboot, bootrec /rebuildbcd, bootsect /nt60.
           bootrec.exe exists only inside WinRE/WinPE (boot.wim / winre.wim) and bootsect.exe only in the
           ADK and on the installation media - neither is in C:\Windows\System32 on Windows Server. If the
           MBR boot code or the volume boot record is damaged, boot the recovery ISO / WinRE and run them
           there. This command will say so; it will not run them and claim success.

REVERSIBILITY:
  Before any -Boot action the current BCD is exported to C:\Scripts\bcd-backup-<timestamp> and the ESP boot
  directory is copied to C:\Scripts\esp-backup-<timestamp>. The exact restore commands are printed at the
  end of the run and written to the log.

EXAMPLES:
  boot-repair -DryRun                        inspect the layout, change nothing (do this first)
  boot-repair -Boot                          rebuild the boot loader on the system disk, with backups
  boot-repair -Boot -UpdateNvram             also (re)create the UEFI firmware boot entry
  boot-repair -Full -Reboot                  boot + filesystem repair, then reboot to run chkdsk /f /r
  bcdedit /import C:\Scripts\bcd-backup-20260816-101500     undo the BCD change made by -Boot

EXIT CODES: 0 success, 1 failure (nothing was left half-written), 5 not elevated.
NOTES: run as Administrator. Unattended-safe (no prompts). Default with no switch is READ-ONLY.
Log: C:\Scripts\boot-repair.log
"@ | Write-Host -ForegroundColor Cyan
  Stop-YcLog 0; exit 0
}

Assert-YcPrereqs -NeedAdmin
if($Full){ $Boot=$true; $FileSystem=$true }

$ESP_GPT_TYPE = 'c12a7328-f81f-11d2-ba4b-00a0c93ec93b'   # PARTITION_SYSTEM_GUID (EFI System Partition)
$SysDrive     = $env:SystemDrive                          # 'C:'
$SysLetter    = $SysDrive.TrimEnd(':')                    # 'C'
$Stamp        = (Get-Date).ToString('yyyyMMdd-HHmmss')
$BcdEdit      = Join-Path $env:SystemRoot 'System32\bcdedit.exe'
$BcdBoot      = Join-Path $env:SystemRoot 'System32\bcdboot.exe'
$BootRec      = Join-Path $env:SystemRoot 'System32\bootrec.exe'
$BootSect     = Join-Path $env:SystemRoot 'System32\bootsect.exe'
$MountVol     = Join-Path $env:SystemRoot 'System32\mountvol.exe'
$ChkDsk       = Join-Path $env:SystemRoot 'System32\chkdsk.exe'

# ---------------------------------------------------------------- helpers ----
function Invoke-YcNative{
    param([string]$File,[string[]]$Arguments)
    if(-not (Test-Path $File)){
        Write-YcLog ('Executable not found: ' + $File) 'ERROR'
        return 9009
    }
    Write-YcLog ('RUN: "' + $File + '" ' + ($Arguments -join ' '))
    $out = & $File @Arguments 2>&1
    $code = $LASTEXITCODE
    foreach($line in $out){ Write-Host ('    ' + [string]$line) }
    Write-YcLog ('exit code ' + $code + ' from ' + [System.IO.Path]::GetFileName($File))
    return $code
}

function Get-YcNativeText{
    param([string]$File,[string[]]$Arguments)
    if(-not (Test-Path $File)){ return '' }
    $out = & $File @Arguments 2>&1 | Out-String
    return $out
}

function Show-YcBlock{
    param([string]$Title,[string]$Text)
    Write-Host ('--- ' + $Title + ' ---') -ForegroundColor Cyan
    if([string]::IsNullOrWhiteSpace($Text)){ Write-Host '    (no output)' } else { Write-Host $Text }
}

# Pick a drive letter that is genuinely free. Never assumes S:.
function Get-YcFreeDriveLetter{
    param([string]$Preferred)
    $used = New-Object System.Collections.ArrayList
    try{
        foreach($d in [System.IO.DriveInfo]::GetDrives()){
            [void]$used.Add($d.Name.Substring(0,1).ToUpper())
        }
    }catch{ Write-YcLog ('Could not enumerate logical drives: ' + $_.Exception.Message) 'WARN' }
    try{
        foreach($v in (Get-Volume -ErrorAction Stop)){
            $vl = [string]$v.DriveLetter
            if($vl -match '^[A-Za-z]$'){ [void]$used.Add($vl.ToUpper()) }
        }
    }catch{ Write-YcLog ('Could not enumerate volumes: ' + $_.Exception.Message) 'WARN' }

    $order = New-Object System.Collections.ArrayList
    if($Preferred){
        $p = $Preferred.TrimEnd(':').ToUpper()
        if($p -match '^[A-Za-z]$'){ [void]$order.Add($p) }
        else { Write-YcLog ('-EspLetter "' + $Preferred + '" is not a single drive letter; ignoring it.') 'WARN' }
    }
    foreach($c in @('S','T','U','V','W','X','Y','Z','R','Q','P','O','N','M','L','K','J','I','H','G','F','E','D')){
        [void]$order.Add($c)
    }
    foreach($L in $order){
        if($used -contains $L){ continue }
        if(Test-Path ($L + ':\')){ continue }
        return $L
    }
    return $null
}

# Mount $Partition on $Letter using the most explicit method available, then PROVE that the letter really
# resolves to that exact partition. Returns $true only when both succeeded.
function Mount-YcPartition{
    param($Partition,[string]$Letter)
    $ok = $false
    try{
        Set-Partition -DiskNumber $Partition.DiskNumber -PartitionNumber $Partition.PartitionNumber -NewDriveLetter $Letter -ErrorAction Stop
        $ok = $true
    }catch{
        Write-YcLog ('Set-Partition could not assign ' + $Letter + ': (' + $_.Exception.Message + '); trying mountvol /S.') 'WARN'
    }
    if(-not $ok -or -not (Test-Path ($Letter + ':\'))){
        $rc = Invoke-YcNative -File $MountVol -Arguments @(($Letter + ':'),'/S')
        if($rc -ne 0){ Write-YcLog ('mountvol ' + $Letter + ': /S returned ' + $rc) 'WARN' }
    }
    if(-not (Test-Path ($Letter + ':\'))){
        $dpScript = Join-Path $env:TEMP ('yc-mount-' + $Stamp + '.txt')
        $lines = @(('select disk ' + $Partition.DiskNumber),('select partition ' + $Partition.PartitionNumber),('assign letter=' + $Letter))
        Set-Content -Path $dpScript -Value $lines -Encoding ascii
        $rc = Invoke-YcNative -File (Join-Path $env:SystemRoot 'System32\diskpart.exe') -Arguments @('/s',$dpScript)
        Remove-Item $dpScript -Force -ErrorAction Continue
        if($rc -ne 0){ Write-YcLog ('diskpart assign returned ' + $rc) 'WARN' }
    }
    if(-not (Test-Path ($Letter + ':\'))){
        Write-YcLog ('Drive ' + $Letter + ': did not appear after the mount attempt.') 'ERROR'
        return $false
    }
    # P0-9 guard: confirm the letter really is the partition we picked, not something that was already there.
    try{
        $back = Get-Partition -DriveLetter $Letter -ErrorAction Stop
    }catch{
        Write-YcLog ('Cannot read back the partition behind ' + $Letter + ': - ' + $_.Exception.Message) 'ERROR'
        return $false
    }
    if($back.DiskNumber -ne $Partition.DiskNumber -or $back.PartitionNumber -ne $Partition.PartitionNumber){
        Write-YcLog (('SAFETY ABORT: {0}: resolves to disk {1} partition {2}, but the target is disk {3} partition {4}. ' +
                      'Refusing to write boot files to the wrong volume.') -f $Letter,$back.DiskNumber,$back.PartitionNumber,$Partition.DiskNumber,$Partition.PartitionNumber) 'ERROR'
        return $false
    }
    Write-YcLog ('Verified ' + $Letter + ': = disk ' + $Partition.DiskNumber + ' partition ' + $Partition.PartitionNumber + '.') 'OK'
    return $true
}

function Dismount-YcLetter{
    param([string]$Letter)
    Write-YcLog ('Removing the temporary drive letter ' + $Letter + ': again.')
    $rc = Invoke-YcNative -File $MountVol -Arguments @(($Letter + ':'),'/D')
    if($rc -ne 0){ Write-YcLog ('Could not remove ' + $Letter + ': (mountvol exit ' + $rc + '). Harmless, but tidy it up manually.') 'WARN' }
}

function Assert-YcBootrec{
    # P0-10: bootrec.exe ships only in WinRE/WinPE. Never pretend it ran.
    if(-not (Test-Path $BootRec)){
        Write-YcLog 'bootrec is only available in WinRE/WinPE - boot the recovery ISO to repair a BIOS/MBR boot.' 'ERROR'
        Write-YcLog 'In WinRE: bootrec /fixmbr ; bootrec /fixboot ; bootrec /scanos ; bootrec /rebuildbcd' 'ERROR'
        Stop-YcLog 1; exit 1
    }
}

# ------------------------------------------------------- layout discovery ----
try{
    $sysPart = Get-Partition -DriveLetter $SysLetter -ErrorAction Stop
}catch{
    Write-YcLog ('Cannot resolve the system volume ' + $SysDrive + ' to a partition: ' + $_.Exception.Message) 'ERROR'
    Write-YcLog 'The Storage module (Get-Partition/Get-Disk) is required. Without it this command cannot tell which disk is the system disk, and it will not guess.' 'ERROR'
    Stop-YcLog 1; exit 1
}
try{
    $sysDisk = $sysPart | Get-Disk -ErrorAction Stop
}catch{
    Write-YcLog ('Cannot resolve the system disk for ' + $SysDrive + ': ' + $_.Exception.Message) 'ERROR'
    Stop-YcLog 1; exit 1
}
if(-not $sysDisk){
    Write-YcLog ('No disk found behind ' + $SysDrive + '.') 'ERROR'
    Stop-YcLog 1; exit 1
}

try{
    $sysDiskParts = @(Get-Partition -DiskNumber $sysDisk.Number -ErrorAction Stop)
}catch{
    Write-YcLog ('Cannot enumerate partitions on disk ' + $sysDisk.Number + ': ' + $_.Exception.Message) 'ERROR'
    Stop-YcLog 1; exit 1
}

# ESP, constrained to the SYSTEM disk (P0-9). GptType is reported with braces by the Storage cmdlets and
# without braces by the underlying MSFT_Partition class, so normalise before comparing.
$esp = $sysDiskParts | Where-Object { $_.GptType -and (((([string]$_.GptType) -replace '[{}]','')).ToLower() -eq $ESP_GPT_TYPE) } | Select-Object -First 1

# Any ESP on OTHER disks is exactly what v1 could have written to. Surface it.
$foreignEsps = @()
try{
    $foreignEsps = @(Get-Partition -ErrorAction Stop | Where-Object {
        $_.GptType -and (((([string]$_.GptType) -replace '[{}]','')).ToLower() -eq $ESP_GPT_TYPE) -and $_.DiskNumber -ne $sysDisk.Number })
}catch{ Write-YcLog ('Could not scan other disks for EFI System Partitions: ' + $_.Exception.Message) 'WARN' }

# Active/system partition on the system disk (this is the bcdboot target on BIOS/MBR).
$biosSysPart = $sysDiskParts | Where-Object { $_.IsSystem } | Select-Object -First 1
if(-not $biosSysPart){ $biosSysPart = $sysDiskParts | Where-Object { $_.IsActive } | Select-Object -First 1 }

# Firmware type. Primary signal is what the live BCD actually loads; the others are corroboration.
$bcdCurrent  = Get-YcNativeText -File $BcdEdit -Arguments @('/enum','{current}')
$fwFromBcd   = $null
if($bcdCurrent -match 'winload\.efi'){ $fwFromBcd = 'UEFI' } elseif($bcdCurrent -match 'winload\.exe'){ $fwFromBcd = 'BIOS' }
$fwFromEnv   = $null
if($env:firmware_type -match 'UEFI'){ $fwFromEnv = 'UEFI' } elseif($env:firmware_type -match 'Legacy|BIOS'){ $fwFromEnv = 'BIOS' }
$fwFromDisk  = if($esp -and $sysDisk.PartitionStyle -eq 'GPT'){ 'UEFI' } else { 'BIOS' }
$firmware    = if($fwFromBcd){ $fwFromBcd } elseif($fwFromEnv){ $fwFromEnv } else { $fwFromDisk }

Write-YcLog ('Firmware=' + $firmware + '  SystemDrive=' + $SysDrive + '  SystemDisk=' + $sysDisk.Number + ' (' + $sysDisk.PartitionStyle + ')')
if($fwFromBcd -and $fwFromDisk -ne $fwFromBcd){
    Write-YcLog ('Firmware signals disagree: BCD says ' + $fwFromBcd + ', disk layout suggests ' + $fwFromDisk + '. Trusting the BCD. Run -DryRun and read the report before repairing.') 'WARN'
}

function Write-YcLayoutReport{
    Write-Host ''
    Write-Host '================ DETECTED LAYOUT ================' -ForegroundColor Cyan
    Write-Host ('  Firmware (from BCD loader)  : ' + $(if($fwFromBcd){$fwFromBcd}else{'unknown'}))
    Write-Host ('  Firmware (from firmware_type): ' + $(if($fwFromEnv){$fwFromEnv}else{'not set'}))
    Write-Host ('  Firmware (from disk layout) : ' + $fwFromDisk)
    Write-Host ('  Firmware IN USE             : ' + $firmware)
    Write-Host ('  System drive                : ' + $SysDrive + '  (disk ' + $sysPart.DiskNumber + ' partition ' + $sysPart.PartitionNumber + ')')
    Write-Host ('  System disk                 : ' + $sysDisk.Number + '  ' + $sysDisk.FriendlyName + '  style=' + $sysDisk.PartitionStyle + '  size=' + [math]::Round($sysDisk.Size/1GB,1) + 'GB')
    Write-Host ('  Partitions on system disk   : ' + $sysDiskParts.Count)
    foreach($p in $sysDiskParts){
        $pl = [string]$p.DriveLetter
        if(-not ($pl -match '^[A-Za-z]$')){ $pl = '-' }
        Write-Host ('     part ' + $p.PartitionNumber + '  letter=' + $pl + '  size=' + [math]::Round($p.Size/1MB,0) + 'MB  system=' + $p.IsSystem + '  boot=' + $p.IsBoot + '  active=' + $p.IsActive + '  gpttype=' + $p.GptType)
    }
    if($esp){
        $el = [string]$esp.DriveLetter
        if(-not ($el -match '^[A-Za-z]$')){ $el = 'not mounted' } else { $el = $el + ':' }
        Write-Host ('  ESP on system disk          : disk ' + $esp.DiskNumber + ' partition ' + $esp.PartitionNumber + '  size=' + [math]::Round($esp.Size/1MB,0) + 'MB  mounted=' + $el) -ForegroundColor Green
    } else {
        Write-Host '  ESP on system disk          : NONE FOUND' -ForegroundColor Yellow
    }
    if($biosSysPart){
        Write-Host ('  Active/system partition     : disk ' + $biosSysPart.DiskNumber + ' partition ' + $biosSysPart.PartitionNumber)
    } else {
        Write-Host '  Active/system partition     : NONE FOUND' -ForegroundColor Yellow
    }
    if($foreignEsps.Count -gt 0){
        Write-Host ('  EFI System Partitions on OTHER disks: ' + $foreignEsps.Count + ' - these are NEVER written to by this command.') -ForegroundColor Yellow
        foreach($f in $foreignEsps){ Write-Host ('     disk ' + $f.DiskNumber + ' partition ' + $f.PartitionNumber + '  size=' + [math]::Round($f.Size/1MB,0) + 'MB') -ForegroundColor Yellow }
    }
    Write-Host ('  bootrec.exe present         : ' + (Test-Path $BootRec) + '   (expected False - WinRE/WinPE only)')
    Write-Host ('  bootsect.exe present        : ' + (Test-Path $BootSect) + '  (expected False on Server - ADK/media only)')
    Write-Host '================================================' -ForegroundColor Cyan
    Show-YcBlock -Title 'bcdedit /enum {bootmgr}' -Text (Get-YcNativeText -File $BcdEdit -Arguments @('/enum','{bootmgr}'))
    Show-YcBlock -Title 'bcdedit /enum {current}' -Text $bcdCurrent
    if($firmware -eq 'UEFI'){
        Show-YcBlock -Title 'bcdedit /enum firmware (UEFI NVRAM boot entries)' -Text (Get-YcNativeText -File $BcdEdit -Arguments @('/enum','firmware'))
    }
}

# ------------------------------------------------------------- -DryRun ------
if($DryRun){
    Write-YcLog 'DRY RUN: reporting the detected layout only. Nothing is mounted, written, scheduled or rebooted.' 'WARN'
    Write-YcLayoutReport
    Write-Host ''
    Write-Host '--- what -Boot WOULD do on this machine ---' -ForegroundColor Cyan
    if($firmware -eq 'UEFI'){
        if($esp){
            $wl = [string]$esp.DriveLetter
            if(-not ($wl -match '^[A-Za-z]$')){ $wl = Get-YcFreeDriveLetter -Preferred $EspLetter }
            if(-not $wl){ $wl = '<no free drive letter available>' }
            Write-Host ('    bcdedit /export C:\Scripts\bcd-backup-' + $Stamp)
            Write-Host ('    (mount ESP disk ' + $esp.DiskNumber + ' partition ' + $esp.PartitionNumber + ' as ' + $wl + ': , verify identity, back up ' + $wl + ':\EFI\Microsoft\Boot)')
            Write-Host ('    bcdboot ' + $SysDrive + '\Windows /s ' + $wl + ': /f UEFI /v')
            if($UpdateNvram){ Write-Host ('    bcdboot ' + $SysDrive + '\Windows /f UEFI /p     (re-creates the UEFI NVRAM entry)') }
            Write-Host ('    (verify bcdboot exit code, re-read ' + $wl + ':\EFI\Microsoft\Boot\BCD, then unmount ' + $wl + ':)')
        } else {
            Write-Host '    NOTHING - firmware is UEFI but there is no EFI System Partition on the system disk.' -ForegroundColor Yellow
        }
    } else {
        if($biosSysPart){
            Write-Host ('    bcdedit /export C:\Scripts\bcd-backup-' + $Stamp)
            Write-Host ('    bcdboot ' + $SysDrive + '\Windows /s <active system partition on disk ' + $sysDisk.Number + '> /f BIOS /v')
        } else {
            Write-Host ('    bcdboot ' + $SysDrive + '\Windows /s ' + $SysDrive + ' /f BIOS /v')
        }
        Write-Host '    NOT bootrec /fixmbr, /fixboot or /rebuildbcd - those exist only in WinRE/WinPE.' -ForegroundColor Yellow
    }
    if($FileSystem -or $ScheduleChkdsk -or $Full){ Write-Host ('    chkdsk ' + $SysDrive + ' /scan ; sfc /scannow ; DISM /RestoreHealth ; schedule chkdsk /f /r') }
    if($Reboot){ Write-Host '    shutdown /r /t 15    (suppressed by -DryRun)' }
    Write-YcLog 'Dry run complete. No changes were made.' 'OK'
    Stop-YcLog 0; exit 0
}

# --------------------------------------------- SAFE default: read-only ------
if(-not $Boot -and -not $FileSystem -and -not $ScheduleChkdsk -and -not $FixMbr){
    Write-YcLog 'Read-only scan (no changes). Use -DryRun for layout only, or -Boot / -FileSystem / -Full to repair.'
    Write-YcLayoutReport
    Write-Host '--- filesystem scan (chkdsk /scan) ---' -ForegroundColor Cyan
    $rc = Invoke-YcNative -File $ChkDsk -Arguments @($SysDrive,'/scan')
    if($rc -eq 0){ Write-YcLog 'chkdsk /scan found no problems.' 'OK' }
    else { Write-YcLog ('chkdsk /scan exit ' + $rc + ' - problems were found or the scan could not complete. Consider -ScheduleChkdsk.') 'WARN' }
    Write-YcLog 'Read-only report complete.' 'OK'
    Stop-YcLog 0; exit 0
}

# ------------------------------------------------------------- -FixMbr ------
if($FixMbr){
    Write-YcLog 'MBR / boot-sector repair requested.' 'WARN'
    Assert-YcBootrec
    # Only reachable on a WinPE/WinRE image where bootrec really exists.
    $rc1 = Invoke-YcNative -File $BootRec -Arguments @('/fixmbr')
    $rc2 = Invoke-YcNative -File $BootRec -Arguments @('/fixboot')
    $rc3 = Invoke-YcNative -File $BootRec -Arguments @('/rebuildbcd')
    if($rc1 -ne 0 -or $rc2 -ne 0 -or $rc3 -ne 0){
        Write-YcLog ('bootrec reported failure (fixmbr=' + $rc1 + ' fixboot=' + $rc2 + ' rebuildbcd=' + $rc3 + ').') 'ERROR'
        Stop-YcLog 1; exit 1
    }
    Write-YcLog 'bootrec /fixmbr /fixboot /rebuildbcd all returned 0.' 'OK'
}

# --------------------------------------------------------- boot repair ------
$mountedLetter = $null
$bcdBackup     = Join-Path 'C:\Scripts' ('bcd-backup-' + $Stamp)
$espBackupDir  = Join-Path 'C:\Scripts' ('esp-backup-' + $Stamp)
$restoreLines  = New-Object System.Collections.ArrayList

if($Boot){
    Write-YcLog ('Repairing the boot loader for ' + $firmware + ' on disk ' + $sysDisk.Number + ' ...') 'WARN'
    Write-YcLayoutReport

    # ---- 1. back up the BCD before touching anything -------------------------
    $backupOk = $false
    $rc = Invoke-YcNative -File $BcdEdit -Arguments @('/export',$bcdBackup)
    if($rc -eq 0 -and (Test-Path $bcdBackup)){
        $backupOk = $true
        [void]$restoreLines.Add('bcdedit /import "' + $bcdBackup + '"')
        Write-YcLog ('BCD exported to ' + $bcdBackup) 'OK'
    } else {
        Write-YcLog ('bcdedit /export failed (exit ' + $rc + '). There is no BCD backup for this run.') 'ERROR'
        if(-not $Force){
            Write-YcLog 'Refusing to modify boot data without a backup. Re-run with -Force if the BCD is already destroyed and there is nothing left to save.' 'ERROR'
            Stop-YcLog 1; exit 1
        }
        Write-YcLog '-Force was given: continuing WITHOUT a BCD backup.' 'WARN'
    }

    if($firmware -eq 'UEFI'){
        # ---- 2. ESP on the SYSTEM disk only ---------------------------------
        if(-not $esp){
            Write-YcLog ('Firmware is UEFI but disk ' + $sysDisk.Number + ' (the system disk) has no EFI System Partition. This command will not write boot files to another disk. Boot the recovery ISO and rebuild the ESP.') 'ERROR'
            Stop-YcLog 1; exit 1
        }
        if($foreignEsps.Count -gt 0){
            Write-YcLog ('Ignoring ' + $foreignEsps.Count + ' EFI System Partition(s) on other disks - only disk ' + $sysDisk.Number + ' is touched.') 'WARN'
        }

        # ---- 3. drive letter, chosen dynamically, then PROVEN ---------------
        $letter = [string]$esp.DriveLetter
        if($letter -match '^[A-Za-z]$'){
            $letter = $letter.ToUpper()
            Write-YcLog ('ESP already mounted at ' + $letter + ':')
            try{
                $back = Get-Partition -DriveLetter $letter -ErrorAction Stop
                if($back.DiskNumber -ne $esp.DiskNumber -or $back.PartitionNumber -ne $esp.PartitionNumber){
                    Write-YcLog ('SAFETY ABORT: ' + $letter + ': no longer resolves to the ESP on disk ' + $esp.DiskNumber + '.') 'ERROR'
                    Stop-YcLog 1; exit 1
                }
            }catch{
                Write-YcLog ('Cannot verify what ' + $letter + ': points at: ' + $_.Exception.Message) 'ERROR'
                Stop-YcLog 1; exit 1
            }
        } else {
            $letter = Get-YcFreeDriveLetter -Preferred $EspLetter
            if(-not $letter){
                Write-YcLog 'No free drive letter is available to mount the EFI System Partition on.' 'ERROR'
                Stop-YcLog 1; exit 1
            }
            Write-YcLog ('Mounting the ESP on the first free letter: ' + $letter + ':')
            if(-not (Mount-YcPartition -Partition $esp -Letter $letter)){
                Write-YcLog 'Could not mount the EFI System Partition safely. No boot files were written.' 'ERROR'
                Stop-YcLog 1; exit 1
            }
            $mountedLetter = $letter
        }
        # The audit's literal guard, kept verbatim in spirit: the letter must exist before bcdboot runs.
        if(-not (Test-Path ($letter + ':\'))){
            Write-YcLog ('Drive ' + $letter + ': does not exist - refusing to run bcdboot against a volume that is not there.') 'ERROR'
            Stop-YcLog 1; exit 1
        }

        # ---- 4. back up the existing EFI boot files ------------------------
        $espBootDir = $letter + ':\EFI\Microsoft\Boot'
        if(Test-Path $espBootDir){
            try{
                New-Item -ItemType Directory -Force -Path $espBackupDir -ErrorAction Stop | Out-Null
                Copy-Item -Path (Join-Path $espBootDir '*') -Destination $espBackupDir -Recurse -Force -ErrorAction Stop
                [void]$restoreLines.Add('robocopy "' + $espBackupDir + '" "' + $espBootDir + '" /E')
                Write-YcLog ('Existing EFI boot files copied to ' + $espBackupDir) 'OK'
            }catch{
                Write-YcLog ('Could not copy the existing EFI boot files: ' + $_.Exception.Message) 'WARN'
            }
        } else {
            Write-YcLog ($espBootDir + ' does not exist yet - bcdboot will create it.') 'WARN'
        }

        # ---- 5. write the boot files ---------------------------------------
        $rc = Invoke-YcNative -File $BcdBoot -Arguments @(($SysDrive + '\Windows'),'/s',($letter + ':'),'/f','UEFI','/v')
        if($rc -ne 0){
            Write-YcLog ('bcdboot FAILED with exit code ' + $rc + '. The boot files were NOT written as intended.') 'ERROR'
            if($backupOk){ Write-YcLog ('Restore with: bcdedit /import "' + $bcdBackup + '"') 'ERROR' }
            if($mountedLetter){ Dismount-YcLetter -Letter $mountedLetter }
            Stop-YcLog 1; exit 1
        }
        Write-YcLog ('bcdboot wrote the UEFI boot files to ' + $letter + ': (exit 0).') 'OK'

        # bcdboot with /s deliberately does NOT create a firmware (NVRAM) entry - opt in with -UpdateNvram.
        if($UpdateNvram){
            Write-YcLog 'Updating the UEFI firmware (NVRAM) boot entry - bcdboot without /s, /p to preserve its position.' 'WARN'
            $rcn = Invoke-YcNative -File $BcdBoot -Arguments @(($SysDrive + '\Windows'),'/f','UEFI','/p','/v')
            if($rcn -ne 0){ Write-YcLog ('bcdboot NVRAM update returned ' + $rcn + ' - the on-disk boot files are still fine.') 'WARN' }
            else { Write-YcLog 'UEFI firmware boot entry updated.' 'OK' }
        } else {
            Write-YcLog 'UEFI NVRAM was not touched (bcdboot /s suppresses the firmware entry). Add -UpdateNvram if the firmware entry itself is missing.'
        }

        # ---- 6. verify what we just wrote ----------------------------------
        $espBcd  = $letter + ':\EFI\Microsoft\Boot\BCD'
        $espLdr  = $letter + ':\EFI\Microsoft\Boot\bootmgfw.efi'
        $verifyOk = $true
        if(-not (Test-Path $espLdr)){ Write-YcLog ('VERIFY FAILED: ' + $espLdr + ' is missing.') 'ERROR'; $verifyOk = $false }
        if(-not (Test-Path $espBcd)){ Write-YcLog ('VERIFY FAILED: ' + $espBcd + ' is missing.') 'ERROR'; $verifyOk = $false }
        if($verifyOk){
            $storeText = Get-YcNativeText -File $BcdEdit -Arguments @('/store',$espBcd,'/enum','{bootmgr}')
            Show-YcBlock -Title ('bcdedit /store ' + $espBcd + ' /enum {bootmgr}') -Text $storeText
            if($storeText -match 'bootmgfw\.efi'){
                Write-YcLog ('VERIFIED: the BCD on ' + $letter + ': has a Windows Boot Manager entry pointing at \EFI\Microsoft\Boot\bootmgfw.efi.') 'OK'
            } else {
                Write-YcLog ('VERIFY FAILED: the BCD on ' + $letter + ': has no bootmgfw.efi boot manager entry.') 'ERROR'
                $verifyOk = $false
            }
        }
        Show-YcBlock -Title 'bcdedit /enum {bootmgr} (live system store, after repair)' -Text (Get-YcNativeText -File $BcdEdit -Arguments @('/enum','{bootmgr}'))
        if($firmware -eq 'UEFI'){
            Show-YcBlock -Title 'bcdedit /enum firmware (after repair)' -Text (Get-YcNativeText -File $BcdEdit -Arguments @('/enum','firmware'))
        }
        if($mountedLetter){ Dismount-YcLetter -Letter $mountedLetter; $mountedLetter = $null }
        if(-not $verifyOk){
            Write-YcLog 'Boot repair could not be verified. Do NOT reboot until the restore commands below have been considered.' 'ERROR'
            foreach($r in $restoreLines){ Write-Host ('    ' + $r) -ForegroundColor Yellow; Write-YcLog ('RESTORE: ' + $r) 'ERROR' }
            Stop-YcLog 1; exit 1
        }
        Write-YcLog 'UEFI boot loader repair completed and verified.' 'OK'
    }
    else{
        # ---------------------------- BIOS / MBR ----------------------------
        Write-YcLog 'BIOS/MBR system detected.' 'WARN'
        Write-YcLog ('bootrec.exe present in System32: ' + (Test-Path $BootRec) + ' ; bootsect.exe present: ' + (Test-Path $BootSect) + '. Both ship only in WinRE/WinPE (bootrec) or the ADK/installation media (bootsect).') 'WARN'
        Write-YcLog 'This command will therefore NOT attempt bootrec /fixmbr, /fixboot or /rebuildbcd. It does the part a booted Windows can actually do: rebuild bootmgr and the BCD with bcdboot /f BIOS.' 'WARN'

        $target = $null
        if($biosSysPart){
            $bl = [string]$biosSysPart.DriveLetter
            if($bl -match '^[A-Za-z]$'){
                $target = $bl.ToUpper() + ':'
                Write-YcLog ('Active system partition is already mounted at ' + $target)
            } else {
                $letter = Get-YcFreeDriveLetter -Preferred $EspLetter
                if($letter -and (Mount-YcPartition -Partition $biosSysPart -Letter $letter)){
                    $mountedLetter = $letter
                    $target = $letter + ':'
                } else {
                    Write-YcLog ('Could not mount the active system partition (disk ' + $biosSysPart.DiskNumber + ' partition ' + $biosSysPart.PartitionNumber + '); falling back to ' + $SysDrive + '.') 'WARN'
                }
            }
        } else {
            Write-YcLog ('No system/active partition found on disk ' + $sysDisk.Number + '; falling back to ' + $SysDrive + '.') 'WARN'
        }
        if(-not $target){ $target = $SysDrive }
        if(-not (Test-Path ($target + '\'))){
            Write-YcLog ('Target volume ' + $target + ' does not exist - refusing to run bcdboot.') 'ERROR'
            Stop-YcLog 1; exit 1
        }

        $rc = Invoke-YcNative -File $BcdBoot -Arguments @(($SysDrive + '\Windows'),'/s',$target,'/f','BIOS','/v')
        if($rc -ne 0){
            Write-YcLog ('bcdboot /f BIOS FAILED with exit code ' + $rc + '.') 'ERROR'
            if($backupOk){ Write-YcLog ('Restore with: bcdedit /import "' + $bcdBackup + '"') 'ERROR' }
            if($mountedLetter){ Dismount-YcLetter -Letter $mountedLetter }
            Stop-YcLog 1; exit 1
        }
        Write-YcLog ('bcdboot wrote bootmgr + \Boot\BCD to ' + $target + ' (exit 0).') 'OK'

        $verifyOk = $true
        if(-not (Test-Path ($target + '\Boot\BCD'))){ Write-YcLog ('VERIFY FAILED: ' + $target + '\Boot\BCD is missing.') 'ERROR'; $verifyOk = $false }
        if(-not (Test-Path ($target + '\bootmgr'))){ Write-YcLog ('VERIFY WARNING: ' + $target + '\bootmgr not visible (it is a hidden system file; this is often expected).') 'WARN' }
        if($verifyOk){
            $storeText = Get-YcNativeText -File $BcdEdit -Arguments @('/store',($target + '\Boot\BCD'),'/enum','{bootmgr}')
            Show-YcBlock -Title ('bcdedit /store ' + $target + '\Boot\BCD /enum {bootmgr}') -Text $storeText
            if($storeText -match 'Windows Boot Manager'){
                Write-YcLog ('VERIFIED: the BCD on ' + $target + ' contains a Windows Boot Manager entry.') 'OK'
            } else {
                Write-YcLog ('VERIFY FAILED: no Windows Boot Manager entry in ' + $target + '\Boot\BCD.') 'ERROR'
                $verifyOk = $false
            }
        }
        Show-YcBlock -Title 'bcdedit /enum {bootmgr} (live system store, after repair)' -Text (Get-YcNativeText -File $BcdEdit -Arguments @('/enum','{bootmgr}'))
        if($mountedLetter){ Dismount-YcLetter -Letter $mountedLetter; $mountedLetter = $null }

        Write-YcLog 'If the machine still does not boot after this, the damage is in the MBR boot code or the volume boot record. Boot the recovery ISO / WinRE and run: bootrec /fixmbr ; bootrec /fixboot ; bootrec /scanos ; bootrec /rebuildbcd. Those tools do not exist on a booted Windows Server and this command will not pretend otherwise.' 'WARN'
        if(-not $verifyOk){
            foreach($r in $restoreLines){ Write-Host ('    ' + $r) -ForegroundColor Yellow; Write-YcLog ('RESTORE: ' + $r) 'ERROR' }
            Stop-YcLog 1; exit 1
        }
        Write-YcLog 'BIOS boot loader (bootmgr + BCD) repair completed and verified.' 'OK'
    }
}

# ------------------------------------------------------ filesystem / MFT ----
if($FileSystem){
    Write-YcLog 'Filesystem scan (chkdsk /scan) ...'
    $rc = Invoke-YcNative -File $ChkDsk -Arguments @($SysDrive,'/scan')
    if($rc -eq 0){ Write-YcLog 'chkdsk /scan: no problems found.' 'OK' }
    else { Write-YcLog ('chkdsk /scan exit ' + $rc + ' - problems found or scan incomplete; an offline chkdsk /f /r is being scheduled.') 'WARN' }

    Write-YcLog 'sfc /scannow ...'
    $rc = Invoke-YcNative -File (Join-Path $env:SystemRoot 'System32\sfc.exe') -Arguments @('/scannow')
    if($rc -eq 0){ Write-YcLog 'sfc /scannow completed (exit 0).' 'OK' }
    else { Write-YcLog ('sfc /scannow exit ' + $rc + ' - review C:\Windows\Logs\CBS\CBS.log.') 'WARN' }

    Write-YcLog 'DISM /Online /Cleanup-Image /RestoreHealth ...'
    $rc = Invoke-YcNative -File (Join-Path $env:SystemRoot 'System32\Dism.exe') -Arguments @('/Online','/Cleanup-Image','/RestoreHealth')
    if($rc -eq 0){ Write-YcLog 'DISM RestoreHealth completed (exit 0).' 'OK' }
    elseif($rc -eq 3010){ Write-YcLog 'DISM RestoreHealth completed and requires a reboot (exit 3010).' 'OK' }
    else { Write-YcLog ('DISM RestoreHealth exit ' + $rc + ' - review C:\Windows\Logs\DISM\dism.log.') 'WARN' }

    $ScheduleChkdsk = $true
}

# --------------------- schedule offline chkdsk /f /r (MFT/index repair) -----
if($ScheduleChkdsk){
    Write-YcLog ('Scheduling chkdsk /f /r on ' + $SysDrive + ' for the next reboot (MFT/index repair)...') 'WARN'
    $rc = Invoke-YcNative -File (Join-Path $env:SystemRoot 'System32\cmd.exe') -Arguments @('/c',('echo Y| chkdsk ' + $SysDrive + ' /f /r'))
    if($rc -eq 0 -or $rc -eq 1 -or $rc -eq 2 -or $rc -eq 3){ Write-YcLog ('chkdsk scheduled for the next reboot (chkdsk exit ' + $rc + ').') 'OK' }
    else { Write-YcLog ('chkdsk scheduling returned ' + $rc + ' - verify with: fsutil dirty query ' + $SysDrive) 'WARN' }
}

# ------------------------------------------------ reversibility reminder ----
if($restoreLines.Count -gt 0){
    Write-Host ''
    Write-Host '============ HOW TO UNDO THIS RUN ============' -ForegroundColor Yellow
    foreach($r in $restoreLines){
        Write-Host ('    ' + $r) -ForegroundColor Yellow
        Write-YcLog ('RESTORE COMMAND: ' + $r) 'WARN'
    }
    Write-Host '  Run those elevated, then reboot.' -ForegroundColor Yellow
    Write-Host '==============================================' -ForegroundColor Yellow
}

if($Reboot){
    Write-YcLog 'Rebooting in 15s (a scheduled chkdsk and BCD changes take effect on reboot)...' 'WARN'
    & (Join-Path $env:SystemRoot 'System32\shutdown.exe') /r /t 15 /c "boot-repair reboot" | Out-Null
    Write-YcLog 'Reboot requested (T-15s). Cancel with: shutdown /a' 'OK'
    Stop-YcLog 0; exit 0
}

Write-YcLog 'Done. If a chkdsk was scheduled, reboot to run it (boot-repair -Reboot or shutdown /r).' 'OK'
Stop-YcLog 0; exit 0
