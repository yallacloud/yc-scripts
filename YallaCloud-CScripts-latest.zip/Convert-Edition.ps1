#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Converts a Windows Server edition in place - Evaluation to retail/volume, or
    Standard to Datacenter - using Microsoft's documented DISM /Set-Edition path.

.DESCRIPTION
    Start with -List. It prints the current edition and, crucially, the exact
    list of target editions THIS image will accept, read live from
    "DISM /Online /Get-TargetEditions". The toolkit never hardcodes that list,
    because it is wrong often enough to matter: Server 2025 evaluation ISOs
    packaged with Azure Edition components offer ServerTurbine and
    ServerDatacenter but not ServerStandard, and Standard Evaluation on Server
    Core can only ever become Datacenter Core.

    The conversion is a one-way, two-reboot operation with no undo. This script
    therefore refuses to guess: you name the target, it validates the target
    against the live list, it shows you the exact DISM command, and it asks
    before running it.

    Two-stage key handling, which is the part most scripts get wrong. DISM
    /Set-Edition frequently rejects a MAK, CSP or volume key with error 1168
    ("The specified product key could not be validated"). The reliable input is
    the Microsoft-published GVLK for the target edition. So:

        stage 1  DISM /Set-Edition:<target> /ProductKey:<published GVLK>
        reboot twice
        stage 2  slmgr /ipk <your real key>  then  slmgr /ato

    A GVLK changes the edition; it is NOT a licence. Stage 2 is mandatory unless
    you are activating against your own KMS host or an AD activation object, in
    which case the GVLK is the correct final state. Run activate-windows
    after the reboots either way.

.PARAMETER List
    Show the current edition and the live list of valid targets. Changes nothing.
    Run this first, every time.

.PARAMETER TargetEdition
    The edition ID to convert to, exactly as -List printed it (for example
    ServerStandard, ServerDatacenter, ServerDatacenterCor, ServerTurbine).

.PARAMETER ProductKey
    Optional. A retail, volume or CSP key to try directly with DISM. When it is
    omitted - the recommended path - the Microsoft-published GVLK for the target
    edition is used instead, and you install your real key after the reboots.
    Masked in all output.

.PARAMETER AllowReboot
    Restart automatically when DISM reports a pending restart. Off by default:
    the conversion needs TWO reboots and an unattended restart in the middle of
    an irreversible operation is not a good default.

.PARAMETER Force
    Skip the interactive confirmation. Intended for cloud-init and other
    unattended callers that have already validated the target.

.PARAMETER SelfCheck
    Run the built-in assertions and exit. Touches nothing.

.EXAMPLE
    convert-edition -List
    What am I, and what can I legally become?

.EXAMPLE
    convert-edition -TargetEdition ServerStandard
    Convert to Standard using the published GVLK, then reboot twice and run
    activate-windows.

.EXAMPLE
    convert-edition -TargetEdition ServerDatacenter -WhatIf
    Show the exact DISM command that would run. Change nothing.

.NOTES
    Documented blocks this script enforces:

      Domain controllers. Microsoft: "You can't convert an Active Directory
      domain controller from an evaluation to a retail version. In this case,
      install another domain controller on a server that runs a retail version.
      Then migrate any FSMO roles ... Finally, remove Active Directory Domain
      Services (AD DS) from the domain controller that runs on the evaluation
      version." Note that is NOT "demote first".

      Server Core to Desktop Experience. Microsoft: "you can't convert between
      Server Core and Server with Desktop Experience after installation. You'll
      need to do a clean installation". There is no command for this.

      Downgrades. "You can't set a Windows image to a lower edition."

      Re-running. "Don't use /Set-Edition on an image already changed to a
      higher edition."

    Sources
      Conversion     https://learn.microsoft.com/en-us/windows-server/get-started/upgrade-conversion-options
      DISM options   https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/dism-windows-edition-servicing-command-line-options
      Core vs GUI    https://learn.microsoft.com/en-us/windows-server/get-started/install-options-server-core-desktop-experience
      GVLK table     https://learn.microsoft.com/en-us/windows-server/get-started/kms-client-activation-keys
      slmgr          https://learn.microsoft.com/en-us/windows-server/get-started/activation-slmgr-vbs-options
      Error 1168     https://www.dell.com/support/kbdoc/en-us/000204465/cloud-solution-provider-csp-perpetual-license-product-key-not-working-to-convert-eval-os-install
#>
[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [switch] $List,
    [string] $TargetEdition,
    [string] $ProductKey,
    [switch] $AllowReboot,
    [switch] $Force,
    [switch] $SelfCheck,
    [string] $LogDirectory = 'C:\Scripts'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$commonPath = Join-Path $PSScriptRoot '_yc-licensing.ps1'
if (-not (Test-Path -LiteralPath $commonPath)) {
    throw ('_yc-licensing.ps1 was not found next to this script (' + $commonPath + '). It ships with it; copy both.')
}
. $commonPath

# ---------------------------------------------------------------------------
# Parsing and validation - pure functions, exercised by -SelfCheck
# ---------------------------------------------------------------------------

function Get-YcCurrentEditionFromDism {
    <#
      .SYNOPSIS
        Pulls the edition ID out of "DISM /Online /Get-CurrentEdition" output.
      .DESCRIPTION
        DISM prints a banner, a blank line, then "Current Edition : X". The regex
        is anchored on the label rather than on a line index because the number
        of banner lines varies by OS build and by whether a log path warning is
        emitted.
    #>
    [CmdletBinding()][OutputType([string])]
    param([AllowNull()][string[]] $Lines)
    foreach ($l in @($Lines)) {
        if ("$l" -match '(?i)current\s+edition\s*:\s*(\S.*)$') { return $Matches[1].Trim() }
    }
    return ''
}

function Get-YcTargetEditionsFromDism {
    <#
      .SYNOPSIS
        Pulls the list of valid targets out of "DISM /Online /Get-TargetEditions".
      .DESCRIPTION
        Output is one "Target Edition : X" line per available target. An empty
        result is meaningful, not a parse failure: it means this image offers no
        upgrade path and a clean install is the only way to the edition you want.
    #>
    [CmdletBinding()][OutputType([string[]])]
    param([AllowNull()][string[]] $Lines)
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($l in @($Lines)) {
        if ("$l" -match '(?i)target\s+edition\s*:\s*(\S.*)$') {
            $v = $Matches[1].Trim()
            if ($v -and -not $out.Contains($v)) { $out.Add($v) }
        }
    }
    return $out.ToArray()
}

function Resolve-YcDismEditionError {
    <#
      .SYNOPSIS
        Turns a DISM failure into the documented cause and remedy.
      .DESCRIPTION
        Only codes with a real documented cause are mapped. Anything else returns
        null so the caller reports the raw code instead of inventing a meaning.
        In particular 0x8A010101 is NOT mapped here - Microsoft publishes it only
        as an Office for Mac error and it has no documented relationship to
        edition conversion. The code you actually get from a rejected key is 1168.
    #>
    [CmdletBinding()]
    param([AllowNull()][AllowEmptyString()][string] $Text, [int] $ExitCode = 0)
    $t = '' + $Text
    if ($t -match '1168' -or $t -match '(?i)product key could not be validated') {
        return [pscustomobject]@{
            Code    = '1168'
            Meaning = 'The specified product key could not be validated. Check that the key is valid and that it matches the target edition.'
            Fix     = 'Retail and OEM keys are the documented input; MAK, CSP and volume keys are frequently rejected here. Re-run without -ProductKey so the Microsoft-published GVLK for the target edition is used, then install your real key with slmgr /ipk after the two reboots.'
            Url     = 'https://www.dell.com/support/kbdoc/en-us/000204465/cloud-solution-provider-csp-perpetual-license-product-key-not-working-to-convert-eval-os-install'
        }
    }
    if ($t -match '(?i)0x800f0831') {
        return [pscustomobject]@{
            Code    = '0x800f0831'
            Meaning = 'Component store corruption. The servicing stack could not find a payload it needs to complete the edition change.'
            Fix     = 'Run: DISM /Online /Cleanup-Image /RestoreHealth  then retry the conversion. If the machine is an expired evaluation that shuts down hourly, reboot first so the repair and the conversion both fit inside one uptime window.'
            Url     = 'https://learn.microsoft.com/en-us/windows-server/get-started/upgrade-conversion-options'
        }
    }
    if ($t -match '(?i)0x80070490' -or $t -match '(?i)ThreadSkuInstallEula' -or $t -match '(?i)failed to copy edition license') {
        return [pscustomobject]@{
            Code    = '0x80070490'
            Meaning = 'The target edition''s licence file is not present in this image. The conversion is impossible on this media, not misconfigured.'
            Fix     = 'This is the classic Server Core evaluation case: Standard Eval Core can only become Datacenter Core. Check the live -List output and pick a target from it, or do a clean install from correct media.'
            Url     = 'https://learn.microsoft.com/en-us/windows-server/get-started/upgrade-conversion-options'
        }
    }
    if ($t -match '(?i)14003' -or $t -match '(?i)ERROR_SXS_ASSEMBLY_NOT_FOUND') {
        return [pscustomobject]@{
            Code    = '14003'
            Meaning = 'ERROR_SXS_ASSEMBLY_NOT_FOUND - a side-by-side assembly the conversion needs is missing, usually reported at 100%.'
            Fix     = 'Run DISM /Online /Cleanup-Image /RestoreHealth, then sfc /scannow, then retry. If it recurs, the image is damaged; rebuild from clean media.'
            Url     = 'https://learn.microsoft.com/en-us/windows-server/get-started/upgrade-conversion-options'
        }
    }
    return $null
}

function Test-YcEditionTargetValid {
    <#
      .SYNOPSIS
        Is the requested target in the live list DISM reported?
      .OUTPUTS
        Valid (bool), Match (string, the exact-cased target), Reason (string).
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][AllowEmptyString()][string] $Requested,
        [Parameter(Mandatory = $true)][AllowEmptyCollection()][string[]] $Available
    )
    if ([string]::IsNullOrWhiteSpace($Requested)) {
        return [pscustomobject]@{ Valid = $false; Match = ''; Reason = 'No target edition was given.' }
    }
    if (@($Available).Count -eq 0) {
        return [pscustomobject]@{ Valid = $false; Match = ''; Reason = 'This image offers NO target editions. DISM cannot convert it. A clean install is the only route.' }
    }
    foreach ($a in $Available) {
        if ($a -and $a.Trim().ToLowerInvariant() -eq $Requested.Trim().ToLowerInvariant()) {
            return [pscustomobject]@{ Valid = $true; Match = $a; Reason = '' }
        }
    }
    return [pscustomobject]@{
        Valid  = $false
        Match  = ''
        Reason = ('"' + $Requested + '" is not one of the targets this image accepts. Available: ' + ($Available -join ', '))
    }
}

function Get-YcEditionNameForGvlk {
    <#
      .SYNOPSIS
        Maps a DISM edition ID onto the edition name the GVLK table uses.
      .DESCRIPTION
        ServerTurbine is Microsoft's internal SKU name for Datacenter: Azure
        Edition and is what actually appears in /Get-TargetEditions output;
        ServerSolution is Essentials. The Cor / Core suffix marks Server Core,
        which shares the parent edition's GVLK.
    #>
    [CmdletBinding()][OutputType([string])]
    param([AllowNull()][AllowEmptyString()][string] $EditionId)
    $e = ('' + $EditionId).Trim()
    if (-not $e) { return '' }
    if ($e -match '(?i)turbine|azure')            { return 'Datacenter: Azure Edition' }
    if ($e -match '(?i)solution|essential')       { return 'Essentials' }
    if ($e -match '(?i)datacenter')               { return 'Datacenter' }
    if ($e -match '(?i)standard')                 { return 'Standard' }
    return ''
}

function Test-YcEditionIsCore {
    [CmdletBinding()][OutputType([bool])]
    param([AllowNull()][AllowEmptyString()][string] $EditionId)
    return (('' + $EditionId) -match '(?i)cor$|core$|cor[a-z]*$' -and ('' + $EditionId) -match '(?i)cor')
}

# ---------------------------------------------------------------------------
# Self-check
# ---------------------------------------------------------------------------

function Invoke-YcSelfCheck {
    [CmdletBinding()] param()
    $script:n = 0; $script:fail = 0
    function T { param([string] $Name, [bool] $Ok)
        $script:n++
        if ($Ok) { Write-Host ('  ok   ' + $Name) -ForegroundColor Green }
        else     { Write-Host ('  FAIL ' + $Name) -ForegroundColor Red; $script:fail++ }
    }
    Write-Host 'convert-edition self-check' -ForegroundColor Cyan

    $cur = @(
        'Deployment Image Servicing and Management tool',
        'Version: 10.0.20348.1',
        '',
        'Image Version: 10.0.20348.2966',
        '',
        'Current Edition : ServerStandardEval',
        '',
        'The operation completed successfully.'
    )
    T 'current edition parsed from real DISM output' ((Get-YcCurrentEditionFromDism -Lines $cur) -eq 'ServerStandardEval')
    T 'no Current Edition line yields empty, not a crash' ((Get-YcCurrentEditionFromDism -Lines @('junk', '')) -eq '')
    T 'null input is tolerated' ((Get-YcCurrentEditionFromDism -Lines $null) -eq '')

    $tgt = @(
        'Deployment Image Servicing and Management tool',
        '',
        'Editions that can be upgraded to:',
        '',
        'Target Edition : ServerStandard',
        'Target Edition : ServerDatacenter',
        '',
        'The operation completed successfully.'
    )
    $list = @(Get-YcTargetEditionsFromDism -Lines $tgt)
    T 'two target editions parsed' ($list.Count -eq 2)
    T 'targets parsed in order'    ($list[0] -eq 'ServerStandard' -and $list[1] -eq 'ServerDatacenter')
    T 'an image with no targets parses as empty, not as an error' (@(Get-YcTargetEditionsFromDism -Lines @('The operation completed successfully.')).Count -eq 0)

    # The 2025 Azure-Edition ISO case, which a hardcoded table gets wrong
    $turbine = @(Get-YcTargetEditionsFromDism -Lines @('Target Edition : ServerTurbine', 'Target Edition : ServerDatacenter'))
    T 'ServerTurbine (Azure Edition) is parsed, not dropped' ($turbine -contains 'ServerTurbine')
    T 'ServerStandard is correctly absent from that ISO'     (-not ($turbine -contains 'ServerStandard'))

    $v = Test-YcEditionTargetValid -Requested 'ServerStandard' -Available $list
    T 'a valid target validates' ($v.Valid -eq $true -and $v.Match -eq 'ServerStandard')
    $v = Test-YcEditionTargetValid -Requested 'serverstandard' -Available $list
    T 'target matching is case-insensitive' ($v.Valid -eq $true -and $v.Match -eq 'ServerStandard')
    $v = Test-YcEditionTargetValid -Requested 'ServerStandardCor' -Available $list
    T 'an unavailable target is refused' ($v.Valid -eq $false -and $v.Reason -match 'not one of the targets')
    $v = Test-YcEditionTargetValid -Requested 'ServerStandard' -Available @()
    T 'an image with no targets is refused clearly' ($v.Valid -eq $false -and $v.Reason -match 'clean install')
    $v = Test-YcEditionTargetValid -Requested '' -Available $list
    T 'an empty target is refused' ($v.Valid -eq $false)

    T 'ServerStandard      -> Standard'                  ((Get-YcEditionNameForGvlk -EditionId 'ServerStandard') -eq 'Standard')
    T 'ServerDatacenterCor -> Datacenter'                ((Get-YcEditionNameForGvlk -EditionId 'ServerDatacenterCor') -eq 'Datacenter')
    T 'ServerTurbine       -> Datacenter: Azure Edition' ((Get-YcEditionNameForGvlk -EditionId 'ServerTurbine') -eq 'Datacenter: Azure Edition')
    T 'ServerSolution      -> Essentials'                ((Get-YcEditionNameForGvlk -EditionId 'ServerSolution') -eq 'Essentials')
    T 'an unknown edition ID maps to nothing'            ((Get-YcEditionNameForGvlk -EditionId 'ServerNonsense') -eq '')

    T 'GVLK found for ServerStandard on 2022' ((Get-YcGvlkForEdition -Build 20348 -Edition (Get-YcEditionNameForGvlk -EditionId 'ServerStandard')) -eq 'VDYBN-27WPP-V4HQT-9VMD4-VMK7H')

    $e = Resolve-YcDismEditionError -Text 'Error: 1168  The specified product key could not be validated.'
    T '1168 maps to the key-validation cause' ($e -ne $null -and $e.Code -eq '1168')
    T '1168 remedy points at the GVLK path'   ($e.Fix -match 'GVLK')
    $e = Resolve-YcDismEditionError -Text 'Error: 0x800f0831'
    T '0x800f0831 maps to component store corruption' ($e -ne $null -and $e.Fix -match 'RestoreHealth')
    $e = Resolve-YcDismEditionError -Text 'ThreadSkuInstallEula failed'
    T 'a missing edition licence file is identified'  ($e -ne $null -and $e.Code -eq '0x80070490')
    T 'an unknown DISM failure returns null, not a guess' ($null -eq (Resolve-YcDismEditionError -Text 'something else entirely'))
    T '0x8A010101 is deliberately NOT mapped here'    ($null -eq (Resolve-YcDismEditionError -Text 'Error 0x8A010101'))

    Write-Host ''
    if ($script:fail -eq 0) { Write-Host ('SELF-CHECK PASSED: ' + $script:n + ' assertions') -ForegroundColor Green; return 0 }
    Write-Host ('SELF-CHECK FAILED: ' + $script:fail + ' of ' + $script:n + ' assertions') -ForegroundColor Red
    return 1
}

if ($SelfCheck) { exit (Invoke-YcSelfCheck) }

# ---------------------------------------------------------------------------
# Live path
# ---------------------------------------------------------------------------

Assert-YcWindows
$null = Initialize-YcLog -Name 'convert-edition' -Directory $LogDirectory

$facts = Get-YcOsFacts
Write-YcLog ('OS            : ' + $facts.Caption + '  (build ' + $facts.Build + ')') 'STEP'
Write-YcLog ('EditionID     : ' + $facts.EditionId)
Write-YcLog ('Install type  : ' + $facts.InstallationType + $(if ($facts.IsCore) { '  (Server Core)' } else { '' }))
Write-YcLog ('Evaluation    : ' + $facts.IsEvaluation)

# --- documented hard blocks, checked before anything else -------------------

if ($facts.IsDomainController) {
    Write-YcLog ''
    Write-YcLog 'REFUSED: this machine is an Active Directory domain controller.' 'FAIL'
    Write-YcLog 'Microsoft: "You can''t convert an Active Directory domain controller from an evaluation to a' 'FAIL'
    Write-YcLog 'retail version. In this case, install another domain controller on a server that runs a retail' 'FAIL'
    Write-YcLog 'version. Then migrate any FSMO roles that are held by the evaluation domain controller. Finally,' 'FAIL'
    Write-YcLog 'remove Active Directory Domain Services (AD DS) from the domain controller that runs on the' 'FAIL'
    Write-YcLog 'evaluation version."' 'FAIL'
    Write-YcLog 'Note that is a new retail DC plus an FSMO transfer - not "demote this one and convert it".' 'WARN'
    Write-YcLog 'https://learn.microsoft.com/en-us/windows-server/get-started/upgrade-conversion-options' 'WARN'
    exit 2
}

# --- read the live state ----------------------------------------------------

Write-YcLog 'reading DISM /Online /Get-CurrentEdition' 'STEP'
$cur = Invoke-YcProcess -FilePath 'dism.exe' -Arguments @('/Online', '/English', '/Get-CurrentEdition') -TimeoutSeconds 300 -Quiet
$currentEdition = Get-YcCurrentEditionFromDism -Lines ($cur.StdOut -split "`r?`n")
if (-not $currentEdition) {
    Write-YcLog 'DISM did not report a Current Edition. Raw output follows.' 'FAIL'
    Write-YcLog ($cur.StdOut.Trim())
    exit 3
}
Write-YcLog ('Current edition: ' + $currentEdition) 'OK'

Write-YcLog 'reading DISM /Online /Get-TargetEditions' 'STEP'
$tgt = Invoke-YcProcess -FilePath 'dism.exe' -Arguments @('/Online', '/English', '/Get-TargetEditions') -TimeoutSeconds 300 -Quiet
$targets = @(Get-YcTargetEditionsFromDism -Lines ($tgt.StdOut -split "`r?`n"))

Write-YcLog ''
if ($targets.Count -eq 0) {
    Write-YcLog 'This image offers NO target editions.' 'WARN'
    Write-YcLog 'Either it is already at the top of its edition family, or the licence files for any higher' 'WARN'
    Write-YcLog 'edition are simply not present in this media. Neither is fixable in place - a clean install is' 'WARN'
    Write-YcLog 'the only route to a different edition.' 'WARN'
} else {
    Write-YcLog 'Editions this image can be converted to:' 'OK'
    foreach ($t in $targets) {
        $gvlkName = Get-YcEditionNameForGvlk -EditionId $t
        $gvlk = ''
        if ($gvlkName) { $gvlk = Get-YcGvlkForEdition -Build $facts.Build -Edition $gvlkName }
        $note = ''
        if ($gvlk) { $note = '   published GVLK: ' + $gvlk }
        elseif ($gvlkName) { $note = '   (no published GVLK for ' + $gvlkName + ' on Server ' + $facts.Version + ' - supply -ProductKey)' }
        Write-YcLog ('    ' + $t.PadRight(24) + $note)
    }
}

if ($facts.IsCore) {
    Write-YcLog ''
    Write-YcLog 'This is a Server Core installation. Microsoft: "you can''t convert between Server Core and Server' 'WARN'
    Write-YcLog 'with Desktop Experience after installation. You''ll need to do a clean installation". Any target' 'WARN'
    Write-YcLog 'above is a Core target and stays Core. Since Windows Server 2016, Standard Core Evaluation can' 'WARN'
    Write-YcLog 'only become Datacenter Core - never Standard Core.' 'WARN'
}

if ($List -or -not $TargetEdition) {
    Write-YcLog ''
    if (-not $TargetEdition -and -not $List) {
        Write-YcLog 'No -TargetEdition given, so nothing was changed. Pick one of the targets above and re-run:' 'WARN'
        Write-YcLog ('    convert-edition -TargetEdition <edition>') 'WARN'
    } else {
        Write-YcLog 'List only - nothing was changed.' 'OK'
    }
    exit 0
}

# --- validate the requested target against the live list --------------------

$v = Test-YcEditionTargetValid -Requested $TargetEdition -Available $targets
if (-not $v.Valid) {
    Write-YcLog ''
    Write-YcLog ('REFUSED: ' + $v.Reason) 'FAIL'
    exit 4
}
$target = $v.Match

# --- decide which key DISM gets ---------------------------------------------

$dismKey = ''
$dismKeyIsGvlk = $false
if ($ProductKey) {
    if (-not (Test-YcProductKeyFormat -Key $ProductKey)) {
        Write-YcLog '-ProductKey is not a well-formed XXXXX-XXXXX-XXXXX-XXXXX-XXXXX key.' 'FAIL'
        exit 5
    }
    $dismKey = $ProductKey.Trim().ToUpperInvariant()
    $dismKeyIsGvlk = Test-YcIsPublishedGvlk -Key $dismKey
    if (-not $dismKeyIsGvlk) {
        Write-YcLog 'Using the key you supplied. Be aware DISM commonly rejects MAK/CSP/volume keys here with' 'WARN'
        Write-YcLog 'error 1168. If that happens, re-run without -ProductKey to use the published GVLK instead.' 'WARN'
    }
} else {
    $gvlkName = Get-YcEditionNameForGvlk -EditionId $target
    if (-not $gvlkName) {
        Write-YcLog ('Cannot map edition ID "' + $target + '" to a GVLK edition name. Supply -ProductKey explicitly.') 'FAIL'
        exit 5
    }
    $dismKey = Get-YcGvlkForEdition -Build $facts.Build -Edition $gvlkName
    if (-not $dismKey) {
        Write-YcLog ('No Microsoft-published GVLK exists for ' + $gvlkName + ' on Windows Server ' + $facts.Version + '. Supply -ProductKey.') 'FAIL'
        exit 5
    }
    $dismKeyIsGvlk = $true
}

$dismArgs = @('/Online', '/English', ('/Set-Edition:' + $target), ('/ProductKey:' + $dismKey), '/AcceptEula', '/NoRestart')
$shownArgs = @('/Online', '/English', ('/Set-Edition:' + $target), ('/ProductKey:' + (Get-YcMaskedKey -Key $dismKey -AllowGvlk:$dismKeyIsGvlk)), '/AcceptEula', '/NoRestart')

Write-YcLog ''
Write-YcLog '--- about to convert ---' 'STEP'
Write-YcLog ('from : ' + $currentEdition)
Write-YcLog ('to   : ' + $target)
Write-YcLog ('key  : ' + (Get-YcMaskedKey -Key $dismKey -AllowGvlk:$dismKeyIsGvlk) + $(if ($dismKeyIsGvlk) { '   (Microsoft-published GVLK - changes the edition, is NOT a licence)' } else { '   (your key)' }))
Write-YcLog ('cmd  : dism.exe ' + ($shownArgs -join ' '))
Write-YcLog ''
Write-YcLog 'THIS IS IRREVERSIBLE. Windows cannot be moved to a lower edition, and /Set-Edition cannot be' 'WARN'
Write-YcLog 'run again on an image that has already been converted. It needs TWO reboots to complete.' 'WARN'

if (-not $Force -and -not $WhatIfPreference) {
    $answer = Read-Host ('Type the target edition name to confirm (' + $target + ')')
    if ($answer.Trim().ToLowerInvariant() -ne $target.ToLowerInvariant()) {
        Write-YcLog 'Confirmation did not match. Nothing was changed.' 'WARN'
        exit 6
    }
}

if (-not $PSCmdlet.ShouldProcess($env:COMPUTERNAME, ('DISM /Set-Edition:' + $target))) {
    Write-YcLog 'WhatIf: nothing was changed.' 'OK'
    exit 0
}

Write-YcLog 'running DISM - this takes several minutes and must not be interrupted' 'STEP'
$r = Invoke-YcProcess -FilePath 'dism.exe' -Arguments $dismArgs -TimeoutSeconds 3600 -Quiet
Write-YcLog ($r.StdOut.Trim())
if ($r.StdErr.Trim()) { Write-YcLog ($r.StdErr.Trim()) 'WARN' }
Write-YcLog ('DISM exit code: ' + $r.ExitCode)

# 3010 is ERROR_SUCCESS_REBOOT_REQUIRED - success, with a pending restart.
if ($r.ExitCode -ne 0 -and $r.ExitCode -ne 3010) {
    $e = Resolve-YcDismEditionError -Text ($r.StdOut + "`n" + $r.StdErr) -ExitCode $r.ExitCode
    Write-YcLog ''
    Write-YcLog 'CONVERSION FAILED' 'FAIL'
    if ($e) {
        Write-YcLog ('cause : ' + $e.Meaning) 'FAIL'
        Write-YcLog ('fix   : ' + $e.Fix) 'WARN'
        Write-YcLog ('source: ' + $e.Url)
    } else {
        Write-YcLog 'This failure is not in the toolkit table. Read C:\Windows\Logs\DISM\dism.log for the real cause.' 'WARN'
    }
    exit 7
}

Write-YcLog ''
Write-YcLog ('Edition change staged: ' + $currentEdition + ' -> ' + $target) 'OK'
Write-YcLog 'NEXT STEPS - the conversion is not finished until these are done:' 'WARN'
Write-YcLog '  1. Reboot. Then reboot a SECOND time. Microsoft''s procedure restarts twice.' 'WARN'
if ($dismKeyIsGvlk) {
    Write-YcLog '  2. The machine is now on a published GVLK, which is not a licence. Either:' 'WARN'
    Write-YcLog '       - activate against your own KMS host or AD activation object:' 'WARN'
    Write-YcLog '           activate-windows' 'WARN'
    Write-YcLog '       - or install your real key:' 'WARN'
    Write-YcLog '           activate-windows -ProductKey <key from VLSC or your CSP>' 'WARN'
} else {
    Write-YcLog '  2. Activate:  activate-windows -Help   (then -Method MAK if it is not licensed)' 'WARN'
}

if ($AllowReboot) {
    Write-YcLog 'restarting now (-AllowReboot). Remember the SECOND reboot afterwards.' 'WARN'
    if ($PSCmdlet.ShouldProcess($env:COMPUTERNAME, 'Restart-Computer')) { Restart-Computer -Force }
}

exit 0
