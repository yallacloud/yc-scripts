$ErrorActionPreference='SilentlyContinue'
$log="C:\Scripts\disk-guard.log"; function L($m){ "$(Get-Date -f 'yyyy-MM-dd HH:mm:ss')  $m" | Out-File -Append $log -Encoding ascii }
foreach($d in (Get-Volume | Where-Object { $_.DriveLetter -and $_.FileSystem -eq 'NTFS' } | ForEach-Object { $_.DriveLetter })){
  if((cmd /c "fsutil dirty query ${d}:") -match 'is Dirty'){ L "${d}: DIRTY -> chkdsk /spotfix"; cmd /c "echo Y| chkdsk ${d}: /spotfix" | Out-Null }
  else { L "${d}: online /scan"; cmd /c "chkdsk ${d}: /scan" | Out-Null }
}
