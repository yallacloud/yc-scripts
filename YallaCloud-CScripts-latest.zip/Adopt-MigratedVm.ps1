param(
  # What to do. -Report changes NOTHING and is the default, because the first thing you do to
  # a machine holding production data is look at it.
  [switch]$Report,
  [switch]$Run,
  [switch]$Status,
  [switch]$Resume,          # internal: the reboot-resume task calls this
  # Phases. -Only takes the names in $AllPhases; -Skip removes them.
  [string[]]$Only,
  [string[]]$Skip,
  [switch]$AllowReboot,     # reboot immediately when a prerequisite demands it
  [switch]$Force,           # proceed past a GATE finding. Says what it is overriding.
  [string]$Url    = 'https://raw.githubusercontent.com/yallacloud/yc-scripts/main/YallaCloud-CScripts-latest.zip',
  [string]$ShaUrl = 'https://raw.githubusercontent.com/yallacloud/yc-scripts/main/YallaCloud-CScripts-latest.sha256',
  [string]$ScriptsDir = 'C:\Scripts',
  [string]$BackupDir,       # SQL backup root. Omitted: let backup-sql decide (Ola's dir, or its default)
  [switch]$Help
)
# ================================================================================================
# Adopt-MigratedVm.ps1 - YALLACLOUD: bring a MIGRATED VM up to the same day-2 standard as a VM we
# built ourselves. Windows PowerShell 5.1 only. ASCII only. Server 2016-2025.
#
# WHY THIS EXISTS
#   A fresh VM gets the whole toolkit because WE built it: cloudbase-init runs the userdata on
#   first boot, the userdata pulls C:\Scripts, and Yc-VmBuild.ps1 walks a state machine to a
#   reported, monitored, backed-up machine.
#   A migrated VM gets NONE of that, because the chain has no first link - no cloudbase-init (or
#   one still pointed at OpenStack), nothing baked in before sealing, no C:\Scripts, no
#   Chocolatey. This script is that first link, and nothing more: after it runs once, the machine
#   is on exactly the same payload channel as every fresh VM, forever.
#
# THE GOVERNING DIFFERENCE - construct vs adopt
#   A fresh deploy CONSTRUCTS: it owns the machine, nothing is lost on failure, and install-sql is
#   correct because there is no SQL yet.
#   A migration ADOPTS: somebody else built it, it holds production data, there is no redeploy, and
#   install-sql would be DESTRUCTIVE. Same outcome, opposite assumptions.
#
#   Every action here obeys four rules:
#     1. SURVEY BEFORE TOUCH      - no change without a recorded prior state.
#     2. ADDITIVE, NEVER DESTRUCTIVE - add a rule, never flush the set. Add a task only if absent.
#     3. REVERSIBLE, UNDO RECORDED FIRST - written before the change, not after.
#     4. PROVE IT CHANGED NOTHING ELSE - the post-survey diffs against the pre-survey.
#   Anything that cannot satisfy all four is FLAGGED FOR A HUMAN, not automated.
#
# THE BOOTSTRAP PROBLEM, AND WHY THIS FILE IS SELF-CONTAINED
#   Update-YcScripts.ps1 cannot bootstrap itself - it lives inside the payload it fetches. A fresh
#   VM has it baked in before sealing; a migrated VM has nothing. So this script carries its own
#   minimal logger and its own verified download, and only dot-sources C:\Scripts\_yc-lib.ps1
#   AFTER the payload is on disk. Calling the house library before SYNC would fail on exactly the
#   machines this script exists for.
#
# WHAT IT DELIBERATELY DOES NOT DO
#   * install-sql           - destructive on a migrated SQL box. Structurally unreachable here.
#   * activate-windows      - migration changes the MAC, so activation often drops. Re-licensing a
#                             customer VM onto our volume agreement is a COMMERCIAL decision, and
#                             an OEM or retail box must never be silently converted. REPORT ONLY.
#   * install Ola Hallengren - backup-sql already uses dbo.DatabaseBackup when it exists and falls
#                             back to native verified T-SQL BACKUP when it does not, so we add no
#                             objects to a database server we did not build.
#   * remove anything it cannot positively identify - flagged, skipped.
#
# EXIT CODES
#   0  every requested phase completed
#   1  a reboot is required; the resume task is registered. Reboot, and it continues by itself.
#   2  REFUSED at the gate (use -Force only when you know what you are overriding)
#   3  PARTIAL - completed, but one or more phases were flagged for a human
#   4  payload sha256 mismatch (nothing was installed; Update-YcScripts rolls back)
#   5  not elevated
#   6  no HTTPS egress to the payload host, so the toolkit cannot be fetched
#
# LOG   C:\Scripts\adopt-migrated-vm.log        STATE  C:\Scripts\adopt-migrated-vm.state.json
# SURVEY C:\Scripts\survey\<host>-<stamp>.json  MARKER C:\ProgramData\YallaCloud\adopted.json
# ================================================================================================

$ErrorActionPreference = 'Continue'
$script:Tag      = 'adopt-migrated-vm'
$script:LogPath  = Join-Path $ScriptsDir 'adopt-migrated-vm.log'
$script:StatePath= Join-Path $ScriptsDir 'adopt-migrated-vm.state.json'
$script:MarkerDir= 'C:\ProgramData\YallaCloud'
$script:Marker   = Join-Path $script:MarkerDir 'adopted.json'
$script:ResumeTask = 'YC-AdoptResume'
$script:Flags    = New-Object System.Collections.Generic.List[string]
$script:Done     = New-Object System.Collections.Generic.List[string]
$script:LibOK    = $false

$AllPhases = @('SURVEY','PREREQ','BOOTSTRAP','SYNC','PATH','NIC','SQL','SQLBACKUP','TASKS','NOTIFY','VERIFY')

# ------------------------------------------------------------------------------------------------
# Minimal logger. Deliberately NOT the house library: this runs before C:\Scripts exists. Once SYNC
# has landed the payload, Main dot-sources it and swaps in the real Write-YcLog so the log line format, the
# secret redaction and the Application event log entries match every other command on the fleet.
# ------------------------------------------------------------------------------------------------
function L {
  param([string]$Message,[string]$Level='INFO')
  if ($script:LibOK -and (Get-Command Write-YcLog -ErrorAction SilentlyContinue)) {
    Write-YcLog $Message $Level
    return
  }
  $line = ('{0}  {1}  [YALLACLOUD][{2}] [{3}] {4}' -f `
           (Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK'), $env:COMPUTERNAME, $script:Tag, $Level, $Message)
  switch ($Level) {
    'ERROR' { Write-Host $line -ForegroundColor Red }
    'WARN'  { Write-Host $line -ForegroundColor Yellow }
    'OK'    { Write-Host $line -ForegroundColor Green }
    'FLAG'  { Write-Host $line -ForegroundColor Magenta }
    default { Write-Host $line }
  }
  try {
    if (-not (Test-Path -LiteralPath $ScriptsDir)) { New-Item -ItemType Directory -Path $ScriptsDir -Force | Out-Null }
    Add-Content -LiteralPath $script:LogPath -Value $line -Encoding Ascii -ErrorAction SilentlyContinue
  } catch {}
}

# A FLAG is the whole point of the adopt posture: something a human must decide, recorded in the
# log, the state file and the final summary, without stopping the phases that are safe to run.
function Flag { param([string]$Phase,[string]$What)
  $script:Flags.Add(($Phase + ': ' + $What)) | Out-Null
  L ('FLAG [' + $Phase + '] ' + $What) 'FLAG'
}

# The library CANNOT be dot-sourced from inside a function: the definitions land in that
# function's scope and are gone the moment it returns. The first version of this did exactly
# that - the run logged "house library loaded" and then quietly used the built-in logger for
# every line after it. So this only REPORTS whether the file is there; the dot-source itself
# happens at script scope, in Main, where the definitions survive.
function Test-YcLibraryPresent {
  return (Test-Path -LiteralPath (Join-Path $ScriptsDir '_yc-lib.ps1'))
}

function Test-Elevated {
  try { return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch { return $false }
}

# $env:COMPUTERNAME comes back EMPTY in a detached SYSTEM child - measured on yc-survey, where it
# produced survey files named "-20260915.json". Three sources, first one that answers.
function Get-HostNameSafe {
  foreach ($try in @({ [Environment]::MachineName },
                     { (Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).Name },
                     { $env:COMPUTERNAME })) {
    try { $v = & $try; if ($v) { return [string]$v } } catch {}
  }
  return 'UNKNOWN-HOST'
}

function Save-State {
  param([string]$Phase,[string]$Result)
  $s = @{
    schema    = 'ycadopt.state/1'
    host      = (Get-HostNameSafe)
    updated   = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK')
    lastPhase = $Phase
    result    = $Result
    done      = @($script:Done)
    flags     = @($script:Flags)
  }
  try { $s | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $script:StatePath -Encoding Ascii } catch {}
}

# Run a payload command and report honestly. A command that is not there is NOT a success.
function Invoke-YcCommand {
  param([string]$Script,[string[]]$Arguments=@(),[string]$Phase,[int[]]$OkCodes=@(0))
  $p = Join-Path $ScriptsDir $Script
  if (-not (Test-Path -LiteralPath $p)) {
    Flag $Phase ($Script + ' is not in ' + $ScriptsDir + ' - the payload is incomplete, so this step did not run.')
    return $null
  }
  L ('run: ' + $Script + ' ' + ($Arguments -join ' '))
  $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$p) + $Arguments
  try {
    $proc = Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Wait -PassThru -NoNewWindow
    $code = $proc.ExitCode
  } catch { Flag $Phase ($Script + ' could not be started: ' + $_.Exception.Message); return $null }
  if ($OkCodes -contains $code) { L ($Script + ' exit=' + $code) 'OK' }
  else { Flag $Phase ($Script + ' exit=' + $code + ' - see C:\Scripts\' + [IO.Path]::GetFileNameWithoutExtension($Script).ToLower() + '.log') }
  return $code
}

# ================================================================================================
# PHASE 1 - SURVEY.  Read-only. Changes nothing. Nothing else may run until this has.
# It is also the ROLLBACK BASELINE for rule 4: VERIFY diffs against it.
# ================================================================================================
function Invoke-Survey {
  param([string]$Label='pre')
  $h = Get-HostNameSafe
  $s = [ordered]@{ schema='ycadopt.survey/1'; label=$Label; host=$h
                   collected=(Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK') }

  # Each collector is isolated: one that throws must not cost us the other seven. yc-survey lost a
  # whole run to Win32_PnPSignedDriver timing out, which is why none of these share a try block.
  $collect = [ordered]@{
    identity = {
      $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
      $cs = Get-CimInstance Win32_ComputerSystem  -ErrorAction Stop
      [ordered]@{ caption=$os.Caption; build=$os.BuildNumber; installed=$os.InstallDate
                  firmware=$(if ((Get-CimInstance Win32_ComputerSystem).BootupState -and (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State')) {'UEFI'} else {$(try{ if((bcdedit /enum '{current}' 2>$null) -match 'winload.efi'){'UEFI'}else{'BIOS'} }catch{'unknown'})})
                  domain=$cs.Domain; partOfDomain=$cs.PartOfDomain; manufacturer=$cs.Manufacturer
                  model=$cs.Model; memoryGB=[math]::Round($cs.TotalPhysicalMemory/1GB,1) }
    }
    bootRisk = {
      # The make-or-break item for a VMware -> KVM guest. No virtio = the VM does not boot.
      # MEASURED: Get-CimInstance Win32_SystemDriver took 14.5 SECONDS on a real host - it
      # enumerates and joins every driver on the box. The service registry holds the same
      # answer and returns in milliseconds, so the named drivers are looked up directly.
      $virtio = @()
      foreach ($drv in @('viostor','vioscsi','netkvm','balloon','vioser','viorng','vioinput','viofs','pvpanic')) {
        if (Test-Path -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\' + $drv)) { $virtio += $drv }
      }
      [ordered]@{ virtioDrivers=$virtio; virtioPresent=($virtio.Count -gt 0)
                  vmwareTools=[bool](Get-Service -Name 'VMTools' -ErrorAction SilentlyContinue)
                  qemuGuestAgent=[bool](Get-Service -Name 'QEMU-GA','qemu-ga' -ErrorAction SilentlyContinue)
                  pendingReboot=@(Get-PendingRebootReasonsLocal) }
    }
    network = {
      $cfgs = @(Get-CimInstance Win32_NetworkAdapterConfiguration -ErrorAction SilentlyContinue |
                Where-Object { $_.IPEnabled })
      # Ghost NICs: the classic migration failure. CloudStack hands the clone a new MAC, the old
      # adapter persists as a hidden device still holding the old static IP, and the new IP fails
      # with "already assigned to another adapter".
      $ghosts = 0
      try {
        $all = @(Get-CimInstance Win32_NetworkAdapter -ErrorAction Stop)
        $ghosts = @($all | Where-Object { $_.PNPDeviceID -and -not $_.NetEnabled -and $_.PhysicalAdapter }).Count
      } catch {}
      [ordered]@{ nics=@($cfgs | ForEach-Object {
                    [ordered]@{ desc=$_.Description; mac=$_.MACAddress; ip=@($_.IPAddress)
                                gateway=@($_.DefaultIPGateway); dns=@($_.DNSServerSearchOrder)
                                dhcp=$_.DHCPEnabled; dhcpServer=$_.DHCPServer } })
                  hiddenAdapterCount=$ghosts }
    }
    inherited = {
      # What someone else put here. We must not flatten any of it.
      $tasks = @()
      try { $tasks = @(Get-ScheduledTask -ErrorAction Stop |
              Where-Object { $_.TaskPath -notmatch '^\\Microsoft\\' } |
              ForEach-Object { $_.TaskName }) } catch {}
      $cbi = Get-Service -Name 'cloudbase-init' -ErrorAction SilentlyContinue
      $cbiCloud = ''
      foreach ($c in @('C:\Program Files\Cloudbase Solutions\Cloudbase-Init\conf\cloudbase-init.conf')) {
        if (Test-Path -LiteralPath $c) {
          $txt = Get-Content -LiteralPath $c -Raw -ErrorAction SilentlyContinue
          if ($txt -match '(?im)^\s*metadata_services\s*=\s*(.+)$') { $cbiCloud = $Matches[1].Trim() }
        }
      }
      [ordered]@{ nonMicrosoftTasks=$tasks
                  cloudbaseInit=$(if ($cbi) { $cbi.Status.ToString() } else { 'absent' })
                  cloudbaseInitMetadataServices=$cbiCloud
                  backupAgents=@(Get-BackupAgentServicesLocal)
                  antivirus=@(Get-AntivirusLocal) }
    }
    sql = { @(Get-SqlInstancesLocal) }
    capacity = {
      @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction SilentlyContinue |
        ForEach-Object { [ordered]@{ drive=$_.DeviceID; sizeGB=[math]::Round($_.Size/1GB,1)
                                     freeGB=[math]::Round($_.FreeSpace/1GB,1) } })
    }
    us = {
      $cnt = 0
      if (Test-Path -LiteralPath $ScriptsDir) { $cnt = @(Get-ChildItem -LiteralPath $ScriptsDir -File -ErrorAction SilentlyContinue).Count }
      $ver = ''
      $vf = Join-Path $ScriptsDir 'yc-payload-version.txt'
      if (Test-Path -LiteralPath $vf) { $ver = ((Get-Content -LiteralPath $vf -TotalCount 1) -replace '^[^=]*=\s*','').Trim() }
      $ycTasks = @()
      try { $ycTasks = @(Get-ScheduledTask -ErrorAction Stop | Where-Object { $_.TaskName -match '^(YC|GI)' } | ForEach-Object { $_.TaskName }) } catch {}
      [ordered]@{ scriptsDir=$ScriptsDir; fileCount=$cnt; payloadVersion=$ver; ycTasks=$ycTasks
                  onPath=(Test-ScriptsOnPathLocal) }
    }
  }

  foreach ($k in $collect.Keys) {
    $t0 = Get-Date
    try { $s[$k] = & $collect[$k] }
    catch { $s[$k] = @{ error = $_.Exception.Message }; L ('survey collector ' + $k + ' failed: ' + $_.Exception.Message) 'WARN' }
    $ms = [int]((Get-Date) - $t0).TotalMilliseconds
    L ('survey ' + $k + ' ' + $ms + 'ms')
  }

  $dir = Join-Path $ScriptsDir 'survey'
  if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  $file = Join-Path $dir ($h + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $Label + '.json')
  try { $s | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $file -Encoding Ascii
        L ('survey written: ' + $file) 'OK' }
  catch { L ('could not write the survey: ' + $_.Exception.Message) 'ERROR' }
  return @{ data = $s; path = $file }
}

function Get-PendingRebootReasonsLocal {
  # The house library has Get-YcPendingRebootReasons, but SURVEY runs BEFORE the payload exists.
  # Same checks, so the two agree; once the library is loaded the library's copy is used.
  if ($script:LibOK -and (Get-Command Get-YcPendingRebootReasons -ErrorAction SilentlyContinue)) {
    return @(Get-YcPendingRebootReasons)
  }
  $r = New-Object System.Collections.Generic.List[string]
  if (Test-Path -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $r.Add('Component Based Servicing') | Out-Null }
  if (Test-Path -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $r.Add('Windows Update') | Out-Null }
  $pfro = $null
  try { $pfro = (Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction Stop).PendingFileRenameOperations } catch {}
  if ($pfro) { $r.Add('PendingFileRenameOperations') | Out-Null }
  try { if ((Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName' -Name ComputerName -ErrorAction Stop).ComputerName -ne
             (Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName' -Name ComputerName -ErrorAction Stop).ComputerName) {
          $r.Add('pending computer rename') | Out-Null } } catch {}
  return @($r)
}

function Test-ScriptsOnPathLocal {
  $p = [Environment]::GetEnvironmentVariable('Path','Machine')
  return ([string]$p -split ';' | Where-Object { $_.TrimEnd('\') -ieq $ScriptsDir.TrimEnd('\') }).Count -gt 0
}

function Get-BackupAgentServicesLocal {
  # Named, not guessed. A service we cannot identify is reported as-is, never acted on.
  $known = @{
    'AcronisAgent'='Acronis'; 'acrocmd'='Acronis'; 'VeeamEndpointBackupSvc'='Veeam Agent'
    'VeeamBackupSvc'='Veeam B&R'; 'VSSPROV'='Veeam'; 'BackupExecAgentAccelerator'='Veritas Backup Exec'
    'BackupExecRPCService'='Veritas Backup Exec'; 'NetBackup Client Service'='Veritas NetBackup'
    'CommvaultCommServe'='Commvault'; 'GxCVD(Instance001)'='Commvault'; 'cvd'='Commvault'
    'sdrsvc'='Windows Server Backup'; 'AcrSch2Svc'='Acronis Scheduler'
    'MSSQLSERVER_BACKUP'='unknown-sql-backup'; 'RvSrv'='Redstor'; 'bacula-fd'='Bacula'
    'SQLBackupAgent'='Redgate SQL Backup'; 'IDERAService'='Idera SQL Safe'
  }
  $out = @()
  foreach ($n in $known.Keys) {
    $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
    if ($svc) { $out += [ordered]@{ service=$svc.Name; product=$known[$n]; status=$svc.Status.ToString() } }
  }
  return $out
}

function Get-AntivirusLocal {
  try {
    @(Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop |
      ForEach-Object { $_.displayName })
  } catch { @() }
}

# ================================================================================================
# SQL discovery.  Version, edition, licensed state, and the LAST FIVE characters of the key -
# which is all Windows itself publishes (PartialProductKey). A full product key is never read,
# never logged and never printed, here or anywhere else in this payload.
# ================================================================================================
function Get-SqlInstancesLocal {
  $out = @()
  $root = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL'
  if (-not (Test-Path -LiteralPath $root)) { return $out }
  $names = $null
  try { $names = Get-ItemProperty -LiteralPath $root -ErrorAction Stop } catch { return $out }
  foreach ($p in $names.PSObject.Properties) {
    if ($p.Name -match '^PS') { continue }
    $inst = $p.Name
    $key  = $p.Value          # e.g. MSSQL16.MSSQLSERVER
    $rec  = [ordered]@{ instance=$inst; regKey=$key; service=$(if ($inst -eq 'MSSQLSERVER') { 'MSSQLSERVER' } else { 'MSSQL$' + $inst }) }
    $setup = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\' + $key + '\Setup'
    foreach ($f in @('Edition','Version','PatchLevel','SQLPath')) {
      $v = $null
      try { $v = (Get-ItemProperty -LiteralPath $setup -Name $f -ErrorAction Stop).$f } catch {}
      $rec[$f.ToLower()] = [string]$v
    }
    $svc = Get-Service -Name $rec.service -ErrorAction SilentlyContinue
    $rec['status'] = $(if ($svc) { $svc.Status.ToString() } else { 'absent' })
    # Evaluation is NOT an edition on the upgrade ladder - it is a time bomb, so it is called out
    # separately rather than folded into "edition".
    $rec['isEvaluation'] = ([string]$rec.edition -match '(?i)evaluation')
    $rec['isExpress']    = ([string]$rec.edition -match '(?i)express')
    # Ask the engine itself when it is running - the registry records what was INSTALLED, which is
    # not the same as what the engine reports after an edition upgrade.
    if ($rec.status -eq 'Running') {
      $t = $(if ($inst -eq 'MSSQLSERVER') { '.' } else { '.\' + $inst })
      $q = "SET NOCOUNT ON; SELECT CONVERT(varchar(128),SERVERPROPERTY('Edition')) + '|' + " +
           "CONVERT(varchar(128),SERVERPROPERTY('ProductVersion')) + '|' + " +
           "CONVERT(varchar(128),SERVERPROPERTY('ProductLevel')) + '|' + " +
           "ISNULL(CONVERT(varchar(128),SERVERPROPERTY('ProductUpdateLevel')),'') + '|' + " +
           "CONVERT(varchar(32),SERVERPROPERTY('IsIntegratedSecurityOnly'));"
      $r = Invoke-SqlCmdLocal -Target $t -Query $q
      if ($r) {
        $f = $r -split '\|'
        if ($f.Count -ge 3) {
          $rec['liveEdition']=$f[0].Trim(); $rec['liveVersion']=$f[1].Trim(); $rec['liveLevel']=$f[2].Trim()
          if ($f.Count -ge 4) { $rec['liveUpdateLevel']=$f[3].Trim() }
          $rec['isEvaluation'] = ($f[0] -match '(?i)evaluation')
        }
      }
      $rec['databases'] = @(Get-SqlDatabasesLocal -Target $t)
      $rec['foreignBackupHistoryDays'] = (Get-ForeignBackupHistoryDaysLocal -Target $t)
    } else { $rec['databases'] = @(); $rec['foreignBackupHistoryDays'] = -1 }
    # Last five characters of the key, from Windows' own published value. Never more than that.
    $rec['partialProductKey'] = (Get-SqlPartialKeyLocal -RegKey $key)
    $out += $rec
  }
  return $out
}

function Get-SqlPartialKeyLocal {
  param([string]$RegKey)
  # SQL does not publish a PartialProductKey the way Windows does. The DigitalProductID under the
  # instance's Setup key is the only local source, and decoding it would mean reconstructing a full
  # product key - which this payload must never do. So: report whether one is present, nothing more,
  # and let licence-report (which reads Windows' own published partial) carry the five characters
  # for Windows. Saying "present" honestly beats printing five characters we had to derive.
  foreach ($p in @(('HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\' + $RegKey + '\Setup'))) {
    try {
      $v = (Get-ItemProperty -LiteralPath $p -Name DigitalProductID -ErrorAction Stop).DigitalProductID
      if ($v) { return 'present (not decoded - this payload never reconstructs a product key)' }
    } catch {}
  }
  return '(none recorded)'
}

function Get-SqlCmdPathLocal {
  if ($script:SqlCmdPath) { return $script:SqlCmdPath }
  $c = Get-Command sqlcmd.exe -ErrorAction SilentlyContinue
  if ($c) { $script:SqlCmdPath = $c.Source; return $script:SqlCmdPath }
  foreach ($g in @('C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\*\Tools\Binn\sqlcmd.exe',
                   'C:\Program Files\Microsoft SQL Server\*\Tools\Binn\sqlcmd.exe')) {
    $f = @(Get-ChildItem -Path $g -ErrorAction SilentlyContinue | Sort-Object FullName -Descending)
    if ($f.Count) { $script:SqlCmdPath = $f[0].FullName; return $script:SqlCmdPath }
  }
  return $null
}

function Invoke-SqlCmdLocal {
  param([string]$Target,[string]$Query)
  $exe = Get-SqlCmdPathLocal
  if (-not $exe) { return $null }
  try {
    $o = & $exe -S $Target -E -b -h -1 -W -Q $Query 2>&1
    if ($LASTEXITCODE -ne 0) { return $null }
    return (($o | Where-Object { $_ -and ($_ -notmatch '^\s*$') }) -join "`n").Trim()
  } catch { return $null }
}

function Get-SqlDatabasesLocal {
  param([string]$Target)
  $q = "SET NOCOUNT ON; SELECT name + '|' + recovery_model_desc + '|' + state_desc + '|' + " +
       "CONVERT(varchar(20), CAST((SELECT SUM(size)*8.0/1024 FROM sys.master_files WHERE database_id = d.database_id) AS decimal(18,1))) " +
       "FROM sys.databases d WHERE database_id > 4 AND state = 0;"
  $r = Invoke-SqlCmdLocal -Target $Target -Query $q
  if (-not $r) { return @() }
  @($r -split "`n" | ForEach-Object {
      $f = $_ -split '\|'
      if ($f.Count -ge 4) { [ordered]@{ name=$f[0].Trim(); recovery=$f[1].Trim(); state=$f[2].Trim(); sizeMB=$f[3].Trim() } }
    } | Where-Object { $_ })
}

# Is somebody else already backing this instance up? Two backup systems on one database is worse
# than one: each truncates the other's log chain and neither restore is then trustworthy.
# msdb.dbo.backupset is the only honest source - it records every backup whoever took it.
function Get-ForeignBackupHistoryDaysLocal {
  param([string]$Target)
  $q = "SET NOCOUNT ON; SELECT ISNULL(CONVERT(varchar(20), DATEDIFF(day, MAX(backup_finish_date), GETDATE())), '-1') " +
       "FROM msdb.dbo.backupset WHERE backup_finish_date IS NOT NULL;"
  $r = Invoke-SqlCmdLocal -Target $Target -Query $q
  if (-not $r) { return -1 }
  $n = -1; [void][int]::TryParse(($r -replace '[^0-9-]',''), [ref]$n)
  return $n
}

# ================================================================================================
# PHASE 2 - PREREQ.  Admin, PowerShell 5.1, TLS 1.2, egress, free space, and the one that decides
# whether this run can finish today: a PENDING REBOOT.
#
# A migrated guest very often arrives mid-reboot - Windows Update staged on the source, a rename
# half-applied by the migration, file renames queued. Installing on top of that is how you get a
# half-patched box that reports success. So: if a reboot is pending, register a resume task, say
# so, and stop at exit 1. With -AllowReboot it restarts immediately and continues by itself.
# ================================================================================================
function Invoke-Prereq {
  $ok = $true

  if (-not (Test-Elevated)) { L 'not elevated - run this from an administrator session.' 'ERROR'; return 5 }
  L 'elevation: administrator' 'OK'

  $psv = $PSVersionTable.PSVersion
  L ('PowerShell ' + $psv.ToString())
  if ($psv.Major -lt 5) { Flag 'PREREQ' ('Windows PowerShell ' + $psv + ' - this payload needs 5.1. Nothing here will work until that is fixed.'); $ok = $false }
  if ($psv.Major -ge 6) { Flag 'PREREQ' ('running under PowerShell ' + $psv + '. The payload is written for Windows PowerShell 5.1; re-run with powershell.exe, not pwsh.exe.'); $ok = $false }

  # Server 2016 .NET defaults to TLS 1.0, so every HTTPS call fails while the network is fine.
  try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; L 'TLS 1.2 enabled for this session' 'OK' }
  catch { Flag 'PREREQ' 'could not select TLS 1.2 for this session.'; $ok = $false }

  $free = 0
  try { $free = [math]::Round((Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'").FreeSpace/1GB,1) } catch {}
  L ('free space on C: ' + $free + ' GB')
  if ($free -gt 0 -and $free -lt 2) { Flag 'PREREQ' ('only ' + $free + ' GB free on C: - the payload and its logs need room.') }

  $egress = Test-PayloadEgress
  if (-not $egress) {
    L 'no HTTPS egress to raw.githubusercontent.com:443 - the toolkit cannot be fetched.' 'ERROR'
    return 6
  }
  L 'HTTPS egress to the payload host: reachable' 'OK'

  $reasons = @(Get-PendingRebootReasonsLocal)
  if ($reasons.Count -gt 0) {
    L ('a reboot is PENDING: ' + ($reasons -join ', ')) 'WARN'
    Register-ResumeTask
    if ($AllowReboot) {
      L 'rebooting now; YC-AdoptResume will continue this run automatically at startup.' 'WARN'
      Save-State 'PREREQ' 'reboot-requested'
      try { Restart-Computer -Force } catch { L ('reboot failed: ' + $_.Exception.Message) 'ERROR' }
      return 1
    }
    L 'STOPPING so a human picks the moment. Reboot this machine and the run continues by itself.' 'WARN'
    L 'To let it reboot on its own next time, pass -AllowReboot.'
    Save-State 'PREREQ' 'reboot-required'
    return 1
  }
  L 'no pending reboot' 'OK'
  if (-not $ok) { return 2 }
  return 0
}

function Test-PayloadEgress {
  $hostName = ([Uri]$Url).Host
  try {
    $r = Test-NetConnection -ComputerName $hostName -Port 443 -WarningAction SilentlyContinue -ErrorAction Stop
    if ($r.TcpTestSucceeded) { return $true }
  } catch {}
  # Test-NetConnection is absent or slow on some builds; TcpClient with a real ceiling is the
  # fallback. 8 seconds, because a boot-time script must never hang.
  try {
    $c = New-Object Net.Sockets.TcpClient
    $ia = $c.BeginConnect($hostName, 443, $null, $null)
    $ok = $ia.AsyncWaitHandle.WaitOne(8000, $false)
    $c.Close()
    return $ok
  } catch { return $false }
}

# The resume task is how a reboot stops being a dead end. It is removed by the run that completes,
# so it can never become a task that fires forever doing nothing - the failure shape that bit
# report-inventory once already.
function Register-ResumeTask {
  $self = $PSCommandPath
  if (-not $self) { $self = Join-Path $ScriptsDir 'Adopt-MigratedVm.ps1' }
  $args = '-NoProfile -ExecutionPolicy Bypass -File "' + $self + '" -Resume'
  if ($AllowReboot) { $args += ' -AllowReboot' }
  if ($Force)       { $args += ' -Force' }
  try {
    $act = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $args
    $trg = New-ScheduledTaskTrigger -AtStartup
    $pri = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
             -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 2)
    Register-ScheduledTask -TaskName $script:ResumeTask -Action $act -Trigger $trg -Principal $pri `
      -Settings $set -Force | Out-Null
    # Read it back. "Registered without error" is not the same as "the task is there".
    if (Get-ScheduledTask -TaskName $script:ResumeTask -ErrorAction SilentlyContinue) {
      L ($script:ResumeTask + ' registered (at startup, SYSTEM) - existence confirmed.') 'OK'
    } else { Flag 'PREREQ' 'Register-ScheduledTask returned without error but YC-AdoptResume is not there. A reboot will NOT continue this run.' }
  } catch { Flag 'PREREQ' ('could not register ' + $script:ResumeTask + ': ' + $_.Exception.Message) }
}

function Unregister-ResumeTask {
  try {
    if (Get-ScheduledTask -TaskName $script:ResumeTask -ErrorAction SilentlyContinue) {
      Unregister-ScheduledTask -TaskName $script:ResumeTask -Confirm:$false
      L ($script:ResumeTask + ' removed - the run completed, so there is nothing left to resume.') 'OK'
    }
  } catch { L ('could not remove ' + $script:ResumeTask + ': ' + $_.Exception.Message) 'WARN' }
}

# ================================================================================================
# PHASE 3 - BOOTSTRAP.  The ONE genuinely new download path in the whole estate.
# Update-YcScripts.ps1 cannot bootstrap itself - it lives inside the payload it fetches. This
# fetches the zip and its sidecar, VERIFIES THE HASH BEFORE EXTRACTING ANYTHING, and takes exactly
# one file out: Update-YcScripts.ps1. From the next phase on, this machine is on the same channel
# as every fresh VM and this code never runs again.
# ================================================================================================
function Invoke-Bootstrap {
  $upd = Join-Path $ScriptsDir 'Update-YcScripts.ps1'
  if (Test-Path -LiteralPath $upd) { L 'Update-YcScripts.ps1 is already present - bootstrap not needed.' 'OK'; return 0 }

  if (-not (Test-Path -LiteralPath $ScriptsDir)) { New-Item -ItemType Directory -Path $ScriptsDir -Force | Out-Null }
  $tmp = Join-Path $env:TEMP ('yc-bootstrap-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  $zip = Join-Path $tmp 'payload.zip'
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    L ('downloading ' + $Url)
    Invoke-WebRequest -Uri $Url -OutFile $zip -UseBasicParsing -ErrorAction Stop
    L ('downloading ' + $ShaUrl)
    $sidecar = (Invoke-WebRequest -Uri $ShaUrl -UseBasicParsing -ErrorAction Stop).Content
  } catch {
    L ('bootstrap download failed: ' + $_.Exception.Message) 'ERROR'
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    return 6
  }

  $want = ([string]$sidecar -split '\s+')[0].Trim().ToUpper()
  $got  = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToUpper()
  if (-not $want -or $want -ne $got) {
    L ('sha256 MISMATCH - expected ' + $want + ' got ' + $got + '. NOTHING was extracted.') 'ERROR'
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    return 4
  }
  L ('sha256 verified: ' + $got) 'OK'

  # Exactly one file. The rest of the payload arrives through Update-YcScripts, which is the only
  # thing allowed to write C:\Scripts wholesale.
  try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $z = [IO.Compression.ZipFile]::OpenRead($zip)
    try {
      $e = $z.Entries | Where-Object { $_.Name -eq 'Update-YcScripts.ps1' } | Select-Object -First 1
      if (-not $e) { L 'Update-YcScripts.ps1 is not inside the payload zip.' 'ERROR'; return 4 }
      [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $upd, $true)
    } finally { $z.Dispose() }
    L ('extracted Update-YcScripts.ps1 -> ' + $upd) 'OK'
  } catch {
    L ('extract failed: ' + $_.Exception.Message) 'ERROR'
    return 4
  } finally { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
  return 0
}

# ================================================================================================
# PHASE 4 - SYNC.  Hand over to the real payload channel. Exit 4 and 7 mean it ROLLED BACK, not
# that it half-updated - that distinction is why those two codes exist.
# ================================================================================================
function Invoke-Sync {
  $code = Invoke-YcCommand -Script 'Update-YcScripts.ps1' -Arguments @('-Url',$Url,'-ShaUrl',$ShaUrl) -Phase 'SYNC'
  if ($null -eq $code) { return 4 }
  if ($code -eq 4) { L 'payload sha256 mismatch - Update-YcScripts rolled back, so C:\Scripts is unchanged.' 'ERROR'; return 4 }
  if ($code -eq 7) { L 'Update-YcScripts refused at its own gate and rolled back - C:\Scripts is unchanged.' 'ERROR'; return 4 }
  if ($code -ne 0) { return 3 }
  # The library is dot-sourced by Main after this phase returns - see Test-YcLibraryPresent.
  $vf = Join-Path $ScriptsDir 'yc-payload-version.txt'
  if (Test-Path -LiteralPath $vf) { L ('payload now: ' + ((Get-Content -LiteralPath $vf -TotalCount 1) -replace '^[^=]*=\s*','').Trim()) 'OK' }
  $n = @(Get-ChildItem -LiteralPath $ScriptsDir -File -ErrorAction SilentlyContinue).Count
  # The version string alone has lied before - a 124-entry kit and the published 138-entry zip both
  # reported the same payload_version. Count the files too.
  L ($n + ' files in ' + $ScriptsDir)
  if ($n -lt 100) { Flag 'SYNC' ($n + ' files in ' + $ScriptsDir + ' - a full payload is ~148. This looks partial.') }
  return 0
}

# ================================================================================================
# PHASE 5 - PATH.  Make  yallacloud  work, which is the whole point for an L1 on the console.
# ================================================================================================
function Invoke-Path {
  $cur = [Environment]::GetEnvironmentVariable('Path','Machine')
  $parts = @([string]$cur -split ';' | Where-Object { $_ })
  if ($parts | Where-Object { $_.TrimEnd('\') -ieq $ScriptsDir.TrimEnd('\') }) {
    L ($ScriptsDir + ' is already on the machine PATH') 'OK'
  } else {
    try {
      [Environment]::SetEnvironmentVariable('Path', (($parts + $ScriptsDir) -join ';'), 'Machine')
      L ($ScriptsDir + ' added to the machine PATH') 'OK'
    } catch { Flag 'PATH' ('could not add ' + $ScriptsDir + ' to the machine PATH: ' + $_.Exception.Message); return 3 }
  }
  # Make it work in THIS session too, so the operator can type yallacloud without signing out.
  if (($env:Path -split ';' | Where-Object { $_.TrimEnd('\') -ieq $ScriptsDir.TrimEnd('\') }).Count -eq 0) {
    $env:Path = $env:Path + ';' + $ScriptsDir
  }
  $cmd = Join-Path $ScriptsDir 'yallacloud.cmd'
  if (Test-Path -LiteralPath $cmd) { L 'yallacloud is now a command on this host - type it to see the catalog.' 'OK' }
  else { Flag 'PATH' 'yallacloud.cmd is not in the payload, so the catalog command will not resolve.' ; return 3 }
  return 0
}

# ================================================================================================
# PHASE 6 - NIC.  Ghost NICs only, and only through set-nic, which carries the deadman rollback.
# No addressing change is made here: a network change on a production VM you cannot redeploy is
# exactly the thing a human should be holding the console for.
# ================================================================================================
function Invoke-Nic {
  param($Survey)
  $ghosts = 0
  try { $ghosts = [int]$Survey.data.network.hiddenAdapterCount } catch {}
  if ($ghosts -le 0) { L 'no hidden network adapters found - nothing to clean.' 'OK'; return 0 }
  L ($ghosts + ' hidden network adapter(s) present - these hold the old static IP after a MAC change.') 'WARN'
  $code = Invoke-YcCommand -Script 'Set-Nic.ps1' -Arguments @('-CleanGhosts') -Phase 'NIC'
  if ($null -eq $code -or $code -ne 0) { return 3 }
  return 0
}

# ================================================================================================
# PHASE 7 - SQL.  Discover and REPORT. Nothing is installed, nothing is licensed, nothing is
# changed. install-sql is structurally unreachable from this file for a reason.
# ================================================================================================
function Invoke-Sql {
  param($Survey)
  $inst = @()
  try { $inst = @($Survey.data.sql) } catch {}
  if ($inst.Count -eq 0) { L 'no SQL Server instance found on this host.' 'OK'; return 0 }

  foreach ($i in $inst) {
    $ed  = $(if ($i.liveEdition) { $i.liveEdition } else { $i.edition })
    $ver = $(if ($i.liveVersion) { $i.liveVersion } else { $i.version })
    L ('SQL instance ' + $i.instance + '  edition=' + $ed + '  version=' + $ver +
       '  patch=' + $i.patchlevel + '  service=' + $i.status)
    L ('   product key: ' + $i.partialProductKey)
    if ($i.isEvaluation) {
      Flag 'SQL' ($i.instance + ' is running an EVALUATION edition. It will stop accepting connections when the period ends. Licensing a migrated customer instance is a commercial decision - raise it, do not automate it.')
    }
    if ($i.isExpress) {
      L ('   ' + $i.instance + ' is Express: 10 GB per database, 1410 MB buffer pool, no backup compression, no SQL Agent.') 'WARN'
    }
    $dbs = @($i.databases)
    L ('   ' + $dbs.Count + ' user database(s)')
    foreach ($d in $dbs) { L ('     ' + $d.name + '  recovery=' + $d.recovery + '  size=' + $d.sizeMB + ' MB') }
  }
  # licence-report is the house authority on licensing and prints no key. Run it so the JSON lands
  # beside everything else rather than re-deriving any of it here.
  $out = Join-Path $ScriptsDir 'survey\licence-report.json'
  Invoke-YcCommand -Script 'Licence-Report.ps1' -Arguments @('-Format','Json','-Path',$out) -Phase 'SQL' | Out-Null
  return 0
}

# ================================================================================================
# PHASE 8 - SQLBACKUP.  The one phase that touches production data, so it is the most careful.
#
#   REFUSES when another backup scheme is already live. Two backup systems on one database is
#   worse than one: each truncates the other's log chain and then NEITHER restore is trustworthy.
#   Detection is msdb.dbo.backupset (which records every backup, whoever took it) plus the named
#   third-party agent services from the survey.
#
#   Ola Hallengren is NOT installed. backup-sql already uses dbo.DatabaseBackup when it exists and
#   falls back to native verified T-SQL BACKUP when it does not - same files, same naming, same
#   msdb rows - so we add no objects to a database server we did not build.
#
#   Order: ONE FULL of every database first, proved, and only then the recurring tasks. A DIFF
#   with no FULL behind it restores nothing, so the tasks are not registered until the full is on
#   disk and in msdb.
# ================================================================================================
function Invoke-SqlBackup {
  param($Survey)
  $inst = @()
  try { $inst = @($Survey.data.sql | Where-Object { $_.status -eq 'Running' }) } catch {}
  if ($inst.Count -eq 0) { L 'no running SQL instance - nothing to back up.' 'OK'; return 0 }

  # --- the refusal gate ---------------------------------------------------------------------
  $agents = @()
  try { $agents = @($Survey.data.inherited.backupAgents | Where-Object { $_.status -eq 'Running' }) } catch {}
  $foreign = @($inst | Where-Object { $_.foreignBackupHistoryDays -ge 0 -and $_.foreignBackupHistoryDays -le 7 })
  $ycTasks = @()
  try { $ycTasks = @($Survey.data.us.ycTasks | Where-Object { $_ -match 'SqlBackup' }) } catch {}

  if (($agents.Count -gt 0 -or $foreign.Count -gt 0) -and $ycTasks.Count -eq 0) {
    if ($agents.Count -gt 0) {
      Flag 'SQLBACKUP' ('a third-party backup agent is RUNNING on this host: ' +
        (($agents | ForEach-Object { $_.product + ' (' + $_.service + ')' }) -join ', ') + '.')
    }
    foreach ($i in $foreign) {
      Flag 'SQLBACKUP' ($i.instance + ' has backup history in msdb from the last ' + $i.foreignBackupHistoryDays +
        ' day(s), taken by something that is not us.')
    }
    if (-not $Force) {
      L 'REFUSING the SQL backup phase. Two backup systems on one database break each other log chains and neither restore is then trustworthy.' 'ERROR'
      L 'Decide which scheme owns this instance. To proceed anyway once that decision is made, re-run with -Force.' 'WARN'
      return 2
    }
    L 'proceeding past the existing-backup gate because -Force was given. You are now running two backup schemes on this instance.' 'WARN'
  }

  # --- the first full -------------------------------------------------------------------------
  $fullArgs = @('-AllInstances','-Type','Full','-Checksum','-Verify')
  if ($BackupDir) { $fullArgs += @('-Directory',$BackupDir) }
  L 'taking the FIRST FULL backup of every user database. Nothing is scheduled until this is on disk and in msdb.'
  $code = Invoke-YcCommand -Script 'Backup-Sql.ps1' -Arguments $fullArgs -Phase 'SQLBACKUP'
  if ($null -eq $code -or $code -ne 0) {
    Flag 'SQLBACKUP' 'the first FULL backup did not complete, so NO recurring task was registered. A DIFF with no FULL behind it restores nothing.'
    return 3
  }
  L 'first FULL backup completed and verified.' 'OK'

  # --- the recurring tasks ----------------------------------------------------------------------
  # FULL weekly, DIFF on the other six days, LOG every 15 minutes for FULL-recovery databases.
  # Same shape install-sql uses on a fresh VM, so a migrated box and a built box look identical in
  # the task list - except for the name, which says where it came from.
  $rc = 0
  $rc += Register-AdoptTask -Name 'YC-Adopt-SqlBackupFull' -BackupType 'Full' -Weekly   -At '01:15'
  $rc += Register-AdoptTask -Name 'YC-Adopt-SqlBackupDiff' -BackupType 'Diff' -Daily    -At '01:15'
  $anyFull = @()
  foreach ($i in $inst) { $anyFull += @($i.databases | Where-Object { $_.recovery -eq 'FULL' }) }
  if ($anyFull.Count -gt 0) {
    L ($anyFull.Count + ' database(s) are in FULL recovery, so the log must be backed up or it grows until the disk fills.')
    $rc += Register-AdoptTask -Name 'YC-Adopt-SqlBackupLog' -BackupType 'Log' -Daily -At '00:05' -RepeatMinutes 15
  } else {
    L 'no database is in FULL recovery - no log backup task is needed.' 'OK'
  }
  if ($rc -ne 0) { return 3 }
  return 0
}

# Additive, never destructive: a task that already exists is LEFT ALONE and flagged. Overwriting
# somebody else's backup schedule because our name happened to match is the destructive edit this
# whole posture exists to prevent.
function Register-AdoptTask {
  param([string]$Name,[string]$BackupType,[switch]$Daily,[switch]$Weekly,[string]$At,[int]$RepeatMinutes=0)
  $existing = $null
  try { $existing = Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue } catch {}
  if ($existing) {
    Flag 'SQLBACKUP' ('scheduled task ' + $Name + ' already exists - left exactly as it is. Check it is what you want.')
    return 0
  }
  $bs = Join-Path $ScriptsDir 'Backup-Sql.ps1'
  if (-not (Test-Path -LiteralPath $bs)) { Flag 'SQLBACKUP' 'Backup-Sql.ps1 is not in the payload, so no backup task was registered.'; return 1 }
  $a = '-NoProfile -ExecutionPolicy Bypass -File "' + $bs + '" -AllInstances -Type ' + $BackupType + ' -Checksum -Verify'
  if ($BackupDir) { $a += ' -Directory "' + $BackupDir + '"' }
  try {
    $atTime = [datetime]::ParseExact($At,'HH:mm',[Globalization.CultureInfo]::InvariantCulture)
    $act = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $a
    if ($Weekly) { $trg = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At $atTime }
    else         { $trg = New-ScheduledTaskTrigger -Daily -At $atTime }
    if ($RepeatMinutes -gt 0) {
      # RepetitionInterval is set on the TRIGGER. Setting it on the settings set silently does
      # nothing on Server 2019 - the exception is swallowed and the log claims a repeat that never
      # happened. Same trap Yc-AutoUpdate hit with RandomDelay.
      try {
        $trg.Repetition = (New-ScheduledTaskTrigger -Once -At $atTime `
                            -RepetitionInterval (New-TimeSpan -Minutes $RepeatMinutes) `
                            -RepetitionDuration (New-TimeSpan -Days 1)).Repetition
      } catch { Flag 'SQLBACKUP' ($Name + ': this build would not accept a ' + $RepeatMinutes + '-minute repeat, so the log backup runs ONCE a day, not every ' + $RepeatMinutes + ' minutes.') }
    }
    $pri = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
             -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 4)
    Register-ScheduledTask -TaskName $Name -Action $act -Trigger $trg -Principal $pri -Settings $set -Force | Out-Null
    # Read it back, every time. "Registered without error" is not "the task is there".
    if (Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue) {
      L ($Name + ' registered (' + $(if ($Weekly) {'weekly Sunday'} else {'daily'}) + ' ' + $At +
         $(if ($RepeatMinutes -gt 0) { ', repeating every ' + $RepeatMinutes + ' min' } else { '' }) +
         ', SYSTEM) - existence confirmed.') 'OK'
      return 0
    }
    Flag 'SQLBACKUP' ('Register-ScheduledTask returned without error but ' + $Name + ' is not there.')
    return 1
  } catch { Flag 'SQLBACKUP' ('could not register ' + $Name + ': ' + $_.Exception.Message); return 1 }
}

# ================================================================================================
# PHASE 9 - TASKS.  The two recurring jobs that keep this machine current and visible. Installed
# through their OWN commands, because those already read their registration back and already know
# what a correct trigger set looks like on this build. ONLY IF ABSENT.
# ================================================================================================
function Invoke-Tasks {
  param($Survey)
  $have = @()
  try { $have = @($Survey.data.us.ycTasks) } catch {}
  $rc = 0

  if ($have -contains 'YC-AutoUpdate') { L 'YC-AutoUpdate already exists - left alone.' 'OK' }
  else {
    # Keeps C:\Scripts current from the public repo: startup, on network, daily 00:01 with a 30 min
    # random delay so the fleet does not hit raw.githubusercontent.com at the same second.
    $c = Invoke-YcCommand -Script 'Yc-AutoUpdate.ps1' -Arguments @('-Install') -Phase 'TASKS'
    if ($null -eq $c -or $c -ne 0) { $rc = 3 }
  }

  if ($have -contains 'YC-Inventory') { L 'YC-Inventory already exists - left alone.' 'OK' }
  else {
    # -Install collects, writes, PROVES the file and only THEN registers the task - deliberately,
    # after a version that registered first and left hosts with a task that did nothing.
    $c = Invoke-YcCommand -Script 'Report-Inventory.ps1' -Arguments @('-Install','-Tag','migrated') -Phase 'TASKS'
    if ($null -eq $c -or $c -ne 0) { $rc = 3 }
  }
  return $rc
}

# ================================================================================================
# PHASE 10 - NOTIFY.  Say, in three places that outlast this session, that this machine is now
# managed by the YallaCloud scripts: a marker file, a registry stamp an inventory sweep can read,
# and a fleet event.
# ================================================================================================
function Invoke-Notify {
  param($Survey)
  $h = Get-HostNameSafe
  $payload = ''
  $vf = Join-Path $ScriptsDir 'yc-payload-version.txt'
  if (Test-Path -LiteralPath $vf) { $payload = ((Get-Content -LiteralPath $vf -TotalCount 1) -replace '^[^=]*=\s*','').Trim() }

  $marker = [ordered]@{
    schema        = 'ycadopt.marker/1'
    host          = $h
    source        = 'migrated'
    adoptedUtc    = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
    payloadVersion= $payload
    scriptsDir    = $ScriptsDir
    phasesRun     = @($script:Done)
    flags         = @($script:Flags)
    note          = 'This VM was MIGRATED and has been configured with the YallaCloud C-Scripts toolkit. It is on the same payload channel as a freshly deployed VM. Type  yallacloud  for the command catalog.'
  }
  try {
    if (-not (Test-Path -LiteralPath $script:MarkerDir)) { New-Item -ItemType Directory -Path $script:MarkerDir -Force | Out-Null }
    $marker | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $script:Marker -Encoding Ascii
    L ('marker written: ' + $script:Marker) 'OK'
  } catch { Flag 'NOTIFY' ('could not write ' + $script:Marker + ': ' + $_.Exception.Message) }

  # A registry stamp, because that is what an inventory sweep reads without parsing a file.
  try {
    $k = 'HKLM:\SOFTWARE\YallaCloud'
    if (-not (Test-Path -LiteralPath $k)) { New-Item -Path $k -Force | Out-Null }
    New-ItemProperty -Path $k -Name 'Source'         -Value 'migrated'      -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $k -Name 'AdoptedUtc'     -Value $marker.adoptedUtc -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $k -Name 'PayloadVersion' -Value $payload        -PropertyType String -Force | Out-Null
    L 'registry stamp written: HKLM:\SOFTWARE\YallaCloud (Source=migrated)' 'OK'
  } catch { Flag 'NOTIFY' ('could not write the registry stamp: ' + $_.Exception.Message) }

  # The fleet event. yc-event knows how to find out who this VM is and queues to disk when the
  # receiver is unreachable, so a missing event is never silently lost.
  $step = 'ADOPT ' + ($script:Done -join '+')
  Invoke-YcCommand -Script 'Yc-Event.ps1' -Arguments @('-Type','vm.adopt.completed','-Step',$step) -Phase 'NOTIFY' | Out-Null
  return 0
}

# ================================================================================================
# PHASE 11 - VERIFY.  Rule 4: prove it changed nothing else. The post-survey is diffed against the
# pre-survey and ANY delta outside the set this script is allowed to cause is reported loudly.
# ================================================================================================
function Invoke-Verify {
  param($Pre)
  $post = Invoke-Survey -Label 'post'
  $deltas = New-Object System.Collections.Generic.List[string]

  # Things this script is ALLOWED to change. Anything else that moved is worth a human reading.
  $expected = @('us.fileCount','us.payloadVersion','us.ycTasks','us.onPath','network.hiddenAdapterCount')

  foreach ($pair in @(
      @{ n='identity.caption';  a=$Pre.data.identity.caption;  b=$post.data.identity.caption },
      @{ n='identity.domain';   a=$Pre.data.identity.domain;   b=$post.data.identity.domain },
      @{ n='nic count';         a=@($Pre.data.network.nics).Count;  b=@($post.data.network.nics).Count },
      @{ n='sql instance count';a=@($Pre.data.sql).Count;      b=@($post.data.sql).Count },
      @{ n='antivirus';         a=(@($Pre.data.inherited.antivirus) -join ','); b=(@($post.data.inherited.antivirus) -join ',') },
      @{ n='backup agents';     a=@($Pre.data.inherited.backupAgents).Count;    b=@($post.data.inherited.backupAgents).Count },
      @{ n='non-Microsoft task count'; a=@($Pre.data.inherited.nonMicrosoftTasks).Count; b=@($post.data.inherited.nonMicrosoftTasks).Count }
    )) {
    if ([string]$pair.a -ne [string]$pair.b) { $deltas.Add(($pair.n + ': ' + $pair.a + ' -> ' + $pair.b)) | Out-Null }
  }

  # The task count is expected to rise by exactly the tasks we registered. Anything else is not.
  $added = @(@($post.data.inherited.nonMicrosoftTasks) | Where-Object { @($Pre.data.inherited.nonMicrosoftTasks) -notcontains $_ })
  $ours  = @($added | Where-Object { $_ -match '^(YC-Adopt-|YC-AutoUpdate|YC-Inventory|YC-AdoptResume)' })
  $theirs= @($added | Where-Object { $_ -notmatch '^(YC-Adopt-|YC-AutoUpdate|YC-Inventory|YC-AdoptResume)' })
  if ($ours.Count)  { L ('tasks added by this run: ' + ($ours -join ', ')) 'OK' }
  if ($theirs.Count){ Flag 'VERIFY' ('scheduled tasks appeared that this script did not create: ' + ($theirs -join ', ')) }

  $realDeltas = @($deltas | Where-Object { $_ -notmatch '^non-Microsoft task count' })
  if ($realDeltas.Count -eq 0) {
    L 'VERIFY: nothing changed outside the set this script is allowed to change.' 'OK'
    L ('post-survey: ' + $post.path)
    return 0
  }
  foreach ($d in $realDeltas) { Flag 'VERIFY' ('UNEXPECTED CHANGE - ' + $d) }
  L ('post-survey: ' + $post.path)
  return 3
}

# ================================================================================================
# -Status.  What happened to this machine, read back from disk. Changes nothing.
# ================================================================================================
function Show-Status {
  $h = Get-HostNameSafe
  Write-Host ''
  Write-Host ('  ADOPT STATUS  -  ' + $h) -ForegroundColor Green
  Write-Host ''
  if (Test-Path -LiteralPath $script:Marker) {
    try {
      $m = Get-Content -LiteralPath $script:Marker -Raw | ConvertFrom-Json
      Write-Host ('    adopted         : YES, ' + $m.adoptedUtc + ' UTC')
      Write-Host ('    source          : ' + $m.source)
      Write-Host ('    payload version : ' + $m.payloadVersion)
      Write-Host ('    phases run      : ' + (@($m.phasesRun) -join ', '))
      if (@($m.flags).Count) {
        Write-Host ('    flags           : ' + @($m.flags).Count + ' - a human still has to read these:') -ForegroundColor Magenta
        foreach ($f in @($m.flags)) { Write-Host ('                      - ' + $f) -ForegroundColor Magenta }
      } else { Write-Host '    flags           : none' }
    } catch { Write-Host '    adopted         : marker present but unreadable' -ForegroundColor Yellow }
  } else {
    Write-Host '    adopted         : NO - this machine has not been through migrated-vm.' -ForegroundColor Yellow
  }
  $n = 0
  if (Test-Path -LiteralPath $ScriptsDir) { $n = @(Get-ChildItem -LiteralPath $ScriptsDir -File -ErrorAction SilentlyContinue).Count }
  Write-Host ('    C:\Scripts      : ' + $n + ' files' + $(if (Test-ScriptsOnPathLocal) { ', on PATH' } else { ', NOT on PATH' }))
  Write-Host ('    resume task     : ' + $(if (Get-ScheduledTask -TaskName $script:ResumeTask -ErrorAction SilentlyContinue) { 'PRESENT - a run is waiting for a reboot' } else { 'none' }))
  $tasks = @()
  try { $tasks = @(Get-ScheduledTask -ErrorAction Stop | Where-Object { $_.TaskName -match '^YC-' } | ForEach-Object { $_.TaskName }) } catch {}
  Write-Host ('    YC tasks        : ' + $(if ($tasks.Count) { ($tasks -join ', ') } else { 'none' }))
  Write-Host ('    log             : ' + $script:LogPath)
  Write-Host ''
}

# Every exit path closes the transcript. Two of them did not: the terminal-phase stop (including
# the reboot path, which is exactly the run somebody comes back to read) and the normal end left
# the log open with no [END] line and no recorded exit code. yc-compliance EXITDISC blocks on it.
function Exit-Adopt {
  param([int]$Code)
  L ('END exit=' + $Code)
  if ($script:LibOK -and (Get-Command Stop-YcLog -ErrorAction SilentlyContinue)) { Stop-YcLog $Code }
  exit $Code
}

# ================================================================================================
# Help
# ================================================================================================
$Usage = @'
migrated-vm  -  bring a MIGRATED VM up to the same day-2 standard as one we built ourselves.

WHAT IT IS FOR
  A fresh VM gets C:\Scripts, the scheduled tasks, the reports and the backups because the
  userdata runs on first boot. A VM migrated from vCenter or OpenStack gets none of that - there
  is no first link in the chain. This is that first link, run ONCE on the migrated guest.

  After it runs, the machine pulls the same payload from the same URL as every fresh VM, keeps
  itself current, and appears in the fleet view. Nothing special about it afterwards.

MODES
  migrated-vm -Report            look only. Surveys the machine, writes the JSON, changes NOTHING.
                                 THIS IS THE DEFAULT. Run it first, read it, then run -Run.
  migrated-vm -Run               do the work.
  migrated-vm -Status            what was done to this machine, read back from disk.
  migrated-vm -Help              this text.

OPTIONS
  -Only <phases>     run just these        SURVEY PREREQ BOOTSTRAP SYNC PATH NIC SQL SQLBACKUP
  -Skip <phases>     run all but these     TASKS NOTIFY VERIFY
  -AllowReboot       reboot immediately when a prerequisite needs it (default: stop and let a
                     human pick the moment - the resume task is registered either way)
  -Force             proceed past a refusal. Says in the log what it is overriding.
  -BackupDir <path>  SQL backup root. Omitted: backup-sql decides (Ola directory, or its default)
  -Url / -ShaUrl     payload and sidecar. Defaults are the frozen public URLs.

THE PHASES
  SURVEY     read-only inventory -> C:\Scripts\survey\<host>-<stamp>-pre.json. The baseline
             VERIFY later diffs against. Nothing else runs until this has.
  PREREQ     admin, PowerShell 5.1, TLS 1.2, free space, egress, and PENDING REBOOT. A pending
             reboot registers YC-AdoptResume and stops at exit 1 - reboot and it continues itself.
  BOOTSTRAP  fetch the payload zip + .sha256, VERIFY THE HASH, extract Update-YcScripts.ps1 only.
             The one new download path in the estate. Runs once, never again.
  SYNC       update-yc-scripts - the full payload, same channel as every fresh VM.
  PATH       put C:\Scripts on the machine PATH so  yallacloud  works.
  NIC        set-nic -CleanGhosts, only if hidden adapters are present. No addressing change.
  SQL        discover instances: edition, version, patch level, evaluation, databases. REPORTS.
             Never installs, never licenses - activation is a commercial decision.
  SQLBACKUP  ONE FULL of every database first, proved, THEN the recurring tasks:
               YC-Adopt-SqlBackupFull   weekly  Sunday 01:15
               YC-Adopt-SqlBackupDiff   daily   01:15
               YC-Adopt-SqlBackupLog    every 15 min, only if a database is in FULL recovery
             REFUSES if another backup scheme is already live. Ola is not installed: backup-sql
             uses dbo.DatabaseBackup when it exists and native verified BACKUP when it does not.
  TASKS      YC-AutoUpdate and YC-Inventory, through their own commands, ONLY IF ABSENT.
  NOTIFY     marker file, registry stamp (HKLM:\SOFTWARE\YallaCloud Source=migrated), fleet event.
  VERIFY     post-survey diffed against the pre-survey. Any unexpected change is reported loudly.

THE FOUR RULES IT OBEYS
  1. Survey before touch.                  3. Reversible, undo recorded BEFORE the change.
  2. Additive, never destructive.          4. Prove it changed nothing else.
  Anything that cannot satisfy all four is FLAGGED FOR A HUMAN, not automated.

WHAT IT WILL NOT DO
  install-sql        destructive on a migrated SQL box. Unreachable from here.
  activate-windows   the MAC changes on migration so activation often drops. Re-licensing a
                     customer VM onto our agreement is commercial. REPORT ONLY.
  install Ola        adds objects to a database server we did not build.
  remove anything it cannot positively identify.

EXIT CODES
   0  every requested phase completed
   1  reboot required; YC-AdoptResume registered. Reboot and it continues by itself.
   2  REFUSED at a gate (-Force overrides, and says what it overrode)
   3  PARTIAL - finished, but one or more phases were flagged for a human
   4  payload sha256 mismatch - nothing was installed, the update rolled back
   5  not elevated
   6  no HTTPS egress to the payload host

Log:
  C:\Scripts\adopt-migrated-vm.log          every line, also in the Application event log,
                                            source YALLACLOUD, tagged [YALLACLOUD][adopt-migrated-vm]

FILES
  C:\Scripts\adopt-migrated-vm.log          the log above
  C:\Scripts\adopt-migrated-vm.state.json   phase state, survives a reboot
  C:\Scripts\survey\<host>-<stamp>-pre.json / -post.json
  C:\ProgramData\YallaCloud\adopted.json    the marker that says this VM is managed by us

EXAMPLES
  migrated-vm -Report                       look first. Always.
  migrated-vm -Run                          the whole thing
  migrated-vm -Run -AllowReboot             let it reboot itself if a prerequisite demands it
  migrated-vm -Run -Skip SQLBACKUP          adopt the box, leave the database alone for now
  migrated-vm -Only SURVEY,SQL              just tell me what SQL is on here
  migrated-vm -Status                       what was done to this machine
'@

if ($Help -or ($PSBoundParameters.Count -eq 0 -and -not $Run -and -not $Status -and -not $Resume -and -not $Report)) {
  if ($Help) { Write-Host $Usage; exit 0 }
}

# ================================================================================================
# Main
# ================================================================================================
if ($Help)   { Write-Host $Usage; exit 0 }
if ($Status) { Show-Status; exit 0 }

# -Report is the default on purpose. The first thing you do to a machine holding production data
# is look at it, and a bare "migrated-vm" must never start changing one.
if (-not $Run -and -not $Resume) { $Report = $true }

$phases = $AllPhases
if ($Only) {
  $bad = @($Only | Where-Object { $AllPhases -notcontains $_.ToUpper() })
  if ($bad.Count) { L ('unknown phase(s): ' + ($bad -join ', ') + '. Valid: ' + ($AllPhases -join ' ')) 'ERROR'; exit 2 }
  $phases = @($AllPhases | Where-Object { $Only.ToUpper() -contains $_ })
}
if ($Skip) {
  $bad = @($Skip | Where-Object { $AllPhases -notcontains $_.ToUpper() })
  if ($bad.Count) { L ('unknown phase(s): ' + ($bad -join ', ') + '. Valid: ' + ($AllPhases -join ' ')) 'ERROR'; exit 2 }
  $phases = @($phases | Where-Object { $Skip.ToUpper() -notcontains $_ })
}
if ($Report) { $phases = @('SURVEY','SQL') }

L ('START  mode=' + $(if ($Report) {'REPORT (nothing will be changed)'} elseif ($Resume) {'RESUME after reboot'} else {'RUN'}) +
   '  host=' + (Get-HostNameSafe) + '  phases=' + ($phases -join ','))
if ($Resume) { L 'resumed by YC-AdoptResume after a reboot.' }

# Dot-source the house library AT SCRIPT SCOPE so the definitions outlive this statement. If the
# payload is not here yet, L stays on its built-in logger until SYNC lands it and the loop below
# tries again. Nothing depends on which logger is active - only the line format differs.
if ((-not $script:LibOK) -and (Test-YcLibraryPresent)) {
  try {
    . (Join-Path $ScriptsDir '_yc-lib.ps1')
    if (Get-Command Start-YcLog -ErrorAction SilentlyContinue) { Start-YcLog -Name $script:Tag -Dir $ScriptsDir | Out-Null }
    $script:LibOK = $true
    L 'house library loaded - log format, secret redaction and the Application event log are now the fleet standard.'
  } catch { L ('could not load the house library: ' + $_.Exception.Message) 'WARN' }
}

$pre  = $null
$exit = 0

foreach ($p in $phases) {
  L ('--- phase ' + $p + ' ---')
  $rc = 0
  switch ($p) {
    'SURVEY'    { $pre = Invoke-Survey -Label 'pre'; $rc = 0 }
    'PREREQ'    { $rc = Invoke-Prereq }
    'BOOTSTRAP' { $rc = Invoke-Bootstrap }
    'SYNC'      { $rc = Invoke-Sync }
    'PATH'      { $rc = Invoke-Path }
    'NIC'       { if ($pre) { $rc = Invoke-Nic -Survey $pre } else { Flag 'NIC' 'no survey, so the ghost-NIC count is unknown. Skipped.'; $rc = 3 } }
    'SQL'       { if (-not $pre) { $pre = Invoke-Survey -Label 'pre' }; $rc = Invoke-Sql -Survey $pre }
    'SQLBACKUP' { if (-not $pre) { $pre = Invoke-Survey -Label 'pre' }; $rc = Invoke-SqlBackup -Survey $pre }
    'TASKS'     { if (-not $pre) { $pre = Invoke-Survey -Label 'pre' }; $rc = Invoke-Tasks -Survey $pre }
    'NOTIFY'    { $rc = Invoke-Notify -Survey $pre }
    'VERIFY'    { if ($pre) { $rc = Invoke-Verify -Pre $pre } else { L 'VERIFY skipped - there is no pre-survey to diff against.' 'WARN'; $rc = 3 } }
  }
  # 5, 6, 4 and 1 are terminal: there is no point running the next phase on a box that is not
  # elevated, has no egress, could not verify the payload, or is waiting for a reboot.
  if ($rc -in @(1,4,5,6)) {
    Save-State $p 'stopped'
    L ('STOPPING at ' + $p + ' with exit ' + $rc) $(if ($rc -eq 1) {'WARN'} else {'ERROR'})
    Exit-Adopt $rc
  }
  # SYNC is what puts _yc-lib.ps1 on disk, so this is the first moment the real logger can exist.
  if ($p -eq 'SYNC' -and $rc -eq 0 -and -not $script:LibOK -and (Test-YcLibraryPresent)) {
    try {
      . (Join-Path $ScriptsDir '_yc-lib.ps1')
      if (Get-Command Start-YcLog -ErrorAction SilentlyContinue) { Start-YcLog -Name $script:Tag -Dir $ScriptsDir | Out-Null }
      $script:LibOK = $true
      L 'house library loaded - log format, secret redaction and the Application event log are now the fleet standard.'
    } catch { L ('could not load the house library: ' + $_.Exception.Message) 'WARN' }
  }
  if ($rc -eq 2) { $exit = 2 }
  elseif ($rc -ne 0 -and $exit -eq 0) { $exit = 3 }
  $script:Done.Add($p) | Out-Null
  Save-State $p $(if ($rc -eq 0) { 'ok' } else { 'flagged' })
}

# A completed run owns the cleanup of its own resume task.
if (-not $Report) { Unregister-ResumeTask }

Write-Host ''
if ($Report) {
  L 'REPORT ONLY - nothing on this machine was changed.' 'OK'
  L 'When you have read the survey, run:  migrated-vm -Run'
} else {
  if ($script:Flags.Count -eq 0) {
    L ('ADOPTED. Phases: ' + ($script:Done -join ', ') + '. No flags.') 'OK'
    L 'This VM is now on the same payload channel as a freshly deployed one. Type  yallacloud  for the catalog.' 'OK'
  } else {
    L ($script:Flags.Count + ' item(s) need a human. Nothing below was guessed at:') 'WARN'
    foreach ($f in $script:Flags) { L ('   - ' + $f) 'FLAG' }
    if ($exit -eq 0) { $exit = 3 }
  }
}
Exit-Adopt $exit
